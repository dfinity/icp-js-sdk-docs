---
title: AuthClient
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:196](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L196)

Tool to manage authentication and identity

## See

AuthClient

## Constructors

### Constructor

> `protected` **new AuthClient**(`_identity`, `_key`, `_chain`, `_storage`, `idleManager`, `_createOptions`, `_idpWindow?`, `_eventHandler?`): `AuthClient`

Defined in: [auth-client.ts:331](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L331)

#### Parameters

##### \_identity

`PartialIdentity` | `Identity`

##### \_key

`SignIdentity` | `PartialIdentity`

##### \_chain

`DelegationChain` | `null`

##### \_storage

[`AuthClientStorage`](../interfaces/AuthClientStorage.md)

##### idleManager

[`IdleManager`](IdleManager.md) | `undefined`

##### \_createOptions

[`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md) | `undefined`

##### \_idpWindow?

`Window`

##### \_eventHandler?

(`event`) => `void`

#### Returns

`AuthClient`

## Properties

### idleManager

> **idleManager**: [`IdleManager`](IdleManager.md) \| `undefined`

Defined in: [auth-client.ts:336](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L336)

## Methods

### getIdentity()

> **getIdentity**(): `Identity`

Defined in: [auth-client.ts:419](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L419)

#### Returns

`Identity`

***

### isAuthenticated()

> **isAuthenticated**(): `Promise`\<`boolean`\>

Defined in: [auth-client.ts:423](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L423)

#### Returns

`Promise`\<`boolean`\>

***

### login()

> **login**(`options?`): `Promise`\<`void`\>

Defined in: [auth-client.ts:456](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L456)

AuthClient Login - Opens up a new window to authenticate with Internet Identity

#### Parameters

##### options?

[`AuthClientLoginOptions`](../interfaces/AuthClientLoginOptions.md)

Options for logging in, merged with the options set during creation if any. Note: we only perform a shallow merge for the `customValues` property.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
const authClient = await AuthClient.create();
authClient.login({
 identityProvider: 'http://<canisterID>.127.0.0.1:8000',
 maxTimeToLive: BigInt (7) * BigInt(24) * BigInt(3_600_000_000_000), // 1 week
 windowOpenerFeatures: "toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100",
 onSuccess: () => {
   console.log('Login Successful!');
 },
 onError: (error) => {
   console.error('Login Failed: ', error);
 }
});
```

***

### loginWithIcrc29()

> **loginWithIcrc29**(`options?`): `Promise`\<`void`\>

Defined in: [auth-client.ts:504](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L504)

#### Parameters

##### options?

[`AuthClientLoginOptions`](../interfaces/AuthClientLoginOptions.md)

#### Returns

`Promise`\<`void`\>

***

### logout()

> **logout**(`options`): `Promise`\<`void`\>

Defined in: [auth-client.ts:613](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L613)

#### Parameters

##### options

###### returnTo?

`string`

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `Promise`\<`AuthClient`\>

Defined in: [auth-client.ts:218](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L218)

Create an AuthClient to manage authentication and identity

#### Parameters

##### options

[`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md) = `{}`

Options for creating an AuthClient

#### Returns

`Promise`\<`AuthClient`\>

#### See

 - [AuthClientCreateOptions](../interfaces/AuthClientCreateOptions.md)
 - SignIdentity
 - [AuthClientStorage](../interfaces/AuthClientStorage.md)
 - [IdleOptions](../interfaces/IdleOptions.md)
Default behavior is to clear stored identity and reload the page when a user goes idle, unless you set the disableDefaultIdleCallback flag or pass in a custom idle callback.

#### Example

```ts
const authClient = await AuthClient.create({
  idleOptions: {
    disableIdle: true
  }
})
```
