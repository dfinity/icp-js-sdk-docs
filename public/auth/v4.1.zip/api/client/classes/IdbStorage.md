---
title: IdbStorage
editUrl: false
next: true
prev: true
---

Defined in: [storage.ts:65](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/storage.ts#L65)

IdbStorage is an interface for simple storage of string key-value pairs built on [IdbKeyVal](IdbKeyVal.md)

It replaces [LocalStorage](LocalStorage.md)

## See

implements [AuthClientStorage](../interfaces/AuthClientStorage.md)

## Implements

- [`AuthClientStorage`](../interfaces/AuthClientStorage.md)

## Constructors

### Constructor

> **new IdbStorage**(`options?`): `IdbStorage`

Defined in: [storage.ts:78](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/storage.ts#L78)

#### Parameters

##### options?

[`DBCreateOptions`](../type-aliases/DBCreateOptions.md)

DBCreateOptions

#### Returns

`IdbStorage`

#### Example

```ts
const storage = new IdbStorage({ dbName: 'my-db', storeName: 'my-store', version: 2 });
```

## Accessors

### \_db

#### Get Signature

> **get** **\_db**(): `Promise`\<[`IdbKeyVal`](IdbKeyVal.md)\>

Defined in: [storage.ts:84](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/storage.ts#L84)

##### Returns

`Promise`\<[`IdbKeyVal`](IdbKeyVal.md)\>

## Methods

### get()

> **get**\<`T`\>(`key`): `Promise`\<`null` \| `T`\>

Defined in: [storage.ts:97](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/storage.ts#L97)

#### Type Parameters

##### T

`T` = `string`

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`null` \| `T`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`get`](../interfaces/AuthClientStorage.md#get)

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [storage.ts:108](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/storage.ts#L108)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`remove`](../interfaces/AuthClientStorage.md#remove)

***

### set()

> **set**\<`T`\>(`key`, `value`): `Promise`\<`void`\>

Defined in: [storage.ts:103](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/storage.ts#L103)

#### Type Parameters

##### T

`T` = `string`

#### Parameters

##### key

`string`

##### value

`T`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`set`](../interfaces/AuthClientStorage.md#set)
