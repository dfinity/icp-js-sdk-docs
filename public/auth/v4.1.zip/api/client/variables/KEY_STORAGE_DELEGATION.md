---
title: KEY_STORAGE_DELEGATION
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_DELEGATION**: `"delegation"` = `'delegation'`

Defined in: [storage.ts:4](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/storage.ts#L4)
