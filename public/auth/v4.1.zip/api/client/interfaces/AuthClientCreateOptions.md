---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:53](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/auth-client.ts#L53)

List of options for creating an [AuthClient](../classes/AuthClient.md).

## Properties

### identity?

> `optional` **identity**: `SignIdentity` \| `PartialIdentity`

Defined in: [auth-client.ts:57](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/auth-client.ts#L57)

An SignIdentity or PartialIdentity to authenticate via delegation.

***

### idleOptions?

> `optional` **idleOptions**: [`IdleOptions`](IdleOptions.md)

Defined in: [auth-client.ts:77](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/auth-client.ts#L77)

Options to handle idle timeouts

#### Default

```ts
after 10 minutes, invalidates the identity
```

***

### keyType?

> `optional` **keyType**: `BaseKeyType`

Defined in: [auth-client.ts:71](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/auth-client.ts#L71)

Type to use for the base key.

If you are using a custom storage provider that does not support CryptoKey storage,
you should use `Ed25519` as the key type, as it can serialize to a string.

#### Default

```ts
'ECDSA'
```

***

### loginOptions?

> `optional` **loginOptions**: [`AuthClientLoginOptions`](AuthClientLoginOptions.md)

Defined in: [auth-client.ts:82](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/auth-client.ts#L82)

Options to handle login, passed to the login method

***

### storage?

> `optional` **storage**: [`AuthClientStorage`](AuthClientStorage.md)

Defined in: [auth-client.ts:62](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/auth-client.ts#L62)

Optional storage with get, set, and remove. Uses [IdbStorage](../classes/IdbStorage.md) by default.

#### See

[AuthClientStorage](AuthClientStorage.md)
