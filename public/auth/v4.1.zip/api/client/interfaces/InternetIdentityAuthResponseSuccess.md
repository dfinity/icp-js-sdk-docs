---
title: InternetIdentityAuthResponseSuccess
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:152](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L152)

## Properties

### authnMethod

> **authnMethod**: `"passkey"` \| `"pin"` \| `"recovery"`

Defined in: [auth-client.ts:163](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L163)

***

### delegations

> **delegations**: `object`[]

Defined in: [auth-client.ts:154](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L154)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `bigint`

##### delegation.pubkey

> **pubkey**: `Uint8Array`

##### delegation.targets?

> `optional` **targets**: `Principal`[]

#### signature

> **signature**: `Uint8Array`

***

### kind

> **kind**: `"authorize-client-success"`

Defined in: [auth-client.ts:153](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L153)

***

### userPublicKey

> **userPublicKey**: `Uint8Array`

Defined in: [auth-client.ts:162](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L162)
