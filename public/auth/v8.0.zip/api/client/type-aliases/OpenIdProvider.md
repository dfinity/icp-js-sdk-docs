---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:45](https://github.com/dfinity/icp-js-auth/blob/1bac50f4e4bcb0679ea5a1bfdc17bf3dacaee21a/src/client/auth-client.ts#L45)
