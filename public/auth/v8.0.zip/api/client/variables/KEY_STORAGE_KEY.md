---
title: KEY_STORAGE_KEY
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_KEY**: `"identity"` = `'identity'`

Defined in: [storage.ts:3](https://github.com/dfinity/icp-js-auth/blob/1bac50f4e4bcb0679ea5a1bfdc17bf3dacaee21a/src/client/storage.ts#L3)
