---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:164](https://github.com/dfinity/icp-js-auth/blob/1bac50f4e4bcb0679ea5a1bfdc17bf3dacaee21a/src/client/auth-client.ts#L164)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [auth-client.ts:165](https://github.com/dfinity/icp-js-auth/blob/1bac50f4e4bcb0679ea5a1bfdc17bf3dacaee21a/src/client/auth-client.ts#L165)

***

### signature

> **signature**: `Uint8Array`

Defined in: [auth-client.ts:166](https://github.com/dfinity/icp-js-auth/blob/1bac50f4e4bcb0679ea5a1bfdc17bf3dacaee21a/src/client/auth-client.ts#L166)
