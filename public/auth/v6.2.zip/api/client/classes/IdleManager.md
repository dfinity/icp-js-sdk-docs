---
title: IdleManager
editUrl: false
next: true
prev: true
---

Defined in: [idle-manager.ts:35](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/idle-manager.ts#L35)

Detects if the user has been idle for a duration of `idleTimeout` ms, and calls `onIdle` and registered callbacks.
By default, the IdleManager will log a user out after 10 minutes of inactivity.
To override these defaults, you can pass an `onIdle` callback, or configure a custom `idleTimeout` in milliseconds.

IdleManager is a singleton: multiple calls to `create()` return the same instance,
registering any new `onIdle` callback. Call `exit()` to tear down the singleton.

## Methods

### exit()

> **exit**(): `void`

Defined in: [idle-manager.ts:140](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/idle-manager.ts#L140)

Tears down listeners, fires all callbacks, and clears the singleton.

#### Returns

`void`

***

### registerCallback()

> **registerCallback**(`callback`): `void`

Defined in: [idle-manager.ts:133](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/idle-manager.ts#L133)

#### Parameters

##### callback

`IdleCB`

function to be called when user goes idle

#### Returns

`void`

***

### create()

> `static` **create**(`options?`): `IdleManager`

Defined in: [idle-manager.ts:54](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/idle-manager.ts#L54)

Creates or returns the singleton IdleManager.
If the instance already exists, any provided `onIdle` callback is registered
on the existing instance.

#### Parameters

##### options?

Optional configuration

###### captureScroll?

`boolean`

capture scroll events

**Default**

```ts
false
```

###### idleTimeout?

`number`

timeout in ms

**Default**

```ts
10 minutes [600_000]
```

###### onIdle?

() => `unknown`

Callback after the user has gone idle

**See**

IdleCB

###### scrollDebounce?

`number`

scroll debounce time in ms

**Default**

```ts
100
```

#### Returns

`IdleManager`

#### See

[IdleManagerOptions](../type-aliases/IdleManagerOptions.md)
