---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:135](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/auth-client.ts#L135)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [auth-client.ts:136](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/auth-client.ts#L136)

***

### signature

> **signature**: `Uint8Array`

Defined in: [auth-client.ts:137](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/auth-client.ts#L137)
