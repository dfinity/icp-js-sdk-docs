---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:40](https://github.com/dfinity/icp-js-auth/blob/4e5b2734bf168d17eb8f7fb960271e2b48011d42/src/client/auth-client.ts#L40)
