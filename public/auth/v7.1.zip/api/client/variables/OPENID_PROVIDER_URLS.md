---
title: OPENID_PROVIDER_URLS
editUrl: false
next: true
prev: true
---

> `const` **OPENID\_PROVIDER\_URLS**: `object`

Defined in: [auth-client.ts:42](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L42)

## Type Declaration

### apple

> `readonly` **apple**: `"https://appleid.apple.com"` = `'https://appleid.apple.com'`

### google

> `readonly` **google**: `"https://accounts.google.com"` = `'https://accounts.google.com'`

### microsoft

> `readonly` **microsoft**: `"https://login.microsoftonline.com/{tid}/v2.0"` = `'https://login.microsoftonline.com/{tid}/v2.0'`
