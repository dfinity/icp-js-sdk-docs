---
title: AuthClientSignInOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:122](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L122)

Options for [AuthClient.signIn](../classes/AuthClient.md#signin).

## Properties

### maxTimeToLive?

> `optional` **maxTimeToLive?**: `bigint`

Defined in: [auth-client.ts:127](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L127)

Maximum lifetime of the delegation in nanoseconds.

#### Default

```ts
8 hours
```

***

### targets?

> `optional` **targets?**: `Principal`[]

Defined in: [auth-client.ts:132](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L132)

Restrict the delegation to specific canisters.
