---
title: IdleOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:105](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L105)

## Extends

- [`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md)

## Properties

### captureScroll?

> `optional` **captureScroll?**: `boolean`

Defined in: [idle-manager.ts:17](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/idle-manager.ts#L17)

capture scroll events

#### Default

```ts
false
```

#### Inherited from

`IdleManagerOptions.captureScroll`

***

### disableDefaultIdleCallback?

> `optional` **disableDefaultIdleCallback?**: `boolean`

Defined in: [auth-client.ts:116](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L116)

Disables the default idle callback (sign-out & reload).

#### Default

```ts
false
```

***

### disableIdle?

> `optional` **disableIdle?**: `boolean`

Defined in: [auth-client.ts:110](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L110)

Disables idle functionality entirely.

#### Default

```ts
false
```

***

### idleTimeout?

> `optional` **idleTimeout?**: `number`

Defined in: [idle-manager.ts:12](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/idle-manager.ts#L12)

timeout in ms

#### Default

```ts
30 minutes [600_000]
```

#### Inherited from

`IdleManagerOptions.idleTimeout`

***

### onIdle?

> `optional` **onIdle?**: `IdleCB`

Defined in: [idle-manager.ts:7](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/idle-manager.ts#L7)

Callback after the user has gone idle

#### Inherited from

`IdleManagerOptions.onIdle`

***

### scrollDebounce?

> `optional` **scrollDebounce?**: `number`

Defined in: [idle-manager.ts:22](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/idle-manager.ts#L22)

scroll debounce time in ms

#### Default

```ts
100
```

#### Inherited from

`IdleManagerOptions.scrollDebounce`
