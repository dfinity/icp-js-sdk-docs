---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:40](https://github.com/dfinity/icp-js-auth/blob/d05eb86f9e160c9d3057d4e638b5c9869cdedd9b/src/client/auth-client.ts#L40)
