---
title: Changelog
editUrl: false
next: true
prev: true
---

## 9.0.0 (2026-09-15)

### Feat

- say a session ended, and name the identity provider as a pair (#191)
- one-click SSO sign-in for organization domains (#141)
- a shared store with no durable medium (#180)
- acquire a session without a ceremony (#145)
- share a sign-in across sibling subdomains (#173)
- the idle timeout belongs to the canister (#181)
- mint when a tab comes back, before the first click does (#171)
- sign in to a session, and end it at the canister (#159)
- mint app delegations from the Internet Identity canister (#156)
- an identity that replaces its own delegation as it ages (#155)
- hold a key and its delegation as one credential (#169)
- keep the state of a sign-in in a store of its own (#170)

### Fix

- recover from force-closed IndexedDB connections (#137)

## 8.0.3 (2026-08-03)

### Fix

- bump @icp-sdk/signer to 5.6.2 (#138)

## 8.0.2 (2026-07-31)

### Fix

- await session teardown before the idle-logout reload (#127)
- validate signOut returnTo (block open redirect and javascript: URLs) (#128)
- expire and sweep abandoned pending redirect session keys (#129)

## 8.0.1 (2026-07-27)

### Fix

- **auth-client**: keep the redirect flow batched and its derivation origin stable (#124)

## 8.0.0 (2026-07-23)

### BREAKING CHANGE

- `AuthClient.requestAttributes` now takes `nonce` as a
callback `() => Promise<Uint8Array>` instead of a `Uint8Array |
Promise<Uint8Array>` value. Pass the function that fetches the nonce
(don't await it at the call site): `nonce: () => fetchNonce()`.

### Feat

- **auth-client**: URL redirect transport (#121)

## 7.1.0 (2026-05-22)

### Feat

- **auth-client**: support Promise<Uint8Array> nonce in requestAttributes (#116)

## 7.0.0 (2026-05-04)

### BREAKING CHANGE

- `AuthClient.logout()` is renamed to
`AuthClient.signOut()`. Callers must rename `authClient.logout(...)` to
`authClient.signOut(...)`.

### Refactor

- rename AuthClient.logout to signOut (#112)

## 6.2.2 (2026-04-26)

### Fix

- release `@icp-sdk/signer` v5.3.1 bump (#109)

## 6.2.1 (2026-04-25)

### Fix

- include id in requestAttributes JSON-RPC request (#104)

## 6.2.0 (2026-04-22)

### Feat

- Make @icp-sdk/signer a direct dep and bump its minor version. (#101)

## 6.1.0 (2026-04-17)

### Feat

- add requestAttributes for signed user attributes (#85)

### BREAKING CHANGE

- `login()` is now renamed to `signIn()`

## 6.0.0 (2026-04-16)

### BREAKING CHANGE

- - `AuthClient.create()` removed — use `new AuthClient()` instead
- `getIdentity()` is now async (returns `Promise<Identity>`)
- `isAuthenticated()` is now sync (returns `boolean` instead of
`Promise<boolean>`)
- - `identityProvider`, `derivationOrigin`, and `windowOpenerFeatures`
moved from `AuthClientLoginOptions` to `AuthClientCreateOptions`
- `loginOptions` field removed from `AuthClientCreateOptions`
- - `allowPinAuthentication` and `customValues` login options removed (not
supported by the signer protocol)
- `InternetIdentityAuthResponseSuccess` type removed
- `ERROR_USER_INTERRUPT` removed

### Feat

- one-click OpenID sign-in (#83)
- update README and quick-start for new API (#82)
- fresh session keys, improved error handling, singleton IdleManager (#80)

### Refactor

- reorganize auth-client code structure (#84)
- sync constructor, sync isAuthenticated, async getIdentity (#81)
- replace custom postMessage protocol with @icp-sdk/signer (#75)

## 5.0.0 (2025-12-18)

- build: bump `@icp-sdk/core` to 5.0.0 (#65)

## 5.0.0-beta.2 (2025-12-17)

- build: bump `@icp-sdk/core` to 5.0.0-beta.2 (#62)

## 5.0.0-beta.1 (2025-12-11)

- build: bump `@icp-sdk/core` to 5.0.0-beta.1 (#55)

## 5.0.0-beta.0 (2025-11-26)

- build: bump `@icp-sdk/core` to 5.0.0-beta.0 (#55)

## 4.2.0 (2025-11-04)

### Feat

- revert support requesting delegations with ICRC-29 (#50)

## 4.1.1 (2025-10-21)

### Fix

- throw error if IndexedDB fails to open (#45)

## 4.1.0

### Feat

- support requesting delegations using ICRC-29 (#39)

## 4.0.2 (2025-10-01)

### Fix

- **client**: overwrite stored key on login to prevent key/delegation mismatch (#34)

## 4.0.1 (2025-09-26)

### Fix

- Downgrade idb to fix the "localStorage is not defined" error when the library is used in a web worker context. (#28)

## 4.0.0 (2025-09-26)

Publishes the new `@icp-sdk/auth` package.

See the [upgrading guide](https://js.icp.build/auth/v4.0/upgrading/v4) for more information.

## 4.0.0-beta.2 (2025-09-23)

## 4.0.0-beta.1 (2025-09-23)

## 3.2.6

This package was previously published as `@dfinity/auth-client` and its source code was hosted at [dfinity/icp-js-core](https://github.com/dfinity/icp-js-core). The [CHANGELOG](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/CHANGELOG.md) of that repository contains the history of the changes up until v3.
