---
title: LocalCredentialStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/local-credential-storage.ts:19](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L19)

Credentials in `localStorage`, for where IndexedDB is unavailable.

`localStorage` holds strings, so the key has to be one: this generates an
Ed25519 identity, whose private bytes serialise, rather than the
non-extractable key [IdbCredentialStorage](IdbCredentialStorage.md) uses. That is the trade the
medium imposes, and it is why generation belongs to the store.

## See

implements [CredentialStorage](../interfaces/CredentialStorage.md)

## Implements

- [`CredentialStorage`](../interfaces/CredentialStorage.md)\<`Ed25519KeyIdentity`\>

## Constructors

### Constructor

> **new LocalCredentialStorage**(`prefix?`): `LocalCredentialStorage`

Defined in: [src/client/local-credential-storage.ts:27](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L27)

#### Parameters

##### prefix?

`string` = `'ic-'`

Prepended to every slot, so two clients under one origin can
  be kept apart.

#### Returns

`LocalCredentialStorage`

## Properties

### durable

> `readonly` **durable**: `true` = `true`

Defined in: [src/client/local-credential-storage.ts:21](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L21)

Whether what this writes survives the document being torn down.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`durable`](../interfaces/CredentialStorage.md#durable)

***

### prefix

> `readonly` **prefix**: `string` = `'ic-'`

Defined in: [src/client/local-credential-storage.ts:27](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L27)

Prepended to every slot, so two clients under one origin can
  be kept apart.

***

### shared

> `readonly` **shared**: `true` = `true`

Defined in: [src/client/local-credential-storage.ts:20](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L20)

Whether another tab of this origin reads what this writes.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`shared`](../interfaces/CredentialStorage.md#shared)

## Methods

### create()

> **create**(): `Promise`\<`Ed25519KeyIdentity`\>

Defined in: [src/client/local-credential-storage.ts:29](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L29)

A fresh identity of this store's own type, not persisted.

Generation belongs to the store because the medium decides the key type: one
that has to serialise needs a key whose private bytes are readable, and one
that does not should not have them. Kept together so an application cannot
pair a non-extractable key with a store that cannot hold one and find out at
runtime.

#### Returns

`Promise`\<`Ed25519KeyIdentity`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`create`](../interfaces/CredentialStorage.md#create)

***

### get()

> **get**(`slot`): `Promise`\<[`Credential`](../interfaces/Credential.md)\<`Ed25519KeyIdentity`\> \| `null`\>

Defined in: [src/client/local-credential-storage.ts:33](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L33)

The credential stored under `slot`, or `null` where there is none.

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<[`Credential`](../interfaces/Credential.md)\<`Ed25519KeyIdentity`\> \| `null`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`get`](../interfaces/CredentialStorage.md#get)

***

### remove()

> **remove**(`slot`): `Promise`\<`void`\>

Defined in: [src/client/local-credential-storage.ts:56](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L56)

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`remove`](../interfaces/CredentialStorage.md#remove)

***

### set()

> **set**(`slot`, `credential`): `Promise`\<`void`\>

Defined in: [src/client/local-credential-storage.ts:47](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/local-credential-storage.ts#L47)

#### Parameters

##### slot

`string`

##### credential

[`Credential`](../interfaces/Credential.md)\<`Ed25519KeyIdentity`\>

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`set`](../interfaces/CredentialStorage.md#set)
