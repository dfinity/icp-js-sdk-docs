---
title: InteractionRequiredError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/session-delegation.ts:33](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-delegation.ts#L33)

Internet Identity had nothing to answer a silent request from.

The one denial that is not a failure: it says a ceremony is needed, so the
caller signs in interactively rather than retrying. It is also the only
dependable evidence that a shared record is stale rather than replaced, which
is what lets an origin retract a record it did not write.

Thrown only for a request that asked not to render anything. An interactive
sign-in that the user abandons is a different outcome and is not this.

## Extends

- `Error`

## Constructors

### Constructor

> **new InteractionRequiredError**(`message`, `reason?`): `InteractionRequiredError`

Defined in: [src/client/session-delegation.ts:45](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-delegation.ts#L45)

#### Parameters

##### message

`string`

##### reason?

`string`

#### Returns

`InteractionRequiredError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:26

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.name`

***

### reason

> `readonly` **reason**: `string` \| `undefined`

Defined in: [src/client/session-delegation.ts:43](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-delegation.ts#L43)

Why, where Internet Identity said: `login_required` where it holds no
session, `account_selection_required` where it holds more than one and the
request named none.

A caller may word its prompt from this and does not have to branch on it, so
it is deliberately a string rather than a union — a value this library does
not know is not a reason to fail.

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

#### Inherited from

`Error.stack`
