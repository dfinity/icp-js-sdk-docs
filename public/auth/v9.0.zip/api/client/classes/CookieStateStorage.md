---
title: CookieStateStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/cookie-state-storage.ts:52](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L52)

The state of a sign-in, in a cookie, so every sibling of a domain shares it.

A cookie is the only thing that crosses between origins, which is what lets one
sign-out end them all: the record is the domain's rather than this origin's, so
removing it is what tells a sibling the sign-in is over. It carries no chain
and no key, so a sibling acting on it asks the identity provider to re-issue
rather than treating it as proof.

## See

implements [StateStorage](../interfaces/StateStorage.md)

## Implements

- [`StateStorage`](../interfaces/StateStorage.md)

## Constructors

### Constructor

> **new CookieStateStorage**(`options`): `CookieStateStorage`

Defined in: [src/client/cookie-state-storage.ts:73](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L73)

#### Parameters

##### options

[`CookieStateStorageOptions`](../interfaces/CookieStateStorageOptions.md)

#### Returns

`CookieStateStorage`

## Properties

### resumable

> `readonly` **resumable**: `true` = `true`

Defined in: [src/client/cookie-state-storage.ts:62](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L62)

A sign-in kept here may be resumed without a ceremony.

This is the store whose record reaches past one origin, so it is the store
whose siblings arrive holding no credential and needing the identity
provider to remember the session they can be given one from. Asking a
provider to keep a sign-in is only worth the persistence where somebody is
going to come back to it, and here somebody will.

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`resumable`](../interfaces/StateStorage.md#resumable)

## Methods

### discard()

> **discard**(`key`): `void`

Defined in: [src/client/cookie-state-storage.ts:186](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L186)

Drops this origin's claim on the sign-in, leaving the cookie for the siblings.

An origin whose chain turns out to be dead cannot tell a revoked session from
one a sibling replaced by signing in, and in the second case that sibling
wrote this cookie a moment ago. So the record stands and this origin reads it
as not held, which is what sends it to acquire one of its own.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`discard`](../interfaces/StateStorage.md#discard)

***

### get()

> **get**(`key`): [`SessionState`](../interfaces/SessionState.md) \| `null`

Defined in: [src/client/cookie-state-storage.ts:135](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L135)

The state, or `null` where nothing is signed in within this store's reach.

#### Parameters

##### key

`string`

#### Returns

[`SessionState`](../interfaces/SessionState.md) \| `null`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`get`](../interfaces/StateStorage.md#get)

***

### remove()

> **remove**(`key`): `void`

Defined in: [src/client/cookie-state-storage.ts:171](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L171)

Removes the state, and anything this store publishes beyond this origin.

What signing out does: the user ended the sign-in, so a sibling reading a
shared record must stop seeing one.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`remove`](../interfaces/StateStorage.md#remove)

***

### set()

> **set**(`key`, `state`): `void`

Defined in: [src/client/cookie-state-storage.ts:162](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L162)

#### Parameters

##### key

`string`

##### state

`Omit`\<[`SessionState`](../interfaces/SessionState.md), `"held"`\>

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`set`](../interfaces/StateStorage.md#set)

***

### subscribe()

> **subscribe**(`key`, `listener`): () => `void`

Defined in: [src/client/cookie-state-storage.ts:200](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L200)

Fires when the state changes, including when a sibling subdomain changes it.

`document.cookie` raises no event and no `BroadcastChannel` crosses origins,
so a sibling's sign-out is visible only by looking: the Cookie Store API
where the browser has it, and otherwise a re-check whenever this page is
shown or its window regains focus, which is when the user is about to act on
the answer.

#### Parameters

##### key

`string`

##### listener

() => `void`

#### Returns

() => `void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`subscribe`](../interfaces/StateStorage.md#subscribe)
