---
title: IdbKeyVal
editUrl: false
next: true
prev: true
---

Defined in: [src/client/db.ts:59](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/db.ts#L59)

Simple Key Value store
Defaults to `'auth-client-db'` with an object store of `'ic-keyval'`

## Methods

### get()

> **get**\<`T`\>(`key`): `Promise`\<`T` \| `null`\>

Defined in: [src/client/db.ts:146](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/db.ts#L146)

Basic getter
Pass in a type T for type safety if you know the type the value will have if it is found

#### Type Parameters

##### T

`T`

#### Parameters

##### key

`IDBValidKey`

string | number | Date | BufferSource | IDBValidKey[]

#### Returns

`Promise`\<`T` \| `null`\>

`Promise<T | null>`

#### Example

```ts
await get<string>('exampleKey') -> 'exampleValue'
```

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [src/client/db.ts:155](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/db.ts#L155)

Remove a key

#### Parameters

##### key

`IDBValidKey`

IDBValidKey

#### Returns

`Promise`\<`void`\>

void

***

### set()

> **set**\<`T`\>(`key`, `value`): `Promise`\<`IDBValidKey`\>

Defined in: [src/client/db.ts:135](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/db.ts#L135)

Basic setter

#### Type Parameters

##### T

`T`

#### Parameters

##### key

`IDBValidKey`

string | number | Date | BufferSource | IDBValidKey[]

##### value

`T`

value to set

#### Returns

`Promise`\<`IDBValidKey`\>

void

***

### create()

> `static` **create**(`options?`): `Promise`\<`IdbKeyVal`\>

Defined in: [src/client/db.ts:68](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/db.ts#L68)

#### Parameters

##### options?

[`DBCreateOptions`](../type-aliases/DBCreateOptions.md)

DBCreateOptions

#### Returns

`Promise`\<`IdbKeyVal`\>

#### Default

```ts

```

#### Default

```ts

```
