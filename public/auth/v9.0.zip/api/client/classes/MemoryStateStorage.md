---
title: MemoryStateStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state-storage.ts:102](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/state-storage.ts#L102)

State held for the lifetime of the instance and shared with nothing.

For tests and for environments with no `localStorage`, where a client is
alone and a reload starts from nothing.

## See

implements [StateStorage](../interfaces/StateStorage.md)

## Implements

- [`StateStorage`](../interfaces/StateStorage.md)

## Constructors

### Constructor

> **new MemoryStateStorage**(): `MemoryStateStorage`

#### Returns

`MemoryStateStorage`

## Methods

### discard()

> **discard**(`key`): `void`

Defined in: [src/client/state-storage.ts:123](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/state-storage.ts#L123)

The same as [remove](#remove): this store publishes nothing at all.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`discard`](../interfaces/StateStorage.md#discard)

***

### get()

> **get**(`key`): [`SessionState`](../interfaces/SessionState.md) \| `null`

Defined in: [src/client/state-storage.ts:106](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/state-storage.ts#L106)

The state, or `null` where nothing is signed in within this store's reach.

#### Parameters

##### key

`string`

#### Returns

[`SessionState`](../interfaces/SessionState.md) \| `null`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`get`](../interfaces/StateStorage.md#get)

***

### remove()

> **remove**(`key`): `void`

Defined in: [src/client/state-storage.ts:117](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/state-storage.ts#L117)

Removes the state, and anything this store publishes beyond this origin.

What signing out does: the user ended the sign-in, so a sibling reading a
shared record must stop seeing one.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`remove`](../interfaces/StateStorage.md#remove)

***

### set()

> **set**(`key`, `state`): `void`

Defined in: [src/client/state-storage.ts:112](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/state-storage.ts#L112)

#### Parameters

##### key

`string`

##### state

`Omit`\<[`SessionState`](../interfaces/SessionState.md), `"held"`\>

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`set`](../interfaces/StateStorage.md#set)

***

### subscribe()

> **subscribe**(`key`, `listener`): () => `void`

Defined in: [src/client/state-storage.ts:137](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/state-storage.ts#L137)

Fires when the state changes, which here means when something writes to
this instance.

Nothing outside the process can reach a `Map`, so a medium is not what makes
this worth having: two clients can be handed the same instance, and this is
how the one that did not write finds out. Each listener is told only when the
record actually changed since it was last told, so a client's own writes do
not come back to it as news.

#### Parameters

##### key

`string`

##### listener

() => `void`

#### Returns

() => `void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`subscribe`](../interfaces/StateStorage.md#subscribe)
