---
title: DB_VERSION
editUrl: false
next: true
prev: true
---

> `const` **DB\_VERSION**: `1` = `1`

Defined in: [src/client/db.ts:4](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/db.ts#L4)
