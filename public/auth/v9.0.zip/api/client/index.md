---
title: Overview
editUrl: false
next: true
prev: true
---

## Classes

- [AuthClient](classes/AuthClient.md)
- [CookieStateStorage](classes/CookieStateStorage.md)
- [IdbCredentialStorage](classes/IdbCredentialStorage.md)
- [IdbKeyVal](classes/IdbKeyVal.md)
- [InteractionRequiredError](classes/InteractionRequiredError.md)
- [LocalCredentialStorage](classes/LocalCredentialStorage.md)
- [LocalStateStorage](classes/LocalStateStorage.md)
- [MemoryCredentialStorage](classes/MemoryCredentialStorage.md)
- [MemoryStateStorage](classes/MemoryStateStorage.md)
- [SessionGoneError](classes/SessionGoneError.md)
- [SessionIdentity](classes/SessionIdentity.md)
- [SessionMinter](classes/SessionMinter.md)
- [SessionNotHeldError](classes/SessionNotHeldError.md)
- [SharedMemoryCredentialStorage](classes/SharedMemoryCredentialStorage.md)
- [SupersededError](classes/SupersededError.md)

## Interfaces

- [AppDelegationSource](interfaces/AppDelegationSource.md)
- [AuthClientBaseOptions](interfaces/AuthClientBaseOptions.md)
- [AuthClientSignInOptions](interfaces/AuthClientSignInOptions.md)
- [CookieStateStorageOptions](interfaces/CookieStateStorageOptions.md)
- [Credential](interfaces/Credential.md)
- [CredentialStorage](interfaces/CredentialStorage.md)
- [SessionIdentityOptions](interfaces/SessionIdentityOptions.md)
- [SessionMinterOptions](interfaces/SessionMinterOptions.md)
- [SessionState](interfaces/SessionState.md)
- [SignedAttributes](interfaces/SignedAttributes.md)
- [StateStorage](interfaces/StateStorage.md)

## Type Aliases

- [AuthClientCreateOptions](type-aliases/AuthClientCreateOptions.md)
- [DBCreateOptions](type-aliases/DBCreateOptions.md)
- [OpenIdProvider](type-aliases/OpenIdProvider.md)
- [SessionStatus](type-aliases/SessionStatus.md)

## Variables

- [DB\_VERSION](variables/DB_VERSION.md)
- [DEFAULT\_SHARED\_MEMORY\_NAME](variables/DEFAULT_SHARED_MEMORY_NAME.md)
- [OPENID\_PROVIDER\_URLS](variables/OPENID_PROVIDER_URLS.md)

## Functions

- [isValidSsoDomain](functions/isValidSsoDomain.md)
- [requestSessionDelegation](functions/requestSessionDelegation.md)
- [scopedKeys](functions/scopedKeys.md)
- [watchActivity](functions/watchActivity.md)
- [watchForeground](functions/watchForeground.md)
