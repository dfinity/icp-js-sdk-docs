---
title: requestSessionDelegation
editUrl: false
next: true
prev: true
---

> **requestSessionDelegation**(`signer`, `params`): `Promise`\<`DelegationChain`\>

Defined in: [src/client/session-delegation.ts:78](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-delegation.ts#L78)

Asks the identity provider for a session, and returns the chain it signed.

The chain is restricted to the Internet Identity canister, so it is not
something an application can call its own canisters with. It is what app
delegations are minted from.

## Parameters

### signer

`Signer`

### params

#### derivationOrigin?

`string`

#### maxTimeToIdle?

`bigint`

#### maxTimeToLive?

`bigint`

#### sessionPublicKey

`DerEncodedPublicKey`

## Returns

`Promise`\<`DelegationChain`\>
