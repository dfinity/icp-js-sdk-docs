---
title: watchForeground
editUrl: false
next: true
prev: true
---

> **watchForeground**(`onForeground`): (() => `void`) \| `undefined`

Defined in: [src/client/foreground-refresh.ts:17](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/foreground-refresh.ts#L17)

Calls back when the page is shown or the window regains focus.

Its own module because it is the one part of the session machinery that needs a
DOM. `AuthClient` runs outside a browser too, so nothing else may assume these
APIs exist: where they do not, this and [watchActivity](watchActivity.md) return
`undefined` and hook nothing.

A backgrounded tab has its timers throttled, so a session's scheduled refresh
may not run and its delegation lapses while nobody is looking. Coming back to
the tab happens a second or two before the user's next click, which is room
enough to mint in. Whether a mint is actually due is not decided here.

## Parameters

### onForeground

() => `void`

Invoked when the page becomes visible or regains focus.

## Returns

(() => `void`) \| `undefined`

A function that unhooks the listeners, or `undefined` where there is
  no DOM to hook.
