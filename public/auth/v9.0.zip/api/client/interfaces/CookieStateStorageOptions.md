---
title: CookieStateStorageOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/client/cookie-state-storage.ts:29](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L29)

## Properties

### domain

> **domain**: `string`

Defined in: [src/client/cookie-state-storage.ts:39](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/cookie-state-storage.ts#L39)

Domain to scope the cookie to, e.g. `example.com` so `a.example.com` and
`b.example.com` share one sign-in.

Must be the current host or a domain above it: the browser rejects a cookie
scoped to anything else, including a sibling subdomain, and refuses a public
suffix — so an over-broad value fails rather than leaking to unrelated sites.
Nothing needs to be served at the domain; it is only a scope.
