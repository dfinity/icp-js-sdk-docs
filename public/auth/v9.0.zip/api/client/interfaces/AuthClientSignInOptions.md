---
title: AuthClientSignInOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:248](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/auth-client.ts#L248)

Options for [AuthClient.signIn](../classes/AuthClient.md#signin).

## Properties

### maxTimeToIdle?

> `optional` **maxTimeToIdle?**: `bigint`

Defined in: [src/client/auth-client.ts:259](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/auth-client.ts#L259)

How long a signed-in user may be idle before the sign-in ends, in nanoseconds.

#### Default

```ts
the identity provider's, currently 7 days
```

***

### maxTimeToLive?

> `optional` **maxTimeToLive?**: `bigint`

Defined in: [src/client/auth-client.ts:253](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/auth-client.ts#L253)

The longest the session may last, in nanoseconds.

#### Default

```ts
the identity provider's, currently 30 days
```

***

### returnTo?

> `optional` **returnTo?**: `string`

Defined in: [src/client/auth-client.ts:271](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/auth-client.ts#L271)

Where to go once the sign-in completes, ignored unless it is a same-origin
`http(s)` target.

For the flow that leaves the page: a redirect sign-in comes back to whatever
URL the ceremony was started from, which is rarely where the user was. It is
journaled, so it survives the round trip, and the navigation replaces the
current history entry rather than adding one — the sign-in page and the
redirect chain are not somewhere a back button should return to.
