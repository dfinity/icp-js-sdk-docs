---
title: SessionIdentityOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/client/session-identity.ts:190](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-identity.ts#L190)

## Properties

### accountKey

> **accountKey**: `DerEncodedPublicKey`

Defined in: [src/client/session-identity.ts:192](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-identity.ts#L192)

The account's key, which every app delegation is rooted at.

***

### onSessionGone

> **onSessionGone**: () => `void`

Defined in: [src/client/session-identity.ts:224](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-identity.ts#L224)

Called once when the session turns out to be gone, so the client can drop
what it holds and tell its subscribers. Ending a session is the client's to
do; this only reports it.

#### Returns

`void`

***

### sessionExpiresAtMs

> **sessionExpiresAtMs**: `number`

Defined in: [src/client/session-identity.ts:195](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-identity.ts#L195)

When the session itself ends. Nothing is minted past this.

***

### slot

> **slot**: `string`

Defined in: [src/client/session-identity.ts:217](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-identity.ts#L217)

The slot the app credential lives under, and the name of the lock that
serialises minting into it.

Taken rather than assumed, because the client assigns every name from one
namespace: reaching for the bare constant here would read and write a slot
the client never promotes into, so a namespaced client would mint again on
every load and its sign-out would clear a slot nothing was using.

***

### source

> **source**: [`AppDelegationSource`](AppDelegationSource.md)

Defined in: [src/client/session-identity.ts:197](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-identity.ts#L197)

***

### storage

> **storage**: [`CredentialStorage`](CredentialStorage.md)

Defined in: [src/client/session-identity.ts:206](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-identity.ts#L206)

Where the app credential is kept, and what makes the key a mint gets a
delegation for.

The store is what every tab of the origin reads, so a delegation minted in
one is the delegation the others use.
