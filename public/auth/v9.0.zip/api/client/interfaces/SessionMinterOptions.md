---
title: SessionMinterOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/client/session-minter.ts:115](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-minter.ts#L115)

## Properties

### agentOptions?

> `optional` **agentOptions?**: `Omit`\<`HttpAgentOptions`, `"identity"`\>

Defined in: [src/client/session-minter.ts:129](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-minter.ts#L129)

Options for the agent making them. `identity` is not among them: the agent
signs as the session, which is what a mint call rests on.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [src/client/session-minter.ts:123](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-minter.ts#L123)

The canister these calls go to.

***

### sessionChain

> **sessionChain**: `DelegationChain`

Defined in: [src/client/session-minter.ts:120](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-minter.ts#L120)

The chain proving those calls come from the session. Restricted to II.

***

### sessionKey

> **sessionKey**: `SignIdentity`

Defined in: [src/client/session-minter.ts:117](https://github.com/dfinity/icp-js-auth/blob/bd5e5ef6ece907adc7d0772027b131ed945800ff/src/client/session-minter.ts#L117)

The key the session chain delegates to. Signs the calls made here.
