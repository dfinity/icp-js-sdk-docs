---
title: IdleOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:82](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L82)

## Extends

- [`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md)

## Properties

### captureScroll?

> `optional` **captureScroll**: `boolean`

Defined in: [idle-manager.ts:17](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/idle-manager.ts#L17)

capture scroll events

#### Default

```ts
false
```

#### Inherited from

`IdleManagerOptions.captureScroll`

***

### disableDefaultIdleCallback?

> `optional` **disableDefaultIdleCallback**: `boolean`

Defined in: [auth-client.ts:93](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L93)

Disables default idle behavior - call logout & reload window

#### Default

```ts
false
```

***

### disableIdle?

> `optional` **disableIdle**: `boolean`

Defined in: [auth-client.ts:87](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L87)

Disables idle functionality for [IdleManager](../classes/IdleManager.md)

#### Default

```ts
false
```

***

### idleTimeout?

> `optional` **idleTimeout**: `number`

Defined in: [idle-manager.ts:12](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/idle-manager.ts#L12)

timeout in ms

#### Default

```ts
30 minutes [600_000]
```

#### Inherited from

`IdleManagerOptions.idleTimeout`

***

### onIdle?

> `optional` **onIdle**: `IdleCB`

Defined in: [idle-manager.ts:7](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/idle-manager.ts#L7)

Callback after the user has gone idle

#### Inherited from

`IdleManagerOptions.onIdle`

***

### scrollDebounce?

> `optional` **scrollDebounce**: `number`

Defined in: [idle-manager.ts:22](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/idle-manager.ts#L22)

scroll debounce time in ms

#### Default

```ts
100
```

#### Inherited from

`IdleManagerOptions.scrollDebounce`
