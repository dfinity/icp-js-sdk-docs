---
title: KEY_STORAGE_DELEGATION
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_DELEGATION**: `"delegation"` = `'delegation'`

Defined in: [storage.ts:4](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/storage.ts#L4)
