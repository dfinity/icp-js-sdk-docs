---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:53](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L53)

Options for creating an [AuthClient](../classes/AuthClient.md).

## Properties

### derivationOrigin?

> `optional` **derivationOrigin?**: `string` \| `URL`

Defined in: [auth-client.ts:89](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L89)

Derivation origin for the identity provider.

#### See

https://github.com/dfinity/internet-identity/blob/main/docs/internet-identity-spec.adoc

***

### identity?

> `optional` **identity?**: `SignIdentity` \| `PartialIdentity`

Defined in: [auth-client.ts:57](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L57)

An identity to authenticate via delegation.

***

### identityProvider?

> `optional` **identityProvider?**: `string` \| `URL`

Defined in: [auth-client.ts:83](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L83)

Identity provider URL.

#### Default

```ts
"https://id.ai/authorize"
```

***

### idleOptions?

> `optional` **idleOptions?**: [`IdleOptions`](IdleOptions.md)

Defined in: [auth-client.ts:77](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L77)

Idle timeout configuration.

#### Default

```ts
after 10 minutes, invalidates the identity
```

***

### keyType?

> `optional` **keyType?**: `BaseKeyType`

Defined in: [auth-client.ts:71](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L71)

Type of session key to generate on each sign-in.

Use `'Ed25519'` when your storage provider does not support `CryptoKey`.

#### Default

```ts
'ECDSA'
```

***

### openIdProvider?

> `optional` **openIdProvider?**: [`OpenIdProvider`](../type-aliases/OpenIdProvider.md)

Defined in: [auth-client.ts:102](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L102)

OpenID provider for one-click sign-in. When set, the identity provider
URL includes an `openid` search param so the user authenticates via
the chosen provider (e.g. Google) instead of seeing Internet Identity directly.

***

### storage?

> `optional` **storage?**: [`AuthClientStorage`](AuthClientStorage.md)

Defined in: [auth-client.ts:63](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L63)

Persistent storage backend. Defaults to IndexedDB.

#### Default

```ts
IdbStorage
```

***

### windowOpenerFeatures?

> `optional` **windowOpenerFeatures?**: `string`

Defined in: [auth-client.ts:95](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L95)

Window features string for the authentication popup.

#### Example

```ts
"toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100"
```
