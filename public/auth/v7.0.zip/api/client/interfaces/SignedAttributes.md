---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:135](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L135)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [auth-client.ts:136](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L136)

***

### signature

> **signature**: `Uint8Array`

Defined in: [auth-client.ts:137](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L137)
