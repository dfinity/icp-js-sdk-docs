---
title: AuthClient
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:150](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L150)

Manages authentication and identity for Internet Computer web apps.

## Example

```ts
const authClient = new AuthClient();

const identity = authClient.isAuthenticated()
  ? await authClient.getIdentity()
  : await authClient.signIn();
```

## Constructors

### Constructor

> **new AuthClient**(`options?`): `AuthClient`

Defined in: [auth-client.ts:159](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L159)

#### Parameters

##### options?

[`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md) = `{}`

#### Returns

`AuthClient`

## Properties

### idleManager

> **idleManager**: [`IdleManager`](IdleManager.md) \| `undefined`

Defined in: [auth-client.ts:157](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L157)

## Methods

### getIdentity()

> **getIdentity**(): `Promise`\<`Identity`\>

Defined in: [auth-client.ts:190](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L190)

Returns the current identity, restoring a previous session if available.

#### Returns

`Promise`\<`Identity`\>

***

### isAuthenticated()

> **isAuthenticated**(): `boolean`

Defined in: [auth-client.ts:198](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L198)

Checks whether the user has an active, non-expired session.

#### Returns

`boolean`

***

### requestAttributes()

> **requestAttributes**(`params`): `Promise`\<[`SignedAttributes`](../interfaces/SignedAttributes.md)\>

Defined in: [auth-client.ts:268](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L268)

Requests signed identity attributes from the identity provider.

#### Parameters

##### params

Request parameters.

###### keys

`string`[]

Attribute keys to request (e.g. `['email', 'name']`).

###### nonce

`Uint8Array`

32-byte nonce issued by the RP canister.

#### Returns

`Promise`\<[`SignedAttributes`](../interfaces/SignedAttributes.md)\>

Signed attribute data and signature.

#### Throws

When the identity provider returns an error or an invalid response.

***

### signIn()

> **signIn**(`options?`): `Promise`\<`Identity`\>

Defined in: [auth-client.ts:222](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L222)

Opens the identity provider, requests a delegation, and returns the authenticated identity.

#### Parameters

##### options?

[`AuthClientSignInOptions`](../interfaces/AuthClientSignInOptions.md)

Sign-in options.

#### Returns

`Promise`\<`Identity`\>

The authenticated identity.

#### Throws

When authentication fails.

#### Example

```ts
try {
  const identity = await authClient.signIn();
} catch (error) {
  console.error('Sign-in failed:', error);
}
```

***

### signOut()

> **signOut**(`options?`): `Promise`\<`void`\>

Defined in: [auth-client.ts:306](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/auth-client.ts#L306)

Clears the stored session and resets the client to an anonymous state.

#### Parameters

##### options?

Sign-out options.

###### returnTo?

`string`

URL to navigate to after sign-out.

#### Returns

`Promise`\<`void`\>
