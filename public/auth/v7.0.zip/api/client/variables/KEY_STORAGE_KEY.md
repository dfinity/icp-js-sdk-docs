---
title: KEY_STORAGE_KEY
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_KEY**: `"identity"` = `'identity'`

Defined in: [storage.ts:3](https://github.com/dfinity/icp-js-auth/blob/23f00b40a3910bad224e6fe4f487cca8dcadb8e9/src/client/storage.ts#L3)
