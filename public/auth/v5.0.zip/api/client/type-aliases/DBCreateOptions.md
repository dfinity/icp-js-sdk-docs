---
title: DBCreateOptions
editUrl: false
next: true
prev: true
---

> **DBCreateOptions** = `object`

Defined in: [db.ts:50](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L50)

## Properties

### dbName?

> `optional` **dbName**: `string`

Defined in: [db.ts:51](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L51)

***

### storeName?

> `optional` **storeName**: `string`

Defined in: [db.ts:52](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L52)

***

### version?

> `optional` **version**: `number`

Defined in: [db.ts:53](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L53)
