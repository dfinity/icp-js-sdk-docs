---
title: IdbKeyVal
editUrl: false
next: true
prev: true
---

Defined in: [db.ts:60](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L60)

Simple Key Value store
Defaults to `'auth-client-db'` with an object store of `'ic-keyval'`

## Methods

### get()

> **get**\<`T`\>(`key`): `Promise`\<`T` \| `null`\>

Defined in: [db.ts:102](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L102)

Basic getter
Pass in a type T for type safety if you know the type the value will have if it is found

#### Type Parameters

##### T

`T`

#### Parameters

##### key

`IDBValidKey`

string | number | Date | BufferSource | IDBValidKey[]

#### Returns

`Promise`\<`T` \| `null`\>

`Promise<T | null>`

#### Example

```ts
await get<string>('exampleKey') -> 'exampleValue'
```

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [db.ts:111](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L111)

Remove a key

#### Parameters

##### key

`IDBValidKey`

IDBValidKey

#### Returns

`Promise`\<`void`\>

void

***

### set()

> **set**\<`T`\>(`key`, `value`): `Promise`\<`IDBValidKey`\>

Defined in: [db.ts:91](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L91)

Basic setter

#### Type Parameters

##### T

`T`

#### Parameters

##### key

`IDBValidKey`

string | number | Date | BufferSource | IDBValidKey[]

##### value

`T`

value to set

#### Returns

`Promise`\<`IDBValidKey`\>

void

***

### create()

> `static` **create**(`options?`): `Promise`\<`IdbKeyVal`\>

Defined in: [db.ts:69](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/db.ts#L69)

#### Parameters

##### options?

[`DBCreateOptions`](../type-aliases/DBCreateOptions.md)

DBCreateOptions

#### Returns

`Promise`\<`IdbKeyVal`\>

#### Default

```ts

```

#### Default

```ts

```
