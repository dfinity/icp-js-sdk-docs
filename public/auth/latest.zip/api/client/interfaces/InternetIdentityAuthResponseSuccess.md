---
title: InternetIdentityAuthResponseSuccess
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:149](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/auth-client.ts#L149)

## Properties

### authnMethod

> **authnMethod**: `"passkey"` \| `"pin"` \| `"recovery"`

Defined in: [auth-client.ts:160](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/auth-client.ts#L160)

***

### delegations

> **delegations**: `object`[]

Defined in: [auth-client.ts:151](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/auth-client.ts#L151)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `bigint`

##### delegation.pubkey

> **pubkey**: `Uint8Array`

##### delegation.targets?

> `optional` **targets**: `Principal`[]

#### signature

> **signature**: `Uint8Array`

***

### kind

> **kind**: `"authorize-client-success"`

Defined in: [auth-client.ts:150](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/auth-client.ts#L150)

***

### userPublicKey

> **userPublicKey**: `Uint8Array`

Defined in: [auth-client.ts:159](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/auth-client.ts#L159)
