---
title: InternetIdentityAuthResponseSuccess
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:148](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L148)

## Properties

### authnMethod

> **authnMethod**: `"passkey"` \| `"pin"` \| `"recovery"`

Defined in: [auth-client.ts:159](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L159)

***

### delegations

> **delegations**: `object`[]

Defined in: [auth-client.ts:150](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L150)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `bigint`

##### delegation.pubkey

> **pubkey**: `Uint8Array`

##### delegation.targets?

> `optional` **targets**: `Principal`[]

#### signature

> **signature**: `Uint8Array`

***

### kind

> **kind**: `"authorize-client-success"`

Defined in: [auth-client.ts:149](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L149)

***

### userPublicKey

> **userPublicKey**: `Uint8Array`

Defined in: [auth-client.ts:158](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L158)
