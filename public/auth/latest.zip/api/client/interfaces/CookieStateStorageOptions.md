---
title: CookieStateStorageOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/client/cookie-state-storage.ts:29](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/cookie-state-storage.ts#L29)

## Properties

### domain

> **domain**: `string`

Defined in: [src/client/cookie-state-storage.ts:39](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/cookie-state-storage.ts#L39)

Domain to scope the cookie to, e.g. `example.com` so `a.example.com` and
`b.example.com` share one sign-in.

Must be the current host or a domain above it: the browser rejects a cookie
scoped to anything else, including a sibling subdomain, and refuses a public
suffix — so an over-broad value fails rather than leaking to unrelated sites.
Nothing needs to be served at the domain; it is only a scope.
