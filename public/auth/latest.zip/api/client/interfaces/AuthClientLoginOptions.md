---
title: AuthClientLoginOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:124](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L124)

Options for [AuthClient.login](../classes/AuthClient.md#login).

## Properties

### maxTimeToLive?

> `optional` **maxTimeToLive?**: `bigint`

Defined in: [auth-client.ts:129](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L129)

Maximum lifetime of the delegation in nanoseconds.

#### Default

```ts
8 hours
```

***

### onError?

> `optional` **onError?**: [`OnErrorFunc`](../type-aliases/OnErrorFunc.md)

Defined in: [auth-client.ts:145](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L145)

Called when login fails. When provided the error is **not** re-thrown,
allowing the caller to handle it via this callback instead.

***

### onSuccess?

> `optional` **onSuccess?**: [`OnSuccessFunc`](../type-aliases/OnSuccessFunc.md)

Defined in: [auth-client.ts:139](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L139)

Called after a successful login.

***

### targets?

> `optional` **targets?**: `Principal`[]

Defined in: [auth-client.ts:134](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L134)

Restrict the delegation to specific canisters.
