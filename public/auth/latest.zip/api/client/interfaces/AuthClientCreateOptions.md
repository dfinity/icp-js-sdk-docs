---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:71](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L71)

Options for creating an [AuthClient](../classes/AuthClient.md).

## Properties

### derivationOrigin?

> `optional` **derivationOrigin?**: `string` \| `URL`

Defined in: [auth-client.ts:107](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L107)

Derivation origin for the identity provider.

#### See

https://github.com/dfinity/internet-identity/blob/main/docs/internet-identity-spec.adoc

***

### identity?

> `optional` **identity?**: `SignIdentity` \| `PartialIdentity`

Defined in: [auth-client.ts:75](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L75)

An identity to authenticate via delegation.

***

### identityProvider?

> `optional` **identityProvider?**: `string` \| `URL`

Defined in: [auth-client.ts:101](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L101)

Identity provider URL.

#### Default

```ts
"https://id.ai/authorize"
```

***

### idleOptions?

> `optional` **idleOptions?**: [`IdleOptions`](IdleOptions.md)

Defined in: [auth-client.ts:95](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L95)

Idle timeout configuration.

#### Default

```ts
after 10 minutes, invalidates the identity
```

***

### keyType?

> `optional` **keyType?**: `BaseKeyType`

Defined in: [auth-client.ts:89](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L89)

Type of session key to generate on each sign-in.

Use `'Ed25519'` when your storage provider does not support `CryptoKey`.

#### Default

```ts
'ECDSA'
```

***

### openIdProvider?

> `optional` **openIdProvider?**: [`OpenIdProvider`](../type-aliases/OpenIdProvider.md)

Defined in: [auth-client.ts:144](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L144)

OpenID provider for one-click sign-in. When set, the identity provider
URL includes an `openid` search param so the user authenticates via
the chosen provider (e.g. Google) instead of seeing Internet Identity directly.

***

### storage?

> `optional` **storage?**: [`AuthClientStorage`](AuthClientStorage.md)

Defined in: [auth-client.ts:81](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L81)

Persistent storage backend. Defaults to IndexedDB.

#### Default

```ts
IdbStorage
```

***

### transport?

> `optional` **transport?**: `"window"` \| `"redirect"`

Defined in: [auth-client.ts:137](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L137)

How the client communicates with the identity provider.

- `'window'` (default) — the identity provider opens in a separate browser
  tab or window (a popup when [windowOpenerFeatures](#windowopenerfeatures) is set) and
  communicates over the ICRC-29 `postMessage` transport.
- `'redirect'` — the current page navigates to the identity provider over
  the ICRC-167 URL transport, which returns to this same page. The callback
  URL is the current page's URL (`location.origin + location.pathname`), so
  that page must be on an origin you control and declared in that origin's
  `/.well-known/ii-auth-callbacks` allow-list. Use it for full-page sign-in
  that shouldn't need a user gesture to open a window (e.g. redirecting on a
  restricted route), or native apps handing off via universal links.

With `'redirect'` the page unloads on each step and the flow re-runs on the
return load, so call `signIn` / `requestAttributes` directly on the page's
load (not deferred behind, say, a click handler): a fresh visit starts the
flow and the identity provider's return replays it to completion. Give each
flow its own route so its persisted state stays isolated.

#### Default

```ts
'window'
```

#### See

https://github.com/dfinity/wg-identity-authentication/blob/main/topics/icrc_167_browser_url_transport.md

***

### windowOpenerFeatures?

> `optional` **windowOpenerFeatures?**: `string`

Defined in: [auth-client.ts:113](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L113)

Window features string for the authentication popup.

#### Example

```ts
"toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100"
```
