---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:49](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L49)

List of options for creating an [AuthClient](../classes/AuthClient.md).

## Properties

### identity?

> `optional` **identity**: `SignIdentity` \| `PartialIdentity`

Defined in: [auth-client.ts:53](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L53)

An SignIdentity or PartialIdentity to authenticate via delegation.

***

### idleOptions?

> `optional` **idleOptions**: [`IdleOptions`](IdleOptions.md)

Defined in: [auth-client.ts:73](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L73)

Options to handle idle timeouts

#### Default

```ts
after 10 minutes, invalidates the identity
```

***

### keyType?

> `optional` **keyType**: `BaseKeyType`

Defined in: [auth-client.ts:67](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L67)

Type to use for the base key.

If you are using a custom storage provider that does not support CryptoKey storage,
you should use `Ed25519` as the key type, as it can serialize to a string.

#### Default

```ts
'ECDSA'
```

***

### loginOptions?

> `optional` **loginOptions**: [`AuthClientLoginOptions`](AuthClientLoginOptions.md)

Defined in: [auth-client.ts:78](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L78)

Options to handle login, passed to the login method

***

### storage?

> `optional` **storage**: [`AuthClientStorage`](AuthClientStorage.md)

Defined in: [auth-client.ts:58](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L58)

Optional storage with get, set, and remove. Uses [IdbStorage](../classes/IdbStorage.md) by default.

#### See

[AuthClientStorage](AuthClientStorage.md)
