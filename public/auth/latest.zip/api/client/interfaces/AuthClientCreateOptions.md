---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:51](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L51)

Options for creating an [AuthClient](../classes/AuthClient.md).

## Properties

### derivationOrigin?

> `optional` **derivationOrigin?**: `string` \| `URL`

Defined in: [auth-client.ts:87](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L87)

Derivation origin for the identity provider.

#### See

https://github.com/dfinity/internet-identity/blob/main/docs/internet-identity-spec.adoc

***

### identity?

> `optional` **identity?**: `SignIdentity` \| `PartialIdentity`

Defined in: [auth-client.ts:55](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L55)

An identity to authenticate via delegation.

***

### identityProvider?

> `optional` **identityProvider?**: `string` \| `URL`

Defined in: [auth-client.ts:81](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L81)

Identity provider URL.

#### Default

```ts
"https://id.ai/authorize"
```

***

### idleOptions?

> `optional` **idleOptions?**: [`IdleOptions`](IdleOptions.md)

Defined in: [auth-client.ts:75](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L75)

Idle timeout configuration.

#### Default

```ts
after 10 minutes, invalidates the identity
```

***

### keyType?

> `optional` **keyType?**: `BaseKeyType`

Defined in: [auth-client.ts:69](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L69)

Type of session key to generate on each login.

Use `'Ed25519'` when your storage provider does not support `CryptoKey`.

#### Default

```ts
'ECDSA'
```

***

### openIdProvider?

> `optional` **openIdProvider?**: [`OpenIdProvider`](../type-aliases/OpenIdProvider.md)

Defined in: [auth-client.ts:100](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L100)

OpenID provider for one-click sign-in. When set, the identity provider
URL includes an `openid` search param so the user authenticates via
the chosen provider (e.g. Google) instead of seeing Internet Identity directly.

***

### storage?

> `optional` **storage?**: [`AuthClientStorage`](AuthClientStorage.md)

Defined in: [auth-client.ts:61](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L61)

Persistent storage backend. Defaults to IndexedDB.

#### Default

```ts
IdbStorage
```

***

### windowOpenerFeatures?

> `optional` **windowOpenerFeatures?**: `string`

Defined in: [auth-client.ts:93](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L93)

Window features string for the authentication popup.

#### Example

```ts
"toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100"
```
