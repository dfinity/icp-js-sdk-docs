---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:50](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L50)

List of options for creating an [AuthClient](../classes/AuthClient.md).

## Properties

### identity?

> `optional` **identity**: `SignIdentity` \| `PartialIdentity`

Defined in: [auth-client.ts:54](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L54)

An SignIdentity or PartialIdentity to authenticate via delegation.

***

### idleOptions?

> `optional` **idleOptions**: [`IdleOptions`](IdleOptions.md)

Defined in: [auth-client.ts:74](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L74)

Options to handle idle timeouts

#### Default

```ts
after 10 minutes, invalidates the identity
```

***

### keyType?

> `optional` **keyType**: `BaseKeyType`

Defined in: [auth-client.ts:68](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L68)

Type to use for the base key.

If you are using a custom storage provider that does not support CryptoKey storage,
you should use `Ed25519` as the key type, as it can serialize to a string.

#### Default

```ts
'ECDSA'
```

***

### loginOptions?

> `optional` **loginOptions**: [`AuthClientLoginOptions`](AuthClientLoginOptions.md)

Defined in: [auth-client.ts:79](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L79)

Options to handle login, passed to the login method

***

### storage?

> `optional` **storage**: [`AuthClientStorage`](AuthClientStorage.md)

Defined in: [auth-client.ts:59](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L59)

Optional storage with get, set, and remove. Uses [IdbStorage](../classes/IdbStorage.md) by default.

#### See

[AuthClientStorage](AuthClientStorage.md)
