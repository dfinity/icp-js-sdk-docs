---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:274](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/auth-client.ts#L274)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [src/client/auth-client.ts:275](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/auth-client.ts#L275)

***

### signature

> **signature**: `Uint8Array`

Defined in: [src/client/auth-client.ts:276](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/auth-client.ts#L276)
