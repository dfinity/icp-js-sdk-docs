---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:177](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L177)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [auth-client.ts:178](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L178)

***

### signature

> **signature**: `Uint8Array`

Defined in: [auth-client.ts:179](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L179)
