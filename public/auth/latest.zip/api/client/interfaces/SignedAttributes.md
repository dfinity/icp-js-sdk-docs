---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:164](https://github.com/dfinity/icp-js-auth/blob/43414d83f747f590108a9af502a568b719ce04b7/src/client/auth-client.ts#L164)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [auth-client.ts:165](https://github.com/dfinity/icp-js-auth/blob/43414d83f747f590108a9af502a568b719ce04b7/src/client/auth-client.ts#L165)

***

### signature

> **signature**: `Uint8Array`

Defined in: [auth-client.ts:166](https://github.com/dfinity/icp-js-auth/blob/43414d83f747f590108a9af502a568b719ce04b7/src/client/auth-client.ts#L166)
