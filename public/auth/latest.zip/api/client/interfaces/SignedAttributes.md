---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:135](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/auth-client.ts#L135)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [auth-client.ts:136](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/auth-client.ts#L136)

***

### signature

> **signature**: `Uint8Array`

Defined in: [auth-client.ts:137](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/auth-client.ts#L137)
