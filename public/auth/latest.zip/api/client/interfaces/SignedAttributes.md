---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:177](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L177)

## Properties

### data

> **data**: `Uint8Array`

Defined in: [auth-client.ts:178](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L178)

***

### signature

> **signature**: `Uint8Array`

Defined in: [auth-client.ts:179](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L179)
