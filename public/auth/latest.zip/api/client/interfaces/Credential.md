---
title: Credential
editUrl: false
next: true
prev: true
---

Defined in: [src/client/credential-storage.ts:12](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/credential-storage.ts#L12)

An identity, and the delegation that authorises it.

The two are one record because a delegation is issued to a key: held apart
they can disagree, and every reader then has to decide what a chain whose key
is missing means. Stored together, the half that would be dangerous — a chain
with no key to sign for it — cannot be written down at all.

## Type Parameters

### T

`T` *extends* `SignIdentity` = `SignIdentity`

## Properties

### chain?

> `optional` **chain?**: `DelegationChain`

Defined in: [src/client/credential-storage.ts:19](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/credential-storage.ts#L19)

Absent only while a ceremony is in flight, under the session-pending slot: there
is a key, and no delegation for it yet.

***

### identity

> **identity**: `T`

Defined in: [src/client/credential-storage.ts:13](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/credential-storage.ts#L13)
