---
title: CredentialStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/credential-storage.ts:32](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/credential-storage.ts#L32)

Holds the material a client acts with, a credential per slot.

Asynchronous, because using a credential means making a call and a
non-extractable key needs a store that can hold one. What a page renders on is
the state rather than this, so nothing here has to answer without awaiting.

A store knows two things about its medium that the library cannot infer, and
declares both.

## Type Parameters

### T

`T` *extends* `SignIdentity` = `SignIdentity`

## Properties

### durable

> `readonly` **durable**: `boolean`

Defined in: [src/client/credential-storage.ts:37](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/credential-storage.ts#L37)

Whether what this writes survives the document being torn down.

***

### shared

> `readonly` **shared**: `boolean`

Defined in: [src/client/credential-storage.ts:34](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/credential-storage.ts#L34)

Whether another tab of this origin reads what this writes.

## Methods

### create()

> **create**(): `Promise`\<`T`\>

Defined in: [src/client/credential-storage.ts:48](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/credential-storage.ts#L48)

A fresh identity of this store's own type, not persisted.

Generation belongs to the store because the medium decides the key type: one
that has to serialise needs a key whose private bytes are readable, and one
that does not should not have them. Kept together so an application cannot
pair a non-extractable key with a store that cannot hold one and find out at
runtime.

#### Returns

`Promise`\<`T`\>

***

### get()

> **get**(`slot`): `Promise`\<[`Credential`](Credential.md)\<`T`\> \| `null`\>

Defined in: [src/client/credential-storage.ts:51](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/credential-storage.ts#L51)

The credential stored under `slot`, or `null` where there is none.

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<[`Credential`](Credential.md)\<`T`\> \| `null`\>

***

### remove()

> **remove**(`slot`): `Promise`\<`void`\>

Defined in: [src/client/credential-storage.ts:55](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/credential-storage.ts#L55)

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<`void`\>

***

### set()

> **set**(`slot`, `credential`): `Promise`\<`void`\>

Defined in: [src/client/credential-storage.ts:53](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/credential-storage.ts#L53)

#### Parameters

##### slot

`string`

##### credential

[`Credential`](Credential.md)\<`T`\>

#### Returns

`Promise`\<`void`\>
