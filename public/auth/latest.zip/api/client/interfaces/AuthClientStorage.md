---
title: AuthClientStorage
editUrl: false
next: true
prev: true
---

Defined in: [storage.ts:14](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/storage.ts#L14)

Interface for persisting user authentication data

## Methods

### get()

> **get**(`key`): `Promise`\<`StoredKey` \| `null`\>

Defined in: [storage.ts:15](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/storage.ts#L15)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`StoredKey` \| `null`\>

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [storage.ts:19](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/storage.ts#L19)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`void`\>

***

### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [storage.ts:17](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/storage.ts#L17)

#### Parameters

##### key

`string`

##### value

`StoredKey`

#### Returns

`Promise`\<`void`\>
