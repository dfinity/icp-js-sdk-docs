---
title: AuthClientSignInOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:164](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L164)

Options for [AuthClient.signIn](../classes/AuthClient.md#signin).

## Properties

### maxTimeToLive?

> `optional` **maxTimeToLive?**: `bigint`

Defined in: [auth-client.ts:169](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L169)

Maximum lifetime of the delegation in nanoseconds.

#### Default

```ts
8 hours
```

***

### targets?

> `optional` **targets?**: `Principal`[]

Defined in: [auth-client.ts:174](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L174)

Restrict the delegation to specific canisters.
