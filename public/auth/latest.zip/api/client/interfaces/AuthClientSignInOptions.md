---
title: AuthClientSignInOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:164](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L164)

Options for [AuthClient.signIn](../classes/AuthClient.md#signin).

## Properties

### maxTimeToLive?

> `optional` **maxTimeToLive?**: `bigint`

Defined in: [auth-client.ts:169](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L169)

Maximum lifetime of the delegation in nanoseconds.

#### Default

```ts
8 hours
```

***

### targets?

> `optional` **targets?**: `Principal`[]

Defined in: [auth-client.ts:174](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L174)

Restrict the delegation to specific canisters.
