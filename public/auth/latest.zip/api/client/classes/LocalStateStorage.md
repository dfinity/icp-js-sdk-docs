---
title: LocalStateStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/state-storage.ts:177](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/state-storage.ts#L177)

State in `localStorage`, so every tab of an origin agrees on it and it
survives a reload.

The two fields are written as `<principal>|<expiration>` rather than JSON,
because an expiration is a `bigint` and JSON has no way to carry one.

## See

implements [StateStorage](../interfaces/StateStorage.md)

## Implements

- [`StateStorage`](../interfaces/StateStorage.md)

## Constructors

### Constructor

> **new LocalStateStorage**(): `LocalStateStorage`

#### Returns

`LocalStateStorage`

## Methods

### discard()

> **discard**(`key`): `void`

Defined in: [src/client/state-storage.ts:213](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/state-storage.ts#L213)

The same as [remove](#remove): this store publishes nothing beyond the origin.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`discard`](../interfaces/StateStorage.md#discard)

***

### get()

> **get**(`key`): [`SessionState`](../interfaces/SessionState.md) \| `null`

Defined in: [src/client/state-storage.ts:183](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/state-storage.ts#L183)

The state, or `null` where nothing is signed in within this store's reach.

#### Parameters

##### key

`string`

#### Returns

[`SessionState`](../interfaces/SessionState.md) \| `null`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`get`](../interfaces/StateStorage.md#get)

***

### remove()

> **remove**(`key`): `void`

Defined in: [src/client/state-storage.ts:207](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/state-storage.ts#L207)

Removes the state, and anything this store publishes beyond this origin.

What signing out does: the user ended the sign-in, so a sibling reading a
shared record must stop seeing one.

#### Parameters

##### key

`string`

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`remove`](../interfaces/StateStorage.md#remove)

***

### set()

> **set**(`key`, `state`): `void`

Defined in: [src/client/state-storage.ts:202](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/state-storage.ts#L202)

#### Parameters

##### key

`string`

##### state

`Omit`\<[`SessionState`](../interfaces/SessionState.md), `"held"`\>

#### Returns

`void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`set`](../interfaces/StateStorage.md#set)

***

### subscribe()

> **subscribe**(`key`, `listener`): () => `void`

Defined in: [src/client/state-storage.ts:225](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/state-storage.ts#L225)

Fires when the state changes, here or in another tab of this origin.

`localStorage` raises `storage` in every tab except the one that wrote, so
that event carries a change between tabs and a same-tab write is announced
directly. Either way the record is readable before it is announced, so a
listener asking who is signed in sees what it was told about.

#### Parameters

##### key

`string`

##### listener

() => `void`

#### Returns

() => `void`

#### Implementation of

[`StateStorage`](../interfaces/StateStorage.md).[`subscribe`](../interfaces/StateStorage.md#subscribe)
