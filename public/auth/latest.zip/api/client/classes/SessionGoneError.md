---
title: SessionGoneError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/app-delegation-source.ts:12](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/app-delegation-source.ts#L12)

Thrown when the canister has no session behind the caller: revoked, expired,
pruned, or never one at all.

This is the one terminal outcome. Everything else a mint can fail with, a
transport error or an internal canister error, leaves the session alone and is
worth retrying, so only this type may end a session.

## Extends

- `Error`

## Constructors

### Constructor

> **new SessionGoneError**(`message?`): `SessionGoneError`

Defined in: [src/client/app-delegation-source.ts:13](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/app-delegation-source.ts#L13)

#### Parameters

##### message?

`string` = `'The session behind this identity no longer exists'`

#### Returns

`SessionGoneError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:26

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

#### Inherited from

`Error.stack`
