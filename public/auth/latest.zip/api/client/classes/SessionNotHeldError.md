---
title: SessionNotHeldError
editUrl: false
next: true
prev: true
---

Defined in: [src/client/auth-client.ts:314](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/auth-client.ts#L314)

Thrown when a sign-in exists within the state store's reach but this origin
holds no credential for it.

A sibling subdomain reads the shared record on its first load and is in exactly
this position: someone is signed in, and it has nothing to act with until it
acquires its own. Catching this is where a silent re-issue belongs.

## Extends

- `Error`

## Constructors

### Constructor

> **new SessionNotHeldError**(`message?`): `SessionNotHeldError`

Defined in: [src/client/auth-client.ts:315](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/auth-client.ts#L315)

#### Parameters

##### message?

`string` = `'A sign-in exists for this domain, but this origin holds no credential for it'`

#### Returns

`SessionNotHeldError`

#### Overrides

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:26

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

#### Inherited from

`Error.stack`
