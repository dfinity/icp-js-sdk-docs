---
title: SharedMemoryCredentialStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/shared-memory-credential-storage.ts:78](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L78)

Credentials in memory, replicated to the other tabs of this origin.

For an environment with no durable medium — a browser with IndexedDB and
`localStorage` both unavailable, or an application that has decided nothing may
reach disk — where every tab minting for itself is still worth avoiding.

Every write is broadcast and every instance applies what it receives, so a
steady-state read is local and immediate: the medium is a `Map`, and the channel
is what keeps the Maps agreeing. A `CryptoKeyPair` survives a structured clone
as a handle that signs and cannot be exported, so what crosses is usable
without key material having been sent.

Nothing survives the document, which is what `durable` says. What that costs is
the last tab of an origin closing: the credentials go with it, and the next load
signs in again.

## See

implements [CredentialStorage](../interfaces/CredentialStorage.md)

## Implements

- [`CredentialStorage`](../interfaces/CredentialStorage.md)\<`ECDSAKeyIdentity`\>

## Constructors

### Constructor

> **new SharedMemoryCredentialStorage**(`options?`): `SharedMemoryCredentialStorage`

Defined in: [src/client/shared-memory-credential-storage.ts:117](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L117)

#### Parameters

##### options?

The channel and lock prefix the tabs of this origin share.

###### name?

`string`

#### Returns

`SharedMemoryCredentialStorage`

## Properties

### durable

> `readonly` **durable**: `false` = `false`

Defined in: [src/client/shared-memory-credential-storage.ts:80](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L80)

Whether what this writes survives the document being torn down.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`durable`](../interfaces/CredentialStorage.md#durable)

***

### shared

> `readonly` **shared**: `true` = `true`

Defined in: [src/client/shared-memory-credential-storage.ts:79](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L79)

Whether another tab of this origin reads what this writes.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`shared`](../interfaces/CredentialStorage.md#shared)

## Methods

### close()

> **close**(): `void`

Defined in: [src/client/shared-memory-credential-storage.ts:131](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L131)

Stops replicating and lets go of the name a peer waits on.

Only needed when you replace a store while the page lives; the document
going away does the same thing.

#### Returns

`void`

***

### create()

> **create**(): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [src/client/shared-memory-credential-storage.ts:137](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L137)

A fresh identity of this store's own type, not persisted.

Generation belongs to the store because the medium decides the key type: one
that has to serialise needs a key whose private bytes are readable, and one
that does not should not have them. Kept together so an application cannot
pair a non-extractable key with a store that cannot hold one and find out at
runtime.

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`create`](../interfaces/CredentialStorage.md#create)

***

### get()

> **get**(`slot`): `Promise`\<[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\> \| `null`\>

Defined in: [src/client/shared-memory-credential-storage.ts:141](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L141)

The credential stored under `slot`, or `null` where there is none.

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\> \| `null`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`get`](../interfaces/CredentialStorage.md#get)

***

### remove()

> **remove**(`slot`): `Promise`\<`void`\>

Defined in: [src/client/shared-memory-credential-storage.ts:155](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L155)

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`remove`](../interfaces/CredentialStorage.md#remove)

***

### set()

> **set**(`slot`, `credential`): `Promise`\<`void`\>

Defined in: [src/client/shared-memory-credential-storage.ts:150](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L150)

#### Parameters

##### slot

`string`

##### credential

[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\>

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`set`](../interfaces/CredentialStorage.md#set)
