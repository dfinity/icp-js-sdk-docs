---
title: LocalStorage
editUrl: false
next: true
prev: true
---

Defined in: [storage.ts:25](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/storage.ts#L25)

Legacy implementation of AuthClientStorage, for use where IndexedDb is not available

## Implements

- [`AuthClientStorage`](../interfaces/AuthClientStorage.md)

## Constructors

### Constructor

> **new LocalStorage**(`prefix`, `_localStorage?`): `LocalStorage`

Defined in: [storage.ts:26](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/storage.ts#L26)

#### Parameters

##### prefix

`string` = `'ic-'`

##### \_localStorage?

`Storage`

#### Returns

`LocalStorage`

## Properties

### prefix

> `readonly` **prefix**: `string` = `'ic-'`

Defined in: [storage.ts:27](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/storage.ts#L27)

## Methods

### get()

> **get**(`key`): `Promise`\<`string` \| `null`\>

Defined in: [storage.ts:31](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/storage.ts#L31)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`string` \| `null`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`get`](../interfaces/AuthClientStorage.md#get)

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [storage.ts:40](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/storage.ts#L40)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`remove`](../interfaces/AuthClientStorage.md#remove)

***

### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [storage.ts:35](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/storage.ts#L35)

#### Parameters

##### key

`string`

##### value

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`set`](../interfaces/AuthClientStorage.md#set)
