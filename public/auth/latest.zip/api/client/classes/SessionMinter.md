---
title: SessionMinter
editUrl: false
next: true
prev: true
---

Defined in: [src/client/session-minter.ts:133](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/session-minter.ts#L133)

Mints app delegations by asking the Internet Identity canister for one.

## Implements

- [`AppDelegationSource`](../interfaces/AppDelegationSource.md)

## Methods

### mint()

> **mint**(`appPublicKey`): `Promise`\<`DelegationChain`\>

Defined in: [src/client/session-minter.ts:161](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/session-minter.ts#L161)

Prepares and fetches an app delegation, once more if the fetch finds nothing
signed for what the prepare handed out.

The pair is two calls, and only the first of them is an update: an expiration
the canister will not sign for is one this session no longer holds, and the
answer is to prepare again rather than to sign in again. Attempted a second
time and no further — a third would be pursuing something other than the race
this covers.

#### Parameters

##### appPublicKey

`DerEncodedPublicKey`

#### Returns

`Promise`\<`DelegationChain`\>

#### Implementation of

[`AppDelegationSource`](../interfaces/AppDelegationSource.md).[`mint`](../interfaces/AppDelegationSource.md#mint)

***

### revoke()

> **revoke**(): `Promise`\<`void`\>

Defined in: [src/client/session-minter.ts:180](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/session-minter.ts#L180)

Ends the session at the canister.

Idempotent at the canister: a session that is already gone is `Ok`, because
the caller wanted it gone and it is gone. What comes back as an error is the
canister failing to write, and it is raised rather than dropped — an
application that told a user it signed them out of their apps should be able
to find out that it did not. The call can also fail the way any update call
can, and that rejection is the caller's to decide about too.

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `Promise`\<`SessionMinter`\>

Defined in: [src/client/session-minter.ts:140](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/session-minter.ts#L140)

#### Parameters

##### options

[`SessionMinterOptions`](../interfaces/SessionMinterOptions.md)

#### Returns

`Promise`\<`SessionMinter`\>
