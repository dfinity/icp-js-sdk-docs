---
title: AuthClient
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:162](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L162)

Manages authentication and identity for Internet Computer web apps.

## Example

```ts
const authClient = new AuthClient();

if (authClient.isAuthenticated()) {
  const identity = await authClient.getIdentity();
}

await authClient.login({
  onSuccess: () => console.log('Logged in!'),
});
```

## Constructors

### Constructor

> **new AuthClient**(`options?`): `AuthClient`

Defined in: [auth-client.ts:171](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L171)

#### Parameters

##### options?

[`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md) = `{}`

#### Returns

`AuthClient`

## Properties

### idleManager

> **idleManager**: [`IdleManager`](IdleManager.md) \| `undefined`

Defined in: [auth-client.ts:169](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L169)

## Methods

### getIdentity()

> **getIdentity**(): `Promise`\<`Identity`\>

Defined in: [auth-client.ts:202](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L202)

Returns the current identity, restoring a previous session if available.

#### Returns

`Promise`\<`Identity`\>

***

### isAuthenticated()

> **isAuthenticated**(): `boolean`

Defined in: [auth-client.ts:210](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L210)

Checks whether the user has an active, non-expired session.

#### Returns

`boolean`

***

### login()

> **login**(`options?`): `Promise`\<`void`\>

Defined in: [auth-client.ts:234](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L234)

Opens the identity provider and requests a delegation.

#### Parameters

##### options?

[`AuthClientLoginOptions`](../interfaces/AuthClientLoginOptions.md)

Login options.

#### Returns

`Promise`\<`void`\>

#### Throws

When authentication fails and no `onError` callback is provided.

#### Example

```ts
await authClient.login({
  onSuccess: () => console.log('Logged in!'),
  onError: (err) => console.error(err),
});
```

***

### logout()

> **logout**(`options?`): `Promise`\<`void`\>

Defined in: [auth-client.ts:287](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L287)

Clears the stored session and resets the client to an anonymous state.

#### Parameters

##### options?

Logout options.

###### returnTo?

`string`

URL to navigate to after logout.

#### Returns

`Promise`\<`void`\>
