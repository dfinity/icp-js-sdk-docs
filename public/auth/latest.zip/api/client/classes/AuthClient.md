---
title: AuthClient
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:192](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L192)

Tool to manage authentication and identity

## See

AuthClient

## Constructors

### Constructor

> `protected` **new AuthClient**(`_identity`, `_key`, `_chain`, `_storage`, `idleManager`, `_createOptions`, `_idpWindow?`, `_eventHandler?`): `AuthClient`

Defined in: [auth-client.ts:326](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L326)

#### Parameters

##### \_identity

`PartialIdentity` | `Identity`

##### \_key

`SignIdentity` | `PartialIdentity`

##### \_chain

`null` | `DelegationChain`

##### \_storage

[`AuthClientStorage`](../interfaces/AuthClientStorage.md)

##### idleManager

`undefined` | [`IdleManager`](IdleManager.md)

##### \_createOptions

`undefined` | [`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md)

##### \_idpWindow?

`Window`

##### \_eventHandler?

(`event`) => `void`

#### Returns

`AuthClient`

## Properties

### idleManager

> **idleManager**: `undefined` \| [`IdleManager`](IdleManager.md)

Defined in: [auth-client.ts:331](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L331)

## Methods

### getIdentity()

> **getIdentity**(): `Identity`

Defined in: [auth-client.ts:409](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L409)

#### Returns

`Identity`

***

### isAuthenticated()

> **isAuthenticated**(): `Promise`\<`boolean`\>

Defined in: [auth-client.ts:413](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L413)

#### Returns

`Promise`\<`boolean`\>

***

### login()

> **login**(`options?`): `Promise`\<`void`\>

Defined in: [auth-client.ts:446](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L446)

AuthClient Login - Opens up a new window to authenticate with Internet Identity

#### Parameters

##### options?

[`AuthClientLoginOptions`](../interfaces/AuthClientLoginOptions.md)

Options for logging in, merged with the options set during creation if any. Note: we only perform a shallow merge for the `customValues` property.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
const authClient = await AuthClient.create();
authClient.login({
 identityProvider: 'http://<canisterID>.127.0.0.1:8000',
 maxTimeToLive: BigInt (7) * BigInt(24) * BigInt(3_600_000_000_000), // 1 week
 windowOpenerFeatures: "toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100",
 onSuccess: () => {
   console.log('Login Successful!');
 },
 onError: (error) => {
   console.error('Login Failed: ', error);
 }
});
```

***

### logout()

> **logout**(`options`): `Promise`\<`void`\>

Defined in: [auth-client.ts:549](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L549)

#### Parameters

##### options

###### returnTo?

`string`

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `Promise`\<`AuthClient`\>

Defined in: [auth-client.ts:212](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L212)

Create an AuthClient to manage authentication and identity

#### Parameters

##### options

[`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md) = `{}`

Options for creating an AuthClient

#### Returns

`Promise`\<`AuthClient`\>

#### See

 - [AuthClientCreateOptions](../interfaces/AuthClientCreateOptions.md)
 - SignIdentity
 - [AuthClientStorage](../interfaces/AuthClientStorage.md)
 - [IdleOptions](../interfaces/IdleOptions.md)
Default behavior is to clear stored identity and reload the page when a user goes idle, unless you set the disableDefaultIdleCallback flag or pass in a custom idle callback.

#### Example

```ts
const authClient = await AuthClient.create({
  idleOptions: {
    disableIdle: true
  }
})
```
