---
title: MemoryCredentialStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/memory-credential-storage.ts:15](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/memory-credential-storage.ts#L15)

Credentials held for the lifetime of the instance and shared with nothing.

For tests and for environments with neither IndexedDB nor `localStorage`. A
reload starts from nothing, and other tabs see nothing, so every tab of an
origin is alone.

Records are handed back as they were given rather than round-tripped through
an encoding, which is what lets this hold a non-extractable key at all.

## See

implements [CredentialStorage](../interfaces/CredentialStorage.md)

## Implements

- [`CredentialStorage`](../interfaces/CredentialStorage.md)\<`ECDSAKeyIdentity`\>

## Constructors

### Constructor

> **new MemoryCredentialStorage**(): `MemoryCredentialStorage`

#### Returns

`MemoryCredentialStorage`

## Properties

### durable

> `readonly` **durable**: `false` = `false`

Defined in: [src/client/memory-credential-storage.ts:17](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/memory-credential-storage.ts#L17)

Whether what this writes survives the document being torn down.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`durable`](../interfaces/CredentialStorage.md#durable)

***

### shared

> `readonly` **shared**: `false` = `false`

Defined in: [src/client/memory-credential-storage.ts:16](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/memory-credential-storage.ts#L16)

Whether another tab of this origin reads what this writes.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`shared`](../interfaces/CredentialStorage.md#shared)

## Methods

### create()

> **create**(): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [src/client/memory-credential-storage.ts:23](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/memory-credential-storage.ts#L23)

A fresh identity of this store's own type, not persisted.

Generation belongs to the store because the medium decides the key type: one
that has to serialise needs a key whose private bytes are readable, and one
that does not should not have them. Kept together so an application cannot
pair a non-extractable key with a store that cannot hold one and find out at
runtime.

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`create`](../interfaces/CredentialStorage.md#create)

***

### get()

> **get**(`slot`): `Promise`\<[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\> \| `null`\>

Defined in: [src/client/memory-credential-storage.ts:28](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/memory-credential-storage.ts#L28)

The credential stored under `slot`, or `null` where there is none.

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\> \| `null`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`get`](../interfaces/CredentialStorage.md#get)

***

### remove()

> **remove**(`slot`): `Promise`\<`void`\>

Defined in: [src/client/memory-credential-storage.ts:37](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/memory-credential-storage.ts#L37)

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`remove`](../interfaces/CredentialStorage.md#remove)

***

### set()

> **set**(`slot`, `credential`): `Promise`\<`void`\>

Defined in: [src/client/memory-credential-storage.ts:32](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/memory-credential-storage.ts#L32)

#### Parameters

##### slot

`string`

##### credential

[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\>

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`set`](../interfaces/CredentialStorage.md#set)
