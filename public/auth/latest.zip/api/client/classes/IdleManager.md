---
title: IdleManager
editUrl: false
next: true
prev: true
---

Defined in: [idle-manager.ts:32](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L32)

Detects if the user has been idle for a duration of `idleTimeout` ms, and calls `onIdle` and registered callbacks.
By default, the IdleManager will log a user out after 10 minutes of inactivity.
To override these defaults, you can pass an `onIdle` callback, or configure a custom `idleTimeout` in milliseconds

## Constructors

### Constructor

> `protected` **new IdleManager**(`options`): `IdleManager`

Defined in: [idle-manager.ts:77](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L77)

#### Parameters

##### options

[`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md) = `{}`

[IdleManagerOptions](../type-aliases/IdleManagerOptions.md)

#### Returns

`IdleManager`

## Properties

### callbacks

> **callbacks**: `IdleCB`[] = `[]`

Defined in: [idle-manager.ts:33](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L33)

***

### idleTimeout

> **idleTimeout**: `undefined` \| `number`

Defined in: [idle-manager.ts:34](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L34)

***

### timeoutID?

> `optional` **timeoutID**: `number` = `undefined`

Defined in: [idle-manager.ts:35](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L35)

## Methods

### \_resetTimer()

> **\_resetTimer**(): `void`

Defined in: [idle-manager.ts:139](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L139)

Resets the timeouts during cleanup

#### Returns

`void`

***

### exit()

> **exit**(): `void`

Defined in: [idle-manager.ts:123](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L123)

Cleans up the idle manager and its listeners

#### Returns

`void`

***

### registerCallback()

> **registerCallback**(`callback`): `void`

Defined in: [idle-manager.ts:116](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L116)

#### Parameters

##### callback

`IdleCB`

function to be called when user goes idle

#### Returns

`void`

***

### create()

> `static` **create**(`options`): `IdleManager`

Defined in: [idle-manager.ts:46](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/idle-manager.ts#L46)

Creates an IdleManager

#### Parameters

##### options

Optional configuration

###### captureScroll?

`boolean`

capture scroll events

**Default**

```ts
false
```

###### idleTimeout?

`number`

timeout in ms

**Default**

```ts
10 minutes [600_000]
```

###### onIdle?

() => `unknown`

Callback after the user has gone idle

**See**

IdleCB

###### scrollDebounce?

`number`

scroll debounce time in ms

**Default**

```ts
100
```

#### Returns

`IdleManager`

#### See

[IdleManagerOptions](../type-aliases/IdleManagerOptions.md)
