---
title: IdbCredentialStorage
editUrl: false
next: true
prev: true
---

Defined in: [src/client/idb-credential-storage.ts:20](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L20)

Credentials in IndexedDB, which is what a browser offers that can hold a key
whose private half is unreadable.

A non-extractable `CryptoKeyPair` survives a structured clone, so what another
tab reads is a handle that signs and cannot be exported — no key material is
written anywhere.

## See

implements [CredentialStorage](../interfaces/CredentialStorage.md)

## Implements

- [`CredentialStorage`](../interfaces/CredentialStorage.md)\<`ECDSAKeyIdentity`\>

## Constructors

### Constructor

> **new IdbCredentialStorage**(`options?`): `IdbCredentialStorage`

Defined in: [src/client/idb-credential-storage.ts:29](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L29)

#### Parameters

##### options?

[`DBCreateOptions`](../type-aliases/DBCreateOptions.md)

Database name, store name and version.

#### Returns

`IdbCredentialStorage`

## Properties

### durable

> `readonly` **durable**: `true` = `true`

Defined in: [src/client/idb-credential-storage.ts:22](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L22)

Whether what this writes survives the document being torn down.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`durable`](../interfaces/CredentialStorage.md#durable)

***

### shared

> `readonly` **shared**: `true` = `true`

Defined in: [src/client/idb-credential-storage.ts:21](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L21)

Whether another tab of this origin reads what this writes.

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`shared`](../interfaces/CredentialStorage.md#shared)

## Methods

### create()

> **create**(): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [src/client/idb-credential-storage.ts:49](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L49)

A fresh identity of this store's own type, not persisted.

Generation belongs to the store because the medium decides the key type: one
that has to serialise needs a key whose private bytes are readable, and one
that does not should not have them. Kept together so an application cannot
pair a non-extractable key with a store that cannot hold one and find out at
runtime.

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`create`](../interfaces/CredentialStorage.md#create)

***

### get()

> **get**(`slot`): `Promise`\<[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\> \| `null`\>

Defined in: [src/client/idb-credential-storage.ts:53](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L53)

The credential stored under `slot`, or `null` where there is none.

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\> \| `null`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`get`](../interfaces/CredentialStorage.md#get)

***

### remove()

> **remove**(`slot`): `Promise`\<`void`\>

Defined in: [src/client/idb-credential-storage.ts:78](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L78)

#### Parameters

##### slot

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`remove`](../interfaces/CredentialStorage.md#remove)

***

### set()

> **set**(`slot`, `credential`): `Promise`\<`void`\>

Defined in: [src/client/idb-credential-storage.ts:70](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/idb-credential-storage.ts#L70)

#### Parameters

##### slot

`string`

##### credential

[`Credential`](../interfaces/Credential.md)\<`ECDSAKeyIdentity`\>

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`CredentialStorage`](../interfaces/CredentialStorage.md).[`set`](../interfaces/CredentialStorage.md#set)
