---
title: KEY_STORAGE_KEY
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_KEY**: `"identity"` = `'identity'`

Defined in: [storage.ts:3](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/storage.ts#L3)
