---
title: KEY_STORAGE_KEY
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_KEY**: `"identity"` = `'identity'`

Defined in: [storage.ts:3](https://github.com/dfinity/icp-js-auth/blob/43414d83f747f590108a9af502a568b719ce04b7/src/client/storage.ts#L3)
