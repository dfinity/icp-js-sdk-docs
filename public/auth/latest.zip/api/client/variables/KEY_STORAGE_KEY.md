---
title: KEY_STORAGE_KEY
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_KEY**: `"identity"` = `'identity'`

Defined in: [storage.ts:3](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/storage.ts#L3)
