---
title: OPENID_PROVIDER_URLS
editUrl: false
next: true
prev: true
---

> `const` **OPENID\_PROVIDER\_URLS**: `object`

Defined in: [auth-client.ts:42](https://github.com/dfinity/icp-js-auth/blob/78cb257493c98baeb84ab7114797e0da27fa3cba/src/client/auth-client.ts#L42)

## Type Declaration

### apple

> `readonly` **apple**: `"https://appleid.apple.com"` = `'https://appleid.apple.com'`

### google

> `readonly` **google**: `"https://accounts.google.com"` = `'https://accounts.google.com'`

### microsoft

> `readonly` **microsoft**: `"https://login.microsoftonline.com/{tid}/v2.0"` = `'https://login.microsoftonline.com/{tid}/v2.0'`
