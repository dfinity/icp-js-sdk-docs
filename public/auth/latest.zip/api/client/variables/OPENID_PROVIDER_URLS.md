---
title: OPENID_PROVIDER_URLS
editUrl: false
next: true
prev: true
---

> `const` **OPENID\_PROVIDER\_URLS**: `object`

Defined in: [auth-client.ts:47](https://github.com/dfinity/icp-js-auth/blob/43414d83f747f590108a9af502a568b719ce04b7/src/client/auth-client.ts#L47)

## Type Declaration

### apple

> `readonly` **apple**: `"https://appleid.apple.com"` = `'https://appleid.apple.com'`

### google

> `readonly` **google**: `"https://accounts.google.com"` = `'https://accounts.google.com'`

### microsoft

> `readonly` **microsoft**: `"https://login.microsoftonline.com/{tid}/v2.0"` = `'https://login.microsoftonline.com/{tid}/v2.0'`
