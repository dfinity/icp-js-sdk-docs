---
title: OPENID_PROVIDER_URLS
editUrl: false
next: true
prev: true
---

> `const` **OPENID\_PROVIDER\_URLS**: `object`

Defined in: [auth-client.ts:60](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L60)

## Type Declaration

### apple

> `readonly` **apple**: `"https://appleid.apple.com"` = `'https://appleid.apple.com'`

### google

> `readonly` **google**: `"https://accounts.google.com"` = `'https://accounts.google.com'`

### microsoft

> `readonly` **microsoft**: `"https://login.microsoftonline.com/{tid}/v2.0"` = `'https://login.microsoftonline.com/{tid}/v2.0'`
