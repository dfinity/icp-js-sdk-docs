---
title: KEY_STORAGE_DELEGATION
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_DELEGATION**: `"delegation"` = `'delegation'`

Defined in: [storage.ts:4](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/storage.ts#L4)
