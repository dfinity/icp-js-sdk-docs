---
title: KEY_STORAGE_DELEGATION
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_DELEGATION**: `"delegation"` = `'delegation'`

Defined in: [storage.ts:4](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/storage.ts#L4)
