---
title: DB_VERSION
editUrl: false
next: true
prev: true
---

> `const` **DB\_VERSION**: `1` = `1`

Defined in: [src/client/db.ts:4](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/db.ts#L4)
