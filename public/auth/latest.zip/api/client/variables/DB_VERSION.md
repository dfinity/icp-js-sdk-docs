---
title: DB_VERSION
editUrl: false
next: true
prev: true
---

> `const` **DB\_VERSION**: `1` = `1`

Defined in: [src/client/db.ts:4](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/db.ts#L4)
