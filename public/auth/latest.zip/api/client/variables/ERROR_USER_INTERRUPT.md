---
title: ERROR_USER_INTERRUPT
editUrl: false
next: true
prev: true
---

> `const` **ERROR\_USER\_INTERRUPT**: `"UserInterrupt"` = `'UserInterrupt'`

Defined in: [auth-client.ts:48](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L48)
