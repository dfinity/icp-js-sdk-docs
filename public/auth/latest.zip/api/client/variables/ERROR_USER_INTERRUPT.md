---
title: ERROR_USER_INTERRUPT
editUrl: false
next: true
prev: true
---

> `const` **ERROR\_USER\_INTERRUPT**: `"UserInterrupt"` = `'UserInterrupt'`

Defined in: [auth-client.ts:45](https://github.com/dfinity/icp-js-auth/blob/66b46f46ef183f021effc695de3adff07afb63d1/src/client/auth-client.ts#L45)
