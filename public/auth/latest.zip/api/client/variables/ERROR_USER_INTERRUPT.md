---
title: ERROR_USER_INTERRUPT
editUrl: false
next: true
prev: true
---

> `const` **ERROR\_USER\_INTERRUPT**: `"UserInterrupt"` = `'UserInterrupt'`

Defined in: [auth-client.ts:45](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L45)
