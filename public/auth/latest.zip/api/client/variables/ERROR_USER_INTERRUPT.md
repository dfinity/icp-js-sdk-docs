---
title: ERROR_USER_INTERRUPT
editUrl: false
next: true
prev: true
---

> `const` **ERROR\_USER\_INTERRUPT**: `"UserInterrupt"` = `'UserInterrupt'`

Defined in: [auth-client.ts:45](https://github.com/dfinity/icp-js-auth/blob/8afec10e1b4ca2afb53676db1f92c9b43e16f780/src/client/auth-client.ts#L45)
