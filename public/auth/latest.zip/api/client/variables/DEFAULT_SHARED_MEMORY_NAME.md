---
title: DEFAULT_SHARED_MEMORY_NAME
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_SHARED\_MEMORY\_NAME**: `"ic-credentials"` = `'ic-credentials'`

Defined in: [src/client/shared-memory-credential-storage.ts:5](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/shared-memory-credential-storage.ts#L5)

The channel and lock prefix every instance agrees on by default.
