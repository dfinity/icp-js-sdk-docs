---
title: DEFAULT_SHARED_MEMORY_NAME
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_SHARED\_MEMORY\_NAME**: `"ic-credentials"` = `'ic-credentials'`

Defined in: [src/client/shared-memory-credential-storage.ts:5](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/shared-memory-credential-storage.ts#L5)

The channel and lock prefix every instance agrees on by default.
