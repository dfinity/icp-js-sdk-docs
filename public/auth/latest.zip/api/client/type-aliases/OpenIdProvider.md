---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:40](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/auth-client.ts#L40)
