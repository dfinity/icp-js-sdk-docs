---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:58](https://github.com/dfinity/icp-js-auth/blob/2bcd97c551c0ff07fb3b68727b2eff2b62a654d0/src/client/auth-client.ts#L58)
