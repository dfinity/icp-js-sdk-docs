---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:45](https://github.com/dfinity/icp-js-auth/blob/43414d83f747f590108a9af502a568b719ce04b7/src/client/auth-client.ts#L45)
