---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:40](https://github.com/dfinity/icp-js-auth/blob/78cb257493c98baeb84ab7114797e0da27fa3cba/src/client/auth-client.ts#L40)
