---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [src/client/auth-client.ts:45](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/auth-client.ts#L45)
