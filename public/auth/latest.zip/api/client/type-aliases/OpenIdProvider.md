---
title: OpenIdProvider
editUrl: false
next: true
prev: true
---

> **OpenIdProvider** = `"google"` \| `"apple"` \| `"microsoft"`

Defined in: [auth-client.ts:58](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/auth-client.ts#L58)
