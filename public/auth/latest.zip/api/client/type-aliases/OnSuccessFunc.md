---
title: OnSuccessFunc
editUrl: false
next: true
prev: true
---

> **OnSuccessFunc** = () => `void` \| `Promise`\<`void`\> \| (`message`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:99](https://github.com/dfinity/icp-js-auth/blob/505768787e6cbdd9222dd39824af8e349e067a62/src/client/auth-client.ts#L99)
