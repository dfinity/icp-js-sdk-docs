---
title: OnSuccessFunc
editUrl: false
next: true
prev: true
---

> **OnSuccessFunc** = () => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:117](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L117)

## Returns

`void` \| `Promise`\<`void`\>
