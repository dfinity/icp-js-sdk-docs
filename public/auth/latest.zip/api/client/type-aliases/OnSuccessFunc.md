---
title: OnSuccessFunc
editUrl: false
next: true
prev: true
---

> **OnSuccessFunc** = () => `void` \| `Promise`\<`void`\> \| (`message`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:95](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L95)
