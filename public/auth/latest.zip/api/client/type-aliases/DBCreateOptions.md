---
title: DBCreateOptions
editUrl: false
next: true
prev: true
---

> **DBCreateOptions** = `object`

Defined in: [db.ts:50](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/db.ts#L50)

## Properties

### dbName?

> `optional` **dbName?**: `string`

Defined in: [db.ts:51](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/db.ts#L51)

***

### storeName?

> `optional` **storeName?**: `string`

Defined in: [db.ts:52](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/db.ts#L52)

***

### version?

> `optional` **version?**: `number`

Defined in: [db.ts:53](https://github.com/dfinity/icp-js-auth/blob/83e0ad647b81ca3ae2a373c7167ef3a55606e450/src/client/db.ts#L53)
