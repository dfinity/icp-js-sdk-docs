---
title: DBCreateOptions
editUrl: false
next: true
prev: true
---

> **DBCreateOptions** = `object`

Defined in: [src/client/db.ts:49](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/db.ts#L49)

## Properties

### dbName?

> `optional` **dbName?**: `string`

Defined in: [src/client/db.ts:50](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/db.ts#L50)

***

### storeName?

> `optional` **storeName?**: `string`

Defined in: [src/client/db.ts:51](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/db.ts#L51)

***

### version?

> `optional` **version?**: `number`

Defined in: [src/client/db.ts:52](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/db.ts#L52)
