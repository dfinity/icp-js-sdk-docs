---
title: DBCreateOptions
editUrl: false
next: true
prev: true
---

> **DBCreateOptions** = `object`

Defined in: [db.ts:50](https://github.com/dfinity/icp-js-auth/blob/78cb257493c98baeb84ab7114797e0da27fa3cba/src/client/db.ts#L50)

## Properties

### dbName?

> `optional` **dbName?**: `string`

Defined in: [db.ts:51](https://github.com/dfinity/icp-js-auth/blob/78cb257493c98baeb84ab7114797e0da27fa3cba/src/client/db.ts#L51)

***

### storeName?

> `optional` **storeName?**: `string`

Defined in: [db.ts:52](https://github.com/dfinity/icp-js-auth/blob/78cb257493c98baeb84ab7114797e0da27fa3cba/src/client/db.ts#L52)

***

### version?

> `optional` **version?**: `number`

Defined in: [db.ts:53](https://github.com/dfinity/icp-js-auth/blob/78cb257493c98baeb84ab7114797e0da27fa3cba/src/client/db.ts#L53)
