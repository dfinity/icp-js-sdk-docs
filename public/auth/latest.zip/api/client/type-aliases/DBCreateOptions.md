---
title: DBCreateOptions
editUrl: false
next: true
prev: true
---

> **DBCreateOptions** = `object`

Defined in: [db.ts:50](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/db.ts#L50)

## Properties

### dbName?

> `optional` **dbName**: `string`

Defined in: [db.ts:51](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/db.ts#L51)

***

### storeName?

> `optional` **storeName**: `string`

Defined in: [db.ts:52](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/db.ts#L52)

***

### version?

> `optional` **version**: `number`

Defined in: [db.ts:53](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/db.ts#L53)
