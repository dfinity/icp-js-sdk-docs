---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
---

> **AuthClientCreateOptions** = [`AuthClientBaseOptions`](../interfaces/AuthClientBaseOptions.md) & \{ `openIdProvider?`: [`OpenIdProvider`](OpenIdProvider.md); `ssoDomain?`: `never`; \} \| \{ `openIdProvider?`: `never`; `ssoDomain?`: `string`; \}

Defined in: [src/client/auth-client.ts:220](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/auth-client.ts#L220)

Options for creating an [AuthClient](../classes/AuthClient.md).

At most one one-click sign-in entry point may be set: `openIdProvider` for a
hardcoded provider, or `ssoDomain` for an organization's own SSO.
