---
title: OnErrorFunc
editUrl: false
next: true
prev: true
---

> **OnErrorFunc** = (`error?`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:119](https://github.com/dfinity/icp-js-auth/blob/8ecb4f2f45cc4773d82734de0d19597f96a36912/src/client/auth-client.ts#L119)

## Parameters

### error?

`string`

## Returns

`void` \| `Promise`\<`void`\>
