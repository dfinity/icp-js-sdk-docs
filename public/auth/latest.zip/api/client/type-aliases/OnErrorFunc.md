---
title: OnErrorFunc
editUrl: false
next: true
prev: true
---

> **OnErrorFunc** = (`error?`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:103](https://github.com/dfinity/icp-js-auth/blob/68af9e9258c0ad9cc567190c06b1118488a19d27/src/client/auth-client.ts#L103)

## Parameters

### error?

`string`

## Returns

`void` \| `Promise`\<`void`\>
