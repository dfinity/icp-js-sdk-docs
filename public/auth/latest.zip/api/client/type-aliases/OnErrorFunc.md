---
title: OnErrorFunc
editUrl: false
next: true
prev: true
---

> **OnErrorFunc** = (`error?`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:100](https://github.com/dfinity/icp-js-auth/blob/282a1a558a2bf0a16fa555eea4dd269e46d6f8b3/src/client/auth-client.ts#L100)

## Parameters

### error?

`string`

## Returns

`void` \| `Promise`\<`void`\>
