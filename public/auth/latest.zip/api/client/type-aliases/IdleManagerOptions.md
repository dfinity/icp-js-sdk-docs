---
title: IdleManagerOptions
editUrl: false
next: true
prev: true
---

> **IdleManagerOptions** = `object`

Defined in: [idle-manager.ts:3](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/idle-manager.ts#L3)

## Extended by

- [`IdleOptions`](../interfaces/IdleOptions.md)

## Properties

### captureScroll?

> `optional` **captureScroll?**: `boolean`

Defined in: [idle-manager.ts:17](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/idle-manager.ts#L17)

capture scroll events

#### Default

```ts
false
```

***

### idleTimeout?

> `optional` **idleTimeout?**: `number`

Defined in: [idle-manager.ts:12](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/idle-manager.ts#L12)

timeout in ms

#### Default

```ts
30 minutes [600_000]
```

***

### onIdle?

> `optional` **onIdle?**: `IdleCB`

Defined in: [idle-manager.ts:7](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/idle-manager.ts#L7)

Callback after the user has gone idle

***

### scrollDebounce?

> `optional` **scrollDebounce?**: `number`

Defined in: [idle-manager.ts:22](https://github.com/dfinity/icp-js-auth/blob/eed30ba5de5179a51d6a3f555de081e1f4f2707c/src/client/idle-manager.ts#L22)

scroll debounce time in ms

#### Default

```ts
100
```
