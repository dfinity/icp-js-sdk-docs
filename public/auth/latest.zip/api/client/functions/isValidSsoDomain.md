---
title: isValidSsoDomain
editUrl: false
next: true
prev: true
---

> **isValidSsoDomain**(`domain`, `signal`): `Promise`\<`boolean`\>

Defined in: [src/client/sso.ts:93](https://github.com/dfinity/icp-js-auth/blob/4f6ebef59de4d165a3fa8e2ae5d9889db17e566d/src/client/sso.ts#L93)

Checks whether an organization domain can be used for SSO sign-in: it is a
domain name, and it publishes `/.well-known/ii-openid-configuration` with a
`client_id` and an `openid_configuration` URL.

The document must be served with `Access-Control-Allow-Origin: *`.

The check waits on a third-party server and has no deadline of its own, so
`signal` sets one. Pass `AbortSignal.timeout(...)` for a one-shot check, or a
controller you abort per keystroke when checking as the user types.

## Parameters

### domain

`string`

The organization domain.

### signal

`AbortSignal`

Bounds the check.

## Returns

`Promise`\<`boolean`\>

Whether the domain is usable for SSO sign-in.

## Throws

When `signal` aborts — an abandoned check is not a verdict on the
  domain, so it must not be read as `false`.

## Example

```ts
if (await isValidSsoDomain(input.value, AbortSignal.timeout(5_000))) {
  const authClient = new AuthClient({ ssoDomain: input.value });
  await authClient.signIn();
}
```
