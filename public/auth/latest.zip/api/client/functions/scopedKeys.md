---
title: scopedKeys
editUrl: false
next: true
prev: true
---

> **scopedKeys**\<`P`, `K`\>(`params`): `` `openid:${{ apple: "https://appleid.apple.com"; google: "https://accounts.google.com"; microsoft: "https://login.microsoftonline.com/{tid}/v2.0" }[P]}:${K}` ``[]

Defined in: [auth-client.ts:750](https://github.com/dfinity/icp-js-auth/blob/43414d83f747f590108a9af502a568b719ce04b7/src/client/auth-client.ts#L750)

Scopes attribute keys to an OpenID provider.

When using one-click sign-in, attributes can be scoped to the same provider
so the user grants access in a single step without an additional prompt.

## Type Parameters

### P

`P` *extends* `"google"` \| `"apple"` \| `"microsoft"`

### K

`K` *extends* `string` = `"name"` \| `"email"` \| `"verified_email"`

## Parameters

### params

#### keys?

readonly `K`[]

The attribute keys to scope. Defaults to `['name', 'email', 'verified_email']`.

#### openIdProvider

`P`

The OpenID provider the keys should be scoped to.

## Returns

`` `openid:${{ apple: "https://appleid.apple.com"; google: "https://accounts.google.com"; microsoft: "https://login.microsoftonline.com/{tid}/v2.0" }[P]}:${K}` ``[]

The scoped attribute keys as `openid:<provider-url>:<key>`.

## Example

```ts
scopedKeys({ openIdProvider: 'google', keys: ['email'] });
// ['openid:https://accounts.google.com:email']
```
