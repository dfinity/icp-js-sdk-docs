---
title: watchActivity
editUrl: false
next: true
prev: true
---

> **watchActivity**(`onActivity`): (() => `void`) \| `undefined`

Defined in: [src/client/foreground-refresh.ts:72](https://github.com/dfinity/icp-js-auth/blob/b2403da0dcd445588fce38bb34c16f4add2011d9/src/client/foreground-refresh.ts#L72)

Calls back when somebody is using the page.

A user moving a mouse is very likely about to do something that needs a
delegation, so this is the same claim [watchForeground](watchForeground.md) makes — this
page is in front of a person right now — from the other direction. Whether a
mint is actually due is not decided here, and the identity's pre-mint
threshold is what keeps a resting hand from costing more than one mint per
refresh interval.

It matters beyond saving the first request a mint: a session bounded by how
long it goes unminted would otherwise end under a user who is reading rather
than clicking.

## Parameters

### onActivity

() => `void`

Invoked on any sign of use.

## Returns

(() => `void`) \| `undefined`

A function that unhooks the listeners, or `undefined` where there is
  no DOM to hook.
