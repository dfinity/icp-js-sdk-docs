---
title: Overview
editUrl: false
next: true
prev: true
---

## Classes

- [AuthClient](classes/AuthClient.md)
- [IdbKeyVal](classes/IdbKeyVal.md)
- [IdbStorage](classes/IdbStorage.md)
- [IdleManager](classes/IdleManager.md)
- [LocalStorage](classes/LocalStorage.md)

## Interfaces

- [AuthClientCreateOptions](interfaces/AuthClientCreateOptions.md)
- [AuthClientLoginOptions](interfaces/AuthClientLoginOptions.md)
- [AuthClientStorage](interfaces/AuthClientStorage.md)
- [IdleOptions](interfaces/IdleOptions.md)

## Type Aliases

- [DBCreateOptions](type-aliases/DBCreateOptions.md)
- [IdleManagerOptions](type-aliases/IdleManagerOptions.md)
- [OnErrorFunc](type-aliases/OnErrorFunc.md)
- [OnSuccessFunc](type-aliases/OnSuccessFunc.md)
- [OpenIdProvider](type-aliases/OpenIdProvider.md)

## Variables

- [KEY\_STORAGE\_DELEGATION](variables/KEY_STORAGE_DELEGATION.md)
- [KEY\_STORAGE\_KEY](variables/KEY_STORAGE_KEY.md)
