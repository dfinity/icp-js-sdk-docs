---
title: OnErrorFunc
editUrl: false
next: true
prev: true
---

> **OnErrorFunc** = (`error?`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:100](https://github.com/dfinity/icp-js-auth/blob/8afec10e1b4ca2afb53676db1f92c9b43e16f780/src/client/auth-client.ts#L100)

## Parameters

### error?

`string`

## Returns

`void` \| `Promise`\<`void`\>
