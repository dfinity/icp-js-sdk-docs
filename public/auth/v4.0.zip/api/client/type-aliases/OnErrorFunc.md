---
title: OnErrorFunc
editUrl: false
next: true
prev: true
---

> **OnErrorFunc** = (`error?`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:99](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/auth-client.ts#L99)

## Parameters

### error?

`string`

## Returns

`void` \| `Promise`\<`void`\>
