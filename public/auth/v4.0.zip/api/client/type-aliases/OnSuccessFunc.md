---
title: OnSuccessFunc
editUrl: false
next: true
prev: true
---

> **OnSuccessFunc** = () => `void` \| `Promise`\<`void`\> \| (`message`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:96](https://github.com/dfinity/icp-js-auth/blob/8afec10e1b4ca2afb53676db1f92c9b43e16f780/src/client/auth-client.ts#L96)
