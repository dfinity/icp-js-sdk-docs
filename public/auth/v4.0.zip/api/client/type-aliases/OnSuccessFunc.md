---
title: OnSuccessFunc
editUrl: false
next: true
prev: true
---

> **OnSuccessFunc** = () => `void` \| `Promise`\<`void`\> \| (`message`) => `void` \| `Promise`\<`void`\>

Defined in: [auth-client.ts:95](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/auth-client.ts#L95)
