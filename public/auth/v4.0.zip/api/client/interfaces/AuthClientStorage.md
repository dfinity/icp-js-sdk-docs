---
title: AuthClientStorage
editUrl: false
next: true
prev: true
---

Defined in: [storage.ts:14](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/storage.ts#L14)

Interface for persisting user authentication data

## Methods

### get()

> **get**(`key`): `Promise`\<`null` \| `StoredKey`\>

Defined in: [storage.ts:15](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/storage.ts#L15)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`null` \| `StoredKey`\>

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [storage.ts:19](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/storage.ts#L19)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`void`\>

***

### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [storage.ts:17](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/storage.ts#L17)

#### Parameters

##### key

`string`

##### value

`StoredKey`

#### Returns

`Promise`\<`void`\>
