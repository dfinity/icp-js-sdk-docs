---
title: AuthClientLoginOptions
editUrl: false
next: true
prev: true
---

Defined in: [auth-client.ts:101](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L101)

## Properties

### allowPinAuthentication?

> `optional` **allowPinAuthentication**: `boolean`

Defined in: [auth-client.ts:115](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L115)

If present, indicates whether or not the Identity Provider should allow the user to authenticate and/or register using a temporary key/PIN identity. Authenticating dapps may want to prevent users from using Temporary keys/PIN identities because Temporary keys/PIN identities are less secure than Passkeys (webauthn credentials) and because Temporary keys/PIN identities generally only live in a browser database (which may get cleared by the browser/OS).

***

### customValues?

> `optional` **customValues**: `Record`\<`string`, `unknown`\>

Defined in: [auth-client.ts:137](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L137)

Extra values to be passed in the login request during the authorize-ready phase

***

### derivationOrigin?

> `optional` **derivationOrigin**: `string` \| `URL`

Defined in: [auth-client.ts:120](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L120)

Origin for Identity Provider to use while generating the delegated identity. For II, the derivation origin must authorize this origin by setting a record at `<derivation-origin>/.well-known/ii-alternative-origins`.

#### See

https://github.com/dfinity/internet-identity/blob/main/docs/internet-identity-spec.adoc

***

### identityProvider?

> `optional` **identityProvider**: `string` \| `URL`

Defined in: [auth-client.ts:106](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L106)

Identity provider

#### Default

```ts
"https://identity.internetcomputer.org"
```

***

### maxTimeToLive?

> `optional` **maxTimeToLive**: `bigint`

Defined in: [auth-client.ts:111](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L111)

Expiration of the authentication in nanoseconds

#### Default

```ts
BigInt(8) hours * BigInt(3_600_000_000_000) nanoseconds
```

***

### onError?

> `optional` **onError**: [`OnErrorFunc`](../type-aliases/OnErrorFunc.md)

Defined in: [auth-client.ts:133](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L133)

Callback in case authentication fails

***

### onSuccess?

> `optional` **onSuccess**: [`OnSuccessFunc`](../type-aliases/OnSuccessFunc.md)

Defined in: [auth-client.ts:129](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L129)

Callback once login has completed

***

### windowOpenerFeatures?

> `optional` **windowOpenerFeatures**: `string`

Defined in: [auth-client.ts:125](https://github.com/dfinity/icp-js-auth/blob/db0a878c6b610869013c2fe1553d6ff1b304d6f9/src/client/auth-client.ts#L125)

Auth Window feature config string

#### Example

```ts
"toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100"
```
