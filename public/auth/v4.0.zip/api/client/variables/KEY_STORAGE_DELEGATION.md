---
title: KEY_STORAGE_DELEGATION
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_DELEGATION**: `"delegation"` = `'delegation'`

Defined in: [storage.ts:4](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/storage.ts#L4)
