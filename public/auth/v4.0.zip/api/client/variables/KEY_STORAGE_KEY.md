---
title: KEY_STORAGE_KEY
editUrl: false
next: true
prev: true
---

> `const` **KEY\_STORAGE\_KEY**: `"identity"` = `'identity'`

Defined in: [storage.ts:3](https://github.com/dfinity/icp-js-auth/blob/8afec10e1b4ca2afb53676db1f92c9b43e16f780/src/client/storage.ts#L3)
