---
title: ERROR_USER_INTERRUPT
editUrl: false
next: true
prev: true
---

> `const` **ERROR\_USER\_INTERRUPT**: `"UserInterrupt"` = `'UserInterrupt'`

Defined in: [auth-client.ts:44](https://github.com/dfinity/icp-js-auth/blob/70414920065c9239ba2520ee77fc40cbadf93c11/src/client/auth-client.ts#L44)
