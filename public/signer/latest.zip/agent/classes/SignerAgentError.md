---
title: SignerAgentError
editUrl: false
next: true
prev: true
---

Defined in: [src/agent/agent.ts:80](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/agent/agent.ts#L80)

Error thrown by [SignerAgent](SignerAgent.md) when a signer returns an invalid
response or certificate validation fails.

## Extends

- `Error`

## Constructors

### Constructor

> **new SignerAgentError**(`message?`): `SignerAgentError`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1080

#### Parameters

##### message?

`string`

#### Returns

`SignerAgentError`

#### Inherited from

`Error.constructor`

### Constructor

> **new SignerAgentError**(`message?`, `options?`): `SignerAgentError`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1080

#### Parameters

##### message?

`string`

##### options?

`ErrorOptions`

#### Returns

`SignerAgentError`

#### Inherited from

`Error.constructor`

## Properties

### cause?

> `optional` **cause?**: `unknown`

Defined in: docs/node\_modules/typescript/lib/lib.es2022.error.d.ts:24

#### Inherited from

`Error.cause`

***

### message

> **message**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1075

#### Inherited from

`Error.message`

***

### name

> **name**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1074

#### Inherited from

`Error.name`

***

### stack?

> `optional` **stack?**: `string`

Defined in: docs/node\_modules/typescript/lib/lib.es5.d.ts:1076

#### Inherited from

`Error.stack`
