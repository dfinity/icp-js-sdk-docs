---
title: Transport
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:33](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L33)

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`Channel`](Channel.md)\>

Defined in: [src/transport.ts:34](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L34)

#### Returns

`Promise`\<[`Channel`](Channel.md)\>
