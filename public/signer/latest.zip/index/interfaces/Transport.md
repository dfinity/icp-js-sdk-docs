---
title: Transport
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:33](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/transport.ts#L33)

## Methods

### establishChannel()

> **establishChannel**(): `Promise`\<[`Channel`](Channel.md)\>

Defined in: [src/transport.ts:34](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/transport.ts#L34)

#### Returns

`Promise`\<[`Channel`](Channel.md)\>
