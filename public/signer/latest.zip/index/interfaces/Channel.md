---
title: Channel
editUrl: false
next: true
prev: true
---

Defined in: [src/transport.ts:16](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L16)

## Properties

### closed

> **closed**: `boolean`

Defined in: [src/transport.ts:17](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L17)

## Methods

### addEventListener()

#### Call Signature

> **addEventListener**(`event`, `listener`): () => `void`

Defined in: [src/transport.ts:19](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L19)

##### Parameters

###### event

`"close"`

###### listener

() => `void`

##### Returns

() => `void`

#### Call Signature

> **addEventListener**(`event`, `listener`): () => `void`

Defined in: [src/transport.ts:21](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L21)

##### Parameters

###### event

`"response"`

###### listener

(`response`) => `void`

##### Returns

() => `void`

***

### close()

> **close**(): `Promise`\<`void`\>

Defined in: [src/transport.ts:30](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L30)

#### Returns

`Promise`\<`void`\>

***

### send()

> **send**(`request`): `Promise`\<`void`\>

Defined in: [src/transport.ts:28](https://github.com/dfinity/icp-js-signer/blob/163695b433f1bd38d38c461b2856e8b7eb963bfa/src/transport.ts#L28)

Sends a request to the signer. A promise of a request is sent once it
resolves, and keeps the place in call order it was given on the call.

#### Parameters

##### request

`JsonRpcRequest` \| `Promise`\<`JsonRpcRequest`\>

The JSON-RPC request to send, or a promise of it.

#### Returns

`Promise`\<`void`\>
