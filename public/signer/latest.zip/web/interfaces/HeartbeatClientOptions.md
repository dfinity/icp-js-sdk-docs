---
title: HeartbeatClientOptions
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/client.ts:3](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L3)

## Properties

### crypto?

> `optional` **crypto?**: `Pick`\<`Crypto`, `"randomUUID"`\>

Defined in: [src/web/heartbeat/client.ts:60](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L60)

Get random uuid implementation for status messages

#### Default

```ts
globalThis.crypto
```

***

### disconnectTimeout?

> `optional` **disconnectTimeout?**: `number`

Defined in: [src/web/heartbeat/client.ts:41](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L41)

Time in milliseconds of not receiving heartbeat responses from a signer window that is still open
after which the communication channel is disconnected. A closed signer window disconnects at the
next status poll.

#### Default

```ts
5000
```

***

### establishTimeout?

> `optional` **establishTimeout?**: `number`

Defined in: [src/web/heartbeat/client.ts:17](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L17)

Reasonable time in milliseconds in which an open signer window needs to answer.
A closed signer window fails establishment at the next status poll.

#### Default

```ts
10000
```

***

### onDisconnect

> **onDisconnect**: () => `void`

Defined in: [src/web/heartbeat/client.ts:45](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L45)

Callback when no heartbeats have been received for `disconnectTimeout` milliseconds

#### Returns

`void`

***

### onEstablish

> **onEstablish**: (`origin`, `status`) => `void`

Defined in: [src/web/heartbeat/client.ts:11](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L11)

Callback when first heartbeat has been received

#### Parameters

##### origin

`string`

##### status

`"pending"` \| `"ready"`

#### Returns

`void`

***

### onEstablishTimeout

> **onEstablishTimeout**: () => `void`

Defined in: [src/web/heartbeat/client.ts:21](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L21)

Callback when establishment fails because `establishTimeout` elapsed or the signer window closed

#### Returns

`void`

***

### onPendingTimeout

> **onPendingTimeout**: () => `void`

Defined in: [src/web/heartbeat/client.ts:34](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L34)

Callback when no heartbeats have been received for `pendingTimeout` milliseconds

#### Returns

`void`

***

### onStatusChange

> **onStatusChange**: (`status`) => `void`

Defined in: [src/web/heartbeat/client.ts:25](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L25)

Callback when status response has changed

#### Parameters

##### status

`"pending"` \| `"ready"`

#### Returns

`void`

***

### pendingTimeout?

> `optional` **pendingTimeout?**: `number`

Defined in: [src/web/heartbeat/client.ts:30](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L30)

Reasonable time in milliseconds in which the communication channel can be pending

#### Default

```ts
300000
```

***

### signerWindow

> **signerWindow**: `Window`

Defined in: [src/web/heartbeat/client.ts:7](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L7)

Signer window to send and receive heartbeat messages from

***

### statusPollingRate?

> `optional` **statusPollingRate?**: `number`

Defined in: [src/web/heartbeat/client.ts:50](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L50)

Status polling rate in ms

#### Default

```ts
300
```

***

### window?

> `optional` **window?**: `Window`

Defined in: [src/web/heartbeat/client.ts:55](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L55)

Relying party window, used to listen for incoming message events

#### Default

```ts
globalThis.window
```
