---
title: HeartbeatClient
editUrl: false
next: true
prev: true
---

Defined in: [src/web/heartbeat/client.ts:63](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L63)

## Constructors

### Constructor

> **new HeartbeatClient**(`options`): `HeartbeatClient`

Defined in: [src/web/heartbeat/client.ts:67](https://github.com/dfinity/icp-js-signer/blob/697575191ad85694235f30ac804c0915734b02c3/src/web/heartbeat/client.ts#L67)

#### Parameters

##### options

[`HeartbeatClientOptions`](../interfaces/HeartbeatClientOptions.md)

#### Returns

`HeartbeatClient`
