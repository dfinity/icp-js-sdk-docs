---
title: SnsSwapDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L397)

#### Properties

##### error\_refund\_icp

> **error\_refund\_icp**: `ActorMethod`\<\[[`ErrorRefundIcpRequest`](#errorrefundicprequest)\], [`ErrorRefundIcpResponse`](#errorrefundicpresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L398)

##### finalize\_swap

> **finalize\_swap**: `ActorMethod`\<\[\{ \}\], [`FinalizeSwapResponse`](#finalizeswapresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L402)

##### get\_auto\_finalization\_status

> **get\_auto\_finalization\_status**: `ActorMethod`\<\[\{ \}\], [`GetAutoFinalizationStatusResponse`](#getautofinalizationstatusresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L403)

##### get\_buyer\_state

> **get\_buyer\_state**: `ActorMethod`\<\[[`GetBuyerStateRequest`](#getbuyerstaterequest)\], [`GetBuyerStateResponse`](#getbuyerstateresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L407)

##### get\_buyers\_total

> **get\_buyers\_total**: `ActorMethod`\<\[\{ \}\], [`GetBuyersTotalResponse`](#getbuyerstotalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L408)

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\{ \}\], [`CanisterStatusResultV2`](#canisterstatusresultv2)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L409)

##### get\_derived\_state

> **get\_derived\_state**: `ActorMethod`\<\[\{ \}\], [`GetDerivedStateResponse`](#getderivedstateresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L410)

##### get\_init

> **get\_init**: `ActorMethod`\<\[\{ \}\], [`GetInitResponse`](#getinitresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L411)

##### get\_lifecycle

> **get\_lifecycle**: `ActorMethod`\<\[\{ \}\], [`GetLifecycleResponse`](#getlifecycleresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L412)

##### get\_open\_ticket

> **get\_open\_ticket**: `ActorMethod`\<\[\{ \}\], [`GetOpenTicketResponse`](#getopenticketresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L413)

##### get\_sale\_parameters

> **get\_sale\_parameters**: `ActorMethod`\<\[\{ \}\], [`GetSaleParametersResponse`](#getsaleparametersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L414)

##### get\_state

> **get\_state**: `ActorMethod`\<\[\{ \}\], [`GetStateResponse`](#getstateresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L415)

##### get\_timers

> **get\_timers**: `ActorMethod`\<\[\{ \}\], [`GetTimersResponse`](#gettimersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L416)

##### list\_community\_fund\_participants

> **list\_community\_fund\_participants**: `ActorMethod`\<\[[`ListCommunityFundParticipantsRequest`](#listcommunityfundparticipantsrequest)\], [`ListCommunityFundParticipantsResponse`](#listcommunityfundparticipantsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L417)

##### list\_direct\_participants

> **list\_direct\_participants**: `ActorMethod`\<\[[`ListDirectParticipantsRequest`](#listdirectparticipantsrequest)\], [`ListDirectParticipantsResponse`](#listdirectparticipantsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L421)

##### list\_sns\_neuron\_recipes

> **list\_sns\_neuron\_recipes**: `ActorMethod`\<\[[`ListSnsNeuronRecipesRequest`](#listsnsneuronrecipesrequest)\], [`ListSnsNeuronRecipesResponse`](#listsnsneuronrecipesresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L425)

##### new\_sale\_ticket

> **new\_sale\_ticket**: `ActorMethod`\<\[[`NewSaleTicketRequest`](#newsaleticketrequest)\], [`NewSaleTicketResponse`](#newsaleticketresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L429)

##### notify\_payment\_failure

> **notify\_payment\_failure**: `ActorMethod`\<\[\{ \}\], [`Ok_2`](#ok_2)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L430)

##### refresh\_buyer\_tokens

> **refresh\_buyer\_tokens**: `ActorMethod`\<\[[`RefreshBuyerTokensRequest`](#refreshbuyertokensrequest)\], [`RefreshBuyerTokensResponse`](#refreshbuyertokensresponse)\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L431)

##### reset\_timers

> **reset\_timers**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L435)

***

### BuyerState

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L13)

#### Properties

##### has\_created\_neuron\_recipes

> **has\_created\_neuron\_recipes**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L15)

##### icp

> **icp**: \[\] \| \[[`TransferableAmount`](#transferableamount)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L14)

***

### CanisterCallError

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L17)

#### Properties

##### code

> **code**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L18)

##### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L19)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L21)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L25)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L28)

##### memory\_metrics

> **memory\_metrics**: \[\] \| \[[`MemoryMetrics`](#memorymetrics)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L22)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L24)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L29)

##### query\_stats

> **query\_stats**: \[\] \| \[[`QueryStats`](#querystats)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L27)

##### settings

> **settings**: [`DefiniteCanisterSettingsArgs`](#definitecanistersettingsargs)

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L26)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L23)

***

### CfInvestment

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L35)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L36)

##### hotkey\_principal

> **hotkey\_principal**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L37)

##### hotkeys

> **hotkeys**: \[\] \| \[[`Principals`](#principals)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L38)

##### nns\_neuron\_id

> **nns\_neuron\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L39)

***

### CfNeuron

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L41)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L45)

##### has\_created\_neuron\_recipes

> **has\_created\_neuron\_recipes**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L42)

##### hotkeys

> **hotkeys**: \[\] \| \[[`Principals`](#principals)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L43)

##### nns\_neuron\_id

> **nns\_neuron\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L44)

***

### CfParticipant

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L47)

#### Properties

##### cf\_neurons

> **cf\_neurons**: [`CfNeuron`](#cfneuron)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L50)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L48)

##### hotkey\_principal

> **hotkey\_principal**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L49)

***

### Countries

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L52)

#### Properties

##### iso\_codes

> **iso\_codes**: `string`[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L53)

***

### DefiniteCanisterSettingsArgs

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L55)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L61)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L58)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L56)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L60)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L59)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L57)

***

### DerivedState

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L63)

#### Properties

##### buyer\_total\_icp\_e8s

> **buyer\_total\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L65)

##### cf\_neuron\_count

> **cf\_neuron\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L70)

##### cf\_participant\_count

> **cf\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L66)

##### direct\_participant\_count

> **direct\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L69)

##### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L68)

##### neurons\_fund\_participation\_icp\_e8s

> **neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L67)

##### sns\_tokens\_per\_icp

> **sns\_tokens\_per\_icp**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L64)

***

### DirectInvestment

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L72)

#### Properties

##### buyer\_principal

> **buyer\_principal**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L73)

***

### Err

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L75)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L76)

##### error\_type

> **error\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L77)

***

### Err\_1

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L79)

#### Properties

##### error\_type

> **error\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L80)

***

### Err\_2

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L82)

#### Properties

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L85)

##### existing\_ticket

> **existing\_ticket**: \[\] \| \[[`Ticket`](#ticket-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L84)

##### invalid\_user\_amount

> **invalid\_user\_amount**: \[\] \| \[[`InvalidUserAmount`](#invaliduseramount)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L83)

***

### Error

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L87)

#### Properties

##### message

> **message**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L88)

***

### ErrorRefundIcpRequest

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L90)

#### Properties

##### source\_principal\_id

> **source\_principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L91)

***

### ErrorRefundIcpResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L93)

#### Properties

##### result

> **result**: \[\] \| \[[`Result`](#result-3)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L94)

***

### FailedUpdate

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L96)

#### Properties

##### dapp\_canister\_id

> **dapp\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L98)

##### err

> **err**: \[\] \| \[[`CanisterCallError`](#canistercallerror)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L97)

***

### FinalizeSwapResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L100)

#### Properties

##### claim\_neuron\_result

> **claim\_neuron\_result**: \[\] \| \[[`SweepResult`](#sweepresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L112)

##### create\_sns\_neuron\_recipes\_result

> **create\_sns\_neuron\_recipes\_result**: \[\] \| \[[`SweepResult`](#sweepresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L102)

##### error\_message

> **error\_message**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L106)

##### set\_dapp\_controllers\_call\_result

> **set\_dapp\_controllers\_call\_result**: \[\] \| \[[`SetDappControllersCallResult`](#setdappcontrollerscallresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L101)

##### set\_mode\_call\_result

> **set\_mode\_call\_result**: \[\] \| \[[`SetModeCallResult`](#setmodecallresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L110)

##### settle\_community\_fund\_participation\_result

> **settle\_community\_fund\_participation\_result**: \[\] \| \[[`SettleCommunityFundParticipationResult`](#settlecommunityfundparticipationresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L103)

##### settle\_neurons\_fund\_participation\_result

> **settle\_neurons\_fund\_participation\_result**: \[\] \| \[[`SettleNeuronsFundParticipationResult`](#settleneuronsfundparticipationresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L107)

##### sweep\_icp\_result

> **sweep\_icp\_result**: \[\] \| \[[`SweepResult`](#sweepresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L111)

##### sweep\_sns\_result

> **sweep\_sns\_result**: \[\] \| \[[`SweepResult`](#sweepresult)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L113)

***

### GetAutoFinalizationStatusResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L115)

#### Properties

##### auto\_finalize\_swap\_response

> **auto\_finalize\_swap\_response**: \[\] \| \[[`FinalizeSwapResponse`](#finalizeswapresponse)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L116)

##### has\_auto\_finalize\_been\_attempted

> **has\_auto\_finalize\_been\_attempted**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L117)

##### is\_auto\_finalize\_enabled

> **is\_auto\_finalize\_enabled**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L118)

***

### GetBuyerStateRequest

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L120)

#### Properties

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L121)

***

### GetBuyerStateResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L123)

#### Properties

##### buyer\_state

> **buyer\_state**: \[\] \| \[[`BuyerState`](#buyerstate)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L124)

***

### GetBuyersTotalResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L126)

#### Properties

##### buyers\_total

> **buyers\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L127)

***

### GetDerivedStateResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L129)

#### Properties

##### buyer\_total\_icp\_e8s

> **buyer\_total\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L131)

##### cf\_neuron\_count

> **cf\_neuron\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L136)

##### cf\_participant\_count

> **cf\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L132)

##### direct\_participant\_count

> **direct\_participant\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L135)

##### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L134)

##### neurons\_fund\_participation\_icp\_e8s

> **neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L133)

##### sns\_tokens\_per\_icp

> **sns\_tokens\_per\_icp**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L130)

***

### GetInitResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L138)

#### Properties

##### init

> **init**: \[\] \| \[[`Init`](#init-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L139)

***

### GetLifecycleResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L141)

#### Properties

##### decentralization\_sale\_open\_timestamp\_seconds

> **decentralization\_sale\_open\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L142)

##### decentralization\_swap\_termination\_timestamp\_seconds

> **decentralization\_swap\_termination\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L144)

##### lifecycle

> **lifecycle**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L143)

***

### GetOpenTicketResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L146)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L147)

***

### GetSaleParametersResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L149)

#### Properties

##### params

> **params**: \[\] \| \[[`Params`](#params-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L150)

***

### GetStateResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L152)

#### Properties

##### derived

> **derived**: \[\] \| \[[`DerivedState`](#derivedstate)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L154)

##### swap

> **swap**: \[\] \| \[[`Swap`](#swap-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L153)

***

### GetTimersResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L156)

#### Properties

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L157)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L159)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L160)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L161)

***

### Icrc1Account

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L163)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L164)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L165)

***

### IdealMatchedParticipationFunction

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L167)

#### Properties

##### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L168)

***

### Init

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L170)

#### Properties

##### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L181)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `string`[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L178)

##### icp\_ledger\_canister\_id

> **icp\_ledger\_canister\_id**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L188)

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L199)

##### max\_icp\_e8s

> **max\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L179)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L194)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L196)

##### min\_icp\_e8s

> **min\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L198)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L174)

##### min\_participants

> **min\_participants**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L184)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L175)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L180)

##### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L173)

##### neurons\_fund\_participation\_constraints

> **neurons\_fund\_participation\_constraints**: \[\] \| \[[`NeuronsFundParticipationConstraints`](#neuronsfundparticipationconstraints)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L190)

##### nns\_governance\_canister\_id

> **nns\_governance\_canister\_id**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L186)

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L171)

##### restricted\_countries

> **restricted\_countries**: \[\] \| \[[`Countries`](#countries)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L197)

##### should\_auto\_finalize

> **should\_auto\_finalize**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L193)

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L195)

##### sns\_ledger\_canister\_id

> **sns\_ledger\_canister\_id**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L189)

##### sns\_root\_canister\_id

> **sns\_root\_canister\_id**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L172)

##### sns\_token\_e8s

> **sns\_token\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L185)

##### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L183)

##### swap\_start\_timestamp\_seconds

> **swap\_start\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L182)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L187)

***

### InvalidUserAmount

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L201)

#### Properties

##### max\_amount\_icp\_e8s\_included

> **max\_amount\_icp\_e8s\_included**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L203)

##### min\_amount\_icp\_e8s\_included

> **min\_amount\_icp\_e8s\_included**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L202)

***

### LinearScalingCoefficient

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L208)

#### Properties

##### from\_direct\_participation\_icp\_e8s

> **from\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L211)

##### intercept\_icp\_e8s

> **intercept\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L210)

##### slope\_denominator

> **slope\_denominator**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L212)

##### slope\_numerator

> **slope\_numerator**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L209)

##### to\_direct\_participation\_icp\_e8s

> **to\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L213)

***

### ListCommunityFundParticipantsRequest

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L215)

#### Properties

##### limit

> **limit**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L217)

##### offset

> **offset**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L216)

***

### ListCommunityFundParticipantsResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L219)

#### Properties

##### cf\_participants

> **cf\_participants**: [`CfParticipant`](#cfparticipant)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L220)

***

### ListDirectParticipantsRequest

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L222)

#### Properties

##### limit

> **limit**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L224)

##### offset

> **offset**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L223)

***

### ListDirectParticipantsResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L226)

#### Properties

##### participants

> **participants**: [`Participant`](#participant)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L227)

***

### ListSnsNeuronRecipesRequest

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L229)

#### Properties

##### limit

> **limit**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L231)

##### offset

> **offset**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L230)

***

### ListSnsNeuronRecipesResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L233)

#### Properties

##### sns\_neuron\_recipes

> **sns\_neuron\_recipes**: [`SnsNeuronRecipe`](#snsneuronrecipe)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L234)

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L236)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L239)

##### custom\_sections\_size

> **custom\_sections\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L244)

##### global\_memory\_size

> **global\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L243)

##### snapshots\_size

> **snapshots\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L241)

##### stable\_memory\_size

> **stable\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L240)

##### wasm\_binary\_size

> **wasm\_binary\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L237)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L238)

##### wasm\_memory\_size

> **wasm\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L242)

***

### NeuronAttributes

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L246)

#### Properties

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L247)

##### followees

> **followees**: [`NeuronId`](#neuronid)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L249)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L248)

***

### NeuronBasketConstructionParameters

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L251)

#### Properties

##### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L253)

##### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L252)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L255)

#### Properties

##### id

> **id**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L256)

***

### NeuronsFundParticipationConstraints

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L258)

#### Properties

##### coefficient\_intervals

> **coefficient\_intervals**: [`LinearScalingCoefficient`](#linearscalingcoefficient)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L259)

##### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](#idealmatchedparticipationfunction)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L262)

##### max\_neurons\_fund\_participation\_icp\_e8s

> **max\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L260)

##### min\_direct\_participation\_threshold\_icp\_e8s

> **min\_direct\_participation\_threshold\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L261)

***

### NewSaleTicketRequest

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L266)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L268)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L267)

***

### NewSaleTicketResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L270)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_2`](#result_2)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L271)

***

### Ok

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L273)

#### Properties

##### block\_height

> **block\_height**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L274)

***

### Ok\_1

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L276)

#### Properties

##### neurons\_fund\_neurons\_count

> **neurons\_fund\_neurons\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L278)

##### neurons\_fund\_participation\_icp\_e8s

> **neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L277)

***

### Ok\_2

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L280)

#### Properties

##### ticket

> **ticket**: \[\] \| \[[`Ticket`](#ticket-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L281)

***

### Params

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L283)

#### Properties

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L296)

##### max\_icp\_e8s

> **max\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L288)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L293)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L294)

##### min\_icp\_e8s

> **min\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L295)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L284)

##### min\_participants

> **min\_participants**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L290)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L285)

##### sale\_delay\_seconds

> **sale\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L292)

##### sns\_token\_e8s

> **sns\_token\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L291)

##### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L289)

***

### Participant

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L298)

#### Properties

##### participant\_id

> **participant\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L300)

##### participation

> **participation**: \[\] \| \[[`BuyerState`](#buyerstate)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L299)

***

### Principals

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L308)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L309)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L311)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L314)

##### num\_instructions\_total

> **num\_instructions\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L313)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L315)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L312)

***

### RefreshBuyerTokensRequest

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L317)

#### Properties

##### buyer

> **buyer**: `string`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L319)

##### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L318)

***

### RefreshBuyerTokensResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L321)

#### Properties

##### icp\_accepted\_participation\_e8s

> **icp\_accepted\_participation\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L322)

##### icp\_ledger\_account\_balance\_e8s

> **icp\_ledger\_account\_balance\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L323)

***

### Response

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L325)

#### Properties

##### governance\_error

> **governance\_error**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L326)

***

### SetDappControllersCallResult

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L331)

#### Properties

##### possibility

> **possibility**: \[\] \| \[[`Possibility`](#possibility-4)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:332](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L332)

***

### SetDappControllersResponse

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L334)

#### Properties

##### failed\_updates

> **failed\_updates**: [`FailedUpdate`](#failedupdate)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L335)

***

### SetModeCallResult

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L337)

#### Properties

##### possibility

> **possibility**: \[\] \| \[[`Possibility_3`](#possibility_3)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L338)

***

### SettleCommunityFundParticipationResult

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L340)

#### Properties

##### possibility

> **possibility**: \[\] \| \[[`Possibility_1`](#possibility_1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L341)

***

### SettleNeuronsFundParticipationResult

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L343)

#### Properties

##### possibility

> **possibility**: \[\] \| \[[`Possibility_2`](#possibility_2)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L344)

***

### SnsNeuronRecipe

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L346)

#### Properties

##### claimed\_status

> **claimed\_status**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L348)

##### investor

> **investor**: \[\] \| \[[`Investor`](#investor-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L350)

##### neuron\_attributes

> **neuron\_attributes**: \[\] \| \[[`NeuronAttributes`](#neuronattributes)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L349)

##### sns

> **sns**: \[\] \| \[[`TransferableAmount`](#transferableamount)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L347)

***

### Swap

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L352)

#### Properties

##### already\_tried\_to\_auto\_finalize

> **already\_tried\_to\_auto\_finalize**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L361)

##### auto\_finalize\_swap\_response

> **auto\_finalize\_swap\_response**: \[\] \| \[[`FinalizeSwapResponse`](#finalizeswapresponse)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L353)

##### buyers

> **buyers**: \[`string`, [`BuyerState`](#buyerstate)\][]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L368)

##### cf\_participants

> **cf\_participants**: [`CfParticipant`](#cfparticipant)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L359)

##### decentralization\_sale\_open\_timestamp\_seconds

> **decentralization\_sale\_open\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L356)

##### decentralization\_swap\_termination\_timestamp\_seconds

> **decentralization\_swap\_termination\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L367)

##### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L364)

##### finalize\_swap\_in\_progress

> **finalize\_swap\_in\_progress**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L357)

##### init

> **init**: \[\] \| \[[`Init`](#init-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L360)

##### lifecycle

> **lifecycle**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L365)

##### neuron\_recipes

> **neuron\_recipes**: [`SnsNeuronRecipe`](#snsneuronrecipe)[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L354)

##### neurons\_fund\_participation\_icp\_e8s

> **neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L362)

##### next\_ticket\_id

> **next\_ticket\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L355)

##### open\_sns\_token\_swap\_proposal\_id

> **open\_sns\_token\_swap\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L370)

##### params

> **params**: \[\] \| \[[`Params`](#params-1)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L369)

##### purge\_old\_tickets\_last\_completion\_timestamp\_nanoseconds

> **purge\_old\_tickets\_last\_completion\_timestamp\_nanoseconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L363)

##### purge\_old\_tickets\_next\_principal

> **purge\_old\_tickets\_next\_principal**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L366)

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L358)

***

### SweepResult

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L372)

#### Properties

##### failure

> **failure**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L373)

##### global\_failures

> **global\_failures**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L377)

##### invalid

> **invalid**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L375)

##### skipped

> **skipped**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L374)

##### success

> **success**: `number`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L376)

***

### Ticket

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L379)

#### Properties

##### account

> **account**: \[\] \| \[[`Icrc1Account`](#icrc1account)\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L382)

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L383)

##### creation\_time

> **creation\_time**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L380)

##### ticket\_id

> **ticket\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L381)

***

### Timers

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L385)

#### Properties

##### last\_reset\_timestamp\_seconds

> **last\_reset\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L387)

##### last\_spawned\_timestamp\_seconds

> **last\_spawned\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L386)

##### requires\_periodic\_tasks

> **requires\_periodic\_tasks**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L388)

***

### TransferableAmount

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L390)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L393)

##### amount\_transferred\_e8s

> **amount\_transferred\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L394)

##### transfer\_fee\_paid\_e8s

> **transfer\_fee\_paid\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L391)

##### transfer\_start\_timestamp\_seconds

> **transfer\_start\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L392)

##### transfer\_success\_timestamp\_seconds

> **transfer\_success\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L395)

## Type Aliases

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L31)

***

### Investor

> **Investor** = \{ `CommunityFund`: [`CfInvestment`](#cfinvestment); \} \| \{ `Direct`: [`DirectInvestment`](#directinvestment); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L205)

***

### Possibility

> **Possibility** = \{ `Ok`: [`SetDappControllersResponse`](#setdappcontrollersresponse); \} \| \{ `Err`: [`CanisterCallError`](#canistercallerror); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:302](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L302)

***

### Possibility\_1

> **Possibility\_1** = \{ `Ok`: [`Response`](#response); \} \| \{ `Err`: [`CanisterCallError`](#canistercallerror); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L305)

***

### Possibility\_2

> **Possibility\_2** = \{ `Ok`: [`Ok_1`](#ok_1); \} \| \{ `Err`: [`Error`](#error); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L306)

***

### Possibility\_3

> **Possibility\_3** = \{ `Ok`: \{ \}; \} \| \{ `Err`: [`CanisterCallError`](#canistercallerror); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L307)

***

### Result

> **Result** = \{ `Ok`: [`Ok`](#ok); \} \| \{ `Err`: [`Err`](#err); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L328)

***

### Result\_1

> **Result\_1** = \{ `Ok`: [`Ok_2`](#ok_2); \} \| \{ `Err`: [`Err_1`](#err_1); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L329)

***

### Result\_2

> **Result\_2** = \{ `Ok`: [`Ok_2`](#ok_2); \} \| \{ `Err`: [`Err_2`](#err_2); \}

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L330)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L437)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/sns/swap.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/sns/swap.d.ts#L438)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
