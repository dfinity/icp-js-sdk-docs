---
title: IcpLedgerDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:563](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L563)

#### Properties

##### account\_balance

> **account\_balance**: `ActorMethod`\<\[[`AccountBalanceArgs`](#accountbalanceargs)\], [`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:567](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L567)

Returns the amount of Tokens on the specified account.

##### account\_balance\_dfx

> **account\_balance\_dfx**: `ActorMethod`\<\[[`AccountBalanceArgsDfx`](#accountbalanceargsdfx)\], [`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L568)

##### account\_identifier

> **account\_identifier**: `ActorMethod`\<\[[`Account`](#account)\], [`AccountIdentifier`](#accountidentifier)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L572)

Returns the account identifier for the given Principal and subaccount.

##### archives

> **archives**: `ActorMethod`\<\[\], [`Archives`](#archives-1)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L576)

Returns the existing archive canisters information.

##### decimals

> **decimals**: `ActorMethod`\<\[\], \{ `decimals`: `number`; \}\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L580)

Returns token decimals.

##### get\_allowances

> **get\_allowances**: `ActorMethod`\<\[[`GetAllowancesArgs`](#getallowancesargs)\], [`Allowances`](#allowances)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L581)

##### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:586](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L586)

##### icrc1\_decimals

> **icrc1\_decimals**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:587](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L587)

##### icrc1\_fee

> **icrc1\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:588](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L588)

##### icrc1\_metadata

> **icrc1\_metadata**: `ActorMethod`\<\[\], \[`string`, [`Value`](#value)\][]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:589](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L589)

##### icrc1\_minting\_account

> **icrc1\_minting\_account**: `ActorMethod`\<\[\], \[\] \| \[[`Account`](#account)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:590](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L590)

##### icrc1\_name

> **icrc1\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:595](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L595)

The following methods implement the ICRC-1 Token Standard.
https://github.com/dfinity/ICRC-1/tree/main/standards/ICRC-1

##### icrc1\_supported\_standards

> **icrc1\_supported\_standards**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L596)

##### icrc1\_symbol

> **icrc1\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:600](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L600)

##### icrc1\_total\_supply

> **icrc1\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L601)

##### icrc1\_transfer

> **icrc1\_transfer**: `ActorMethod`\<\[[`TransferArg`](#transferarg)\], [`Icrc1TransferResult`](#icrc1transferresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:602](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L602)

##### icrc10\_supported\_standards

> **icrc10\_supported\_standards**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:582](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L582)

##### icrc2\_allowance

> **icrc2\_allowance**: `ActorMethod`\<\[[`AllowanceArgs`](#allowanceargs)\], [`Allowance`](#allowance)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:607](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L607)

##### icrc2\_approve

> **icrc2\_approve**: `ActorMethod`\<\[[`ApproveArgs`](#approveargs)\], [`ApproveResult`](#approveresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:608](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L608)

##### icrc2\_transfer\_from

> **icrc2\_transfer\_from**: `ActorMethod`\<\[[`TransferFromArgs`](#transferfromargs)\], [`TransferFromResult`](#transferfromresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:609](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L609)

##### icrc21\_canister\_call\_consent\_message

> **icrc21\_canister\_call\_consent\_message**: `ActorMethod`\<\[[`icrc21_consent_message_request`](#icrc21_consent_message_request)\], [`icrc21_consent_message_response`](#icrc21_consent_message_response)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:603](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L603)

##### is\_ledger\_ready

> **is\_ledger\_ready**: `ActorMethod`\<\[\], `boolean`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L610)

##### name

> **name**: `ActorMethod`\<\[\], \{ `name`: `string`; \}\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:614](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L614)

Returns token name.

##### query\_blocks

> **query\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`QueryBlocksResponse`](#queryblocksresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L618)

Queries blocks in the specified range.

##### query\_encoded\_blocks

> **query\_encoded\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`QueryEncodedBlocksResponse`](#queryencodedblocksresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L622)

Queries encoded blocks in the specified range

##### remove\_approval

> **remove\_approval**: `ActorMethod`\<\[[`RemoveApprovalArgs`](#removeapprovalargs)\], [`ApproveResult`](#approveresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L626)

##### send\_dfx

> **send\_dfx**: `ActorMethod`\<\[[`SendArgs`](#sendargs)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L627)

##### symbol

> **symbol**: `ActorMethod`\<\[\], \{ `symbol`: `string`; \}\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L631)

Returns token symbol.

##### tip\_of\_chain

> **tip\_of\_chain**: `ActorMethod`\<\[\], [`TipOfChainRes`](#tipofchainres)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L632)

##### transfer

> **transfer**: `ActorMethod`\<\[[`TransferArgs`](#transferargs)\], [`TransferResult`](#transferresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L638)

Transfers tokens from a subaccount of the caller to the destination address.
The source address is computed from the principal of the caller and the specified subaccount.
When successful, returns the index of the block containing the transaction.

##### transfer\_fee

> **transfer\_fee**: `ActorMethod`\<\[[`TransferFeeArg`](#transferfeearg)\], [`TransferFee`](#transferfee)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L642)

Returns the current transfer_fee.

***

### Account

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L15)

***

### AccountBalanceArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L20)

Arguments for the `account_balance` call.

#### Properties

##### account

> **account**: [`AccountIdentifier`](#accountidentifier)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L21)

***

### AccountBalanceArgsDfx

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L23)

#### Properties

##### account

> **account**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L24)

***

### Allowance

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L31)

#### Properties

##### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L32)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L33)

***

### AllowanceArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L35)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L36)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L37)

***

### ApproveArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L48)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L53)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L52)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L54)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L55)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L49)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L51)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L50)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L56)

***

### Archive

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L71)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L72)

***

### ArchivedBlocksRange

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L84)

#### Properties

##### callback

> **callback**: \[`Principal`, `string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L90)

The function that should be called to fetch the archived blocks.
The range of the blocks accessible using this function is given by [from]
and [len] fields above.

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L98)

The number of blocks that can be fetch using the callback.

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L94)

The index of the first archived block that can be fetched using the callback.

***

### ArchivedEncodedBlocksRange

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L100)

#### Properties

##### callback

> **callback**: \[`Principal`, `string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L101)

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L103)

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L102)

***

### ArchiveOptions

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L74)

#### Properties

##### controller\_id

> **controller\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L82)

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L80)

##### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L79)

##### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L76)

##### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L78)

##### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L81)

##### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L75)

##### trigger\_threshold

> **trigger\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L77)

***

### Archives

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L105)

#### Properties

##### archives

> **archives**: [`Archive`](#archive)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L106)

***

### Block

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L108)

#### Properties

##### parent\_hash

> **parent\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L111)

##### timestamp

> **timestamp**: [`TimeStamp`](#timestamp-1)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L110)

##### transaction

> **transaction**: [`Transaction`](#transaction-1)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L109)

***

### BlockRange

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L120)

A prefix of the block range specified in the [GetBlocksArgs] request.

#### Properties

##### blocks

> **blocks**: [`Block`](#block)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L136)

A prefix of the requested block range.
The index of the first block is equal to [GetBlocksArgs.from].

Note that the number of blocks might be less than the requested
[GetBlocksArgs.len] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the full block range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of blocks can be empty if:
1. [GetBlocksArgs.len] was zero.
2. [GetBlocksArgs.from] was larger than the last block known to the canister.

***

### ChangeArchiveOptions

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L138)

#### Properties

##### controller\_id

> **controller\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L146)

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L144)

##### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L143)

##### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L140)

##### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L142)

##### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L145)

##### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L139)

##### trigger\_threshold

> **trigger\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L141)

***

### Duration

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L148)

#### Properties

##### nanos

> **nanos**: `number`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L150)

##### secs

> **secs**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L149)

***

### FeatureFlags

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L152)

#### Properties

##### icrc2

> **icrc2**: `boolean`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L153)

***

### FieldsDisplay

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L155)

#### Properties

##### fields

> **fields**: \[`string`, [`Icrc21Value`](#icrc21value)\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L156)

##### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L157)

***

### GetAllowancesArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L165)

The arguments for the `get_allowances` endpoint.
The `prev_spender_id` argument can be used for pagination. If specified
the endpoint returns allowances that are lexicographically greater than
(`from_account_id`, `prev_spender_id`) - start with spender after `prev_spender_id`.

#### Properties

##### from\_account\_id

> **from\_account\_id**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L167)

##### prev\_spender\_id

> **prev\_spender\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L166)

##### take

> **take**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L168)

***

### GetBlocksArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L170)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L178)

Max number of blocks to fetch.

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L174)

The index of the first block to fetch.

***

### icrc21\_consent\_info

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L525)

#### Properties

##### consent\_message

> **consent\_message**: [`icrc21_consent_message`](#icrc21_consent_message)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L527)

##### metadata

> **metadata**: [`icrc21_consent_message_metadata`](#icrc21_consent_message_metadata)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L526)

***

### icrc21\_consent\_message\_metadata

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L534)

#### Properties

##### language

> **language**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L536)

##### utc\_offset\_minutes

> **utc\_offset\_minutes**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L535)

***

### icrc21\_consent\_message\_request

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L538)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L539)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L540)

##### user\_preferences

> **user\_preferences**: [`icrc21_consent_message_spec`](#icrc21_consent_message_spec)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L541)

***

### icrc21\_consent\_message\_spec

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L546)

#### Properties

##### device\_spec

> **device\_spec**: \[\] \| \[\{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:548](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L548)

##### metadata

> **metadata**: [`icrc21_consent_message_metadata`](#icrc21_consent_message_metadata)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L547)

***

### icrc21\_error\_info

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L560)

#### Properties

##### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L561)

***

### InitArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L211)

#### Properties

##### archive\_options

> **archive\_options**: \[\] \| \[[`ArchiveOptions`](#archiveoptions)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L219)

##### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](#featureflags)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L222)

##### icrc1\_minting\_account

> **icrc1\_minting\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L218)

##### initial\_values

> **initial\_values**: \[`string`, [`Tokens`](#tokens)\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L220)

##### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L217)

##### minting\_account

> **minting\_account**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L215)

##### send\_whitelist

> **send\_whitelist**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L212)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L221)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L213)

##### transaction\_window

> **transaction\_window**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L216)

##### transfer\_fee

> **transfer\_fee**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L214)

***

### QueryBlocksResponse

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L311)

The result of a "query_blocks" call.

The structure of the result is somewhat complicated because the main ledger canister might
not have all the blocks that the caller requested: One or more "archive" canisters might
store some of the requested blocks.

Note: as of Q4 2021 when this interface is authored, the IC doesn't support making nested
query calls within a query call.

#### Properties

##### archived\_blocks

> **archived\_blocks**: [`ArchivedBlocksRange`](#archivedblocksrange)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L344)

Encoding of instructions for fetching archived blocks whose indices fall into the
requested range.

For each entry `e` in [archived_blocks], `[e.from, e.from + len)` is a sub-range
of the originally requested block range.

##### blocks

> **blocks**: [`Block`](#block)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L326)

List of blocks that were available in the ledger when it processed the call.

The blocks form a contiguous range, with the first block having index
[first_block_index] (see below), and the last block having index
[first_block_index] + len(blocks) - 1.

The block range can be an arbitrary sub-range of the originally requested range.

##### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L316)

System certificate for the hash of the latest block in the chain.
Only present if `query_blocks` is called in a non-replicated query context.

##### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L331)

The total number of blocks in the chain.
If the chain length is positive, the index of the last block is `chain_len - 1`.

##### first\_block\_index

> **first\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L336)

The index of the first block in "blocks".
If the blocks vector is empty, the exact value of this field is not specified.

***

### QueryEncodedBlocksResponse

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L346)

#### Properties

##### archived\_blocks

> **archived\_blocks**: [`ArchivedEncodedBlocksRange`](#archivedencodedblocksrange)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L351)

##### blocks

> **blocks**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L348)

##### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L347)

##### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L349)

##### first\_block\_index

> **first\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L350)

***

### RemoveApprovalArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L353)

#### Properties

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L354)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L355)

##### spender

> **spender**: [`AccountIdentifier`](#accountidentifier)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L356)

***

### SendArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L361)

Arguments for the `send_dfx` call.

#### Properties

##### amount

> **amount**: [`Tokens`](#tokens)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L367)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[[`TimeStamp`](#timestamp-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L366)

##### fee

> **fee**: [`Tokens`](#tokens)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L363)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L365)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L364)

##### to

> **to**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L362)

***

### TimeStamp

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L382)

Number of nanoseconds from the UNIX epoch in UTC timezone.

#### Properties

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L383)

***

### TipOfChainRes

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L385)

#### Properties

##### certification

> **certification**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L386)

##### tip\_index

> **tip\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L387)

***

### Tokens

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L392)

Amount of tokens, measured in 10^-8 of a token.

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L393)

***

### Transaction

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L395)

#### Properties

##### created\_at\_time

> **created\_at\_time**: [`TimeStamp`](#timestamp-1)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L399)

##### icrc1\_memo

> **icrc1\_memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L397)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L396)

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L398)

***

### TransferArg

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L401)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L407)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L406)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L403)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L405)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L404)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L402)

***

### TransferArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L412)

Arguments for the `transfer` call.

#### Properties

##### amount

> **amount**: [`Tokens`](#tokens)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L442)

The amount that the caller wants to transfer to the destination address.

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[[`TimeStamp`](#timestamp-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L438)

The point in time when the caller created this request.
If null, the ledger uses current IC time as the timestamp.

##### fee

> **fee**: [`Tokens`](#tokens)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L422)

The amount that the caller pays for the transaction.
Must be 10000 e8s.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L433)

The subaccount from which the caller wants to transfer funds.
If null, the ledger uses the default (all zeros) subaccount to compute the source address.
See comments for the `SubAccount` type.

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L427)

Transaction memo.
See comments for the `Memo` type.

##### to

> **to**: [`AccountIdentifier`](#accountidentifier)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L417)

The destination account.
If the transfer is successful, the balance of this address increases by `amount`.

***

### TransferFee

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L480)

#### Properties

##### transfer\_fee

> **transfer\_fee**: [`Tokens`](#tokens)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L484)

The fee to pay to perform a transfer

***

### TransferFromArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L487)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L494)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L493)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L489)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L491)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L492)

##### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L490)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L488)

***

### UpgradeArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L512)

#### Properties

##### change\_archive\_options

> **change\_archive\_options**: \[\] \| \[[`ChangeArchiveOptions`](#changearchiveoptions)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L513)

##### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](#featureflags)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L515)

##### icrc1\_minting\_account

> **icrc1\_minting\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L514)

## Type Aliases

### AccountIdentifier

> **AccountIdentifier** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L30)

AccountIdentifier is a 32-byte array.
The first 4 bytes is big-endian encoding of a CRC32 checksum of the last 28 bytes.

***

### Allowances

> **Allowances** = `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L42)

The allowances returned by the `get_allowances` endpoint.

#### Type Declaration

##### allowance

> **allowance**: [`Tokens`](#tokens)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

##### from\_account\_id

> **from\_account\_id**: [`TextAccountIdentifier`](#textaccountidentifier)

##### to\_spender\_id

> **to\_spender\_id**: [`TextAccountIdentifier`](#textaccountidentifier)

***

### ApproveError

> **ApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`Icrc1BlockIndex`](#icrc1blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Icrc1Tokens`](#icrc1tokens); \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: [`Icrc1Tokens`](#icrc1tokens); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Icrc1Tokens`](#icrc1tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L58)

***

### ApproveResult

> **ApproveResult** = \{ `Ok`: [`Icrc1BlockIndex`](#icrc1blockindex); \} \| \{ `Err`: [`ApproveError`](#approveerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L70)

***

### BlockIndex

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L116)

Sequence number of a block produced by the ledger.

***

### Icrc1BlockIndex

> **Icrc1BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L180)

***

### Icrc1Timestamp

> **Icrc1Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L184)

Number of nanoseconds since the UNIX epoch in UTC timezone.

***

### Icrc1Tokens

> **Icrc1Tokens** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L185)

***

### Icrc1TransferError

> **Icrc1TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Icrc1Tokens`](#icrc1tokens); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`Icrc1BlockIndex`](#icrc1blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Icrc1Tokens`](#icrc1tokens); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Icrc1Tokens`](#icrc1tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L186)

***

### Icrc1TransferResult

> **Icrc1TransferResult** = \{ `Ok`: [`Icrc1BlockIndex`](#icrc1blockindex); \} \| \{ `Err`: [`Icrc1TransferError`](#icrc1transfererror); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L197)

***

### icrc21\_consent\_message

> **icrc21\_consent\_message** = \{ `FieldsDisplayMessage`: [`FieldsDisplay`](#fieldsdisplay); \} \| \{ `GenericDisplayMessage`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L529)

***

### icrc21\_consent\_message\_response

> **icrc21\_consent\_message\_response** = \{ `Ok`: [`icrc21_consent_info`](#icrc21_consent_info); \} \| \{ `Err`: [`icrc21_error`](#icrc21_error); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L543)

***

### icrc21\_error

> **icrc21\_error** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `InsufficientPayment`: [`icrc21_error_info`](#icrc21_error_info); \} \| \{ `UnsupportedCanisterCall`: [`icrc21_error_info`](#icrc21_error_info); \} \| \{ `ConsentMessageUnavailable`: [`icrc21_error_info`](#icrc21_error_info); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L550)

#### Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

##### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

###### GenericError.description

> **description**: `string`

###### GenericError.error\_code

> **error\_code**: `bigint`

\{ `InsufficientPayment`: [`icrc21_error_info`](#icrc21_error_info); \}

##### InsufficientPayment

> **InsufficientPayment**: [`icrc21_error_info`](#icrc21_error_info)

\{ `UnsupportedCanisterCall`: [`icrc21_error_info`](#icrc21_error_info); \}

##### UnsupportedCanisterCall

> **UnsupportedCanisterCall**: [`icrc21_error_info`](#icrc21_error_info)

\{ `ConsentMessageUnavailable`: [`icrc21_error_info`](#icrc21_error_info); \}

##### ConsentMessageUnavailable

> **ConsentMessageUnavailable**: [`icrc21_error_info`](#icrc21_error_info)

***

### Icrc21Value

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L200)

***

### LedgerCanisterPayload

> **LedgerCanisterPayload** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](#upgradeargs)\]; \} \| \{ `Init`: [`InitArgs`](#initargs); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L224)

***

### Memo

> **Memo** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L231)

An arbitrary number associated with a transaction.
The caller can set it in a `transfer` call as a correlation identifier.

***

### Operation

> **Operation** = \{ `Approve`: \{ `allowance`: [`Tokens`](#tokens); `allowance_e8s`: `bigint`; `expected_allowance`: \[\] \| \[[`Tokens`](#tokens)\]; `expires_at`: \[\] \| \[[`TimeStamp`](#timestamp-1)\]; `fee`: [`Tokens`](#tokens); `from`: [`AccountIdentifier`](#accountidentifier); `spender`: [`AccountIdentifier`](#accountidentifier); \}; \} \| \{ `Burn`: \{ `amount`: [`Tokens`](#tokens); `from`: [`AccountIdentifier`](#accountidentifier); `spender`: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]; \}; \} \| \{ `Mint`: \{ `amount`: [`Tokens`](#tokens); `to`: [`AccountIdentifier`](#accountidentifier); \}; \} \| \{ `Transfer`: \{ `amount`: [`Tokens`](#tokens); `fee`: [`Tokens`](#tokens); `from`: [`AccountIdentifier`](#accountidentifier); `spender`: \[\] \| \[`Uint8Array`\]; `to`: [`AccountIdentifier`](#accountidentifier); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L232)

***

### QueryArchiveError

> **QueryArchiveError** = \{ `BadFirstBlockIndex`: \{ `first_valid_index`: [`BlockIndex`](#blockindex); `requested_index`: [`BlockIndex`](#blockindex); \}; \} \| \{ `Other`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L267)

An error indicating that the arguments passed to [QueryArchiveFn] were invalid.

#### Type Declaration

\{ `BadFirstBlockIndex`: \{ `first_valid_index`: [`BlockIndex`](#blockindex); `requested_index`: [`BlockIndex`](#blockindex); \}; \}

##### BadFirstBlockIndex

> **BadFirstBlockIndex**: `object`

[GetBlocksArgs.from] argument was smaller than the first block
served by the canister that received the request.

###### BadFirstBlockIndex.first\_valid\_index

> **first\_valid\_index**: [`BlockIndex`](#blockindex)

###### BadFirstBlockIndex.requested\_index

> **requested\_index**: [`BlockIndex`](#blockindex)

\{ `Other`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### Other

> **Other**: `object`

Reserved for future use.

###### Other.error\_code

> **error\_code**: `bigint`

###### Other.error\_message

> **error\_message**: `string`

***

### QueryArchiveFn

> **QueryArchiveFn** = `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`QueryArchiveResult`](#queryarchiveresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L287)

A function that is used for fetching archived ledger blocks.

***

### QueryArchiveResult

> **QueryArchiveResult** = \{ `Ok`: [`BlockRange`](#blockrange); \} \| \{ `Err`: [`QueryArchiveError`](#queryarchiveerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L288)

#### Type Declaration

\{ `Ok`: [`BlockRange`](#blockrange); \}

##### Ok

> **Ok**: [`BlockRange`](#blockrange)

Successfully fetched zero or more blocks.

\{ `Err`: [`QueryArchiveError`](#queryarchiveerror); \}

##### Err

> **Err**: [`QueryArchiveError`](#queryarchiveerror)

The [GetBlocksArgs] request was invalid.

***

### SubAccount

> **SubAccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L374)

Subaccount is an arbitrary 32-byte byte array.
Ledger uses subaccounts to compute the source address, which enables one
principal to control multiple ledger accounts.

***

### TextAccountIdentifier

> **TextAccountIdentifier** = `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L378)

Account identifier encoded as a 64-byte ASCII hex string.

***

### TransferError

> **TransferError** = \{ `TxTooOld`: \{ `allowed_window_nanos`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Tokens`](#tokens); \}; \} \| \{ `TxDuplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `TxCreatedInFuture`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Tokens`](#tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L444)

#### Type Declaration

\{ `TxTooOld`: \{ `allowed_window_nanos`: `bigint`; \}; \}

##### TxTooOld

> **TxTooOld**: `object`

The request is too old.
The ledger only accepts requests created within 24 hours window.
This is a non-recoverable error.

###### TxTooOld.allowed\_window\_nanos

> **allowed\_window\_nanos**: `bigint`

\{ `BadFee`: \{ `expected_fee`: [`Tokens`](#tokens); \}; \}

##### BadFee

> **BadFee**: `object`

The fee that the caller specified in the transfer request was not the one that ledger expects.
The caller can change the transfer fee to the `expected_fee` and retry the request.

###### BadFee.expected\_fee

> **expected\_fee**: [`Tokens`](#tokens)

\{ `TxDuplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \}

##### TxDuplicate

> **TxDuplicate**: `object`

The ledger has already executed the request.
`duplicate_of` field is equal to the index of the block containing the original transaction.

###### TxDuplicate.duplicate\_of

> **duplicate\_of**: [`BlockIndex`](#blockindex)

\{ `TxCreatedInFuture`: `null`; \}

##### TxCreatedInFuture

> **TxCreatedInFuture**: `null`

The caller specified `created_at_time` that is too far in future.
The caller can retry the request later.

\{ `InsufficientFunds`: \{ `balance`: [`Tokens`](#tokens); \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The account specified by the caller doesn't have enough funds.

###### InsufficientFunds.balance

> **balance**: [`Tokens`](#tokens)

***

### TransferFeeArg

> **TransferFeeArg** = `object`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L486)

***

### TransferFromError

> **TransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: [`Icrc1Tokens`](#icrc1tokens); \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Icrc1Tokens`](#icrc1tokens); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`Icrc1BlockIndex`](#icrc1blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Icrc1Tokens`](#icrc1tokens); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Icrc1Timestamp`](#icrc1timestamp); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Icrc1Tokens`](#icrc1tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L496)

***

### TransferFromResult

> **TransferFromResult** = \{ `Ok`: [`Icrc1BlockIndex`](#icrc1blockindex); \} \| \{ `Err`: [`TransferFromError`](#transferfromerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L508)

***

### TransferResult

> **TransferResult** = \{ `Ok`: [`BlockIndex`](#blockindex); \} \| \{ `Err`: [`TransferError`](#transfererror); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L511)

***

### Value

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L520)

The value returned from the [icrc1_metadata] endpoint.

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L644)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L645)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
