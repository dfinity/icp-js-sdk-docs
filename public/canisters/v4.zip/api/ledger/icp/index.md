---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [IcpIndexDid](namespaces/IcpIndexDid.md)
- [IcpLedgerDid](namespaces/IcpLedgerDid.md)

## Classes

### AccountIdentifier

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L23)

A 32-byte account identifier used to send and receive ICP tokens.

The ICP Ledger uses the concept of an `AccountIdentifier` to represent accounts.
It’s a unique value derived from a principal (the identity controlling the account)
and a subaccount. This design allows a single principal to control multiple accounts
by using different subaccounts.

#### See

 - https://internetcomputer.org/docs/references/ledger#_accounts
 - https://internetcomputer.org/docs/defi/token-ledgers/setup/icp_ledger_setup
 - https://internetcomputer.org/docs/references/ledger#_operations_transactions_blocks_transaction_ledger

#### Methods

##### toAccountIdentifierHash()

> **toAccountIdentifierHash**(): `object`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:127](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L127)

Returns the raw bytes wrapped in an object under the `hash` key.

###### Returns

`object`

`{ hash: Uint8Array }` where `hash` is the raw 32-byte `Uint8Array`.

###### hash

> **hash**: `Uint8Array`

##### toHex()

> **toHex**(): `string`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L100)

Returns the ICP Ledger Account Identifier as a 64-character hexadecimal string.
This is the format typically used to display the account identifier in a human-readable way.

###### Returns

`string`

Hex representation (64-character string).

##### toNumbers()

> **toNumbers**(): `number`[]

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:118](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L118)

Returns the account identifier as an array of numbers.

###### Returns

`number`[]

An array of byte values.

##### toUint8Array()

> **toUint8Array**(): `Uint8Array`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L109)

Returns the raw 32-byte `Uint8Array` of the account identifier.

###### Returns

`Uint8Array`

The raw bytes of the account identifier.

##### fromHex()

> `static` **fromHex**(`hex`): [`AccountIdentifier`](#accountidentifier)

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L34)

Creates an `AccountIdentifier` object from a hexadecimal string (e.g. d3e13d4777e22367532053190b6c6ccf57444a61337e996242b1abfb52cf92c8).
Validates the checksum in the process.

###### Parameters

###### hex

`string`

The 64-character hexadecimal representation of the account identifier.

###### Returns

[`AccountIdentifier`](#accountidentifier)

An instance of `AccountIdentifier`.

###### Throws

If the length is not 32 bytes or if the checksum is invalid.

##### fromPrincipal()

> `static` **fromPrincipal**(`__namedParameters`): [`AccountIdentifier`](#accountidentifier)

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:68](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L68)

Creates an `AccountIdentifier` object from a principal and optional subaccount.

When no subaccount is provided, a 32-byte array of zeros is used by default.
You can use any arbitrary 32 bytes as a subaccount identifier to derive a distinct account identifier
for the same principal.

###### Parameters

###### \_\_namedParameters

###### principal

`Principal`

###### subAccount?

[`SubAccount`](#subaccount) = `...`

###### Returns

[`AccountIdentifier`](#accountidentifier)

An instance of `AccountIdentifier`.

***

### AllowanceChangedError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L57)

#### Extends

- [`ApproveError`](#approveerror)

#### Constructors

##### Constructor

> **new AllowanceChangedError**(`currentAllowance`): [`AllowanceChangedError`](#allowancechangederror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:58](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L58)

###### Parameters

###### currentAllowance

`bigint`

###### Returns

[`AllowanceChangedError`](#allowancechangederror)

###### Overrides

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ApproveError`](#approveerror).[`cause`](#cause-1)

##### currentAllowance

> `readonly` **currentAllowance**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:58](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L58)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ApproveError`](#approveerror).[`message`](#message-1)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ApproveError`](#approveerror).[`name`](#name-1)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ApproveError`](#approveerror).[`stack`](#stack-1)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ApproveError`](#approveerror).[`stackTraceLimit`](#stacktracelimit-1)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ApproveError`](#approveerror).[`captureStackTrace`](#capturestacktrace-2)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ApproveError`](#approveerror).[`isError`](#iserror-2)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ApproveError`](#approveerror).[`prepareStackTrace`](#preparestacktrace-2)

***

### ApproveError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:7](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L7)

#### Extends

- [`IcrcError`](#icrcerror)

#### Extended by

- [`GenericError`](#genericerror)
- [`TemporarilyUnavailableError`](#temporarilyunavailableerror)
- [`DuplicateError`](#duplicateerror)
- [`AllowanceChangedError`](#allowancechangederror)
- [`CreatedInFutureError`](#createdinfutureerror)
- [`TooOldError`](#tooolderror)
- [`ExpiredError`](#expirederror)

#### Constructors

##### Constructor

> **new ApproveError**(`message?`): [`ApproveError`](#approveerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ApproveError`](#approveerror)

###### Inherited from

[`IcrcError`](#icrcerror).[`constructor`](#constructor-11)

##### Constructor

> **new ApproveError**(`message?`, `options?`): [`ApproveError`](#approveerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ApproveError`](#approveerror)

###### Inherited from

[`IcrcError`](#icrcerror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`IcrcError`](#icrcerror).[`cause`](#cause-9)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`IcrcError`](#icrcerror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`IcrcError`](#icrcerror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`IcrcError`](#icrcerror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`IcrcError`](#icrcerror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`IcrcError`](#icrcerror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`IcrcError`](#icrcerror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`IcrcError`](#icrcerror).[`prepareStackTrace`](#preparestacktrace-18)

***

### BadFeeError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L34)

#### Extends

- [`IcrcError`](#icrcerror)

#### Constructors

##### Constructor

> **new BadFeeError**(`expectedFee`): [`BadFeeError`](#badfeeerror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L35)

###### Parameters

###### expectedFee

`bigint`

###### Returns

[`BadFeeError`](#badfeeerror)

###### Overrides

[`IcrcError`](#icrcerror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`IcrcError`](#icrcerror).[`cause`](#cause-9)

##### expectedFee

> `readonly` **expectedFee**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L35)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`IcrcError`](#icrcerror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`IcrcError`](#icrcerror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`IcrcError`](#icrcerror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`IcrcError`](#icrcerror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`IcrcError`](#icrcerror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`IcrcError`](#icrcerror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`IcrcError`](#icrcerror).[`prepareStackTrace`](#preparestacktrace-18)

***

### ConsentMessageError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L8)

#### Extends

- [`IcrcError`](#icrcerror)

#### Extended by

- [`InsufficientPaymentError`](#insufficientpaymenterror)
- [`UnsupportedCanisterCallError`](#unsupportedcanistercallerror)
- [`ConsentMessageUnavailableError`](#consentmessageunavailableerror)

#### Constructors

##### Constructor

> **new ConsentMessageError**(`message?`): [`ConsentMessageError`](#consentmessageerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ConsentMessageError`](#consentmessageerror)

###### Inherited from

[`IcrcError`](#icrcerror).[`constructor`](#constructor-11)

##### Constructor

> **new ConsentMessageError**(`message?`, `options?`): [`ConsentMessageError`](#consentmessageerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ConsentMessageError`](#consentmessageerror)

###### Inherited from

[`IcrcError`](#icrcerror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`IcrcError`](#icrcerror).[`cause`](#cause-9)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`IcrcError`](#icrcerror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`IcrcError`](#icrcerror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`IcrcError`](#icrcerror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`IcrcError`](#icrcerror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`IcrcError`](#icrcerror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`IcrcError`](#icrcerror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`IcrcError`](#icrcerror).[`prepareStackTrace`](#preparestacktrace-18)

***

### ConsentMessageUnavailableError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:74](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L74)

#### Extends

- [`ConsentMessageError`](#consentmessageerror)

#### Constructors

##### Constructor

> **new ConsentMessageUnavailableError**(`message?`): [`ConsentMessageUnavailableError`](#consentmessageunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ConsentMessageUnavailableError`](#consentmessageunavailableerror)

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`constructor`](#constructor-3)

##### Constructor

> **new ConsentMessageUnavailableError**(`message?`, `options?`): [`ConsentMessageUnavailableError`](#consentmessageunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ConsentMessageUnavailableError`](#consentmessageunavailableerror)

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`constructor`](#constructor-3)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`cause`](#cause-3)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`message`](#message-3)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`name`](#name-3)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`stack`](#stack-3)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`stackTraceLimit`](#stacktracelimit-3)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`captureStackTrace`](#capturestacktrace-6)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`isError`](#iserror-6)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`prepareStackTrace`](#preparestacktrace-6)

***

### CreatedInFutureError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:63](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L63)

#### Extends

- [`ApproveError`](#approveerror)

#### Constructors

##### Constructor

> **new CreatedInFutureError**(`message?`): [`CreatedInFutureError`](#createdinfutureerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`CreatedInFutureError`](#createdinfutureerror)

###### Inherited from

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

##### Constructor

> **new CreatedInFutureError**(`message?`, `options?`): [`CreatedInFutureError`](#createdinfutureerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`CreatedInFutureError`](#createdinfutureerror)

###### Inherited from

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ApproveError`](#approveerror).[`cause`](#cause-1)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ApproveError`](#approveerror).[`message`](#message-1)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ApproveError`](#approveerror).[`name`](#name-1)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ApproveError`](#approveerror).[`stack`](#stack-1)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ApproveError`](#approveerror).[`stackTraceLimit`](#stacktracelimit-1)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ApproveError`](#approveerror).[`captureStackTrace`](#capturestacktrace-2)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ApproveError`](#approveerror).[`isError`](#iserror-2)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ApproveError`](#approveerror).[`prepareStackTrace`](#preparestacktrace-2)

***

### DuplicateError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:51](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L51)

#### Extends

- [`ApproveError`](#approveerror)

#### Constructors

##### Constructor

> **new DuplicateError**(`duplicateOf`): [`DuplicateError`](#duplicateerror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:52](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L52)

###### Parameters

###### duplicateOf

`bigint`

###### Returns

[`DuplicateError`](#duplicateerror)

###### Overrides

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ApproveError`](#approveerror).[`cause`](#cause-1)

##### duplicateOf

> `readonly` **duplicateOf**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:52](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L52)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ApproveError`](#approveerror).[`message`](#message-1)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ApproveError`](#approveerror).[`name`](#name-1)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ApproveError`](#approveerror).[`stack`](#stack-1)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ApproveError`](#approveerror).[`stackTraceLimit`](#stacktracelimit-1)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ApproveError`](#approveerror).[`captureStackTrace`](#capturestacktrace-2)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ApproveError`](#approveerror).[`isError`](#iserror-2)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ApproveError`](#approveerror).[`prepareStackTrace`](#preparestacktrace-2)

***

### ExpiredError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:66](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L66)

#### Extends

- [`ApproveError`](#approveerror)

#### Constructors

##### Constructor

> **new ExpiredError**(`ledgerTime`): [`ExpiredError`](#expirederror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L67)

###### Parameters

###### ledgerTime

`bigint`

###### Returns

[`ExpiredError`](#expirederror)

###### Overrides

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ApproveError`](#approveerror).[`cause`](#cause-1)

##### ledgerTime

> `readonly` **ledgerTime**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L67)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ApproveError`](#approveerror).[`message`](#message-1)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ApproveError`](#approveerror).[`name`](#name-1)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ApproveError`](#approveerror).[`stack`](#stack-1)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ApproveError`](#approveerror).[`stackTraceLimit`](#stacktracelimit-1)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ApproveError`](#approveerror).[`captureStackTrace`](#capturestacktrace-2)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ApproveError`](#approveerror).[`isError`](#iserror-2)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ApproveError`](#approveerror).[`prepareStackTrace`](#preparestacktrace-2)

***

### GenericError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:40](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L40)

#### Extends

- [`ApproveError`](#approveerror)

#### Constructors

##### Constructor

> **new GenericError**(`message`, `error_code`): [`GenericError`](#genericerror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:41](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L41)

###### Parameters

###### message

`string`

###### error\_code

`bigint`

###### Returns

[`GenericError`](#genericerror)

###### Overrides

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ApproveError`](#approveerror).[`cause`](#cause-1)

##### error\_code

> `readonly` **error\_code**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L43)

##### message

> `readonly` **message**: `string`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:42](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L42)

###### Inherited from

[`ApproveError`](#approveerror).[`message`](#message-1)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ApproveError`](#approveerror).[`name`](#name-1)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ApproveError`](#approveerror).[`stack`](#stack-1)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ApproveError`](#approveerror).[`stackTraceLimit`](#stacktracelimit-1)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ApproveError`](#approveerror).[`captureStackTrace`](#capturestacktrace-2)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ApproveError`](#approveerror).[`isError`](#iserror-2)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ApproveError`](#approveerror).[`prepareStackTrace`](#preparestacktrace-2)

***

### IcpIndexCanister

Defined in: [packages/canisters/src/ledger/icp/index.canister.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/index.canister.ts#L19)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/IcpIndexDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new IcpIndexCanister**(`id`, `service`, `certifiedService`): [`IcpIndexCanister`](#icpindexcanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/IcpIndexDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/IcpIndexDid.md#_service)

###### Returns

[`IcpIndexCanister`](#icpindexcanister)

###### Inherited from

`Canister<IcpIndexService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/IcpIndexDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/IcpIndexDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/IcpIndexDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/IcpIndexDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### accountBalance()

> **accountBalance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/index.canister.ts:45](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/index.canister.ts#L45)

Returns the balance of the specified account identifier.

###### Parameters

###### params

`AccountBalanceParams`

The parameters to get the balance of an account.

###### Returns

`Promise`\<`bigint`\>

The balance of the given account.

##### getTransactions()

> **getTransactions**(`params`): `Promise`\<[`GetAccountIdentifierTransactionsResponse`](namespaces/IcpIndexDid.md#getaccountidentifiertransactionsresponse)\>

Defined in: [packages/canisters/src/ledger/icp/index.canister.ts:64](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/index.canister.ts#L64)

Returns the transactions and balance of an ICP account.

###### Parameters

###### params

`GetTransactionsParams`

The parameters to get the transactions.

###### Returns

`Promise`\<[`GetAccountIdentifierTransactionsResponse`](namespaces/IcpIndexDid.md#getaccountidentifiertransactionsresponse)\>

The transactions, balance and the transaction id of the oldest transaction the account has.

###### Throws

IndexError

##### create()

> `static` **create**(`__namedParameters`): [`IcpIndexCanister`](#icpindexcanister)

Defined in: [packages/canisters/src/ledger/icp/index.canister.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/index.canister.ts#L20)

###### Parameters

###### \_\_namedParameters

`CanisterOptions`\<[`_SERVICE`](namespaces/IcpIndexDid.md#_service)\>

###### Returns

[`IcpIndexCanister`](#icpindexcanister)

***

### IcpLedgerCanister

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:33](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L33)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/IcpLedgerDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new IcpLedgerCanister**(`id`, `service`, `certifiedService`): [`IcpLedgerCanister`](#icpledgercanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/IcpLedgerDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/IcpLedgerDid.md#_service)

###### Returns

[`IcpLedgerCanister`](#icpledgercanister)

###### Inherited from

`Canister<IcpLedgerService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/IcpLedgerDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/IcpLedgerDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/IcpLedgerDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/IcpLedgerDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### accountBalance()

> **accountBalance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:62](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L62)

Returns the balance of the specified account identifier.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### params

`AccountBalanceParams`

The parameters to get the balance of an account.

###### Returns

`Promise`\<`bigint`\>

The balance of the given account.

###### Throws

Error

##### icrc1Transfer()

> **icrc1Transfer**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:132](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L132)

Transfer ICP from the caller to the destination `Account`.
Returns the index of the block containing the tx if it was successful.

###### Parameters

###### request

[`Icrc1TransferRequest`](#icrc1transferrequest)

###### Returns

`Promise`\<`bigint`\>

###### Throws

[TransferError](#transfererror)

##### icrc21ConsentMessage()

> **icrc21ConsentMessage**(`params`): `Promise`\<[`icrc21_consent_info`](namespaces/IcpLedgerDid.md#icrc21_consent_info)\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:179](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L179)

Fetches the consent message for a specified canister call, intended to provide a human-readable message that helps users make informed decisions.

@link: https://github.com/dfinity/wg-identity-authentication/blob/main/topics/ICRC-21/icrc_21_consent_msg.md

###### Parameters

###### params

`Icrc21ConsentMessageRequest`

The request parameters containing the method name, arguments, and consent preferences (e.g., language).

###### Returns

`Promise`\<[`icrc21_consent_info`](namespaces/IcpLedgerDid.md#icrc21_consent_info)\>

- A promise that resolves to the consent message response, which includes the consent message in the specified language and other related information.

###### Throws

- This error is reserved for future use, in case payment extensions are introduced. For example, if consent messages, which are currently free, begin to require payments.

###### Throws

- If the specified canister call is not supported.

###### Throws

- If there is no consent message available.

###### Throws

- For any other generic errors.

##### icrc2Approve()

> **icrc2Approve**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:152](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L152)

This method entitles the `spender` to transfer token `amount` on behalf of the caller from account `{ owner = caller; subaccount = from_subaccount }`.

Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-2/index.md#icrc2_approve

###### Parameters

###### params

[`Icrc2ApproveRequest`](#icrc2approverequest)

The parameters to approve.

###### Returns

`Promise`\<`bigint`\>

The block index of the approved transaction.

###### Throws

If the approval fails.

##### metadata()

> **metadata**(`params`): `Promise`\<\[`string`, [`Value`](namespaces/IcpLedgerDid.md#value)\][]\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:81](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L81)

Fetches the ledger metadata.

###### Parameters

###### params

`QueryParams`

The parameters used to fetch the metadata, notably query or certified call.

###### Returns

`Promise`\<\[`string`, [`Value`](namespaces/IcpLedgerDid.md#value)\][]\>

The metadata of the ICP ledger. A promise that resolves to an array of metadata entries, where each entry is a tuple consisting of a string and a value.

##### transactionFee()

> **transactionFee**(`params?`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:94](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L94)

Returns the transaction fee of the ICP ledger canister.

###### Parameters

###### params?

`QueryParams` = `...`

Optional query parameters for the request, defaulting to `{ certified: false }` for backwards compatibility reason.

###### Returns

`Promise`\<`bigint`\>

A promise that resolves to the transaction fee as a bigint.

##### transfer()

> **transfer**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L112)

Transfer ICP from the caller to the destination `accountIdentifier`.
Returns the index of the block containing the tx if it was successful.

###### Parameters

###### request

[`TransferRequest`](#transferrequest)

###### Returns

`Promise`\<`bigint`\>

###### Throws

[TransferError](#transfererror)

##### create()

> `static` **create**(`options`): [`IcpLedgerCanister`](#icpledgercanister)

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/ledger.canister.ts#L34)

###### Parameters

###### options

[`IcpLedgerCanisterOptions`](#icpledgercanisteroptions) = `{}`

###### Returns

[`IcpLedgerCanister`](#icpledgercanister)

***

### IcrcError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:4](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L4)

#### Extends

- `Error`

#### Extended by

- [`TransferError`](#transfererror)
- [`ApproveError`](#approveerror)
- [`ConsentMessageError`](#consentmessageerror)
- [`BadFeeError`](#badfeeerror)

#### Constructors

##### Constructor

> **new IcrcError**(`message?`): [`IcrcError`](#icrcerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`IcrcError`](#icrcerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new IcrcError**(`message?`, `options?`): [`IcrcError`](#icrcerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`IcrcError`](#icrcerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### InsufficientFundsError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L14)

#### Extends

- [`TransferError`](#transfererror)

#### Constructors

##### Constructor

> **new InsufficientFundsError**(`balance`): [`InsufficientFundsError`](#insufficientfundserror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L15)

###### Parameters

###### balance

`bigint`

###### Returns

[`InsufficientFundsError`](#insufficientfundserror)

###### Overrides

[`TransferError`](#transfererror).[`constructor`](#constructor-18)

#### Properties

##### balance

> `readonly` **balance**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L15)

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`TransferError`](#transfererror).[`cause`](#cause-16)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`TransferError`](#transfererror).[`message`](#message-16)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`TransferError`](#transfererror).[`name`](#name-16)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`TransferError`](#transfererror).[`stack`](#stack-16)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`TransferError`](#transfererror).[`stackTraceLimit`](#stacktracelimit-16)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`TransferError`](#transfererror).[`captureStackTrace`](#capturestacktrace-32)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`TransferError`](#transfererror).[`isError`](#iserror-32)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`TransferError`](#transfererror).[`prepareStackTrace`](#preparestacktrace-32)

***

### InsufficientPaymentError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:72](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L72)

#### Extends

- [`ConsentMessageError`](#consentmessageerror)

#### Constructors

##### Constructor

> **new InsufficientPaymentError**(`message?`): [`InsufficientPaymentError`](#insufficientpaymenterror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`InsufficientPaymentError`](#insufficientpaymenterror)

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`constructor`](#constructor-3)

##### Constructor

> **new InsufficientPaymentError**(`message?`, `options?`): [`InsufficientPaymentError`](#insufficientpaymenterror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`InsufficientPaymentError`](#insufficientpaymenterror)

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`constructor`](#constructor-3)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`cause`](#cause-3)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`message`](#message-3)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`name`](#name-3)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`stack`](#stack-3)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`stackTraceLimit`](#stacktracelimit-3)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`captureStackTrace`](#capturestacktrace-6)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`isError`](#iserror-6)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`prepareStackTrace`](#preparestacktrace-6)

***

### InvalidAccountIDError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:12](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L12)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new InvalidAccountIDError**(`message?`): [`InvalidAccountIDError`](#invalidaccountiderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`InvalidAccountIDError`](#invalidaccountiderror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new InvalidAccountIDError**(`message?`, `options?`): [`InvalidAccountIDError`](#invalidaccountiderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`InvalidAccountIDError`](#invalidaccountiderror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### InvalidSenderError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:10](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L10)

#### Extends

- [`TransferError`](#transfererror)

#### Constructors

##### Constructor

> **new InvalidSenderError**(`message?`): [`InvalidSenderError`](#invalidsendererror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`InvalidSenderError`](#invalidsendererror)

###### Inherited from

[`TransferError`](#transfererror).[`constructor`](#constructor-18)

##### Constructor

> **new InvalidSenderError**(`message?`, `options?`): [`InvalidSenderError`](#invalidsendererror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`InvalidSenderError`](#invalidsendererror)

###### Inherited from

[`TransferError`](#transfererror).[`constructor`](#constructor-18)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`TransferError`](#transfererror).[`cause`](#cause-16)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`TransferError`](#transfererror).[`message`](#message-16)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`TransferError`](#transfererror).[`name`](#name-16)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`TransferError`](#transfererror).[`stack`](#stack-16)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`TransferError`](#transfererror).[`stackTraceLimit`](#stacktracelimit-16)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`TransferError`](#transfererror).[`captureStackTrace`](#capturestacktrace-32)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`TransferError`](#transfererror).[`isError`](#iserror-32)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`TransferError`](#transfererror).[`prepareStackTrace`](#preparestacktrace-32)

***

### SubAccount

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L140)

A subaccount in the ICP ledger is a 32-byte identifier that allows a principal (user or canister)
to control multiple independent accounts under the same principal.

#### See

https://internetcomputer.org/docs/references/ledger#_accounts

#### Methods

##### toUint8Array()

> **toUint8Array**(): `Uint8Array`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L218)

Returns the raw 32-byte `Uint8Array` representing this subaccount.

###### Returns

`Uint8Array`

A 32-byte array.

##### fromBytes()

> `static` **fromBytes**(`bytes`): [`SubAccount`](#subaccount)

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L150)

Creates a `SubAccount` from a 32‑byte array.

###### Parameters

###### bytes

`Uint8Array`

A `Uint8Array` of exactly 32 bytes.

###### Returns

[`SubAccount`](#subaccount)

A `SubAccount` instance.

###### Throws

If the byte array length is not 32.

##### fromID()

> `static` **fromID**(`id`): [`SubAccount`](#subaccount)

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:189](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L189)

Generates a `SubAccount` from a non‑negative number.

The number is encoded into the last 8 bytes of the 32‑byte array.
This is a common pattern when using numbered subaccounts like 0, 1, 2...

###### Parameters

###### id

`number`

A non-negative integer.

###### Returns

[`SubAccount`](#subaccount)

A `SubAccount` instance.

###### Throws

If the number is negative or exceeds `Number.MAX_SAFE_INTEGER`.

##### fromPrincipal()

> `static` **fromPrincipal**(`principal`): [`SubAccount`](#subaccount)

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:166](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/account_identifier.ts#L166)

Generates a `SubAccount` from a principal.

The principal is embedded into the beginning of a 32‑byte array.

###### Parameters

###### principal

`Principal`

A principal to encode into the subaccount.

###### Returns

[`SubAccount`](#subaccount)

A `SubAccount` instance.

***

### TemporarilyUnavailableError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L49)

#### Extends

- [`ApproveError`](#approveerror)

#### Constructors

##### Constructor

> **new TemporarilyUnavailableError**(`message?`): [`TemporarilyUnavailableError`](#temporarilyunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`TemporarilyUnavailableError`](#temporarilyunavailableerror)

###### Inherited from

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

##### Constructor

> **new TemporarilyUnavailableError**(`message?`, `options?`): [`TemporarilyUnavailableError`](#temporarilyunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`TemporarilyUnavailableError`](#temporarilyunavailableerror)

###### Inherited from

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ApproveError`](#approveerror).[`cause`](#cause-1)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ApproveError`](#approveerror).[`message`](#message-1)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ApproveError`](#approveerror).[`name`](#name-1)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ApproveError`](#approveerror).[`stack`](#stack-1)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ApproveError`](#approveerror).[`stackTraceLimit`](#stacktracelimit-1)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ApproveError`](#approveerror).[`captureStackTrace`](#capturestacktrace-2)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ApproveError`](#approveerror).[`isError`](#iserror-2)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ApproveError`](#approveerror).[`prepareStackTrace`](#preparestacktrace-2)

***

### TooOldError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:64](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L64)

#### Extends

- [`ApproveError`](#approveerror)

#### Constructors

##### Constructor

> **new TooOldError**(`message?`): [`TooOldError`](#tooolderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`TooOldError`](#tooolderror)

###### Inherited from

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

##### Constructor

> **new TooOldError**(`message?`, `options?`): [`TooOldError`](#tooolderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`TooOldError`](#tooolderror)

###### Inherited from

[`ApproveError`](#approveerror).[`constructor`](#constructor-1)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ApproveError`](#approveerror).[`cause`](#cause-1)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ApproveError`](#approveerror).[`message`](#message-1)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ApproveError`](#approveerror).[`name`](#name-1)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ApproveError`](#approveerror).[`stack`](#stack-1)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ApproveError`](#approveerror).[`stackTraceLimit`](#stacktracelimit-1)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ApproveError`](#approveerror).[`captureStackTrace`](#capturestacktrace-2)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ApproveError`](#approveerror).[`isError`](#iserror-2)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ApproveError`](#approveerror).[`prepareStackTrace`](#preparestacktrace-2)

***

### TransferError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L6)

#### Extends

- [`IcrcError`](#icrcerror)

#### Extended by

- [`InvalidSenderError`](#invalidsendererror)
- [`InsufficientFundsError`](#insufficientfundserror)
- [`TxTooOldError`](#txtooolderror)
- [`TxCreatedInFutureError`](#txcreatedinfutureerror)
- [`TxDuplicateError`](#txduplicateerror)

#### Constructors

##### Constructor

> **new TransferError**(`message?`): [`TransferError`](#transfererror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`TransferError`](#transfererror)

###### Inherited from

[`IcrcError`](#icrcerror).[`constructor`](#constructor-11)

##### Constructor

> **new TransferError**(`message?`, `options?`): [`TransferError`](#transfererror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`TransferError`](#transfererror)

###### Inherited from

[`IcrcError`](#icrcerror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`IcrcError`](#icrcerror).[`cause`](#cause-9)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`IcrcError`](#icrcerror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`IcrcError`](#icrcerror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`IcrcError`](#icrcerror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`IcrcError`](#icrcerror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`IcrcError`](#icrcerror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`IcrcError`](#icrcerror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`IcrcError`](#icrcerror).[`prepareStackTrace`](#preparestacktrace-18)

***

### TxCreatedInFutureError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L26)

#### Extends

- [`TransferError`](#transfererror)

#### Constructors

##### Constructor

> **new TxCreatedInFutureError**(`message?`): [`TxCreatedInFutureError`](#txcreatedinfutureerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`TxCreatedInFutureError`](#txcreatedinfutureerror)

###### Inherited from

[`TransferError`](#transfererror).[`constructor`](#constructor-18)

##### Constructor

> **new TxCreatedInFutureError**(`message?`, `options?`): [`TxCreatedInFutureError`](#txcreatedinfutureerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`TxCreatedInFutureError`](#txcreatedinfutureerror)

###### Inherited from

[`TransferError`](#transfererror).[`constructor`](#constructor-18)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`TransferError`](#transfererror).[`cause`](#cause-16)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`TransferError`](#transfererror).[`message`](#message-16)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`TransferError`](#transfererror).[`name`](#name-16)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`TransferError`](#transfererror).[`stack`](#stack-16)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`TransferError`](#transfererror).[`stackTraceLimit`](#stacktracelimit-16)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`TransferError`](#transfererror).[`captureStackTrace`](#capturestacktrace-32)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`TransferError`](#transfererror).[`isError`](#iserror-32)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`TransferError`](#transfererror).[`prepareStackTrace`](#preparestacktrace-32)

***

### TxDuplicateError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L28)

#### Extends

- [`TransferError`](#transfererror)

#### Constructors

##### Constructor

> **new TxDuplicateError**(`duplicateOf`): [`TxDuplicateError`](#txduplicateerror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L29)

###### Parameters

###### duplicateOf

`bigint`

###### Returns

[`TxDuplicateError`](#txduplicateerror)

###### Overrides

[`TransferError`](#transfererror).[`constructor`](#constructor-18)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`TransferError`](#transfererror).[`cause`](#cause-16)

##### duplicateOf

> `readonly` **duplicateOf**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L29)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`TransferError`](#transfererror).[`message`](#message-16)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`TransferError`](#transfererror).[`name`](#name-16)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`TransferError`](#transfererror).[`stack`](#stack-16)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`TransferError`](#transfererror).[`stackTraceLimit`](#stacktracelimit-16)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`TransferError`](#transfererror).[`captureStackTrace`](#capturestacktrace-32)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`TransferError`](#transfererror).[`isError`](#iserror-32)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`TransferError`](#transfererror).[`prepareStackTrace`](#preparestacktrace-32)

***

### TxTooOldError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L20)

#### Extends

- [`TransferError`](#transfererror)

#### Constructors

##### Constructor

> **new TxTooOldError**(`allowed_window_secs?`): [`TxTooOldError`](#txtooolderror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L21)

###### Parameters

###### allowed\_window\_secs?

`number`

###### Returns

[`TxTooOldError`](#txtooolderror)

###### Overrides

[`TransferError`](#transfererror).[`constructor`](#constructor-18)

#### Properties

##### allowed\_window\_secs?

> `readonly` `optional` **allowed\_window\_secs**: `number`

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L21)

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`TransferError`](#transfererror).[`cause`](#cause-16)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`TransferError`](#transfererror).[`message`](#message-16)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`TransferError`](#transfererror).[`name`](#name-16)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`TransferError`](#transfererror).[`stack`](#stack-16)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`TransferError`](#transfererror).[`stackTraceLimit`](#stacktracelimit-16)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`TransferError`](#transfererror).[`captureStackTrace`](#capturestacktrace-32)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`TransferError`](#transfererror).[`isError`](#iserror-32)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`TransferError`](#transfererror).[`prepareStackTrace`](#preparestacktrace-32)

***

### UnsupportedCanisterCallError

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:73](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L73)

#### Extends

- [`ConsentMessageError`](#consentmessageerror)

#### Constructors

##### Constructor

> **new UnsupportedCanisterCallError**(`message?`): [`UnsupportedCanisterCallError`](#unsupportedcanistercallerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`UnsupportedCanisterCallError`](#unsupportedcanistercallerror)

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`constructor`](#constructor-3)

##### Constructor

> **new UnsupportedCanisterCallError**(`message?`, `options?`): [`UnsupportedCanisterCallError`](#unsupportedcanistercallerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`UnsupportedCanisterCallError`](#unsupportedcanistercallerror)

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`constructor`](#constructor-3)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`cause`](#cause-3)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`message`](#message-3)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`name`](#name-3)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`stack`](#stack-3)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`stackTraceLimit`](#stacktracelimit-3)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`captureStackTrace`](#capturestacktrace-6)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`isError`](#iserror-6)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ConsentMessageError`](#consentmessageerror).[`prepareStackTrace`](#preparestacktrace-6)

## Interfaces

### Icrc1TransferRequest

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L23)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L25)

##### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L32)

##### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:27](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L27)

##### fromSubAccount?

> `optional` **fromSubAccount**: [`SubAccount`](namespaces/IcpLedgerDid.md#subaccount-1)

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L28)

##### icrc1Memo?

> `optional` **icrc1Memo**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L26)

##### to

> **to**: [`Account`](namespaces/IcpLedgerDid.md#account)

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L24)

***

### TransferRequest

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:5](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L5)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:7](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L7)

##### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L15)

##### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:9](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L9)

##### fromSubAccount?

> `optional` **fromSubAccount**: `number`[]

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:11](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L11)

##### memo?

> `optional` **memo**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:8](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L8)

##### to

> **to**: [`AccountIdentifier`](#accountidentifier)

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:6](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L6)

## Type Aliases

### AccountIdentifierHex

> **AccountIdentifierHex** = `string`

Defined in: [packages/canisters/src/ledger/icp/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/common.ts#L1)

***

### BlockHeight

> **BlockHeight** = `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/common.ts:2](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/common.ts#L2)

***

### E8s

> **E8s** = `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/common.ts#L3)

***

### IcpLedgerCanisterOptions

> **IcpLedgerCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](namespaces/IcpLedgerDid.md#_service)\>

Defined in: [packages/canisters/src/ledger/icp/types/ledger.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger.options.ts#L4)

***

### Icrc2ApproveRequest

> **Icrc2ApproveRequest** = `Omit`\<[`Icrc1TransferRequest`](#icrc1transferrequest), `"to"`\> & `object`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:47](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L47)

Params for an icrc2_approve.

#### Type Declaration

##### expected\_allowance?

> `optional` **expected\_allowance**: [`Icrc1Tokens`](namespaces/IcpLedgerDid.md#icrc1tokens)

##### expires\_at?

> `optional` **expires\_at**: [`Icrc1Timestamp`](namespaces/IcpLedgerDid.md#icrc1timestamp)

##### spender

> **spender**: [`Account`](namespaces/IcpLedgerDid.md#account)

#### Param

The account of the spender.

#### Param

The amount of tokens to approve.

#### Param

The subaccount to transfer tokens from.

#### Param

Approve memo.

#### Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues

#### Param

The fee of the transfer when it's not the default fee.

#### Param

The optional allowance expected. If the expected_allowance field is set, the ledger MUST ensure that the current allowance for the spender from the caller's account is equal to the given value and return the AllowanceChanged error otherwise.

#### Param

When the approval expires. If the field is set, it's greater than the current ledger time.

## Functions

### checkAccountId()

> **checkAccountId**(`accountId`): `void`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L15)

Checks account id check sum

#### Parameters

##### accountId

`string`

#### Returns

`void`

#### Throws

InvalidAccountIDError

***

### isIcpAccountIdentifier()

> **isIcpAccountIdentifier**(`address`): `boolean`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:41](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L41)

Checks if a given string (or undefined) is a valid ICP account identifier.

It uses the `checkAccountId` function to validate the checksum, but it does not throw an error.

#### Parameters

##### address

The putative ICP account identifier.

`string` | `undefined`

#### Returns

`boolean`

***

### mapIcrc1TransferError()

> **mapIcrc1TransferError**(`rawTransferError`): [`TransferError`](#transfererror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L104)

#### Parameters

##### rawTransferError

[`Icrc1TransferError`](namespaces/IcpLedgerDid.md#icrc1transfererror)

#### Returns

[`TransferError`](#transfererror)

***

### mapIcrc21ConsentMessageError()

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](#consentmessageerror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:187](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L187)

#### Parameters

##### rawError

[`icrc21_error`](namespaces/IcpLedgerDid.md#icrc21_error)

#### Returns

[`ConsentMessageError`](#consentmessageerror)

***

### mapIcrc2ApproveError()

> **mapIcrc2ApproveError**(`rawApproveError`): [`ApproveError`](#approveerror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:130](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L130)

#### Parameters

##### rawApproveError

[`ApproveError`](namespaces/IcpLedgerDid.md#approveerror)

#### Returns

[`ApproveError`](#approveerror)

***

### mapTransferError()

> **mapTransferError**(`rawTransferError`): [`TransferError`](#transfererror)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L76)

#### Parameters

##### rawTransferError

[`TransferError`](namespaces/IcpLedgerDid.md#transfererror)

#### Returns

[`TransferError`](#transfererror)

***

### toIcrc1TransferRawRequest()

> **toIcrc1TransferRawRequest**(`__namedParameters`): [`TransferArg`](namespaces/IcpLedgerDid.md#transferarg)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L43)

#### Parameters

##### \_\_namedParameters

[`Icrc1TransferRequest`](#icrc1transferrequest)

#### Returns

[`TransferArg`](namespaces/IcpLedgerDid.md#transferarg)

***

### toIcrc21ConsentMessageRawRequest()

> **toIcrc21ConsentMessageRawRequest**(`__namedParameters`): [`icrc21_consent_message_request`](namespaces/IcpLedgerDid.md#icrc21_consent_message_request)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L79)

#### Parameters

##### \_\_namedParameters

`Icrc21ConsentMessageRequest`

#### Returns

[`icrc21_consent_message_request`](namespaces/IcpLedgerDid.md#icrc21_consent_message_request)

***

### toIcrc2ApproveRawRequest()

> **toIcrc2ApproveRawRequest**(`__namedParameters`): [`ApproveArgs`](namespaces/IcpLedgerDid.md#approveargs)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:59](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L59)

#### Parameters

##### \_\_namedParameters

[`Icrc2ApproveRequest`](#icrc2approverequest)

#### Returns

[`ApproveArgs`](namespaces/IcpLedgerDid.md#approveargs)

***

### toTransferRawRequest()

> **toTransferRawRequest**(`__namedParameters`): [`TransferArgs`](namespaces/IcpLedgerDid.md#transferargs)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L17)

#### Parameters

##### \_\_namedParameters

[`TransferRequest`](#transferrequest)

#### Returns

[`TransferArgs`](namespaces/IcpLedgerDid.md#transferargs)
