---
title: CyclesLedgerDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L376)

#### Properties

##### create\_canister

> **create\_canister**: `ActorMethod`\<\[[`CreateCanisterArgs`](#createcanisterargs)\], \{ `Ok`: [`CreateCanisterSuccess`](#createcanistersuccess); \} \| \{ `Err`: [`CreateCanisterError`](#createcanistererror); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L377)

##### create\_canister\_from

> **create\_canister\_from**: `ActorMethod`\<\[[`CreateCanisterFromArgs`](#createcanisterfromargs)\], \{ `Ok`: [`CreateCanisterSuccess`](#createcanistersuccess); \} \| \{ `Err`: [`CreateCanisterFromError`](#createcanisterfromerror); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L381)

##### deposit

> **deposit**: `ActorMethod`\<\[[`DepositArgs`](#depositargs)\], [`DepositResult`](#depositresult)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L385)

##### http\_request

> **http\_request**: `ActorMethod`\<\[[`HttpRequest`](#httprequest)\], [`HttpResponse`](#httpresponse)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L386)

##### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L392)

##### icrc1\_decimals

> **icrc1\_decimals**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L393)

##### icrc1\_fee

> **icrc1\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L394)

##### icrc1\_metadata

> **icrc1\_metadata**: `ActorMethod`\<\[\], \[`string`, [`MetadataValue`](#metadatavalue)\][]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L395)

##### icrc1\_minting\_account

> **icrc1\_minting\_account**: `ActorMethod`\<\[\], \[\] \| \[[`Account`](#account)\]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L396)

##### icrc1\_name

> **icrc1\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L397)

##### icrc1\_supported\_standards

> **icrc1\_supported\_standards**: `ActorMethod`\<\[\], [`SupportedStandard`](#supportedstandard)[]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L398)

##### icrc1\_symbol

> **icrc1\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L399)

##### icrc1\_total\_supply

> **icrc1\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L400)

##### icrc1\_transfer

> **icrc1\_transfer**: `ActorMethod`\<\[[`TransferArgs`](#transferargs)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`TransferError`](#transfererror); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L401)

##### icrc103\_get\_allowances

> **icrc103\_get\_allowances**: `ActorMethod`\<\[[`GetAllowancesArgs`](#getallowancesargs)\], [`ICRC103GetAllowancesResponse`](#icrc103getallowancesresponse)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L387)

##### icrc106\_get\_index\_principal

> **icrc106\_get\_index\_principal**: `ActorMethod`\<\[\], [`GetIndexPrincipalResult`](#getindexprincipalresult)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L391)

##### icrc2\_allowance

> **icrc2\_allowance**: `ActorMethod`\<\[[`AllowanceArgs`](#allowanceargs)\], [`Allowance`](#allowance)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L405)

##### icrc2\_approve

> **icrc2\_approve**: `ActorMethod`\<\[[`ApproveArgs`](#approveargs)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`ApproveError`](#approveerror); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L406)

##### icrc2\_transfer\_from

> **icrc2\_transfer\_from**: `ActorMethod`\<\[[`TransferFromArgs`](#transferfromargs)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`TransferFromError`](#transferfromerror); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L410)

##### icrc3\_get\_archives

> **icrc3\_get\_archives**: `ActorMethod`\<\[[`GetArchivesArgs`](#getarchivesargs)\], [`GetArchivesResult`](#getarchivesresult)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L414)

##### icrc3\_get\_blocks

> **icrc3\_get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`GetBlocksResult`](#getblocksresult)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L415)

##### icrc3\_get\_tip\_certificate

> **icrc3\_get\_tip\_certificate**: `ActorMethod`\<\[\], \[\] \| \[[`DataCertificate`](#datacertificate)\]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L416)

##### icrc3\_supported\_block\_types

> **icrc3\_supported\_block\_types**: `ActorMethod`\<\[\], [`SupportedBlockType`](#supportedblocktype)[]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L417)

##### withdraw

> **withdraw**: `ActorMethod`\<\[[`WithdrawArgs`](#withdrawargs)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`WithdrawError`](#withdrawerror); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L418)

##### withdraw\_from

> **withdraw\_from**: `ActorMethod`\<\[[`WithdrawFromArgs`](#withdrawfromargs)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`WithdrawFromError`](#withdrawfromerror); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L422)

***

### Account

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L15)

***

### Allowance

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L17)

#### Properties

##### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L18)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L19)

***

### AllowanceArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L21)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L22)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L23)

***

### ApproveArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L31)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L36)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L35)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L37)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L38)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L32)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L34)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L33)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L39)

***

### CanisterSettings

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L54)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L59)

##### controllers

> **controllers**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L56)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L55)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L58)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L57)

***

### CmcCreateCanisterArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L62)

#### Properties

##### settings

> **settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L71)

Optional canister settings that, if set, are applied to the newly created canister.
If not specified, the caller is the controller of the canister and the other settings are set to default values.

##### subnet\_selection

> **subnet\_selection**: \[\] \| \[[`SubnetSelection`](#subnetselection)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L66)

Optional instructions to select on which subnet the new canister will be created on.

***

### CreateCanisterArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L73)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L76)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L75)

##### creation\_args

> **creation\_args**: \[\] \| \[[`CmcCreateCanisterArgs`](#cmccreatecanisterargs)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L77)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L74)

***

### CreateCanisterFromArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L103)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L107)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L106)

##### creation\_args

> **creation\_args**: \[\] \| \[[`CmcCreateCanisterArgs`](#cmccreatecanisterargs)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L108)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L105)

##### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L104)

***

### CreateCanisterSuccess

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L135)

#### Properties

##### block\_id

> **block\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L136)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L137)

***

### DataCertificate

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L139)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L143)

See https://internetcomputer.org/docs/current/references/ic-interface-spec#certification

##### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L147)

CBOR encoded hash_tree

***

### DepositArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L149)

#### Properties

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L151)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L150)

***

### DepositResult

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L153)

#### Properties

##### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L154)

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L155)

***

### GetAllowancesArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L157)

#### Properties

##### from\_account

> **from\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L160)

##### prev\_spender

> **prev\_spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L159)

##### take

> **take**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L158)

***

### GetArchivesArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L167)

#### Properties

##### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L174)

The last archive seen by the client.
The ledger will return archives coming
after this one if set, otherwise it
will return the first archives.

***

### GetBlocksResult

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L191)

#### Properties

##### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L202)

The archived_blocks vector is always going to be empty
for this ledger because there is no archive node.

###### args

> **args**: [`GetBlocksArgs`](#getblocksargs)

###### callback

> **callback**: \[`Principal`, `string`\]

##### blocks

> **blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L197)

###### block

> **block**: [`Value`](#value)

###### id

> **id**: `bigint`

##### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L196)

Total number of blocks in the
block log.

***

### HttpRequest

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L218)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L221)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L222)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L220)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L219)

***

### HttpResponse

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L224)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L225)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L226)

##### status\_code

> **status\_code**: `number`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L227)

***

### InitArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L232)

#### Properties

##### index\_id

> **index\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L234)

##### initial\_balances

> **initial\_balances**: \[\] \| \[\[[`Account`](#account), `bigint`\][]\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L233)

##### max\_blocks\_per\_request

> **max\_blocks\_per\_request**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L235)

***

### SubnetFilter

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L251)

#### Properties

##### subnet\_type

> **subnet\_type**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L252)

***

### SupportedBlockType

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L267)

#### Properties

##### block\_type

> **block\_type**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L269)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L268)

***

### SupportedStandard

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L271)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L273)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L272)

***

### TransferArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L275)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L281)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L280)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L277)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L279)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L278)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L276)

***

### TransferFromArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L294)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L301)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L300)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L296)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L298)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L299)

##### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L297)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L295)

***

### UpgradeArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L315)

#### Properties

##### change\_index\_id

> **change\_index\_id**: \[\] \| \[[`ChangeIndexId`](#changeindexid)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L316)

##### max\_blocks\_per\_request

> **max\_blocks\_per\_request**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L317)

***

### WithdrawArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L327)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L331)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L330)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L329)

##### to

> **to**: `Principal`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L328)

***

### WithdrawFromArgs

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L349)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L354)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L353)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L352)

##### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L351)

##### to

> **to**: `Principal`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L350)

## Type Aliases

### Allowances

> **Allowances** = `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L25)

#### Type Declaration

##### allowance

> **allowance**: `bigint`

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

##### from\_account

> **from\_account**: [`Account`](#account)

##### to\_spender

> **to\_spender**: [`Account`](#account)

***

### ApproveError

> **ApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L41)

***

### BlockIndex

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L53)

***

### ChangeIndexId

> **ChangeIndexId** = \{ `SetTo`: `Principal`; \} \| \{ `Unset`: `null`; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L61)

***

### CreateCanisterError

> **CreateCanisterError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `canister_id`: \[\] \| \[`Principal`\]; `duplicate_of`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `FailedToCreate`: \{ `error`: `string`; `fee_block`: \[\] \| \[[`BlockIndex`](#blockindex)\]; `refund_block`: \[\] \| \[[`BlockIndex`](#blockindex)\]; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L79)

***

### CreateCanisterFromError

> **CreateCanisterFromError** = \{ `FailedToCreateFrom`: \{ `approval_refund_block`: \[\] \| \[[`BlockIndex`](#blockindex)\]; `create_from_block`: \[\] \| \[[`BlockIndex`](#blockindex)\]; `refund_block`: \[\] \| \[[`BlockIndex`](#blockindex)\]; `rejection_code`: [`RejectionCode`](#rejectioncode); `rejection_reason`: `string`; \}; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `canister_id`: \[\] \| \[`Principal`\]; `duplicate_of`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L110)

***

### GetAllowancesError

> **GetAllowancesError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `AccessDenied`: \{ `reason`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L162)

***

### GetArchivesResult

> **GetArchivesResult** = `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L176)

#### Type Declaration

##### canister\_id

> **canister\_id**: `Principal`

The id of the archive

##### end

> **end**: `bigint`

The last block in the archive

##### start

> **start**: `bigint`

The first block in the archive

***

### GetBlocksArgs

> **GetBlocksArgs** = `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L190)

#### Type Declaration

##### length

> **length**: `bigint`

##### start

> **start**: `bigint`

***

### GetIndexPrincipalError

> **GetIndexPrincipalError** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `IndexPrincipalNotSet`: `null`; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L207)

#### Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

##### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

###### GenericError.description

> **description**: `string`

###### GenericError.error\_code

> **error\_code**: `bigint`

\{ `IndexPrincipalNotSet`: `null`; \}

##### IndexPrincipalNotSet

> **IndexPrincipalNotSet**: `null`

***

### GetIndexPrincipalResult

> **GetIndexPrincipalResult** = \{ `Ok`: `Principal`; \} \| \{ `Err`: [`GetIndexPrincipalError`](#getindexprincipalerror); \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L215)

***

### ICRC103GetAllowancesResponse

> **ICRC103GetAllowancesResponse** = \{ `Ok`: [`Allowances`](#allowances); \} \| \{ `Err`: [`GetAllowancesError`](#getallowanceserror); \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L229)

***

### LedgerArgs

> **LedgerArgs** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](#upgradeargs)\]; \} \| \{ `Init`: [`InitArgs`](#initargs); \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L237)

***

### MetadataValue

> **MetadataValue** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L238)

***

### RejectionCode

> **RejectionCode** = \{ `NoError`: `null`; \} \| \{ `CanisterError`: `null`; \} \| \{ `SysTransient`: `null`; \} \| \{ `DestinationInvalid`: `null`; \} \| \{ `Unknown`: `null`; \} \| \{ `SysFatal`: `null`; \} \| \{ `CanisterReject`: `null`; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L243)

***

### SubnetSelection

> **SubnetSelection** = \{ `Filter`: [`SubnetFilter`](#subnetfilter); \} \| \{ `Subnet`: \{ `subnet`: `Principal`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L254)

#### Type Declaration

\{ `Filter`: [`SubnetFilter`](#subnetfilter); \}

##### Filter

> **Filter**: [`SubnetFilter`](#subnetfilter)

Choose a random subnet that satisfies the specified properties.

\{ `Subnet`: \{ `subnet`: `Principal`; \}; \}

##### Subnet

> **Subnet**: `object`

/ Choose a specific subnet

###### Subnet.subnet

> **subnet**: `Principal`

***

### TransferError

> **TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `BadBurn`: \{ `min_burn_amount`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L283)

***

### TransferFromError

> **TransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L303)

***

### Value

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`Value`](#value)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`Value`](#value)[]; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L319)

***

### WithdrawError

> **WithdrawError** = \{ `FailedToWithdraw`: \{ `fee_block`: \[\] \| \[`bigint`\]; `rejection_code`: [`RejectionCode`](#rejectioncode); `rejection_reason`: `string`; \}; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `InvalidReceiver`: \{ `receiver`: `Principal`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L333)

***

### WithdrawFromError

> **WithdrawFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `InvalidReceiver`: \{ `receiver`: `Principal`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `FailedToWithdrawFrom`: \{ `approval_refund_block`: \[\] \| \[`bigint`\]; `refund_block`: \[\] \| \[`bigint`\]; `rejection_code`: [`RejectionCode`](#rejectioncode); `rejection_reason`: `string`; `withdraw_from_block`: \[\] \| \[`bigint`\]; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L356)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L427)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L428)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
