---
title: IcrcIndexDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L186)

#### Properties

##### get\_account\_transactions

> **get\_account\_transactions**: `ActorMethod`\<\[[`GetAccountTransactionsArgs`](#getaccounttransactionsargs)\], [`GetTransactionsResult`](#gettransactionsresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L187)

##### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksRequest`](#getblocksrequest)\], [`GetBlocksResponse`](#getblocksresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L191)

##### get\_fee\_collectors\_ranges

> **get\_fee\_collectors\_ranges**: `ActorMethod`\<\[\], [`FeeCollectorRanges`](#feecollectorranges)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L192)

##### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L193)

##### ledger\_id

> **ledger\_id**: `ActorMethod`\<\[\], `Principal`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L194)

##### list\_subaccounts

> **list\_subaccounts**: `ActorMethod`\<\[[`ListSubaccountsArgs`](#listsubaccountsargs)\], [`SubAccount`](#subaccount-1)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L195)

##### status

> **status**: `ActorMethod`\<\[\], [`Status`](#status-1)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L196)

***

### Account

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L15)

***

### Approve

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L17)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L22)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L21)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L23)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L24)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L18)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L19)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L20)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L25)

***

### AuthorizedBurn

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L27)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L32)

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L30)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L31)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L28)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L29)

##### reason

> **reason**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L33)

***

### AuthorizedMint

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L35)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L40)

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L38)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L39)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L37)

##### reason

> **reason**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L41)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L36)

***

### Burn

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L45)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L50)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L49)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L46)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L47)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L48)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L51)

***

### FeeCollector

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L53)

#### Properties

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L57)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L56)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L55)

##### ts

> **ts**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L54)

***

### FeeCollectorRanges

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L59)

#### Properties

##### ranges

> **ranges**: \[[`Account`](#account), \[`bigint`, `bigint`\][]\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L60)

***

### GetAccountTransactionsArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L62)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L74)

##### max\_results

> **max\_results**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L66)

Maximum number of transactions to fetch.

##### start

> **start**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L73)

The txid of the last transaction seen by the client.
If None then the results will start from the most recent
txid. If set then the results will start from the next
most recent txid after start (start won't be included).

***

### GetBlocksRequest

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L76)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L78)

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L77)

***

### GetBlocksResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L80)

#### Properties

##### blocks

> **blocks**: [`Value`](#value)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L81)

##### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L82)

***

### GetTransactions

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L84)

#### Properties

##### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L85)

##### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L90)

The txid of the oldest transaction the account has

##### transactions

> **transactions**: [`TransactionWithId`](#transactionwithid)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L86)

***

### GetTransactionsErr

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L92)

#### Properties

##### message

> **message**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L93)

***

### InitArg

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L99)

#### Properties

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L100)

##### max\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **max\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L116)

##### min\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **min\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L115)

The minimum and maximum intervals in seconds in which to retrieve blocks from the ledger.
When a request to the ledger returns an empty response, the interval is increased (up to the maximum).
In case of a non-empty response, the interval is decreased (down to the minimum). A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.

##### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L107)

The legacy parameter to set a fixed interval in seconds in which to retrieve blocks from the ledger.
If set, the index will set both `min_retrieve_blocks_from_ledger_interval_seconds` and
`max_retrieve_blocks_from_ledger_interval_seconds` to the value of `retrieve_blocks_from_ledger_interval_seconds`.
If either the min or max interval parameters are also set, the index will trap during initialization.

***

### ListSubaccountsArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L118)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L119)

##### start

> **start**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L120)

***

### Mint

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L123)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L128)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L127)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L125)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L126)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L124)

***

### Status

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L130)

#### Properties

##### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L131)

***

### Transaction

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L135)

#### Properties

##### approve

> **approve**: \[\] \| \[[`Approve`](#approve)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L139)

##### authorized\_burn

> **authorized\_burn**: \[\] \| \[[`AuthorizedBurn`](#authorizedburn)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L140)

##### authorized\_mint

> **authorized\_mint**: \[\] \| \[[`AuthorizedMint`](#authorizedmint)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L141)

##### burn

> **burn**: \[\] \| \[[`Burn`](#burn)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L136)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`FeeCollector`](#feecollector)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L142)

##### kind

> **kind**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L137)

##### mint

> **mint**: \[\] \| \[[`Mint`](#mint)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L138)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L143)

##### transfer

> **transfer**: \[\] \| \[[`Transfer`](#transfer-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L144)

***

### TransactionWithId

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L146)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L147)

##### transaction

> **transaction**: [`Transaction`](#transaction)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L148)

***

### Transfer

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L150)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L156)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L155)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L152)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L153)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L154)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L157)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L151)

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L159)

#### Properties

##### ledger\_id

> **ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L160)

##### max\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **max\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L176)

##### min\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **min\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L175)

The minimum and maximum intervals in seconds in which to retrieve blocks from the ledger.
When a request to the ledger returns an empty response, the interval is increased (up to the maximum).
In case of a non-empty response, the interval is decreased (down to the minimum). A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.

##### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L167)

The legacy parameter to set a fixed interval in seconds in which to retrieve blocks from the ledger.
If set, the index will set both `min_retrieve_blocks_from_ledger_interval_seconds` and
`max_retrieve_blocks_from_ledger_interval_seconds` to the value of `retrieve_blocks_from_ledger_interval_seconds`.
If either the min or max interval parameters are also set, the index will trap during post upgrade.

## Type Aliases

### Block

> **Block** = [`Value`](#value)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L43)

***

### BlockIndex

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L44)

***

### GetTransactionsResult

> **GetTransactionsResult** = \{ `Ok`: [`GetTransactions`](#gettransactions); \} \| \{ `Err`: [`GetTransactionsErr`](#gettransactionserr); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L95)

***

### IndexArg

> **IndexArg** = \{ `Upgrade`: [`UpgradeArg`](#upgradearg); \} \| \{ `Init`: [`InitArg`](#initarg); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L98)

***

### Map

> **Map** = \[`string`, [`Value`](#value)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L122)

***

### SubAccount

> **SubAccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L133)

***

### Tokens

> **Tokens** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L134)

***

### Value

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: [`Map`](#map); \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`Value`](#value)[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L178)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L198)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L199)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
