---
title: IcrcLedgerDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:597](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L597)

#### Properties

##### archives

> **archives**: `ActorMethod`\<\[\], [`ArchiveInfo`](#archiveinfo)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:598](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L598)

##### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`GetBlocksResponse`](#getblocksresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:599](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L599)

##### get\_data\_certificate

> **get\_data\_certificate**: `ActorMethod`\<\[\], [`DataCertificate`](#datacertificate)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:600](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L600)

##### get\_transactions

> **get\_transactions**: `ActorMethod`\<\[[`GetTransactionsRequest`](#gettransactionsrequest)\], [`GetTransactionsResponse`](#gettransactionsresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L601)

##### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L616)

##### icrc1\_decimals

> **icrc1\_decimals**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L617)

##### icrc1\_fee

> **icrc1\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L618)

##### icrc1\_metadata

> **icrc1\_metadata**: `ActorMethod`\<\[\], \[`string`, [`MetadataValue`](#metadatavalue)\][]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:619](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L619)

##### icrc1\_minting\_account

> **icrc1\_minting\_account**: `ActorMethod`\<\[\], \[\] \| \[[`Account`](#account)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:620](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L620)

##### icrc1\_name

> **icrc1\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L621)

##### icrc1\_supported\_standards

> **icrc1\_supported\_standards**: `ActorMethod`\<\[\], [`StandardRecord`](#standardrecord)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L622)

##### icrc1\_symbol

> **icrc1\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:623](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L623)

##### icrc1\_total\_supply

> **icrc1\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L624)

##### icrc1\_transfer

> **icrc1\_transfer**: `ActorMethod`\<\[[`TransferArg`](#transferarg)\], [`TransferResult`](#transferresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L625)

##### icrc10\_supported\_standards

> **icrc10\_supported\_standards**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L610)

##### icrc103\_get\_allowances

> **icrc103\_get\_allowances**: `ActorMethod`\<\[[`GetAllowancesArgs`](#getallowancesargs)\], [`icrc103_get_allowances_response`](#icrc103_get_allowances_response)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:605](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L605)

##### icrc106\_get\_index\_principal

> **icrc106\_get\_index\_principal**: `ActorMethod`\<\[\], [`GetIndexPrincipalResult`](#getindexprincipalresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:609](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L609)

##### icrc152\_burn

> **icrc152\_burn**: `ActorMethod`\<\[[`Icrc152BurnArgs`](#icrc152burnargs)\], [`Icrc152BurnResult`](#icrc152burnresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:614](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L614)

##### icrc152\_mint

> **icrc152\_mint**: `ActorMethod`\<\[[`Icrc152MintArgs`](#icrc152mintargs)\], [`Icrc152MintResult`](#icrc152mintresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L615)

##### icrc2\_allowance

> **icrc2\_allowance**: `ActorMethod`\<\[[`AllowanceArgs`](#allowanceargs)\], [`Allowance`](#allowance)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L630)

##### icrc2\_approve

> **icrc2\_approve**: `ActorMethod`\<\[[`ApproveArgs`](#approveargs)\], [`ApproveResult`](#approveresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L631)

##### icrc2\_transfer\_from

> **icrc2\_transfer\_from**: `ActorMethod`\<\[[`TransferFromArgs`](#transferfromargs)\], [`TransferFromResult`](#transferfromresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L632)

##### icrc21\_canister\_call\_consent\_message

> **icrc21\_canister\_call\_consent\_message**: `ActorMethod`\<\[[`icrc21_consent_message_request`](#icrc21_consent_message_request)\], [`icrc21_consent_message_response`](#icrc21_consent_message_response)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L626)

##### icrc3\_get\_archives

> **icrc3\_get\_archives**: `ActorMethod`\<\[[`GetArchivesArgs`](#getarchivesargs)\], [`GetArchivesResult`](#getarchivesresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L633)

##### icrc3\_get\_blocks

> **icrc3\_get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)[]\], [`GetBlocksResult`](#getblocksresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L634)

##### icrc3\_get\_tip\_certificate

> **icrc3\_get\_tip\_certificate**: `ActorMethod`\<\[\], \[\] \| \[[`ICRC3DataCertificate`](#icrc3datacertificate)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L635)

##### icrc3\_supported\_block\_types

> **icrc3\_supported\_block\_types**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:636](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L636)

##### is\_ledger\_ready

> **is\_ledger\_ready**: `ActorMethod`\<\[\], `boolean`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L640)

***

### Account

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L15)

***

### Allowance

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L17)

#### Properties

##### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L18)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L19)

***

### Allowance103

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L21)

#### Properties

##### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L24)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L25)

##### from\_account

> **from\_account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L22)

##### to\_spender

> **to\_spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L23)

***

### AllowanceArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L27)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L28)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L29)

***

### Approve

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L31)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L36)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L35)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L37)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L38)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L32)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L33)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L34)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L39)

***

### ApproveArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L41)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L46)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L45)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L47)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L48)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L42)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L44)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L43)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L49)

***

### ArchiveInfo

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L64)

#### Properties

##### block\_range\_end

> **block\_range\_end**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L65)

##### block\_range\_start

> **block\_range\_start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L67)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L66)

***

### AuthorizedBurn

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L69)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L74)

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L72)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L73)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L70)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L71)

##### reason

> **reason**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L75)

***

### AuthorizedMint

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L77)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L82)

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L80)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L81)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L79)

##### reason

> **reason**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L83)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L78)

***

### BlockRange

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L90)

A prefix of the block range specified in the [GetBlocksArgs] request.

#### Properties

##### blocks

> **blocks**: [`Value`](#value)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L108)

A prefix of the requested block range.
The index of the first block is equal to [GetBlocksArgs.start].

Note that the number of blocks might be less than the requested
[GetBlocksArgs.length] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the whole range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of blocks can be empty if:

1. [GetBlocksArgs.length] was zero.
2. [GetBlocksArgs.start] was larger than the last block known to
the canister.

***

### Burn

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L110)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L115)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L114)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L111)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L112)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L113)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L116)

***

### ChangeArchiveOptions

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L118)

#### Properties

##### controller\_id

> **controller\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L126)

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L124)

##### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L123)

##### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L120)

##### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L122)

##### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L125)

##### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L119)

##### trigger\_threshold

> **trigger\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L121)

***

### DataCertificate

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L132)

Certificate for the block at `block_index`.

#### Properties

##### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L133)

##### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L134)

***

### FeatureFlags

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L140)

#### Properties

##### icrc152

> **icrc152**: `boolean`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L141)

##### icrc2

> **icrc2**: `boolean`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L142)

***

### FeeCollector

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L144)

#### Properties

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L148)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L147)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L146)

##### ts

> **ts**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L145)

***

### FieldsDisplay

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L150)

#### Properties

##### fields

> **fields**: \[`string`, [`Icrc21Value`](#icrc21value)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L151)

##### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L152)

***

### GetAllowancesArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L154)

#### Properties

##### from\_account

> **from\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L157)

##### prev\_spender

> **prev\_spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L156)

##### take

> **take**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L155)

***

### GetArchivesArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L164)

#### Properties

##### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L171)

The last archive seen by the client.
The Ledger will return archives coming
after this one if set, otherwise it
will return the first archives.

***

### GetBlocksArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L187)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L195)

Max number of blocks to fetch.

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L191)

The index of the first block to fetch.

***

### GetBlocksResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L200)

The result of a "get_blocks" call.

#### Properties

##### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L229)

Encoding of instructions for fetching archived blocks.

###### callback

> **callback**: \[`Principal`, `string`\]

Callback to fetch the archived blocks.

###### length

> **length**: `bigint`

The number of blocks that can be fetched.

###### start

> **start**: `bigint`

The index of the first archived block.

##### blocks

> **blocks**: [`Value`](#value)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L220)

List of blocks that were available in the ledger when it processed the call.

The blocks form a contiguous range, with the first block having index
[first_block_index] (see below), and the last block having index
[first_block_index] + len(blocks) - 1.

The block range can be an arbitrary sub-range of the originally requested range.

##### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L205)

System certificate for the hash of the latest block in the chain.
Only present if `get_blocks` is called in a non-replicated query context.

##### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L225)

The total number of blocks in the chain.
If the chain length is positive, the index of the last block is `chain_len - 1`.

##### first\_index

> **first\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L210)

The index of the first block in "blocks".
If the blocks vector is empty, the exact value of this field is not specified.

***

### GetBlocksResult

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L244)

#### Properties

##### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L251)

###### args

> **args**: [`GetBlocksArgs`](#getblocksargs)[]

###### callback

> **callback**: \[`Principal`, `string`\]

##### blocks

> **blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L250)

###### block

> **block**: [`ICRC3Value`](#icrc3value)

###### id

> **id**: `bigint`

##### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L249)

Total number of blocks in the
block log

***

### GetTransactionsRequest

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L267)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L275)

The number of transactions to fetch.

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L271)

The index of the first tx to fetch.

***

### GetTransactionsResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L277)

#### Properties

##### archived\_transactions

> **archived\_transactions**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L304)

Encoding of instructions for fetching archived transactions whose indices fall into the
requested range.

For each entry `e` in [archived_transactions], `[e.from, e.from + len)` is a sub-range
of the originally requested transaction range.

###### callback

> **callback**: \[`Principal`, `string`\]

The function you should call to fetch the archived transactions.
The range of the transaction accessible using this function is given by [from]
and [len] fields above.

###### length

> **length**: `bigint`

The number of transactions you can fetch using the callback.

###### start

> **start**: `bigint`

The index of the first archived transaction you can fetch using the [callback].

##### first\_index

> **first\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L282)

The index of the first transaction in [transactions].
If the transaction vector is empty, the exact value of this field is not specified.

##### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L286)

The total number of transactions in the log.

##### transactions

> **transactions**: [`Transaction`](#transaction)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L296)

List of transaction that were available in the ledger when it processed the call.

The transactions form a contiguous range, with the first transaction having index
[first_index] (see below), and the last transaction having index
[first_index] + len(transactions) - 1.

The transaction range can be an arbitrary sub-range of the originally requested range.

***

### HttpRequest

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L321)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L324)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L325)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L323)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L322)

***

### HttpResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L327)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L328)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L329)

##### status\_code

> **status\_code**: `number`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L330)

***

### Icrc152BurnArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L349)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L352)

##### created\_at\_time

> **created\_at\_time**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L351)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L350)

##### reason

> **reason**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L353)

***

### Icrc152MintArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L362)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L365)

##### created\_at\_time

> **created\_at\_time**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L364)

##### reason

> **reason**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L366)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L363)

***

### icrc21\_consent\_info

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L559)

#### Properties

##### consent\_message

> **consent\_message**: [`icrc21_consent_message`](#icrc21_consent_message)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L561)

##### metadata

> **metadata**: [`icrc21_consent_message_metadata`](#icrc21_consent_message_metadata)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L560)

***

### icrc21\_consent\_message\_metadata

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L568)

#### Properties

##### language

> **language**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L570)

##### utc\_offset\_minutes

> **utc\_offset\_minutes**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L569)

***

### icrc21\_consent\_message\_request

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L572)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L573)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L574)

##### user\_preferences

> **user\_preferences**: [`icrc21_consent_message_spec`](#icrc21_consent_message_spec)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L575)

***

### icrc21\_consent\_message\_spec

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L580)

#### Properties

##### device\_spec

> **device\_spec**: \[\] \| \[\{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:582](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L582)

##### metadata

> **metadata**: [`icrc21_consent_message_metadata`](#icrc21_consent_message_metadata)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L581)

***

### icrc21\_error\_info

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:594](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L594)

#### Properties

##### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:595](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L595)

***

### ICRC3DataCertificate

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:332](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L332)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L336)

See https://internetcomputer.org/docs/current/references/ic-interface-spec#certification

##### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L340)

CBOR encoded hash_tree

***

### InitArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L388)

The initialization parameters of the Ledger

#### Properties

##### archive\_options

> **archive\_options**: `object`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L396)

###### controller\_id

> **controller\_id**: `Principal`

###### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

###### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

###### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

###### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

###### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

###### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: `bigint`

###### trigger\_threshold

> **trigger\_threshold**: `bigint`

##### decimals

> **decimals**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L389)

##### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](#featureflags)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L409)

##### fee\_collector\_account

> **fee\_collector\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L395)

##### index\_principal

> **index\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L407)

##### initial\_balances

> **initial\_balances**: \[[`Account`](#account), `bigint`\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L394)

##### max\_memo\_length

> **max\_memo\_length**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L406)

##### metadata

> **metadata**: \[`string`, [`MetadataValue`](#metadatavalue)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L392)

##### minting\_account

> **minting\_account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L393)

##### token\_name

> **token\_name**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L408)

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L390)

##### transfer\_fee

> **transfer\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L391)

***

### Mint

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L421)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L426)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L425)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L423)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L424)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L422)

***

### StandardRecord

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L439)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L441)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L440)

***

### Transaction

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L449)

#### Properties

##### approve

> **approve**: \[\] \| \[[`Approve`](#approve)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L453)

##### authorized\_burn

> **authorized\_burn**: \[\] \| \[[`AuthorizedBurn`](#authorizedburn)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L454)

##### authorized\_mint

> **authorized\_mint**: \[\] \| \[[`AuthorizedMint`](#authorizedmint)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L455)

##### burn

> **burn**: \[\] \| \[[`Burn`](#burn)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:450](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L450)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`FeeCollector`](#feecollector)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L456)

##### kind

> **kind**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L451)

##### mint

> **mint**: \[\] \| \[[`Mint`](#mint)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L452)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L457)

##### transfer

> **transfer**: \[\] \| \[[`Transfer`](#transfer-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L458)

***

### TransactionRange

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L463)

A prefix of the transaction range specified in the [GetTransactionsRequest] request.

#### Properties

##### transactions

> **transactions**: [`Transaction`](#transaction)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L481)

A prefix of the requested transaction range.
The index of the first transaction is equal to [GetTransactionsRequest.from].

Note that the number of transactions might be less than the requested
[GetTransactionsRequest.length] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the whole range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of transactions can be empty if:

1. [GetTransactionsRequest.length] was zero.
2. [GetTransactionsRequest.from] was larger than the last transaction known to
the canister.

***

### Transfer

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L483)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L489)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L488)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L485)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L486)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L487)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L490)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L484)

***

### TransferArg

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L492)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L498)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L497)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L494)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L496)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L495)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L493)

***

### TransferFromArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L511)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L518)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L517)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L513)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L515)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L516)

##### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L514)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L512)

***

### UpgradeArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L537)

#### Properties

##### change\_archive\_options

> **change\_archive\_options**: \[\] \| \[[`ChangeArchiveOptions`](#changearchiveoptions)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L538)

##### change\_fee\_collector

> **change\_fee\_collector**: \[\] \| \[[`ChangeFeeCollector`](#changefeecollector)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L542)

##### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](#featureflags)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L546)

##### index\_principal

> **index\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:544](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L544)

##### max\_memo\_length

> **max\_memo\_length**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L543)

##### metadata

> **metadata**: \[\] \| \[\[`string`, [`MetadataValue`](#metadatavalue)\][]\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L541)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:545](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L545)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L539)

##### transfer\_fee

> **transfer\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L540)

## Type Aliases

### ApproveError

> **ApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L51)

***

### ApproveResult

> **ApproveResult** = \{ `Ok`: [`BlockIndex`](#blockindex); \} \| \{ `Err`: [`ApproveError`](#approveerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L63)

***

### Block

> **Block** = [`Value`](#value)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L85)

***

### BlockIndex

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L86)

***

### ChangeFeeCollector

> **ChangeFeeCollector** = \{ `SetTo`: [`Account`](#account); \} \| \{ `Unset`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L128)

***

### Duration

> **Duration** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L139)

Number of nanoseconds between two [Timestamp]s.

***

### GetAllowancesError

> **GetAllowancesError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `AccessDenied`: \{ `reason`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L159)

***

### GetArchivesResult

> **GetArchivesResult** = `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L173)

#### Type Declaration

##### canister\_id

> **canister\_id**: `Principal`

The id of the archive

##### end

> **end**: `bigint`

The last block in the archive

##### start

> **start**: `bigint`

The first block in the archive

***

### GetIndexPrincipalError

> **GetIndexPrincipalError** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `IndexPrincipalNotSet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L256)

#### Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

##### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

###### GenericError.description

> **description**: `string`

###### GenericError.error\_code

> **error\_code**: `bigint`

\{ `IndexPrincipalNotSet`: `null`; \}

##### IndexPrincipalNotSet

> **IndexPrincipalNotSet**: `null`

***

### GetIndexPrincipalResult

> **GetIndexPrincipalResult** = \{ `Ok`: `Principal`; \} \| \{ `Err`: [`GetIndexPrincipalError`](#getindexprincipalerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L264)

***

### icrc103\_get\_allowances\_response

> **icrc103\_get\_allowances\_response** = \{ `Ok`: [`Allowance103`](#allowance103)[]; \} \| \{ `Err`: [`GetAllowancesError`](#getallowanceserror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L556)

***

### Icrc152BurnError

> **Icrc152BurnError** = \{ `InvalidAccount`: `string`; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `InsufficientBalance`: \{ `balance`: `bigint`; \}; \} \| \{ `Unauthorized`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L355)

***

### Icrc152BurnResult

> **Icrc152BurnResult** = \{ `Ok`: `bigint`; \} \| \{ `Err`: [`Icrc152BurnError`](#icrc152burnerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L361)

***

### Icrc152MintError

> **Icrc152MintError** = \{ `InvalidAccount`: `string`; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `Unauthorized`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L368)

***

### Icrc152MintResult

> **Icrc152MintResult** = \{ `Ok`: `bigint`; \} \| \{ `Err`: [`Icrc152MintError`](#icrc152minterror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L373)

***

### icrc21\_consent\_message

> **icrc21\_consent\_message** = \{ `FieldsDisplayMessage`: [`FieldsDisplay`](#fieldsdisplay); \} \| \{ `GenericDisplayMessage`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:563](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L563)

***

### icrc21\_consent\_message\_response

> **icrc21\_consent\_message\_response** = \{ `Ok`: [`icrc21_consent_info`](#icrc21_consent_info); \} \| \{ `Err`: [`icrc21_error`](#icrc21_error); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L577)

***

### icrc21\_error

> **icrc21\_error** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `InsufficientPayment`: [`icrc21_error_info`](#icrc21_error_info); \} \| \{ `UnsupportedCanisterCall`: [`icrc21_error_info`](#icrc21_error_info); \} \| \{ `ConsentMessageUnavailable`: [`icrc21_error_info`](#icrc21_error_info); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L584)

#### Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

##### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

###### GenericError.description

> **description**: `string`

###### GenericError.error\_code

> **error\_code**: `bigint`

\{ `InsufficientPayment`: [`icrc21_error_info`](#icrc21_error_info); \}

##### InsufficientPayment

> **InsufficientPayment**: [`icrc21_error_info`](#icrc21_error_info)

\{ `UnsupportedCanisterCall`: [`icrc21_error_info`](#icrc21_error_info); \}

##### UnsupportedCanisterCall

> **UnsupportedCanisterCall**: [`icrc21_error_info`](#icrc21_error_info)

\{ `ConsentMessageUnavailable`: [`icrc21_error_info`](#icrc21_error_info); \}

##### ConsentMessageUnavailable

> **ConsentMessageUnavailable**: [`icrc21_error_info`](#icrc21_error_info)

***

### Icrc21Value

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L374)

***

### ICRC3Value

> **ICRC3Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`ICRC3Value`](#icrc3value)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`ICRC3Value`](#icrc3value)[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L342)

***

### LedgerArg

> **LedgerArg** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](#upgradeargs)\]; \} \| \{ `Init`: [`InitArgs`](#initargs); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L411)

***

### Map

> **Map** = \[`string`, [`Value`](#value)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L412)

***

### MetadataValue

> **MetadataValue** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L416)

The value returned from the [icrc1_metadata] endpoint.

***

### QueryArchiveFn

> **QueryArchiveFn** = `ActorMethod`\<\[[`GetTransactionsRequest`](#gettransactionsrequest)\], [`TransactionRange`](#transactionrange)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L431)

A function for fetching archived transaction.

***

### QueryBlockArchiveFn

> **QueryBlockArchiveFn** = `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`BlockRange`](#blockrange)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L438)

A function for fetching archived blocks.

***

### Subaccount

> **Subaccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L443)

***

### Timestamp

> **Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L447)

Number of nanoseconds since the UNIX epoch in UTC timezone.

***

### Tokens

> **Tokens** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L448)

***

### TransferError

> **TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Tokens`](#tokens); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Tokens`](#tokens); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Tokens`](#tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L500)

***

### TransferFromError

> **TransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: [`Tokens`](#tokens); \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Tokens`](#tokens); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Tokens`](#tokens); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Tokens`](#tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L520)

***

### TransferFromResult

> **TransferFromResult** = \{ `Ok`: [`BlockIndex`](#blockindex); \} \| \{ `Err`: [`TransferFromError`](#transferfromerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L532)

***

### TransferResult

> **TransferResult** = \{ `Ok`: [`BlockIndex`](#blockindex); \} \| \{ `Err`: [`TransferError`](#transfererror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L535)

***

### TxIndex

> **TxIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L536)

***

### Value

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: [`Map`](#map); \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`Value`](#value)[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:548](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L548)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L642)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L643)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
