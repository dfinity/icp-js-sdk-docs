---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [NnsGenesisTokenDid](namespaces/NnsGenesisTokenDid.md)
- [NnsGovernanceDid](namespaces/NnsGovernanceDid.md)
- [NnsGovernanceTestDid](namespaces/NnsGovernanceTestDid.md)
- [SnsWasmDid](namespaces/SnsWasmDid.md)

## Enumerations

### CanisterAction

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:173](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L173)

#### Enumeration Members

##### Start

> **Start**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L178)

##### Stop

> **Stop**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:176](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L176)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L174)

***

### CanisterInstallMode

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:189](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L189)

#### Enumeration Members

##### Install

> **Install**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L191)

##### Reinstall

> **Reinstall**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:192](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L192)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:190](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L190)

##### Upgrade

> **Upgrade**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:193](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L193)

***

### LogVisibility

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:164](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L164)

#### Enumeration Members

##### Controllers

> **Controllers**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L167)

##### Public

> **Public**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:169](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L169)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:165](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L165)

***

### NeuronState

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:7](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L7)

#### Enumeration Members

##### Dissolved

> **Dissolved**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:11](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L11)

##### Dissolving

> **Dissolving**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:10](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L10)

##### Locked

> **Locked**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:9](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L9)

##### Spawning

> **Spawning**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:12](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L12)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:8](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L8)

***

### NeuronType

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:151](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L151)

#### Enumeration Members

##### Ect

> **Ect**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:160](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L160)

##### Seed

> **Seed**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L157)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L154)

***

### NeuronVisibility

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:182](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L182)

#### Enumeration Members

##### Private

> **Private**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:184](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L184)

##### Public

> **Public**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:185](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L185)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:183](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L183)

***

### NnsFunction

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:88](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L88)

#### Enumeration Members

##### AddApiBoundaryNodes

> **AddApiBoundaryNodes**: `43`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:132](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L132)

##### AddFirewallRules

> **AddFirewallRules**: `25`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:114](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L114)

##### AddNodeToSubnet

> **AddNodeToSubnet**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:91](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L91)

##### AddOrRemoveDataCenters

> **AddOrRemoveDataCenters**: `21`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L110)

##### AddSnsWasm

> **AddSnsWasm**: `30`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:119](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L119)

##### AssignNoid

> **AssignNoid**: `8`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:97](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L97)

##### BitcoinSetConfig

> **BitcoinSetConfig**: `39`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:128](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L128)

##### BlessReplicaVersion

> **BlessReplicaVersion**: `5`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:94](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L94)

##### ChangeSubnetMembership

> **ChangeSubnetMembership**: `31`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:120](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L120)

##### ChangeSubnetTypeAssignment

> **ChangeSubnetTypeAssignment**: `33`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:122](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L122)

##### ClearProvisionalWhitelist

> **ClearProvisionalWhitelist**: `12`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L101)

##### CompleteCanisterMigration

> **CompleteCanisterMigration**: `29`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:118](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L118)

##### CreateSubnet

> **CreateSubnet**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L90)

##### DeployGuestosToAllSubnetNodes

> **DeployGuestosToAllSubnetNodes**: `11`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L100)

##### DeployGuestosToAllUnassignedNodes

> **DeployGuestosToAllUnassignedNodes**: `48`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L140)

##### DeployGuestosToSomeApiBoundaryNodes

> **DeployGuestosToSomeApiBoundaryNodes**: `47`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L139)

##### DeployHostosToSomeNodes

> **DeployHostosToSomeNodes**: `51`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L143)

##### HardResetNnsRootToVersion

> **HardResetNnsRootToVersion**: `42`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:131](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L131)

##### IcpXdrConversionRate

> **IcpXdrConversionRate**: `10`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:99](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L99)

##### InsertSnsWasmUpgradePathEntries

> **InsertSnsWasmUpgradePathEntries**: `37`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:126](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L126)

##### NnsCanisterInstall

> **NnsCanisterInstall**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:92](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L92)

##### NnsCanisterUpgrade

> **NnsCanisterUpgrade**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:93](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L93)

##### NnsRootUpgrade

> **NnsRootUpgrade**: `9`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L98)

##### PauseCanisterMigrations

> **PauseCanisterMigrations**: `53`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:145](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L145)

##### PrepareCanisterMigration

> **PrepareCanisterMigration**: `28`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:117](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L117)

##### RecoverSubnet

> **RecoverSubnet**: `6`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:95](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L95)

##### RemoveApiBoundaryNodes

> **RemoveApiBoundaryNodes**: `44`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:133](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L133)

##### RemoveFirewallRules

> **RemoveFirewallRules**: `26`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L115)

##### RemoveNodeOperators

> **RemoveNodeOperators**: `23`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L112)

##### RemoveNodes

> **RemoveNodes**: `18`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L107)

##### RemoveNodesFromSubnet

> **RemoveNodesFromSubnet**: `13`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L102)

##### RerouteCanisterRanges

> **RerouteCanisterRanges**: `24`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L113)

##### RetireReplicaVersion

> **RetireReplicaVersion**: `36`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:125](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L125)

##### ReviseElectedGuestosVersions

> **ReviseElectedGuestosVersions**: `38`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:127](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L127)

##### ReviseElectedHostosVersions

> **ReviseElectedHostosVersions**: `50`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L142)

##### SetAuthorizedSubnetworks

> **SetAuthorizedSubnetworks**: `14`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:103](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L103)

##### SetFirewallConfig

> **SetFirewallConfig**: `15`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L104)

##### SetSubnetOperationalLevel

> **SetSubnetOperationalLevel**: `55`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:147](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L147)

##### StopOrStartNnsCanister

> **StopOrStartNnsCanister**: `17`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L106)

##### SubnetRentalRequest

> **SubnetRentalRequest**: `52`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L144)

##### UninstallCode

> **UninstallCode**: `19`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L108)

##### UnpauseCanisterMigrations

> **UnpauseCanisterMigrations**: `54`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L146)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:89](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L89)

##### UpdateAllowedPrincipals

> **UpdateAllowedPrincipals**: `35`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:124](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L124)

##### ~~UpdateApiBoundaryNodeDomain~~

> **UpdateApiBoundaryNodeDomain**: `45`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:137](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L137)

###### Deprecated

##### UpdateApiBoundaryNodesVersion

> **UpdateApiBoundaryNodesVersion**: `46`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:138](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L138)

##### UpdateConfigOfSubnet

> **UpdateConfigOfSubnet**: `7`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:96](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L96)

##### UpdateElectedHostosVersions

> **UpdateElectedHostosVersions**: `40`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:129](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L129)

##### UpdateFirewallRules

> **UpdateFirewallRules**: `27`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L116)

##### UpdateNodeOperatorConfig

> **UpdateNodeOperatorConfig**: `16`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L105)

##### UpdateNodeRewardsTable

> **UpdateNodeRewardsTable**: `20`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L109)

##### UpdateNodesHostosVersion

> **UpdateNodesHostosVersion**: `41`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:130](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L130)

##### UpdateSnsWasmSnsSubnetIds

> **UpdateSnsWasmSnsSubnetIds**: `34`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:123](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L123)

##### UpdateSshReadOnlyAccessForAllUnassignedNodes

> **UpdateSshReadOnlyAccessForAllUnassignedNodes**: `49`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L141)

##### UpdateSubnetType

> **UpdateSubnetType**: `32`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:121](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L121)

##### UpdateUnassignedNodesConfig

> **UpdateUnassignedNodesConfig**: `22`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L111)

***

### ProposalRewardStatus

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:42](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L42)

#### Enumeration Members

##### AcceptVotes

> **AcceptVotes**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:47](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L47)

##### Ineligible

> **Ineligible**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L57)

##### ReadyToSettle

> **ReadyToSettle**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:51](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L51)

##### Settled

> **Settled**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:54](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L54)

##### Unknown

> **Unknown**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L43)

***

### ProposalStatus

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:62](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L62)

#### Enumeration Members

##### Accepted

> **Accepted**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:73](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L73)

##### Executed

> **Executed**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L76)

##### Failed

> **Failed**: `5`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L79)

##### Open

> **Open**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:66](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L66)

##### Rejected

> **Rejected**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:69](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L69)

##### Unknown

> **Unknown**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:63](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L63)

***

### Topic

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L15)

#### Enumeration Members

##### ApiBoundaryNodeManagement

> **ApiBoundaryNodeManagement**: `15`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L34)

##### ExchangeRate

> **ExchangeRate**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L18)

##### Governance

> **Governance**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L20)

##### IcOsVersionDeployment

> **IcOsVersionDeployment**: `12`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:31](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L31)

##### IcOsVersionElection

> **IcOsVersionElection**: `13`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L32)

##### Kyc

> **Kyc**: `9`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L25)

##### NetworkCanisterManagement

> **NetworkCanisterManagement**: `8`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L24)

##### NetworkEconomics

> **NetworkEconomics**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L19)

##### NeuronManagement

> **NeuronManagement**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L17)

##### NodeAdmin

> **NodeAdmin**: `5`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L21)

##### NodeProviderRewards

> **NodeProviderRewards**: `10`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L26)

##### ParticipantManagement

> **ParticipantManagement**: `6`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L22)

##### ProtocolCanisterManagement

> **ProtocolCanisterManagement**: `17`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L36)

##### ServiceNervousSystemManagement

> **ServiceNervousSystemManagement**: `18`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L37)

##### SnsAndCommunityFund

> **SnsAndCommunityFund**: `14`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:33](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L33)

##### ~~SnsDecentralizationSale~~

> **SnsDecentralizationSale**: `11`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:30](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L30)

###### Deprecated

##### SubnetManagement

> **SubnetManagement**: `7`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L23)

##### SubnetRental

> **SubnetRental**: `16`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L35)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:16](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L16)

***

### Vote

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L82)

#### Enumeration Members

##### No

> **No**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:85](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L85)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:83](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L83)

##### Yes

> **Yes**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/enums/governance.enums.ts#L84)

## Classes

### CouldNotClaimNeuronError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L5)

#### Extends

- [`StakeNeuronError`](#stakeneuronerror)

#### Constructors

##### Constructor

> **new CouldNotClaimNeuronError**(`message?`): [`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`constructor`](#constructor-3)

##### Constructor

> **new CouldNotClaimNeuronError**(`message?`, `options?`): [`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`constructor`](#constructor-3)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`cause`](#cause-3)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`message`](#message-3)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`name`](#name-3)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stack`](#stack-3)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stackTraceLimit`](#stacktracelimit-3)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`captureStackTrace`](#capturestacktrace-6)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`isError`](#iserror-6)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`prepareStackTrace`](#preparestacktrace-6)

***

### GovernanceError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L14)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new GovernanceError**(`detail`): [`GovernanceError`](#governanceerror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L15)

###### Parameters

###### detail

[`GovernanceError`](namespaces/NnsGovernanceDid.md#governanceerror)

###### Returns

[`GovernanceError`](#governanceerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### detail

> `readonly` **detail**: [`GovernanceError`](namespaces/NnsGovernanceDid.md#governanceerror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L15)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### InsufficientAmountError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:7](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L7)

#### Extends

- [`StakeNeuronError`](#stakeneuronerror)

#### Constructors

##### Constructor

> **new InsufficientAmountError**(`minimumAmount`): [`InsufficientAmountError`](#insufficientamounterror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L8)

###### Parameters

###### minimumAmount

`bigint`

###### Returns

[`InsufficientAmountError`](#insufficientamounterror)

###### Overrides

[`StakeNeuronError`](#stakeneuronerror).[`constructor`](#constructor-3)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`cause`](#cause-3)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`message`](#message-3)

##### minimumAmount

> `readonly` **minimumAmount**: `bigint`

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L8)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`name`](#name-3)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stack`](#stack-3)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`stackTraceLimit`](#stacktracelimit-3)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`captureStackTrace`](#capturestacktrace-6)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`isError`](#iserror-6)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`StakeNeuronError`](#stakeneuronerror).[`prepareStackTrace`](#preparestacktrace-6)

***

### NnsGenesisTokenCanister

Defined in: [packages/canisters/src/nns/genesis\_token.canister.ts:11](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/genesis_token.canister.ts#L11)

#### Methods

##### claimNeurons()

> **claimNeurons**(`__namedParameters`): `Promise`\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/genesis\_token.canister.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/genesis_token.canister.ts#L29)

###### Parameters

###### \_\_namedParameters

###### hexPubKey

`string`

###### Returns

`Promise`\<`bigint`[]\>

##### create()

> `static` **create**(`options`): [`NnsGenesisTokenCanister`](#nnsgenesistokencanister)

Defined in: [packages/canisters/src/nns/genesis\_token.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/genesis_token.canister.ts#L16)

###### Parameters

###### options

`CanisterOptions`\<[`_SERVICE`](namespaces/NnsGenesisTokenDid.md#_service)\> = `{}`

###### Returns

[`NnsGenesisTokenCanister`](#nnsgenesistokencanister)

***

### NnsGovernanceCanister

Defined in: [packages/canisters/src/nns/governance.canister.ts:95](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L95)

#### Methods

##### addHotkey()

> **addHotkey**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:915](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L915)

Add hotkey to neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### principal

`Principal`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### autoStakeMaturity()

> **autoStakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:506](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L506)

Changes auto-stake maturity for this Neuron. While on, auto-stake maturity will cause all the maturity generated by voting rewards to this neuron to be automatically staked and contribute to the voting power of the neuron.

###### Parameters

###### params

###### autoStake

`boolean`

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### claimOrRefreshNeuron()

> **claimOrRefreshNeuron**(`request`): `Promise`\<`bigint` \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:984](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L984)

Refreshes neuron and returns neuronId when successful
Uses query call only.

###### Parameters

###### request

[`ClaimOrRefreshNeuronRequest`](#claimorrefreshneuronrequest)

###### Returns

`Promise`\<`bigint` \| `undefined`\>

###### Throws

[UnrecognizedTypeError](#unrecognizedtypeerror)

##### claimOrRefreshNeuronFromAccount()

> **claimOrRefreshNeuronFromAccount**(`__namedParameters`): `Promise`\<`bigint` \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:953](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L953)

Gets the NeuronID of a newly created neuron.

###### Parameters

###### \_\_namedParameters

###### controller?

`Principal`

###### memo

`bigint`

###### Returns

`Promise`\<`bigint` \| `undefined`\>

##### disburse()

> **disburse**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:759](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L759)

Disburse neuron on Account

###### Parameters

###### \_\_namedParameters

###### amount?

`bigint`

###### neuronId

`bigint`

###### toAccountId?

`string`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidAccountIDError

##### disburseMaturity()

> **disburseMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1059](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L1059)

Disburses a neuron's maturity (always certified).
Reference: https://github.com/dfinity/ic/blob/ca2be53acf413bb92478ee7694ac0fb92af07030/rs/sns/governance/src/governance.rs#L1614

###### Parameters

###### params

###### neuronId

`bigint`

The id of the neuron for which to disburse maturity

###### percentageToDisburse

`number`

The percentage of the neuron's maturity to disburse, between 1 and 100 (inclusive).

###### toAccount?

[`Account`](#account)

Optional. The ICRC account to which the maturity will be disbursed. If not provided, the maturity will be disbursed to the caller's Main account.

###### toAccountIdentifier?

`string`

Optional. The account identifier to which the maturity will be disbursed. If not provided, the maturity will be disbursed to the caller's Main account.

###### Returns

`Promise`\<`void`\>

###### Preconditions

- The neuron exists
- The caller is authorized to perform this neuron operation (NeuronPermissionType::DisburseMaturity)
- The given percentage_to_merge is between 1 and 100 (inclusive)
- The neuron's id is not yet in the list of neurons with ongoing operations
- The e8s equivalent of the amount of maturity to disburse is more than the transaction fee.

##### getLatestRewardEvent()

> **getLatestRewardEvent**(`certified`): `Promise`\<[`RewardEvent`](namespaces/NnsGovernanceDid.md#rewardevent)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:316](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L316)

Returns the latest reward event.

If `certified` is true, the request is fetched as an update call, otherwise
it's fetched using a query call.

###### Parameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`RewardEvent`](namespaces/NnsGovernanceDid.md#rewardevent)\>

##### getMetrics()

> **getMetrics**(`__namedParameters`): `Promise`\<[`GovernanceCachedMetrics`](#governancecachedmetrics)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L1105)

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`GovernanceCachedMetrics`](#governancecachedmetrics)\>

##### getNetworkEconomicsParameters()

> **getNetworkEconomicsParameters**(`__namedParameters`): `Promise`\<[`NetworkEconomics`](#networkeconomics-2)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1030](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L1030)

Return the [Network Economics](https://github.com/dfinity/ic/blob/d90e934eb440c730d44d9d9b1ece2cc3f9505d05/rs/nns/governance/proto/ic_nns_governance/pb/v1/governance.proto#L1847).

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`NetworkEconomics`](#networkeconomics-2)\>

##### getNeuron()

> **getNeuron**(`__namedParameters`): `Promise`\<[`NeuronInfo`](#neuroninfo) \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L1009)

Return the data of the neuron provided as id.

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### neuronId

`bigint`

###### Returns

`Promise`\<[`NeuronInfo`](#neuroninfo) \| `undefined`\>

##### getProposal()

> **getProposal**(`__namedParameters`): `Promise`\<[`ProposalInfo`](#proposalinfo) \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:681](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L681)

Returns single proposal info

If `certified` is true (default), the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### \_\_namedParameters

###### certified?

`boolean` = `true`

###### proposalId

`bigint`

###### Returns

`Promise`\<[`ProposalInfo`](#proposalinfo) \| `undefined`\>

##### increaseDissolveDelay()

> **increaseDissolveDelay**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:411](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L411)

Increases dissolve delay of a neuron

###### Parameters

###### \_\_namedParameters

###### additionalDissolveDelaySeconds

`number`

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### joinCommunityFund()

> **joinCommunityFund**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:488](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L488)

Neuron joins the community fund

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### leaveCommunityFund()

> **leaveCommunityFund**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:521](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L521)

Neuron leaves the community fund

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### listKnownNeurons()

> **listKnownNeurons**(`certified`): `Promise`\<[`KnownNeuron`](#knownneuron)[]\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:289](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L289)

Returns the list of neurons who have been approved by the community to
appear as the default followee options.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### certified

`boolean` = `true`

###### Returns

`Promise`\<[`KnownNeuron`](#knownneuron)[]\>

##### listNeurons()

> **listNeurons**(`__namedParameters`): `Promise`\<[`NeuronInfo`](#neuroninfo)[]\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L156)

Returns the list of neurons controlled by the caller.

If an array of neuron IDs is provided, precisely those neurons will be fetched.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

The backend treats `includeEmptyNeurons` as false if absent.

The response from the canister might be paginated. In this case, all pages will be fetched in parallel and
combined into a single return value.

###### Parameters

###### \_\_namedParameters

###### certified

`boolean` = `true`

###### includeEmptyNeurons?

`boolean`

###### includePublicNeurons?

`boolean`

###### neuronIds?

`bigint`[]

###### neuronSubaccounts?

[`NeuronSubaccount`](namespaces/NnsGovernanceDid.md#neuronsubaccount)[]

###### Returns

`Promise`\<[`NeuronInfo`](#neuroninfo)[]\>

##### listProposals()

> **listProposals**(`request`): `Promise`\<[`ListProposalsResponse`](#listproposalsresponse)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:331](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L331)

Returns the list of proposals made for the community to vote on,
paginated and filtered by the request.

If `certified` is true (default), the request is fetched as an update call, otherwise
it is fetched using a query call.

###### Parameters

###### request

the options to list the proposals (limit number of results, topics to search for, etc.)

###### certified?

`boolean` = `true`

###### request

[`ListProposalsRequest`](#listproposalsrequest)

###### Returns

`Promise`\<[`ListProposalsResponse`](#listproposalsresponse)\>

##### makeProposal()

> **makeProposal**(`request`): `Promise`\<`bigint` \| `undefined`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:701](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L701)

Create new proposal

###### Parameters

###### request

[`MakeProposalRequest`](#makeproposalrequest)

###### Returns

`Promise`\<`bigint` \| `undefined`\>

The newly created proposal ID or undefined if the success response returned by the Governance canister does not provide such information.

###### Throws

[GovernanceError](#governanceerror)

##### mergeMaturity()

> **mergeMaturity**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:817](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L817)

Merge Maturity of a neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### percentageToMerge

`number`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidPercentageError

##### mergeNeurons()

> **mergeNeurons**(`request`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:576](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L576)

Merge two neurons

###### Parameters

###### request

###### sourceNeuronId

`bigint`

###### targetNeuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### refreshVotingPower()

> **refreshVotingPower**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:795](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L795)

Refreshes voting power of a neuron
(Resets the `votingPowerRefreshedTimestampSeconds`
parameter of the neuron to the current time).

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### registerVote()

> **registerVote**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:722](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L722)

Registers vote for a proposal from the neuron passed.

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### proposalId

`bigint`

###### vote

[`Vote`](#vote)

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### removeHotkey()

> **removeHotkey**(`__namedParameters`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:935](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L935)

Remove hotkey to neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### principal

`Principal`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### setDissolveDelay()

> **setDissolveDelay**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:437](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L437)

Sets dissolve delay of a neuron.
The new date is now + dissolveDelaySeconds.

###### Parameters

###### neuronId

###### dissolveDelaySeconds

`number`

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### setFollowees()

> **setFollowees**(`followRequest`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:744](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L744)

Edit neuron followees per topic

###### Parameters

###### followRequest

[`FollowRequest`](#followrequest)

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### setFollowing()

> **setFollowing**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:1090](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L1090)

Set the following topics for a neuron.

###### Parameters

###### params

###### neuronId

`bigint`

The id of the neuron for which to set the following topics

###### topicFollowing

[`FolloweesForTopic`](#followeesfortopic)[]

The topics and the followees for each topic that the neuron should follow.

###### Returns

`Promise`\<`void`\>

##### setNodeProviderAccount()

> **setNodeProviderAccount**(`accountIdentifier`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:556](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L556)

Sets node provider reward account.
Where the reward is paid to.

###### Parameters

###### accountIdentifier

`string`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidAccountIDError

##### setVisibility()

> **setVisibility**(`neuronId`, `visibility`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:536](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L536)

Set visibility of a neuron

###### Parameters

###### neuronId

`bigint`

###### visibility

[`NeuronVisibility`](#neuronvisibility)

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### simulateMergeNeurons()

> **simulateMergeNeurons**(`request`): `Promise`\<[`NeuronInfo`](#neuroninfo)\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:593](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L593)

Simulate merging two neurons

###### Parameters

###### request

###### sourceNeuronId

`bigint`

###### targetNeuronId

`bigint`

###### Returns

`Promise`\<[`NeuronInfo`](#neuroninfo)\>

###### Throws

[GovernanceError](#governanceerror)

##### spawnNeuron()

> **spawnNeuron**(`__namedParameters`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:868](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L868)

Merge Maturity of a neuron

###### Parameters

###### \_\_namedParameters

###### neuronId

`bigint`

###### newController?

`Principal`

###### nonce?

`bigint`

###### percentageToSpawn?

`number`

###### Returns

`Promise`\<`bigint`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidPercentageError

##### splitNeuron()

> **splitNeuron**(`__namedParameters`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:638](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L638)

Splits a neuron creating a new one

###### Parameters

###### \_\_namedParameters

###### amount

`bigint`

###### memo?

`bigint`

###### neuronId

`bigint`

###### Returns

`Promise`\<`bigint`\>

newNeuronId

###### Throws

[GovernanceError](#governanceerror)

##### stakeMaturity()

> **stakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:846](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L846)

Stake the maturity of a neuron.

###### Parameters

###### params

###### neuronId

`bigint`

###### percentageToStake?

`number`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

###### Throws

InvalidPercentageError

##### stakeNeuron()

> **stakeNeuron**(`__namedParameters`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L350)

###### Parameters

###### \_\_namedParameters

###### createdAt?

`bigint`

###### fee?

`bigint`

###### fromSubAccount?

`number`[]

###### ledgerCanister

[`IcpLedgerCanister`](../ledger/icp/index.md#icpledgercanister)

###### principal

`Principal`

###### stake

`bigint`

###### Returns

`Promise`\<`bigint`\>

###### Throws

[InsufficientAmountError](#insufficientamounterror)

###### Throws

StakeNeuronTransferError

###### Throws

[CouldNotClaimNeuronError](#couldnotclaimneuronerror)

###### Throws

TransferError

##### startDissolving()

> **startDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:460](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L460)

Start dissolving process of a neuron

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### stopDissolving()

> **stopDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/nns/governance.canister.ts:474](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L474)

Stop dissolving process of a neuron

###### Parameters

###### neuronId

`bigint`

###### Returns

`Promise`\<`void`\>

###### Throws

[GovernanceError](#governanceerror)

##### create()

> `static` **create**(`options`): [`NnsGovernanceCanister`](#nnsgovernancecanister)

Defined in: [packages/canisters/src/nns/governance.canister.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance.canister.ts#L110)

###### Parameters

###### options

[`NnsGovernanceCanisterOptions`](#nnsgovernancecanisteroptions) = `{}`

###### Returns

[`NnsGovernanceCanister`](#nnsgovernancecanister)

***

### NnsGovernanceTestCanister

Defined in: [packages/canisters/src/nns/governance\_test.canister.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance_test.canister.ts#L19)

#### Methods

##### updateNeuron()

> **updateNeuron**(`neuron`): `Promise`\<\[\] \| \[[`GovernanceError`](namespaces/NnsGovernanceTestDid.md#governanceerror)\]\>

Defined in: [packages/canisters/src/nns/governance\_test.canister.ts:51](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance_test.canister.ts#L51)

Test method to update fields of a neuron.

Only available in the governance test canister.

###### Parameters

###### neuron

[`Neuron`](#neuron)

###### Returns

`Promise`\<\[\] \| \[[`GovernanceError`](namespaces/NnsGovernanceTestDid.md#governanceerror)\]\>

##### create()

> `static` **create**(`options`): [`NnsGovernanceTestCanister`](#nnsgovernancetestcanister)

Defined in: [packages/canisters/src/nns/governance\_test.canister.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/governance_test.canister.ts#L28)

###### Parameters

###### options

`CanisterOptions`\<[`_SERVICE`](namespaces/NnsGovernanceTestDid.md#_service)\> = `{}`

###### Returns

[`NnsGovernanceTestCanister`](#nnsgovernancetestcanister)

***

### SnsWasmCanister

Defined in: [packages/canisters/src/nns/sns\_wasm.canister.ts:10](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/sns_wasm.canister.ts#L10)

#### Methods

##### listSnses()

> **listSnses**(`__namedParameters`): `Promise`\<[`DeployedSns`](namespaces/SnsWasmDid.md#deployedsns)[]\>

Defined in: [packages/canisters/src/nns/sns\_wasm.canister.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/sns_wasm.canister.ts#L29)

###### Parameters

###### \_\_namedParameters

###### certified?

`boolean` = `true`

###### Returns

`Promise`\<[`DeployedSns`](namespaces/SnsWasmDid.md#deployedsns)[]\>

##### create()

> `static` **create**(`options`): [`SnsWasmCanister`](#snswasmcanister)

Defined in: [packages/canisters/src/nns/sns\_wasm.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/sns_wasm.canister.ts#L16)

###### Parameters

###### options

`CanisterOptions`\<[`_SERVICE`](namespaces/SnsWasmDid.md#_service)\> = `{}`

###### Returns

[`SnsWasmCanister`](#snswasmcanister)

***

### `abstract` StakeNeuronError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:3](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L3)

#### Extends

- `Error`

#### Extended by

- [`CouldNotClaimNeuronError`](#couldnotclaimneuronerror)
- [`InsufficientAmountError`](#insufficientamounterror)

#### Constructors

##### Constructor

> **new StakeNeuronError**(`message?`): [`StakeNeuronError`](#stakeneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`StakeNeuronError`](#stakeneuronerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new StakeNeuronError**(`message?`, `options?`): [`StakeNeuronError`](#stakeneuronerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`StakeNeuronError`](#stakeneuronerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### UnrecognizedTypeError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L13)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new UnrecognizedTypeError**(`message?`): [`UnrecognizedTypeError`](#unrecognizedtypeerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`UnrecognizedTypeError`](#unrecognizedtypeerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new UnrecognizedTypeError**(`message?`, `options?`): [`UnrecognizedTypeError`](#unrecognizedtypeerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`UnrecognizedTypeError`](#unrecognizedtypeerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### UnsupportedValueError

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L23)

An error used to ensure at compile-time that it's never reached.

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new UnsupportedValueError**(`value`): [`UnsupportedValueError`](#unsupportedvalueerror)

Defined in: [packages/canisters/src/nns/errors/governance.errors.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/errors/governance.errors.ts#L24)

###### Parameters

###### value

`never`

###### Returns

[`UnsupportedValueError`](#unsupportedvalueerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

## Interfaces

### Account

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:186](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L186)

#### Properties

##### owner

> **owner**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:187](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L187)

##### subaccount

> **subaccount**: [`Option`](#option)\<`number`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:188](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L188)

***

### AddHotKey

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:70](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L70)

#### Properties

##### newHotKey

> **newHotKey**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:71](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L71)

***

### AddHotKeyRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:605](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L605)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:606](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L606)

##### principal

> **principal**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:607](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L607)

***

### AddOrRemoveNodeProvider

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:73](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L73)

#### Properties

##### change

> **change**: [`Option`](#option)\<[`Change`](#change-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:74](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L74)

***

### ApproveGenesisKyc

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L76)

#### Properties

##### principals

> **principals**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L77)

***

### Ballot

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L82)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:83](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L83)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L84)

##### votingPower

> **votingPower**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:85](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L85)

***

### BallotInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:87](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L87)

#### Properties

##### proposalId

> **proposalId**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:89](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L89)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:88](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L88)

***

### BlessAlternativeGuestOsVersion

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:337](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L337)

#### Properties

##### baseGuestLaunchMeasurements

> **baseGuestLaunchMeasurements**: [`Option`](#option)\<[`GuestLaunchMeasurements`](#guestlaunchmeasurements)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:340](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L340)

##### chipIds

> **chipIds**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:339](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L339)

##### rootfsHash

> **rootfsHash**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:338](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L338)

***

### CanisterAuthzInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:95](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L95)

#### Properties

##### methodsAuthz

> **methodsAuthz**: [`MethodAuthzInfo`](#methodauthzinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:96](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L96)

***

### CanisterSettings

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:304](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L304)

#### Properties

##### computeAllocation

> **computeAllocation**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:311](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L311)

##### controllers

> **controllers**: [`Option`](#option)\<`string`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:306](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L306)

##### freezingThreshold

> **freezingThreshold**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:305](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L305)

##### logVisibility

> **logVisibility**: [`Option`](#option)\<[`LogVisibility`](#logvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:307](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L307)

##### memoryAllocation

> **memoryAllocation**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:310](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L310)

##### snapshotVisibility

> **snapshotVisibility**: [`Option`](#option)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:308](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L308)

##### wasmMemoryLimit

> **wasmMemoryLimit**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:309](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L309)

##### wasmMemoryThreshold

> **wasmMemoryThreshold**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:312](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L312)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L220)

#### Properties

##### requestedSettingForAutoStakeMaturity

> **requestedSettingForAutoStakeMaturity**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:221](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L221)

***

### ClaimNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:575](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L575)

#### Properties

##### dissolveDelayInSecs

> **dissolveDelayInSecs**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:578](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L578)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:577](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L577)

##### publicKey

> **publicKey**: `DerEncodedPublicKey`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:576](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L576)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:99](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L99)

#### Properties

##### by

> **by**: [`Option`](#option)\<[`By`](#by-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L100)

***

### ClaimOrRefreshNeuronFromAccount

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L102)

#### Properties

##### controller

> **controller**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:103](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L103)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L104)

***

### ClaimOrRefreshNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L106)

#### Properties

##### by

> **by**: [`Option`](#option)\<[`By`](#by-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L108)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L107)

***

### Configure

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L142)

#### Properties

##### operation

> **operation**: [`Option`](#option)\<[`Operation`](#operation-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L143)

***

### Countries

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:737](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L737)

#### Properties

##### isoCodes

> **isoCodes**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:738](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L738)

***

### CreateCanisterAndInstallCode

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L353)

#### Properties

##### canisterSettings

> **canisterSettings**: [`Option`](#option)\<[`CanisterSettings`](#canistersettings)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:355](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L355)

##### hostSubnetId

> **hostSubnetId**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:357](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L357)

##### installArgHash

> **installArgHash**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:356](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L356)

##### wasmModuleHash

> **wasmModuleHash**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:354](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L354)

***

### CreateServiceNervousSystem

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:823](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L823)

#### Properties

##### dappCanisters

> **dappCanisters**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:831](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L831)

##### description

> **description**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:830](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L830)

##### fallbackControllerPrincipalIds

> **fallbackControllerPrincipalIds**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:826](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L826)

##### governanceParameters

> **governanceParameters**: [`Option`](#option)\<[`GovernanceParameters`](#governanceparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:825](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L825)

##### initialTokenDistribution

> **initialTokenDistribution**: [`Option`](#option)\<[`InitialTokenDistribution`](#initialtokendistribution-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:833](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L833)

##### ledgerParameters

> **ledgerParameters**: [`Option`](#option)\<[`LedgerParameters`](#ledgerparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:829](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L829)

##### logo

> **logo**: [`Option`](#option)\<[`Image`](#image)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:827](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L827)

##### name

> **name**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:828](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L828)

##### swapParameters

> **swapParameters**: [`Option`](#option)\<[`SwapParameters`](#swapparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:832](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L832)

##### url

> **url**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:824](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L824)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:776](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L776)

#### Properties

##### additionalCriticalNativeActionIds

> **additionalCriticalNativeActionIds**: [`Option`](#option)\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:777](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L777)

***

### Decimal

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:452](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L452)

#### Properties

##### humanReadable

> **humanReadable**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:453](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L453)

***

### DeregisterKnownNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:214](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L214)

#### Properties

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:215](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L215)

***

### DeveloperDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:813](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L813)

#### Properties

##### developerNeurons

> **developerNeurons**: [`NeuronDistribution`](#neurondistribution)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:814](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L814)

***

### Disburse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:149](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L149)

#### Properties

##### amount

> **amount**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:151](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L151)

##### toAccountId

> **toAccountId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L150)

***

### DisburseMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:190](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L190)

#### Properties

##### percentageToDisburse

> **percentageToDisburse**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:193](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L193)

##### toAccount

> **toAccount**: [`Option`](#option)\<[`Account`](#account)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L191)

##### toAccountIdentifier

> **toAccountIdentifier**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:192](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L192)

***

### DisburseRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:651](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L651)

#### Properties

##### amount?

> `optional` **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:654](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L654)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:652](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L652)

##### toAccountId?

> `optional` **toAccountId**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:653](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L653)

***

### DisburseResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L153)

#### Properties

##### transferBlockHeight

> **transferBlockHeight**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L154)

***

### DisburseToNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L156)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:159](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L159)

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L157)

##### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:158](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L158)

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:160](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L160)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:161](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L161)

***

### DisburseToNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:657](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L657)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:661](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L661)

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:659](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L659)

##### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:660](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L660)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:658](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L658)

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:662](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L662)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:663](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L663)

***

### Duration

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:729](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L729)

#### Properties

##### seconds

> **seconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:730](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L730)

***

### ExecuteNnsFunction

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:173](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L173)

#### Properties

##### nnsFunctionId

> **nnsFunctionId**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L174)

##### payloadBytes?

> `optional` **payloadBytes**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:175](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L175)

***

### Follow

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:177](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L177)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:179](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L179)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L178)

***

### Followees

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:181](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L181)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:183](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L183)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:182](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L182)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:163](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L163)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:165](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L165)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:164](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L164)

***

### FollowRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:628](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L628)

#### Properties

##### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:631](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L631)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:629](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L629)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:630](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L630)

***

### FulfillSubnetRentalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:318](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L318)

#### Properties

##### nodeIds

> **nodeIds**: `Principal`[] \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:321](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L321)

##### replicaVersionId

> **replicaVersionId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:320](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L320)

##### user

> **user**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:319](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L319)

***

### GlobalTimeOfDay

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:733](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L733)

#### Properties

##### secondsAfterUtcMidnight

> **secondsAfterUtcMidnight**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:734](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L734)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:853](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L853)

#### Properties

##### communityFundTotalMaturityE8sEquivalent

> **communityFundTotalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:865](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L865)

##### communityFundTotalStakedE8s

> **communityFundTotalStakedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:893](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L893)

##### decliningVotingPowerNeuronSubsetMetrics

> **decliningVotingPowerNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:877](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L877)

##### dissolvedNeuronsCount

> **dissolvedNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:864](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L864)

##### dissolvedNeuronsE8s

> **dissolvedNeuronsE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:880](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L880)

##### dissolvingNeuronsCount

> **dissolvingNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:890](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L890)

##### dissolvingNeuronsCountBuckets

> **dissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:887](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L887)

##### dissolvingNeuronsE8sBuckets

> **dissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:891](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L891)

##### dissolvingNeuronsE8sBucketsEct

> **dissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:888](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L888)

##### dissolvingNeuronsE8sBucketsSeed

> **dissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:882](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L882)

##### dissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **dissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:858](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L858)

##### dissolvingNeuronsStakedMaturityE8sEquivalentSum

> **dissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:856](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L856)

##### ectNeuronCount

> **ectNeuronCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:861](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L861)

##### fullyLostVotingPowerNeuronSubsetMetrics

> **fullyLostVotingPowerNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:869](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L869)

##### garbageCollectableNeuronsCount

> **garbageCollectableNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:857](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L857)

##### neuronsFundTotalActiveNeurons

> **neuronsFundTotalActiveNeurons**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:872](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L872)

##### neuronsWithInvalidStakeCount

> **neuronsWithInvalidStakeCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:859](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L859)

##### neuronsWithLessThan6MonthsDissolveDelayCount

> **neuronsWithLessThan6MonthsDissolveDelayCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:863](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L863)

##### neuronsWithLessThan6MonthsDissolveDelayE8s

> **neuronsWithLessThan6MonthsDissolveDelayE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:883](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L883)

##### nonSelfAuthenticatingControllerNeuronSubsetMetrics

> **nonSelfAuthenticatingControllerNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:889](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L889)

##### notDissolvingNeuronsCount

> **notDissolvingNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:870](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L870)

##### notDissolvingNeuronsCountBuckets

> **notDissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:860](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L860)

##### notDissolvingNeuronsE8sBuckets

> **notDissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:855](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L855)

##### notDissolvingNeuronsE8sBucketsEct

> **notDissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:875](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L875)

##### notDissolvingNeuronsE8sBucketsSeed

> **notDissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:894](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L894)

##### notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:884](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L884)

##### notDissolvingNeuronsStakedMaturityE8sEquivalentSum

> **notDissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:879](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L879)

##### publicNeuronSubsetMetrics

> **publicNeuronSubsetMetrics**: [`Option`](#option)\<[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:895](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L895)

##### seedNeuronCount

> **seedNeuronCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:897](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L897)

##### spawningNeuronsCount

> **spawningNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:876](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L876)

##### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:896](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L896)

##### totalLockedE8s

> **totalLockedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:871](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L871)

##### totalMaturityDisbursementsInProgressE8sEquivalent

> **totalMaturityDisbursementsInProgressE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:904](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L904)

SDK DIVERGENCE: optional here even though the backend declares the
underlying Candid field as required, so the SDK can decode responses from
canister versions that predate the field (e.g. bundled dfx wasms,
rolling-release mainnet). See the comment on `governance.did`.

##### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:854](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L854)

##### totalStakedE8s

> **totalStakedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:868](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L868)

##### totalStakedE8sEct

> **totalStakedE8sEct**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:878](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L878)

##### totalStakedE8sNonSelfAuthenticatingController

> **totalStakedE8sNonSelfAuthenticatingController**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:881](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L881)

##### totalStakedE8sSeed

> **totalStakedE8sSeed**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:866](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L866)

##### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:874](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L874)

##### totalStakedMaturityE8sEquivalentEct

> **totalStakedMaturityE8sEquivalentEct**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:867](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L867)

##### totalStakedMaturityE8sEquivalentSeed

> **totalStakedMaturityE8sEquivalentSeed**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:892](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L892)

##### totalSupplyIcp

> **totalSupplyIcp**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:862](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L862)

##### totalVotingPowerNonSelfAuthenticatingController

> **totalVotingPowerNonSelfAuthenticatingController**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:873](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L873)

***

### GovernanceParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:762](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L762)

#### Properties

##### customProposalCriticality

> **customProposalCriticality**: [`Option`](#option)\<[`CustomProposalCriticality`](#customproposalcriticality)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:773](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L773)

##### neuronMaximumAgeBonus

> **neuronMaximumAgeBonus**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:767](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L767)

##### neuronMaximumAgeForAgeBonus

> **neuronMaximumAgeForAgeBonus**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L764)

##### neuronMaximumDissolveDelay

> **neuronMaximumDissolveDelay**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:765](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L765)

##### neuronMaximumDissolveDelayBonus

> **neuronMaximumDissolveDelayBonus**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:763](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L763)

##### neuronMinimumDissolveDelayToVote

> **neuronMinimumDissolveDelayToVote**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:766](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L766)

##### neuronMinimumStake

> **neuronMinimumStake**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:768](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L768)

##### proposalInitialVotingPeriod

> **proposalInitialVotingPeriod**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:770](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L770)

##### proposalRejectionFee

> **proposalRejectionFee**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:771](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L771)

##### proposalWaitForQuietDeadlineIncrease

> **proposalWaitForQuietDeadlineIncrease**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:769](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L769)

##### votingRewardParameters

> **votingRewardParameters**: [`Option`](#option)\<[`VotingRewardParameters`](#votingrewardparameters-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:772](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L772)

***

### GuestLaunchMeasurement

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:327](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L327)

#### Properties

##### measurement

> **measurement**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:332](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L332)

SEV-SNP measurement (48 bytes).

##### metadata

> **metadata**: [`Option`](#option)\<[`GuestLaunchMeasurementMetadata`](#guestlaunchmeasurementmetadata-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:328](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L328)

***

### GuestLaunchMeasurementMetadata

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L323)

#### Properties

##### kernelCmdline

> **kernelCmdline**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:324](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L324)

##### vcpuType

> **vcpuType**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:325](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L325)

***

### GuestLaunchMeasurements

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:334](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L334)

#### Properties

##### guestLaunchMeasurements

> **guestLaunchMeasurements**: [`Option`](#option)\<[`GuestLaunchMeasurement`](#guestlaunchmeasurement)[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:335](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L335)

***

### Image

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:745](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L745)

#### Properties

##### base64Encoding

> **base64Encoding**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:746](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L746)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:204](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L204)

#### Properties

##### additionalDissolveDelaySeconds

> **additionalDissolveDelaySeconds**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:205](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L205)

***

### IncreaseDissolveDelayRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:623](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L623)

#### Properties

##### additionalDissolveDelaySeconds

> **additionalDissolveDelaySeconds**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:625](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L625)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:624](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L624)

***

### InitialTokenDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:817](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L817)

#### Properties

##### developerDistribution

> **developerDistribution**: [`Option`](#option)\<[`DeveloperDistribution`](#developerdistribution)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:819](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L819)

##### swapDistribution

> **swapDistribution**: [`Option`](#option)\<[`SwapDistribution`](#swapdistribution-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:820](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L820)

##### treasuryDistribution

> **treasuryDistribution**: [`Option`](#option)\<[`SwapDistribution`](#swapdistribution-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:818](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L818)

***

### InstallCode

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:286](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L286)

#### Properties

##### argHash

> **argHash**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:287](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L287)

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:290](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L290)

##### installMode

> **installMode**: [`Option`](#option)\<[`CanisterInstallMode`](#canisterinstallmode)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:291](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L291)

##### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:289](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L289)

##### wasmModuleHash

> **wasmModuleHash**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:288](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L288)

***

### InstallCodeRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:293](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L293)

#### Properties

##### arg

> **arg**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:294](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L294)

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:297](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L297)

##### installMode

> **installMode**: [`Option`](#option)\<[`CanisterInstallMode`](#canisterinstallmode)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:298](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L298)

##### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L296)

##### wasmModule

> **wasmModule**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:295](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L295)

***

### JoinCommunityFundRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:666](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L666)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:667](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L667)

***

### KnownNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:207](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L207)

#### Properties

##### committed\_topics

> **committed\_topics**: [`Option`](#option)\<(\[\] \| \[[`TopicToFollow`](namespaces/NnsGovernanceDid.md#topictofollow)\])[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:212](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L212)

##### description

> **description**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L210)

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:208](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L208)

##### links

> **links**: [`Option`](#option)\<`string`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:211](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L211)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:209](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L209)

***

### LedgerParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:749](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L749)

#### Properties

##### tokenLogo

> **tokenLogo**: [`Option`](#option)\<[`Image`](#image)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:752](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L752)

##### tokenName

> **tokenName**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:753](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L753)

##### tokenSymbol

> **tokenSymbol**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:751](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L751)

##### transactionFee

> **transactionFee**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:750](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L750)

***

### ListNodeProvidersResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:721](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L721)

#### Properties

##### nodeProviders

> **nodeProviders**: [`NodeProvider`](#nodeprovider-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:722](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L722)

***

### ListProposalsRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:226](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L226)

#### Properties

##### beforeProposal

> **beforeProposal**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:235](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L235)

##### excludeTopic

> **excludeTopic**: [`Topic`](#topic)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:249](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L249)

##### includeAllManageNeuronProposals

> **includeAllManageNeuronProposals**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:254](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L254)

##### includeRewardStatus

> **includeRewardStatus**: [`ProposalRewardStatus`](#proposalrewardstatus)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:243](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L243)

##### includeStatus

> **includeStatus**: [`ProposalStatus`](#proposalstatus)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:259](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L259)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:230](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L230)

##### omitLargeFields?

> `optional` **omitLargeFields**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:265](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L265)

##### returnSelfDescribingAction?

> `optional` **returnSelfDescribingAction**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:268](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L268)

***

### ListProposalsResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:270](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L270)

#### Properties

##### proposals

> **proposals**: [`ProposalInfo`](#proposalinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:271](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L271)

***

### LoadCanisterSnapshot

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:348](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L348)

#### Properties

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L349)

##### snapshotId

> **snapshotId**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L350)

***

### MakeExecuteNnsFunctionProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:712](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L712)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:713](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L713)

##### nnsFunction

> **nnsFunction**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:717](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L717)

##### payload

> **payload**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:718](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L718)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:715](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L715)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:714](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L714)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:716](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L716)

***

### MakeMotionProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:678](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L678)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:679](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L679)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:683](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L683)

##### text

> **text**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:682](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L682)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:680](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L680)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:681](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L681)

***

### MakeNetworkEconomicsProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:686](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L686)

#### Properties

##### networkEconomics

> **networkEconomics**: [`NetworkEconomics`](#networkeconomics-2)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:691](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L691)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:687](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L687)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:689](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L689)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:688](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L688)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:690](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L690)

***

### MakeProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:670](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L670)

#### Properties

##### action

> **action**: [`ProposalActionRequest`](#proposalactionrequest)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:675](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L675)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:671](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L671)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:674](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L674)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:672](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L672)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:673](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L673)

***

### MakeProposalResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:273](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L273)

#### Properties

##### proposalId

> **proposalId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:274](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L274)

***

### MakeRewardNodeProviderProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:694](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L694)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:700](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L700)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:695](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L695)

##### nodeProvider

> **nodeProvider**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:699](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L699)

##### rewardMode

> **rewardMode**: [`Option`](#option)\<[`RewardMode`](#rewardmode-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:701](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L701)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:697](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L697)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:696](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L696)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:698](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L698)

***

### MakeSetDefaultFolloweesProposalRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:704](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L704)

#### Properties

##### followees

> **followees**: [`Followees`](#followees-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:709](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L709)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:705](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L705)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:707](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L707)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:706](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L706)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:708](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L708)

***

### ManageNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:276](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L276)

#### Properties

##### command

> **command**: [`Option`](#option)\<[`Command`](#command-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:278](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L278)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L277)

##### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](#option)\<[`NeuronIdOrSubaccount`](#neuronidorsubaccount-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:279](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L279)

***

### ManageNeuronRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:281](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L281)

#### Properties

##### command

> **command**: [`Option`](#option)\<[`ManageNeuronCommandRequest`](#manageneuroncommandrequest)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L283)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:282](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L282)

##### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](#option)\<[`NeuronIdOrSubaccount`](#neuronidorsubaccount-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:284](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L284)

***

### MaturityDisbursement

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:196](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L196)

#### Properties

##### accountIdentifierToDisburseTo

> **accountIdentifierToDisburseTo**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:200](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L200)

##### accountToDisburseTo

> **accountToDisburseTo**: [`Option`](#option)\<[`Account`](#account)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:199](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L199)

##### amountE8s

> **amountE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:198](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L198)

##### finalizeDisbursementTimestampSeconds

> **finalizeDisbursementTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:201](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L201)

##### timestampOfDisbursementSeconds

> **timestampOfDisbursementSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:197](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L197)

***

### Merge

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:360](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L360)

#### Properties

##### sourceNeuronId

> **sourceNeuronId**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:361](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L361)

***

### MergeMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:370](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L370)

#### Properties

##### percentageToMerge

> **percentageToMerge**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:371](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L371)

***

### MergeMaturityRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:373](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L373)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:374](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L374)

##### percentageToMerge

> **percentageToMerge**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:375](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L375)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:377](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L377)

#### Properties

##### mergedMaturityE8s

> **mergedMaturityE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:378](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L378)

##### newStakeE8s

> **newStakeE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:379](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L379)

***

### MergeRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L363)

#### Properties

##### sourceNeuronId

> **sourceNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:364](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L364)

##### targetNeuronId

> **targetNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:365](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L365)

***

### MethodAuthzChange

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:381](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L381)

#### Properties

##### canister

> **canister**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:384](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L384)

##### methodName

> **methodName**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:383](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L383)

##### operation

> **operation**: [`AuthzChangeOp`](#authzchangeop)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:385](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L385)

##### principal

> **principal**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:382](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L382)

***

### MethodAuthzInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:387](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L387)

#### Properties

##### methodName

> **methodName**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:388](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L388)

##### principalIds

> **principalIds**: `ArrayBuffer`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:389](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L389)

***

### Motion

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:391](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L391)

#### Properties

##### motionText

> **motionText**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:392](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L392)

***

### NetworkEconomics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:424](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L424)

#### Properties

##### maximumNodeProviderRewards

> **maximumNodeProviderRewards**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:432](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L432)

##### maxProposalsToKeepPerTopic

> **maxProposalsToKeepPerTopic**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:426](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L426)

##### minimumIcpXdrRate

> **minimumIcpXdrRate**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:431](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L431)

##### neuronManagementFeePerProposal

> **neuronManagementFeePerProposal**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:427](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L427)

##### neuronMinimumStake

> **neuronMinimumStake**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:425](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L425)

##### neuronsFundEconomics

> **neuronsFundEconomics**: [`Option`](#option)\<[`NeuronsFundEconomics`](#neuronsfundeconomics-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:433](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L433)

##### neuronSpawnDissolveDelaySeconds

> **neuronSpawnDissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:430](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L430)

##### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:428](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L428)

##### transactionFee

> **transactionFee**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:429](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L429)

##### votingPowerEconomics

> **votingPowerEconomics**: [`Option`](#option)\<[`VotingPowerEconomics`](#votingpowereconomics-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:434](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L434)

***

### Neuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:455](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L455)

#### Properties

##### accountIdentifier

> **accountIdentifier**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:471](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L471)

##### agingSinceTimestampSeconds

> **agingSinceTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:467](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L467)

##### autoStakeMaturity

> **autoStakeMaturity**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:465](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L465)

##### cachedNeuronStake

> **cachedNeuronStake**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:463](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L463)

##### controller

> **controller**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:459](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L459)

##### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:464](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L464)

##### decidingVotingPower

> **decidingVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:479](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L479)

##### dissolveState

> **dissolveState**: [`Option`](#option)\<[`DissolveState`](#dissolvestate-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:474](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L474)

##### eightYearGangBonusBaseE8s

> **eightYearGangBonusBaseE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:480](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L480)

##### followees

> **followees**: [`Followees`](#followees-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:475](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L475)

##### hotKeys

> **hotKeys**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:470](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L470)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:456](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L456)

##### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:472](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L472)

##### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:461](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L461)

##### maturityDisbursementsInProgress

> **maturityDisbursementsInProgress**: [`Option`](#option)\<[`MaturityDisbursement`](#maturitydisbursement)[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:473](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L473)

##### maturityE8sEquivalent

> **maturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:466](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L466)

##### neuronFees

> **neuronFees**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:469](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L469)

##### neuronType

> **neuronType**: [`Option`](#option)\<[`NeuronType`](#neurontype)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:457](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L457)

##### notForProfit

> **notForProfit**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:462](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L462)

##### potentialVotingPower

> **potentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:478](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L478)

##### recentBallots

> **recentBallots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:460](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L460)

##### spawnAtTimesSeconds

> **spawnAtTimesSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:468](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L468)

##### stakedMaturityE8sEquivalent

> **stakedMaturityE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:458](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L458)

##### visibility

> **visibility**: [`Option`](#option)\<[`NeuronVisibility`](#neuronvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:476](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L476)

##### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:477](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L477)

***

### NeuronBasketConstructionParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:780](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L780)

#### Properties

##### count

> **count**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:782](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L782)

##### dissolveDelayInterval

> **dissolveDelayInterval**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:781](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L781)

***

### NeuronDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:805](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L805)

#### Properties

##### controller

> **controller**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:806](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L806)

##### dissolveDelay

> **dissolveDelay**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:807](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L807)

##### memo

> **memo**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:808](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L808)

##### stake

> **stake**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:810](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L810)

##### vestingPeriod

> **vestingPeriod**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:809](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L809)

***

### NeuronInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:485](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L485)

#### Properties

##### ageSeconds

> **ageSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:499](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L499)

##### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:490](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L490)

##### decidingVotingPower

> **decidingVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:496](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L496)

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:487](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L487)

##### eightYearGangBonusBaseE8s

> **eightYearGangBonusBaseE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:498](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L498)

##### fullNeuron

> **fullNeuron**: [`Option`](#option)\<[`Neuron`](#neuron)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:500](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L500)

##### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:492](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L492)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:486](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L486)

##### neuronType

> **neuronType**: [`Option`](#option)\<[`NeuronType`](#neurontype)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:489](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L489)

##### potentialVotingPower

> **potentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:497](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L497)

##### recentBallots

> **recentBallots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:488](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L488)

##### retrievedAtTimestampSeconds

> **retrievedAtTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:493](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L493)

##### state

> **state**: [`NeuronState`](#neuronstate)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:491](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L491)

##### visibility

> **visibility**: [`Option`](#option)\<[`NeuronVisibility`](#neuronvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:501](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L501)

##### votingPower

> **votingPower**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:494](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L494)

##### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:495](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L495)

***

### NeuronsFundEconomics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:441](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L441)

#### Properties

##### maximumIcpXdrRate

> **maximumIcpXdrRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:442](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L442)

##### maxTheoreticalNeuronsFundParticipationAmountXdr

> **maxTheoreticalNeuronsFundParticipationAmountXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:444](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L444)

##### minimumIcpXdrRate

> **minimumIcpXdrRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:445](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L445)

##### neuronsFundMatchedFundingCurveCoefficients

> **neuronsFundMatchedFundingCurveCoefficients**: [`Option`](#option)\<[`NeuronsFundMatchedFundingCurveCoefficients`](#neuronsfundmatchedfundingcurvecoefficients-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:443](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L443)

***

### NeuronsFundMatchedFundingCurveCoefficients

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:447](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L447)

#### Properties

##### contributionThresholdXdr

> **contributionThresholdXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:448](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L448)

##### fullParticipationMilestoneXdr

> **fullParticipationMilestoneXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:450](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L450)

##### oneThirdParticipationMilestoneXdr

> **oneThirdParticipationMilestoneXdr**: [`Option`](#option)\<[`Decimal`](#decimal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:449](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L449)

***

### NeuronSubsetMetrics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:836](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L836)

#### Properties

##### count

> **count**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:841](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L841)

##### countBuckets

> **countBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:850](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L850)

##### decidingVotingPowerBuckets

> **decidingVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:842](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L842)

##### maturityE8sEquivalentBuckets

> **maturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:838](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L838)

##### potentialVotingPowerBuckets

> **potentialVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:849](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L849)

##### stakedE8sBuckets

> **stakedE8sBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:847](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L847)

##### stakedMaturityE8sEquivalentBuckets

> **stakedMaturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:846](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L846)

##### totalDecidingVotingPower

> **totalDecidingVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:845](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L845)

##### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:837](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L837)

##### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:844](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L844)

##### totalStakedE8s

> **totalStakedE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:840](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L840)

##### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:843](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L843)

##### totalVotingPower

> **totalVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:848](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L848)

##### votingPowerBuckets

> **votingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:839](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L839)

***

### NnsGovernanceCanisterOptions

Defined in: [packages/canisters/src/nns/types/governance.options.ts:5](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance.options.ts#L5)

#### Extends

- `CanisterOptions`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

###### Inherited from

`CanisterOptions.agent`

##### canisterId?

> `optional` **canisterId**: `Principal`

Defined in: packages/utils/dist/types/canister.options.d.ts:5

###### Inherited from

`CanisterOptions.canisterId`

##### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

###### Inherited from

`CanisterOptions.certifiedServiceOverride`

##### hardwareWallet?

> `optional` **hardwareWallet**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance.options.ts:8](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance.options.ts#L8)

##### oldListNeuronsServiceOverride?

> `optional` **oldListNeuronsServiceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

Defined in: [packages/canisters/src/nns/types/governance.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance.options.ts#L9)

##### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/NnsGovernanceDid.md#_service)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

###### Inherited from

`CanisterOptions.serviceOverride`

***

### NodeProvider

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:504](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L504)

#### Properties

##### id

> **id**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:505](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L505)

##### rewardAccount

> **rewardAccount**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:506](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L506)

***

### OpenSnsTokenSwap

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L394)

#### Properties

##### communityFundInvestmentE8s

> **communityFundInvestmentE8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L395)

##### params

> **params**: [`Option`](#option)\<\{ `maxDirectParticipationIcpE8s`: [`Option`](#option)\<`bigint`\>; `maxIcpE8s`: `bigint`; `maxParticipantIcpE8s`: `bigint`; `minDirectParticipationIcpE8s`: [`Option`](#option)\<`bigint`\>; `minIcpE8s`: `bigint`; `minParticipantIcpE8s`: `bigint`; `minParticipants`: `number`; `neuronBasketConstructionParameters`: [`Option`](#option)\<\{ `count`: `bigint`; `dissolve_delay_interval_seconds`: `bigint`; \}\>; `saleDelaySeconds`: [`Option`](#option)\<`bigint`\>; `snsTokenE8s`: `bigint`; `swapDueTimestampSeconds`: `bigint`; \}\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:397](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L397)

##### targetSwapCanisterId

> **targetSwapCanisterId**: [`Option`](#option)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:396](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L396)

***

### Percentage

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:725](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L725)

#### Properties

##### basisPoints

> **basisPoints**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:726](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L726)

***

### Proposal

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:526](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L526)

#### Properties

##### action

> **action**: [`Option`](#option)\<[`Action`](#action-3)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:529](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L529)

##### selfDescribingAction

> **selfDescribingAction**: [`Option`](#option)\<[`SelfDescribingProposalAction`](#selfdescribingproposalaction)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:531](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L531)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:530](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L530)

##### title

> **title**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:527](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L527)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:528](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L528)

***

### ProposalInfo

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:535](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L535)

#### Properties

##### ballots

> **ballots**: [`Ballot`](#ballot)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:537](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L537)

##### deadlineTimestampSeconds

> **deadlineTimestampSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:543](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L543)

##### decidedTimestampSeconds

> **decidedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:542](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L542)

##### executedTimestampSeconds

> **executedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:547](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L547)

##### failedTimestampSeconds

> **failedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:541](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L541)

##### id

> **id**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:536](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L536)

##### latestTally

> **latestTally**: [`Option`](#option)\<[`Tally`](#tally)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:544](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L544)

##### proposal

> **proposal**: [`Option`](#option)\<[`Proposal`](#proposal)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:545](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L545)

##### proposalTimestampSeconds

> **proposalTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:539](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L539)

##### proposer

> **proposer**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:546](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L546)

##### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:538](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L538)

##### rewardEventRound

> **rewardEventRound**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:540](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L540)

##### rewardStatus

> **rewardStatus**: [`ProposalRewardStatus`](#proposalrewardstatus)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:550](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L550)

##### status

> **status**: [`ProposalStatus`](#proposalstatus)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:549](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L549)

##### topic

> **topic**: [`Topic`](#topic)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:548](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L548)

##### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:551](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L551)

***

### RefreshVotingPower

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L146)

***

### RegisterVote

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:554](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L554)

#### Properties

##### proposal

> **proposal**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:556](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L556)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:555](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L555)

***

### RegisterVoteRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:634](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L634)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:635](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L635)

##### proposal

> **proposal**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:637](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L637)

##### vote

> **vote**: [`Vote`](#vote)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:636](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L636)

***

### RemoveHotKey

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:558](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L558)

#### Properties

##### hotKeyToRemove

> **hotKeyToRemove**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:559](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L559)

***

### RemoveHotKeyRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:610](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L610)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:611](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L611)

##### principal

> **principal**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:612](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L612)

***

### RewardNodeProvider

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:581](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L581)

#### Properties

##### amountE8s

> **amountE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:584](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L584)

##### nodeProvider

> **nodeProvider**: [`Option`](#option)\<[`NodeProvider`](#nodeprovider-1)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:582](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L582)

##### rewardMode

> **rewardMode**: [`Option`](#option)\<[`RewardMode`](#rewardmode-2)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:583](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L583)

***

### RewardNodeProviders

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:564](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L564)

#### Properties

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:566](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L566)

##### useRegistryDerivedRewards

> **useRegistryDerivedRewards**: `boolean` \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:565](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L565)

***

### RewardToAccount

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:568](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L568)

#### Properties

##### toAccount

> **toAccount**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:569](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L569)

***

### RewardToNeuron

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:571](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L571)

#### Properties

##### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:572](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L572)

***

### SelfDescribingProposalAction

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:520](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L520)

#### Properties

##### typeDescription

> **typeDescription**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:521](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L521)

##### typeName

> **typeName**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:522](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L522)

##### value

> **value**: [`Option`](#option)\<[`SelfDescribingValue`](namespaces/NnsGovernanceDid.md#selfdescribingvalue)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:523](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L523)

***

### SetDefaultFollowees

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:586](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L586)

#### Properties

##### defaultFollowees

> **defaultFollowees**: [`Followees`](#followees-1)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:587](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L587)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:217](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L217)

#### Properties

##### dissolveTimestampSeconds

> **dissolveTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L218)

***

### SetFollowing

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L167)

#### Properties

##### topicFollowing

> **topicFollowing**: [`FolloweesForTopic`](#followeesfortopic)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:168](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L168)

***

### SetSnsTokenSwapOpenTimeWindow

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:415](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L415)

#### Properties

##### request

> **request**: [`Option`](#option)\<\{ `openTimeWindow`: [`Option`](#option)\<\{ `endTimestampSeconds`: `bigint`; `startTimestampSeconds`: `bigint`; \}\>; \}\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:416](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L416)

##### swapCanisterId

> **swapCanisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:422](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L422)

***

### SetVisibility

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:223](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L223)

#### Properties

##### visibility

> **visibility**: [`Option`](#option)\<[`NeuronVisibility`](#neuronvisibility)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L224)

***

### Spawn

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:589](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L589)

#### Properties

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:590](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L590)

##### percentageToSpawn

> **percentageToSpawn**: `number` \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:591](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L591)

***

### SpawnRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:640](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L640)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:641](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L641)

##### newController

> **newController**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:642](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L642)

##### percentageToSpawn?

> `optional` **percentageToSpawn**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:643](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L643)

***

### Split

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:594](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L594)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:595](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L595)

##### memo

> **memo**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:596](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L596)

***

### SplitRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:646](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L646)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:648](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L648)

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:647](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L647)

***

### StakeMaturity

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:367](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L367)

#### Properties

##### percentageToStake

> **percentageToStake**: [`Option`](#option)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:368](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L368)

***

### StartDissolvingRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:615](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L615)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:616](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L616)

***

### StopDissolvingRequest

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:619](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L619)

#### Properties

##### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:620](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L620)

***

### StopOrStartCanister

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L300)

#### Properties

##### action

> **action**: [`Option`](#option)\<[`CanisterAction`](#canisteraction)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:302](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L302)

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:301](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L301)

***

### SwapDistribution

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:801](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L801)

#### Properties

##### total

> **total**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:802](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L802)

***

### SwapParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:784](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L784)

#### Properties

##### confirmationText

> **confirmationText**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:788](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L788)

##### duration

> **duration**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:786](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L786)

##### maxDirectParticipationIcp

> **maxDirectParticipationIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:796](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L796)

##### maximumIcp

> **maximumIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:794](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L794)

##### maximumParticipantIcp

> **maximumParticipantIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:789](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L789)

##### minDirectParticipationIcp

> **minDirectParticipationIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:797](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L797)

##### minimumIcp

> **minimumIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:791](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L791)

##### minimumParticipantIcp

> **minimumParticipantIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:792](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L792)

##### minimumParticipants

> **minimumParticipants**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:785](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L785)

##### neuronBasketConstructionParameters

> **neuronBasketConstructionParameters**: [`Option`](#option)\<[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:787](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L787)

##### neuronsFundInvestmentIcp

> **neuronsFundInvestmentIcp**: [`Option`](#option)\<[`Tokens`](#tokens)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:790](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L790)

##### neuronsFundParticipation

> **neuronsFundParticipation**: [`Option`](#option)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:798](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L798)

##### restrictedCountries

> **restrictedCountries**: [`Option`](#option)\<[`Countries`](#countries)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:795](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L795)

##### startTime

> **startTime**: [`Option`](#option)\<[`GlobalTimeOfDay`](#globaltimeofday)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:793](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L793)

***

### TakeCanisterSnapshot

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:343](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L343)

#### Properties

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:345](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L345)

##### replaceSnapshot

> **replaceSnapshot**: [`Option`](#option)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:344](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L344)

***

### Tally

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:598](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L598)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:599](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L599)

##### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:602](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L602)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:601](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L601)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:600](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L600)

***

### Tokens

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:741](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L741)

#### Properties

##### e8s

> **e8s**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:742](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L742)

***

### UpdateCanisterSettings

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:314](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L314)

#### Properties

##### canisterId

> **canisterId**: [`Option`](#option)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:315](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L315)

##### settings

> **settings**: [`Option`](#option)\<[`CanisterSettings`](#canistersettings)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:316](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L316)

***

### VotingPowerEconomics

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:436](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L436)

#### Properties

##### clearFollowingAfterSeconds

> **clearFollowingAfterSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:439](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L439)

##### neuronMinimumDissolveDelayToVoteSeconds

> **neuronMinimumDissolveDelayToVoteSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:438](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L438)

##### startReducingVotingPowerAfterSeconds

> **startReducingVotingPowerAfterSeconds**: [`Option`](#option)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:437](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L437)

***

### VotingRewardParameters

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:756](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L756)

#### Properties

##### finalRewardRate

> **finalRewardRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:759](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L759)

##### initialRewardRate

> **initialRewardRate**: [`Option`](#option)\<[`Percentage`](#percentage)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:758](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L758)

##### rewardRateTransitionDuration

> **rewardRateTransitionDuration**: [`Option`](#option)\<[`Duration`](#duration)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:757](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L757)

## Type Aliases

### Action

> **Action** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ManageNeuron`: [`ManageNeuron`](#manageneuron); \} \| \{ `InstallCode`: [`InstallCode`](#installcode); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `ApproveGenesisKyc`: [`ApproveGenesisKyc`](#approvegenesiskyc); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics-2); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `SetDefaultFollowees`: [`SetDefaultFollowees`](#setdefaultfollowees); \} \| \{ `Motion`: [`Motion`](#motion); \} \| \{ `SetSnsTokenSwapOpenTimeWindow`: [`SetSnsTokenSwapOpenTimeWindow`](#setsnstokenswapopentimewindow); \} \| \{ `OpenSnsTokenSwap`: [`OpenSnsTokenSwap`](#opensnstokenswap); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCode`](#createcanisterandinstallcode); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L25)

***

### AuthzChangeOp

> **AuthzChangeOp** = \{ `Authorize`: \{ `addSelf`: `boolean`; \}; \} \| \{ `Deauthorize`: `null`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L79)

***

### By

> **By** = \{ `NeuronIdOrSubaccount`: `Record`\<`string`, `never`\>; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount-2); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:91](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L91)

***

### CanisterIdString

> **CanisterIdString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/common.ts#L1)

***

### Change

> **Change** = \{ `ToRemove`: [`NodeProvider`](#nodeprovider-1); \} \| \{ `ToAdd`: [`NodeProvider`](#nodeprovider-1); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L98)

***

### Command

> **Command** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote-2); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing-2); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity-2); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity-2); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `Disburse`: [`Disburse`](#disburse-2); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower-2); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity-2); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L110)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:170](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L170)

***

### E8s

> **E8s** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/common.ts#L3)

***

### ManageNeuronCommandRequest

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote-2); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing-2); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity-2); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity-2); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](#makeproposalrequest); \} \| \{ `Disburse`: [`Disburse`](#disburse-2); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity-2); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:127](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L127)

***

### Memo

> **Memo** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:4](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/common.ts#L4)

***

### NeuronId

> **NeuronId** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:2](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/common.ts#L2)

***

### NeuronIdOrSubaccount

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `number`[]; \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-23); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:482](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L482)

***

### Operation

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](#removehotkey-2); \} \| \{ `AddHotKey`: [`AddHotKey`](#addhotkey-2); \} \| \{ `StopDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `StartDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay-2); \} \| \{ `JoinCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `LeaveCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `SetVisibility`: [`SetVisibility`](#setvisibility-2); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:508](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L508)

***

### Option

> **Option**\<`T`\> = `T` \| `undefined`

Defined in: [packages/canisters/src/nns/types/common.ts:7](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/common.ts#L7)

#### Type Parameters

##### T

`T`

***

### PrincipalString

> **PrincipalString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:5](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/common.ts#L5)

***

### ProposalActionRequest

> **ProposalActionRequest** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](#manageneuronrequest); \} \| \{ `InstallCode`: [`InstallCodeRequest`](#installcoderequest); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `ApproveGenesisKyc`: [`ApproveGenesisKyc`](#approvegenesiskyc); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics-2); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:50](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L50)

***

### ProposalId

> **ProposalId** = `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:533](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L533)

***

### RewardMode

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](#rewardtoneuron); \} \| \{ `RewardToAccount`: [`RewardToAccount`](#rewardtoaccount); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:561](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/governance_converters.ts#L561)

***

### SnsWasmCanisterOptions

> **SnsWasmCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](namespaces/SnsWasmDid.md#_service)\>

Defined in: [packages/canisters/src/nns/types/sns\_wasm.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/types/sns_wasm.options.ts#L4)

## Functions

### accountIdentifierFromBytes()

> **accountIdentifierFromBytes**(`accountIdentifier`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/account_identifier.utils.ts#L19)

#### Parameters

##### accountIdentifier

`Uint8Array`

#### Returns

`string`

***

### accountIdentifierToBytes()

> **accountIdentifierToBytes**(`accountIdentifier`): `Uint8Array`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/account_identifier.utils.ts#L15)

#### Parameters

##### accountIdentifier

`string`

#### Returns

`Uint8Array`

***

### ineligibleNeurons()

> **ineligibleNeurons**(`params`): [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/neurons.utils.ts#L37)

Filter the neurons that are ineligible to vote to a proposal.

This feature needs the ballots of the proposal to contains accurate data.
If the proposal has settled, as the ballots of the proposal are emptied for archive purpose, the function might return a list of ineligible neurons that are actually neurons that have not voted but would have been eligible.

Long story short, check the status of the proposal before using this function.

#### Parameters

##### params

###### neurons

[`NeuronInfo`](#neuroninfo)[]

The neurons to filter.

###### proposal

[`ProposalInfo`](#proposalinfo)

The proposal to match against the selected neurons.

#### Returns

[`NeuronInfo`](#neuroninfo)[]

***

### memoToNeuronAccountIdentifier()

> **memoToNeuronAccountIdentifier**(`__namedParameters`): [`AccountIdentifier`](../ledger/icp/index.md#accountidentifier)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/neurons.utils.ts#L122)

#### Parameters

##### \_\_namedParameters

###### controller

`Principal`

###### governanceCanisterId

`Principal`

###### memo

`bigint`

#### Returns

[`AccountIdentifier`](../ledger/icp/index.md#accountidentifier)

***

### memoToNeuronSubaccount()

> **memoToNeuronSubaccount**(`__namedParameters`): [`SubAccount`](../ledger/icp/index.md#subaccount)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/neurons.utils.ts#L101)

#### Parameters

##### \_\_namedParameters

###### controller

`Principal`

###### memo

`bigint`

#### Returns

[`SubAccount`](../ledger/icp/index.md#subaccount)

***

### principalToAccountIdentifier()

> **principalToAccountIdentifier**(`principal`, `subAccount?`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/account_identifier.utils.ts#L24)

#### Parameters

##### principal

`Principal`

##### subAccount?

`Uint8Array`\<`ArrayBufferLike`\>

#### Returns

`string`

***

### votableNeurons()

> **votableNeurons**(`params`): [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:66](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/neurons.utils.ts#L66)

Filter the neurons that can vote for a proposal - i.e. the neurons that have not voted yet and are eligible

#### Parameters

##### params

###### neurons

[`NeuronInfo`](#neuroninfo)[]

The neurons to filter.

###### proposal

[`ProposalInfo`](#proposalinfo)

The proposal to match against the selected neurons.

#### Returns

[`NeuronInfo`](#neuroninfo)[]

***

### votedNeurons()

> **votedNeurons**(`params`): [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:89](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/nns/utils/neurons.utils.ts#L89)

Filter the neurons that have voted for a proposal.

#### Parameters

##### params

###### neurons

[`NeuronInfo`](#neuroninfo)[]

The neurons to filter.

###### proposal

[`ProposalInfo`](#proposalinfo)

The proposal for which some neurons might have already voted.

#### Returns

[`NeuronInfo`](#neuroninfo)[]
