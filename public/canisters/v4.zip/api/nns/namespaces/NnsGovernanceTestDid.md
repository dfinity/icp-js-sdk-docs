---
title: NnsGovernanceTestDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1470](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1470)

#### Properties

##### claim\_gtc\_neurons

> **claim\_gtc\_neurons**: `ActorMethod`\<\[`Principal`, [`NeuronId`](#neuronid-1)[]\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1471](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1471)

##### claim\_or\_refresh\_neuron\_from\_account

> **claim\_or\_refresh\_neuron\_from\_account**: `ActorMethod`\<\[[`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount)\], [`ClaimOrRefreshNeuronFromAccountResponse`](#claimorrefreshneuronfromaccountresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1472](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1472)

##### create\_neuron

> **create\_neuron**: `ActorMethod`\<\[[`CreateNeuronRequest`](#createneuronrequest)\], [`CreateNeuronResponse`](#createneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1476](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1476)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1477](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1477)

##### get\_full\_neuron

> **get\_full\_neuron**: `ActorMethod`\<\[`bigint`\], [`Result_2`](#result_2)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1478](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1478)

##### get\_full\_neuron\_by\_id\_or\_subaccount

> **get\_full\_neuron\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\], [`Result_2`](#result_2)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1479](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1479)

##### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](#rewardevent)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1483](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1483)

##### get\_maturity\_modulation

> **get\_maturity\_modulation**: `ActorMethod`\<\[[`GetMaturityModulationRequest`](#getmaturitymodulationrequest)\], [`GetMaturityModulationResponse`](#getmaturitymodulationresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1484](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1484)

##### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[\], [`Result_3`](#result_3)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1488](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1488)

##### get\_monthly\_node\_provider\_rewards

> **get\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], [`Result_4`](#result_4)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1489](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1489)

##### get\_most\_recent\_monthly\_node\_provider\_rewards

> **get\_most\_recent\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], \[\] \| \[[`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1490](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1490)

##### get\_network\_economics\_parameters

> **get\_network\_economics\_parameters**: `ActorMethod`\<\[\], [`NetworkEconomics`](#networkeconomics)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1494](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1494)

##### get\_neuron\_ids

> **get\_neuron\_ids**: `ActorMethod`\<\[\], `BigUint64Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1495](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1495)

##### get\_neuron\_index

> **get\_neuron\_index**: `ActorMethod`\<\[[`GetNeuronIndexRequest`](#getneuronindexrequest)\], [`GetNeuronIndexResult`](#getneuronindexresult)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1496](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1496)

##### get\_neuron\_info

> **get\_neuron\_info**: `ActorMethod`\<\[`bigint`\], [`Result_5`](#result_5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1497](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1497)

##### get\_neuron\_info\_by\_id\_or\_subaccount

> **get\_neuron\_info\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\], [`Result_5`](#result_5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1498](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1498)

##### get\_neurons\_fund\_audit\_info

> **get\_neurons\_fund\_audit\_info**: `ActorMethod`\<\[[`GetNeuronsFundAuditInfoRequest`](#getneuronsfundauditinforequest)\], [`GetNeuronsFundAuditInfoResponse`](#getneuronsfundauditinforesponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1502](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1502)

##### get\_node\_provider\_by\_caller

> **get\_node\_provider\_by\_caller**: `ActorMethod`\<\[`null`\], [`Result_7`](#result_7)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1506](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1506)

##### get\_pending\_proposals

> **get\_pending\_proposals**: `ActorMethod`\<\[\[\] \| \[[`GetPendingProposalsRequest`](#getpendingproposalsrequest)\]\], [`ProposalInfo`](#proposalinfo)[]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1507](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1507)

##### get\_proposal\_info

> **get\_proposal\_info**: `ActorMethod`\<\[`bigint`\], \[\] \| \[[`ProposalInfo`](#proposalinfo)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1511](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1511)

##### get\_restore\_aging\_summary

> **get\_restore\_aging\_summary**: `ActorMethod`\<\[\], [`RestoreAgingSummary`](#restoreagingsummary)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1512](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1512)

##### list\_known\_neurons

> **list\_known\_neurons**: `ActorMethod`\<\[\], [`ListKnownNeuronsResponse`](#listknownneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1513](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1513)

##### list\_neuron\_votes

> **list\_neuron\_votes**: `ActorMethod`\<\[[`ListNeuronVotesRequest`](#listneuronvotesrequest)\], [`ListNeuronVotesResponse`](#listneuronvotesresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1514](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1514)

##### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](#listneurons)\], [`ListNeuronsResponse`](#listneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1518](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1518)

##### list\_node\_provider\_rewards

> **list\_node\_provider\_rewards**: `ActorMethod`\<\[[`ListNodeProviderRewardsRequest`](#listnodeproviderrewardsrequest)\], [`ListNodeProviderRewardsResponse`](#listnodeproviderrewardsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1519](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1519)

##### list\_node\_providers

> **list\_node\_providers**: `ActorMethod`\<\[\], [`ListNodeProvidersResponse`](#listnodeprovidersresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1523](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1523)

##### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposalInfoRequest`](#listproposalinforequest)\], [`ListProposalInfoResponse`](#listproposalinforesponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1524](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1524)

##### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](#manageneuronrequest)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1528](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1528)

##### settle\_community\_fund\_participation

> **settle\_community\_fund\_participation**: `ActorMethod`\<\[[`SettleCommunityFundParticipation`](#settlecommunityfundparticipation)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1529](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1529)

##### settle\_neurons\_fund\_participation

> **settle\_neurons\_fund\_participation**: `ActorMethod`\<\[[`SettleNeuronsFundParticipationRequest`](#settleneuronsfundparticipationrequest)\], [`SettleNeuronsFundParticipationResponse`](#settleneuronsfundparticipationresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1533](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1533)

##### simulate\_manage\_neuron

> **simulate\_manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](#manageneuronrequest)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1537](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1537)

##### transfer\_gtc\_neuron

> **transfer\_gtc\_neuron**: `ActorMethod`\<\[[`NeuronId`](#neuronid-1), [`NeuronId`](#neuronid-1)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1541](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1541)

##### update\_neuron

> **update\_neuron**: `ActorMethod`\<\[[`Neuron`](#neuron)\], \[\] \| \[[`GovernanceError`](#governanceerror)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1545](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1545)

The following are methods for feature = "test"

##### update\_node\_provider

> **update\_node\_provider**: `ActorMethod`\<\[[`UpdateNodeProvider`](#updatenodeprovider)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1546](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1546)

***

### Account

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L13)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L15)

***

### AccountIdentifier

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L17)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L18)

***

### AddHotKey

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L43)

#### Properties

##### new\_hot\_key

> **new\_hot\_key**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L44)

***

### AddOrRemoveNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L46)

#### Properties

##### change

> **change**: \[\] \| \[[`Change`](#change-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L47)

***

### Amount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L49)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L50)

***

### ApproveGenesisKyc

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L52)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L53)

***

### Ballot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L55)

#### Properties

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L56)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L57)

***

### BallotInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L59)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L61)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L60)

***

### BlessAlternativeGuestOsVersion

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L67)

Declares an approved set of alternative replica virtual machine software for
disaster recovery purposes.

#### Properties

##### base\_guest\_launch\_measurements

> **base\_guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurements`](#guestlaunchmeasurements)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L84)

The version being replaced by this (alternative version) must match this
field (or one of the possibilities therein).

(Here, we refer to the version being replaced as the "base" version.)

##### chip\_ids

> **chip\_ids**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L77)

AMD Secure Processor chip IDs that are allowed to run this software.
Each chip ID must be exactly 64 bytes.

##### rootfs\_hash

> **rootfs\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L72)

Hexadecimal fingerprint of the recovery rootfs.
Must contain only hexadecimal characters (0-9, A-F, a-f).

***

### Canister

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L90)

#### Properties

##### id

> **id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L91)

***

### CanisterSettings

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L93)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L101)

##### controllers

> **controllers**: \[\] \| \[[`Controllers`](#controllers-2)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L96)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L94)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L97)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L100)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L98)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L99)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L95)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L103)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L106)

##### cycles

> **cycles**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L108)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L105)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L109)

##### memory\_size

> **memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L107)

##### module\_hash

> **module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L110)

##### status

> **status**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L104)

***

### CanisterSummary

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L112)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L114)

##### status

> **status**: \[\] \| \[[`CanisterStatusResultV2`](#canisterstatusresultv2)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L113)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L117)

#### Properties

##### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L118)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L120)

#### Properties

##### by

> **by**: \[\] \| \[[`By`](#by-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L121)

***

### ClaimOrRefreshNeuronFromAccount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L123)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L124)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L125)

***

### ClaimOrRefreshNeuronFromAccountResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L127)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L128)

***

### ClaimOrRefreshResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L130)

#### Properties

##### refreshed\_neuron\_id

> **refreshed\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L131)

***

### Committed

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L160)

#### Properties

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L163)

##### total\_direct\_contribution\_icp\_e8s

> **total\_direct\_contribution\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L161)

##### total\_neurons\_fund\_contribution\_icp\_e8s

> **total\_neurons\_fund\_contribution\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L162)

***

### Committed\_1

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L165)

#### Properties

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L168)

##### total\_direct\_participation\_icp\_e8s

> **total\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L166)

##### total\_neurons\_fund\_participation\_icp\_e8s

> **total\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L167)

***

### Configure

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L170)

#### Properties

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L171)

***

### Controllers

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L173)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L174)

***

### Countries

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L176)

#### Properties

##### iso\_codes

> **iso\_codes**: `string`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L177)

***

### CreateCanisterAndInstallCode

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L179)

#### Properties

##### canister\_settings

> **canister\_settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L181)

##### host\_subnet\_id

> **host\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L183)

##### install\_arg\_hash

> **install\_arg\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L182)

##### wasm\_module\_hash

> **wasm\_module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L180)

***

### CreateCanisterAndInstallCodeOk

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L185)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L186)

***

### CreateCanisterAndInstallCodeRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L188)

#### Properties

##### canister\_settings

> **canister\_settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L190)

##### host\_subnet\_id

> **host\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L192)

##### install\_arg

> **install\_arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L191)

##### wasm\_module

> **wasm\_module**: \[\] \| \[[`WasmModule`](#wasmmodule)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L189)

***

### CreatedNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L243)

#### Properties

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L244)

***

### CreateNeuronRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L198)

Request to create a new neuron using ICRC-2 transfer_from.
The caller must have previously approved the governance canister to spend the specified amount.

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L218)

Required. The amount of ICP to stake in e8s.

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L214)

Whether to automatically stake maturity. Defaults to false.

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L202)

The controller of the new neuron. Defaults to the caller.

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L210)

The dissolve delay in seconds. Defaults to 7 days. Clamped to [0, 8 years].

##### dissolving

> **dissolving**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L226)

Whether the neuron should start dissolving immediately. Defaults to false.

##### followees

> **followees**: \[\] \| \[[`SetFollowing`](#setfollowing)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L222)

The followees to set for the new neuron. Defaults to the network's default followees.

##### source\_subaccount

> **source\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L206)

The subaccount of the caller to transfer ICP from. Defaults to the default subaccount.

***

### CreateServiceNervousSystem

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L231)

#### Properties

##### dapp\_canisters

> **dapp\_canisters**: [`Canister`](#canister)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L239)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L238)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L234)

##### governance\_parameters

> **governance\_parameters**: \[\] \| \[[`GovernanceParameters`](#governanceparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L233)

##### initial\_token\_distribution

> **initial\_token\_distribution**: \[\] \| \[[`InitialTokenDistribution`](#initialtokendistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L241)

##### ledger\_parameters

> **ledger\_parameters**: \[\] \| \[[`LedgerParameters`](#ledgerparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L237)

##### logo

> **logo**: \[\] \| \[[`Image`](#image)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L235)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L236)

##### swap\_parameters

> **swap\_parameters**: \[\] \| \[[`SwapParameters`](#swapparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L240)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L232)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L246)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: \[\] \| \[`BigUint64Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L247)

***

### DateRangeFilter

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L249)

#### Properties

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L251)

##### start\_timestamp\_seconds

> **start\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L250)

***

### DateUtc

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L253)

#### Properties

##### day

> **day**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L254)

##### month

> **month**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L255)

##### year

> **year**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L256)

***

### Decimal

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L258)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L259)

***

### DeregisterKnownNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L261)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L262)

***

### DerivedProposalInformation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L264)

#### Properties

##### swap\_background\_information

> **swap\_background\_information**: \[\] \| \[[`SwapBackgroundInformation`](#swapbackgroundinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L265)

***

### DeveloperDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L267)

#### Properties

##### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](#neurondistribution)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L268)

***

### Disburse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L270)

#### Properties

##### amount

> **amount**: \[\] \| \[[`Amount`](#amount)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L272)

##### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L271)

***

### DisburseMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L274)

#### Properties

##### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L277)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L276)

##### to\_account\_identifier

> **to\_account\_identifier**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L275)

***

### DisburseMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L279)

#### Properties

##### amount\_disbursed\_e8s

> **amount\_disbursed\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L280)

***

### DisburseResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L282)

#### Properties

##### transfer\_block\_height

> **transfer\_block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L283)

***

### DisburseToNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L285)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L288)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L286)

##### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L287)

##### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L289)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L290)

***

### Duration

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L295)

#### Properties

##### seconds

> **seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L296)

***

### ExecuteNnsFunction

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L298)

#### Properties

##### nns\_function

> **nns\_function**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L299)

##### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L300)

***

### Follow

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:302](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L302)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L304)

##### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L303)

***

### Followees

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L306)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L307)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L309)

#### Properties

##### followees

> **followees**: \[\] \| \[[`NeuronId`](#neuronid-1)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L311)

##### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:310](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L310)

***

### FulfillSubnetRentalRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L317)

Creates a rented subnet from a rental request (in the Subnet Rental
canister).

#### Properties

##### initial\_dkg\_subnet\_id

> **initial\_dkg\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L322)

Optional subnet that should handle `setup_initial_dkg` for subnet creation.
If not set, handling defaults to the NNS subnet.

##### node\_ids

> **node\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L353)

Which nodes will be members of the subnet.

##### replica\_version\_id

> **replica\_version\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L349)

What software the nodes will run.

This must be approved by a prior proposal to bless an IC OS version.

This is a FULL git commit ID in the ic repo. (Therefore, it must be a 40
character hexidecimal string, not an abbreviated git commit ID.)

One way to find a suitable value is with the following command:

ic-admin \
get-subnet 0 \
--nns-urls https://nns.ic0.app \
| grep replica_version_id

Where to obtain a recent version of ic-admin:

https://github.com/dfinity/ic/releases/latest

##### user

> **user**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L329)

Identifies which rental request to fulfill.

(Identifying the rental request by user works, because a user can have at
most one rental request in the Subnet Rental canister).

***

### GetMaturityModulationResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L356)

#### Properties

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L357)

***

### GetNeuronIndexRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L359)

#### Properties

##### exclusive\_start\_neuron\_id

> **exclusive\_start\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L361)

##### page\_size

> **page\_size**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L360)

***

### GetNeuronsFundAuditInfoRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L366)

#### Properties

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L367)

***

### GetNeuronsFundAuditInfoResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L369)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_6`](#result_6)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L370)

***

### GetPendingProposalsRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L372)

#### Properties

##### return\_self\_describing\_action

> **return\_self\_describing\_action**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L373)

***

### GlobalTimeOfDay

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L375)

#### Properties

##### seconds\_after\_utc\_midnight

> **seconds\_after\_utc\_midnight**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L376)

***

### Governance

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L378)

#### Properties

##### cached\_daily\_maturity\_modulation\_basis\_points

> **cached\_daily\_maturity\_modulation\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L386)

##### default\_followees

> **default\_followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L379)

##### economics

> **economics**: \[\] \| \[[`NetworkEconomics`](#networkeconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L387)

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L397)

##### in\_flight\_commands

> **in\_flight\_commands**: \[`bigint`, [`NeuronInFlightCommand`](#neuroninflightcommand)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L395)

##### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](#rewardevent)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L390)

##### maturity\_modulation\_last\_updated\_at\_timestamp\_seconds

> **maturity\_modulation\_last\_updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L381)

##### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](#governancecachedmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L383)

##### most\_recent\_monthly\_node\_provider\_rewards

> **most\_recent\_monthly\_node\_provider\_rewards**: \[\] \| \[[`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L380)

##### neuron\_management\_voting\_period\_seconds

> **neuron\_management\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L384)

##### neurons

> **neurons**: \[`bigint`, [`Neuron`](#neuron)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L396)

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L385)

##### proposals

> **proposals**: \[`bigint`, [`ProposalData`](#proposaldata)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L393)

##### restore\_aging\_summary

> **restore\_aging\_summary**: \[\] \| \[[`RestoreAgingSummary`](#restoreagingsummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L388)

##### short\_voting\_period\_seconds

> **short\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L392)

##### spawning\_neurons

> **spawning\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L389)

##### to\_claim\_transfers

> **to\_claim\_transfers**: [`NeuronStakeTransfer`](#neuronstaketransfer)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L391)

##### wait\_for\_quiet\_threshold\_seconds

> **wait\_for\_quiet\_threshold\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L382)

##### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](#xdrconversionrate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L394)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L399)

#### Properties

##### community\_fund\_total\_maturity\_e8s\_equivalent

> **community\_fund\_total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L413)

##### community\_fund\_total\_staked\_e8s

> **community\_fund\_total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L451)

##### declining\_voting\_power\_neuron\_subset\_metrics

> **declining\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L433)

##### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L412)

##### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L436)

##### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L448)

##### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L443)

##### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L449)

##### dissolving\_neurons\_e8s\_buckets\_ect

> **dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L444)

##### dissolving\_neurons\_e8s\_buckets\_seed

> **dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L438)

##### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L404)

##### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L402)

##### ect\_neuron\_count

> **ect\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L409)

##### fully\_lost\_voting\_power\_neuron\_subset\_metrics

> **fully\_lost\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L425)

##### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L403)

##### neurons\_fund\_total\_active\_neurons

> **neurons\_fund\_total\_active\_neurons**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L428)

##### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L407)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L411)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L439)

##### non\_self\_authenticating\_controller\_neuron\_subset\_metrics

> **non\_self\_authenticating\_controller\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L445)

##### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L426)

##### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L408)

##### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L401)

##### not\_dissolving\_neurons\_e8s\_buckets\_ect

> **not\_dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L431)

##### not\_dissolving\_neurons\_e8s\_buckets\_seed

> **not\_dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L452)

##### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L440)

##### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L435)

##### public\_neuron\_subset\_metrics

> **public\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L453)

##### seed\_neuron\_count

> **seed\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L455)

##### spawning\_neurons\_count

> **spawning\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L432)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L454)

##### total\_locked\_e8s

> **total\_locked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L427)

##### total\_maturity\_disbursements\_in\_progress\_e8s\_equivalent

> **total\_maturity\_disbursements\_in\_progress\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L423)

SDK DIVERGENCE: the backend declares this as `nat64` (required) since
ic@3ef6b6f876 (2026-03-06). We keep it `opt nat64` here so the SDK can
still decode responses from canister versions (e.g. bundled dfx wasms,
rolling-release mainnet) that predate the field. Revert to `nat64` once
every consumed canister version is guaranteed to include it.

##### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L400)

##### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L424)

##### total\_staked\_e8s\_ect

> **total\_staked\_e8s\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L434)

##### total\_staked\_e8s\_non\_self\_authenticating\_controller

> **total\_staked\_e8s\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L437)

##### total\_staked\_e8s\_seed

> **total\_staked\_e8s\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L414)

##### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L430)

##### total\_staked\_maturity\_e8s\_equivalent\_ect

> **total\_staked\_maturity\_e8s\_equivalent\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L415)

##### total\_staked\_maturity\_e8s\_equivalent\_seed

> **total\_staked\_maturity\_e8s\_equivalent\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:450](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L450)

##### total\_supply\_icp

> **total\_supply\_icp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L410)

##### total\_voting\_power\_non\_self\_authenticating\_controller

> **total\_voting\_power\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L429)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L457)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L458)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L459)

***

### GovernanceParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:461](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L461)

#### Properties

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L470)

##### neuron\_maximum\_age\_bonus

> **neuron\_maximum\_age\_bonus**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L466)

##### neuron\_maximum\_age\_for\_age\_bonus

> **neuron\_maximum\_age\_for\_age\_bonus**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L463)

##### neuron\_maximum\_dissolve\_delay

> **neuron\_maximum\_dissolve\_delay**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L464)

##### neuron\_maximum\_dissolve\_delay\_bonus

> **neuron\_maximum\_dissolve\_delay\_bonus**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L462)

##### neuron\_minimum\_dissolve\_delay\_to\_vote

> **neuron\_minimum\_dissolve\_delay\_to\_vote**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L465)

##### neuron\_minimum\_stake

> **neuron\_minimum\_stake**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L467)

##### proposal\_initial\_voting\_period

> **proposal\_initial\_voting\_period**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L469)

##### proposal\_rejection\_fee

> **proposal\_rejection\_fee**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L471)

##### proposal\_wait\_for\_quiet\_deadline\_increase

> **proposal\_wait\_for\_quiet\_deadline\_increase**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L468)

##### voting\_reward\_parameters

> **voting\_reward\_parameters**: \[\] \| \[[`VotingRewardParameters`](#votingrewardparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L472)

***

### GuestLaunchMeasurement

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L474)

#### Properties

##### measurement

> **measurement**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L482)

SEV-SNP measurement (48 bytes).

##### metadata

> **metadata**: \[\] \| \[[`GuestLaunchMeasurementMetadata`](#guestlaunchmeasurementmetadata-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L478)

Metadata associated with the measurement.

***

### GuestLaunchMeasurementMetadata

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L484)

#### Properties

##### kernel\_cmdline

> **kernel\_cmdline**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L488)

Kernel command line used for this measurement.

##### vcpu\_type

> **vcpu\_type**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L492)

Virtual CPU type used for this measurement.

***

### GuestLaunchMeasurements

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L494)

#### Properties

##### guest\_launch\_measurements

> **guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurement`](#guestlaunchmeasurement)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L495)

***

### IdealMatchedParticipationFunction

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L497)

#### Properties

##### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L498)

***

### Image

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L500)

#### Properties

##### base64\_encoding

> **base64\_encoding**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L501)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L503)

#### Properties

##### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L504)

***

### InitialTokenDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L506)

#### Properties

##### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](#developerdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L508)

##### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](#swapdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L509)

##### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`SwapDistribution`](#swapdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L507)

***

### InstallCode

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L511)

#### Properties

##### arg\_hash

> **arg\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L515)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L514)

##### install\_mode

> **install\_mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L516)

##### skip\_stopping\_before\_installing

> **skip\_stopping\_before\_installing**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L512)

##### wasm\_module\_hash

> **wasm\_module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L513)

***

### InstallCodeRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L518)

#### Properties

##### arg

> **arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L519)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L527)

##### install\_mode

> **install\_mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L528)

##### skip\_stopping\_before\_installing

> **skip\_stopping\_before\_installing**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L526)

##### wasm\_module

> **wasm\_module**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L525)

If we add support for chunked WASMs later, the WasmModule type should
probably be used in place of this field in order to be consistent with
CreateCanisterAndInstallCodeRequest.

***

### KnownNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L530)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L531)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L532)

***

### KnownNeuronData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L534)

#### Properties

##### committed\_topics

> **committed\_topics**: \[\] \| \[(\[\] \| \[[`TopicToFollow`](#topictofollow)\])[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L542)

Topics that the known neuron is committed to always vote on.
Note regarding the type: the first `opt` makes it so that the field can be renamed/deprecated
in the future, and the second `opt` makes it so that an older client not recognizing a new
variant can still get the rest of the `vec`.

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L543)

##### links

> **links**: \[\] \| \[`string`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L547)

Links related to the known neuron. Can be links to social URLs (OpenChat, X, etc.), or a homepage.

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L535)

***

### LedgerParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L549)

#### Properties

##### token\_logo

> **token\_logo**: \[\] \| \[[`Image`](#image)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L552)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L553)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L551)

##### transaction\_fee

> **transaction\_fee**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L550)

***

### ListKnownNeuronsResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L555)

#### Properties

##### known\_neurons

> **known\_neurons**: [`KnownNeuron`](#knownneuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L556)

***

### ListNeurons

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:595](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L595)

Parameters of the list_neurons method.

#### Properties

##### include\_empty\_neurons\_readable\_by\_caller

> **include\_empty\_neurons\_readable\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L611)

Only has an effect when include_neurons_readable_by_caller.

##### include\_neurons\_readable\_by\_caller

> **include\_neurons\_readable\_by\_caller**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:613](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L613)

##### include\_public\_neurons\_in\_full\_neurons

> **include\_public\_neurons\_in\_full\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:602](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L602)

When a public neuron is a member of the result set, include it in the
full_neurons field (of ListNeuronsResponse). This does not affect which
neurons are part of the result set.

##### neuron\_ids

> **neuron\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:606](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L606)

These fields select neurons to be in the result set.

##### neuron\_subaccounts

> **neuron\_subaccounts**: \[\] \| \[[`NeuronSubaccount`](#neuronsubaccount)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:612](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L612)

##### page\_number

> **page\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:607](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L607)

##### page\_size

> **page\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L596)

***

### ListNeuronsResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L618)

Output of the list_neurons method.

#### Properties

##### full\_neurons

> **full\_neurons**: [`Neuron`](#neuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L631)

If the caller has the necessary special privileges (or the neuron is
public, and the request sets include_public_neurons_in_full_neurons to
true), then all the information about the neurons in the result set is made
available here.

##### neuron\_infos

> **neuron\_infos**: \[`bigint`, [`NeuronInfo`](#neuroninfo)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L624)

Per the NeuronInfo type, this is a redacted view of the neurons in the
result set consisting of information that require no special privileges to
view.

##### total\_pages\_available

> **total\_pages\_available**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L632)

***

### ListNeuronVotesRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:558](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L558)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:563](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L563)

Only fetch the voting history for proposal whose id `< before_proposal`. This can be used as a
pagination token - pass the minimum proposal id as `before_proposal` for the next page.

##### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L568)

The maximum number of votes to fetch. The maximum number allowed is 500, and 500 will be used
if is set as either null or > 500.

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L573)

The neuron id for which the voting history will be returned. Currently, the voting history is
only recorded for known neurons.

***

### ListNodeProviderRewardsRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L634)

#### Properties

##### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](#daterangefilter)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L635)

***

### ListNodeProviderRewardsResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:637](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L637)

#### Properties

##### rewards

> **rewards**: [`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L638)

***

### ListNodeProvidersResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L640)

#### Properties

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L641)

***

### ListProposalInfoRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L643)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L647)

##### exclude\_topic

> **exclude\_topic**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:649](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L649)

##### include\_all\_manage\_neuron\_proposals

> **include\_all\_manage\_neuron\_proposals**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:650](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L650)

##### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L645)

##### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L651)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:648](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L648)

##### omit\_large\_fields

> **omit\_large\_fields**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:646](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L646)

##### return\_self\_describing\_action

> **return\_self\_describing\_action**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L644)

***

### ListProposalInfoResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L653)

#### Properties

##### proposal\_info

> **proposal\_info**: [`ProposalInfo`](#proposalinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L654)

***

### LoadCanisterSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L656)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:657](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L657)

##### snapshot\_id

> **snapshot\_id**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L658)

***

### MakeProposalRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:660](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L660)

#### Properties

##### action

> **action**: \[\] \| \[[`ProposalActionRequest`](#proposalactionrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:663](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L663)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:664](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L664)

##### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L662)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:661](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L661)

***

### MakeProposalResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L666)

#### Properties

##### message

> **message**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:667](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L667)

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:668](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L668)

***

### ManageNeuronProposal

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:693](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L693)

Not to be confused with ManageNeuronRequest. This is only used to represent a manage neuron proposal.
(Yes, this is very structurally similar to that, but not actually exactly equivalent)

#### Properties

##### command

> **command**: \[\] \| \[[`ManageNeuronProposalCommand`](#manageneuronproposalcommand-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:695](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L695)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:694](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L694)

##### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:696](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L696)

***

### ManageNeuronRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:720](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L720)

Parameters of the manage_neuron method.

#### Properties

##### command

> **command**: \[\] \| \[[`ManageNeuronCommandRequest`](#manageneuroncommandrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L728)

What operation to perform on the neuron.

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:724](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L724)

Deprecated. Use neuron_id_or_subaccount instead.

##### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L732)

Which neuron to operate on.

***

### ManageNeuronResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:737](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L737)

Output of the manage_neuron method.

#### Properties

##### command

> **command**: \[\] \| \[[`Command_1`](#command_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L742)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.

***

### MaturityDisbursement

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:744](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L744)

#### Properties

##### account\_identifier\_to\_disburse\_to

> **account\_identifier\_to\_disburse\_to**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:745](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L745)

##### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:748](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L748)

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L747)

##### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L749)

##### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:746](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L746)

***

### MaturityModulation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L751)

#### Properties

##### current\_value\_permyriad

> **current\_value\_permyriad**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L752)

##### updated\_at\_timestamp\_seconds

> **updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:753](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L753)

***

### Merge

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:755](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L755)

#### Properties

##### source\_neuron\_id

> **source\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:756](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L756)

***

### MergeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:758](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L758)

#### Properties

##### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L759)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:761](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L761)

#### Properties

##### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:762](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L762)

##### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:763](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L763)

***

### MergeResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:765](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L765)

#### Properties

##### source\_neuron

> **source\_neuron**: \[\] \| \[[`Neuron`](#neuron)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:767](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L767)

##### source\_neuron\_info

> **source\_neuron\_info**: \[\] \| \[[`NeuronInfo`](#neuroninfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:769](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L769)

##### target\_neuron

> **target\_neuron**: \[\] \| \[[`Neuron`](#neuron)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:766](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L766)

##### target\_neuron\_info

> **target\_neuron\_info**: \[\] \| \[[`NeuronInfo`](#neuroninfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:768](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L768)

***

### MonthlyNodeProviderRewards

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L771)

#### Properties

##### algorithm\_version

> **algorithm\_version**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L772)

##### end\_date

> **end\_date**: \[\] \| \[[`DateUtc`](#dateutc)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:774](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L774)

##### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:781](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L781)

##### minimum\_xdr\_permyriad\_per\_icp

> **minimum\_xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:773](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L773)

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L776)

##### registry\_version

> **registry\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L775)

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L779)

##### start\_date

> **start\_date**: \[\] \| \[[`DateUtc`](#dateutc)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:777](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L777)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:778](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L778)

##### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](#xdrconversionrate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:780](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L780)

***

### Motion

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:783](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L783)

#### Properties

##### motion\_text

> **motion\_text**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:784](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L784)

***

### NetworkEconomics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:786](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L786)

#### Properties

##### max\_proposals\_to\_keep\_per\_topic

> **max\_proposals\_to\_keep\_per\_topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:792](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L792)

##### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:798](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L798)

##### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:797](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L797)

##### neuron\_management\_fee\_per\_proposal\_e8s

> **neuron\_management\_fee\_per\_proposal\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:793](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L793)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:787](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L787)

##### neuron\_spawn\_dissolve\_delay\_seconds

> **neuron\_spawn\_dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:796](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L796)

##### neurons\_fund\_economics

> **neurons\_fund\_economics**: \[\] \| \[[`NeuronsFundEconomics`](#neuronsfundeconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:799](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L799)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:794](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L794)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:795](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L795)

##### voting\_power\_economics

> **voting\_power\_economics**: \[\] \| \[[`VotingPowerEconomics`](#votingpowereconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:791](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L791)

Parameters that affect the voting power of neurons.

***

### Neuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:801](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L801)

#### Properties

##### account

> **account**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L875)

##### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L873)

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:872](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L872)

##### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:870](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L870)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:804](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L804)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:871](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L871)

##### deciding\_voting\_power

> **deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L869)

The amount of "sway" this neuron has when voting on proposals.

When a proposal is created, each eligible neuron gets a "blank" ballot. The
amount of voting power in that ballot is set to the neuron's deciding
voting power at the time of proposal creation. There are two ways that a
proposal can become decided:

1. Early: Either more than half of the total voting power in the ballots
votes in favor (then the proposal is approved), or at least half of the
votal voting power in the ballots votes against (then, the proposal is
rejected).

2. The proposal's voting deadline is reached. At that point, if there is
more voting power in favor than against, and at least 3% of the total
voting power voted in favor, then the proposal is approved. Otherwise, it
is rejected.

If a neuron regularly refreshes its voting power, this has the same value
as potential_voting_power. Actions that cause a refresh are as follows:

1. voting directly (not via following)
2. set following
3. refresh voting power

(All of these actions are performed via the manage_neuron method.)

However, if a neuron has not refreshed in a "long" time, this will be less
than potential voting power. See VotingPowerEconomics. As a further result
of less deciding voting power, not only does it have less influence on the
outcome of proposals, the neuron receives less voting rewards (when it
votes indirectly via following).

For details, see https://dashboard.internetcomputer.org/proposal/132411.

Per NNS policy, this is opt. Nevertheless, it will never be null.

##### dissolve\_state

> **dissolve\_state**: \[\] \| \[[`DissolveState`](#dissolvestate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L889)

##### eight\_year\_gang\_bonus\_base\_e8s

> **eight\_year\_gang\_bonus\_base\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:883](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L883)

Base value (in e8s) used for the "8-year gang" dissolve delay bonus. For neurons that had the
maximum dissolve delay of 8 years before the maximum was reduced, this is set to the total
staked value net of fees (including staked maturity) captured at the time of migration.
For all other neurons, this is 0.

##### followees

> **followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L890)

##### hot\_keys

> **hot\_keys**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L874)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:802](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L802)

##### joined\_community\_fund\_timestamp\_seconds

> **joined\_community\_fund\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:876](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L876)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:894](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L894)

##### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:807](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L807)

##### maturity\_disbursements\_in\_progress

> **maturity\_disbursements\_in\_progress**: \[\] \| \[[`MaturityDisbursement`](#maturitydisbursement)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L888)

The maturity disbursements in progress, i.e. the disbursements that are initiated but not
finalized. The finalization happens 7 days after the disbursement is initiated.

##### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:831](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L831)

##### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L891)

##### neuron\_type

> **neuron\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:829](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L829)

##### not\_for\_profit

> **not\_for\_profit**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:830](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L830)

##### potential\_voting\_power

> **potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:828](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L828)

The amount of "sway" this neuron can have if it refreshes its voting power
frequently enough.

Unlike deciding_voting_power, this does NOT take refreshing into account.
Rather, this only takes three factors into account:

1. (Net) staked amount - This is the "base" of a neuron's voting power.
This primarily consists of the neuron's ICP balance.

2. Age - Neurons with more age have more voting power (all else being
equal).

3. Dissolve delay - Neurons with longer dissolve delay have more voting
power (all else being equal). Neurons with a dissolve delay of less
than six months are not eligible to vote. Therefore, such neurons
are considered to have 0 voting power.

Per NNS policy, this is opt. Nevertheless, it will never be null.

##### recent\_ballots

> **recent\_ballots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:805](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L805)

##### spawn\_at\_timestamp\_seconds

> **spawn\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L895)

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:803](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L803)

##### transfer

> **transfer**: \[\] \| \[[`NeuronStakeTransfer`](#neuronstaketransfer)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L893)

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:892](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L892)

##### voting\_power\_refreshed\_timestamp\_seconds

> **voting\_power\_refreshed\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:806](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L806)

***

### NeuronBasketConstructionParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:897](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L897)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:899](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L899)

##### dissolve\_delay\_interval

> **dissolve\_delay\_interval**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L898)

***

### NeuronBasketConstructionParameters\_1

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L901)

#### Properties

##### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:903](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L903)

##### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:902](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L902)

***

### NeuronDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:905](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L905)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:906](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L906)

##### dissolve\_delay

> **dissolve\_delay**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:907](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L907)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:908](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L908)

##### stake

> **stake**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:910](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L910)

##### vesting\_period

> **vesting\_period**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L909)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:912](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L912)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L913)

***

### NeuronIndexData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L922)

#### Properties

##### neurons

> **neurons**: [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:923](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L923)

***

### NeuronInFlightCommand

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L918)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_2`](#command_2)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L919)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L920)

***

### NeuronInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:933](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L933)

A limit view of Neuron that allows some aspects of all neurons to be read by
anyone (i.e. without having to be the neuron's controller nor one of its
hotkeys).

As such, the meaning of each field in this type is generally the same as the
one of the same (or at least similar) name in Neuron.

#### Properties

##### age\_seconds

> **age\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:973](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L973)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:945](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L945)

##### deciding\_voting\_power

> **deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:944](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L944)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:939](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L939)

##### eight\_year\_gang\_bonus\_base\_e8s

> **eight\_year\_gang\_bonus\_base\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:959](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L959)

See analogous field in Neuron.

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:934](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L934)

##### joined\_community\_fund\_timestamp\_seconds

> **joined\_community\_fund\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:955](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L955)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:962](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L962)

##### neuron\_type

> **neuron\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:943](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L943)

##### potential\_voting\_power

> **potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:942](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L942)

##### recent\_ballots

> **recent\_ballots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:940](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L940)

##### retrieved\_at\_timestamp\_seconds

> **retrieved\_at\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:960](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L960)

##### stake\_e8s

> **stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:954](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L954)

The amount of ICP (and staked maturity) locked in this neuron.

This is the foundation of the neuron's voting power.

cached_neuron_stake_e8s - neuron_fees_e8s + staked_maturity_e8s_equivalent

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:938](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L938)

See analogous field in Neuron.

##### state

> **state**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:946](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L946)

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:961](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L961)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:972](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L972)

Deprecated. Use either deciding_voting_power or potential_voting_power
instead. Has the same value as deciding_voting_power.

Previously, if a neuron had < 6 months dissolve delay (making it ineligible
to vote), this would not get set to 0 (zero). That was pretty confusing.
Now that this is set to deciding_voting_power, this actually does get
zeroed out.

##### voting\_power\_refreshed\_timestamp\_seconds

> **voting\_power\_refreshed\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:941](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L941)

***

### NeuronsFundAuditInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1010](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1010)

#### Properties

##### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1011](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1011)

##### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1012](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1012)

##### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1013](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1013)

***

### NeuronsFundData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1015](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1015)

#### Properties

##### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1016](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1016)

##### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1017](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1017)

##### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1018](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1018)

***

### NeuronsFundEconomics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1020](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1020)

#### Properties

##### max\_theoretical\_neurons\_fund\_participation\_amount\_xdr

> **max\_theoretical\_neurons\_fund\_participation\_amount\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1025](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1025)

##### maximum\_icp\_xdr\_rate

> **maximum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1021](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1021)

##### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1026](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1026)

##### neurons\_fund\_matched\_funding\_curve\_coefficients

> **neurons\_fund\_matched\_funding\_curve\_coefficients**: \[\] \| \[[`NeuronsFundMatchedFundingCurveCoefficients`](#neuronsfundmatchedfundingcurvecoefficients)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1022](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1022)

***

### NeuronsFundMatchedFundingCurveCoefficients

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1028](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1028)

#### Properties

##### contribution\_threshold\_xdr

> **contribution\_threshold\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1029](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1029)

##### full\_participation\_milestone\_xdr

> **full\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1031](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1031)

##### one\_third\_participation\_milestone\_xdr

> **one\_third\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1030](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1030)

***

### NeuronsFundNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1033](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1033)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1038](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1038)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1034](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1034)

##### hotkeys

> **hotkeys**: \[\] \| \[[`Principals`](#principals-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1035](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1035)

##### is\_capped

> **is\_capped**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1036](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1036)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1037](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1037)

***

### NeuronsFundNeuronPortion

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1040](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1040)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1046](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1046)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1041](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1041)

##### hotkeys

> **hotkeys**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1042](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1042)

##### is\_capped

> **is\_capped**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1043](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1043)

##### maturity\_equivalent\_icp\_e8s

> **maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1044](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1044)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1045](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1045)

***

### NeuronsFundParticipation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1048](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1048)

#### Properties

##### allocated\_neurons\_fund\_participation\_icp\_e8s

> **allocated\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1058](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1058)

##### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1051](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1051)

##### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](#idealmatchedparticipationfunction)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1055](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1055)

##### intended\_neurons\_fund\_participation\_icp\_e8s

> **intended\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1050](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1050)

##### max\_neurons\_fund\_swap\_participation\_icp\_e8s

> **max\_neurons\_fund\_swap\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1053](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1053)

##### neurons\_fund\_reserves

> **neurons\_fund\_reserves**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1054](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1054)

##### swap\_participation\_limits

> **swap\_participation\_limits**: \[\] \| \[[`SwapParticipationLimits`](#swapparticipationlimits)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1052](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1052)

##### total\_maturity\_equivalent\_icp\_e8s

> **total\_maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1049](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1049)

***

### NeuronsFundSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1060](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1060)

#### Properties

##### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuronPortion`](#neuronsfundneuronportion)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1061](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1061)

***

### NeuronStakeTransfer

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:975](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L975)

#### Properties

##### block\_height

> **block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:982](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L982)

##### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:978](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L978)

##### from\_subaccount

> **from\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:980](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L980)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:979](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L979)

##### neuron\_stake\_e8s

> **neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:977](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L977)

##### to\_subaccount

> **to\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:976](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L976)

##### transfer\_timestamp

> **transfer\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:981](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L981)

***

### NeuronSubaccount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:984](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L984)

#### Properties

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:985](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L985)

***

### NeuronSubsetMetrics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:987](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L987)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:992](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L992)

##### count\_buckets

> **count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1001](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1001)

##### deciding\_voting\_power\_buckets

> **deciding\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:993](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L993)

##### maturity\_e8s\_equivalent\_buckets

> **maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:989](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L989)

##### potential\_voting\_power\_buckets

> **potential\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1000](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1000)

##### staked\_e8s\_buckets

> **staked\_e8s\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:998](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L998)

##### staked\_maturity\_e8s\_equivalent\_buckets

> **staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:997](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L997)

##### total\_deciding\_voting\_power

> **total\_deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:996](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L996)

##### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:988](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L988)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:995](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L995)

##### total\_staked\_e8s

> **total\_staked\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:991](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L991)

##### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:994](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L994)

##### total\_voting\_power

> **total\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:999](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L999)

##### voting\_power\_buckets

> **voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:990](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L990)

***

### NeuronVote

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1003](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1003)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1008](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1008)

##### vote

> **vote**: \[\] \| \[[`Vote`](#vote-4)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1007](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1007)

The vote of the neuron on the specific proposal id.

***

### NodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1063](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1063)

#### Properties

##### id

> **id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1064](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1064)

##### reward\_account

> **reward\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1065](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1065)

***

### Ok

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1067](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1067)

#### Properties

##### neurons\_fund\_audit\_info

> **neurons\_fund\_audit\_info**: \[\] \| \[[`NeuronsFundAuditInfo`](#neuronsfundauditinfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1068](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1068)

***

### Ok\_1

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1070](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1070)

#### Properties

##### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuron`](#neuronsfundneuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1071](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1071)

***

### OpenSnsTokenSwap

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1073](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1073)

#### Properties

##### community\_fund\_investment\_e8s

> **community\_fund\_investment\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1074](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1074)

##### params

> **params**: \[\] \| \[[`Params`](#params-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1076](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1076)

##### target\_swap\_canister\_id

> **target\_swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1075](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1075)

***

### Params

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1089](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1089)

#### Properties

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1102)

##### max\_icp\_e8s

> **max\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1094](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1094)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1099](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1099)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1100)

##### min\_icp\_e8s

> **min\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1101)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1090](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1090)

##### min\_participants

> **min\_participants**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1096](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1096)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters_1`](#neuronbasketconstructionparameters_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1091](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1091)

##### sale\_delay\_seconds

> **sale\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1098](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1098)

##### sns\_token\_e8s

> **sns\_token\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1097](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1097)

##### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1095](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1095)

***

### Percentage

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1104)

#### Properties

##### basis\_points

> **basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1105)

***

### Principals

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1107)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1108)

***

### Proposal

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1110)

#### Properties

##### action

> **action**: \[\] \| \[[`Action`](#action-3)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1113)

##### self\_describing\_action

> **self\_describing\_action**: \[\] \| \[[`SelfDescribingProposalAction`](#selfdescribingproposalaction)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1115)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1114](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1114)

##### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1112)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1111)

***

### ProposalData

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1137](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1137)

#### Properties

##### ballots

> **ballots**: \[`bigint`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1141)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1152](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1152)

##### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](#derivedproposalinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1148](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1148)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1156)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1144)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1140)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1138](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1138)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1149](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1149)

##### neurons\_fund\_data

> **neurons\_fund\_data**: \[\] \| \[[`NeuronsFundData`](#neuronsfunddata)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1146)

##### original\_total\_community\_fund\_maturity\_e8s\_equivalent

> **original\_total\_community\_fund\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1157)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1153)

##### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1142)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1154)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1147](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1147)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1143)

##### sns\_token\_swap\_lifecycle

> **sns\_token\_swap\_lifecycle**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1151](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1151)

##### success\_value

> **success\_value**: \[\] \| \[[`SuccessfulProposalExecutionValue`](#successfulproposalexecutionvalue)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1145](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1145)

##### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1139)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1150)

##### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](#waitforquietstate)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1155](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1155)

***

### ProposalId

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1159](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1159)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1160](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1160)

***

### ProposalInfo

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1162](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1162)

#### Properties

##### ballots

> **ballots**: \[`bigint`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1167](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1167)

##### deadline\_timestamp\_seconds

> **deadline\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1170](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1170)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1178)

##### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](#derivedproposalinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1174)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1181](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1181)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1171](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1171)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1166](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1166)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1163](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1163)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1175](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1175)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1179](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1179)

##### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1168](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1168)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1180](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1180)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1173](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1173)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1169](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1169)

##### reward\_status

> **reward\_status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1177](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1177)

##### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1164](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1164)

##### success\_value

> **success\_value**: \[\] \| \[[`SuccessfulProposalExecutionValue`](#successfulproposalexecutionvalue)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1172](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1172)

##### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1165](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1165)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1176](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1176)

***

### RegisterVote

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1190](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1190)

#### Properties

##### proposal

> **proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1192](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1192)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1191)

***

### RemoveHotKey

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1194](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1194)

#### Properties

##### hot\_key\_to\_remove

> **hot\_key\_to\_remove**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1195](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1195)

***

### RestoreAgingNeuronGroup

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1197](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1197)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1198](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1198)

##### current\_total\_stake\_e8s

> **current\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1200](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1200)

##### group\_type

> **group\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1201](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1201)

##### previous\_total\_stake\_e8s

> **previous\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1199](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1199)

***

### RestoreAgingSummary

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1203](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1203)

#### Properties

##### groups

> **groups**: [`RestoreAgingNeuronGroup`](#restoreagingneurongroup)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1204](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1204)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1205](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1205)

***

### RewardEvent

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1222](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1222)

#### Properties

##### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1225](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1225)

##### day\_after\_genesis

> **day\_after\_genesis**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1224)

##### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1228](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1228)

##### latest\_round\_available\_e8s\_equivalent

> **latest\_round\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1227](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1227)

##### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1223](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1223)

##### settled\_proposals

> **settled\_proposals**: [`ProposalId`](#proposalid)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1229)

##### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1226](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1226)

***

### RewardNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1234](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1234)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1237)

##### node\_provider

> **node\_provider**: \[\] \| \[[`NodeProvider`](#nodeprovider)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1235](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1235)

##### reward\_mode

> **reward\_mode**: \[\] \| \[[`RewardMode`](#rewardmode)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1236](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1236)

***

### RewardNodeProviders

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1239](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1239)

#### Properties

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1241](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1241)

##### use\_registry\_derived\_rewards

> **use\_registry\_derived\_rewards**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1240](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1240)

***

### RewardToAccount

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1243](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1243)

#### Properties

##### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1244](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1244)

***

### RewardToNeuron

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1246](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1246)

#### Properties

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1247](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1247)

***

### SelfDescribingProposalAction

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1249](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1249)

#### Properties

##### type\_description

> **type\_description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1250](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1250)

##### type\_name

> **type\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1251](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1251)

##### value

> **value**: \[\] \| \[[`SelfDescribingValue`](#selfdescribingvalue)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1252](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1252)

***

### SetDefaultFollowees

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1263](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1263)

#### Properties

##### default\_followees

> **default\_followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1264](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1264)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1266](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1266)

#### Properties

##### dissolve\_timestamp\_seconds

> **dissolve\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1267](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1267)

***

### SetFollowing

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1269](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1269)

#### Properties

##### topic\_following

> **topic\_following**: \[\] \| \[[`FolloweesForTopic`](#followeesfortopic)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1270](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1270)

***

### SetOpenTimeWindowRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1273](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1273)

#### Properties

##### open\_time\_window

> **open\_time\_window**: \[\] \| \[[`TimeWindow`](#timewindow)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1274](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1274)

***

### SetSnsTokenSwapOpenTimeWindow

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1276](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1276)

#### Properties

##### request

> **request**: \[\] \| \[[`SetOpenTimeWindowRequest`](#setopentimewindowrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1277)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1278](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1278)

***

### SettleCommunityFundParticipation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1283)

#### Properties

##### open\_sns\_token\_swap\_proposal\_id

> **open\_sns\_token\_swap\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1285](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1285)

##### result

> **result**: \[\] \| \[[`Result_8`](#result_8)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1284](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1284)

***

### SettleNeuronsFundParticipationRequest

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1287](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1287)

#### Properties

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1289](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1289)

##### result

> **result**: \[\] \| \[[`Result_9`](#result_9)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1288](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1288)

***

### SettleNeuronsFundParticipationResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1291](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1291)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_10`](#result_10)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1292](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1292)

***

### SetVisibility

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1280](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1280)

#### Properties

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1281](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1281)

***

### Spawn

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1294](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1294)

#### Properties

##### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1296)

##### nonce

> **nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1297](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1297)

##### percentage\_to\_spawn

> **percentage\_to\_spawn**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1295](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1295)

***

### SpawnResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1299](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1299)

#### Properties

##### created\_neuron\_id

> **created\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1300)

***

### Split

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1302](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1302)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1304](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1304)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1303](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1303)

***

### StakeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1306](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1306)

#### Properties

##### percentage\_to\_stake

> **percentage\_to\_stake**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1307](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1307)

***

### StakeMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1309](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1309)

#### Properties

##### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1310](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1310)

##### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1311](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1311)

***

### StopOrStartCanister

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1313](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1313)

#### Properties

##### action

> **action**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1314](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1314)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1315](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1315)

***

### SwapBackgroundInformation

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1322](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1322)

#### Properties

##### dapp\_canister\_summaries

> **dapp\_canister\_summaries**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1330](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1330)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1324](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1324)

##### governance\_canister\_summary

> **governance\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1328](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1328)

##### ledger\_archive\_canister\_summaries

> **ledger\_archive\_canister\_summaries**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1325](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1325)

##### ledger\_canister\_summary

> **ledger\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1326](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1326)

##### ledger\_index\_canister\_summary

> **ledger\_index\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1323)

##### root\_canister\_summary

> **root\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1329](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1329)

##### swap\_canister\_summary

> **swap\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1327](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1327)

***

### SwapDistribution

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1332](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1332)

#### Properties

##### total

> **total**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1333](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1333)

***

### SwapParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1335](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1335)

#### Properties

##### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1342](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1342)

##### duration

> **duration**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1338](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1338)

##### maximum\_direct\_participation\_icp

> **maximum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1348](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1348)

##### maximum\_icp

> **maximum\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1349)

##### maximum\_participant\_icp

> **maximum\_participant\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1343](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1343)

##### minimum\_direct\_participation\_icp

> **minimum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1345](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1345)

##### minimum\_icp

> **minimum\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1344](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1344)

##### minimum\_participant\_icp

> **minimum\_participant\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1346](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1346)

##### minimum\_participants

> **minimum\_participants**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1336](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1336)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1339](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1339)

##### neurons\_fund\_investment\_icp

> **neurons\_fund\_investment\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1350)

##### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1337](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1337)

##### restricted\_countries

> **restricted\_countries**: \[\] \| \[[`Countries`](#countries)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1351](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1351)

##### start\_time

> **start\_time**: \[\] \| \[[`GlobalTimeOfDay`](#globaltimeofday)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1347](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1347)

***

### SwapParticipationLimits

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1353)

#### Properties

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1357](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1357)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1355](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1355)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1356](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1356)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1354](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1354)

***

### TakeCanisterSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1359](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1359)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1361](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1361)

##### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1360](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1360)

***

### TakeCanisterSnapshotOk

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1363)

#### Properties

##### snapshot\_id

> **snapshot\_id**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1364](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1364)

***

### Tally

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1366](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1366)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1367](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1367)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1370](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1370)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1369](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1369)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1368](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1368)

***

### TimeWindow

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1372](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1372)

#### Properties

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1374](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1374)

##### start\_timestamp\_seconds

> **start\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1373](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1373)

***

### Tokens

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1376](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1376)

#### Properties

##### e8s

> **e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1377](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1377)

***

### UpdateCanisterSettings

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1404](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1404)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1405](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1405)

##### settings

> **settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1406](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1406)

***

### UpdateNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1408](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1408)

#### Properties

##### reward\_account

> **reward\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1409](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1409)

***

### VotingPowerEconomics

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1423](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1423)

Parameters that affect the voting power of neurons.

#### Properties

##### clear\_following\_after\_seconds

> **clear\_following\_after\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1455](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1455)

After a neuron has experienced voting power reduction for this amount of
time, a couple of things happen:

1. Deciding voting power reaches 0.

2. Its following on topics other than NeuronManagement are cleared.

Initially, set to 1/12 years.

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1444](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1444)

The minimum dissolve delay a neuron must have in order to be eligible to vote.

Neurons with a dissolve delay lower than this threshold will not have
voting power, even if they are otherwise active.

This value is an essential part of the staking mechanism, promoting
long-term alignment with the network's governance.

##### start\_reducing\_voting\_power\_after\_seconds

> **start\_reducing\_voting\_power\_after\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1434](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1434)

If a neuron has not "refreshed" its voting power after this amount of time,
its deciding voting power starts decreasing linearly. See also
clear_following_after_seconds.

For explanation of what "refresh" means in this context, see
https://dashboard.internetcomputer.org/proposal/132411

Initially, set to 0.5 years. (The nominal length of a year is 365.25 days).

***

### VotingRewardParameters

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1457](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1457)

#### Properties

##### final\_reward\_rate

> **final\_reward\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1460](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1460)

##### initial\_reward\_rate

> **initial\_reward\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1459](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1459)

##### reward\_rate\_transition\_duration

> **reward\_rate\_transition\_duration**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1458](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1458)

***

### WaitForQuietState

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1462](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1462)

#### Properties

##### current\_deadline\_timestamp\_seconds

> **current\_deadline\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1463](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1463)

***

### XdrConversionRate

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1466](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1466)

#### Properties

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1468](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1468)

##### xdr\_permyriad\_per\_icp

> **xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1467](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1467)

## Type Aliases

### Action

> **Action** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `ManageNeuron`: [`ManageNeuronProposal`](#manageneuronproposal); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `InstallCode`: [`InstallCode`](#installcode); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCode`](#createcanisterandinstallcode); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `OpenSnsTokenSwap`: [`OpenSnsTokenSwap`](#opensnstokenswap); \} \| \{ `SetSnsTokenSwapOpenTimeWindow`: [`SetSnsTokenSwapOpenTimeWindow`](#setsnstokenswapopentimewindow); \} \| \{ `SetDefaultFollowees`: [`SetDefaultFollowees`](#setdefaultfollowees); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics); \} \| \{ `ApproveGenesisKyc`: [`Principals`](#principals-1); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L20)

***

### By

> **By** = \{ `NeuronIdOrSubaccount`: \{ \}; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L86)

***

### Change

> **Change** = \{ `ToRemove`: [`NodeProvider`](#nodeprovider); \} \| \{ `ToAdd`: [`NodeProvider`](#nodeprovider); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L116)

***

### Command\_1

> **Command\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Spawn`: [`SpawnResponse`](#spawnresponse); \} \| \{ `Split`: [`SpawnResponse`](#spawnresponse); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](#disbursematurityresponse); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPowerResponse`](#refreshvotingpowerresponse); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](#claimorrefreshresponse); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `Merge`: [`MergeResponse`](#mergeresponse); \} \| \{ `DisburseToNeuron`: [`SpawnResponse`](#spawnresponse); \} \| \{ `SetFollowing`: [`SetFollowingResponse`](#setfollowingresponse); \} \| \{ `MakeProposal`: [`MakeProposalResponse`](#makeproposalresponse); \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](#stakematurityresponse); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](#mergematurityresponse); \} \| \{ `Disburse`: [`DisburseResponse`](#disburseresponse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L133)

***

### Command\_2

> **Command\_2** = \{ `Spawn`: [`NeuronId`](#neuronid-1); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L150)

***

### CreateNeuronResponse

> **CreateNeuronResponse** = \{ `Ok`: [`CreatedNeuron`](#createdneuron); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L228)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L292)

***

### GetMaturityModulationRequest

> **GetMaturityModulationRequest** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L355)

***

### GetNeuronIndexResult

> **GetNeuronIndexResult** = \{ `Ok`: [`NeuronIndexData`](#neuronindexdata); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L363)

***

### ListNeuronVotesResponse

> **ListNeuronVotesResponse** = \{ `Ok`: \{ `all_finalized_before_proposal`: \[\] \| \[[`ProposalId`](#proposalid)\]; `votes`: \[\] \| \[[`NeuronVote`](#neuronvote)[]\]; \}; \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L575)

***

### ManageNeuronCommandRequest

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](#makeproposalrequest); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:673](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L673)

KEEP THIS IN SYNC WITH COMMAND!

***

### ManageNeuronProposalCommand

> **ManageNeuronProposalCommand** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:701](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L701)

KEEP THIS IN SYNC WITH ManageNeuronCommandRequest!

***

### NeuronIdOrSubaccount

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `Uint8Array`; \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-1); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L915)

***

### Operation

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](#removehotkey); \} \| \{ `AddHotKey`: [`AddHotKey`](#addhotkey); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay); \} \| \{ `SetVisibility`: [`SetVisibility`](#setvisibility); \} \| \{ `JoinCommunityFund`: \{ \}; \} \| \{ `LeaveCommunityFund`: \{ \}; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1078](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1078)

***

### ProposalActionRequest

> **ProposalActionRequest** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](#manageneuronrequest); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `InstallCode`: [`InstallCodeRequest`](#installcoderequest); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCodeRequest`](#createcanisterandinstallcoderequest); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics); \} \| \{ `ApproveGenesisKyc`: [`Principals`](#principals-1); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1117](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1117)

***

### RefreshVotingPower

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1188](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1188)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.

***

### RefreshVotingPowerResponse

> **RefreshVotingPowerResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1189](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1189)

***

### Result

> **Result** = \{ `Ok`: `null`; \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1207](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1207)

***

### Result\_1

> **Result\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-1); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1208](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1208)

***

### Result\_10

> **Result\_10** = \{ `Ok`: [`Ok_1`](#ok_1); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1209](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1209)

***

### Result\_2

> **Result\_2** = \{ `Ok`: [`Neuron`](#neuron); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1210)

***

### Result\_3

> **Result\_3** = \{ `Ok`: [`GovernanceCachedMetrics`](#governancecachedmetrics); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1211](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1211)

***

### Result\_4

> **Result\_4** = \{ `Ok`: [`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1214](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1214)

***

### Result\_5

> **Result\_5** = \{ `Ok`: [`NeuronInfo`](#neuroninfo); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1217](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1217)

***

### Result\_6

> **Result\_6** = \{ `Ok`: [`Ok`](#ok); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1218)

***

### Result\_7

> **Result\_7** = \{ `Ok`: [`NodeProvider`](#nodeprovider); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1219](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1219)

***

### Result\_8

> **Result\_8** = \{ `Committed`: [`Committed`](#committed); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1220)

***

### Result\_9

> **Result\_9** = \{ `Committed`: [`Committed_1`](#committed_1); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1221](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1221)

***

### RewardMode

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](#rewardtoneuron); \} \| \{ `RewardToAccount`: [`RewardToAccount`](#rewardtoaccount); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1231](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1231)

***

### SelfDescribingValue

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`SelfDescribingValue`](#selfdescribingvalue)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Null`: `null`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`SelfDescribingValue`](#selfdescribingvalue)[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1254](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1254)

***

### SetFollowingResponse

> **SetFollowingResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1272](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1272)

***

### SuccessfulProposalExecutionValue

> **SuccessfulProposalExecutionValue** = \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshotOk`](#takecanistersnapshotok); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCodeOk`](#createcanisterandinstallcodeok); \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1317](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1317)

***

### TopicToFollow

> **TopicToFollow** = \{ `Kyc`: `null`; \} \| \{ `ServiceNervousSystemManagement`: `null`; \} \| \{ `ApiBoundaryNodeManagement`: `null`; \} \| \{ `ApplicationCanisterManagement`: `null`; \} \| \{ `SubnetRental`: `null`; \} \| \{ `NeuronManagement`: `null`; \} \| \{ `NodeProviderRewards`: `null`; \} \| \{ `SubnetManagement`: `null`; \} \| \{ `ExchangeRate`: `null`; \} \| \{ `CatchAll`: `null`; \} \| \{ `NodeAdmin`: `null`; \} \| \{ `IcOsVersionElection`: `null`; \} \| \{ `ProtocolCanisterManagement`: `null`; \} \| \{ `NetworkEconomics`: `null`; \} \| \{ `IcOsVersionDeployment`: `null`; \} \| \{ `ParticipantManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsAndCommunityFund`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1385](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1385)

A topic that can be followed. It is almost the same as the topic on the
proposal, except that the `CatchAll` is a special value and following on this
`topic` will let the neuron follow the votes on all topics except for
Governance and SnsAndCommunityFund.

***

### Vote

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1411](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1411)

#### Type Declaration

\{ `No`: `null`; \}

##### No

> **No**: `null`

\{ `Yes`: `null`; \}

##### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

##### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.

***

### WasmModule

> **WasmModule** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1465](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1465)

#### Properties

##### Inlined

> **Inlined**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1465](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1465)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1548](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1548)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1549](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/nns/governance_test.d.ts#L1549)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
