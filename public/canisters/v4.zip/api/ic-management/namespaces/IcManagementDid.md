---
title: IcManagementDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L529)

#### Properties

##### bitcoin\_get\_balance

> **bitcoin\_get\_balance**: `ActorMethod`\<\[[`bitcoin_get_balance_args`](#bitcoin_get_balance_args)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L533)

bitcoin interface

##### bitcoin\_get\_block\_headers

> **bitcoin\_get\_block\_headers**: `ActorMethod`\<\[[`bitcoin_get_block_headers_args`](#bitcoin_get_block_headers_args)\], [`bitcoin_get_block_headers_result`](#bitcoin_get_block_headers_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L537)

##### bitcoin\_get\_current\_fee\_percentiles

> **bitcoin\_get\_current\_fee\_percentiles**: `ActorMethod`\<\[[`bitcoin_get_current_fee_percentiles_args`](#bitcoin_get_current_fee_percentiles_args)\], [`bitcoin_get_current_fee_percentiles_result`](#bitcoin_get_current_fee_percentiles_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L541)

##### bitcoin\_get\_utxos

> **bitcoin\_get\_utxos**: `ActorMethod`\<\[[`bitcoin_get_utxos_args`](#bitcoin_get_utxos_args)\], [`bitcoin_get_utxos_result`](#bitcoin_get_utxos_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:545](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L545)

##### bitcoin\_send\_transaction

> **bitcoin\_send\_transaction**: `ActorMethod`\<\[[`bitcoin_send_transaction_args`](#bitcoin_send_transaction_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L549)

##### canister\_info

> **canister\_info**: `ActorMethod`\<\[[`canister_info_args`](#canister_info_args)\], [`canister_info_result`](#canister_info_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L556)

Public canister data

##### canister\_metadata

> **canister\_metadata**: `ActorMethod`\<\[[`canister_metadata_args`](#canister_metadata_args)\], [`canister_metadata_result`](#canister_metadata_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L557)

##### canister\_metrics

> **canister\_metrics**: `ActorMethod`\<\[[`canister_metrics_args`](#canister_metrics_args)\], [`canister_metrics_result`](#canister_metrics_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L564)

Returns canister related metrics

##### canister\_status

> **canister\_status**: `ActorMethod`\<\[[`canister_status_args`](#canister_status_args)\], [`canister_status_result`](#canister_status_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L568)

##### clear\_chunk\_store

> **clear\_chunk\_store**: `ActorMethod`\<\[[`clear_chunk_store_args`](#clear_chunk_store_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L569)

##### create\_canister

> **create\_canister**: `ActorMethod`\<\[[`create_canister_args`](#create_canister_args)\], [`create_canister_result`](#create_canister_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L570)

##### delete\_canister

> **delete\_canister**: `ActorMethod`\<\[[`delete_canister_args`](#delete_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L571)

##### delete\_canister\_snapshot

> **delete\_canister\_snapshot**: `ActorMethod`\<\[[`delete_canister_snapshot_args`](#delete_canister_snapshot_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L572)

##### deposit\_cycles

> **deposit\_cycles**: `ActorMethod`\<\[[`deposit_cycles_args`](#deposit_cycles_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L576)

##### ecdsa\_public\_key

> **ecdsa\_public\_key**: `ActorMethod`\<\[[`ecdsa_public_key_args`](#ecdsa_public_key_args)\], [`ecdsa_public_key_result`](#ecdsa_public_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L580)

Threshold ECDSA signature

##### fetch\_canister\_logs

> **fetch\_canister\_logs**: `ActorMethod`\<\[[`fetch_canister_logs_args`](#fetch_canister_logs_args)\], [`fetch_canister_logs_result`](#fetch_canister_logs_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:587](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L587)

canister logging

##### http\_request

> **http\_request**: `ActorMethod`\<\[[`http_request_args`](#http_request_args)\], [`http_request_result`](#http_request_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L591)

##### install\_chunked\_code

> **install\_chunked\_code**: `ActorMethod`\<\[[`install_chunked_code_args`](#install_chunked_code_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L592)

##### install\_code

> **install\_code**: `ActorMethod`\<\[[`install_code_args`](#install_code_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:593](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L593)

##### list\_canister\_snapshots

> **list\_canister\_snapshots**: `ActorMethod`\<\[[`list_canister_snapshots_args`](#list_canister_snapshots_args)\], [`list_canister_snapshots_result`](#list_canister_snapshots_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:594](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L594)

##### list\_canisters

> **list\_canisters**: `ActorMethod`\<\[\], [`list_canisters_result`](#list_canisters_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L601)

subnet admin methods

##### load\_canister\_snapshot

> **load\_canister\_snapshot**: `ActorMethod`\<\[[`load_canister_snapshot_args`](#load_canister_snapshot_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:602](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L602)

##### node\_metrics\_history

> **node\_metrics\_history**: `ActorMethod`\<\[[`node_metrics_history_args`](#node_metrics_history_args)\], [`node_metrics_history_result`](#node_metrics_history_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:606](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L606)

metrics interface

##### provisional\_create\_canister\_with\_cycles

> **provisional\_create\_canister\_with\_cycles**: `ActorMethod`\<\[[`provisional_create_canister_with_cycles_args`](#provisional_create_canister_with_cycles_args)\], [`provisional_create_canister_with_cycles_result`](#provisional_create_canister_with_cycles_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:613](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L613)

provisional interfaces for the pre-ledger world

##### provisional\_top\_up\_canister

> **provisional\_top\_up\_canister**: `ActorMethod`\<\[[`provisional_top_up_canister_args`](#provisional_top_up_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L617)

##### raw\_rand

> **raw\_rand**: `ActorMethod`\<\[\], [`raw_rand_result`](#raw_rand_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L621)

##### read\_canister\_snapshot\_data

> **read\_canister\_snapshot\_data**: `ActorMethod`\<\[[`read_canister_snapshot_data_args`](#read_canister_snapshot_data_args)\], [`read_canister_snapshot_data_response`](#read_canister_snapshot_data_response)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L622)

##### read\_canister\_snapshot\_metadata

> **read\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`read_canister_snapshot_metadata_args`](#read_canister_snapshot_metadata_args)\], [`read_canister_snapshot_metadata_response`](#read_canister_snapshot_metadata_response)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L626)

##### schnorr\_public\_key

> **schnorr\_public\_key**: `ActorMethod`\<\[[`schnorr_public_key_args`](#schnorr_public_key_args)\], [`schnorr_public_key_result`](#schnorr_public_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L633)

Threshold Schnorr signature

##### sign\_with\_ecdsa

> **sign\_with\_ecdsa**: `ActorMethod`\<\[[`sign_with_ecdsa_args`](#sign_with_ecdsa_args)\], [`sign_with_ecdsa_result`](#sign_with_ecdsa_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:637](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L637)

##### sign\_with\_schnorr

> **sign\_with\_schnorr**: `ActorMethod`\<\[[`sign_with_schnorr_args`](#sign_with_schnorr_args)\], [`sign_with_schnorr_result`](#sign_with_schnorr_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L638)

##### start\_canister

> **start\_canister**: `ActorMethod`\<\[[`start_canister_args`](#start_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L642)

##### stop\_canister

> **stop\_canister**: `ActorMethod`\<\[[`stop_canister_args`](#stop_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L643)

##### stored\_chunks

> **stored\_chunks**: `ActorMethod`\<\[[`stored_chunks_args`](#stored_chunks_args)\], [`stored_chunks_result`](#stored_chunks_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L644)

##### subnet\_info

> **subnet\_info**: `ActorMethod`\<\[[`subnet_info_args`](#subnet_info_args)\], [`subnet_info_result`](#subnet_info_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:648](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L648)

subnet info

##### take\_canister\_snapshot

> **take\_canister\_snapshot**: `ActorMethod`\<\[[`take_canister_snapshot_args`](#take_canister_snapshot_args)\], [`snapshot`](#snapshot)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:652](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L652)

Canister snapshots

##### uninstall\_code

> **uninstall\_code**: `ActorMethod`\<\[[`uninstall_code_args`](#uninstall_code_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L656)

##### update\_settings

> **update\_settings**: `ActorMethod`\<\[[`update_settings_args`](#update_settings_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:657](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L657)

##### upload\_canister\_snapshot\_data

> **upload\_canister\_snapshot\_data**: `ActorMethod`\<\[[`upload_canister_snapshot_data_args`](#upload_canister_snapshot_data_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L658)

##### upload\_canister\_snapshot\_metadata

> **upload\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`upload_canister_snapshot_metadata_args`](#upload_canister_snapshot_metadata_args)\], [`upload_canister_snapshot_metadata_response`](#upload_canister_snapshot_metadata_response)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L662)

##### upload\_chunk

> **upload\_chunk**: `ActorMethod`\<\[[`upload_chunk_args`](#upload_chunk_args)\], [`chunk_hash`](#chunk_hash)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L666)

##### vetkd\_derive\_key

> **vetkd\_derive\_key**: `ActorMethod`\<\[[`vetkd_derive_key_args`](#vetkd_derive_key_args)\], [`vetkd_derive_key_result`](#vetkd_derive_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:667](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L667)

##### vetkd\_public\_key

> **vetkd\_public\_key**: `ActorMethod`\<\[[`vetkd_public_key_args`](#vetkd_public_key_args)\], [`vetkd_public_key_result`](#vetkd_public_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L674)

Threshold key derivation

***

### bitcoin\_get\_balance\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L17)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L19)

##### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L20)

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L18)

***

### bitcoin\_get\_block\_headers\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L23)

#### Properties

##### end\_height

> **end\_height**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L25)

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L26)

##### start\_height

> **start\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L24)

***

### bitcoin\_get\_block\_headers\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L28)

#### Properties

##### block\_headers

> **block\_headers**: [`bitcoin_block_header`](#bitcoin_block_header)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L30)

##### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L29)

***

### bitcoin\_get\_current\_fee\_percentiles\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L32)

#### Properties

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L33)

***

### bitcoin\_get\_utxos\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L36)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L39)

##### filter

> **filter**: \[\] \| \[\{ `page`: `Uint8Array`; \} \| \{ `min_confirmations`: `number`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L38)

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L37)

***

### bitcoin\_get\_utxos\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L41)

#### Properties

##### next\_page

> **next\_page**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L42)

##### tip\_block\_hash

> **tip\_block\_hash**: [`bitcoin_block_hash`](#bitcoin_block_hash)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L44)

##### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L43)

##### utxos

> **utxos**: [`utxo`](#utxo)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L45)

***

### bitcoin\_send\_transaction\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L48)

#### Properties

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L50)

##### transaction

> **transaction**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L49)

***

### canister\_id\_range

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L53)

#### Properties

##### end

> **end**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L54)

##### start

> **start**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L55)

***

### canister\_info\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L57)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L58)

##### num\_requested\_changes

> **num\_requested\_changes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L59)

***

### canister\_info\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L61)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L62)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L63)

##### recent\_changes

> **recent\_changes**: [`change`](#change)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L64)

##### total\_num\_changes

> **total\_num\_changes**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L65)

***

### canister\_log\_record

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L82)

#### Properties

##### content

> **content**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L85)

##### idx

> **idx**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L83)

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L84)

***

### canister\_metadata\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L87)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L89)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L88)

***

### canister\_metadata\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L91)

#### Properties

##### value

> **value**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L92)

***

### canister\_metrics\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L94)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L95)

***

### canister\_metrics\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L97)

#### Properties

##### cycles\_consumed

> **cycles\_consumed**: [`cycles_consumed`](#cycles_consumed-1)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L98)

***

### canister\_settings

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L100)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L110)

##### controllers

> **controllers**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L104)

##### environment\_variables

> **environment\_variables**: \[\] \| \[[`environment_variable`](#environment_variable)[]\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L103)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L101)

##### log\_visibility

> **log\_visibility**: \[\] \| \[[`log_visibility`](#log_visibility-2)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L106)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L109)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L105)

##### snapshot\_visibility

> **snapshot\_visibility**: \[\] \| \[[`snapshot_visibility`](#snapshot_visibility-2)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L107)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L108)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L102)

***

### canister\_status\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L112)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L113)

***

### canister\_status\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L115)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L130)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L138)

##### memory\_metrics

> **memory\_metrics**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L116)

###### canister\_history\_size

> **canister\_history\_size**: `bigint`

###### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

###### global\_memory\_size

> **global\_memory\_size**: `bigint`

###### snapshots\_size

> **snapshots\_size**: `bigint`

###### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

###### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

###### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

###### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L127)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L139)

##### query\_stats

> **query\_stats**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L132)

###### num\_calls\_total

> **num\_calls\_total**: `bigint`

###### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

###### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

###### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L128)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L140)

##### settings

> **settings**: [`definite_canister_settings`](#definite_canister_settings)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L131)

##### status

> **status**: \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L126)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L129)

***

### change

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L142)

#### Properties

##### canister\_version

> **canister\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L144)

##### details

> **details**: [`change_details`](#change_details)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L146)

##### origin

> **origin**: [`change_origin`](#change_origin)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L145)

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L143)

***

### chunk\_hash

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L192)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L193)

***

### clear\_chunk\_store\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L195)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L196)

***

### create\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L198)

#### Properties

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L200)

##### settings

> **settings**: \[\] \| \[[`canister_settings`](#canister_settings)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L199)

***

### create\_canister\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L202)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L203)

***

### cycles\_consumed

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L205)

#### Properties

##### burned\_cycles

> **burned\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L208)

##### canister\_creation

> **canister\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L207)

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L220)

##### http\_outcalls

> **http\_outcalls**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L209)

##### ingress\_induction

> **ingress\_induction**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L218)

##### instructions

> **instructions**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L210)

##### memory

> **memory**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L206)

##### request\_and\_response\_transmission

> **request\_and\_response\_transmission**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L219)

##### uninstall

> **uninstall**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L217)

This metric applies to canisters that ran out of cycles. In particular,
uninstalling code explicitly would not result in this metric being updated.
In fact, others might be updated in that case, e.g. cycles for ingress induction
if the uninstallation of the canister was requested via an ingress message.

***

### definite\_canister\_settings

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L222)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L232)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L226)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L225)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L223)

##### log\_visibility

> **log\_visibility**: [`log_visibility`](#log_visibility-2)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L228)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L231)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L227)

##### snapshot\_visibility

> **snapshot\_visibility**: [`snapshot_visibility`](#snapshot_visibility-2)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L229)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L230)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L224)

***

### delete\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L234)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L235)

***

### delete\_canister\_snapshot\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L237)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L238)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L239)

***

### deposit\_cycles\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L241)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L242)

***

### ecdsa\_public\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L245)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L247)

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L248)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L246)

###### curve

> **curve**: [`ecdsa_curve`](#ecdsa_curve)

###### name

> **name**: `string`

***

### ecdsa\_public\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L250)

#### Properties

##### chain\_code

> **chain\_code**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L252)

##### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L251)

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L254)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L256)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L255)

***

### fetch\_canister\_logs\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L258)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L259)

***

### fetch\_canister\_logs\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L261)

#### Properties

##### canister\_log\_records

> **canister\_log\_records**: [`canister_log_record`](#canister_log_record)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L262)

***

### http\_header

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L264)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L266)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L265)

***

### http\_request\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L268)

#### Properties

##### body

> **body**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L277)

##### headers

> **headers**: [`http_header`](#http_header)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L279)

##### is\_replicated

> **is\_replicated**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L280)

##### max\_response\_bytes

> **max\_response\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L276)

##### method

> **method**: \{ `get`: `null`; \} \| \{ `put`: `null`; \} \| \{ `head`: `null`; \} \| \{ `post`: `null`; \} \| \{ `delete`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L270)

##### transform

> **transform**: \[\] \| \[\{ `context`: `Uint8Array`; `function`: \[`Principal`, `string`\]; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L278)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L269)

***

### http\_request\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L282)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L284)

##### headers

> **headers**: [`http_header`](#http_header)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L285)

##### status

> **status**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L283)

***

### install\_chunked\_code\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L287)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L288)

##### chunk\_hashes\_list

> **chunk\_hashes\_list**: [`chunk_hash`](#chunk_hash)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L291)

##### mode

> **mode**: [`canister_install_mode`](#canister_install_mode)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L290)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L294)

##### store\_canister

> **store\_canister**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L293)

##### target\_canister

> **target\_canister**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L292)

##### wasm\_module\_hash

> **wasm\_module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L289)

***

### install\_code\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L296)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L297)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L300)

##### mode

> **mode**: [`canister_install_mode`](#canister_install_mode)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L299)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L301)

##### wasm\_module

> **wasm\_module**: [`wasm_module`](#wasm_module-1)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L298)

***

### list\_canister\_snapshots\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L303)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L304)

***

### list\_canisters\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L307)

#### Properties

##### canisters

> **canisters**: [`canister_id_range`](#canister_id_range)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L308)

***

### load\_canister\_snapshot\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:310](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L310)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L311)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L312)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L313)

***

### node\_metrics

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L320)

#### Properties

##### node\_id

> **node\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L322)

##### num\_block\_failures\_total

> **num\_block\_failures\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L321)

##### num\_blocks\_proposed\_total

> **num\_blocks\_proposed\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L323)

***

### node\_metrics\_history\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L325)

#### Properties

##### start\_at\_timestamp\_nanos

> **start\_at\_timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L326)

##### subnet\_id

> **subnet\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L327)

***

### outpoint

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L333)

#### Properties

##### txid

> **txid**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L334)

##### vout

> **vout**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L335)

***

### provisional\_create\_canister\_with\_cycles\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L337)

#### Properties

##### amount

> **amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L340)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L341)

##### settings

> **settings**: \[\] \| \[[`canister_settings`](#canister_settings)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L338)

##### specified\_id

> **specified\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L339)

***

### provisional\_create\_canister\_with\_cycles\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L343)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L344)

***

### provisional\_top\_up\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L346)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L348)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L347)

***

### read\_canister\_snapshot\_data\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L351)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L357)

##### kind

> **kind**: \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L352)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L358)

***

### read\_canister\_snapshot\_data\_response

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L360)

#### Properties

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L361)

***

### read\_canister\_snapshot\_metadata\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L363)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L364)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L365)

***

### read\_canister\_snapshot\_metadata\_response

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L367)

#### Properties

##### canister\_version

> **canister\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L375)

##### certified\_data

> **certified\_data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L377)

##### global\_timer

> **global\_timer**: \[\] \| \[\{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L378)

##### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L368)

##### on\_low\_wasm\_memory\_hook\_status

> **on\_low\_wasm\_memory\_hook\_status**: \[\] \| \[\{ `condition_not_satisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L379)

##### source

> **source**: \{ `metadata_upload`: `any`; \} \| \{ `taken_from_canister`: `any`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L376)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L387)

##### taken\_at\_timestamp

> **taken\_at\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L389)

##### wasm\_chunk\_store

> **wasm\_chunk\_store**: `object`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L388)

###### hash

> **hash**: `Uint8Array`

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L390)

##### wasm\_module\_size

> **wasm\_module\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L386)

***

### schnorr\_public\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L395)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L397)

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L398)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L396)

###### algorithm

> **algorithm**: [`schnorr_algorithm`](#schnorr_algorithm)

###### name

> **name**: `string`

***

### schnorr\_public\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L400)

#### Properties

##### chain\_code

> **chain\_code**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L402)

##### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L401)

***

### sign\_with\_ecdsa\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L404)

#### Properties

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L406)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L405)

###### curve

> **curve**: [`ecdsa_curve`](#ecdsa_curve)

###### name

> **name**: `string`

##### message\_hash

> **message\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L407)

***

### sign\_with\_ecdsa\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L409)

#### Properties

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L410)

***

### sign\_with\_schnorr\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L412)

#### Properties

##### aux

> **aux**: \[\] \| \[[`schnorr_aux`](#schnorr_aux)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L413)

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L415)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L414)

###### algorithm

> **algorithm**: [`schnorr_algorithm`](#schnorr_algorithm)

###### name

> **name**: `string`

##### message

> **message**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L416)

***

### sign\_with\_schnorr\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L418)

#### Properties

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L419)

***

### snapshot

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L421)

#### Properties

##### id

> **id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L422)

##### taken\_at\_timestamp

> **taken\_at\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L424)

##### total\_size

> **total\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L423)

***

### start\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L431)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L432)

***

### stop\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L434)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L435)

***

### stored\_chunks\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L437)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L438)

***

### subnet\_info\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L441)

#### Properties

##### subnet\_id

> **subnet\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L442)

***

### subnet\_info\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L444)

#### Properties

##### registry\_version

> **registry\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L446)

##### replica\_version

> **replica\_version**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L445)

***

### take\_canister\_snapshot\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L448)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:450](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L450)

##### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[[`snapshot_id`](#snapshot_id-6)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L449)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L452)

##### uninstall\_code

> **uninstall\_code**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L451)

***

### uninstall\_code\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L455)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L456)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L457)

***

### update\_settings\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L459)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L460)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L462)

##### settings

> **settings**: [`canister_settings`](#canister_settings)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:461](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L461)

***

### upload\_canister\_snapshot\_data\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L464)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L471)

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L465)

##### kind

> **kind**: \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L466)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L472)

***

### upload\_canister\_snapshot\_metadata\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L474)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L493)

##### certified\_data

> **certified\_data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L483)

##### global\_timer

> **global\_timer**: \[\] \| \[\{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L484)

##### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L475)

##### on\_low\_wasm\_memory\_hook\_status

> **on\_low\_wasm\_memory\_hook\_status**: \[\] \| \[\{ `condition_not_satisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L485)

##### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[[`snapshot_id`](#snapshot_id-6)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L482)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L494)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L495)

##### wasm\_module\_size

> **wasm\_module\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L492)

***

### upload\_canister\_snapshot\_metadata\_response

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L497)

#### Properties

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L498)

***

### upload\_chunk\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L500)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L502)

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L501)

***

### utxo

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L505)

#### Properties

##### height

> **height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L506)

##### outpoint

> **outpoint**: [`outpoint`](#outpoint)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L508)

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L507)

***

### vetkd\_derive\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L511)

#### Properties

##### context

> **context**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L512)

##### input

> **input**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L514)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L513)

###### curve

> **curve**: [`vetkd_curve`](#vetkd_curve)

###### name

> **name**: `string`

##### transport\_public\_key

> **transport\_public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L515)

***

### vetkd\_derive\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L517)

#### Properties

##### encrypted\_key

> **encrypted\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L518)

***

### vetkd\_public\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L520)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L523)

##### context

> **context**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L521)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L522)

###### curve

> **curve**: [`vetkd_curve`](#vetkd_curve)

###### name

> **name**: `string`

***

### vetkd\_public\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L525)

#### Properties

##### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L526)

## Type Aliases

### bitcoin\_address

> **bitcoin\_address** = `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L13)

***

### bitcoin\_block\_hash

> **bitcoin\_block\_hash** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L14)

***

### bitcoin\_block\_header

> **bitcoin\_block\_header** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L15)

***

### bitcoin\_block\_height

> **bitcoin\_block\_height** = `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L16)

***

### bitcoin\_get\_balance\_result

> **bitcoin\_get\_balance\_result** = [`satoshi`](#satoshi)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L22)

***

### bitcoin\_get\_current\_fee\_percentiles\_result

> **bitcoin\_get\_current\_fee\_percentiles\_result** = `BigUint64Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L35)

***

### bitcoin\_network

> **bitcoin\_network** = \{ `mainnet`: `null`; \} \| \{ `testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L47)

***

### canister\_id

> **canister\_id** = `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L52)

***

### canister\_install\_mode

> **canister\_install\_mode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; `wasm_memory_persistence`: \[\] \| \[\{ `keep`: `null`; \} \| \{ `replace`: `null`; \}\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L67)

***

### change\_details

> **change\_details** = \{ `creation`: \{ `controllers`: `Principal`[]; `environment_variables_hash`: \[\] \| \[`Uint8Array`\]; \}; \} \| \{ `code_deployment`: \{ `mode`: \{ `reinstall`: `null`; \} \| \{ `upgrade`: `null`; \} \| \{ `install`: `null`; \}; `module_hash`: `Uint8Array`; \}; \} \| \{ `load_snapshot`: \{ `canister_version`: `bigint`; `from_canister_id`: \[\] \| \[`Principal`\]; `snapshot_id`: [`snapshot_id`](#snapshot_id-6); `source`: \{ `metadata_upload`: `any`; \} \| \{ `taken_from_canister`: `any`; \}; `taken_at_timestamp`: `bigint`; \}; \} \| \{ `rename_canister`: \{ `canister_id`: [`canister_id`](#canister_id-29); `rename_to`: \{ `canister_id`: [`canister_id`](#canister_id-29); `total_num_changes`: `bigint`; `version`: `bigint`; \}; `requested_by`: `Principal`; `total_num_changes`: `bigint`; \}; \} \| \{ `controllers_change`: \{ `controllers`: `Principal`[]; \}; \} \| \{ `code_uninstall`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L148)

***

### change\_origin

> **change\_origin** = \{ `from_user`: \{ `user_id`: `Principal`; \}; \} \| \{ `from_canister`: \{ `canister_id`: [`canister_id`](#canister_id-29); `canister_version`: \[\] \| \[`bigint`\]; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L184)

***

### ecdsa\_curve

> **ecdsa\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L244)

#### Properties

##### secp256k1

> **secp256k1**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L244)

***

### list\_canister\_snapshots\_result

> **list\_canister\_snapshots\_result** = [`snapshot`](#snapshot)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L306)

***

### log\_visibility

> **log\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L315)

***

### millisatoshi\_per\_byte

> **millisatoshi\_per\_byte** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L319)

***

### node\_metrics\_history\_result

> **node\_metrics\_history\_result** = `object`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L329)

#### Type Declaration

##### node\_metrics

> **node\_metrics**: [`node_metrics`](#node_metrics)[]

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

***

### raw\_rand\_result

> **raw\_rand\_result** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L350)

***

### satoshi

> **satoshi** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L392)

***

### schnorr\_algorithm

> **schnorr\_algorithm** = \{ `ed25519`: `null`; \} \| \{ `bip340secp256k1`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L393)

***

### schnorr\_aux

> **schnorr\_aux** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L394)

#### Properties

##### bip341

> **bip341**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L394)

###### merkle\_root\_hash

> **merkle\_root\_hash**: `Uint8Array`

***

### snapshot\_id

> **snapshot\_id** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L426)

***

### snapshot\_visibility

> **snapshot\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L427)

***

### stored\_chunks\_result

> **stored\_chunks\_result** = [`chunk_hash`](#chunk_hash)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L440)

***

### take\_canister\_snapshot\_result

> **take\_canister\_snapshot\_result** = [`snapshot`](#snapshot)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L454)

***

### upload\_chunk\_result

> **upload\_chunk\_result** = [`chunk_hash`](#chunk_hash)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L504)

***

### vetkd\_curve

> **vetkd\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L510)

#### Properties

##### bls12\_381\_g2

> **bls12\_381\_g2**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L510)

***

### wasm\_module

> **wasm\_module** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L528)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:679](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L679)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L680)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
