---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [CmcDid](namespaces/CmcDid.md)

## Classes

### CmcCanister

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:12](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L12)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/CmcDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new CmcCanister**(`id`, `service`, `certifiedService`): [`CmcCanister`](#cmccanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/CmcDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/CmcDid.md#_service)

###### Returns

[`CmcCanister`](#cmccanister)

###### Inherited from

`Canister<CmcService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/CmcDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/CmcDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/CmcDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/CmcDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### getDefaultSubnets()

> **getDefaultSubnets**(`params?`): `Promise`\<`Principal`[]\>

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L153)

This function calls the `get_default_subnets` method of the CMC canister, which returns a list of
default subnets as `Principal` objects. It can be called as query or update.

###### Parameters

###### params?

`QueryParams` = `{}`

The query parameters for the call.

###### Returns

`Promise`\<`Principal`[]\>

- A promise that resolves to an array of `Principal` objects
representing the default subnets.

##### getIcpToCyclesConversionRate()

> **getIcpToCyclesConversionRate**(`params?`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L32)

Returns conversion rate of ICP to Cycles. It can be called as query or update.

###### Parameters

###### params?

`QueryParams` = `{}`

The parameters for the call.

###### Returns

`Promise`\<`bigint`\>

Promise<BigInt>

##### getSubnetTypesToSubnets()

> **getSubnetTypesToSubnets**(`params?`): `Promise`\<[`SubnetTypesToSubnetsResponse`](namespaces/CmcDid.md#subnettypestosubnetsresponse)\>

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:172](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L172)

This function calls the `get_subnet_types_to_subnets` method of the CMC canister, which returns a list of subnets where canisters can be created.
These subnets are excluded from the random subnet selection process used by the CMC when no explicit subnet ID is provided
during canister creation and therefore, not provided in the results of the similar function `get_default_subnets`.

###### Parameters

###### params?

`QueryParams` = `{}`

The optional query parameters for the call.

###### Returns

`Promise`\<[`SubnetTypesToSubnetsResponse`](namespaces/CmcDid.md#subnettypestosubnetsresponse)\>

- A promise that resolves to an object representing
the mapping of subnet types to subnets.

##### notifyCreateCanister()

> **notifyCreateCanister**(`request`): `Promise`\<`Principal`\>

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L56)

Notifies CMC (Cycles Minting Canister) of the creation of a new canister.

###### Parameters

###### request

[`NotifyCreateCanisterArg`](namespaces/CmcDid.md#notifycreatecanisterarg)

###### Returns

`Promise`\<`Principal`\>

Promise<Principal> The principal of the newly created canister

###### Throws

RefundedError, InvalidaTransactionError, ProcessingError, TransactionTooOldError, CmcError

##### notifyMintCycles()

> **notifyMintCycles**(`request`): `Promise`\<[`NotifyMintCyclesSuccess`](namespaces/CmcDid.md#notifymintcyclessuccess)\>

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:121](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L121)

Notifies the CMC (Cycles Minting Canister) to mint cycles and deposit them to a cycles ledger account owned by the caller.
This function is commonly used to finalize the process of converting ICP to cycles.

###### Parameters

###### request

[`NotifyMintCyclesArg`](namespaces/CmcDid.md#notifymintcyclesarg)

###### Returns

`Promise`\<[`NotifyMintCyclesSuccess`](namespaces/CmcDid.md#notifymintcyclessuccess)\>

Promise<Cycles> The new cycles of the canister

###### Throws

RefundedError, InvalidTransactionError, ProcessingError, TransactionTooOldError, CmcError

##### notifyTopUp()

> **notifyTopUp**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:89](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L89)

Notifies the CMC (Cycles Minting Canister) of new cycles being added to a canister.
This function is commonly used to finalize the process of topping up a canister using ICP.

###### Parameters

###### request

[`NotifyTopUpArg`](namespaces/CmcDid.md#notifytopuparg)

###### Returns

`Promise`\<`bigint`\>

Promise<Cycles> The new cycles of the canister

###### Throws

RefundedError, InvalidTransactionError, ProcessingError, TransactionTooOldError, CmcError

##### create()

> `static` **create**(`options`): [`CmcCanister`](#cmccanister)

Defined in: [packages/canisters/src/cmc/cmc.canister.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.canister.ts#L13)

###### Parameters

###### options

[`CmcCanisterOptions`](#cmccanisteroptions)

###### Returns

[`CmcCanister`](#cmccanister)

***

### CmcError

Defined in: [packages/canisters/src/cmc/cmc.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.errors.ts#L6)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new CmcError**(`message?`): [`CmcError`](#cmcerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`CmcError`](#cmcerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new CmcError**(`message?`, `options?`): [`CmcError`](#cmcerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`CmcError`](#cmcerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### InvalidaTransactionError

Defined in: [packages/canisters/src/cmc/cmc.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.errors.ts#L5)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new InvalidaTransactionError**(`message?`): [`InvalidaTransactionError`](#invalidatransactionerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`InvalidaTransactionError`](#invalidatransactionerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new InvalidaTransactionError**(`message?`, `options?`): [`InvalidaTransactionError`](#invalidatransactionerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`InvalidaTransactionError`](#invalidatransactionerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### ProcessingError

Defined in: [packages/canisters/src/cmc/cmc.errors.ts:7](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.errors.ts#L7)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new ProcessingError**(`message?`): [`ProcessingError`](#processingerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ProcessingError`](#processingerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new ProcessingError**(`message?`, `options?`): [`ProcessingError`](#processingerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ProcessingError`](#processingerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### RefundedError

Defined in: [packages/canisters/src/cmc/cmc.errors.ts:4](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.errors.ts#L4)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new RefundedError**(`message?`): [`RefundedError`](#refundederror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`RefundedError`](#refundederror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new RefundedError**(`message?`, `options?`): [`RefundedError`](#refundederror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`RefundedError`](#refundederror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### TransactionTooOldError

Defined in: [packages/canisters/src/cmc/cmc.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.errors.ts#L8)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new TransactionTooOldError**(`message?`): [`TransactionTooOldError`](#transactiontooolderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`TransactionTooOldError`](#transactiontooolderror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new TransactionTooOldError**(`message?`, `options?`): [`TransactionTooOldError`](#transactiontooolderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`TransactionTooOldError`](#transactiontooolderror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

## Interfaces

### CmcCanisterOptions

Defined in: [packages/canisters/src/cmc/cmc.options.ts:5](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.options.ts#L5)

#### Extends

- `Omit`\<`CanisterOptions`\<[`_SERVICE`](namespaces/CmcDid.md#_service)\>, `"canisterId"`\>

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

###### Inherited from

[`NnsGovernanceCanisterOptions`](../nns/index.md#nnsgovernancecanisteroptions).[`agent`](../nns/index.md#agent)

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/cmc/cmc.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.options.ts#L9)

##### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/CmcDid.md#_service)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

###### Inherited from

`Omit.certifiedServiceOverride`

##### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<[`_SERVICE`](namespaces/CmcDid.md#_service)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

###### Inherited from

`Omit.serviceOverride`

## Functions

### throwNotifyError()

> **throwNotifyError**(`__namedParameters`): `void`

Defined in: [packages/canisters/src/cmc/cmc.errors.ts:11](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/cmc/cmc.errors.ts#L11)

#### Parameters

##### \_\_namedParameters

###### Err

[`NotifyError`](namespaces/CmcDid.md#notifyerror)

#### Returns

`void`
