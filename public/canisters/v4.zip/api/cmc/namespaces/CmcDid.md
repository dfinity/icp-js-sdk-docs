---
title: CmcDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L304)

#### Properties

##### change\_subnet\_type\_assignment

> **change\_subnet\_type\_assignment**: `ActorMethod`\<\[[`ChangeSubnetTypeAssignmentArgs`](#changesubnettypeassignmentargs)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L305)

##### create\_canister

> **create\_canister**: `ActorMethod`\<\[[`CreateCanisterArg`](#createcanisterarg)\], [`CreateCanisterResult`](#createcanisterresult)\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L312)

Creates a canister using the cycles attached to the function call.

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L313)

##### get\_default\_subnets

> **get\_default\_subnets**: `ActorMethod`\<\[\], `Principal`[]\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L314)

##### get\_icp\_xdr\_conversion\_rate

> **get\_icp\_xdr\_conversion\_rate**: `ActorMethod`\<\[\], [`IcpXdrConversionRateResponse`](#icpxdrconversionrateresponse)\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L318)

Returns the ICP/XDR conversion rate.

##### get\_principals\_authorized\_to\_create\_canisters\_to\_subnets

> **get\_principals\_authorized\_to\_create\_canisters\_to\_subnets**: `ActorMethod`\<\[\], [`PrincipalsAuthorizedToCreateCanistersToSubnetsResponse`](#principalsauthorizedtocreatecanisterstosubnetsresponse)\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L323)

Returns the mapping from principals to subnets in which they are authorized
to create canisters.

##### get\_subnet\_types\_to\_subnets

> **get\_subnet\_types\_to\_subnets**: `ActorMethod`\<\[\], [`SubnetTypesToSubnetsResponse`](#subnettypestosubnetsresponse)\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L330)

Returns the current mapping of subnet types to subnets.

##### notify\_create\_canister

> **notify\_create\_canister**: `ActorMethod`\<\[[`NotifyCreateCanisterArg`](#notifycreatecanisterarg)\], [`NotifyCreateCanisterResult`](#notifycreatecanisterresult)\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L334)

Prompts the cycles minting canister to process a payment for canister creation.

##### notify\_mint\_cycles

> **notify\_mint\_cycles**: `ActorMethod`\<\[[`NotifyMintCyclesArg`](#notifymintcyclesarg)\], [`NotifyMintCyclesResult`](#notifymintcyclesresult)\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L341)

Mints cycles and deposits them to the cycles ledger

##### notify\_top\_up

> **notify\_top\_up**: `ActorMethod`\<\[[`NotifyTopUpArg`](#notifytopuparg)\], [`NotifyTopUpResult`](#notifytopupresult)\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L349)

Prompts the cycles minting canister to process a payment by converting ICP
into cycles and sending the cycles the specified canister.

##### set\_authorized\_subnetwork\_list

> **set\_authorized\_subnetwork\_list**: `ActorMethod`\<\[[`SetAuthorizedSubnetworkListArgs`](#setauthorizedsubnetworklistargs)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L353)

Below are methods that can only be called by other NNS canisters.

##### update\_subnet\_type

> **update\_subnet\_type**: `ActorMethod`\<\[[`UpdateSubnetTypeArgs`](#updatesubnettypeargs)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L357)

***

### CanisterSettings

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L15)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L26)

##### controllers

> **controllers**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L19)

##### environment\_variables

> **environment\_variables**: \[\] \| \[[`environment_variable`](#environment_variable)[]\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L18)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L16)

##### log\_memory\_limit

> **log\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L22)

##### log\_visibility

> **log\_visibility**: \[\] \| \[[`log_visibility`](#log_visibility-1)\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L21)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L25)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L20)

##### snapshot\_visibility

> **snapshot\_visibility**: \[\] \| \[[`snapshot_visibility`](#snapshot_visibility-1)\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L23)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L24)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L17)

***

### CreateCanisterArg

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L34)

The argument of the [create_canister] method.

#### Properties

##### settings

> **settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L43)

Optional canister settings that, if set, are applied to the newly created canister.
If not specified, the caller is the controller of the canister and the other settings are set to default values.

##### subnet\_selection

> **subnet\_selection**: \[\] \| \[[`SubnetSelection`](#subnetselection)\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L38)

Optional instructions to select on which subnet the new canister will be created on.

##### subnet\_type

> **subnet\_type**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L49)

An optional subnet type that, if set, determines what type of subnet
the new canister will be created on.
Deprecated. Use subnet_selection instead.

***

### CyclesCanisterInitPayload

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L76)

#### Properties

##### cycles\_ledger\_canister\_id

> **cycles\_ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L78)

##### exchange\_rate\_canister

> **exchange\_rate\_canister**: \[\] \| \[[`ExchangeRateCanister`](#exchangeratecanister)\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L77)

##### governance\_canister\_id

> **governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L80)

##### last\_purged\_notification

> **last\_purged\_notification**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L79)

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L82)

##### minting\_account\_id

> **minting\_account\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L81)

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L292)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L294)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L293)

***

### IcpXdrConversionRate

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L97)

#### Properties

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L107)

The time for which the market data was queried, expressed in UNIX epoch
time in seconds.

##### xdr\_permyriad\_per\_icp

> **xdr\_permyriad\_per\_icp**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L102)

The number of 10,000ths of IMF SDR (currency code XDR) that corresponds
to 1 ICP. This value reflects the current market price of one ICP token.

***

### IcpXdrConversionRateResponse

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L109)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L114)

System certificate as specified in
https://internetcomputer.org/docs/interface-spec/index.html#certification-encoding

##### data

> **data**: [`IcpXdrConversionRate`](#icpxdrconversionrate)

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L118)

The latest ICP/XDR conversion rate.

##### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L131)

CBOR-serialized hash tree as specified in
https://internetcomputer.org/docs/interface-spec/index.html#certification-encoding
The hash tree is used for certification and hash the following structure:
```
*
|
+-- ICP_XDR_CONVERSION_RATE -- [ Candid encoded IcpXdrConversionRate ]
|
`-- AVERAGE_ICP_XDR_CONVERSION_RATE -- [ Candid encoded IcpXdrConversionRate ]
```

***

### NotifyCreateCanisterArg

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L137)

The argument of the [notify_create_canister] method.

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L145)

Index of the block on the ICP ledger that contains the payment.

##### controller

> **controller**: `Principal`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L141)

The controller of canister to create.

##### settings

> **settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L155)

Optional canister settings that, if set, are applied to the newly created canister.
If not specified, the caller is the controller of the canister and the other settings are set to default values.

##### subnet\_selection

> **subnet\_selection**: \[\] \| \[[`SubnetSelection`](#subnetselection)\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L150)

Optional instructions to select on which subnet the new canister will be created on.
vec may contain no more than one element.

##### subnet\_type

> **subnet\_type**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L161)

An optional subnet type that, if set, determines what type of subnet
the new canister will be created on.
Deprecated. Use subnet_selection instead.

***

### NotifyMintCyclesArg

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L217)

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L218)

##### deposit\_memo

> **deposit\_memo**: [`Memo`](#memo)

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L219)

##### to\_subaccount

> **to\_subaccount**: [`Subaccount`](#subaccount)

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L220)

***

### NotifyMintCyclesSuccess

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L225)

#### Properties

##### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L229)

New balance of the cycles ledger account

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L233)

Cycles ledger block index of deposit

##### minted

> **minted**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L237)

Amount of cycles that were minted and deposited to the cycles ledger

***

### NotifyTopUpArg

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L242)

The argument of the [notify_top_up] method.

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L246)

Index of the block on the ICP ledger that contains the payment.

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L250)

The canister to top up.

***

### PrincipalsAuthorizedToCreateCanistersToSubnetsResponse

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L260)

#### Properties

##### data

> **data**: \[`Principal`, `Principal`[]\][]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L261)

***

### SetAuthorizedSubnetworkListArgs

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L263)

#### Properties

##### subnets

> **subnets**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L265)

##### who

> **who**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L264)

***

### SubnetFilter

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L268)

#### Properties

##### subnet\_type

> **subnet\_type**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L269)

***

### SubnetListWithType

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L271)

#### Properties

##### subnet\_type

> **subnet\_type**: `string`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L273)

##### subnets

> **subnets**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L272)

***

### SubnetTypesToSubnetsResponse

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L288)

#### Properties

##### data

> **data**: \[`string`, `Principal`[]\][]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L289)

## Type Aliases

### AccountIdentifier

> **AccountIdentifier** = `string`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L13)

***

### BlockIndex

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L14)

***

### ChangeSubnetTypeAssignmentArgs

> **ChangeSubnetTypeAssignmentArgs** = \{ `Add`: [`SubnetListWithType`](#subnetlistwithtype); \} \| \{ `Remove`: [`SubnetListWithType`](#subnetlistwithtype); \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L28)

***

### CreateCanisterError

> **CreateCanisterError** = `object`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L55)

Canister creation failed and the cycles attached to the call were returned to the calling canister.
A small fee may be charged.

#### Properties

##### Refunded

> **Refunded**: `object`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L56)

###### create\_error

> **create\_error**: `string`

The reason why creating a canister failed.

###### refund\_amount

> **refund\_amount**: `bigint`

The amount of cycles returned to the calling canister

***

### CreateCanisterResult

> **CreateCanisterResult** = \{ `Ok`: `Principal`; \} \| \{ `Err`: [`CreateCanisterError`](#createcanistererror); \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L67)

#### Type Declaration

\{ `Ok`: `Principal`; \}

##### Ok

> **Ok**: `Principal`

The principal of the newly created canister.

\{ `Err`: [`CreateCanisterError`](#createcanistererror); \}

##### Err

> **Err**: [`CreateCanisterError`](#createcanistererror)

***

### Cycles

> **Cycles** = `bigint`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L75)

***

### ExchangeRateCanister

> **ExchangeRateCanister** = \{ `Set`: `Principal`; \} \| \{ `Unset`: `null`; \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L84)

#### Type Declaration

\{ `Set`: `Principal`; \}

##### Set

> **Set**: `Principal`

/ Enables the exchange rate canister with the given canister ID.

\{ `Unset`: `null`; \}

##### Unset

> **Unset**: `null`

/ Disable the exchange rate canister.

***

### log\_visibility

> **log\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L296)

***

### Memo

> **Memo** = \[\] \| \[`Uint8Array`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L133)

***

### NotifyCreateCanisterResult

> **NotifyCreateCanisterResult** = \{ `Ok`: `Principal`; \} \| \{ `Err`: [`NotifyError`](#notifyerror); \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L163)

#### Type Declaration

\{ `Ok`: `Principal`; \}

##### Ok

> **Ok**: `Principal`

The principal of the newly created canister.

\{ `Err`: [`NotifyError`](#notifyerror); \}

##### Err

> **Err**: [`NotifyError`](#notifyerror)

***

### NotifyError

> **NotifyError** = \{ `Refunded`: \{ `block_index`: \[\] \| \[[`BlockIndex`](#blockindex)\]; `reason`: `string`; \}; \} \| \{ `InvalidTransaction`: `string`; \} \| \{ `Other`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \} \| \{ `Processing`: `null`; \} \| \{ `TransactionTooOld`: [`BlockIndex`](#blockindex); \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L171)

#### Type Declaration

\{ `Refunded`: \{ `block_index`: \[\] \| \[[`BlockIndex`](#blockindex)\]; `reason`: `string`; \}; \}

##### Refunded

> **Refunded**: `object`

The payment processing failed and the payment was returned the caller.
This is a non-retriable error.

###### Refunded.block\_index

> **block\_index**: \[\] \| \[[`BlockIndex`](#blockindex)\]

The index of the block containing the refund.

###### Refunded.reason

> **reason**: `string`

The reason for the refund.

\{ `InvalidTransaction`: `string`; \}

##### InvalidTransaction

> **InvalidTransaction**: `string`

The transaction does not satisfy the cycle minting canister payment protocol.
The text contains the description of the problem.
This is a non-retriable error.

\{ `Other`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### Other

> **Other**: `object`

Other error.

###### Other.error\_code

> **error\_code**: `bigint`

###### Other.error\_message

> **error\_message**: `string`

\{ `Processing`: `null`; \}

##### Processing

> **Processing**: `null`

The same payment is already being processed by a concurrent request.
This is a retriable error.

\{ `TransactionTooOld`: [`BlockIndex`](#blockindex); \}

##### TransactionTooOld

> **TransactionTooOld**: [`BlockIndex`](#blockindex)

The payment was too old to be processed.
The value of the variant is the oldest block index that can still be processed.
This a non-retriable error.

***

### NotifyMintCyclesResult

> **NotifyMintCyclesResult** = \{ `Ok`: [`NotifyMintCyclesSuccess`](#notifymintcyclessuccess); \} \| \{ `Err`: [`NotifyError`](#notifyerror); \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L222)

***

### NotifyTopUpResult

> **NotifyTopUpResult** = \{ `Ok`: [`Cycles`](#cycles); \} \| \{ `Err`: [`NotifyError`](#notifyerror); \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L252)

#### Type Declaration

\{ `Ok`: [`Cycles`](#cycles); \}

##### Ok

> **Ok**: [`Cycles`](#cycles)

The amount of cycles sent to the specified canister.

\{ `Err`: [`NotifyError`](#notifyerror); \}

##### Err

> **Err**: [`NotifyError`](#notifyerror)

***

### snapshot\_visibility

> **snapshot\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L300)

***

### Subaccount

> **Subaccount** = \[\] \| \[`Uint8Array`\]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L267)

***

### SubnetSelection

> **SubnetSelection** = \{ `Filter`: [`SubnetFilter`](#subnetfilter); \} \| \{ `Subnet`: \{ `subnet`: `Principal`; \}; \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L275)

#### Type Declaration

\{ `Filter`: [`SubnetFilter`](#subnetfilter); \}

##### Filter

> **Filter**: [`SubnetFilter`](#subnetfilter)

/ Choose a random subnet that fulfills the specified properties

\{ `Subnet`: \{ `subnet`: `Principal`; \}; \}

##### Subnet

> **Subnet**: `object`

/ Choose a specific subnet

###### Subnet.subnet

> **subnet**: `Principal`

***

### UpdateSubnetTypeArgs

> **UpdateSubnetTypeArgs** = \{ `Add`: `string`; \} \| \{ `Remove`: `string`; \}

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L291)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L359)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cmc/cmc.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cmc/cmc.d.ts#L360)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
