---
title: CkBtcMinterDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:957](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L957)

#### Properties

##### decode\_ledger\_memo

> **decode\_ledger\_memo**: `ActorMethod`\<\[[`DecodeLedgerMemoArgs`](#decodeledgermemoargs)\], [`DecodeLedgerMemoResult`](#decodeledgermemoresult)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:962](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L962)

Section "Transaction Information" {{{
Returns information related to minter transactions.

##### estimate\_withdrawal\_fee

> **estimate\_withdrawal\_fee**: `ActorMethod`\<\[\{ `amount`: \[\] \| \[`bigint`\]; \}\], \{ `bitcoin_fee`: `bigint`; `minter_fee`: `bigint`; \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:970](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L970)

/ Returns an estimate of the user's fee (in Satoshi) for a
/ retrieve_btc request based on the current status of the Bitcoin network.

##### get\_btc\_address

> **get\_btc\_address**: `ActorMethod`\<\[\{ `owner`: \[\] \| \[`Principal`\]; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}\], `string`\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:982](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L982)

Returns the Bitcoin address to which the owner should send BTC
before converting the amount to ckBTC using the [update_balance]
endpoint.

If the owner is not set, it defaults to the caller's principal.
The resolved owner must be a non-anonymous principal.

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:986](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L986)

##### get\_deposit\_fee

> **get\_deposit\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:990](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L990)

/ Returns the fee that the minter will charge for a bitcoin deposit.

##### get\_events

> **get\_events**: `ActorMethod`\<\[\{ `length`: `bigint`; `start`: `bigint`; \}\], [`Event`](#event)[]\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1002](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1002)

The minter keeps track of all state modifications in an internal event log.

This method returns a list of events in the specified range.
The minter can return fewer events than requested. The result is
an empty vector if the start position is greater than the total
number of events.

NOTE: this method exists for debugging purposes.
The ckBTC minter authors do not guarantee backward compatibility for this method.

##### get\_known\_utxos

> **get\_known\_utxos**: `ActorMethod`\<\[\{ `owner`: \[\] \| \[`Principal`\]; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}\], [`Utxo`](#utxo-1)[]\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1009)

Returns UTXOs of the given account known by the minter (with no
guarantee in the ordering of the returned values).

If the owner is not set, it defaults to the caller's principal.

##### get\_minter\_info

> **get\_minter\_info**: `ActorMethod`\<\[\], [`MinterInfo`](#minterinfo)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1017](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1017)

Section "Minter Information" {{{
Returns internal minter parameters.

##### get\_withdrawal\_account

> **get\_withdrawal\_account**: `ActorMethod`\<\[\], [`Account`](#account)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1022](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1022)

Returns the account to which the caller should deposit ckBTC
before withdrawing BTC using the [retrieve_btc] endpoint.

##### icrc10\_supported\_standards

> **icrc10\_supported\_standards**: `ActorMethod`\<\[\], [`Icrc10StandardRecord`](#icrc10standardrecord)[]\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1026](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1026)

Returns the list of supported ICRC standards.

##### icrc21\_canister\_call\_consent\_message

> **icrc21\_canister\_call\_consent\_message**: `ActorMethod`\<\[[`Icrc21ConsentMessageRequest`](#icrc21consentmessagerequest)\], \{ `Ok`: [`Icrc21ConsentInfo`](#icrc21consentinfo); \} \| \{ `Err`: [`Icrc21Error`](#icrc21error); \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1032](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1032)

Returns a human-readable consent message describing the requested
canister call. See the ICRC-21 standard for details:
https://github.com/dfinity/ICRC/blob/main/ICRCs/ICRC-21/ICRC-21.md

##### retrieve\_btc

> **retrieve\_btc**: `ActorMethod`\<\[[`RetrieveBtcArgs`](#retrievebtcargs)\], \{ `Ok`: [`RetrieveBtcOk`](#retrievebtcok); \} \| \{ `Err`: [`RetrieveBtcError`](#retrievebtcerror); \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1051](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1051)

Submits a request to convert ckBTC to BTC.


The BTC retrieval process is slow.  Instead of
synchronously waiting for a BTC transaction to settle, this
method returns a request ([block_index]) that the caller can use
to query the request status.

# Preconditions

* The caller deposited the requested amount in ckBTC to the account
that the [get_withdrawal_account] endpoint returns.

##### retrieve\_btc\_status

> **retrieve\_btc\_status**: `ActorMethod`\<\[\{ `block_index`: `bigint`; \}\], [`RetrieveBtcStatus`](#retrievebtcstatus)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1059](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1059)

/ [deprecated] Returns the status of a withdrawal request.
/ You should use retrieve_btc_status_v2 to retrieve the status of your withdrawal request.

##### retrieve\_btc\_status\_v2

> **retrieve\_btc\_status\_v2**: `ActorMethod`\<\[\{ `block_index`: `bigint`; \}\], [`RetrieveBtcStatusV2`](#retrievebtcstatusv2)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1066](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1066)

/ Returns the status of a withdrawal request request using the RetrieveBtcStatusV2 type.

##### retrieve\_btc\_status\_v2\_by\_account

> **retrieve\_btc\_status\_v2\_by\_account**: `ActorMethod`\<\[\[\] \| \[[`Account`](#account)\]\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1078](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1078)

Returns the withdrawal statues by account.

# Note
The _v2_ part indicates that you get a response in line with the retrieve_btc_status_v2 endpoint,
i.e., you get a vector of RetrieveBtcStatusV2 and not RetrieveBtcStatus.

##### retrieve\_btc\_with\_approval

> **retrieve\_btc\_with\_approval**: `ActorMethod`\<\[[`RetrieveBtcWithApprovalArgs`](#retrievebtcwithapprovalargs)\], \{ `Ok`: [`RetrieveBtcOk`](#retrievebtcok); \} \| \{ `Err`: [`RetrieveBtcWithApprovalError`](#retrievebtcwithapprovalerror); \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1097](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1097)

Submits a request to convert ckBTC to BTC.

# Note

The BTC retrieval process is slow.  Instead of
synchronously waiting for a BTC transaction to settle, this
method returns a request ([block_index]) that the caller can use
to query the request status.

# Preconditions

* The caller allowed the minter's principal to spend its funds
using [icrc2_approve] on the ckBTC ledger.

##### update\_balance

> **update\_balance**: `ActorMethod`\<\[\{ `owner`: \[\] \| \[`Principal`\]; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}\], \{ `Ok`: [`UtxoStatus`](#utxostatus)[]; \} \| \{ `Err`: [`UpdateBalanceError`](#updatebalanceerror); \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1111)

Mints ckBTC for newly deposited UTXOs.

If the owner is not set, it defaults to the caller's principal.

# Preconditions

* The owner deposited some BTC to the address that the
[get_btc_address] endpoint returns.

***

### Account

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L16)

Represents an account on the ckBTC ledger.

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L17)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L18)

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L80)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L86)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L89)

##### memory\_metrics

> **memory\_metrics**: [`MemoryMetrics`](#memorymetrics)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L81)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L83)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L90)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L88)

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L84)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L91)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L87)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L82)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L85)

***

### DecodeLedgerMemoArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L97)

#### Properties

##### encoded\_memo

> **encoded\_memo**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L105)

The encoded memo from a minter transaction on the ledger

##### memo\_type

> **memo\_type**: [`MemoType`](#memotype)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L101)

The encoded memo type

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L141)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L150)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L145)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L144)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L142)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L147)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L149)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L146)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L148)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L143)

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:953](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L953)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:955](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L955)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:954](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L954)

***

### Event

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L152)

#### Properties

##### payload

> **payload**: [`EventType`](#eventtype)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L154)

##### timestamp

> **timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L153)

***

### Icrc10StandardRecord

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L277)

ICRC-10 supported standards record.

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L279)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L278)

***

### Icrc21ConsentInfo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L281)

#### Properties

##### consent\_message

> **consent\_message**: [`Icrc21ConsentMessage`](#icrc21consentmessage)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L283)

##### metadata

> **metadata**: [`Icrc21ConsentMessageMetadata`](#icrc21consentmessagemetadata)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L282)

***

### Icrc21ConsentMessageMetadata

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L293)

ICRC-21 Canister Call Consent Message types.

#### Properties

##### language

> **language**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L295)

##### utc\_offset\_minutes

> **utc\_offset\_minutes**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L294)

***

### Icrc21ConsentMessageRequest

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L297)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L298)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L299)

##### user\_preferences

> **user\_preferences**: [`Icrc21ConsentMessageSpec`](#icrc21consentmessagespec)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L300)

***

### Icrc21ConsentMessageSpec

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:302](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L302)

#### Properties

##### device\_spec

> **device\_spec**: \[\] \| \[[`Icrc21DeviceSpec`](#icrc21devicespec)\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L304)

##### metadata

> **metadata**: [`Icrc21ConsentMessageMetadata`](#icrc21consentmessagemetadata)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L303)

***

### Icrc21ErrorInfo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L316)

#### Properties

##### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L317)

***

### Icrc21FieldsDisplay

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L319)

#### Properties

##### fields

> **fields**: \[`string`, [`Icrc21Value`](#icrc21value)\][]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L320)

##### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L321)

***

### InitArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L337)

The initialization parameters of the minter canister.

#### Properties

##### btc\_checker\_principal

> **btc\_checker\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L394)

/ The canister id of the Bitcoin checker canister.

##### btc\_network

> **btc\_network**: [`BtcNetwork`](#btcnetwork)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L378)

The minter will interact with this Bitcoin network.

##### check\_fee

> **check\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L382)

/ The fee paid per Bitcoin check.

##### deposit\_btc\_min\_amount

> **deposit\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L363)

The minimal amount of BTC that can be converted to ckBTC.
UTXOs with lower values will be ignored.

##### ecdsa\_key\_name

> **ecdsa\_key\_name**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L350)

The name of the ECDSA key to use.
E.g., "dfx_test_key" on the local replica.

##### get\_utxos\_cache\_expiration\_seconds

> **get\_utxos\_cache\_expiration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L341)

/ The expiration duration (in seconds) for cached entries in the get_utxos cache.

##### kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L403)

/ The fee paid per check by the KYT canister (deprecated, use check_fee instead).

##### kyt\_principal

> **kyt\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L345)

/ The canister id of the KYT canister (deprecated, use btc_checker_principal instead).

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L369)

The principal of the ledger that handles ckBTC transfers.
The default account of the ckBTC minter must be configured as
the minting account of the ledger.

##### max\_num\_inputs\_in\_transaction

> **max\_num\_inputs\_in\_transaction**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L386)

/ The maximum number of input UTXOs allowed in a transaction.

##### max\_time\_in\_queue\_nanos

> **max\_time\_in\_queue\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L374)

/ Maximum time in nanoseconds that a transaction should spend in the queue
/ before being sent.

##### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L399)

/ The minimum number of confirmations required for the minter to
/ accept a Bitcoin transaction.

##### mode

> **mode**: [`Mode`](#mode-2)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L354)

/ The minter's operation mode.

##### retrieve\_btc\_min\_amount

> **retrieve\_btc\_min\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L358)

The minimal amount of ckBTC that can be converted to BTC.

##### utxo\_consolidation\_threshold

> **utxo\_consolidation\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L390)

/ The minimum number of available UTXOs to trigger a consolidation.

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L413)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L416)

##### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L421)

##### global\_memory\_size

> **global\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L420)

##### snapshots\_size

> **snapshots\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L418)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L417)

##### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L414)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L415)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L419)

***

### MinterInfo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L476)

#### Properties

##### deposit\_btc\_min\_amount

> **deposit\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L486)

Minimal amount of BTC that can be deposited to be converted into ckBTC.
UTXOs with lower values will be ignored.

##### kyt\_fee

> **kyt\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L491)

The same as `check_fee`, but the old name is kept here to be backward compatible.

##### min\_confirmations

> **min\_confirmations**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L487)

##### retrieve\_btc\_min\_amount

> **retrieve\_btc\_min\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L481)

This amount is based on the `retrieve_btc_min_amount` setting during canister
initialization or upgrades, but may vary according to current network fees.

***

### PendingUtxo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L521)

Utxos that don't have enough confirmations to be processed.

#### Properties

##### confirmations

> **confirmations**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L522)

##### outpoint

> **outpoint**: `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L524)

###### txid

> **txid**: `Uint8Array`

###### vout

> **vout**: `number`

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L523)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L526)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L529)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L528)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L530)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L527)

***

### ReimbursedDeposit

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L532)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L533)

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L535)

##### mint\_block\_index

> **mint\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L534)

##### reason

> **reason**: [`ReimbursementReason`](#reimbursementreason)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L536)

***

### ReimbursementRequest

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L541)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L542)

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L543)

##### reason

> **reason**: [`ReimbursementReason`](#reimbursementreason)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:544](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L544)

***

### RetrieveBtcArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L551)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L555)

The address to which the ckBTC minter should deposit BTC.

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L559)

The amount of ckBTC in Satoshis that the client wants to withdraw.

***

### RetrieveBtcOk

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L601)

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:606](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L606)

Returns the burn transaction index corresponding to the withdrawal.
You can use this index to query the withdrawal status.

***

### RetrieveBtcWithApprovalArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:722](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L722)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:730](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L730)

The address to which the ckBTC minter should deposit BTC.

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L734)

The amount of ckBTC in Satoshis that the client wants to withdraw.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:726](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L726)

The subaccount to burn ckBTC from.

***

### SuspendedUtxo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:810](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L810)

#### Properties

##### earliest\_retry

> **earliest\_retry**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:812](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L812)

##### reason

> **reason**: [`SuspendedReason`](#suspendedreason)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:813](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L813)

##### utxo

> **utxo**: [`Utxo`](#utxo-1)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:811](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L811)

***

### UpgradeArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:853](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L853)

The upgrade parameters of the minter canister.

#### Properties

##### btc\_checker\_principal

> **btc\_checker\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L895)

/ The principal of the Bitcoin checker canister.

##### check\_fee

> **check\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:883](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L883)

/ The fee per Bitcoin check.

##### deposit\_btc\_min\_amount

> **deposit\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L874)

The minimal amount of BTC that can be converted to ckBTC.
UTXOs with lower values will be ignored.

##### get\_utxos\_cache\_expiration\_seconds

> **get\_utxos\_cache\_expiration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:857](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L857)

/ The expiration duration (in seconds) for cached entries in the get_utxos cache.

##### kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:904](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L904)

/ The fee paid per check by the KYT canister (deprecated, use check_fee instead).

##### kyt\_principal

> **kyt\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:861](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L861)

/ The canister id of the KYT canister (deprecated, use btc_checker_principal instead).

##### max\_num\_inputs\_in\_transaction

> **max\_num\_inputs\_in\_transaction**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L887)

/ The maximum number of input UTXOs allowed in a transaction.

##### max\_time\_in\_queue\_nanos

> **max\_time\_in\_queue\_nanos**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:879](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L879)

/ Maximum time in nanoseconds that a transaction should spend in the queue
/ before being sent.

##### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L900)

/ The minimum number of confirmations required for the minter to
/ accept a Bitcoin transaction.

##### mode

> **mode**: \[\] \| \[[`Mode`](#mode-2)\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:865](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L865)

/ If set, overrides the current minter's operation mode.

##### retrieve\_btc\_min\_amount

> **retrieve\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L869)

The minimal amount of ckBTC that the minter converts to BTC.

##### utxo\_consolidation\_threshold

> **utxo\_consolidation\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L891)

/ The minimum number of available UTXOs to trigger a consolidation.

***

### Utxo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:906](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L906)

#### Properties

##### height

> **height**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:907](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L907)

##### outpoint

> **outpoint**: `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L909)

###### txid

> **txid**: `Uint8Array`

###### vout

> **vout**: `number`

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:908](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L908)

***

### WithdrawalFee

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:946](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L946)

#### Properties

##### bitcoin\_fee

> **bitcoin\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L948)

##### minter\_fee

> **minter\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:947](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L947)

## Type Aliases

### BitcoinAddress

> **BitcoinAddress** = \{ `p2wsh_v0`: `Uint8Array`; \} \| \{ `p2tr_v1`: `Uint8Array`; \} \| \{ `p2sh`: `Uint8Array`; \} \| \{ `p2wpkh_v0`: `Uint8Array`; \} \| \{ `p2pkh`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L20)

***

### BtcNetwork

> **BtcNetwork** = \{ `Mainnet`: `null`; \} \| \{ `Regtest`: `null`; \} \| \{ `Testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L26)

#### Type Declaration

\{ `Mainnet`: `null`; \}

##### Mainnet

> **Mainnet**: `null`

The public Bitcoin mainnet.

\{ `Regtest`: `null`; \}

##### Regtest

> **Regtest**: `null`

A local Bitcoin regtest installation.

\{ `Testnet`: `null`; \}

##### Testnet

> **Testnet**: `null`

The public Bitcoin testnet.

***

### BurnMemo

> **BurnMemo** = \{ `Consolidate`: \{ `inputs`: `bigint`; `value`: `bigint`; \}; \} \| \{ `Convert`: \{ `address`: \[\] \| \[`string`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L45)

#### Type Declaration

\{ `Consolidate`: \{ `inputs`: `bigint`; `value`: `bigint`; \}; \}

##### Consolidate

> **Consolidate**: `object`

The minter consolidated UTXOs.

###### Consolidate.inputs

> **inputs**: `bigint`

The number of input UTXOs that were consolidated.

###### Consolidate.value

> **value**: `bigint`

The total value of the consolidated UTXOs.

\{ `Convert`: \{ `address`: \[\] \| \[`string`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \}

##### Convert

> **Convert**: `object`

The minter processed a retrieve_btc request.

###### Convert.address

> **address**: \[\] \| \[`string`\]

The destination of the retrieve BTC request.

###### Convert.kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

The check fee for the burn.

###### Convert.status

> **status**: \[\] \| \[[`Status`](#status-1)\]

The status of the Bitcoin check.

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L93)

***

### DecodedMemo

> **DecodedMemo** = \{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \} \| \{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L128)

#### Type Declaration

\{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \}

##### Burn

> **Burn**: \[\] \| \[[`BurnMemo`](#burnmemo)\]

The decoded BurnMemo - `opt` since other variants of `BurnMemo` could be added in the future.

\{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

##### Mint

> **Mint**: \[\] \| \[[`MintMemo`](#mintmemo)\]

The decoded MintMemo - `opt` since other variants of `MintMemo` could be added in the future.

***

### DecodeLedgerMemoError

> **DecodeLedgerMemoError** = `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L107)

#### Properties

##### InvalidMemo

> **InvalidMemo**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L111)

The provided memo could not be decoded.

***

### DecodeLedgerMemoResult

> **DecodeLedgerMemoResult** = \{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \} \| \{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L113)

#### Type Declaration

\{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \}

##### Ok

> **Ok**: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]

The decoded memo, if the minter was able to decode it. This field is `opt`, so that other memo types can be
added in the future.

\{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

##### Err

> **Err**: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]

An error in case the minter was not able to decode the provided memo. This field is `opt`, so that other error
types can be added in the future.

***

### EventType

> **EventType** = \{ `received_utxos`: \{ `mint_txid`: \[\] \| \[`bigint`\]; `to_account`: [`Account`](#account); `utxos`: [`Utxo`](#utxo-1)[]; \}; \} \| \{ `schedule_deposit_reimbursement`: \{ `account`: [`Account`](#account); `amount`: `bigint`; `burn_block_index`: `bigint`; `reason`: [`ReimbursementReason`](#reimbursementreason); \}; \} \| \{ `sent_transaction`: \{ `change_output`: \[\] \| \[\{ `value`: `bigint`; `vout`: `number`; \}\]; `fee`: \[\] \| \[`bigint`\]; `requests`: `BigUint64Array`; `signed_tx`: \[\] \| \[`Uint8Array`\]; `submitted_at`: `bigint`; `txid`: `Uint8Array`; `utxos`: [`Utxo`](#utxo-1)[]; `withdrawal_fee`: \[\] \| \[[`WithdrawalFee`](#withdrawalfee)\]; \}; \} \| \{ `distributed_kyt_fee`: \{ `amount`: `bigint`; `block_index`: `bigint`; `kyt_provider`: `Principal`; \}; \} \| \{ `init`: [`InitArgs`](#initargs); \} \| \{ `upgrade`: [`UpgradeArgs`](#upgradeargs); \} \| \{ `retrieve_btc_kyt_failed`: \{ `address`: `string`; `amount`: `bigint`; `block_index`: `bigint`; `kyt_provider`: `Principal`; `owner`: `Principal`; `uuid`: `string`; \}; \} \| \{ `suspended_utxo`: \{ `account`: [`Account`](#account); `reason`: [`SuspendedReason`](#suspendedreason); `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `accepted_retrieve_btc_request`: \{ `address`: [`BitcoinAddress`](#bitcoinaddress); `amount`: `bigint`; `block_index`: `bigint`; `kyt_provider`: \[\] \| \[`Principal`\]; `received_at`: `bigint`; `reimbursement_account`: \[\] \| \[[`Account`](#account)\]; \}; \} \| \{ `checked_utxo`: \{ `clean`: `boolean`; `kyt_provider`: \[\] \| \[`Principal`\]; `utxo`: [`Utxo`](#utxo-1); `uuid`: `string`; \}; \} \| \{ `schedule_withdrawal_reimbursement`: \{ `account`: [`Account`](#account); `amount`: `bigint`; `burn_block_index`: `bigint`; `reason`: [`WithdrawalReimbursementReason`](#withdrawalreimbursementreason); \}; \} \| \{ `quarantined_withdrawal_reimbursement`: \{ `burn_block_index`: `bigint`; \}; \} \| \{ `removed_retrieve_btc_request`: \{ `block_index`: `bigint`; \}; \} \| \{ `confirmed_transaction`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `replaced_transaction`: \{ `change_output`: \{ `value`: `bigint`; `vout`: `number`; \}; `fee`: `bigint`; `new_txid`: `Uint8Array`; `new_utxos`: \[\] \| \[[`Utxo`](#utxo-1)[]\]; `old_txid`: `Uint8Array`; `reason`: \[\] \| \[[`ReplacedReason`](#replacedreason)\]; `submitted_at`: `bigint`; `withdrawal_fee`: \[\] \| \[[`WithdrawalFee`](#withdrawalfee)\]; \}; \} \| \{ `checked_utxo_v2`: \{ `account`: [`Account`](#account); `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `ignored_utxo`: \{ `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `checked_utxo_mint_unknown`: \{ `account`: [`Account`](#account); `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `created_consolidate_utxos_request`: \{ `address`: [`BitcoinAddress`](#bitcoinaddress); `amount`: `bigint`; `block_index`: `bigint`; `received_at`: `bigint`; \}; \} \| \{ `reimbursed_failed_deposit`: \{ `burn_block_index`: `bigint`; `mint_block_index`: `bigint`; \}; \} \| \{ `reimbursed_withdrawal`: \{ `burn_block_index`: `bigint`; `mint_block_index`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L156)

***

### Icrc21ConsentMessage

> **Icrc21ConsentMessage** = \{ `FieldsDisplayMessage`: [`Icrc21FieldsDisplay`](#icrc21fieldsdisplay); \} \| \{ `GenericDisplayMessage`: `string`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L285)

***

### Icrc21DeviceSpec

> **Icrc21DeviceSpec** = \{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L306)

***

### Icrc21Error

> **Icrc21Error** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `InsufficientPayment`: [`Icrc21ErrorInfo`](#icrc21errorinfo); \} \| \{ `UnsupportedCanisterCall`: [`Icrc21ErrorInfo`](#icrc21errorinfo); \} \| \{ `ConsentMessageUnavailable`: [`Icrc21ErrorInfo`](#icrc21errorinfo); \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L309)

***

### Icrc21Value

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L323)

***

### InvalidTransactionError

> **InvalidTransactionError** = `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L405)

#### Properties

##### too\_many\_inputs

> **too\_many\_inputs**: `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L406)

###### max\_num\_inputs

> **max\_num\_inputs**: `bigint`

###### num\_inputs

> **num\_inputs**: `bigint`

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L408)

***

### MemoType

> **MemoType** = \{ `Burn`: `null`; \} \| \{ `Mint`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L412)

***

### MinterArg

> **MinterArg** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](#upgradeargs)\]; \} \| \{ `Init`: [`InitArgs`](#initargs); \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L475)

***

### MintMemo

> **MintMemo** = \{ `Kyt`: `null`; \} \| \{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \} \| \{ `KytFail`: \{ `associated_burn_index`: \[\] \| \[`bigint`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \} \| \{ `Convert`: \{ `kyt_fee`: \[\] \| \[`bigint`\]; `txid`: \[\] \| \[`Uint8Array`\]; `vout`: \[\] \| \[`number`\]; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L423)

#### Type Declaration

\{ `Kyt`: `null`; \}

##### Kyt

> **Kyt**: `null`

[deprecated] The minter minted accumulated check fees to the KYT provider.

\{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \}

##### ReimburseWithdrawal

> **ReimburseWithdrawal**: `object`

###### ReimburseWithdrawal.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request,
which corresponds to the ledger burn index.

\{ `KytFail`: \{ `associated_burn_index`: \[\] \| \[`bigint`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \}

##### KytFail

> **KytFail**: `object`

[deprecated] The minter failed to check retrieve btc destination address
or the destination address is tainted.

###### KytFail.associated\_burn\_index

> **associated\_burn\_index**: \[\] \| \[`bigint`\]

###### KytFail.kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

The Bitcoin check fee.

###### KytFail.status

> **status**: \[\] \| \[[`Status`](#status-1)\]

The status of the Bitcoin check.

\{ `Convert`: \{ `kyt_fee`: \[\] \| \[`bigint`\]; `txid`: \[\] \| \[`Uint8Array`\]; `vout`: \[\] \| \[`number`\]; \}; \}

##### Convert

> **Convert**: `object`

The minter converted a single UTXO to ckBTC.

###### Convert.kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

The Bitcoin check fee.

###### Convert.txid

> **txid**: \[\] \| \[`Uint8Array`\]

The transaction ID of the accepted UTXO.

###### Convert.vout

> **vout**: \[\] \| \[`number`\]

UTXO's output index within the BTC transaction.

***

### Mode

> **Mode** = \{ `RestrictedTo`: `Principal`[]; \} \| \{ `DepositsRestrictedTo`: `Principal`[]; \} \| \{ `ReadOnly`: `null`; \} \| \{ `GeneralAvailability`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L493)

#### Type Declaration

\{ `RestrictedTo`: `Principal`[]; \}

##### RestrictedTo

> **RestrictedTo**: `Principal`[]

Only specified principals can modify minter's state.

\{ `DepositsRestrictedTo`: `Principal`[]; \}

##### DepositsRestrictedTo

> **DepositsRestrictedTo**: `Principal`[]

Only specified principals can convert BTC to ckBTC.

\{ `ReadOnly`: `null`; \}

##### ReadOnly

> **ReadOnly**: `null`

The minter does not allow any state modifications.

\{ `GeneralAvailability`: `null`; \}

##### GeneralAvailability

> **GeneralAvailability**: `null`

Anyone can interact with the minter.

***

### ReimbursementReason

> **ReimbursementReason** = \{ `CallFailed`: `null`; \} \| \{ `TaintedDestination`: \{ `kyt_fee`: `bigint`; `kyt_provider`: `Principal`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L538)

***

### ReplacedReason

> **ReplacedReason** = \{ `to_cancel`: \{ `reason`: [`WithdrawalReimbursementReason`](#withdrawalreimbursementreason); \}; \} \| \{ `to_retry`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L546)

***

### RetrieveBtcError

> **RetrieveBtcError** = \{ `MalformedAddress`: `string`; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `AlreadyProcessing`: `null`; \} \| \{ `AmountTooLow`: `bigint`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L561)

#### Type Declaration

\{ `MalformedAddress`: `string`; \}

##### MalformedAddress

> **MalformedAddress**: `string`

The minter failed to parse the destination address.

\{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### GenericError

> **GenericError**: `object`

A generic error reserved for future extensions.

###### GenericError.error\_code

> **error\_code**: `bigint`

###### GenericError.error\_message

> **error\_message**: `string`

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `AlreadyProcessing`: `null`; \}

##### AlreadyProcessing

> **AlreadyProcessing**: `null`

The minter is already processing another retrieval request for the same
principal.

\{ `AmountTooLow`: `bigint`; \}

##### AmountTooLow

> **AmountTooLow**: `bigint`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The ckBTC balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

***

### RetrieveBtcStatus

> **RetrieveBtcStatus** = \{ `Signing`: `null`; \} \| \{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Sending`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `AmountTooLow`: `null`; \} \| \{ `Unknown`: `null`; \} \| \{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:608](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L608)

#### Type Declaration

\{ `Signing`: `null`; \}

##### Signing

> **Signing**: `null`

The minter is obtaining all required ECDSA signatures on the
Bitcoin transaction for this request.

\{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \}

##### Confirmed

> **Confirmed**: `object`

The minter received enough confirmations for the Bitcoin
transaction for this request.  The payload contains the
identifier of the transaction on the Bitcoin network.

###### Confirmed.txid

> **txid**: `Uint8Array`

\{ `Sending`: \{ `txid`: `Uint8Array`; \}; \}

##### Sending

> **Sending**: `object`

The minter signed the transaction and is waiting for a reply
from the Bitcoin canister.

###### Sending.txid

> **txid**: `Uint8Array`

\{ `AmountTooLow`: `null`; \}

##### AmountTooLow

> **AmountTooLow**: `null`

The amount was too low to cover the transaction fees.

\{ `Unknown`: `null`; \}

##### Unknown

> **Unknown**: `null`

The minter does not have any information on the specified
retrieval request.  It can be that nobody submitted the
request or the minter pruned the relevant information from the
history to save space.

\{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \}

##### Submitted

> **Submitted**: `object`

The minter sent a transaction for the retrieve request.
The payload contains the identifier of the transaction on the Bitcoin network.

###### Submitted.txid

> **txid**: `Uint8Array`

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

The minter did not send a Bitcoin transaction for this request yet.

***

### RetrieveBtcStatusV2

> **RetrieveBtcStatusV2** = \{ `Signing`: `null`; \} \| \{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Sending`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `AmountTooLow`: `null`; \} \| \{ `WillReimburse`: [`ReimbursementRequest`](#reimbursementrequest); \} \| \{ `Unknown`: `null`; \} \| \{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Reimbursed`: [`ReimbursedDeposit`](#reimburseddeposit); \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L659)

#### Type Declaration

\{ `Signing`: `null`; \}

##### Signing

> **Signing**: `null`

The minter is obtaining all required ECDSA signatures on the
Bitcoin transaction for this request.

\{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \}

##### Confirmed

> **Confirmed**: `object`

The minter received enough confirmations for the Bitcoin
transaction for this request.  The payload contains the
identifier of the transaction on the Bitcoin network.

###### Confirmed.txid

> **txid**: `Uint8Array`

\{ `Sending`: \{ `txid`: `Uint8Array`; \}; \}

##### Sending

> **Sending**: `object`

The minter signed the transaction and is waiting for a reply
from the Bitcoin canister.

###### Sending.txid

> **txid**: `Uint8Array`

\{ `AmountTooLow`: `null`; \}

##### AmountTooLow

> **AmountTooLow**: `null`

The amount was too low to cover the transaction fees.

\{ `WillReimburse`: [`ReimbursementRequest`](#reimbursementrequest); \}

##### WillReimburse

> **WillReimburse**: [`ReimbursementRequest`](#reimbursementrequest)

/ The minter will try to reimburse this transaction.

\{ `Unknown`: `null`; \}

##### Unknown

> **Unknown**: `null`

The minter does not have any information on the specified
retrieval request.  It can be that nobody submitted the
request or the minter pruned the relevant information from the
history to save space.

\{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \}

##### Submitted

> **Submitted**: `object`

The minter sent a transaction for the retrieve request.
The payload contains the identifier of the transaction on the Bitcoin network.

###### Submitted.txid

> **txid**: `Uint8Array`

\{ `Reimbursed`: [`ReimbursedDeposit`](#reimburseddeposit); \}

##### Reimbursed

> **Reimbursed**: [`ReimbursedDeposit`](#reimburseddeposit)

/ The retrieve Bitcoin request has been reimbursed.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

The minter did not send a Bitcoin transaction for this request yet.

***

### RetrieveBtcWithApprovalError

> **RetrieveBtcWithApprovalError** = \{ `MalformedAddress`: `string`; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `AlreadyProcessing`: `null`; \} \| \{ `AmountTooLow`: `bigint`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:736](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L736)

#### Type Declaration

\{ `MalformedAddress`: `string`; \}

##### MalformedAddress

> **MalformedAddress**: `string`

The minter failed to parse the destination address.

\{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### GenericError

> **GenericError**: `object`

A generic error reserved for future extensions.

###### GenericError.error\_code

> **error\_code**: `bigint`

###### GenericError.error\_message

> **error\_message**: `string`

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

\{ `AlreadyProcessing`: `null`; \}

##### AlreadyProcessing

> **AlreadyProcessing**: `null`

The minter is already processing another retrieval request for the same
principal.

\{ `AmountTooLow`: `bigint`; \}

##### AmountTooLow

> **AmountTooLow**: `bigint`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The ckBTC balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

***

### Status

> **Status** = \{ `CallFailed`: `null`; \} \| \{ `Rejected`: `null`; \} \| \{ `Accepted`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:782](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L782)

#### Type Declaration

\{ `CallFailed`: `null`; \}

##### CallFailed

> **CallFailed**: `null`

\{ `Rejected`: `null`; \}

##### Rejected

> **Rejected**: `null`

The minter rejected a retrieve_btc due to a failed Bitcoin check.

\{ `Accepted`: `null`; \}

##### Accepted

> **Accepted**: `null`

The minter accepted a retrieve_btc request.

***

### SuspendedReason

> **SuspendedReason** = \{ `ValueTooSmall`: `null`; \} \| \{ `Quarantined`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:796](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L796)

#### Type Declaration

\{ `ValueTooSmall`: `null`; \}

##### ValueTooSmall

> **ValueTooSmall**: `null`

The minter ignored this UTXO because UTXO's value is too small to pay
the check fees.

\{ `Quarantined`: `null`; \}

##### Quarantined

> **Quarantined**: `null`

The Bitcoin checker considered this UTXO to be tainted.

***

### Timestamp

> **Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:818](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L818)

Number of nanoseconds since the Unix Epoch

***

### UpdateBalanceError

> **UpdateBalanceError** = \{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `AlreadyProcessing`: `null`; \} \| \{ `NoNewUtxos`: \{ `current_confirmations`: \[\] \| \[`number`\]; `pending_utxos`: \[\] \| \[[`PendingUtxo`](#pendingutxo)[]\]; `required_confirmations`: `number`; `suspended_utxos`: \[\] \| \[[`SuspendedUtxo`](#suspendedutxo)[]\]; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:819](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L819)

#### Type Declaration

\{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### GenericError

> **GenericError**: `object`

A generic error reserved for future extensions.

###### GenericError.error\_code

> **error\_code**: `bigint`

###### GenericError.error\_message

> **error\_message**: `string`

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `AlreadyProcessing`: `null`; \}

##### AlreadyProcessing

> **AlreadyProcessing**: `null`

The minter is already processing another update balance request for the caller.

\{ `NoNewUtxos`: \{ `current_confirmations`: \[\] \| \[`number`\]; `pending_utxos`: \[\] \| \[[`PendingUtxo`](#pendingutxo)[]\]; `required_confirmations`: `number`; `suspended_utxos`: \[\] \| \[[`SuspendedUtxo`](#suspendedutxo)[]\]; \}; \}

##### NoNewUtxos

> **NoNewUtxos**: `object`

There are no new UTXOs to process.

###### NoNewUtxos.current\_confirmations

> **current\_confirmations**: \[\] \| \[`number`\]

###### NoNewUtxos.pending\_utxos

> **pending\_utxos**: \[\] \| \[[`PendingUtxo`](#pendingutxo)[]\]

###### NoNewUtxos.required\_confirmations

> **required\_confirmations**: `number`

###### NoNewUtxos.suspended\_utxos

> **suspended\_utxos**: \[\] \| \[[`SuspendedUtxo`](#suspendedutxo)[]\]

***

### UtxoStatus

> **UtxoStatus** = \{ `ValueTooSmall`: [`Utxo`](#utxo-1); \} \| \{ `Tainted`: [`Utxo`](#utxo-1); \} \| \{ `Minted`: \{ `block_index`: `bigint`; `minted_amount`: `bigint`; `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `Checked`: [`Utxo`](#utxo-1); \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L914)

The result of an [update_balance] call.

#### Type Declaration

\{ `ValueTooSmall`: [`Utxo`](#utxo-1); \}

##### ValueTooSmall

> **ValueTooSmall**: [`Utxo`](#utxo-1)

The minter ignored this UTXO because UTXO's value is too small to pay
the check fees.

\{ `Tainted`: [`Utxo`](#utxo-1); \}

##### Tainted

> **Tainted**: [`Utxo`](#utxo-1)

The Bitcoin checker considered this UTXO to be tainted.

\{ `Minted`: \{ `block_index`: `bigint`; `minted_amount`: `bigint`; `utxo`: [`Utxo`](#utxo-1); \}; \}

##### Minted

> **Minted**: `object`

The UTXO passed the Bitcoin check, and ckBTC has been minted.

###### Minted.block\_index

> **block\_index**: `bigint`

###### Minted.minted\_amount

> **minted\_amount**: `bigint`

###### Minted.utxo

> **utxo**: [`Utxo`](#utxo-1)

\{ `Checked`: [`Utxo`](#utxo-1); \}

##### Checked

> **Checked**: [`Utxo`](#utxo-1)

The UTXO passed the Bitcoin check, but the minter failed to mint ckBTC
because the Ledger was unavailable. Retrying the [update_balance] call
should eventually advance the UTXO to the [Minted] state.

***

### WithdrawalReimbursementReason

> **WithdrawalReimbursementReason** = `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:950](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L950)

#### Properties

##### invalid\_transaction

> **invalid\_transaction**: [`InvalidTransactionError`](#invalidtransactionerror)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:951](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L951)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1116](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1116)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1117](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1117)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
