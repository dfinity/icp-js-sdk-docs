---
title: Overview
editUrl: false
next: true
prev: true
---

## Quick Start

The `AssetManager` supports the (chunked) upload of `File`, `Blob`, `ArrayBuffer`, `Uint8Array` and `number[]`.

Create an asset manager instance:

```ts
import { AssetManager } from "@icp-sdk/canisters/assets";

const assetManager = new AssetManager({
    canisterId: ..., // Principal of assets canister
    agent: ..., // Identity in agent must be authorized by the assets canister to make any changes
});
```

Select file and upload to asset canister from the browser:

```ts
const input = document.createElement('input');
input.type = 'file';
input.addEventListener('change', async e => {
  const file = e.target.files[0];
  const key = await assetManager.store(file);
});
input.click();
```

A config argument can be optionally passed as second argument in the `store` method.
The `fileName` property is required when the data passed in the first argument
is not a `File`, file path or custom `Readable` implementation.

List files stored in the asset canister:

```ts
const files = await assetManager.list();
```

Upload multiple files and delete an existing file as batch in Node.js:

```ts
import fs from 'fs';

const banana = fs.readFileSync('./banana.png');
const apple = fs.readFileSync('./apple.png');
const strawberry = fs.readFileSync('./strawberry.png');
const batch = assetManager.batch();
const keys = [
  await batch.store(banana, { fileName: 'banana.png' }),
  await batch.store(apple, { fileName: 'apple.png', path: '/directory/with/apples' }),
  await batch.store(strawberry, { fileName: 'strawberry.png' }),
];
await batch.delete('/path/to/old/file.csv');
await batch.commit();
```

Read file from disk, compress with gzip and upload to asset canister in Node.js,
GZIP compression is recommended for HTML and JS files:

```ts
import fs from 'fs';

const file = fs.readFileSync('./index.html');
const gzippedFile = // gzip the file here
const key = await assetManager.insert(gzippedFile, {
  fileName: 'index.html',
  contentEncoding: 'gzip',
});
```

Download image asset to blob and open in new browser tab:

```ts
const asset = await assetManager.get('/path/to/file/on/asset/canister/motoko.png');
const blob = await asset.toBlob();
const url = URL.createObjectURL(blob);

window.open(URL.createObjectURL(blob, '_blank'));
```

Download and write asset to path in Node.js:

```ts
const asset = await assetManager.get('/large_dataset.csv');
asset.write('/large_dataset.csv');
```

## Classes

### AssetManager

Defined in: [packages/canisters/src/assets/index.ts:237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L237)

#### Constructors

##### Constructor

> **new AssetManager**(`config`): [`AssetManager`](#assetmanager)

Defined in: [packages/canisters/src/assets/index.ts:247](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L247)

Create assets canister manager instance

###### Parameters

###### config

[`AssetManagerConfig`](#assetmanagerconfig)

Additional configuration options, canister id is required

###### Returns

[`AssetManager`](#assetmanager)

#### Methods

##### batch()

> **batch**(): `AssetManagerBatch`

Defined in: [packages/canisters/src/assets/index.ts:426](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L426)

Create a batch assets operations instance, commit multiple operations in a single request

###### Returns

`AssetManagerBatch`

##### clear()

> **clear**(): `Promise`\<`void`\>

Defined in: [packages/canisters/src/assets/index.ts:391](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L391)

Delete all files from assets canister

###### Returns

`Promise`\<`void`\>

##### delete()

> **delete**(`key`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/assets/index.ts:384](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L384)

Delete file from assets canister

###### Parameters

###### key

`string`

The path to the file on the assets canister e.g. /folder/to/my_file.txt

###### Returns

`Promise`\<`void`\>

##### get()

> **get**(`key`, `acceptEncodings?`): `Promise`\<`Asset`\>

Defined in: [packages/canisters/src/assets/index.ts:400](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L400)

Get asset instance from assets canister

###### Parameters

###### key

`string`

The path to the file on the assets canister e.g. /folder/to/my_file.txt

###### acceptEncodings?

[`ContentEncoding`](#contentencoding-1)[]

The accepted content encodings, defaults to ['identity']

###### Returns

`Promise`\<`Asset`\>

##### list()

> **list**(): `Promise`\<`object`[]\>

Defined in: [packages/canisters/src/assets/index.ts:293](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L293)

Get list of all files in assets canister.

###### Returns

`Promise`\<`object`[]\>

All files in asset canister

##### store()

> **store**(...`args`): `Promise`\<`string`\>

Defined in: [packages/canisters/src/assets/index.ts:342](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L342)

Store data on assets canister

###### Parameters

###### args

...[`StoreArgs`](#storeargs)

Arguments with either a file, blob, path, bytes or custom Readable implementation

###### Returns

`Promise`\<`string`\>

##### toReadable()

> `static` **toReadable**(...`args`): `Promise`\<`Readable`\>

Defined in: [packages/canisters/src/assets/index.ts:260](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L260)

Create readable from store arguments

###### Parameters

###### args

...[`StoreArgs`](#storeargs)

Arguments with either a file, blob, path, bytes or custom Readable implementation

###### Returns

`Promise`\<`Readable`\>

## Interfaces

### AssetManagerConfig

Defined in: [packages/canisters/src/assets/index.ts:219](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L219)

Configuration that can be passed to set the canister id of the
assets canister to be managed, inherits actor configuration and
has additional asset manager specific configuration options.

#### Extends

- `ActorConfig`

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:21

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

###### Inherited from

`ActorConfig.agent`

##### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:62

Polyfill for BLS Certificate verification in case wasm is not supported

###### Inherited from

`ActorConfig.blsVerify`

##### canisterId

> **canisterId**: `string` \| `Principal`

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:50

The Canister ID of this Actor. This is required for an Actor.

###### Inherited from

`ActorConfig.canisterId`

##### concurrency?

> `optional` **concurrency**: `number`

Defined in: [packages/canisters/src/assets/index.ts:224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L224)

Max number of concurrent requests to the Internet Computer

###### Default

```ts
16
```

##### ~~effectiveCanisterId?~~

> `optional` **effectiveCanisterId**: `Principal`

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:37

###### Deprecated

Use CallConfig.effectiveTarget instead.

###### Inherited from

`ActorConfig.effectiveCanisterId`

##### effectiveTarget?

> `optional` **effectiveTarget**: `TargetPrincipal`

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:33

The effective canister or subnet ID.

###### Inherited from

`ActorConfig.effectiveTarget`

##### maxChunkSize?

> `optional` **maxChunkSize**: `number`

Defined in: [packages/canisters/src/assets/index.ts:234](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L234)

Size of each chunk in bytes when the asset manager has to chunk a file

###### Default

```ts
1900000
```

##### maxSingleFileSize?

> `optional` **maxSingleFileSize**: `number`

Defined in: [packages/canisters/src/assets/index.ts:229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L229)

Max file size in bytes that the asset manager shouldn't chunk

###### Default

```ts
1900000
```

##### pollingOptions?

> `optional` **pollingOptions**: `PollingOptions`

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:66

Polling options to use when making update calls. This will override the default DEFAULT_POLLING_OPTIONS.

###### Inherited from

`ActorConfig.pollingOptions`

##### queryStrategy?

> `optional` **queryStrategy**: `QueryStrategy`

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:73

Controls how query and composite_query methods are executed.
- `'query'` (default) — standard non-replicated query call.
- `'update'` — send query methods as update calls that go through consensus.

###### Default

```ts
'query'
```

###### Inherited from

`ActorConfig.queryStrategy`

#### Methods

##### callTransform()?

> `optional` **callTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<`CallConfig`\>

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:54

An override function for update calls' CallConfig. This will be called on every calls.

###### Parameters

###### methodName

`string`

###### args

`unknown`[]

###### callConfig

`CallConfig`

###### Returns

`void` \| `Partial`\<`CallConfig`\>

###### Inherited from

`ActorConfig.callTransform`

##### queryTransform()?

> `optional` **queryTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<`CallConfig`\>

Defined in: node\_modules/@icp-sdk/core/lib/esm/agent/actor.d.ts:58

An override function for query calls' CallConfig. This will be called on every query.

###### Parameters

###### methodName

`string`

###### args

`unknown`[]

###### callConfig

`CallConfig`

###### Returns

`void` \| `Partial`\<`CallConfig`\>

###### Inherited from

`ActorConfig.queryTransform`

***

### CommitBatchArgs

Defined in: [packages/canisters/src/assets/index.ts:210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L210)

Arguments to commit batch in asset manager

#### Properties

##### onProgress()?

> `optional` **onProgress**: (`progress`) => `void`

Defined in: [packages/canisters/src/assets/index.ts:211](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L211)

###### Parameters

###### progress

[`Progress`](#progress)

###### Returns

`void`

***

### Progress

Defined in: [packages/canisters/src/assets/index.ts:135](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L135)

Upload progress in bytes

#### Properties

##### current

> **current**: `number`

Defined in: [packages/canisters/src/assets/index.ts:136](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L136)

##### total

> **total**: `number`

Defined in: [packages/canisters/src/assets/index.ts:137](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L137)

***

### StoreConfig

Defined in: [packages/canisters/src/assets/index.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L143)

Configuration that can be passed to set and override defaults and add progress callback

#### Properties

##### contentEncoding?

> `optional` **contentEncoding**: [`ContentEncoding`](#contentencoding-1)

Defined in: [packages/canisters/src/assets/index.ts:168](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L168)

Content encoding

###### Default

```ts
'identity'
```

##### contentType?

> `optional` **contentType**: `string`

Defined in: [packages/canisters/src/assets/index.ts:158](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L158)

File content type

###### Default

```ts
File/Blob object type or type from file name extension
```

##### fileName?

> `optional` **fileName**: `string`

Defined in: [packages/canisters/src/assets/index.ts:148](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L148)

File name

###### Default

```ts
File object name or name in file path
```

##### headers?

> `optional` **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/assets/index.ts:163](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L163)

Custom headers to be sent with the asset

###### Default

```ts
[]
```

##### onProgress()?

> `optional` **onProgress**: (`progress`) => `void`

Defined in: [packages/canisters/src/assets/index.ts:176](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L176)

Callback method to get upload progress in bytes (current / total)

###### Parameters

###### progress

[`Progress`](#progress)

###### Returns

`void`

##### path?

> `optional` **path**: `string`

Defined in: [packages/canisters/src/assets/index.ts:153](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L153)

File path that file will be uploaded to

###### Default

```ts
'/'
```

##### sha256?

> `optional` **sha256**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/canisters/src/assets/index.ts:172](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L172)

File hash generation will be skipped if hash is provided

## Type Aliases

### ContentEncoding

> **ContentEncoding** = `"identity"` \| `"gzip"` \| `"compress"` \| `"deflate"` \| `"br"`

Defined in: [packages/canisters/src/assets/index.ts:125](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L125)

Supported content encodings by asset canister

***

### StoreArgs

> **StoreArgs** = [`StoreReadableArgs`](#storereadableargs) \| [`StoreFileArgs`](#storefileargs) \| [`StoreBlobArgs`](#storeblobargs) \| [`StorePathArgs`](#storepathargs) \| [`StoreBytesArgs`](#storebytesargs)

Defined in: [packages/canisters/src/assets/index.ts:200](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L200)

Arguments to store an asset in asset manager

***

### StoreBlobArgs

> **StoreBlobArgs** = \[`Blob`, `Omit`\<[`StoreConfig`](#storeconfig), `"fileName"`\> & `Required`\<`Pick`\<[`StoreConfig`](#storeconfig), `"fileName"`\>\>\]

Defined in: [packages/canisters/src/assets/index.ts:183](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L183)

***

### StoreBytesArgs

> **StoreBytesArgs** = \[`Uint8Array` \| `ArrayBuffer` \| `number`[], `Omit`\<[`StoreConfig`](#storeconfig), `"fileName"`\> & `Required`\<`Pick`\<[`StoreConfig`](#storeconfig), `"fileName"`\>\>\]

Defined in: [packages/canisters/src/assets/index.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L191)

***

### StoreFileArgs

> **StoreFileArgs** = \[`File`, [`StoreConfig`](#storeconfig)\]

Defined in: [packages/canisters/src/assets/index.ts:181](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L181)

***

### StorePathArgs

> **StorePathArgs** = \[`string`, [`StoreConfig`](#storeconfig)\]

Defined in: [packages/canisters/src/assets/index.ts:189](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L189)

***

### StoreReadableArgs

> **StoreReadableArgs** = \[`Readable`, [`StoreConfig`](#storeconfig)\]

Defined in: [packages/canisters/src/assets/index.ts:179](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/assets/index.ts#L179)
