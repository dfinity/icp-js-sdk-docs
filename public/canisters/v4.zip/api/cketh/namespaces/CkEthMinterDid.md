---
title: CkEthMinterDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:978](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L978)

#### Properties

##### add\_ckerc20\_token

> **add\_ckerc20\_token**: `ActorMethod`\<\[[`AddCkErc20Token`](#addckerc20token)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:983](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L983)

Add a ckERC-20 token to be supported by the minter.
This call is restricted to the orchestrator ID.

##### decode\_ledger\_memo

> **decode\_ledger\_memo**: `ActorMethod`\<\[[`DecodeLedgerMemoArgs`](#decodeledgermemoargs)\], [`DecodeLedgerMemoResult`](#decodeledgermemoresult)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:987](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L987)

Decode ledger memos produced by the minter when minting (deposits) or burning (withdrawals).

##### eip\_1559\_transaction\_price

> **eip\_1559\_transaction\_price**: `ActorMethod`\<\[\[\] \| \[[`Eip1559TransactionPriceArg`](#eip1559transactionpricearg)\]\], [`Eip1559TransactionPrice`](#eip1559transactionprice)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:994](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L994)

Estimate the price of a transaction issued by the minter when converting ckETH to ETH.

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1003](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1003)

Retrieve the status of the minter canister.

This is a debug endpoint where backwards-compatibility is not guaranteed.

##### get\_events

> **get\_events**: `ActorMethod`\<\[\{ `length`: `bigint`; `start`: `bigint`; \}\], \{ `events`: [`Event`](#event)[]; `total_event_count`: `bigint`; \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1009)

Retrieve events from the minter's audit log.
The endpoint can return fewer events than requested to bound the response size.
IMPORTANT: this endpoint is meant as a debugging tool and is not guaranteed to be backwards-compatible.

##### get\_minter\_info

> **get\_minter\_info**: `ActorMethod`\<\[\], [`MinterInfo`](#minterinfo)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1016](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1016)

Returns internal minter parameters

##### is\_address\_blocked

> **is\_address\_blocked**: `ActorMethod`\<\[`string`\], `boolean`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1020](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1020)

Check if an address is blocked by the minter.

##### minter\_address

> **minter\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1028](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1028)

Retrieve the Ethereum address controlled by the minter:
* Deposits will be transferred from the helper smart contract to this address
* Withdrawals will originate from this address
IMPORTANT: Do NOT send ETH to this address directly. Use the helper smart contract instead so that the minter
knows to which IC principal the funds should be deposited.

##### retrieve\_eth\_status

> **retrieve\_eth\_status**: `ActorMethod`\<\[`bigint`\], [`RetrieveEthStatus`](#retrieveethstatus)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1032](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1032)

Retrieve the status of a Eth withdrawal request.

##### smart\_contract\_address

> **smart\_contract\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1041](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1041)

Address of the helper smart contract.
Returns "N/A" if the helper smart contract is not set.
IMPORTANT:
* Use this address to send ETH to the minter to convert it to ckETH.
* In case the smart contract needs to be updated the returned address will change!
Always check the address before making a transfer.

##### withdraw\_erc20

> **withdraw\_erc20**: `ActorMethod`\<\[[`WithdrawErc20Arg`](#withdrawerc20arg)\], \{ `Ok`: [`RetrieveErc20Request`](#retrieveerc20request); \} \| \{ `Err`: [`WithdrawErc20Error`](#withdrawerc20error); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1045](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1045)

Withdraw the specified amount of ERC-20 tokens to the given Ethereum address.

##### withdraw\_eth

> **withdraw\_eth**: `ActorMethod`\<\[[`WithdrawalArg`](#withdrawalarg)\], \{ `Ok`: [`RetrieveEthRequest`](#retrieveethrequest); \} \| \{ `Err`: [`WithdrawalError`](#withdrawalerror); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1053](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1053)

Withdraw the specified amount in Wei to the given Ethereum address.
IMPORTANT: The current gas limit is set to 21,000 for a transaction so withdrawals to smart contract addresses will likely fail.

##### withdrawal\_status

> **withdrawal\_status**: `ActorMethod`\<\[[`WithdrawalSearchParameter`](#withdrawalsearchparameter)\], [`WithdrawalDetail`](#withdrawaldetail)[]\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1060](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1060)

Return details of all withdrawals matching the given search parameter.

***

### Account

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L16)

ICRC-1 account type.

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L17)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L18)

***

### AddCkErc20Token

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L20)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L32)

The Ethereum address of the ERC-20 smart contract.

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L28)

Ethereum chain ID.

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L24)

The ledger ID for that ckERC20 token.

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L36)

The ckERC20 token symbol on the ledger.

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L104)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L110)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L113)

##### memory\_metrics

> **memory\_metrics**: [`MemoryMetrics`](#memorymetrics)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L105)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L107)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L114)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L112)

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L108)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L115)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L111)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L106)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L109)

***

### CkErc20Token

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L121)

#### Properties

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L124)

##### erc20\_contract\_address

> **erc20\_contract\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L122)

##### ledger\_canister\_id

> **ledger\_canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L123)

***

### DecodeLedgerMemoArgs

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L126)

#### Properties

##### encoded\_memo

> **encoded\_memo**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L134)

The encoded memo from a minter transaction on the ledger

##### memo\_type

> **memo\_type**: [`MemoType`](#memotype)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L130)

The encoded memo type

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L170)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L179)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L174)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L173)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L171)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L176)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L178)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L175)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L177)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L172)

***

### Eip1559TransactionPrice

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L186)

Estimate price of an EIP-1559 transaction
when converting ckETH to ETH or ckERC20 to ERC20, see
https://eips.ethereum.org/EIPS/eip-1559

#### Properties

##### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L210)

Maximum amount of gas transaction is authorized to consume.

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L196)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L191)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

##### max\_transaction\_fee

> **max\_transaction\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L201)

Maximum amount of Wei that can be charged for the transaction,
computed as `max_fee_per_gas * gas_limit`

##### timestamp

> **timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L206)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.

***

### Eip1559TransactionPriceArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L217)

Argument to Eip1559TransactionPrice.
When specified, it is to lookup transaction price for a ckERC20 token withdrawal.
When not specified (null), it is for ETH withdrawal.

#### Properties

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L221)

The ledger ID for that ckERC20 token.

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:974](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L974)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:976](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L976)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:975](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L975)

***

### EthTransaction

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L223)

#### Properties

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L224)

***

### Event

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L239)

#### Properties

##### payload

> **payload**: \{ `SkippedBlock`: \{ `block_number`: `bigint`; `contract_address`: \[\] \| \[`string`\]; \}; \} \| \{ `AcceptedErc20Deposit`: \{ `block_number`: `bigint`; `erc20_contract_address`: `string`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-1)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `SignedTransaction`: \{ `raw_transaction`: `string`; `withdrawal_id`: `bigint`; \}; \} \| \{ `Upgrade`: [`UpgradeArg`](#upgradearg); \} \| \{ `Init`: [`InitArg`](#initarg); \} \| \{ `AddedCkErc20Token`: \{ `address`: `string`; `chain_id`: `bigint`; `ckerc20_ledger_id`: `Principal`; `ckerc20_token_symbol`: `string`; \}; \} \| \{ `SyncedDepositWithSubaccountToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `QuarantinedDeposit`: \{ `event_source`: [`EventSource`](#eventsource); \}; \} \| \{ `SyncedToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedDeposit`: \{ `block_number`: `bigint`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-1)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `ReplacedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \} \| \{ `QuarantinedReimbursement`: \{ `index`: [`ReimbursementIndex`](#reimbursementindex); \}; \} \| \{ `MintedCkEth`: \{ `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \} \| \{ `ReimbursedEthWithdrawal`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `FailedErc20WithdrawalRequest`: \{ `reimbursed_amount`: `bigint`; `to`: `Principal`; `to_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `ReimbursedErc20Withdrawal`: \{ `burn_in_block`: `bigint`; `ledger_id`: `Principal`; `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `MintedCkErc20`: \{ `ckerc20_token_symbol`: `string`; `erc20_contract_address`: `string`; `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \} \| \{ `CreatedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \} \| \{ `InvalidDeposit`: \{ `event_source`: [`EventSource`](#eventsource); `reason`: `string`; \}; \} \| \{ `SyncedErc20ToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedErc20WithdrawalRequest`: \{ `ckerc20_ledger_burn_index`: `bigint`; `ckerc20_ledger_id`: `Principal`; `cketh_ledger_burn_index`: `bigint`; `created_at`: `bigint`; `destination`: `string`; `erc20_contract_address`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `max_transaction_fee`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `AcceptedEthWithdrawalRequest`: \{ `created_at`: \[\] \| \[`bigint`\]; `destination`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `ledger_burn_index`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `FinalizedTransaction`: \{ `transaction_receipt`: [`TransactionReceipt`](#transactionreceipt); `withdrawal_id`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L241)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L240)

***

### EventSource

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L376)

#### Properties

##### log\_index

> **log\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L378)

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L377)

***

### GasFeeEstimate

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L380)

#### Properties

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L390)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L385)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L395)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.

***

### InitArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L400)

The initialization parameters of the minter canister.

#### Properties

##### ecdsa\_key\_name

> **ecdsa\_key\_name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L414)

The name of the ECDSA key to use.
E.g., "dfx_test_key" on the local replica.

##### ethereum\_block\_height

> **ethereum\_block\_height**: [`BlockTag`](#blocktag)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L442)

Determine ethereum block height observed by minter.

##### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L434)

Address of the helper smart contract.

##### ethereum\_network

> **ethereum\_network**: [`EthereumNetwork`](#ethereumnetwork)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L404)

The minter will interact with this Ethereum network.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L424)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain. If not specified, uses the production or
staging EVM RPC canister based on the ethereum_network field.

##### last\_scraped\_block\_number

> **last\_scraped\_block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L409)

Block number to start scrapping from on the Ethereum network.
Scrapping the logs will resume at `last_scraped_block_number + 1` (inclusive).

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L430)

The principal of the ledger that handles ckETH transfers.
The default account of the ckETH minter must be configured as
the minting account of the ledger.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L438)

Minimum amount in Wei that can be withdrawn.

##### next\_transaction\_nonce

> **next\_transaction\_nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L418)

Nonce of the next transaction to be sent to the Ethereum network.

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L490)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L493)

##### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L498)

##### global\_memory\_size

> **global\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L497)

##### snapshots\_size

> **snapshots\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L495)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L494)

##### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L491)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L492)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L496)

***

### MinterInfo

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:545](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L545)

#### Properties

##### cketh\_ledger\_id

> **cketh\_ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:587](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L587)

Canister ID of the ckETH ledger.

##### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L549)

Address of the ETH or ERC20 deposit with subaccount helper smart contract.

##### erc20\_balances

> **erc20\_balances**: \[\] \| \[`object`[]\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:605](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L605)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

##### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L571)

Address of the ERC20 helper smart contract

##### eth\_balance

> **eth\_balance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L554)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

##### eth\_helper\_contract\_address

> **eth\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:558](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L558)

Address of the ETH helper smart contract.

##### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[[`BlockTag`](#blocktag)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:619](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L619)

Determine ethereum block height observed by minter.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:567](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L567)

Canister ID of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

##### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L615)

Last scraped block number for logs of the deposit with subaccount helper contract.

##### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L575)

Last scraped block number for logs of the ERC20 helper contract.

##### last\_eth\_scraped\_block\_number

> **last\_eth\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L596)

Last scraped block number for logs of the ETH helper contract.

##### last\_gas\_fee\_estimate

> **last\_gas\_fee\_estimate**: \[\] \| \[[`GasFeeEstimate`](#gasfeeestimate)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:583](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L583)

Last gas fee estimate.

##### last\_observed\_block\_number

> **last\_observed\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:562](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L562)

Last Ethereum block number observed by the minter.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:600](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L600)

Minimum amount in Wei that can be withdrawn when converting ckETH -> ETH.

##### minter\_address

> **minter\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L611)

Ethereum address controlled by the minter via threshold ECDSA.

##### smart\_contract\_address

> **smart\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L592)

(Deprecated) Address of the ETH helper smart contract.
Use `eth_helper_contract_address`.

##### supported\_ckerc20\_tokens

> **supported\_ckerc20\_tokens**: \[\] \| \[[`CkErc20Token`](#ckerc20token)[]\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L579)

Information of supported ERC20 tokens.

***

### QueryStats

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L621)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L624)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:623](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L623)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L625)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L622)

***

### RetrieveErc20Request

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:636](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L636)

#### Properties

##### ckerc20\_block\_index

> **ckerc20\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L640)

Burn index on the ledger handling the withdrawn ckERC20 token.

##### cketh\_block\_index

> **cketh\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L645)

Burn index on the ckETH ledger.
ckETH is needed to pay for the transaction fees.

***

### RetrieveEthRequest

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L647)

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:648](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L648)

***

### TransactionReceipt

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:686](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L686)

#### Properties

##### block\_hash

> **block\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:690](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L690)

##### block\_number

> **block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:691](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L691)

##### effective\_gas\_price

> **effective\_gas\_price**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:687](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L687)

##### gas\_used

> **gas\_used**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:692](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L692)

##### status

> **status**: \{ `Success`: `null`; \} \| \{ `Failure`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:688](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L688)

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L689)

***

### UnsignedTransaction

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:723](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L723)

#### Properties

##### access\_list

> **access\_list**: `object`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L732)

###### address

> **address**: `string`

###### storage\_keys

> **storage\_keys**: `Uint8Array`\<`ArrayBufferLike`\>[]

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:729](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L729)

##### data

> **data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:727](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L727)

##### destination

> **destination**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:724](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L724)

##### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:731](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L731)

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L728)

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:726](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L726)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:730](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L730)

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:725](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L725)

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L734)

#### Properties

##### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:738](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L738)

Change the deposit with subaccount helper smart contract address.

##### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:756](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L756)

Change the ERC-20 helper smart contract address.

##### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[[`BlockTag`](#blocktag)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L776)

Change the ethereum block height observed by the minter.

##### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:764](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L764)

Change the ETH helper smart contract address.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L747)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

##### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L772)

Change the last scraped block number of the deposit with subaccount helper smart contract.

##### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:760](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L760)

Change the last scraped block number of the ERC-20 helper smart contract.

##### ledger\_suite\_orchestrator\_id

> **ledger\_suite\_orchestrator\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L752)

The principal of the ledger suite orchestrator that handles the ICRC1 ledger suites
for all ckERC20 tokens.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:768](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L768)

Change the minimum amount in Wei that can be withdrawn.

##### next\_transaction\_nonce

> **next\_transaction\_nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L742)

Change the nonce of the next transaction to be sent to the Ethereum network.

***

### WithdrawalArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:839](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L839)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:851](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L851)

The amount of ckETH in Wei that the client wants to withdraw.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:847](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L847)

The subaccount to burn ckETH from.

##### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:843](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L843)

The address to which the minter should deposit ETH.

***

### WithdrawalDetail

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L856)

Details of a withdrawal request and its status.

#### Properties

##### from

> **from**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:876](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L876)

Sender's principal.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:880](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L880)

Sender's subaccount (if given).

##### max\_transaction\_fee

> **max\_transaction\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:884](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L884)

Max transaction fee in Wei (transaction fee paid by the sender).

##### recipient\_address

> **recipient\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L888)

Address to send tokens to.

##### status

> **status**: [`WithdrawalStatus`](#withdrawalstatus)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:860](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L860)

Withdrawal status

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:864](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L864)

Symbol of the withdrawal token (either ckETH or ckERC20 token symbol).

##### withdrawal\_amount

> **withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:868](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L868)

Amount of tokens in base unit that was withdrawn.

##### withdrawal\_id

> **withdrawal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:872](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L872)

Withdrawal id (i.e. burn index on the ckETH ledger).

***

### WithdrawErc20Arg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:778](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L778)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:800](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L800)

Amount of tokens to withdraw.
The amount is in the smallest unit of the token, e.g.,
ckUSDC uses 6 decimals and so to withdraw 1 ckUSDC, the amount should be 1_000_000.

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:782](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L782)

The ledger ID for that ckERC20 token.

##### from\_ckerc20\_subaccount

> **from\_ckerc20\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:794](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L794)

The subaccount to burn ckERC20 from.

##### from\_cketh\_subaccount

> **from\_cketh\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:790](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L790)

The subaccount to burn ckETH from to pay for the transaction fee.

##### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:786](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L786)

Ethereum address to withdraw to.

## Type Aliases

### BlockTag

> **BlockTag** = \{ `Safe`: `null`; \} \| \{ `Finalized`: `null`; \} \| \{ `Latest`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L38)

#### Type Declaration

\{ `Safe`: `null`; \}

##### Safe

> **Safe**: `null`

/ The latest safe head block.

\{ `Finalized`: `null`; \}

##### Finalized

> **Finalized**: `null`

/ The latest finalized block.

\{ `Latest`: `null`; \}

##### Latest

> **Latest**: `null`

/ The latest mined block.

***

### BurnMemo

> **BurnMemo** = \{ `Erc20Convert`: \{ `ckerc20_withdrawal_id`: `bigint`; `to_address`: `string`; \}; \} \| \{ `Erc20GasFee`: \{ `ckerc20_token_symbol`: `string`; `ckerc20_withdrawal_amount`: `bigint`; `to_address`: `string`; \}; \} \| \{ `Convert`: \{ `to_address`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L57)

#### Type Declaration

\{ `Erc20Convert`: \{ `ckerc20_withdrawal_id`: `bigint`; `to_address`: `string`; \}; \}

##### Erc20Convert

> **Erc20Convert**: `object`

The minter processed a ckERC20 withdrawal request.

###### Erc20Convert.ckerc20\_withdrawal\_id

> **ckerc20\_withdrawal\_id**: `bigint`

ckETH ledger burn index identifying the burn to pay for the transaction fee.

###### Erc20Convert.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

\{ `Erc20GasFee`: \{ `ckerc20_token_symbol`: `string`; `ckerc20_withdrawal_amount`: `bigint`; `to_address`: `string`; \}; \}

##### Erc20GasFee

> **Erc20GasFee**: `object`

The minter processed a ckERC20 withdrawal request
and that burn pays the transaction fee.

###### Erc20GasFee.ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

ckERC20 token symbol of the withdrawal request.

###### Erc20GasFee.ckerc20\_withdrawal\_amount

> **ckerc20\_withdrawal\_amount**: `bigint`

The amount of the ckERC20 withdrawal request.

###### Erc20GasFee.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

\{ `Convert`: \{ `to_address`: `string`; \}; \}

##### Convert

> **Convert**: `object`

The minter processed a withdrawal request.

###### Convert.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L117)

***

### DecodedMemo

> **DecodedMemo** = \{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \} \| \{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L157)

#### Type Declaration

\{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \}

##### Burn

> **Burn**: \[\] \| \[[`BurnMemo`](#burnmemo)\]

The decoded BurnMemo - `opt` since other variants of `BurnMemo` could be added in the future.

\{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

##### Mint

> **Mint**: \[\] \| \[[`MintMemo`](#mintmemo)\]

The decoded MintMemo - `opt` since other variants of `MintMemo` could be added in the future.

***

### DecodeLedgerMemoError

> **DecodeLedgerMemoError** = `object`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L136)

#### Properties

##### InvalidMemo

> **InvalidMemo**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L140)

The provided memo could not be decoded.

***

### DecodeLedgerMemoResult

> **DecodeLedgerMemoResult** = \{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \} \| \{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L142)

#### Type Declaration

\{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \}

##### Ok

> **Ok**: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]

The decoded memo, if the minter was able to decode it. This field is `opt`, so that other memo types can be
added in the future.

\{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

##### Err

> **Err**: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]

An error in case the minter was not able to decode the provided memo. This field is `opt`, so that other error
types can be added in the future.

***

### EthereumNetwork

> **EthereumNetwork** = \{ `Mainnet`: `null`; \} \| \{ `Sepolia`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L226)

#### Type Declaration

\{ `Mainnet`: `null`; \}

##### Mainnet

> **Mainnet**: `null`

The public Ethereum mainnet.

\{ `Sepolia`: `null`; \}

##### Sepolia

> **Sepolia**: `null`

The public Ethereum Sepolia testnet.

***

### LedgerError

> **LedgerError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \} \| \{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L444)

#### Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The ledger is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

###### InsufficientAllowance.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### InsufficientAllowance.ledger\_id

> **ledger\_id**: `Principal`

###### InsufficientAllowance.token\_symbol

> **token\_symbol**: `string`

\{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \}

##### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low and doesn't cover the ledger transaction fee.

###### AmountTooLow.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### AmountTooLow.ledger\_id

> **ledger\_id**: `Principal`

###### AmountTooLow.minimum\_burn\_amount

> **minimum\_burn\_amount**: `bigint`

###### AmountTooLow.token\_symbol

> **token\_symbol**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

###### InsufficientFunds.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### InsufficientFunds.ledger\_id

> **ledger\_id**: `Principal`

###### InsufficientFunds.token\_symbol

> **token\_symbol**: `string`

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L485)

***

### MemoType

> **MemoType** = \{ `Burn`: `null`; \} \| \{ `Mint`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L489)

***

### MinterArg

> **MinterArg** = \{ `UpgradeArg`: [`UpgradeArg`](#upgradearg); \} \| \{ `InitArg`: [`InitArg`](#initarg); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:544](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L544)

***

### MintMemo

> **MintMemo** = \{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \} \| \{ `ReimburseTransaction`: \{ `tx_hash`: `string`; `withdrawal_id`: `bigint`; \}; \} \| \{ `Convert`: \{ `from_address`: `string`; `log_index`: `bigint`; `tx_hash`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L500)

#### Type Declaration

\{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \}

##### ReimburseWithdrawal

> **ReimburseWithdrawal**: `object`

The minter failed to process a withdrawal request,
so no transaction was issued, but some reimbursement was made.

###### ReimburseWithdrawal.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request.

\{ `ReimburseTransaction`: \{ `tx_hash`: `string`; `withdrawal_id`: `bigint`; \}; \}

##### ReimburseTransaction

> **ReimburseTransaction**: `object`

###### ReimburseTransaction.tx\_hash

> **tx\_hash**: `string`

Hash of the failed transaction.

###### ReimburseTransaction.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request.

\{ `Convert`: \{ `from_address`: `string`; `log_index`: `bigint`; `tx_hash`: `string`; \}; \}

##### Convert

> **Convert**: `object`

The minter received some ETH or ERC20 token.

###### Convert.from\_address

> **from\_address**: `string`

The sender of the ETH or ERC20 token.

###### Convert.log\_index

> **log\_index**: `bigint`

Integer of the log index position in the block.

###### Convert.tx\_hash

> **tx\_hash**: `string`

Hash of the transaction.

***

### ReimbursementIndex

> **ReimbursementIndex** = \{ `CkErc20`: \{ `ckerc20_ledger_burn_index`: `bigint`; `cketh_ledger_burn_index`: `bigint`; `ledger_id`: `Principal`; \}; \} \| \{ `CkEth`: \{ `ledger_burn_index`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L627)

***

### RetrieveEthStatus

> **RetrieveEthStatus** = \{ `NotFound`: `null`; \} \| \{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \} \| \{ `TxSent`: [`EthTransaction`](#ethtransaction); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L653)

Retrieve the status of a withdrawal request.

#### Type Declaration

\{ `NotFound`: `null`; \}

##### NotFound

> **NotFound**: `null`

Withdrawal request is not found.

\{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \}

##### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](#txfinalizedstatus)

Ethereum transaction is finalized.

\{ `TxSent`: [`EthTransaction`](#ethtransaction); \}

##### TxSent

> **TxSent**: [`EthTransaction`](#ethtransaction)

Ethereum transaction was signed and is sent to the network.

\{ `TxCreated`: `null`; \}

##### TxCreated

> **TxCreated**: `null`

Transaction fees were estimated and an Ethereum transaction was created.
Transaction is not signed yet.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

Withdrawal request is waiting to be processed.

***

### Subaccount

> **Subaccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L685)

***

### TxFinalizedStatus

> **TxFinalizedStatus** = \{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \} \| \{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \} \| \{ `PendingReimbursement`: [`EthTransaction`](#ethtransaction); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:697](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L697)

Status of a finalized transaction.

#### Type Declaration

\{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \}

##### Success

> **Success**: `object`

Transaction was successful.

###### Success.effective\_transaction\_fee

> **effective\_transaction\_fee**: \[\] \| \[`bigint`\]

###### Success.transaction\_hash

> **transaction\_hash**: `string`

\{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \}

##### Reimbursed

> **Reimbursed**: `object`

Transaction failed, user got reimbursed.

###### Reimbursed.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

###### Reimbursed.reimbursed\_in\_block

> **reimbursed\_in\_block**: `bigint`

###### Reimbursed.transaction\_hash

> **transaction\_hash**: `string`

\{ `PendingReimbursement`: [`EthTransaction`](#ethtransaction); \}

##### PendingReimbursement

> **PendingReimbursement**: [`EthTransaction`](#ethtransaction)

Transaction failed and will be reimbursed,

***

### WithdrawalError

> **WithdrawalError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L890)

#### Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter or the ckETH ledger is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

\{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \}

##### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

###### AmountTooLow.min\_withdrawal\_amount

> **min\_withdrawal\_amount**: `bigint`

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

##### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

###### RecipientAddressBlocked.address

> **address**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The ckETH balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

***

### WithdrawalSearchParameter

> **WithdrawalSearchParameter** = \{ `ByRecipient`: `string`; \} \| \{ `BySenderAccount`: [`Account`](#account); \} \| \{ `ByWithdrawalId`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:927](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L927)

Search parameter for withdrawals.

#### Type Declaration

\{ `ByRecipient`: `string`; \}

##### ByRecipient

> **ByRecipient**: `string`

Search by recipient's ETH address.

\{ `BySenderAccount`: [`Account`](#account); \}

##### BySenderAccount

> **BySenderAccount**: [`Account`](#account)

Search by sender's token account.

\{ `ByWithdrawalId`: `bigint`; \}

##### ByWithdrawalId

> **ByWithdrawalId**: `bigint`

Search by ckETH burn index (which is also used to index ckERC20 withdrawals).

***

### WithdrawalStatus

> **WithdrawalStatus** = \{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \} \| \{ `TxSent`: [`EthTransaction`](#ethtransaction); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L949)

Status of a withdrawal request.

#### Type Declaration

\{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \}

##### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](#txfinalizedstatus)

Transaction already finalized.

\{ `TxSent`: [`EthTransaction`](#ethtransaction); \}

##### TxSent

> **TxSent**: [`EthTransaction`](#ethtransaction)

Transaction sent but not yet finalized.

\{ `TxCreated`: `null`; \}

##### TxCreated

> **TxCreated**: `null`

Transaction created byt not yet sent.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

Request is pending, i.e. transaction is not yet created.

***

### WithdrawErc20Error

> **WithdrawErc20Error** = \{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](#ledgererror); \}; \} \| \{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](#ledgererror); \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:802](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L802)

#### Type Declaration

\{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \}

##### TokenNotSupported

> **TokenNotSupported**: `object`

The user provided ckERC20 token is not supported by the minter.

###### TokenNotSupported.supported\_tokens

> **supported\_tokens**: [`CkErc20Token`](#ckerc20token)[]

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](#ledgererror); \}; \}

##### CkErc20LedgerError

> **CkErc20LedgerError**: `object`

The minter could not burn the requested amount of ckERC20 tokens.
The `cketh_block_index` identifies the burn that occurred on the ckETH ledger and that will be reimbursed.

###### CkErc20LedgerError.cketh\_block\_index

> **cketh\_block\_index**: `bigint`

###### CkErc20LedgerError.error

> **error**: [`LedgerError`](#ledgererror)

\{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](#ledgererror); \}; \}

##### CkEthLedgerError

> **CkEthLedgerError**: `object`

The minter could not burn the required amount of ckETH to pay for the transaction fees.

###### CkEthLedgerError.error

> **error**: [`LedgerError`](#ledgererror)

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

##### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

###### RecipientAddressBlocked.address

> **address**: `string`

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1065](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1065)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1066](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/minter.d.ts#L1066)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
