---
title: CkEthOrchestratorDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L311)

#### Properties

##### canister\_ids

> **canister\_ids**: `ActorMethod`\<\[[`Erc20Contract`](#erc20contract)\], \[\] \| \[[`ManagedCanisterIds`](#managedcanisterids)\]\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L315)

Managed canister IDs for a given ERC20 contract

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L319)

Retrieve the status of the canister.

##### get\_orchestrator\_info

> **get\_orchestrator\_info**: `ActorMethod`\<\[\], [`OrchestratorInfo`](#orchestratorinfo)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L323)

Return internal orchestrator parameters

***

### AddErc20Arg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L13)

#### Properties

##### contract

> **contract**: [`Erc20Contract`](#erc20contract)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L14)

##### ledger\_init\_arg

> **ledger\_init\_arg**: [`LedgerInitArg`](#ledgerinitarg)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L15)

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L17)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L23)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L26)

##### memory\_metrics

> **memory\_metrics**: [`MemoryMetrics`](#memorymetrics)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L18)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L20)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L27)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L25)

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L21)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L28)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L24)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L19)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L22)

***

### CyclesManagement

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L34)

#### Properties

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L46)

Number of cycles when creating a new ICRC1 archive canister.

##### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L50)

Number of cycles when creating a new ICRC1 index canister.

##### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L42)

Number of cycles when creating a new ICRC1 ledger canister.

##### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L38)

Number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L52)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L61)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L56)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L55)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L53)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L58)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L60)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L57)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L59)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L54)

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L307)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L309)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L308)

***

### Erc20Contract

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L63)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L65)

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L64)

***

### InitArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L67)

#### Properties

##### cycles\_management

> **cycles\_management**: \[\] \| \[[`CyclesManagement`](#cyclesmanagement)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L71)

Controls the cycles management of the canisters managed by the orchestrator.

##### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L80)

Canister ID of the minter that will be notified when new ERC-20 tokens are added.

##### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L76)

All canisters that will be spawned off by the orchestrator will be controlled by the orchestrator
and *additionally* by the following controllers.

***

### InstalledCanister

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L82)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L83)

##### installed\_wasm\_hash

> **installed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L84)

***

### InstalledLedgerSuite

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L86)

#### Properties

##### archives

> **archives**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L102)

List of archive canister ids

##### index

> **index**: [`InstalledCanister`](#installedcanister)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L98)

Index canister

##### ledger

> **ledger**: [`InstalledCanister`](#installedcanister)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L94)

Ledger canister

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L90)

Token symbol on the ledger

***

### LedgerInitArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L108)

ICRC1 ledger initialization argument that will be used when the orchestrator spawns a new ledger canister.
Other fields, such as `archive_options`, needed to initialize a new ledger will be set by the orchestrator.

#### Properties

##### decimals

> **decimals**: `number`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L109)

##### token\_logo

> **token\_logo**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L112)

##### token\_name

> **token\_name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L113)

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L110)

##### transfer\_fee

> **transfer\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L111)

***

### LedgerSuiteVersion

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L115)

#### Properties

##### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L120)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"e59ec306ef67d0ec2e8919e8f6366aff31c666346e238d07d52f616bef61ccab".

##### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L132)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used to spawn off a new index canister when an ERC-20 token is added.

##### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L126)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used to spawn off a new ledger canister when an ERC-20 token is added.

***

### ManagedCanisterIds

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L138)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L141)

##### index

> **index**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L140)

##### ledger

> **ledger**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L139)

***

### ManagedCanisters

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L158)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L174)

List of archive canister ids

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L178)

ckERC20 Token symbol

##### erc20\_contract

> **erc20\_contract**: [`Erc20Contract`](#erc20contract)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L162)

Corresponding ERC20 contract

##### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L170)

Status of the index canister

##### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L166)

Status of the ledger canister

***

### ManagedLedgerSuite

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L180)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L196)

List of archive canister ids

##### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L192)

Status of the index canister

##### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L188)

Status of the ledger canister

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L184)

Token symbol

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L198)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L201)

##### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L206)

##### global\_memory\_size

> **global\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L205)

##### snapshots\_size

> **snapshots\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L203)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L202)

##### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L199)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L200)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L204)

***

### OrchestratorInfo

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L212)

#### Properties

##### cycles\_management

> **cycles\_management**: [`CyclesManagement`](#cyclesmanagement)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L216)

Cycle management parameters.

##### ledger\_suite\_version

> **ledger\_suite\_version**: \[\] \| \[[`LedgerSuiteVersion`](#ledgersuiteversion)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L233)

Ledger suite version that will be used to spawn off a new ledger suite (ledger and index canisters) when an ERC-20 token is added.

##### managed\_canisters

> **managed\_canisters**: [`ManagedCanisters`](#managedcanisters)[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L220)

List of managed canisters data for each ERC20 contract.

##### managed\_pre\_existing\_ledger\_suites

> **managed\_pre\_existing\_ledger\_suites**: \[\] \| \[[`ManagedLedgerSuite`](#managedledgersuite)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L225)

List of managed ledger suites that were not initially installed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.

##### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L237)

ckETH minter canister id.

##### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L229)

Additional controllers that new canisters will be spawned with.

***

### QueryStats

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L239)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L242)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L241)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L243)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L240)

***

### UpdateCyclesManagement

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L245)

#### Properties

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L259)

Change the number of cycles when creating a new ICRC1 archive canister.
Previously created canisters are not affected.

##### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L264)

Change the number of cycles when creating a new ICRC1 index canister.
Previously created canisters are not affected.

##### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L254)

Change the number of cycles when creating a new ICRC1 ledger canister.
Previously created canisters are not affected.

##### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L249)

Change the number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L266)

#### Properties

##### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L283)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"b24812976b2cc64f12faf813cf592631f3062bfda837334f77ab807361d64e82".
This exact version will be used for upgrading all existing archive canisters managed by the orchestrator.
Leaving this field empty will not upgrade the archive canisters.

##### cycles\_management

> **cycles\_management**: \[\] \| \[[`UpdateCyclesManagement`](#updatecyclesmanagement)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L276)

Update the cycles management of the canisters managed by the orchestrator.

##### git\_commit\_hash

> **git\_commit\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L291)

Hexadecimal encoding of the SHA-1 git commit hash used for this upgrade, e.g.,
"51d01d3936498d4010de54505d6433e9ad5cc62b", corresponding to a git revision in the
[IC repository](https://github.com/dfinity/ic).
If this field is present, the orchestrator will register all embedded wasms (ledger, index, and archive) in its stable memory,
so that those exact wasms can be used to upgrade managed canisters as specified below.

##### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L305)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used for upgrading all existing index canisters managed by the orchestrator.
Leaving this field empty will not upgrade the index canisters.

##### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L298)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used for upgrading all existing ledger canisters managed by the orchestrator.
Leaving this field empty will not upgrade the ledger canisters.

##### manage\_ledger\_suites

> **manage\_ledger\_suites**: \[\] \| \[[`InstalledLedgerSuite`](#installedledgersuite)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L272)

Add already installed ledger suites to the canisters managed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.
This assumes that the orchestrator is a controller of all the canisters in the list.

## Type Aliases

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L30)

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L134)

***

### ManagedCanisterStatus

> **ManagedCanisterStatus** = \{ `Created`: \{ `canister_id`: `Principal`; \}; \} \| \{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L143)

#### Type Declaration

\{ `Created`: \{ `canister_id`: `Principal`; \}; \}

##### Created

> **Created**: `object`

Canister created with the given principal but wasm module is not yet installed.

###### Created.canister\_id

> **canister\_id**: `Principal`

\{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

##### Installed

> **Installed**: `object`

Canister created and wasm module installed.
The wasm_hash reflects the installed wasm module by the orchestrator
but *may differ* from the one being currently deployed (if another controller did an upgrade)

###### Installed.canister\_id

> **canister\_id**: `Principal`

###### Installed.installed\_wasm\_hash

> **installed\_wasm\_hash**: `string`

***

### OrchestratorArg

> **OrchestratorArg** = \{ `UpgradeArg`: [`UpgradeArg`](#upgradearg); \} \| \{ `InitArg`: [`InitArg`](#initarg); \} \| \{ `AddErc20Arg`: [`AddErc20Arg`](#adderc20arg); \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L208)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L325)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/185ae34c9260b7229a0526c8c61c52a4e8bc9afb/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L326)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
