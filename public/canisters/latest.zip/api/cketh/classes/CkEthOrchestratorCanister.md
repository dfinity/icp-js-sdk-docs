---
title: CkEthOrchestratorCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/cketh/orchestrator.canister.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/orchestrator.canister.ts#L15)

Class representing the CkEth Orchestrator Canister, which manages the Ledger and Index canisters of ckERC20 tokens.

## See

[Code](https://github.com/dfinity/ic/tree/master/rs/ethereum/ledger-suite-orchestrator|Source)

## Extends

- `Canister`\<[`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new CkEthOrchestratorCanister**(`id`, `service`, `certifiedService`): `CkEthOrchestratorCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)

#### Returns

`CkEthOrchestratorCanister`

#### Inherited from

`Canister<CkEthOrchestratorService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### getOrchestratorInfo()

> **getOrchestratorInfo**(`params?`): `Promise`\<[`OrchestratorInfo`](../namespaces/CkEthOrchestratorDid/interfaces/OrchestratorInfo.md)\>

Defined in: [packages/canisters/src/cketh/orchestrator.canister.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/orchestrator.canister.ts#L40)

Retrieves orchestrator information, which contains the list of existing ckERC20 Ledger and Index canisters.

#### Parameters

##### params?

`QueryParams` = `{}`

The query parameters.

#### Returns

`Promise`\<[`OrchestratorInfo`](../namespaces/CkEthOrchestratorDid/interfaces/OrchestratorInfo.md)\>

A promise that resolves to the orchestrator information.

***

### create()

> `static` **create**(`options`): `CkEthOrchestratorCanister`

Defined in: [packages/canisters/src/cketh/orchestrator.canister.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/orchestrator.canister.ts#L21)

Creates an instance of CkEthOrchestratorCanister.

#### Parameters

##### options

[`CkEthOrchestratorCanisterOptions`](../type-aliases/CkEthOrchestratorCanisterOptions.md)\<[`_SERVICE`](../namespaces/CkEthOrchestratorDid/interfaces/SERVICE.md)\>

Options for creating the canister.

#### Returns

`CkEthOrchestratorCanister`

A new instance of CkEthOrchestratorCanister.
