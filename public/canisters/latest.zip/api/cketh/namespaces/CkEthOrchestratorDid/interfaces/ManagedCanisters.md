---
title: ManagedCanisters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L153)

## Properties

### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L169)

List of archive canister ids

***

### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L173)

ckERC20 Token symbol

***

### erc20\_contract

> **erc20\_contract**: [`Erc20Contract`](Erc20Contract.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L157)

Corresponding ERC20 contract

***

### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](../type-aliases/ManagedCanisterStatus.md)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L165)

Status of the index canister

***

### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](../type-aliases/ManagedCanisterStatus.md)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L161)

Status of the ledger canister
