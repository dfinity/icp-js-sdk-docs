---
title: ManagedLedgerSuite
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L175)

## Properties

### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L191)

List of archive canister ids

***

### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](../type-aliases/ManagedCanisterStatus.md)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L187)

Status of the index canister

***

### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](../type-aliases/ManagedCanisterStatus.md)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L183)

Status of the ledger canister

***

### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L179)

Token symbol
