---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L292)

## Properties

### canister\_ids

> **canister\_ids**: `ActorMethod`\<\[[`Erc20Contract`](Erc20Contract.md)\], \[\] \| \[[`ManagedCanisterIds`](ManagedCanisterIds.md)\]\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L296)

Managed canister IDs for a given ERC20 contract

***

### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](CanisterStatusResponse.md)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L300)

Retrieve the status of the canister.

***

### get\_orchestrator\_info

> **get\_orchestrator\_info**: `ActorMethod`\<\[\], [`OrchestratorInfo`](OrchestratorInfo.md)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L304)

Return internal orchestrator parameters
