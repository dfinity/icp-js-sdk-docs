---
title: QueryStats
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L224)

## Properties

### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L227)

***

### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L226)

***

### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L228)

***

### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L225)
