---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L62)

## Properties

### cycles\_management

> **cycles\_management**: \[\] \| \[[`CyclesManagement`](CyclesManagement.md)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L66)

Controls the cycles management of the canisters managed by the orchestrator.

***

### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L75)

Canister ID of the minter that will be notified when new ERC-20 tokens are added.

***

### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L71)

All canisters that will be spawned off by the orchestrator will be controlled by the orchestrator
and *additionally* by the following controllers.
