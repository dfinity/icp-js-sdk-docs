---
title: LedgerSuiteVersion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L110)

## Properties

### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L115)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"e59ec306ef67d0ec2e8919e8f6366aff31c666346e238d07d52f616bef61ccab".

***

### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L127)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used to spawn off a new index canister when an ERC-20 token is added.

***

### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L121)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used to spawn off a new ledger canister when an ERC-20 token is added.
