---
title: OrchestratorInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L197)

## Properties

### cycles\_management

> **cycles\_management**: [`CyclesManagement`](CyclesManagement.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L201)

Cycle management parameters.

***

### ledger\_suite\_version

> **ledger\_suite\_version**: \[\] \| \[[`LedgerSuiteVersion`](LedgerSuiteVersion.md)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L218)

Ledger suite version that will be used to spawn off a new ledger suite (ledger and index canisters) when an ERC-20 token is added.

***

### managed\_canisters

> **managed\_canisters**: [`ManagedCanisters`](ManagedCanisters.md)[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L205)

List of managed canisters data for each ERC20 contract.

***

### managed\_pre\_existing\_ledger\_suites

> **managed\_pre\_existing\_ledger\_suites**: \[\] \| \[[`ManagedLedgerSuite`](ManagedLedgerSuite.md)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L210)

List of managed ledger suites that were not initially installed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.

***

### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L222)

ckETH minter canister id.

***

### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L214)

Additional controllers that new canisters will be spawned with.
