---
title: ManagedCanisterIds
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L133)

## Properties

### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L136)

***

### index

> **index**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L135)

***

### ledger

> **ledger**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L134)
