---
title: AddErc20Arg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L13)

## Properties

### contract

> **contract**: [`Erc20Contract`](Erc20Contract.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L14)

***

### ledger\_init\_arg

> **ledger\_init\_arg**: [`LedgerInitArg`](LedgerInitArg.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L15)
