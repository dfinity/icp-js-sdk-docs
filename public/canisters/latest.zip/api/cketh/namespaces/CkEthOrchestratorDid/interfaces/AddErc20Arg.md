---
title: AddErc20Arg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L13)

## Properties

### contract

> **contract**: [`Erc20Contract`](Erc20Contract.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L14)

***

### ledger\_init\_arg

> **ledger\_init\_arg**: [`LedgerInitArg`](LedgerInitArg.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L15)
