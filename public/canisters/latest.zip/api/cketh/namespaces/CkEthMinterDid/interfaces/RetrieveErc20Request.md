---
title: RetrieveErc20Request
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L485)

## Properties

### ckerc20\_block\_index

> **ckerc20\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L489)

Burn index on the ledger handling the withdrawn ckERC20 token.

***

### cketh\_block\_index

> **cketh\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L494)

Burn index on the ckETH ledger.
ckETH is needed to pay for the transaction fees.
