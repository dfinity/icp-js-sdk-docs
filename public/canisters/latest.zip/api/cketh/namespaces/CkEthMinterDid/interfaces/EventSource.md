---
title: EventSource
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L280)

## Properties

### log\_index

> **log\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L282)

***

### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L281)
