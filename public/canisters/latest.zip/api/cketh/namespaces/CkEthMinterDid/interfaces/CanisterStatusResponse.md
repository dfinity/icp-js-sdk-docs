---
title: CanisterStatusResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L57)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L60)

***

### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L63)

***

### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L59)

***

### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L64)

***

### query\_stats

> **query\_stats**: [`QueryStats`](QueryStats.md)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L62)

***

### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L65)

***

### settings

> **settings**: [`DefiniteCanisterSettings`](DefiniteCanisterSettings.md)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L61)

***

### status

> **status**: [`CanisterStatusType`](../type-aliases/CanisterStatusType.md)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L58)
