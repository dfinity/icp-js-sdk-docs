---
title: TransactionReceipt
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L535)

## Properties

### block\_hash

> **block\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L539)

***

### block\_number

> **block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L540)

***

### effective\_gas\_price

> **effective\_gas\_price**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L536)

***

### gas\_used

> **gas\_used**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L541)

***

### status

> **status**: \{ `Success`: `null`; \} \| \{ `Failure`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L537)

***

### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L538)
