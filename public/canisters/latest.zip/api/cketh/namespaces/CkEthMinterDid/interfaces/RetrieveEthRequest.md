---
title: RetrieveEthRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L496)

## Properties

### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L497)
