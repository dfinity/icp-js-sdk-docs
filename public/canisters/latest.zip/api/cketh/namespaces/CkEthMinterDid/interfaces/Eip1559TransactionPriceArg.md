---
title: Eip1559TransactionPriceArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L121)

Argument to Eip1559TransactionPrice.
When specified, it is to lookup transaction price for a ckERC20 token withdrawal.
When not specified (null), it is for ETH withdrawal.

## Properties

### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L125)

The ledger ID for that ckERC20 token.
