---
title: BlockTag
editUrl: false
next: true
prev: true
---

> **BlockTag** = \{ `Safe`: `null`; \} \| \{ `Finalized`: `null`; \} \| \{ `Latest`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L38)

## Type Declaration

\{ `Safe`: `null`; \}

### Safe

> **Safe**: `null`

/ The latest safe head block.

\{ `Finalized`: `null`; \}

### Finalized

> **Finalized**: `null`

/ The latest finalized block.

\{ `Latest`: `null`; \}

### Latest

> **Latest**: `null`

/ The latest mined block.
