---
title: WithdrawErc20Error
editUrl: false
next: true
prev: true
---

> **WithdrawErc20Error** = \{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](../interfaces/CkErc20Token.md)[]; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](LedgerError.md); \}; \} \| \{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](LedgerError.md); \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L651)

## Type Declaration

\{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](../interfaces/CkErc20Token.md)[]; \}; \}

### TokenNotSupported

> **TokenNotSupported**: `object`

The user provided ckERC20 token is not supported by the minter.

#### TokenNotSupported.supported\_tokens

> **supported\_tokens**: [`CkErc20Token`](../interfaces/CkErc20Token.md)[]

\{ `TemporarilyUnavailable`: `string`; \}

### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](LedgerError.md); \}; \}

### CkErc20LedgerError

> **CkErc20LedgerError**: `object`

The minter could not burn the requested amount of ckERC20 tokens.
The `cketh_block_index` identifies the burn that occurred on the ckETH ledger and that will be reimbursed.

#### CkErc20LedgerError.cketh\_block\_index

> **cketh\_block\_index**: `bigint`

#### CkErc20LedgerError.error

> **error**: [`LedgerError`](LedgerError.md)

\{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](LedgerError.md); \}; \}

### CkEthLedgerError

> **CkEthLedgerError**: `object`

The minter could not burn the required amount of ckETH to pay for the transaction fees.

#### CkEthLedgerError.error

> **error**: [`LedgerError`](LedgerError.md)

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

#### RecipientAddressBlocked.address

> **address**: `string`
