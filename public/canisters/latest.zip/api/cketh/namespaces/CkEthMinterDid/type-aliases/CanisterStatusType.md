---
title: CanisterStatusType
editUrl: false
next: true
prev: true
---

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L67)
