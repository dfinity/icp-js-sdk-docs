---
title: TxFinalizedStatus
editUrl: false
next: true
prev: true
---

> **TxFinalizedStatus** = \{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \} \| \{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \} \| \{ `PendingReimbursement`: [`EthTransaction`](../interfaces/EthTransaction.md); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L546)

Status of a finalized transaction.

## Type Declaration

\{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \}

### Success

> **Success**: `object`

Transaction was successful.

#### Success.effective\_transaction\_fee

> **effective\_transaction\_fee**: \[\] \| \[`bigint`\]

#### Success.transaction\_hash

> **transaction\_hash**: `string`

\{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \}

### Reimbursed

> **Reimbursed**: `object`

Transaction failed, user got reimbursed.

#### Reimbursed.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

#### Reimbursed.reimbursed\_in\_block

> **reimbursed\_in\_block**: `bigint`

#### Reimbursed.transaction\_hash

> **transaction\_hash**: `string`

\{ `PendingReimbursement`: [`EthTransaction`](../interfaces/EthTransaction.md); \}

### PendingReimbursement

> **PendingReimbursement**: [`EthTransaction`](../interfaces/EthTransaction.md)

Transaction failed and will be reimbursed,
