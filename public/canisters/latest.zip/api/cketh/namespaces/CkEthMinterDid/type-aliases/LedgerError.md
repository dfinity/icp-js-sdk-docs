---
title: LedgerError
editUrl: false
next: true
prev: true
---

> **LedgerError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \} \| \{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L348)

## Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The ledger is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

#### InsufficientAllowance.allowance

> **allowance**: `bigint`

#### InsufficientAllowance.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

#### InsufficientAllowance.ledger\_id

> **ledger\_id**: `Principal`

#### InsufficientAllowance.token\_symbol

> **token\_symbol**: `string`

\{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \}

### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low and doesn't cover the ledger transaction fee.

#### AmountTooLow.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

#### AmountTooLow.ledger\_id

> **ledger\_id**: `Principal`

#### AmountTooLow.minimum\_burn\_amount

> **minimum\_burn\_amount**: `bigint`

#### AmountTooLow.token\_symbol

> **token\_symbol**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

### InsufficientFunds

> **InsufficientFunds**: `object`

The balance of the withdrawal account is too low.

#### InsufficientFunds.balance

> **balance**: `bigint`

#### InsufficientFunds.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

#### InsufficientFunds.ledger\_id

> **ledger\_id**: `Principal`

#### InsufficientFunds.token\_symbol

> **token\_symbol**: `string`
