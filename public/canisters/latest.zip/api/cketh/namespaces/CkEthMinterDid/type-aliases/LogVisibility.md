---
title: LogVisibility
editUrl: false
next: true
prev: true
---

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L389)
