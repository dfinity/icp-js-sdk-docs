---
title: idlFactory
editUrl: false
next: true
prev: true
---

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L901)
