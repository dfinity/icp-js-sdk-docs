---
title: CkEthMinterDid
editUrl: false
next: true
prev: true
---

## Interfaces

- [\_SERVICE](interfaces/SERVICE.md)
- [Account](interfaces/Account.md)
- [AddCkErc20Token](interfaces/AddCkErc20Token.md)
- [CanisterStatusResponse](interfaces/CanisterStatusResponse.md)
- [CkErc20Token](interfaces/CkErc20Token.md)
- [DefiniteCanisterSettings](interfaces/DefiniteCanisterSettings.md)
- [Eip1559TransactionPrice](interfaces/Eip1559TransactionPrice.md)
- [Eip1559TransactionPriceArg](interfaces/Eip1559TransactionPriceArg.md)
- [EthTransaction](interfaces/EthTransaction.md)
- [Event](interfaces/Event.md)
- [EventSource](interfaces/EventSource.md)
- [GasFeeEstimate](interfaces/GasFeeEstimate.md)
- [InitArg](interfaces/InitArg.md)
- [MinterInfo](interfaces/MinterInfo.md)
- [QueryStats](interfaces/QueryStats.md)
- [RetrieveErc20Request](interfaces/RetrieveErc20Request.md)
- [RetrieveEthRequest](interfaces/RetrieveEthRequest.md)
- [TransactionReceipt](interfaces/TransactionReceipt.md)
- [UnsignedTransaction](interfaces/UnsignedTransaction.md)
- [UpgradeArg](interfaces/UpgradeArg.md)
- [WithdrawalArg](interfaces/WithdrawalArg.md)
- [WithdrawalDetail](interfaces/WithdrawalDetail.md)
- [WithdrawErc20Arg](interfaces/WithdrawErc20Arg.md)

## Type Aliases

- [BlockTag](type-aliases/BlockTag.md)
- [CanisterStatusType](type-aliases/CanisterStatusType.md)
- [EthereumNetwork](type-aliases/EthereumNetwork.md)
- [LedgerError](type-aliases/LedgerError.md)
- [LogVisibility](type-aliases/LogVisibility.md)
- [MinterArg](type-aliases/MinterArg.md)
- [ReimbursementIndex](type-aliases/ReimbursementIndex.md)
- [RetrieveEthStatus](type-aliases/RetrieveEthStatus.md)
- [Subaccount](type-aliases/Subaccount.md)
- [TxFinalizedStatus](type-aliases/TxFinalizedStatus.md)
- [WithdrawalError](type-aliases/WithdrawalError.md)
- [WithdrawalSearchParameter](type-aliases/WithdrawalSearchParameter.md)
- [WithdrawalStatus](type-aliases/WithdrawalStatus.md)
- [WithdrawErc20Error](type-aliases/WithdrawErc20Error.md)

## Variables

- [idlFactory](variables/idlFactory.md)
- [init](variables/init.md)
