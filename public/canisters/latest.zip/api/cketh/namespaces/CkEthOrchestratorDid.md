---
title: CkEthOrchestratorDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L292)

#### Properties

##### canister\_ids

> **canister\_ids**: `ActorMethod`\<\[[`Erc20Contract`](#erc20contract)\], \[\] \| \[[`ManagedCanisterIds`](#managedcanisterids)\]\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L296)

Managed canister IDs for a given ERC20 contract

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L300)

Retrieve the status of the canister.

##### get\_orchestrator\_info

> **get\_orchestrator\_info**: `ActorMethod`\<\[\], [`OrchestratorInfo`](#orchestratorinfo)\>

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L304)

Return internal orchestrator parameters

***

### AddErc20Arg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L13)

#### Properties

##### contract

> **contract**: [`Erc20Contract`](#erc20contract)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L14)

##### ledger\_init\_arg

> **ledger\_init\_arg**: [`LedgerInitArg`](#ledgerinitarg)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L15)

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L17)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L20)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L23)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L19)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L24)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L22)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L25)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L21)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L18)

***

### CyclesManagement

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L31)

#### Properties

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L43)

Number of cycles when creating a new ICRC1 archive canister.

##### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L47)

Number of cycles when creating a new ICRC1 index canister.

##### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L39)

Number of cycles when creating a new ICRC1 ledger canister.

##### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L35)

Number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L49)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L56)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L51)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L50)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L53)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L55)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L52)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L54)

***

### Erc20Contract

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L58)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L60)

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L59)

***

### InitArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L62)

#### Properties

##### cycles\_management

> **cycles\_management**: \[\] \| \[[`CyclesManagement`](#cyclesmanagement)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L66)

Controls the cycles management of the canisters managed by the orchestrator.

##### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L75)

Canister ID of the minter that will be notified when new ERC-20 tokens are added.

##### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L71)

All canisters that will be spawned off by the orchestrator will be controlled by the orchestrator
and *additionally* by the following controllers.

***

### InstalledCanister

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L77)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L78)

##### installed\_wasm\_hash

> **installed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L79)

***

### InstalledLedgerSuite

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L81)

#### Properties

##### archives

> **archives**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L97)

List of archive canister ids

##### index

> **index**: [`InstalledCanister`](#installedcanister)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L93)

Index canister

##### ledger

> **ledger**: [`InstalledCanister`](#installedcanister)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L89)

Ledger canister

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L85)

Token symbol on the ledger

***

### LedgerInitArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L103)

ICRC1 ledger initialization argument that will be used when the orchestrator spawns a new ledger canister.
Other fields, such as `archive_options`, needed to initialize a new ledger will be set by the orchestrator.

#### Properties

##### decimals

> **decimals**: `number`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L104)

##### token\_logo

> **token\_logo**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L107)

##### token\_name

> **token\_name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L108)

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L105)

##### transfer\_fee

> **transfer\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L106)

***

### LedgerSuiteVersion

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L110)

#### Properties

##### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L115)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"e59ec306ef67d0ec2e8919e8f6366aff31c666346e238d07d52f616bef61ccab".

##### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L127)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used to spawn off a new index canister when an ERC-20 token is added.

##### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L121)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used to spawn off a new ledger canister when an ERC-20 token is added.

***

### ManagedCanisterIds

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L133)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L136)

##### index

> **index**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L135)

##### ledger

> **ledger**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L134)

***

### ManagedCanisters

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L153)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L169)

List of archive canister ids

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L173)

ckERC20 Token symbol

##### erc20\_contract

> **erc20\_contract**: [`Erc20Contract`](#erc20contract)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L157)

Corresponding ERC20 contract

##### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L165)

Status of the index canister

##### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L161)

Status of the ledger canister

***

### ManagedLedgerSuite

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L175)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L191)

List of archive canister ids

##### index

> **index**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L187)

Status of the index canister

##### ledger

> **ledger**: \[\] \| \[[`ManagedCanisterStatus`](#managedcanisterstatus)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L183)

Status of the ledger canister

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L179)

Token symbol

***

### OrchestratorInfo

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L197)

#### Properties

##### cycles\_management

> **cycles\_management**: [`CyclesManagement`](#cyclesmanagement)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L201)

Cycle management parameters.

##### ledger\_suite\_version

> **ledger\_suite\_version**: \[\] \| \[[`LedgerSuiteVersion`](#ledgersuiteversion)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L218)

Ledger suite version that will be used to spawn off a new ledger suite (ledger and index canisters) when an ERC-20 token is added.

##### managed\_canisters

> **managed\_canisters**: [`ManagedCanisters`](#managedcanisters)[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L205)

List of managed canisters data for each ERC20 contract.

##### managed\_pre\_existing\_ledger\_suites

> **managed\_pre\_existing\_ledger\_suites**: \[\] \| \[[`ManagedLedgerSuite`](#managedledgersuite)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L210)

List of managed ledger suites that were not initially installed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.

##### minter\_id

> **minter\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L222)

ckETH minter canister id.

##### more\_controller\_ids

> **more\_controller\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L214)

Additional controllers that new canisters will be spawned with.

***

### QueryStats

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L224)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L227)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L226)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L228)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L225)

***

### UpdateCyclesManagement

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L230)

#### Properties

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L244)

Change the number of cycles when creating a new ICRC1 archive canister.
Previously created canisters are not affected.

##### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L249)

Change the number of cycles when creating a new ICRC1 index canister.
Previously created canisters are not affected.

##### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L239)

Change the number of cycles when creating a new ICRC1 ledger canister.
Previously created canisters are not affected.

##### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L234)

Change the number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L251)

#### Properties

##### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L268)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"b24812976b2cc64f12faf813cf592631f3062bfda837334f77ab807361d64e82".
This exact version will be used for upgrading all existing archive canisters managed by the orchestrator.
Leaving this field empty will not upgrade the archive canisters.

##### cycles\_management

> **cycles\_management**: \[\] \| \[[`UpdateCyclesManagement`](#updatecyclesmanagement)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L261)

Update the cycles management of the canisters managed by the orchestrator.

##### git\_commit\_hash

> **git\_commit\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L276)

Hexadecimal encoding of the SHA-1 git commit hash used for this upgrade, e.g.,
"51d01d3936498d4010de54505d6433e9ad5cc62b", corresponding to a git revision in the
[IC repository](https://github.com/dfinity/ic).
If this field is present, the orchestrator will register all embedded wasms (ledger, index, and archive) in its stable memory,
so that those exact wasms can be used to upgrade managed canisters as specified below.

##### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L290)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used for upgrading all existing index canisters managed by the orchestrator.
Leaving this field empty will not upgrade the index canisters.

##### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L283)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used for upgrading all existing ledger canisters managed by the orchestrator.
Leaving this field empty will not upgrade the ledger canisters.

##### manage\_ledger\_suites

> **manage\_ledger\_suites**: \[\] \| \[[`InstalledLedgerSuite`](#installedledgersuite)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:257](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L257)

Add already installed ledger suites to the canisters managed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.
This assumes that the orchestrator is a controller of all the canisters in the list.

## Type Aliases

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L27)

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L129)

***

### ManagedCanisterStatus

> **ManagedCanisterStatus** = \{ `Created`: \{ `canister_id`: `Principal`; \}; \} \| \{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L138)

#### Type Declaration

\{ `Created`: \{ `canister_id`: `Principal`; \}; \}

##### Created

> **Created**: `object`

Canister created with the given principal but wasm module is not yet installed.

###### Created.canister\_id

> **canister\_id**: `Principal`

\{ `Installed`: \{ `canister_id`: `Principal`; `installed_wasm_hash`: `string`; \}; \}

##### Installed

> **Installed**: `object`

Canister created and wasm module installed.
The wasm_hash reflects the installed wasm module by the orchestrator
but *may differ* from the one being currently deployed (if another controller did an upgrade)

###### Installed.canister\_id

> **canister\_id**: `Principal`

###### Installed.installed\_wasm\_hash

> **installed\_wasm\_hash**: `string`

***

### OrchestratorArg

> **OrchestratorArg** = \{ `UpgradeArg`: [`UpgradeArg`](#upgradearg); \} \| \{ `InitArg`: [`InitArg`](#initarg); \} \| \{ `AddErc20Arg`: [`AddErc20Arg`](#adderc20arg); \}

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L193)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L306)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L307)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
