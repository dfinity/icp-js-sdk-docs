---
title: CkEthMinterDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:959](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L959)

#### Properties

##### add\_ckerc20\_token

> **add\_ckerc20\_token**: `ActorMethod`\<\[[`AddCkErc20Token`](#addckerc20token)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:964](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L964)

Add a ckERC-20 token to be supported by the minter.
This call is restricted to the orchestrator ID.

##### decode\_ledger\_memo

> **decode\_ledger\_memo**: `ActorMethod`\<\[[`DecodeLedgerMemoArgs`](#decodeledgermemoargs)\], [`DecodeLedgerMemoResult`](#decodeledgermemoresult)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:968](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L968)

Decode ledger memos produced by the minter when minting (deposits) or burning (withdrawals).

##### eip\_1559\_transaction\_price

> **eip\_1559\_transaction\_price**: `ActorMethod`\<\[\[\] \| \[[`Eip1559TransactionPriceArg`](#eip1559transactionpricearg)\]\], [`Eip1559TransactionPrice`](#eip1559transactionprice)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:975](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L975)

Estimate the price of a transaction issued by the minter when converting ckETH to ETH.

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:982](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L982)

Retrieve the status of the minter canister.

##### get\_events

> **get\_events**: `ActorMethod`\<\[\{ `length`: `bigint`; `start`: `bigint`; \}\], \{ `events`: [`Event`](#event)[]; `total_event_count`: `bigint`; \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:988](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L988)

Retrieve events from the minter's audit log.
The endpoint can return fewer events than requested to bound the response size.
IMPORTANT: this endpoint is meant as a debugging tool and is not guaranteed to be backwards-compatible.

##### get\_minter\_info

> **get\_minter\_info**: `ActorMethod`\<\[\], [`MinterInfo`](#minterinfo)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:995](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L995)

Returns internal minter parameters

##### is\_address\_blocked

> **is\_address\_blocked**: `ActorMethod`\<\[`string`\], `boolean`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:999](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L999)

Check if an address is blocked by the minter.

##### minter\_address

> **minter\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1007](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1007)

Retrieve the Ethereum address controlled by the minter:
* Deposits will be transferred from the helper smart contract to this address
* Withdrawals will originate from this address
IMPORTANT: Do NOT send ETH to this address directly. Use the helper smart contract instead so that the minter
knows to which IC principal the funds should be deposited.

##### retrieve\_eth\_status

> **retrieve\_eth\_status**: `ActorMethod`\<\[`bigint`\], [`RetrieveEthStatus`](#retrieveethstatus)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1011](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1011)

Retrieve the status of a Eth withdrawal request.

##### smart\_contract\_address

> **smart\_contract\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1020](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1020)

Address of the helper smart contract.
Returns "N/A" if the helper smart contract is not set.
IMPORTANT:
* Use this address to send ETH to the minter to convert it to ckETH.
* In case the smart contract needs to be updated the returned address will change!
Always check the address before making a transfer.

##### withdraw\_erc20

> **withdraw\_erc20**: `ActorMethod`\<\[[`WithdrawErc20Arg`](#withdrawerc20arg)\], \{ `Ok`: [`RetrieveErc20Request`](#retrieveerc20request); \} \| \{ `Err`: [`WithdrawErc20Error`](#withdrawerc20error); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1024](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1024)

Withdraw the specified amount of ERC-20 tokens to the given Ethereum address.

##### withdraw\_eth

> **withdraw\_eth**: `ActorMethod`\<\[[`WithdrawalArg`](#withdrawalarg)\], \{ `Ok`: [`RetrieveEthRequest`](#retrieveethrequest); \} \| \{ `Err`: [`WithdrawalError`](#withdrawalerror); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1032](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1032)

Withdraw the specified amount in Wei to the given Ethereum address.
IMPORTANT: The current gas limit is set to 21,000 for a transaction so withdrawals to smart contract addresses will likely fail.

##### withdrawal\_status

> **withdrawal\_status**: `ActorMethod`\<\[[`WithdrawalSearchParameter`](#withdrawalsearchparameter)\], [`WithdrawalDetail`](#withdrawaldetail)[]\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1039](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1039)

Return details of all withdrawals matching the given search parameter.

***

### Account

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L16)

ICRC-1 account type.

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L17)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L18)

***

### AddCkErc20Token

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L20)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L32)

The Ethereum address of the ERC-20 smart contract.

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L28)

Ethereum chain ID.

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L24)

The ledger ID for that ckERC20 token.

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L36)

The ckERC20 token symbol on the ledger.

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L104)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L107)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L110)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L106)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L111)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L109)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L112)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L108)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L105)

***

### CkErc20Token

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L118)

#### Properties

##### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L121)

##### erc20\_contract\_address

> **erc20\_contract\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L119)

##### ledger\_canister\_id

> **ledger\_canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L120)

***

### DecodeLedgerMemoArgs

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L123)

#### Properties

##### encoded\_memo

> **encoded\_memo**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L131)

The encoded memo from a minter transaction on the ledger

##### memo\_type

> **memo\_type**: [`MemoType`](#memotype)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L127)

The encoded memo type

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L167)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L174)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L169)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L168)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L171)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L173)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L170)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L172)

***

### Eip1559TransactionPrice

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L181)

Estimate price of an EIP-1559 transaction
when converting ckETH to ETH or ckERC20 to ERC20, see
https://eips.ethereum.org/EIPS/eip-1559

#### Properties

##### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L205)

Maximum amount of gas transaction is authorized to consume.

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L191)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L186)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

##### max\_transaction\_fee

> **max\_transaction\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L196)

Maximum amount of Wei that can be charged for the transaction,
computed as `max_fee_per_gas * gas_limit`

##### timestamp

> **timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L201)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.

***

### Eip1559TransactionPriceArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L212)

Argument to Eip1559TransactionPrice.
When specified, it is to lookup transaction price for a ckERC20 token withdrawal.
When not specified (null), it is for ETH withdrawal.

#### Properties

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L216)

The ledger ID for that ckERC20 token.

***

### EthTransaction

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L218)

#### Properties

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L219)

***

### Event

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L234)

#### Properties

##### payload

> **payload**: \{ `SkippedBlock`: \{ `block_number`: `bigint`; `contract_address`: \[\] \| \[`string`\]; \}; \} \| \{ `AcceptedErc20Deposit`: \{ `block_number`: `bigint`; `erc20_contract_address`: `string`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-1)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `SignedTransaction`: \{ `raw_transaction`: `string`; `withdrawal_id`: `bigint`; \}; \} \| \{ `Upgrade`: [`UpgradeArg`](#upgradearg); \} \| \{ `Init`: [`InitArg`](#initarg); \} \| \{ `AddedCkErc20Token`: \{ `address`: `string`; `chain_id`: `bigint`; `ckerc20_ledger_id`: `Principal`; `ckerc20_token_symbol`: `string`; \}; \} \| \{ `SyncedDepositWithSubaccountToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `QuarantinedDeposit`: \{ `event_source`: [`EventSource`](#eventsource); \}; \} \| \{ `SyncedToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedDeposit`: \{ `block_number`: `bigint`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](#subaccount-1)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `ReplacedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \} \| \{ `QuarantinedReimbursement`: \{ `index`: [`ReimbursementIndex`](#reimbursementindex); \}; \} \| \{ `MintedCkEth`: \{ `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \} \| \{ `ReimbursedEthWithdrawal`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `FailedErc20WithdrawalRequest`: \{ `reimbursed_amount`: `bigint`; `to`: `Principal`; `to_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `ReimbursedErc20Withdrawal`: \{ `burn_in_block`: `bigint`; `ledger_id`: `Principal`; `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `MintedCkErc20`: \{ `ckerc20_token_symbol`: `string`; `erc20_contract_address`: `string`; `event_source`: [`EventSource`](#eventsource); `mint_block_index`: `bigint`; \}; \} \| \{ `CreatedTransaction`: \{ `transaction`: [`UnsignedTransaction`](#unsignedtransaction); `withdrawal_id`: `bigint`; \}; \} \| \{ `InvalidDeposit`: \{ `event_source`: [`EventSource`](#eventsource); `reason`: `string`; \}; \} \| \{ `SyncedErc20ToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedErc20WithdrawalRequest`: \{ `ckerc20_ledger_burn_index`: `bigint`; `ckerc20_ledger_id`: `Principal`; `cketh_ledger_burn_index`: `bigint`; `created_at`: `bigint`; `destination`: `string`; `erc20_contract_address`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `max_transaction_fee`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `AcceptedEthWithdrawalRequest`: \{ `created_at`: \[\] \| \[`bigint`\]; `destination`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `ledger_burn_index`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `FinalizedTransaction`: \{ `transaction_receipt`: [`TransactionReceipt`](#transactionreceipt); `withdrawal_id`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L236)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L235)

***

### EventSource

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L371)

#### Properties

##### log\_index

> **log\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L373)

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L372)

***

### GasFeeEstimate

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L375)

#### Properties

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L385)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L380)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L390)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.

***

### InitArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L395)

The initialization parameters of the minter canister.

#### Properties

##### ecdsa\_key\_name

> **ecdsa\_key\_name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L409)

The name of the ECDSA key to use.
E.g., "dfx_test_key" on the local replica.

##### ethereum\_block\_height

> **ethereum\_block\_height**: [`BlockTag`](#blocktag)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L437)

Determine ethereum block height observed by minter.

##### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L429)

Address of the helper smart contract.

##### ethereum\_network

> **ethereum\_network**: [`EthereumNetwork`](#ethereumnetwork)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L399)

The minter will interact with this Ethereum network.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L419)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain. If not specified, uses the production or
staging EVM RPC canister based on the ethereum_network field.

##### last\_scraped\_block\_number

> **last\_scraped\_block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L404)

Block number to start scrapping from on the Ethereum network.
Scrapping the logs will resume at `last_scraped_block_number + 1` (inclusive).

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L425)

The principal of the ledger that handles ckETH transfers.
The default account of the ckETH minter must be configured as
the minting account of the ledger.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L433)

Minimum amount in Wei that can be withdrawn.

##### next\_transaction\_nonce

> **next\_transaction\_nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L413)

Nonce of the next transaction to be sent to the Ethereum network.

***

### MinterInfo

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L530)

#### Properties

##### cketh\_ledger\_id

> **cketh\_ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L572)

Canister ID of the ckETH ledger.

##### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L534)

Address of the ETH or ERC20 deposit with subaccount helper smart contract.

##### erc20\_balances

> **erc20\_balances**: \[\] \| \[`object`[]\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:590](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L590)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

##### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L556)

Address of the ERC20 helper smart contract

##### eth\_balance

> **eth\_balance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L539)

Amount of ETH in Wei controlled by the minter.
This might be less that the actual amount available on the `minter_address()`.

##### eth\_helper\_contract\_address

> **eth\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L543)

Address of the ETH helper smart contract.

##### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[[`BlockTag`](#blocktag)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:604](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L604)

Determine ethereum block height observed by minter.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L552)

Canister ID of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

##### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:600](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L600)

Last scraped block number for logs of the deposit with subaccount helper contract.

##### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L560)

Last scraped block number for logs of the ERC20 helper contract.

##### last\_eth\_scraped\_block\_number

> **last\_eth\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L581)

Last scraped block number for logs of the ETH helper contract.

##### last\_gas\_fee\_estimate

> **last\_gas\_fee\_estimate**: \[\] \| \[[`GasFeeEstimate`](#gasfeeestimate)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L568)

Last gas fee estimate.

##### last\_observed\_block\_number

> **last\_observed\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L547)

Last Ethereum block number observed by the minter.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L585)

Minimum amount in Wei that can be withdrawn when converting ckETH -> ETH.

##### minter\_address

> **minter\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L596)

Ethereum address controlled by the minter via threshold ECDSA.

##### smart\_contract\_address

> **smart\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L577)

(Deprecated) Address of the ETH helper smart contract.
Use `eth_helper_contract_address`.

##### supported\_ckerc20\_tokens

> **supported\_ckerc20\_tokens**: \[\] \| \[[`CkErc20Token`](#ckerc20token)[]\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L564)

Information of supported ERC20 tokens.

***

### QueryStats

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:606](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L606)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:609](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L609)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:608](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L608)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L610)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:607](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L607)

***

### RetrieveErc20Request

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L621)

#### Properties

##### ckerc20\_block\_index

> **ckerc20\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L625)

Burn index on the ledger handling the withdrawn ckERC20 token.

##### cketh\_block\_index

> **cketh\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L630)

Burn index on the ckETH ledger.
ckETH is needed to pay for the transaction fees.

***

### RetrieveEthRequest

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L632)

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L633)

***

### TransactionReceipt

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:671](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L671)

#### Properties

##### block\_hash

> **block\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:675](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L675)

##### block\_number

> **block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L676)

##### effective\_gas\_price

> **effective\_gas\_price**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:672](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L672)

##### gas\_used

> **gas\_used**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L677)

##### status

> **status**: \{ `Success`: `null`; \} \| \{ `Failure`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:673](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L673)

##### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L674)

***

### UnsignedTransaction

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:708](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L708)

#### Properties

##### access\_list

> **access\_list**: `object`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:717](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L717)

###### address

> **address**: `string`

###### storage\_keys

> **storage\_keys**: `Uint8Array`\<`ArrayBufferLike`\>[]

##### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:714](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L714)

##### data

> **data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:712](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L712)

##### destination

> **destination**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:709](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L709)

##### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:716](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L716)

##### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:713](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L713)

##### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:711](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L711)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:715](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L715)

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:710](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L710)

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:719](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L719)

#### Properties

##### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:723](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L723)

Change the deposit with subaccount helper smart contract address.

##### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:741](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L741)

Change the ERC-20 helper smart contract address.

##### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[[`BlockTag`](#blocktag)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:761](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L761)

Change the ethereum block height observed by the minter.

##### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L749)

Change the ETH helper smart contract address.

##### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L732)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

##### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:757](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L757)

Change the last scraped block number of the deposit with subaccount helper smart contract.

##### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:745](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L745)

Change the last scraped block number of the ERC-20 helper smart contract.

##### ledger\_suite\_orchestrator\_id

> **ledger\_suite\_orchestrator\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:737](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L737)

The principal of the ledger suite orchestrator that handles the ICRC1 ledger suites
for all ckERC20 tokens.

##### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:753](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L753)

Change the minimum amount in Wei that can be withdrawn.

##### next\_transaction\_nonce

> **next\_transaction\_nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:727](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L727)

Change the nonce of the next transaction to be sent to the Ethereum network.

***

### WithdrawalArg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:824](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L824)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:836](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L836)

The amount of ckETH in Wei that the client wants to withdraw.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:832](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L832)

The subaccount to burn ckETH from.

##### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:828](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L828)

The address to which the minter should deposit ETH.

***

### WithdrawalDetail

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:841](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L841)

Details of a withdrawal request and its status.

#### Properties

##### from

> **from**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:861](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L861)

Sender's principal.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:865](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L865)

Sender's subaccount (if given).

##### max\_transaction\_fee

> **max\_transaction\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L869)

Max transaction fee in Wei (transaction fee paid by the sender).

##### recipient\_address

> **recipient\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L873)

Address to send tokens to.

##### status

> **status**: [`WithdrawalStatus`](#withdrawalstatus)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:845](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L845)

Withdrawal status

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:849](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L849)

Symbol of the withdrawal token (either ckETH or ckERC20 token symbol).

##### withdrawal\_amount

> **withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:853](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L853)

Amount of tokens in base unit that was withdrawn.

##### withdrawal\_id

> **withdrawal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:857](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L857)

Withdrawal id (i.e. burn index on the ckETH ledger).

***

### WithdrawErc20Arg

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:763](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L763)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:785](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L785)

Amount of tokens to withdraw.
The amount is in the smallest unit of the token, e.g.,
ckUSDC uses 6 decimals and so to withdraw 1 ckUSDC, the amount should be 1_000_000.

##### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:767](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L767)

The ledger ID for that ckERC20 token.

##### from\_ckerc20\_subaccount

> **from\_ckerc20\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L779)

The subaccount to burn ckERC20 from.

##### from\_cketh\_subaccount

> **from\_cketh\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L775)

The subaccount to burn ckETH from to pay for the transaction fee.

##### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L771)

Ethereum address to withdraw to.

## Type Aliases

### BlockTag

> **BlockTag** = \{ `Safe`: `null`; \} \| \{ `Finalized`: `null`; \} \| \{ `Latest`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L38)

#### Type Declaration

\{ `Safe`: `null`; \}

##### Safe

> **Safe**: `null`

/ The latest safe head block.

\{ `Finalized`: `null`; \}

##### Finalized

> **Finalized**: `null`

/ The latest finalized block.

\{ `Latest`: `null`; \}

##### Latest

> **Latest**: `null`

/ The latest mined block.

***

### BurnMemo

> **BurnMemo** = \{ `Erc20Convert`: \{ `ckerc20_withdrawal_id`: `bigint`; `to_address`: `string`; \}; \} \| \{ `Erc20GasFee`: \{ `ckerc20_token_symbol`: `string`; `ckerc20_withdrawal_amount`: `bigint`; `to_address`: `string`; \}; \} \| \{ `Convert`: \{ `to_address`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L57)

#### Type Declaration

\{ `Erc20Convert`: \{ `ckerc20_withdrawal_id`: `bigint`; `to_address`: `string`; \}; \}

##### Erc20Convert

> **Erc20Convert**: `object`

The minter processed a ckERC20 withdrawal request.

###### Erc20Convert.ckerc20\_withdrawal\_id

> **ckerc20\_withdrawal\_id**: `bigint`

ckETH ledger burn index identifying the burn to pay for the transaction fee.

###### Erc20Convert.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

\{ `Erc20GasFee`: \{ `ckerc20_token_symbol`: `string`; `ckerc20_withdrawal_amount`: `bigint`; `to_address`: `string`; \}; \}

##### Erc20GasFee

> **Erc20GasFee**: `object`

The minter processed a ckERC20 withdrawal request
and that burn pays the transaction fee.

###### Erc20GasFee.ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

ckERC20 token symbol of the withdrawal request.

###### Erc20GasFee.ckerc20\_withdrawal\_amount

> **ckerc20\_withdrawal\_amount**: `bigint`

The amount of the ckERC20 withdrawal request.

###### Erc20GasFee.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

\{ `Convert`: \{ `to_address`: `string`; \}; \}

##### Convert

> **Convert**: `object`

The minter processed a withdrawal request.

###### Convert.to\_address

> **to\_address**: `string`

The destination of the withdrawal request.

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L114)

***

### DecodedMemo

> **DecodedMemo** = \{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \} \| \{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L154)

#### Type Declaration

\{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \}

##### Burn

> **Burn**: \[\] \| \[[`BurnMemo`](#burnmemo)\]

The decoded BurnMemo - `opt` since other variants of `BurnMemo` could be added in the future.

\{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

##### Mint

> **Mint**: \[\] \| \[[`MintMemo`](#mintmemo)\]

The decoded MintMemo - `opt` since other variants of `MintMemo` could be added in the future.

***

### DecodeLedgerMemoError

> **DecodeLedgerMemoError** = `object`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L133)

#### Properties

##### InvalidMemo

> **InvalidMemo**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L137)

The provided memo could not be decoded.

***

### DecodeLedgerMemoResult

> **DecodeLedgerMemoResult** = \{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \} \| \{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L139)

#### Type Declaration

\{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \}

##### Ok

> **Ok**: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]

The decoded memo, if the minter was able to decode it. This field is `opt`, so that other memo types can be
added in the future.

\{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

##### Err

> **Err**: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]

An error in case the minter was not able to decode the provided memo. This field is `opt`, so that other error
types can be added in the future.

***

### EthereumNetwork

> **EthereumNetwork** = \{ `Mainnet`: `null`; \} \| \{ `Sepolia`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L221)

#### Type Declaration

\{ `Mainnet`: `null`; \}

##### Mainnet

> **Mainnet**: `null`

The public Ethereum mainnet.

\{ `Sepolia`: `null`; \}

##### Sepolia

> **Sepolia**: `null`

The public Ethereum Sepolia testnet.

***

### LedgerError

> **LedgerError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \} \| \{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L439)

#### Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The ledger is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

###### InsufficientAllowance.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### InsufficientAllowance.ledger\_id

> **ledger\_id**: `Principal`

###### InsufficientAllowance.token\_symbol

> **token\_symbol**: `string`

\{ `AmountTooLow`: \{ `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `minimum_burn_amount`: `bigint`; `token_symbol`: `string`; \}; \}

##### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low and doesn't cover the ledger transaction fee.

###### AmountTooLow.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### AmountTooLow.ledger\_id

> **ledger\_id**: `Principal`

###### AmountTooLow.minimum\_burn\_amount

> **minimum\_burn\_amount**: `bigint`

###### AmountTooLow.token\_symbol

> **token\_symbol**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; `failed_burn_amount`: `bigint`; `ledger_id`: `Principal`; `token_symbol`: `string`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

###### InsufficientFunds.failed\_burn\_amount

> **failed\_burn\_amount**: `bigint`

###### InsufficientFunds.ledger\_id

> **ledger\_id**: `Principal`

###### InsufficientFunds.token\_symbol

> **token\_symbol**: `string`

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L480)

***

### MemoType

> **MemoType** = \{ `Burn`: `null`; \} \| \{ `Mint`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L484)

***

### MinterArg

> **MinterArg** = \{ `UpgradeArg`: [`UpgradeArg`](#upgradearg); \} \| \{ `InitArg`: [`InitArg`](#initarg); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L529)

***

### MintMemo

> **MintMemo** = \{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \} \| \{ `ReimburseTransaction`: \{ `tx_hash`: `string`; `withdrawal_id`: `bigint`; \}; \} \| \{ `Convert`: \{ `from_address`: `string`; `log_index`: `bigint`; `tx_hash`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L485)

#### Type Declaration

\{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \}

##### ReimburseWithdrawal

> **ReimburseWithdrawal**: `object`

The minter failed to process a withdrawal request,
so no transaction was issued, but some reimbursement was made.

###### ReimburseWithdrawal.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request.

\{ `ReimburseTransaction`: \{ `tx_hash`: `string`; `withdrawal_id`: `bigint`; \}; \}

##### ReimburseTransaction

> **ReimburseTransaction**: `object`

###### ReimburseTransaction.tx\_hash

> **tx\_hash**: `string`

Hash of the failed transaction.

###### ReimburseTransaction.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request.

\{ `Convert`: \{ `from_address`: `string`; `log_index`: `bigint`; `tx_hash`: `string`; \}; \}

##### Convert

> **Convert**: `object`

The minter received some ETH or ERC20 token.

###### Convert.from\_address

> **from\_address**: `string`

The sender of the ETH or ERC20 token.

###### Convert.log\_index

> **log\_index**: `bigint`

Integer of the log index position in the block.

###### Convert.tx\_hash

> **tx\_hash**: `string`

Hash of the transaction.

***

### ReimbursementIndex

> **ReimbursementIndex** = \{ `CkErc20`: \{ `ckerc20_ledger_burn_index`: `bigint`; `cketh_ledger_burn_index`: `bigint`; `ledger_id`: `Principal`; \}; \} \| \{ `CkEth`: \{ `ledger_burn_index`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:612](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L612)

***

### RetrieveEthStatus

> **RetrieveEthStatus** = \{ `NotFound`: `null`; \} \| \{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \} \| \{ `TxSent`: [`EthTransaction`](#ethtransaction); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L638)

Retrieve the status of a withdrawal request.

#### Type Declaration

\{ `NotFound`: `null`; \}

##### NotFound

> **NotFound**: `null`

Withdrawal request is not found.

\{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \}

##### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](#txfinalizedstatus)

Ethereum transaction is finalized.

\{ `TxSent`: [`EthTransaction`](#ethtransaction); \}

##### TxSent

> **TxSent**: [`EthTransaction`](#ethtransaction)

Ethereum transaction was signed and is sent to the network.

\{ `TxCreated`: `null`; \}

##### TxCreated

> **TxCreated**: `null`

Transaction fees were estimated and an Ethereum transaction was created.
Transaction is not signed yet.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

Withdrawal request is waiting to be processed.

***

### Subaccount

> **Subaccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L670)

***

### TxFinalizedStatus

> **TxFinalizedStatus** = \{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \} \| \{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \} \| \{ `PendingReimbursement`: [`EthTransaction`](#ethtransaction); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:682](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L682)

Status of a finalized transaction.

#### Type Declaration

\{ `Success`: \{ `effective_transaction_fee`: \[\] \| \[`bigint`\]; `transaction_hash`: `string`; \}; \}

##### Success

> **Success**: `object`

Transaction was successful.

###### Success.effective\_transaction\_fee

> **effective\_transaction\_fee**: \[\] \| \[`bigint`\]

###### Success.transaction\_hash

> **transaction\_hash**: `string`

\{ `Reimbursed`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: `string`; \}; \}

##### Reimbursed

> **Reimbursed**: `object`

Transaction failed, user got reimbursed.

###### Reimbursed.reimbursed\_amount

> **reimbursed\_amount**: `bigint`

###### Reimbursed.reimbursed\_in\_block

> **reimbursed\_in\_block**: `bigint`

###### Reimbursed.transaction\_hash

> **transaction\_hash**: `string`

\{ `PendingReimbursement`: [`EthTransaction`](#ethtransaction); \}

##### PendingReimbursement

> **PendingReimbursement**: [`EthTransaction`](#ethtransaction)

Transaction failed and will be reimbursed,

***

### WithdrawalError

> **WithdrawalError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L875)

#### Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter or the ckETH ledger is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

\{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \}

##### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

###### AmountTooLow.min\_withdrawal\_amount

> **min\_withdrawal\_amount**: `bigint`

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

##### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

###### RecipientAddressBlocked.address

> **address**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The ckETH balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

***

### WithdrawalSearchParameter

> **WithdrawalSearchParameter** = \{ `ByRecipient`: `string`; \} \| \{ `BySenderAccount`: [`Account`](#account); \} \| \{ `ByWithdrawalId`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:912](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L912)

Search parameter for withdrawals.

#### Type Declaration

\{ `ByRecipient`: `string`; \}

##### ByRecipient

> **ByRecipient**: `string`

Search by recipient's ETH address.

\{ `BySenderAccount`: [`Account`](#account); \}

##### BySenderAccount

> **BySenderAccount**: [`Account`](#account)

Search by sender's token account.

\{ `ByWithdrawalId`: `bigint`; \}

##### ByWithdrawalId

> **ByWithdrawalId**: `bigint`

Search by ckETH burn index (which is also used to index ckERC20 withdrawals).

***

### WithdrawalStatus

> **WithdrawalStatus** = \{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \} \| \{ `TxSent`: [`EthTransaction`](#ethtransaction); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:934](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L934)

Status of a withdrawal request.

#### Type Declaration

\{ `TxFinalized`: [`TxFinalizedStatus`](#txfinalizedstatus); \}

##### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](#txfinalizedstatus)

Transaction already finalized.

\{ `TxSent`: [`EthTransaction`](#ethtransaction); \}

##### TxSent

> **TxSent**: [`EthTransaction`](#ethtransaction)

Transaction sent but not yet finalized.

\{ `TxCreated`: `null`; \}

##### TxCreated

> **TxCreated**: `null`

Transaction created byt not yet sent.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

Request is pending, i.e. transaction is not yet created.

***

### WithdrawErc20Error

> **WithdrawErc20Error** = \{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](#ledgererror); \}; \} \| \{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](#ledgererror); \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:787](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L787)

#### Type Declaration

\{ `TokenNotSupported`: \{ `supported_tokens`: [`CkErc20Token`](#ckerc20token)[]; \}; \}

##### TokenNotSupported

> **TokenNotSupported**: `object`

The user provided ckERC20 token is not supported by the minter.

###### TokenNotSupported.supported\_tokens

> **supported\_tokens**: [`CkErc20Token`](#ckerc20token)[]

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `CkErc20LedgerError`: \{ `cketh_block_index`: `bigint`; `error`: [`LedgerError`](#ledgererror); \}; \}

##### CkErc20LedgerError

> **CkErc20LedgerError**: `object`

The minter could not burn the requested amount of ckERC20 tokens.
The `cketh_block_index` identifies the burn that occurred on the ckETH ledger and that will be reimbursed.

###### CkErc20LedgerError.cketh\_block\_index

> **cketh\_block\_index**: `bigint`

###### CkErc20LedgerError.error

> **error**: [`LedgerError`](#ledgererror)

\{ `CkEthLedgerError`: \{ `error`: [`LedgerError`](#ledgererror); \}; \}

##### CkEthLedgerError

> **CkEthLedgerError**: `object`

The minter could not burn the required amount of ckETH to pay for the transaction fees.

###### CkEthLedgerError.error

> **error**: [`LedgerError`](#ledgererror)

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

##### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

###### RecipientAddressBlocked.address

> **address**: `string`

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1044](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1044)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:1045](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/cketh/minter.d.ts#L1045)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
