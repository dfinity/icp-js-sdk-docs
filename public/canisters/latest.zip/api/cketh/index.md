---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [CkEthMinterDid](namespaces/CkEthMinterDid.md)
- [CkEthOrchestratorDid](namespaces/CkEthOrchestratorDid.md)

## Classes

### CkEthMinterCanister

Defined in: [packages/canisters/src/cketh/minter.canister.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L24)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/CkEthMinterDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new CkEthMinterCanister**(`id`, `service`, `certifiedService`): [`CkEthMinterCanister`](#ckethmintercanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/CkEthMinterDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/CkEthMinterDid.md#_service)

###### Returns

[`CkEthMinterCanister`](#ckethmintercanister)

###### Inherited from

`Canister<CkEthMinterService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/CkEthMinterDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/CkEthMinterDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/CkEthMinterDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/CkEthMinterDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### eip1559TransactionPrice()

> **eip1559TransactionPrice**(`params`): `Promise`\<[`Eip1559TransactionPrice`](namespaces/CkEthMinterDid.md#eip1559transactionprice)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:146](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L146)

Estimate the price of a transaction issued by the minter when converting ckETH to ETH and ckER20 to ERC20.

###### Parameters

###### params

[`Eip1559TransactionPriceParams`](#eip1559transactionpriceparams)

The parameters to get the minter info.

###### Returns

`Promise`\<[`Eip1559TransactionPrice`](namespaces/CkEthMinterDid.md#eip1559transactionprice)\>

- The estimated gas fee and limit.

##### getMinterInfo()

> **getMinterInfo**(`params`): `Promise`\<[`MinterInfo`](namespaces/CkEthMinterDid.md#minterinfo)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L176)

Returns internal minter parameters such as the minimal withdrawal amount, the last observed block number, etc.

###### Parameters

###### params

`QueryParams`

The parameters to get the minter info.

###### Returns

`Promise`\<[`MinterInfo`](namespaces/CkEthMinterDid.md#minterinfo)\>

##### getSmartContractAddress()

> **getSmartContractAddress**(`params`): `Promise`\<`string`\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L43)

The address of the helper smart contract may change in the future when the minter is upgraded. Please verify the address of the helper contract before any important transfer by querying the minter as follows.

###### Parameters

###### params

`QueryParams` = `{}`

The parameters to resolve the ckETH smart contract address.

###### Returns

`Promise`\<`string`\>

Address of the helper smart contract.

##### retrieveEthStatus()

> **retrieveEthStatus**(`blockIndex`): `Promise`\<[`RetrieveEthStatus`](namespaces/CkEthMinterDid.md#retrieveethstatus)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:161](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L161)

Retrieve the status of a withdrawal request.

###### Parameters

###### blockIndex

`bigint`

###### Returns

`Promise`\<[`RetrieveEthStatus`](namespaces/CkEthMinterDid.md#retrieveethstatus)\>

The current status of an Ethereum transaction for a block index resulting from a withdrawal.

##### withdrawErc20()

> **withdrawErc20**(`params`): `Promise`\<[`RetrieveErc20Request`](namespaces/CkEthMinterDid.md#retrieveerc20request)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L105)

Submits a request to convert ckErc20 to Erc20 - e.g. ckUSDC to USDC - after making ICRC-2 approvals for the ckETH and related ckErc20 ledgers.

Preconditions:

The caller allowed the minter's principal to spend its funds using
[icrc2_approve] on the ckErc20 ledger and to burn some of the user’s ckETH tokens to pay for the transaction fees on the CkEth ledger.

###### Parameters

###### params

The parameters to withdrawal ckErc20 to Erc20.

###### address

`string`

The destination ETH address.

###### amount

`bigint`

The ETH amount in wei.

###### fromCkErc20Subaccount?

[`Subaccount`](namespaces/CkEthMinterDid.md#subaccount-1)

###### fromCkEthSubaccount?

[`Subaccount`](namespaces/CkEthMinterDid.md#subaccount-1)

The optional subaccount to burn ckETH from to pay for the transaction fee.

###### ledgerCanisterId

`Principal`

###### Returns

`Promise`\<[`RetrieveErc20Request`](namespaces/CkEthMinterDid.md#retrieveerc20request)\>

The successful result or the operation.

##### withdrawEth()

> **withdrawEth**(`params`): `Promise`\<[`RetrieveEthRequest`](namespaces/CkEthMinterDid.md#retrieveethrequest)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L64)

Submits a request to convert ckETH to ETH after making an ICRC-2 approval.

Preconditions:

The caller allowed the minter's principal to spend its funds using
[icrc2_approve] on the ckETH ledger.

###### Parameters

###### params

The parameters to withdrawal ckETH to ETH.

###### address

`string`

The destination ETH address.

###### amount

`bigint`

The ETH amount in wei.

###### fromSubaccount?

[`Subaccount`](namespaces/CkEthMinterDid.md#subaccount-1)

The optional subaccount to burn ckETH from.

###### Returns

`Promise`\<[`RetrieveEthRequest`](namespaces/CkEthMinterDid.md#retrieveethrequest)\>

The successful result or the operation.

##### create()

> `static` **create**(`options`): [`CkEthMinterCanister`](#ckethmintercanister)

Defined in: [packages/canisters/src/cketh/minter.canister.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/minter.canister.ts#L25)

###### Parameters

###### options

[`CkEthMinterCanisterOptions`](#ckethmintercanisteroptions)\<[`_SERVICE`](namespaces/CkEthMinterDid.md#_service)\>

###### Returns

[`CkEthMinterCanister`](#ckethmintercanister)

***

### CkEthOrchestratorCanister

Defined in: [packages/canisters/src/cketh/orchestrator.canister.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/orchestrator.canister.ts#L15)

Class representing the CkEth Orchestrator Canister, which manages the Ledger and Index canisters of ckERC20 tokens.

#### See

[Code](https://github.com/dfinity/ic/tree/master/rs/ethereum/ledger-suite-orchestrator|Source)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new CkEthOrchestratorCanister**(`id`, `service`, `certifiedService`): [`CkEthOrchestratorCanister`](#ckethorchestratorcanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)

###### Returns

[`CkEthOrchestratorCanister`](#ckethorchestratorcanister)

###### Inherited from

`Canister<CkEthOrchestratorService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### getOrchestratorInfo()

> **getOrchestratorInfo**(`params?`): `Promise`\<[`OrchestratorInfo`](namespaces/CkEthOrchestratorDid.md#orchestratorinfo)\>

Defined in: [packages/canisters/src/cketh/orchestrator.canister.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/orchestrator.canister.ts#L40)

Retrieves orchestrator information, which contains the list of existing ckERC20 Ledger and Index canisters.

###### Parameters

###### params?

`QueryParams` = `{}`

The query parameters.

###### Returns

`Promise`\<[`OrchestratorInfo`](namespaces/CkEthOrchestratorDid.md#orchestratorinfo)\>

A promise that resolves to the orchestrator information.

##### create()

> `static` **create**(`options`): [`CkEthOrchestratorCanister`](#ckethorchestratorcanister)

Defined in: [packages/canisters/src/cketh/orchestrator.canister.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/orchestrator.canister.ts#L21)

Creates an instance of CkEthOrchestratorCanister.

###### Parameters

###### options

[`CkEthOrchestratorCanisterOptions`](#ckethorchestratorcanisteroptions)\<[`_SERVICE`](namespaces/CkEthOrchestratorDid.md#_service)\>

Options for creating the canister.

###### Returns

[`CkEthOrchestratorCanister`](#ckethorchestratorcanister)

A new instance of CkEthOrchestratorCanister.

***

### DetailedError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L4)

#### Extends

- `Error`

#### Extended by

- [`MinterError`](#mintererror)
- [`LedgerError`](#ledgererror)

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new DetailedError**\<`T`\>(`__namedParameters`): [`DetailedError`](#detailederror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`DetailedError`](#detailederror)\<`T`\>

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### LedgerAmountTooLowError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L30)

#### Extends

- [`LedgerError`](#ledgererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new LedgerAmountTooLowError**\<`T`\>(`__namedParameters`): [`LedgerAmountTooLowError`](#ledgeramounttoolowerror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`LedgerAmountTooLowError`](#ledgeramounttoolowerror)\<`T`\>

###### Inherited from

[`LedgerError`](#ledgererror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`LedgerError`](#ledgererror).[`cause`](#cause-2)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`LedgerError`](#ledgererror).[`details`](#details-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`LedgerError`](#ledgererror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`LedgerError`](#ledgererror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`LedgerError`](#ledgererror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`LedgerError`](#ledgererror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`LedgerError`](#ledgererror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`LedgerError`](#ledgererror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`LedgerError`](#ledgererror).[`prepareStackTrace`](#preparestacktrace-4)

***

### LedgerError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L25)

#### Extends

- [`DetailedError`](#detailederror)\<`T`\>

#### Extended by

- [`LedgerWithdrawalError`](#ledgerwithdrawalerror)
- [`LedgerTemporaryUnavailableError`](#ledgertemporaryunavailableerror)
- [`LedgerInsufficientAllowanceError`](#ledgerinsufficientallowanceerror)
- [`LedgerAmountTooLowError`](#ledgeramounttoolowerror)
- [`LedgerInsufficientFundsError`](#ledgerinsufficientfundserror)

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new LedgerError**\<`T`\>(`__namedParameters`): [`LedgerError`](#ledgererror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`LedgerError`](#ledgererror)\<`T`\>

###### Inherited from

[`DetailedError`](#detailederror).[`constructor`](#constructor-2)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`DetailedError`](#detailederror).[`cause`](#cause)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`DetailedError`](#detailederror).[`details`](#details)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`DetailedError`](#detailederror).[`message`](#message)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`DetailedError`](#detailederror).[`name`](#name)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`DetailedError`](#detailederror).[`stack`](#stack)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`DetailedError`](#detailederror).[`stackTraceLimit`](#stacktracelimit)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`DetailedError`](#detailederror).[`captureStackTrace`](#capturestacktrace)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`DetailedError`](#detailederror).[`isError`](#iserror)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`DetailedError`](#detailederror).[`prepareStackTrace`](#preparestacktrace)

***

### LedgerGenericError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L23)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new LedgerGenericError**(`message?`): [`LedgerGenericError`](#ledgergenericerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`LedgerGenericError`](#ledgergenericerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new LedgerGenericError**(`message?`, `options?`): [`LedgerGenericError`](#ledgergenericerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`LedgerGenericError`](#ledgergenericerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### LedgerInsufficientAllowanceError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L29)

#### Extends

- [`LedgerError`](#ledgererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new LedgerInsufficientAllowanceError**\<`T`\>(`__namedParameters`): [`LedgerInsufficientAllowanceError`](#ledgerinsufficientallowanceerror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`LedgerInsufficientAllowanceError`](#ledgerinsufficientallowanceerror)\<`T`\>

###### Inherited from

[`LedgerError`](#ledgererror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`LedgerError`](#ledgererror).[`cause`](#cause-2)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`LedgerError`](#ledgererror).[`details`](#details-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`LedgerError`](#ledgererror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`LedgerError`](#ledgererror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`LedgerError`](#ledgererror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`LedgerError`](#ledgererror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`LedgerError`](#ledgererror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`LedgerError`](#ledgererror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`LedgerError`](#ledgererror).[`prepareStackTrace`](#preparestacktrace-4)

***

### LedgerInsufficientFundsError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L31)

#### Extends

- [`LedgerError`](#ledgererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new LedgerInsufficientFundsError**\<`T`\>(`__namedParameters`): [`LedgerInsufficientFundsError`](#ledgerinsufficientfundserror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`LedgerInsufficientFundsError`](#ledgerinsufficientfundserror)\<`T`\>

###### Inherited from

[`LedgerError`](#ledgererror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`LedgerError`](#ledgererror).[`cause`](#cause-2)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`LedgerError`](#ledgererror).[`details`](#details-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`LedgerError`](#ledgererror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`LedgerError`](#ledgererror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`LedgerError`](#ledgererror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`LedgerError`](#ledgererror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`LedgerError`](#ledgererror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`LedgerError`](#ledgererror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`LedgerError`](#ledgererror).[`prepareStackTrace`](#preparestacktrace-4)

***

### LedgerTemporaryUnavailableError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L28)

#### Extends

- [`LedgerError`](#ledgererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new LedgerTemporaryUnavailableError**\<`T`\>(`__namedParameters`): [`LedgerTemporaryUnavailableError`](#ledgertemporaryunavailableerror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`LedgerTemporaryUnavailableError`](#ledgertemporaryunavailableerror)\<`T`\>

###### Inherited from

[`LedgerError`](#ledgererror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`LedgerError`](#ledgererror).[`cause`](#cause-2)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`LedgerError`](#ledgererror).[`details`](#details-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`LedgerError`](#ledgererror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`LedgerError`](#ledgererror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`LedgerError`](#ledgererror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`LedgerError`](#ledgererror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`LedgerError`](#ledgererror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`LedgerError`](#ledgererror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`LedgerError`](#ledgererror).[`prepareStackTrace`](#preparestacktrace-4)

***

### LedgerWithdrawalError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L27)

#### Extends

- [`LedgerError`](#ledgererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new LedgerWithdrawalError**\<`T`\>(`__namedParameters`): [`LedgerWithdrawalError`](#ledgerwithdrawalerror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`LedgerWithdrawalError`](#ledgerwithdrawalerror)\<`T`\>

###### Inherited from

[`LedgerError`](#ledgererror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`LedgerError`](#ledgererror).[`cause`](#cause-2)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`LedgerError`](#ledgererror).[`details`](#details-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`LedgerError`](#ledgererror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`LedgerError`](#ledgererror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`LedgerError`](#ledgererror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`LedgerError`](#ledgererror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`LedgerError`](#ledgererror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`LedgerError`](#ledgererror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`LedgerError`](#ledgererror).[`prepareStackTrace`](#preparestacktrace-4)

***

### MinterAmountTooLowError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L19)

#### Extends

- [`MinterError`](#mintererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new MinterAmountTooLowError**\<`T`\>(`__namedParameters`): [`MinterAmountTooLowError`](#minteramounttoolowerror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`MinterAmountTooLowError`](#minteramounttoolowerror)\<`T`\>

###### Inherited from

[`MinterError`](#mintererror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterError`](#mintererror).[`cause`](#cause-9)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`MinterError`](#mintererror).[`details`](#details-8)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterError`](#mintererror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterError`](#mintererror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterError`](#mintererror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterError`](#mintererror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterError`](#mintererror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterError`](#mintererror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterError`](#mintererror).[`prepareStackTrace`](#preparestacktrace-18)

***

### MinterError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L14)

#### Extends

- [`DetailedError`](#detailederror)\<`T`\>

#### Extended by

- [`MinterInsufficientFundsError`](#minterinsufficientfundserror)
- [`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)
- [`MinterAmountTooLowError`](#minteramounttoolowerror)
- [`MinterRecipientAddressBlockedError`](#minterrecipientaddressblockederror)
- [`MinterTokenNotSupported`](#mintertokennotsupported)

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new MinterError**\<`T`\>(`__namedParameters`): [`MinterError`](#mintererror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`MinterError`](#mintererror)\<`T`\>

###### Inherited from

[`DetailedError`](#detailederror).[`constructor`](#constructor-2)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`DetailedError`](#detailederror).[`cause`](#cause)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`DetailedError`](#detailederror).[`details`](#details)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`DetailedError`](#detailederror).[`message`](#message)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`DetailedError`](#detailederror).[`name`](#name)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`DetailedError`](#detailederror).[`stack`](#stack)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`DetailedError`](#detailederror).[`stackTraceLimit`](#stacktracelimit)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`DetailedError`](#detailederror).[`captureStackTrace`](#capturestacktrace)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`DetailedError`](#detailederror).[`isError`](#iserror)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`DetailedError`](#detailederror).[`prepareStackTrace`](#preparestacktrace)

***

### MinterGenericError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L12)

#### Extends

- `Error`

#### Extended by

- [`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

#### Constructors

##### Constructor

> **new MinterGenericError**(`message?`): [`MinterGenericError`](#mintergenericerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterGenericError`](#mintergenericerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new MinterGenericError**(`message?`, `options?`): [`MinterGenericError`](#mintergenericerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterGenericError`](#mintergenericerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### MinterInsufficientAllowanceError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L18)

#### Extends

- [`MinterError`](#mintererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new MinterInsufficientAllowanceError**\<`T`\>(`__namedParameters`): [`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)\<`T`\>

###### Inherited from

[`MinterError`](#mintererror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterError`](#mintererror).[`cause`](#cause-9)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`MinterError`](#mintererror).[`details`](#details-8)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterError`](#mintererror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterError`](#mintererror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterError`](#mintererror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterError`](#mintererror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterError`](#mintererror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterError`](#mintererror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterError`](#mintererror).[`prepareStackTrace`](#preparestacktrace-18)

***

### MinterInsufficientFundsError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L17)

#### Extends

- [`MinterError`](#mintererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new MinterInsufficientFundsError**\<`T`\>(`__namedParameters`): [`MinterInsufficientFundsError`](#minterinsufficientfundserror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`MinterInsufficientFundsError`](#minterinsufficientfundserror)\<`T`\>

###### Inherited from

[`MinterError`](#mintererror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterError`](#mintererror).[`cause`](#cause-9)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`MinterError`](#mintererror).[`details`](#details-8)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterError`](#mintererror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterError`](#mintererror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterError`](#mintererror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterError`](#mintererror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterError`](#mintererror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterError`](#mintererror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterError`](#mintererror).[`prepareStackTrace`](#preparestacktrace-18)

***

### MinterRecipientAddressBlockedError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L20)

#### Extends

- [`MinterError`](#mintererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new MinterRecipientAddressBlockedError**\<`T`\>(`__namedParameters`): [`MinterRecipientAddressBlockedError`](#minterrecipientaddressblockederror)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`MinterRecipientAddressBlockedError`](#minterrecipientaddressblockederror)\<`T`\>

###### Inherited from

[`MinterError`](#mintererror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterError`](#mintererror).[`cause`](#cause-9)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`MinterError`](#mintererror).[`details`](#details-8)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterError`](#mintererror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterError`](#mintererror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterError`](#mintererror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterError`](#mintererror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterError`](#mintererror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterError`](#mintererror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterError`](#mintererror).[`prepareStackTrace`](#preparestacktrace-18)

***

### MinterTemporaryUnavailableError

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L16)

#### Extends

- [`MinterGenericError`](#mintergenericerror)

#### Constructors

##### Constructor

> **new MinterTemporaryUnavailableError**(`message?`): [`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-12)

##### Constructor

> **new MinterTemporaryUnavailableError**(`message?`, `options?`): [`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-12)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`cause`](#cause-10)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`message`](#message-10)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`name`](#name-10)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stack`](#stack-10)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stackTraceLimit`](#stacktracelimit-10)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`captureStackTrace`](#capturestacktrace-20)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`isError`](#iserror-20)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`prepareStackTrace`](#preparestacktrace-20)

***

### MinterTokenNotSupported

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L21)

#### Extends

- [`MinterError`](#mintererror)\<`T`\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new MinterTokenNotSupported**\<`T`\>(`__namedParameters`): [`MinterTokenNotSupported`](#mintertokennotsupported)\<`T`\>

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L6)

###### Parameters

###### \_\_namedParameters

###### details?

`T`

###### msg?

`string`

###### Returns

[`MinterTokenNotSupported`](#mintertokennotsupported)\<`T`\>

###### Inherited from

[`MinterError`](#mintererror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterError`](#mintererror).[`cause`](#cause-9)

##### details

> **details**: `T` \| `undefined`

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L5)

###### Inherited from

[`MinterError`](#mintererror).[`details`](#details-8)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterError`](#mintererror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterError`](#mintererror).[`name`](#name-9)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterError`](#mintererror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterError`](#mintererror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterError`](#mintererror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterError`](#mintererror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterError`](#mintererror).[`prepareStackTrace`](#preparestacktrace-18)

## Interfaces

### CkEthMinterCanisterOptions

Defined in: [packages/canisters/src/cketh/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/types/canister.options.ts#L4)

#### Extends

- `Omit`\<`CanisterOptions`\<`T`\>, `"canisterId"`\>

#### Type Parameters

##### T

`T`

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

###### Inherited from

[`NnsGovernanceCanisterOptions`](../nns/index.md#nnsgovernancecanisteroptions).[`agent`](../nns/index.md#agent)

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/cketh/types/canister.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/types/canister.options.ts#L9)

##### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

###### Inherited from

`Omit.certifiedServiceOverride`

##### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

###### Inherited from

`Omit.serviceOverride`

## Type Aliases

### CkEthOrchestratorCanisterOptions

> **CkEthOrchestratorCanisterOptions**\<`T`\> = [`CkEthMinterCanisterOptions`](#ckethmintercanisteroptions)\<`T`\>

Defined in: [packages/canisters/src/cketh/types/canister.options.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/types/canister.options.ts#L12)

#### Type Parameters

##### T

`T`

***

### Eip1559TransactionPriceParams

> **Eip1559TransactionPriceParams** = `object` & `QueryParams`

Defined in: [packages/canisters/src/cketh/types/minter.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/types/minter.params.ts#L5)

#### Type Declaration

##### ckErc20LedgerId?

> `optional` **ckErc20LedgerId**: `Principal`

## Functions

### createWithdrawErc20Error()

> **createWithdrawErc20Error**(`Err`): [`MinterGenericError`](#mintergenericerror)

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:71](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L71)

#### Parameters

##### Err

[`WithdrawErc20Error`](namespaces/CkEthMinterDid.md#withdrawerc20error)

#### Returns

[`MinterGenericError`](#mintergenericerror)

***

### createWithdrawEthError()

> **createWithdrawEthError**(`Err`): [`MinterGenericError`](#mintergenericerror)

Defined in: [packages/canisters/src/cketh/errors/minter.errors.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/errors/minter.errors.ts#L33)

#### Parameters

##### Err

[`WithdrawalError`](namespaces/CkEthMinterDid.md#withdrawalerror)

#### Returns

[`MinterGenericError`](#mintergenericerror)

***

### encodePrincipalToEthAddress()

> **encodePrincipalToEthAddress**(`principal`): `string`

Defined in: [packages/canisters/src/cketh/utils/minter.utils.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/cketh/utils/minter.utils.ts#L12)

Encode a principal to a byte array as Ethereum data hex (staring with 0x).
Such a conversion is required to deposit ETH to the ckETH helper contract.

Code adapted from the ckETH minter dashboard JS function: https://github.com/dfinity/ic/blob/master/rs/ethereum/cketh/minter/templates/principal_to_bytes.js

#### Parameters

##### principal

`Principal`

The principal to encode into a fixed 32-byte representation suitable for calling Ethereum smart contracts.

#### Returns

`string`
