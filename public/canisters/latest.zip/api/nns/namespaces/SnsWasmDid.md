---
title: SnsWasmDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L277)

#### Properties

##### add\_wasm

> **add\_wasm**: `ActorMethod`\<\[[`AddWasmRequest`](#addwasmrequest)\], [`AddWasmResponse`](#addwasmresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L278)

##### deploy\_new\_sns

> **deploy\_new\_sns**: `ActorMethod`\<\[[`DeployNewSnsRequest`](#deploynewsnsrequest)\], [`DeployNewSnsResponse`](#deploynewsnsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L279)

##### get\_allowed\_principals

> **get\_allowed\_principals**: `ActorMethod`\<\[\{ \}\], [`GetAllowedPrincipalsResponse`](#getallowedprincipalsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L280)

##### get\_deployed\_sns\_by\_proposal\_id

> **get\_deployed\_sns\_by\_proposal\_id**: `ActorMethod`\<\[[`GetDeployedSnsByProposalIdRequest`](#getdeployedsnsbyproposalidrequest)\], [`GetDeployedSnsByProposalIdResponse`](#getdeployedsnsbyproposalidresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L281)

##### get\_latest\_sns\_version\_pretty

> **get\_latest\_sns\_version\_pretty**: `ActorMethod`\<\[`null`\], \[`string`, `string`\][]\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L285)

##### get\_next\_sns\_version

> **get\_next\_sns\_version**: `ActorMethod`\<\[[`GetNextSnsVersionRequest`](#getnextsnsversionrequest)\], [`GetNextSnsVersionResponse`](#getnextsnsversionresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L286)

##### get\_proposal\_id\_that\_added\_wasm

> **get\_proposal\_id\_that\_added\_wasm**: `ActorMethod`\<\[[`GetProposalIdThatAddedWasmRequest`](#getproposalidthataddedwasmrequest)\], [`GetProposalIdThatAddedWasmResponse`](#getproposalidthataddedwasmresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L290)

##### get\_sns\_subnet\_ids

> **get\_sns\_subnet\_ids**: `ActorMethod`\<\[\{ \}\], [`GetSnsSubnetIdsResponse`](#getsnssubnetidsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L294)

##### get\_wasm

> **get\_wasm**: `ActorMethod`\<\[[`GetWasmRequest`](#getwasmrequest)\], [`GetWasmResponse`](#getwasmresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L295)

##### get\_wasm\_metadata

> **get\_wasm\_metadata**: `ActorMethod`\<\[[`GetWasmMetadataRequest`](#getwasmmetadatarequest)\], [`GetWasmMetadataResponse`](#getwasmmetadataresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L296)

##### insert\_upgrade\_path\_entries

> **insert\_upgrade\_path\_entries**: `ActorMethod`\<\[[`InsertUpgradePathEntriesRequest`](#insertupgradepathentriesrequest)\], [`InsertUpgradePathEntriesResponse`](#insertupgradepathentriesresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L300)

##### list\_deployed\_snses

> **list\_deployed\_snses**: `ActorMethod`\<\[\{ \}\], [`ListDeployedSnsesResponse`](#listdeployedsnsesresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L304)

##### list\_upgrade\_steps

> **list\_upgrade\_steps**: `ActorMethod`\<\[[`ListUpgradeStepsRequest`](#listupgradestepsrequest)\], [`ListUpgradeStepsResponse`](#listupgradestepsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L305)

##### update\_allowed\_principals

> **update\_allowed\_principals**: `ActorMethod`\<\[[`UpdateAllowedPrincipalsRequest`](#updateallowedprincipalsrequest)\], [`UpdateAllowedPrincipalsResponse`](#updateallowedprincipalsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L309)

##### update\_sns\_subnet\_list

> **update\_sns\_subnet\_list**: `ActorMethod`\<\[[`UpdateSnsSubnetListRequest`](#updatesnssubnetlistrequest)\], [`UpdateSnsSubnetListResponse`](#updatesnssubnetlistresponse)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L313)

***

### AddWasmRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L13)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L14)

##### skip\_update\_latest\_version

> **skip\_update\_latest\_version**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L16)

##### wasm

> **wasm**: \[\] \| \[[`SnsWasm`](#snswasm)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L15)

***

### AddWasmResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L18)

#### Properties

##### result

> **result**: \[\] \| \[[`Result`](#result-2)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L19)

***

### Canister

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L21)

#### Properties

##### id

> **id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L22)

***

### Countries

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L24)

#### Properties

##### iso\_codes

> **iso\_codes**: `string`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L25)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L27)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L28)

***

### DappCanisters

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L30)

#### Properties

##### canisters

> **canisters**: [`Canister`](#canister)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L31)

***

### DappCanistersTransferResult

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L33)

#### Properties

##### nns\_controlled\_dapp\_canisters

> **nns\_controlled\_dapp\_canisters**: [`Canister`](#canister)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L35)

##### restored\_dapp\_canisters

> **restored\_dapp\_canisters**: [`Canister`](#canister)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L34)

##### sns\_controlled\_dapp\_canisters

> **sns\_controlled\_dapp\_canisters**: [`Canister`](#canister)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L36)

***

### DeployedSns

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L47)

#### Properties

##### governance\_canister\_id

> **governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L49)

##### index\_canister\_id

> **index\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L50)

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L52)

##### root\_canister\_id

> **root\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L48)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L51)

***

### DeployNewSnsRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L38)

#### Properties

##### sns\_init\_payload

> **sns\_init\_payload**: \[\] \| \[[`SnsInitPayload`](#snsinitpayload)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L39)

***

### DeployNewSnsResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L41)

#### Properties

##### canisters

> **canisters**: \[\] \| \[[`SnsCanisterIds`](#snscanisterids)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L45)

##### dapp\_canisters\_transfer\_result

> **dapp\_canisters\_transfer\_result**: \[\] \| \[[`DappCanistersTransferResult`](#dappcanisterstransferresult)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L42)

##### error

> **error**: \[\] \| \[[`SnsWasmError`](#snswasmerror)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L44)

##### subnet\_id

> **subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L43)

***

### DeveloperDistribution

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L54)

#### Properties

##### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](#neurondistribution)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L55)

***

### FractionalDeveloperVotingPower

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L57)

#### Properties

##### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](#developerdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L59)

##### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](#swapdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L60)

##### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`TreasuryDistribution`](#treasurydistribution)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L58)

***

### GetAllowedPrincipalsResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L62)

#### Properties

##### allowed\_principals

> **allowed\_principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L63)

***

### GetDeployedSnsByProposalIdRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L65)

#### Properties

##### proposal\_id

> **proposal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L66)

***

### GetDeployedSnsByProposalIdResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L68)

#### Properties

##### get\_deployed\_sns\_by\_proposal\_id\_result

> **get\_deployed\_sns\_by\_proposal\_id\_result**: \[\] \| \[[`GetDeployedSnsByProposalIdResult`](#getdeployedsnsbyproposalidresult)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L69)

***

### GetNextSnsVersionRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L76)

#### Properties

##### current\_version

> **current\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L78)

##### governance\_canister\_id

> **governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L77)

***

### GetNextSnsVersionResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L80)

#### Properties

##### next\_version

> **next\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L81)

***

### GetProposalIdThatAddedWasmRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L83)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L84)

***

### GetProposalIdThatAddedWasmResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L86)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L87)

***

### GetSnsSubnetIdsResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L89)

#### Properties

##### sns\_subnet\_ids

> **sns\_subnet\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L90)

***

### GetWasmMetadataRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L92)

#### Properties

##### hash

> **hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L93)

***

### GetWasmMetadataResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L95)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L96)

***

### GetWasmRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L98)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L99)

***

### GetWasmResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L101)

#### Properties

##### wasm

> **wasm**: \[\] \| \[[`SnsWasm`](#snswasm)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L102)

***

### IdealMatchedParticipationFunction

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L104)

#### Properties

##### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L105)

***

### InsertUpgradePathEntriesRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L110)

#### Properties

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L112)

##### upgrade\_path

> **upgrade\_path**: [`SnsUpgrade`](#snsupgrade)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L111)

***

### InsertUpgradePathEntriesResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L114)

#### Properties

##### error

> **error**: \[\] \| \[[`SnsWasmError`](#snswasmerror)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L115)

***

### LinearScalingCoefficient

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L117)

#### Properties

##### from\_direct\_participation\_icp\_e8s

> **from\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L120)

##### intercept\_icp\_e8s

> **intercept\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L119)

##### slope\_denominator

> **slope\_denominator**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L121)

##### slope\_numerator

> **slope\_numerator**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L118)

##### to\_direct\_participation\_icp\_e8s

> **to\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L122)

***

### ListDeployedSnsesResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L124)

#### Properties

##### instances

> **instances**: [`DeployedSns`](#deployedsns)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L125)

***

### ListUpgradeStep

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L127)

#### Properties

##### pretty\_version

> **pretty\_version**: \[\] \| \[[`PrettySnsVersion`](#prettysnsversion)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L128)

##### version

> **version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L129)

***

### ListUpgradeStepsRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L131)

#### Properties

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L132)

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L134)

##### starting\_at

> **starting\_at**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L133)

***

### ListUpgradeStepsResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L136)

#### Properties

##### steps

> **steps**: [`ListUpgradeStep`](#listupgradestep)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L137)

***

### MetadataSection

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L139)

#### Properties

##### contents

> **contents**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L140)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L141)

##### visibility

> **visibility**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L142)

***

### NeuronBasketConstructionParameters

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L144)

#### Properties

##### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L146)

##### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L145)

***

### NeuronDistribution

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L148)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L149)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L150)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L151)

##### stake\_e8s

> **stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L152)

##### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L153)

***

### NeuronsFundParticipationConstraints

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L155)

#### Properties

##### coefficient\_intervals

> **coefficient\_intervals**: [`LinearScalingCoefficient`](#linearscalingcoefficient)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L156)

##### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](#idealmatchedparticipationfunction)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L159)

##### max\_neurons\_fund\_participation\_icp\_e8s

> **max\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L157)

##### min\_direct\_participation\_threshold\_icp\_e8s

> **min\_direct\_participation\_threshold\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L158)

***

### Ok

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L163)

#### Properties

##### sections

> **sections**: [`MetadataSection`](#metadatasection)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L164)

***

### PrettySnsVersion

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L166)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L167)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L171)

##### index\_wasm\_hash

> **index\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L172)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L170)

##### root\_wasm\_hash

> **root\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L168)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L169)

***

### SnsCanisterIds

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L176)

#### Properties

##### governance

> **governance**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L181)

##### index

> **index**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L180)

##### ledger

> **ledger**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L179)

##### root

> **root**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L177)

##### swap

> **swap**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L178)

***

### SnsInitPayload

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L183)

#### Properties

##### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L198)

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L212)

##### dapp\_canisters

> **dapp\_canisters**: \[\] \| \[[`DappCanisters`](#dappcanisters)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L211)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L205)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `string`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L193)

##### final\_reward\_rate\_basis\_points

> **final\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L195)

##### initial\_reward\_rate\_basis\_points

> **initial\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L208)

##### initial\_token\_distribution

> **initial\_token\_distribution**: \[\] \| \[[`InitialTokenDistribution`](#initialtokendistribution)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L217)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L203)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L199)

##### max\_age\_bonus\_percentage

> **max\_age\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L216)

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L226)

##### max\_dissolve\_delay\_bonus\_percentage

> **max\_dissolve\_delay\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L186)

##### max\_dissolve\_delay\_seconds

> **max\_dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L185)

##### max\_icp\_e8s

> **max\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L196)

##### max\_neuron\_age\_seconds\_for\_age\_bonus

> **max\_neuron\_age\_seconds\_for\_age\_bonus**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L206)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L221)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L222)

##### min\_icp\_e8s

> **min\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L225)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L189)

##### min\_participants

> **min\_participants**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L207)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L200)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L190)

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L204)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L197)

##### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L188)

##### neurons\_fund\_participation\_constraints

> **neurons\_fund\_participation\_constraints**: \[\] \| \[[`NeuronsFundParticipationConstraints`](#neuronsfundparticipationconstraints)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L213)

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L187)

##### proposal\_reject\_cost\_e8s

> **proposal\_reject\_cost\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L223)

##### restricted\_countries

> **restricted\_countries**: \[\] \| \[[`Countries`](#countries)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L224)

##### reward\_rate\_transition\_duration\_seconds

> **reward\_rate\_transition\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L218)

##### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L202)

##### swap\_start\_timestamp\_seconds

> **swap\_start\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L201)

##### token\_logo

> **token\_logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L219)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L220)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L194)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L210)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L184)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L209)

***

### SnsUpgrade

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L228)

#### Properties

##### current\_version

> **current\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L230)

##### next\_version

> **next\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L229)

***

### SnsVersion

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L232)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L233)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L237)

##### index\_wasm\_hash

> **index\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L238)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L236)

##### root\_wasm\_hash

> **root\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L234)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L235)

***

### SnsWasm

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L240)

#### Properties

##### canister\_type

> **canister\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L243)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L242)

##### wasm

> **wasm**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L241)

***

### SnsWasmCanisterInitPayload

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L245)

#### Properties

##### access\_controls\_enabled

> **access\_controls\_enabled**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L247)

##### allowed\_principals

> **allowed\_principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L246)

##### sns\_subnet\_ids

> **sns\_subnet\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L248)

***

### SnsWasmError

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L250)

#### Properties

##### message

> **message**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L251)

***

### SwapDistribution

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L253)

#### Properties

##### initial\_swap\_amount\_e8s

> **initial\_swap\_amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L255)

##### total\_e8s

> **total\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L254)

***

### TreasuryDistribution

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:257](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L257)

#### Properties

##### total\_e8s

> **total\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L258)

***

### UpdateAllowedPrincipalsRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L260)

#### Properties

##### added\_principals

> **added\_principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L261)

##### removed\_principals

> **removed\_principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L262)

***

### UpdateAllowedPrincipalsResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L264)

#### Properties

##### update\_allowed\_principals\_result

> **update\_allowed\_principals\_result**: \[\] \| \[[`UpdateAllowedPrincipalsResult`](#updateallowedprincipalsresult)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L265)

***

### UpdateSnsSubnetListRequest

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L270)

#### Properties

##### sns\_subnet\_ids\_to\_add

> **sns\_subnet\_ids\_to\_add**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L271)

##### sns\_subnet\_ids\_to\_remove

> **sns\_subnet\_ids\_to\_remove**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L272)

***

### UpdateSnsSubnetListResponse

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L274)

#### Properties

##### error

> **error**: \[\] \| \[[`SnsWasmError`](#snswasmerror)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L275)

## Type Aliases

### GetDeployedSnsByProposalIdResult

> **GetDeployedSnsByProposalIdResult** = \{ `Error`: [`SnsWasmError`](#snswasmerror); \} \| \{ `DeployedSns`: [`DeployedSns`](#deployedsns); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L73)

***

### InitialTokenDistribution

> **InitialTokenDistribution** = `object`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L107)

#### Properties

##### FractionalDeveloperVotingPower

> **FractionalDeveloperVotingPower**: [`FractionalDeveloperVotingPower`](#fractionaldevelopervotingpower)

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L108)

***

### Result

> **Result** = \{ `Error`: [`SnsWasmError`](#snswasmerror); \} \| \{ `Hash`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L174)

***

### Result\_1

> **Result\_1** = \{ `Ok`: [`Ok`](#ok); \} \| \{ `Error`: [`SnsWasmError`](#snswasmerror); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L175)

***

### UpdateAllowedPrincipalsResult

> **UpdateAllowedPrincipalsResult** = \{ `Error`: [`SnsWasmError`](#snswasmerror); \} \| \{ `AllowedPrincipals`: [`GetAllowedPrincipalsResponse`](#getallowedprincipalsresponse); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L267)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L318)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L319)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
