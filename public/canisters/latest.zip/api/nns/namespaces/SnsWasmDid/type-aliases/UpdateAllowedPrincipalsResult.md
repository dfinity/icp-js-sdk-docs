---
title: UpdateAllowedPrincipalsResult
editUrl: false
next: true
prev: true
---

> **UpdateAllowedPrincipalsResult** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `AllowedPrincipals`: [`GetAllowedPrincipalsResponse`](../interfaces/GetAllowedPrincipalsResponse.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L267)
