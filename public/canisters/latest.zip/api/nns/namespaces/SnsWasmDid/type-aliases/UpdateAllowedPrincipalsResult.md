---
title: UpdateAllowedPrincipalsResult
editUrl: false
next: true
prev: true
---

> **UpdateAllowedPrincipalsResult** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `AllowedPrincipals`: [`GetAllowedPrincipalsResponse`](../interfaces/GetAllowedPrincipalsResponse.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L267)
