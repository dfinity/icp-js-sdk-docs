---
title: GetDeployedSnsByProposalIdResult
editUrl: false
next: true
prev: true
---

> **GetDeployedSnsByProposalIdResult** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `DeployedSns`: [`DeployedSns`](../interfaces/DeployedSns.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L73)
