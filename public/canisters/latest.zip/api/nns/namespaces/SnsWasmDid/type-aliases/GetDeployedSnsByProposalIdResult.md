---
title: GetDeployedSnsByProposalIdResult
editUrl: false
next: true
prev: true
---

> **GetDeployedSnsByProposalIdResult** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `DeployedSns`: [`DeployedSns`](../interfaces/DeployedSns.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L73)
