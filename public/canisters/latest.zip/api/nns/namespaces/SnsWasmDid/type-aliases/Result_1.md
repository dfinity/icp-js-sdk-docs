---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L175)
