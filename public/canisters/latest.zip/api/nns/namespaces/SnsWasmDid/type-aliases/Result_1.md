---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L175)
