---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L175)
