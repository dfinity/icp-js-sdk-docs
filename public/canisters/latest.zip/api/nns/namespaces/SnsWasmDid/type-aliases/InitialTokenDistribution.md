---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

> **InitialTokenDistribution** = `object`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L107)

## Properties

### FractionalDeveloperVotingPower

> **FractionalDeveloperVotingPower**: [`FractionalDeveloperVotingPower`](../interfaces/FractionalDeveloperVotingPower.md)

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L108)
