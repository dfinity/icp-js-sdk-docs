---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

> **InitialTokenDistribution** = `object`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L107)

## Properties

### FractionalDeveloperVotingPower

> **FractionalDeveloperVotingPower**: [`FractionalDeveloperVotingPower`](../interfaces/FractionalDeveloperVotingPower.md)

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L108)
