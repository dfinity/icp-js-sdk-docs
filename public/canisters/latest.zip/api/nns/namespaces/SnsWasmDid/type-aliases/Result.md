---
title: Result
editUrl: false
next: true
prev: true
---

> **Result** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `Hash`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L174)
