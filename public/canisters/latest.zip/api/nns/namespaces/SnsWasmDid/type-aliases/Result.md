---
title: Result
editUrl: false
next: true
prev: true
---

> **Result** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `Hash`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L174)
