---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L319)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
