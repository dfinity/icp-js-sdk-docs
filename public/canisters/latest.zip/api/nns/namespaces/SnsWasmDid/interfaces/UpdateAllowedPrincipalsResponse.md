---
title: UpdateAllowedPrincipalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L264)

## Properties

### update\_allowed\_principals\_result

> **update\_allowed\_principals\_result**: \[\] \| \[[`UpdateAllowedPrincipalsResult`](../type-aliases/UpdateAllowedPrincipalsResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L265)
