---
title: DeployNewSnsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L41)

## Properties

### canisters

> **canisters**: \[\] \| \[[`SnsCanisterIds`](SnsCanisterIds.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L45)

***

### dapp\_canisters\_transfer\_result

> **dapp\_canisters\_transfer\_result**: \[\] \| \[[`DappCanistersTransferResult`](DappCanistersTransferResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L42)

***

### error

> **error**: \[\] \| \[[`SnsWasmError`](SnsWasmError.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L44)

***

### subnet\_id

> **subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L43)
