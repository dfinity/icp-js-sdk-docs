---
title: DeployNewSnsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L41)

## Properties

### canisters

> **canisters**: \[\] \| \[[`SnsCanisterIds`](SnsCanisterIds.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L45)

***

### dapp\_canisters\_transfer\_result

> **dapp\_canisters\_transfer\_result**: \[\] \| \[[`DappCanistersTransferResult`](DappCanistersTransferResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L42)

***

### error

> **error**: \[\] \| \[[`SnsWasmError`](SnsWasmError.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L44)

***

### subnet\_id

> **subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L43)
