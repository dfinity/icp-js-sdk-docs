---
title: CustomProposalCriticality
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L27)

## Properties

### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L28)
