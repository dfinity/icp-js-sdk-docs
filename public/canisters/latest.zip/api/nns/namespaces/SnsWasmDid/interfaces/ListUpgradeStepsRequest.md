---
title: ListUpgradeStepsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L131)

## Properties

### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L132)

***

### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L134)

***

### starting\_at

> **starting\_at**: \[\] \| \[[`SnsVersion`](SnsVersion.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L133)
