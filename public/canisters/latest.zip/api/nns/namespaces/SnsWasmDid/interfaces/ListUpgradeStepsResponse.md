---
title: ListUpgradeStepsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L136)

## Properties

### steps

> **steps**: [`ListUpgradeStep`](ListUpgradeStep.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L137)
