---
title: AddWasmRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L13)

## Properties

### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L14)

***

### skip\_update\_latest\_version

> **skip\_update\_latest\_version**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L16)

***

### wasm

> **wasm**: \[\] \| \[[`SnsWasm`](SnsWasm.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L15)
