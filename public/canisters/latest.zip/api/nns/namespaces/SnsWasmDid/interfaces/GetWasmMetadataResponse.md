---
title: GetWasmMetadataResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L95)

## Properties

### result

> **result**: \[\] \| \[[`Result_1`](../type-aliases/Result_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L96)
