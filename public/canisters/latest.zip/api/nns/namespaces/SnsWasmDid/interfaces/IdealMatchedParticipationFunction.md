---
title: IdealMatchedParticipationFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L104)

## Properties

### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L105)
