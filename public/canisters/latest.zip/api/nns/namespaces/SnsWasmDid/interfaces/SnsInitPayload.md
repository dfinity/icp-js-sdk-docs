---
title: SnsInitPayload
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L183)

## Properties

### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L198)

***

### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](CustomProposalCriticality.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L212)

***

### dapp\_canisters

> **dapp\_canisters**: \[\] \| \[[`DappCanisters`](DappCanisters.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L211)

***

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L205)

***

### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `string`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L193)

***

### final\_reward\_rate\_basis\_points

> **final\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L195)

***

### initial\_reward\_rate\_basis\_points

> **initial\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L208)

***

### initial\_token\_distribution

> **initial\_token\_distribution**: \[\] \| \[[`InitialTokenDistribution`](../type-aliases/InitialTokenDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L217)

***

### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L203)

***

### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L199)

***

### max\_age\_bonus\_percentage

> **max\_age\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L216)

***

### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L226)

***

### max\_dissolve\_delay\_bonus\_percentage

> **max\_dissolve\_delay\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L186)

***

### max\_dissolve\_delay\_seconds

> **max\_dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L185)

***

### max\_icp\_e8s

> **max\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L196)

***

### max\_neuron\_age\_seconds\_for\_age\_bonus

> **max\_neuron\_age\_seconds\_for\_age\_bonus**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L206)

***

### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L221)

***

### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L222)

***

### min\_icp\_e8s

> **min\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L225)

***

### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L189)

***

### min\_participants

> **min\_participants**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L207)

***

### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L200)

***

### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](NeuronBasketConstructionParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L190)

***

### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L204)

***

### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L197)

***

### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L188)

***

### neurons\_fund\_participation\_constraints

> **neurons\_fund\_participation\_constraints**: \[\] \| \[[`NeuronsFundParticipationConstraints`](NeuronsFundParticipationConstraints.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L213)

***

### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L187)

***

### proposal\_reject\_cost\_e8s

> **proposal\_reject\_cost\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L223)

***

### restricted\_countries

> **restricted\_countries**: \[\] \| \[[`Countries`](Countries.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L224)

***

### reward\_rate\_transition\_duration\_seconds

> **reward\_rate\_transition\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L218)

***

### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L202)

***

### swap\_start\_timestamp\_seconds

> **swap\_start\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L201)

***

### token\_logo

> **token\_logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L219)

***

### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L220)

***

### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L194)

***

### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L210)

***

### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L184)

***

### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L209)
