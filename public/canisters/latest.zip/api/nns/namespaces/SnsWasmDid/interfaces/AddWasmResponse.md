---
title: AddWasmResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L18)

## Properties

### result

> **result**: \[\] \| \[[`Result`](../type-aliases/Result.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L19)
