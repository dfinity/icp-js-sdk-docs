---
title: GetDeployedSnsByProposalIdRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L65)

## Properties

### proposal\_id

> **proposal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L66)
