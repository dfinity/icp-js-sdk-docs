---
title: GetDeployedSnsByProposalIdRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L65)

## Properties

### proposal\_id

> **proposal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L66)
