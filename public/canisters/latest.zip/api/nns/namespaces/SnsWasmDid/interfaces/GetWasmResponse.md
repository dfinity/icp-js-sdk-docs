---
title: GetWasmResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L101)

## Properties

### wasm

> **wasm**: \[\] \| \[[`SnsWasm`](SnsWasm.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L102)
