---
title: LinearScalingCoefficient
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L117)

## Properties

### from\_direct\_participation\_icp\_e8s

> **from\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L120)

***

### intercept\_icp\_e8s

> **intercept\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L119)

***

### slope\_denominator

> **slope\_denominator**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L121)

***

### slope\_numerator

> **slope\_numerator**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L118)

***

### to\_direct\_participation\_icp\_e8s

> **to\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L122)
