---
title: NeuronBasketConstructionParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L144)

## Properties

### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L146)

***

### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L145)
