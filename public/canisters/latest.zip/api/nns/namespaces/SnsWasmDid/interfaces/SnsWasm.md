---
title: SnsWasm
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L240)

## Properties

### canister\_type

> **canister\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L243)

***

### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L242)

***

### wasm

> **wasm**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L241)
