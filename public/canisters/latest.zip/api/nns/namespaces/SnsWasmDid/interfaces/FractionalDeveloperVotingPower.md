---
title: FractionalDeveloperVotingPower
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L57)

## Properties

### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](DeveloperDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L59)

***

### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](SwapDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L60)

***

### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`TreasuryDistribution`](TreasuryDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L58)
