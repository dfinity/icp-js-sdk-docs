---
title: ListDeployedSnsesResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L124)

## Properties

### instances

> **instances**: [`DeployedSns`](DeployedSns.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L125)
