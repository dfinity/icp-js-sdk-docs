---
title: ListDeployedSnsesResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L124)

## Properties

### instances

> **instances**: [`DeployedSns`](DeployedSns.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L125)
