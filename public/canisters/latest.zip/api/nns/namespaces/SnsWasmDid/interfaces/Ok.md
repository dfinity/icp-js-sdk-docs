---
title: Ok
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L163)

## Properties

### sections

> **sections**: [`MetadataSection`](MetadataSection.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L164)
