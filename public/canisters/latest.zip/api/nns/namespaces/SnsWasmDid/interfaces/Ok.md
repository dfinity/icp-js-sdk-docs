---
title: Ok
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L163)

## Properties

### sections

> **sections**: [`MetadataSection`](MetadataSection.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L164)
