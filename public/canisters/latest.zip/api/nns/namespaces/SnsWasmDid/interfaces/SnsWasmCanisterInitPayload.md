---
title: SnsWasmCanisterInitPayload
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L245)

## Properties

### access\_controls\_enabled

> **access\_controls\_enabled**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L247)

***

### allowed\_principals

> **allowed\_principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L246)

***

### sns\_subnet\_ids

> **sns\_subnet\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L248)
