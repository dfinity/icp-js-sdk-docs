---
title: SwapDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L253)

## Properties

### initial\_swap\_amount\_e8s

> **initial\_swap\_amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L255)

***

### total\_e8s

> **total\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L254)
