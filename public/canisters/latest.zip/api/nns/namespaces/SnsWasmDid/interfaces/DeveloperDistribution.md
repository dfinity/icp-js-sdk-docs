---
title: DeveloperDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L54)

## Properties

### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](NeuronDistribution.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L55)
