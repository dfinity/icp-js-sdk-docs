---
title: DeveloperDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L54)

## Properties

### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](NeuronDistribution.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L55)
