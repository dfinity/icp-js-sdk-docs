---
title: DeveloperDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L54)

## Properties

### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](NeuronDistribution.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L55)
