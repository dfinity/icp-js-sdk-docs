---
title: DappCanistersTransferResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L33)

## Properties

### nns\_controlled\_dapp\_canisters

> **nns\_controlled\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L35)

***

### restored\_dapp\_canisters

> **restored\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L34)

***

### sns\_controlled\_dapp\_canisters

> **sns\_controlled\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L36)
