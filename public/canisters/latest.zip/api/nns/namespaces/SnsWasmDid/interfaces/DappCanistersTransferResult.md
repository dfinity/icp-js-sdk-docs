---
title: DappCanistersTransferResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L33)

## Properties

### nns\_controlled\_dapp\_canisters

> **nns\_controlled\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L35)

***

### restored\_dapp\_canisters

> **restored\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L34)

***

### sns\_controlled\_dapp\_canisters

> **sns\_controlled\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L36)
