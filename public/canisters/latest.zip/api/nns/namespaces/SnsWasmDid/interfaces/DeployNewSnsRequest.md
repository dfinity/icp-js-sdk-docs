---
title: DeployNewSnsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L38)

## Properties

### sns\_init\_payload

> **sns\_init\_payload**: \[\] \| \[[`SnsInitPayload`](SnsInitPayload.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L39)
