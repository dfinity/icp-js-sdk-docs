---
title: DeployNewSnsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L38)

## Properties

### sns\_init\_payload

> **sns\_init\_payload**: \[\] \| \[[`SnsInitPayload`](SnsInitPayload.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L39)
