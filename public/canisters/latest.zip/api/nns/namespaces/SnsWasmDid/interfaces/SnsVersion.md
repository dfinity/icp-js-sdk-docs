---
title: SnsVersion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L232)

## Properties

### archive\_wasm\_hash

> **archive\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L233)

***

### governance\_wasm\_hash

> **governance\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L237)

***

### index\_wasm\_hash

> **index\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L238)

***

### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L236)

***

### root\_wasm\_hash

> **root\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L234)

***

### swap\_wasm\_hash

> **swap\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L235)
