---
title: PrettySnsVersion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L166)

## Properties

### archive\_wasm\_hash

> **archive\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L167)

***

### governance\_wasm\_hash

> **governance\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L171)

***

### index\_wasm\_hash

> **index\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L172)

***

### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L170)

***

### root\_wasm\_hash

> **root\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L168)

***

### swap\_wasm\_hash

> **swap\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L169)
