---
title: GetDeployedSnsByProposalIdResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L68)

## Properties

### get\_deployed\_sns\_by\_proposal\_id\_result

> **get\_deployed\_sns\_by\_proposal\_id\_result**: \[\] \| \[[`GetDeployedSnsByProposalIdResult`](../type-aliases/GetDeployedSnsByProposalIdResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L69)
