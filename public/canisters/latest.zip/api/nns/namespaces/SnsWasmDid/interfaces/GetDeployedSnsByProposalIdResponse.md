---
title: GetDeployedSnsByProposalIdResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L68)

## Properties

### get\_deployed\_sns\_by\_proposal\_id\_result

> **get\_deployed\_sns\_by\_proposal\_id\_result**: \[\] \| \[[`GetDeployedSnsByProposalIdResult`](../type-aliases/GetDeployedSnsByProposalIdResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L69)
