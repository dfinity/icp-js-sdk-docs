---
title: GetDeployedSnsByProposalIdResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L68)

## Properties

### get\_deployed\_sns\_by\_proposal\_id\_result

> **get\_deployed\_sns\_by\_proposal\_id\_result**: \[\] \| \[[`GetDeployedSnsByProposalIdResult`](../type-aliases/GetDeployedSnsByProposalIdResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L69)
