---
title: UpdateSnsSubnetListRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L270)

## Properties

### sns\_subnet\_ids\_to\_add

> **sns\_subnet\_ids\_to\_add**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L271)

***

### sns\_subnet\_ids\_to\_remove

> **sns\_subnet\_ids\_to\_remove**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L272)
