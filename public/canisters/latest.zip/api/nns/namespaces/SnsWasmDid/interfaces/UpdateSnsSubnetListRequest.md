---
title: UpdateSnsSubnetListRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L270)

## Properties

### sns\_subnet\_ids\_to\_add

> **sns\_subnet\_ids\_to\_add**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L271)

***

### sns\_subnet\_ids\_to\_remove

> **sns\_subnet\_ids\_to\_remove**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L272)
