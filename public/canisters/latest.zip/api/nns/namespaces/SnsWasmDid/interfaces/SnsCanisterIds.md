---
title: SnsCanisterIds
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L176)

## Properties

### governance

> **governance**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L181)

***

### index

> **index**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L180)

***

### ledger

> **ledger**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L179)

***

### root

> **root**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L177)

***

### swap

> **swap**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L178)
