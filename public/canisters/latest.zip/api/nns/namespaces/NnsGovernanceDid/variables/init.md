---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1467](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1467)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
