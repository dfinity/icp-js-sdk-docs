---
title: ListNeurons
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L552)

Parameters of the list_neurons method.

## Properties

### include\_empty\_neurons\_readable\_by\_caller

> **include\_empty\_neurons\_readable\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L568)

Only has an effect when include_neurons_readable_by_caller.

***

### include\_neurons\_readable\_by\_caller

> **include\_neurons\_readable\_by\_caller**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L570)

***

### include\_public\_neurons\_in\_full\_neurons

> **include\_public\_neurons\_in\_full\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L559)

When a public neuron is a member of the result set, include it in the
full_neurons field (of ListNeuronsResponse). This does not affect which
neurons are part of the result set.

***

### neuron\_ids

> **neuron\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:563](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L563)

These fields select neurons to be in the result set.

***

### neuron\_subaccounts

> **neuron\_subaccounts**: \[\] \| \[[`NeuronSubaccount`](NeuronSubaccount.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L569)

***

### page\_number

> **page\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L564)

***

### page\_size

> **page\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L553)
