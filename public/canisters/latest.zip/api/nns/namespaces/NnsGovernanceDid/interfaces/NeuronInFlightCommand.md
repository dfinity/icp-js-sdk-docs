---
title: NeuronInFlightCommand
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:824](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L824)

## Properties

### command

> **command**: \[\] \| \[[`Command_2`](../type-aliases/Command_2.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:825](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L825)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:826](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L826)
