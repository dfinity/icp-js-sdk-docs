---
title: MaturityDisbursement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:661](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L661)

## Properties

### account\_identifier\_to\_disburse\_to

> **account\_identifier\_to\_disburse\_to**: \[\] \| \[[`AccountIdentifier`](AccountIdentifier.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L662)

***

### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:665](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L665)

***

### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:664](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L664)

***

### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L666)

***

### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:663](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L663)
