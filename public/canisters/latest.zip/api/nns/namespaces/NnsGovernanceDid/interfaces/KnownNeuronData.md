---
title: KnownNeuronData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L491)

## Properties

### committed\_topics

> **committed\_topics**: \[\] \| \[(\[\] \| \[[`TopicToFollow`](../type-aliases/TopicToFollow.md)\])[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L499)

Topics that the known neuron is committed to always vote on.
Note regarding the type: the first `opt` makes it so that the field can be renamed/deprecated
in the future, and the second `opt` makes it so that an older client not recognizing a new
variant can still get the rest of the `vec`.

***

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L500)

***

### links

> **links**: \[\] \| \[`string`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L504)

Links related to the known neuron. Can be links to social URLs (OpenChat, X, etc.), or a homepage.

***

### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L492)
