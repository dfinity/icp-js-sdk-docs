---
title: SetOpenTimeWindowRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1208](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1208)

## Properties

### open\_time\_window

> **open\_time\_window**: \[\] \| \[[`TimeWindow`](TimeWindow.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1209](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1209)
