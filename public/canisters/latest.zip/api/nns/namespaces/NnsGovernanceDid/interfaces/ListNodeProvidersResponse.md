---
title: ListNodeProvidersResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L557)

## Properties

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:558](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L558)
