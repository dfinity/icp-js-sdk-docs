---
title: Tally
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1253](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1253)

## Properties

### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1254](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1254)

***

### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1257](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1257)

***

### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1256](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1256)

***

### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1255](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1255)
