---
title: NeuronVote
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:941](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L941)

## Properties

### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:946](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L946)

***

### vote

> **vote**: \[\] \| \[[`Vote`](../type-aliases/Vote.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:945](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L945)

The vote of the neuron on the specific proposal id.
