---
title: OpenSnsTokenSwap
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:971](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L971)

## Properties

### community\_fund\_investment\_e8s

> **community\_fund\_investment\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:972](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L972)

***

### params

> **params**: \[\] \| \[[`Params`](Params.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:974](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L974)

***

### target\_swap\_canister\_id

> **target\_swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:973](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L973)
