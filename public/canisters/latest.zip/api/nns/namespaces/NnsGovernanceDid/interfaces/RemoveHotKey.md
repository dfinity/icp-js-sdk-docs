---
title: RemoveHotKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1089](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1089)

## Properties

### hot\_key\_to\_remove

> **hot\_key\_to\_remove**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1090](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1090)
