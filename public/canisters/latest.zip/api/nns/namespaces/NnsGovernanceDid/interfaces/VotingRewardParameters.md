---
title: VotingRewardParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1344](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1344)

## Properties

### final\_reward\_rate

> **final\_reward\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1347](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1347)

***

### initial\_reward\_rate

> **initial\_reward\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1346](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1346)

***

### reward\_rate\_transition\_duration

> **reward\_rate\_transition\_duration**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1345](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1345)
