---
title: VotingRewardParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1384](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1384)

## Properties

### final\_reward\_rate

> **final\_reward\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1387](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1387)

***

### initial\_reward\_rate

> **initial\_reward\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1386](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1386)

***

### reward\_rate\_transition\_duration

> **reward\_rate\_transition\_duration**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1385](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1385)
