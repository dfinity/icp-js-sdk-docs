---
title: SetDefaultFollowees
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1198](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1198)

## Properties

### default\_followees

> **default\_followees**: \[`number`, [`Followees`](Followees.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1199](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1199)
