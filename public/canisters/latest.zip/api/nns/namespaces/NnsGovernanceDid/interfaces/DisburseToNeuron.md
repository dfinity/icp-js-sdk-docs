---
title: DisburseToNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L228)

## Properties

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L231)

***

### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L229)

***

### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L230)

***

### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L232)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L233)
