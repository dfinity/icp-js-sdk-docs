---
title: IncreaseDissolveDelay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L465)

## Properties

### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L466)
