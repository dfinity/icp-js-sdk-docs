---
title: IncreaseDissolveDelay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L425)

## Properties

### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L426)
