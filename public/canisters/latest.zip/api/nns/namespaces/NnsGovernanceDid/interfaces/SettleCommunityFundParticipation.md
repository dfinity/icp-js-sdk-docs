---
title: SettleCommunityFundParticipation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1178](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1178)

## Properties

### open\_sns\_token\_swap\_proposal\_id

> **open\_sns\_token\_swap\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1180](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1180)

***

### result

> **result**: \[\] \| \[[`Result_8`](../type-aliases/Result_8.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1179](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1179)
