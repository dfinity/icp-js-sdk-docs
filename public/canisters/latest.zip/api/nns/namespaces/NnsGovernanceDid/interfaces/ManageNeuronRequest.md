---
title: ManageNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:637](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L637)

Parameters of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`ManageNeuronCommandRequest`](../type-aliases/ManageNeuronCommandRequest.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L645)

What operation to perform on the neuron.

***

### id

> **id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L641)

Deprecated. Use neuron_id_or_subaccount instead.

***

### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:649](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L649)

Which neuron to operate on.
