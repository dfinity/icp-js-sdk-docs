---
title: ManageNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L677)

Parameters of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`ManageNeuronCommandRequest`](../type-aliases/ManageNeuronCommandRequest.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L685)

What operation to perform on the neuron.

***

### id

> **id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:681](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L681)

Deprecated. Use neuron_id_or_subaccount instead.

***

### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L689)

Which neuron to operate on.
