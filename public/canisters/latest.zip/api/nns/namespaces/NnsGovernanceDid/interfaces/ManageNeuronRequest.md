---
title: ManageNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L677)

Parameters of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`ManageNeuronCommandRequest`](../type-aliases/ManageNeuronCommandRequest.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L685)

What operation to perform on the neuron.

***

### id

> **id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:681](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L681)

Deprecated. Use neuron_id_or_subaccount instead.

***

### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L689)

Which neuron to operate on.
