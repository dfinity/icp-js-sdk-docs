---
title: Governance
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L312)

## Properties

### cached\_daily\_maturity\_modulation\_basis\_points

> **cached\_daily\_maturity\_modulation\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L320)

***

### default\_followees

> **default\_followees**: \[`number`, [`Followees`](Followees.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L313)

***

### economics

> **economics**: \[\] \| \[[`NetworkEconomics`](NetworkEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L321)

***

### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L331)

***

### in\_flight\_commands

> **in\_flight\_commands**: \[`bigint`, [`NeuronInFlightCommand`](NeuronInFlightCommand.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L329)

***

### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](RewardEvent.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L324)

***

### maturity\_modulation\_last\_updated\_at\_timestamp\_seconds

> **maturity\_modulation\_last\_updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L315)

***

### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](GovernanceCachedMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L317)

***

### most\_recent\_monthly\_node\_provider\_rewards

> **most\_recent\_monthly\_node\_provider\_rewards**: \[\] \| \[[`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L314)

***

### neuron\_management\_voting\_period\_seconds

> **neuron\_management\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L318)

***

### neurons

> **neurons**: \[`bigint`, [`Neuron`](Neuron.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L330)

***

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L319)

***

### proposals

> **proposals**: \[`bigint`, [`ProposalData`](ProposalData.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L327)

***

### restore\_aging\_summary

> **restore\_aging\_summary**: \[\] \| \[[`RestoreAgingSummary`](RestoreAgingSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L322)

***

### short\_voting\_period\_seconds

> **short\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L326)

***

### spawning\_neurons

> **spawning\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L323)

***

### to\_claim\_transfers

> **to\_claim\_transfers**: [`NeuronStakeTransfer`](NeuronStakeTransfer.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L325)

***

### wait\_for\_quiet\_threshold\_seconds

> **wait\_for\_quiet\_threshold\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L316)

***

### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](XdrConversionRate.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L328)
