---
title: SettleNeuronsFundParticipationResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1186](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1186)

## Properties

### result

> **result**: \[\] \| \[[`Result_10`](../type-aliases/Result_10.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1187](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1187)
