---
title: SettleNeuronsFundParticipationResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1226](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1226)

## Properties

### result

> **result**: \[\] \| \[[`Result_10`](../type-aliases/Result_10.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1227](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1227)
