---
title: SettleNeuronsFundParticipationResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1186](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1186)

## Properties

### result

> **result**: \[\] \| \[[`Result_10`](../type-aliases/Result_10.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1187](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1187)
