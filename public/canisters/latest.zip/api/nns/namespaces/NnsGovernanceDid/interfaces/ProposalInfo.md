---
title: ProposalInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1058](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1058)

## Properties

### ballots

> **ballots**: \[`bigint`, [`Ballot`](Ballot.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1063](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1063)

***

### deadline\_timestamp\_seconds

> **deadline\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1066](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1066)

***

### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1073](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1073)

***

### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](DerivedProposalInformation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1069](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1069)

***

### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1076](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1076)

***

### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1067](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1067)

***

### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](GovernanceError.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1062](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1062)

***

### id

> **id**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1059](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1059)

***

### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](Tally.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1070](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1070)

***

### proposal

> **proposal**: \[\] \| \[[`Proposal`](Proposal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1074](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1074)

***

### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1064](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1064)

***

### proposer

> **proposer**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1075](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1075)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1068](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1068)

***

### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1065](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1065)

***

### reward\_status

> **reward\_status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1072](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1072)

***

### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1060](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1060)

***

### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1061](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1061)

***

### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1071](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1071)
