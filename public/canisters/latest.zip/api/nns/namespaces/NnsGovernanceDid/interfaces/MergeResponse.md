---
title: MergeResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:678](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L678)

## Properties

### source\_neuron

> **source\_neuron**: \[\] \| \[[`Neuron`](Neuron.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L680)

***

### source\_neuron\_info

> **source\_neuron\_info**: \[\] \| \[[`NeuronInfo`](NeuronInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:682](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L682)

***

### target\_neuron

> **target\_neuron**: \[\] \| \[[`Neuron`](Neuron.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:679](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L679)

***

### target\_neuron\_info

> **target\_neuron\_info**: \[\] \| \[[`NeuronInfo`](NeuronInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:681](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L681)
