---
title: MergeResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:678](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L678)

## Properties

### source\_neuron

> **source\_neuron**: \[\] \| \[[`Neuron`](Neuron.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L680)

***

### source\_neuron\_info

> **source\_neuron\_info**: \[\] \| \[[`NeuronInfo`](NeuronInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:682](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L682)

***

### target\_neuron

> **target\_neuron**: \[\] \| \[[`Neuron`](Neuron.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:679](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L679)

***

### target\_neuron\_info

> **target\_neuron\_info**: \[\] \| \[[`NeuronInfo`](NeuronInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:681](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L681)
