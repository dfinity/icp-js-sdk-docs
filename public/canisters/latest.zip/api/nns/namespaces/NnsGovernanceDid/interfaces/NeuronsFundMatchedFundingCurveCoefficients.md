---
title: NeuronsFundMatchedFundingCurveCoefficients
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:966](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L966)

## Properties

### contribution\_threshold\_xdr

> **contribution\_threshold\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:967](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L967)

***

### full\_participation\_milestone\_xdr

> **full\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:969](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L969)

***

### one\_third\_participation\_milestone\_xdr

> **one\_third\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:968](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L968)
