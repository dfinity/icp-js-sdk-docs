---
title: NeuronIndexData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:868](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L868)

## Properties

### neurons

> **neurons**: [`NeuronInfo`](NeuronInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L869)
