---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L168)

## Properties

### operation

> **operation**: \[\] \| \[[`Operation`](../type-aliases/Operation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L169)
