---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1396](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1396)

## Properties

### claim\_gtc\_neurons

> **claim\_gtc\_neurons**: `ActorMethod`\<\[`Principal`, [`NeuronId`](NeuronId.md)[]\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1397](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1397)

***

### claim\_or\_refresh\_neuron\_from\_account

> **claim\_or\_refresh\_neuron\_from\_account**: `ActorMethod`\<\[[`ClaimOrRefreshNeuronFromAccount`](ClaimOrRefreshNeuronFromAccount.md)\], [`ClaimOrRefreshNeuronFromAccountResponse`](ClaimOrRefreshNeuronFromAccountResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1398](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1398)

***

### create\_neuron

> **create\_neuron**: `ActorMethod`\<\[[`CreateNeuronRequest`](CreateNeuronRequest.md)\], [`CreateNeuronResponse`](../type-aliases/CreateNeuronResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1402](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1402)

***

### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1403](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1403)

***

### get\_full\_neuron

> **get\_full\_neuron**: `ActorMethod`\<\[`bigint`\], [`Result_2`](../type-aliases/Result_2.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1404](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1404)

***

### get\_full\_neuron\_by\_id\_or\_subaccount

> **get\_full\_neuron\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\], [`Result_2`](../type-aliases/Result_2.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1405](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1405)

***

### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](RewardEvent.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1409](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1409)

***

### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[\], [`Result_3`](../type-aliases/Result_3.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1410](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1410)

***

### get\_monthly\_node\_provider\_rewards

> **get\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], [`Result_4`](../type-aliases/Result_4.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1411](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1411)

***

### get\_most\_recent\_monthly\_node\_provider\_rewards

> **get\_most\_recent\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], \[\] \| \[[`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1412](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1412)

***

### get\_network\_economics\_parameters

> **get\_network\_economics\_parameters**: `ActorMethod`\<\[\], [`NetworkEconomics`](NetworkEconomics.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1416](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1416)

***

### get\_neuron\_ids

> **get\_neuron\_ids**: `ActorMethod`\<\[\], `BigUint64Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1417](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1417)

***

### get\_neuron\_index

> **get\_neuron\_index**: `ActorMethod`\<\[[`GetNeuronIndexRequest`](GetNeuronIndexRequest.md)\], [`GetNeuronIndexResult`](../type-aliases/GetNeuronIndexResult.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1418](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1418)

***

### get\_neuron\_info

> **get\_neuron\_info**: `ActorMethod`\<\[`bigint`\], [`Result_5`](../type-aliases/Result_5.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1419](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1419)

***

### get\_neuron\_info\_by\_id\_or\_subaccount

> **get\_neuron\_info\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\], [`Result_5`](../type-aliases/Result_5.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1420](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1420)

***

### get\_neurons\_fund\_audit\_info

> **get\_neurons\_fund\_audit\_info**: `ActorMethod`\<\[[`GetNeuronsFundAuditInfoRequest`](GetNeuronsFundAuditInfoRequest.md)\], [`GetNeuronsFundAuditInfoResponse`](GetNeuronsFundAuditInfoResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1424](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1424)

***

### get\_node\_provider\_by\_caller

> **get\_node\_provider\_by\_caller**: `ActorMethod`\<\[`null`\], [`Result_7`](../type-aliases/Result_7.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1428](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1428)

***

### get\_pending\_proposals

> **get\_pending\_proposals**: `ActorMethod`\<\[\[\] \| \[[`GetPendingProposalsRequest`](GetPendingProposalsRequest.md)\]\], [`ProposalInfo`](ProposalInfo.md)[]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1429](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1429)

***

### get\_proposal\_info

> **get\_proposal\_info**: `ActorMethod`\<\[`bigint`\], \[\] \| \[[`ProposalInfo`](ProposalInfo.md)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1433](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1433)

***

### get\_restore\_aging\_summary

> **get\_restore\_aging\_summary**: `ActorMethod`\<\[\], [`RestoreAgingSummary`](RestoreAgingSummary.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1434](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1434)

***

### list\_known\_neurons

> **list\_known\_neurons**: `ActorMethod`\<\[\], [`ListKnownNeuronsResponse`](ListKnownNeuronsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1435](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1435)

***

### list\_neuron\_votes

> **list\_neuron\_votes**: `ActorMethod`\<\[[`ListNeuronVotesRequest`](ListNeuronVotesRequest.md)\], [`ListNeuronVotesResponse`](../type-aliases/ListNeuronVotesResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1436](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1436)

***

### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](ListNeurons.md)\], [`ListNeuronsResponse`](ListNeuronsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1440](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1440)

***

### list\_node\_provider\_rewards

> **list\_node\_provider\_rewards**: `ActorMethod`\<\[[`ListNodeProviderRewardsRequest`](ListNodeProviderRewardsRequest.md)\], [`ListNodeProviderRewardsResponse`](ListNodeProviderRewardsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1441](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1441)

***

### list\_node\_providers

> **list\_node\_providers**: `ActorMethod`\<\[\], [`ListNodeProvidersResponse`](ListNodeProvidersResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1445](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1445)

***

### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposalInfoRequest`](ListProposalInfoRequest.md)\], [`ListProposalInfoResponse`](ListProposalInfoResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1446](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1446)

***

### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](ManageNeuronRequest.md)\], [`ManageNeuronResponse`](ManageNeuronResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1450](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1450)

***

### settle\_community\_fund\_participation

> **settle\_community\_fund\_participation**: `ActorMethod`\<\[[`SettleCommunityFundParticipation`](SettleCommunityFundParticipation.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1451](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1451)

***

### settle\_neurons\_fund\_participation

> **settle\_neurons\_fund\_participation**: `ActorMethod`\<\[[`SettleNeuronsFundParticipationRequest`](SettleNeuronsFundParticipationRequest.md)\], [`SettleNeuronsFundParticipationResponse`](SettleNeuronsFundParticipationResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1455](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1455)

***

### simulate\_manage\_neuron

> **simulate\_manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](ManageNeuronRequest.md)\], [`ManageNeuronResponse`](ManageNeuronResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1459](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1459)

***

### transfer\_gtc\_neuron

> **transfer\_gtc\_neuron**: `ActorMethod`\<\[[`NeuronId`](NeuronId.md), [`NeuronId`](NeuronId.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1463](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1463)

***

### update\_node\_provider

> **update\_node\_provider**: `ActorMethod`\<\[[`UpdateNodeProvider`](UpdateNodeProvider.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1464](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1464)
