---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1356](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1356)

## Properties

### claim\_gtc\_neurons

> **claim\_gtc\_neurons**: `ActorMethod`\<\[`Principal`, [`NeuronId`](NeuronId.md)[]\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1357](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1357)

***

### claim\_or\_refresh\_neuron\_from\_account

> **claim\_or\_refresh\_neuron\_from\_account**: `ActorMethod`\<\[[`ClaimOrRefreshNeuronFromAccount`](ClaimOrRefreshNeuronFromAccount.md)\], [`ClaimOrRefreshNeuronFromAccountResponse`](ClaimOrRefreshNeuronFromAccountResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1358](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1358)

***

### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1362](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1362)

***

### get\_full\_neuron

> **get\_full\_neuron**: `ActorMethod`\<\[`bigint`\], [`Result_2`](../type-aliases/Result_2.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1363](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1363)

***

### get\_full\_neuron\_by\_id\_or\_subaccount

> **get\_full\_neuron\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\], [`Result_2`](../type-aliases/Result_2.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1364](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1364)

***

### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](RewardEvent.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1368](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1368)

***

### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[\], [`Result_3`](../type-aliases/Result_3.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1369](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1369)

***

### get\_monthly\_node\_provider\_rewards

> **get\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], [`Result_4`](../type-aliases/Result_4.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1370](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1370)

***

### get\_most\_recent\_monthly\_node\_provider\_rewards

> **get\_most\_recent\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], \[\] \| \[[`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1371](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1371)

***

### get\_network\_economics\_parameters

> **get\_network\_economics\_parameters**: `ActorMethod`\<\[\], [`NetworkEconomics`](NetworkEconomics.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1375](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1375)

***

### get\_neuron\_ids

> **get\_neuron\_ids**: `ActorMethod`\<\[\], `BigUint64Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1376](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1376)

***

### get\_neuron\_index

> **get\_neuron\_index**: `ActorMethod`\<\[[`GetNeuronIndexRequest`](GetNeuronIndexRequest.md)\], [`GetNeuronIndexResult`](../type-aliases/GetNeuronIndexResult.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1377](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1377)

***

### get\_neuron\_info

> **get\_neuron\_info**: `ActorMethod`\<\[`bigint`\], [`Result_5`](../type-aliases/Result_5.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1378](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1378)

***

### get\_neuron\_info\_by\_id\_or\_subaccount

> **get\_neuron\_info\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\], [`Result_5`](../type-aliases/Result_5.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1379](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1379)

***

### get\_neurons\_fund\_audit\_info

> **get\_neurons\_fund\_audit\_info**: `ActorMethod`\<\[[`GetNeuronsFundAuditInfoRequest`](GetNeuronsFundAuditInfoRequest.md)\], [`GetNeuronsFundAuditInfoResponse`](GetNeuronsFundAuditInfoResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1383](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1383)

***

### get\_node\_provider\_by\_caller

> **get\_node\_provider\_by\_caller**: `ActorMethod`\<\[`null`\], [`Result_7`](../type-aliases/Result_7.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1387](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1387)

***

### get\_pending\_proposals

> **get\_pending\_proposals**: `ActorMethod`\<\[\[\] \| \[[`GetPendingProposalsRequest`](GetPendingProposalsRequest.md)\]\], [`ProposalInfo`](ProposalInfo.md)[]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1388](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1388)

***

### get\_proposal\_info

> **get\_proposal\_info**: `ActorMethod`\<\[`bigint`\], \[\] \| \[[`ProposalInfo`](ProposalInfo.md)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1392](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1392)

***

### get\_restore\_aging\_summary

> **get\_restore\_aging\_summary**: `ActorMethod`\<\[\], [`RestoreAgingSummary`](RestoreAgingSummary.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1393](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1393)

***

### list\_known\_neurons

> **list\_known\_neurons**: `ActorMethod`\<\[\], [`ListKnownNeuronsResponse`](ListKnownNeuronsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1394](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1394)

***

### list\_neuron\_votes

> **list\_neuron\_votes**: `ActorMethod`\<\[[`ListNeuronVotesRequest`](ListNeuronVotesRequest.md)\], [`ListNeuronVotesResponse`](../type-aliases/ListNeuronVotesResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1395](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1395)

***

### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](ListNeurons.md)\], [`ListNeuronsResponse`](ListNeuronsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1399](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1399)

***

### list\_node\_provider\_rewards

> **list\_node\_provider\_rewards**: `ActorMethod`\<\[[`ListNodeProviderRewardsRequest`](ListNodeProviderRewardsRequest.md)\], [`ListNodeProviderRewardsResponse`](ListNodeProviderRewardsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1400](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1400)

***

### list\_node\_providers

> **list\_node\_providers**: `ActorMethod`\<\[\], [`ListNodeProvidersResponse`](ListNodeProvidersResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1404](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1404)

***

### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposalInfoRequest`](ListProposalInfoRequest.md)\], [`ListProposalInfoResponse`](ListProposalInfoResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1405](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1405)

***

### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](ManageNeuronRequest.md)\], [`ManageNeuronResponse`](ManageNeuronResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1409](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1409)

***

### settle\_community\_fund\_participation

> **settle\_community\_fund\_participation**: `ActorMethod`\<\[[`SettleCommunityFundParticipation`](SettleCommunityFundParticipation.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1410](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1410)

***

### settle\_neurons\_fund\_participation

> **settle\_neurons\_fund\_participation**: `ActorMethod`\<\[[`SettleNeuronsFundParticipationRequest`](SettleNeuronsFundParticipationRequest.md)\], [`SettleNeuronsFundParticipationResponse`](SettleNeuronsFundParticipationResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1414](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1414)

***

### simulate\_manage\_neuron

> **simulate\_manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](ManageNeuronRequest.md)\], [`ManageNeuronResponse`](ManageNeuronResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1418](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1418)

***

### transfer\_gtc\_neuron

> **transfer\_gtc\_neuron**: `ActorMethod`\<\[[`NeuronId`](NeuronId.md), [`NeuronId`](NeuronId.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1422](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1422)

***

### update\_node\_provider

> **update\_node\_provider**: `ActorMethod`\<\[[`UpdateNodeProvider`](UpdateNodeProvider.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1423](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1423)
