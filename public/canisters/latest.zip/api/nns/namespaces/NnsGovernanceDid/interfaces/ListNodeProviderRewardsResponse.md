---
title: ListNodeProviderRewardsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:594](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L594)

## Properties

### rewards

> **rewards**: [`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:595](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L595)
