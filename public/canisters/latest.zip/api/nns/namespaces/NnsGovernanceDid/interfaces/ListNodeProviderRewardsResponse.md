---
title: ListNodeProviderRewardsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L554)

## Properties

### rewards

> **rewards**: [`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L555)
