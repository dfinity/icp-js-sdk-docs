---
title: GovernanceError
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L423)

## Properties

### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L424)

***

### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L425)
