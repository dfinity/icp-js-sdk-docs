---
title: BlessAlternativeGuestOsVersion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L66)

Declares an approved set of alternative replica virtual machine software for
disaster recovery purposes.

## Properties

### base\_guest\_launch\_measurements

> **base\_guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurements`](GuestLaunchMeasurements.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L83)

The version being replaced by this (alternative version) must match this
field (or one of the possibilities therein).

(Here, we refer to the version being replaced as the "base" version.)

***

### chip\_ids

> **chip\_ids**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L76)

AMD Secure Processor chip IDs that are allowed to run this software.
Each chip ID must be exactly 64 bytes.

***

### rootfs\_hash

> **rootfs\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L71)

Hexadecimal fingerprint of the recovery rootfs.
Must contain only hexadecimal characters (0-9, A-F, a-f).
