---
title: ListNeuronsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L575)

Output of the list_neurons method.

## Properties

### full\_neurons

> **full\_neurons**: [`Neuron`](Neuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:588](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L588)

If the caller has the necessary special privileges (or the neuron is
public, and the request sets include_public_neurons_in_full_neurons to
true), then all the information about the neurons in the result set is made
available here.

***

### neuron\_infos

> **neuron\_infos**: \[`bigint`, [`NeuronInfo`](NeuronInfo.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L581)

Per the NeuronInfo type, this is a redacted view of the neurons in the
result set consisting of information that require no special privileges to
view.

***

### total\_pages\_available

> **total\_pages\_available**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:589](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L589)
