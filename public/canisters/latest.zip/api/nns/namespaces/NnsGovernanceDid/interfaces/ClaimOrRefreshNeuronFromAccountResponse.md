---
title: ClaimOrRefreshNeuronFromAccountResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L125)

## Properties

### result

> **result**: \[\] \| \[[`Result_1`](../type-aliases/Result_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L126)
