---
title: SwapBackgroundInformation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1252](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1252)

## Properties

### dapp\_canister\_summaries

> **dapp\_canister\_summaries**: [`CanisterSummary`](CanisterSummary.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1260](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1260)

***

### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1254](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1254)

***

### governance\_canister\_summary

> **governance\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1258](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1258)

***

### ledger\_archive\_canister\_summaries

> **ledger\_archive\_canister\_summaries**: [`CanisterSummary`](CanisterSummary.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1255](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1255)

***

### ledger\_canister\_summary

> **ledger\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1256](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1256)

***

### ledger\_index\_canister\_summary

> **ledger\_index\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1253](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1253)

***

### root\_canister\_summary

> **root\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1259](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1259)

***

### swap\_canister\_summary

> **swap\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1257](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1257)
