---
title: MergeMaturityResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L674)

## Properties

### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:675](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L675)

***

### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L676)
