---
title: NeuronDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:811](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L811)

## Properties

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:812](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L812)

***

### dissolve\_delay

> **dissolve\_delay**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:813](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L813)

***

### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:814](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L814)

***

### stake

> **stake**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:816](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L816)

***

### vesting\_period

> **vesting\_period**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:815](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L815)
