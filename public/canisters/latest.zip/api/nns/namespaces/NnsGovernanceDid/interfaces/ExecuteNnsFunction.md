---
title: ExecuteNnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L281)

## Properties

### nns\_function

> **nns\_function**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L282)

***

### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L283)
