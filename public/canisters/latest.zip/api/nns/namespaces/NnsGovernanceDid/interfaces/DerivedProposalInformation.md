---
title: DerivedProposalInformation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L247)

## Properties

### swap\_background\_information

> **swap\_background\_information**: \[\] \| \[[`SwapBackgroundInformation`](SwapBackgroundInformation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L248)
