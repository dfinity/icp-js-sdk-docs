---
title: DerivedProposalInformation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L247)

## Properties

### swap\_background\_information

> **swap\_background\_information**: \[\] \| \[[`SwapBackgroundInformation`](SwapBackgroundInformation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L248)
