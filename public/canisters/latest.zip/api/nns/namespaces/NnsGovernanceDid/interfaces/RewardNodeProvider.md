---
title: RewardNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1129](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1129)

## Properties

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1132](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1132)

***

### node\_provider

> **node\_provider**: \[\] \| \[[`NodeProvider`](NodeProvider.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1130](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1130)

***

### reward\_mode

> **reward\_mode**: \[\] \| \[[`RewardMode`](../type-aliases/RewardMode.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1131](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1131)
