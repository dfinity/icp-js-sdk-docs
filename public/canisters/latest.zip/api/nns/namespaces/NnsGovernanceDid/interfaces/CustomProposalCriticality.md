---
title: CustomProposalCriticality
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L189)

## Properties

### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: \[\] \| \[`BigUint64Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L190)
