---
title: NeuronBasketConstructionParameters_1
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:807](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L807)

## Properties

### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:809](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L809)

***

### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:808](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L808)
