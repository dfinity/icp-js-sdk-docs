---
title: NeuronBasketConstructionParameters_1
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:847](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L847)

## Properties

### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:849](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L849)

***

### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:848](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L848)
