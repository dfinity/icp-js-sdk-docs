---
title: NeuronBasketConstructionParameters_1
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:807](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L807)

## Properties

### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:809](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L809)

***

### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:808](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L808)
