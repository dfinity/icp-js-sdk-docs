---
title: GuestLaunchMeasurements
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L416)

## Properties

### guest\_launch\_measurements

> **guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurement`](GuestLaunchMeasurement.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L417)
