---
title: GuestLaunchMeasurements
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L416)

## Properties

### guest\_launch\_measurements

> **guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurement`](GuestLaunchMeasurement.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L417)
