---
title: CreateServiceNervousSystem
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L177)

## Properties

### dapp\_canisters

> **dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L185)

***

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L184)

***

### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L180)

***

### governance\_parameters

> **governance\_parameters**: \[\] \| \[[`GovernanceParameters`](GovernanceParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L179)

***

### initial\_token\_distribution

> **initial\_token\_distribution**: \[\] \| \[[`InitialTokenDistribution`](InitialTokenDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L187)

***

### ledger\_parameters

> **ledger\_parameters**: \[\] \| \[[`LedgerParameters`](LedgerParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L183)

***

### logo

> **logo**: \[\] \| \[[`Image`](Image.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L181)

***

### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L182)

***

### swap\_parameters

> **swap\_parameters**: \[\] \| \[[`SwapParameters`](SwapParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L186)

***

### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L178)
