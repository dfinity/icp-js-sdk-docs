---
title: MakeProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L617)

## Properties

### action

> **action**: \[\] \| \[[`ProposalActionRequest`](../type-aliases/ProposalActionRequest.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:620](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L620)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L621)

***

### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:619](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L619)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L618)
