---
title: RewardNodeProviders
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1134](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1134)

## Properties

### rewards

> **rewards**: [`RewardNodeProvider`](RewardNodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1136](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1136)

***

### use\_registry\_derived\_rewards

> **use\_registry\_derived\_rewards**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1135](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1135)
