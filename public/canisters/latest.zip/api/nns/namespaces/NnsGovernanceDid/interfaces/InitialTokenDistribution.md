---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L468)

## Properties

### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](DeveloperDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L470)

***

### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](SwapDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L471)

***

### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`SwapDistribution`](SwapDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L469)
