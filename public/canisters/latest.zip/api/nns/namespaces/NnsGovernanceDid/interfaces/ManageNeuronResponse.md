---
title: ManageNeuronResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:694](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L694)

Output of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`Command_1`](../type-aliases/Command_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:699](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L699)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.
