---
title: ManageNeuronResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L654)

Output of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`Command_1`](../type-aliases/Command_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L659)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.
