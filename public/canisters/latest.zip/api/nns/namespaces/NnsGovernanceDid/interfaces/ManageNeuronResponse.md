---
title: ManageNeuronResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:694](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L694)

Output of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`Command_1`](../type-aliases/Command_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:699](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L699)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.
