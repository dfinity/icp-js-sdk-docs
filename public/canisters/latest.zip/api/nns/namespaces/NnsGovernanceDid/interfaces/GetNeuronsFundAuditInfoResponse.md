---
title: GetNeuronsFundAuditInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L343)

## Properties

### result

> **result**: \[\] \| \[[`Result_6`](../type-aliases/Result_6.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L344)
