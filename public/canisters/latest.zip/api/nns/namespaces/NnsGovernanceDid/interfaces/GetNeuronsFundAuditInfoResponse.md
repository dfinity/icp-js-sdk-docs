---
title: GetNeuronsFundAuditInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L303)

## Properties

### result

> **result**: \[\] \| \[[`Result_6`](../type-aliases/Result_6.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L304)
