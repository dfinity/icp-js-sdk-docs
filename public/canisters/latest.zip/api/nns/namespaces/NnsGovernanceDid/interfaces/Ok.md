---
title: Ok
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:965](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L965)

## Properties

### neurons\_fund\_audit\_info

> **neurons\_fund\_audit\_info**: \[\] \| \[[`NeuronsFundAuditInfo`](NeuronsFundAuditInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:966](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L966)
