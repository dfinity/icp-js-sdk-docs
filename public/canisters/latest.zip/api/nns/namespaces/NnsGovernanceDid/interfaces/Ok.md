---
title: Ok
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:965](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L965)

## Properties

### neurons\_fund\_audit\_info

> **neurons\_fund\_audit\_info**: \[\] \| \[[`NeuronsFundAuditInfo`](NeuronsFundAuditInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:966](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L966)
