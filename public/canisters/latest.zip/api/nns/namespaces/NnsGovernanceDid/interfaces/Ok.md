---
title: Ok
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1005](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1005)

## Properties

### neurons\_fund\_audit\_info

> **neurons\_fund\_audit\_info**: \[\] \| \[[`NeuronsFundAuditInfo`](NeuronsFundAuditInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1006](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1006)
