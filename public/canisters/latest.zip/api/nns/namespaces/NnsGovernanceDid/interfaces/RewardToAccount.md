---
title: RewardToAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1138](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1138)

## Properties

### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](AccountIdentifier.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1139](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1139)
