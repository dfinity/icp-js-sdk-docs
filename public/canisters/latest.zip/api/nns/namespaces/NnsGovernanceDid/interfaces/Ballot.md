---
title: Ballot
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L54)

## Properties

### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L55)

***

### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L56)
