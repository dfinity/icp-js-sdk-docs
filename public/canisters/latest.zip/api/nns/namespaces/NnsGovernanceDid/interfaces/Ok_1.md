---
title: Ok_1
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1008](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1008)

## Properties

### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuron`](NeuronsFundNeuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1009)
