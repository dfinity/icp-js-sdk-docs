---
title: Ok_1
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:968](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L968)

## Properties

### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuron`](NeuronsFundNeuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:969](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L969)
