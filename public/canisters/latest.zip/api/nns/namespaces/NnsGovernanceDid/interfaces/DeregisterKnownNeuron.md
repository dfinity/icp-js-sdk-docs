---
title: DeregisterKnownNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L204)

## Properties

### id

> **id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L205)
