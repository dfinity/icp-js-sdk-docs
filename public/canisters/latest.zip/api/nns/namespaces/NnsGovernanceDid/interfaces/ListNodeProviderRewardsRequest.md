---
title: ListNodeProviderRewardsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L591)

## Properties

### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](DateRangeFilter.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L592)
