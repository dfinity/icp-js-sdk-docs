---
title: ListNodeProviderRewardsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L591)

## Properties

### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](DateRangeFilter.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L592)
