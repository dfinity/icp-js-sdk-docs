---
title: NeuronsFundEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:958](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L958)

## Properties

### max\_theoretical\_neurons\_fund\_participation\_amount\_xdr

> **max\_theoretical\_neurons\_fund\_participation\_amount\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:963](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L963)

***

### maximum\_icp\_xdr\_rate

> **maximum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:959](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L959)

***

### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:964](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L964)

***

### neurons\_fund\_matched\_funding\_curve\_coefficients

> **neurons\_fund\_matched\_funding\_curve\_coefficients**: \[\] \| \[[`NeuronsFundMatchedFundingCurveCoefficients`](NeuronsFundMatchedFundingCurveCoefficients.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:960](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L960)
