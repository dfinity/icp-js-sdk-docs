---
title: NeuronsFundEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L918)

## Properties

### max\_theoretical\_neurons\_fund\_participation\_amount\_xdr

> **max\_theoretical\_neurons\_fund\_participation\_amount\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:923](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L923)

***

### maximum\_icp\_xdr\_rate

> **maximum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L919)

***

### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:924](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L924)

***

### neurons\_fund\_matched\_funding\_curve\_coefficients

> **neurons\_fund\_matched\_funding\_curve\_coefficients**: \[\] \| \[[`NeuronsFundMatchedFundingCurveCoefficients`](NeuronsFundMatchedFundingCurveCoefficients.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L920)
