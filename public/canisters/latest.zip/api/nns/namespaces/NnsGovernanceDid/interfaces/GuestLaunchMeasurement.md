---
title: GuestLaunchMeasurement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L400)

## Properties

### measurement

> **measurement**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L408)

SEV-SNP measurement (48 bytes).

***

### metadata

> **metadata**: \[\] \| \[[`GuestLaunchMeasurementMetadata`](GuestLaunchMeasurementMetadata.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L404)

Metadata associated with the measurement.
