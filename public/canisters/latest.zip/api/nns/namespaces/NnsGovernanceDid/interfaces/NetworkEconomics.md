---
title: NetworkEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:699](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L699)

## Properties

### max\_proposals\_to\_keep\_per\_topic

> **max\_proposals\_to\_keep\_per\_topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:705](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L705)

***

### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:711](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L711)

***

### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:710](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L710)

***

### neuron\_management\_fee\_per\_proposal\_e8s

> **neuron\_management\_fee\_per\_proposal\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:706](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L706)

***

### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:700](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L700)

***

### neuron\_spawn\_dissolve\_delay\_seconds

> **neuron\_spawn\_dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:709](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L709)

***

### neurons\_fund\_economics

> **neurons\_fund\_economics**: \[\] \| \[[`NeuronsFundEconomics`](NeuronsFundEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:712](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L712)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:707](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L707)

***

### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:708](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L708)

***

### voting\_power\_economics

> **voting\_power\_economics**: \[\] \| \[[`VotingPowerEconomics`](VotingPowerEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:704](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L704)

Parameters that affect the voting power of neurons.
