---
title: NetworkEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L739)

## Properties

### max\_proposals\_to\_keep\_per\_topic

> **max\_proposals\_to\_keep\_per\_topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:745](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L745)

***

### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L751)

***

### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:750](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L750)

***

### neuron\_management\_fee\_per\_proposal\_e8s

> **neuron\_management\_fee\_per\_proposal\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:746](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L746)

***

### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:740](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L740)

***

### neuron\_spawn\_dissolve\_delay\_seconds

> **neuron\_spawn\_dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L749)

***

### neurons\_fund\_economics

> **neurons\_fund\_economics**: \[\] \| \[[`NeuronsFundEconomics`](NeuronsFundEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L752)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L747)

***

### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:748](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L748)

***

### voting\_power\_economics

> **voting\_power\_economics**: \[\] \| \[[`VotingPowerEconomics`](VotingPowerEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:744](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L744)

Parameters that affect the voting power of neurons.
