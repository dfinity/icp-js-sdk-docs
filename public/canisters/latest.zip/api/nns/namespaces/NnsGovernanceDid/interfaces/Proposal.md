---
title: Proposal
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1008](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1008)

## Properties

### action

> **action**: \[\] \| \[[`Action`](../type-aliases/Action.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1011](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1011)

***

### self\_describing\_action

> **self\_describing\_action**: \[\] \| \[[`SelfDescribingProposalAction`](SelfDescribingProposalAction.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1013](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1013)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1012](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1012)

***

### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1010](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1010)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1009)
