---
title: Proposal
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1048](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1048)

## Properties

### action

> **action**: \[\] \| \[[`Action`](../type-aliases/Action.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1051](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1051)

***

### self\_describing\_action

> **self\_describing\_action**: \[\] \| \[[`SelfDescribingProposalAction`](SelfDescribingProposalAction.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1053](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1053)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1052](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1052)

***

### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1050](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1050)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1049](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1049)
