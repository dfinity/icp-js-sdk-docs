---
title: DateUtc
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L196)

## Properties

### day

> **day**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L197)

***

### month

> **month**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L198)

***

### year

> **year**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L199)
