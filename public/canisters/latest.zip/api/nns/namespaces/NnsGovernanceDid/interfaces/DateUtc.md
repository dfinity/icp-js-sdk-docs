---
title: DateUtc
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L236)

## Properties

### day

> **day**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L237)

***

### month

> **month**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L238)

***

### year

> **year**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L239)
