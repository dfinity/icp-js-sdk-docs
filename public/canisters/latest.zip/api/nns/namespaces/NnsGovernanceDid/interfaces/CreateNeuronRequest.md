---
title: CreateNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L181)

Request to create a new neuron using ICRC-2 transfer_from.
The caller must have previously approved the governance canister to spend the specified amount.

## Properties

### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L201)

Required. The amount of ICP to stake in e8s.

***

### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L197)

Whether to automatically stake maturity. Defaults to false.

***

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L185)

The controller of the new neuron. Defaults to the caller.

***

### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L193)

The dissolve delay in seconds. Defaults to 7 days. Clamped to [0, 8 years].

***

### dissolving

> **dissolving**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L209)

Whether the neuron should start dissolving immediately. Defaults to false.

***

### followees

> **followees**: \[\] \| \[[`SetFollowing`](SetFollowing.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L205)

The followees to set for the new neuron. Defaults to the network's default followees.

***

### source\_subaccount

> **source\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L189)

The subaccount of the caller to transfer ICP from. Defaults to the default subaccount.
