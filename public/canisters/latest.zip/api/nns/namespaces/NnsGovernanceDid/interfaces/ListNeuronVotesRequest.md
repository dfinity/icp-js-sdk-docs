---
title: ListNeuronVotesRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L475)

## Properties

### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L480)

Only fetch the voting history for proposal whose id `< before_proposal`. This can be used as a
pagination token - pass the minimum proposal id as `before_proposal` for the next page.

***

### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L485)

The maximum number of votes to fetch. The maximum number allowed is 500, and 500 will be used
if is set as either null or > 500.

***

### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L490)

The neuron id for which the voting history will be returned. Currently, the voting history is
only recorded for known neurons.
