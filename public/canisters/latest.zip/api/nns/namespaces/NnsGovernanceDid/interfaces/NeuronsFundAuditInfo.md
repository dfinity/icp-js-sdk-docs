---
title: NeuronsFundAuditInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L948)

## Properties

### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](NeuronsFundParticipation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L949)

***

### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](NeuronsFundParticipation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:950](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L950)

***

### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](NeuronsFundSnapshot.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:951](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L951)
