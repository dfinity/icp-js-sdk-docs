---
title: NeuronsFundAuditInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:908](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L908)

## Properties

### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](NeuronsFundParticipation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L909)

***

### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](NeuronsFundParticipation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:910](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L910)

***

### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](NeuronsFundSnapshot.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:911](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L911)
