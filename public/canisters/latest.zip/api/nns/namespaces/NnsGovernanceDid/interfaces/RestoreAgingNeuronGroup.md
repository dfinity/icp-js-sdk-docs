---
title: RestoreAgingNeuronGroup
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1092](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1092)

## Properties

### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1093](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1093)

***

### current\_total\_stake\_e8s

> **current\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1095](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1095)

***

### group\_type

> **group\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1096](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1096)

***

### previous\_total\_stake\_e8s

> **previous\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1094](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1094)
