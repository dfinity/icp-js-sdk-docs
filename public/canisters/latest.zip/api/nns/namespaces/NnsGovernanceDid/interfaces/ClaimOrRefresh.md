---
title: ClaimOrRefresh
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L118)

## Properties

### by

> **by**: \[\] \| \[[`By`](../type-aliases/By.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L119)
