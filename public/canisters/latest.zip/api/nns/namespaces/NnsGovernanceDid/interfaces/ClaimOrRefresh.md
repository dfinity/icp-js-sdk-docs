---
title: ClaimOrRefresh
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L118)

## Properties

### by

> **by**: \[\] \| \[[`By`](../type-aliases/By.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L119)
