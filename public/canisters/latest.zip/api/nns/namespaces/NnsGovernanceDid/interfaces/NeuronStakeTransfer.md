---
title: NeuronStakeTransfer
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L873)

## Properties

### block\_height

> **block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:880](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L880)

***

### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:876](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L876)

***

### from\_subaccount

> **from\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:878](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L878)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:877](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L877)

***

### neuron\_stake\_e8s

> **neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L875)

***

### to\_subaccount

> **to\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L874)

***

### transfer\_timestamp

> **transfer\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:879](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L879)
