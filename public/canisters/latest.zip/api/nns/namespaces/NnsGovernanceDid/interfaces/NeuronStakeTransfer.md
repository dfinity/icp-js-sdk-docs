---
title: NeuronStakeTransfer
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L913)

## Properties

### block\_height

> **block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L920)

***

### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L916)

***

### from\_subaccount

> **from\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L918)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:917](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L917)

***

### neuron\_stake\_e8s

> **neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L915)

***

### to\_subaccount

> **to\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L914)

***

### transfer\_timestamp

> **transfer\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L919)
