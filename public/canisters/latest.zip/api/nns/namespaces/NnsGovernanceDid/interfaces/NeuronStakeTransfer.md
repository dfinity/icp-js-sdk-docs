---
title: NeuronStakeTransfer
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L913)

## Properties

### block\_height

> **block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L920)

***

### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L916)

***

### from\_subaccount

> **from\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L918)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:917](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L917)

***

### neuron\_stake\_e8s

> **neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L915)

***

### to\_subaccount

> **to\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L914)

***

### transfer\_timestamp

> **transfer\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L919)
