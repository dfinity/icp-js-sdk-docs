---
title: Result_10
editUrl: false
next: true
prev: true
---

> **Result\_10** = \{ `Ok`: [`Ok_1`](../interfaces/Ok_1.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1104](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1104)
