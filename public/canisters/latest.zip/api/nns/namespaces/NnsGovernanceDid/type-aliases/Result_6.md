---
title: Result_6
editUrl: false
next: true
prev: true
---

> **Result\_6** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1113](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1113)
