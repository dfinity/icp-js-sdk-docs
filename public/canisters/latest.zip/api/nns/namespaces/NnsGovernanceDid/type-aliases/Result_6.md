---
title: Result_6
editUrl: false
next: true
prev: true
---

> **Result\_6** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1153](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1153)
