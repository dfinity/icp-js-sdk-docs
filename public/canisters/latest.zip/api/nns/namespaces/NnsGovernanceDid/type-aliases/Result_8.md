---
title: Result_8
editUrl: false
next: true
prev: true
---

> **Result\_8** = \{ `Committed`: [`Committed`](../interfaces/Committed.md); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1155](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1155)
