---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Error`: [`GovernanceError`](../interfaces/GovernanceError.md); \} \| \{ `NeuronId`: [`NeuronId`](../interfaces/NeuronId.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1103](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1103)
