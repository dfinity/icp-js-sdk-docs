---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Error`: [`GovernanceError`](../interfaces/GovernanceError.md); \} \| \{ `NeuronId`: [`NeuronId`](../interfaces/NeuronId.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1143](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1143)
