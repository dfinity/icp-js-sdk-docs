---
title: ListNeuronVotesResponse
editUrl: false
next: true
prev: true
---

> **ListNeuronVotesResponse** = \{ `Ok`: \{ `all_finalized_before_proposal`: \[\] \| \[[`ProposalId`](../interfaces/ProposalId.md)\]; `votes`: \[\] \| \[[`NeuronVote`](../interfaces/NeuronVote.md)[]\]; \}; \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L492)
