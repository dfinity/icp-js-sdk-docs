---
title: CreateNeuronResponse
editUrl: false
next: true
prev: true
---

> **CreateNeuronResponse** = \{ `Ok`: [`CreatedNeuron`](../interfaces/CreatedNeuron.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L211)
