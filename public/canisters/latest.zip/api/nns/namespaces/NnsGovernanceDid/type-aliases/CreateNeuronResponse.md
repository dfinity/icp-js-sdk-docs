---
title: CreateNeuronResponse
editUrl: false
next: true
prev: true
---

> **CreateNeuronResponse** = \{ `Ok`: [`CreatedNeuron`](../interfaces/CreatedNeuron.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L211)
