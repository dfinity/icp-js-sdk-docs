---
title: By
editUrl: false
next: true
prev: true
---

> **By** = \{ `NeuronIdOrSubaccount`: \{ \}; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](../interfaces/ClaimOrRefreshNeuronFromAccount.md); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L85)
