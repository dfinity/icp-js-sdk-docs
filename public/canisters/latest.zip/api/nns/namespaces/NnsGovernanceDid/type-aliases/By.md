---
title: By
editUrl: false
next: true
prev: true
---

> **By** = \{ `NeuronIdOrSubaccount`: \{ \}; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](../interfaces/ClaimOrRefreshNeuronFromAccount.md); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L85)
