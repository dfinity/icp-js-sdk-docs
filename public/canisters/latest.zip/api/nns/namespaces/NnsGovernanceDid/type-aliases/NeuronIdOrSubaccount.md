---
title: NeuronIdOrSubaccount
editUrl: false
next: true
prev: true
---

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `Uint8Array`; \} \| \{ `NeuronId`: [`NeuronId`](../interfaces/NeuronId.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:821](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L821)
