---
title: NeuronIdOrSubaccount
editUrl: false
next: true
prev: true
---

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `Uint8Array`; \} \| \{ `NeuronId`: [`NeuronId`](../interfaces/NeuronId.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:861](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L861)
