---
title: RefreshVotingPower
editUrl: false
next: true
prev: true
---

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1123](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1123)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.
