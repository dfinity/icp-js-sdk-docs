---
title: RefreshVotingPower
editUrl: false
next: true
prev: true
---

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1083](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1083)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.
