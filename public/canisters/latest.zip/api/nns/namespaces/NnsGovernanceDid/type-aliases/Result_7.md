---
title: Result_7
editUrl: false
next: true
prev: true
---

> **Result\_7** = \{ `Ok`: [`NodeProvider`](../interfaces/NodeProvider.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1114](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1114)
