---
title: GetNeuronIndexResult
editUrl: false
next: true
prev: true
---

> **GetNeuronIndexResult** = \{ `Ok`: [`NeuronIndexData`](../interfaces/NeuronIndexData.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L297)
