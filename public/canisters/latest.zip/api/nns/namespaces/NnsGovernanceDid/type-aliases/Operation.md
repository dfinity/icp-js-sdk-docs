---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](../interfaces/RemoveHotKey.md); \} \| \{ `AddHotKey`: [`AddHotKey`](../interfaces/AddHotKey.md); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](../interfaces/ChangeAutoStakeMaturity.md); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](../interfaces/IncreaseDissolveDelay.md); \} \| \{ `SetVisibility`: [`SetVisibility`](../interfaces/SetVisibility.md); \} \| \{ `JoinCommunityFund`: \{ \}; \} \| \{ `LeaveCommunityFund`: \{ \}; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](../interfaces/SetDissolveTimestamp.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:976](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L976)
