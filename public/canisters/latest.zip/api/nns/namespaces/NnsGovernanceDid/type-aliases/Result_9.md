---
title: Result_9
editUrl: false
next: true
prev: true
---

> **Result\_9** = \{ `Committed`: [`Committed_1`](../interfaces/Committed_1.md); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1156](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1156)
