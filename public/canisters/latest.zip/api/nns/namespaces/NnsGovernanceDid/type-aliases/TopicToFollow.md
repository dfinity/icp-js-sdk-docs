---
title: TopicToFollow
editUrl: false
next: true
prev: true
---

> **TopicToFollow** = \{ `Kyc`: `null`; \} \| \{ `ServiceNervousSystemManagement`: `null`; \} \| \{ `ApiBoundaryNodeManagement`: `null`; \} \| \{ `ApplicationCanisterManagement`: `null`; \} \| \{ `SubnetRental`: `null`; \} \| \{ `NeuronManagement`: `null`; \} \| \{ `NodeProviderRewards`: `null`; \} \| \{ `SubnetManagement`: `null`; \} \| \{ `ExchangeRate`: `null`; \} \| \{ `CatchAll`: `null`; \} \| \{ `NodeAdmin`: `null`; \} \| \{ `IcOsVersionElection`: `null`; \} \| \{ `ProtocolCanisterManagement`: `null`; \} \| \{ `NetworkEconomics`: `null`; \} \| \{ `IcOsVersionDeployment`: `null`; \} \| \{ `ParticipantManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsAndCommunityFund`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1312](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1312)

A topic that can be followed. It is almost the same as the topic on the
proposal, except that the `CatchAll` is a special value and following on this
`topic` will let the neuron follow the votes on all topics except for
Governance and SnsAndCommunityFund.
