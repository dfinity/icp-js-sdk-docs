---
title: SetFollowingResponse
editUrl: false
next: true
prev: true
---

> **SetFollowingResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1167](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1167)
