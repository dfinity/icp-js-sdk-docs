---
title: Vote
editUrl: false
next: true
prev: true
---

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1338](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1338)

## Type Declaration

\{ `No`: `null`; \}

### No

> **No**: `null`

\{ `Yes`: `null`; \}

### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.
