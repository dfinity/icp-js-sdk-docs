---
title: Vote
editUrl: false
next: true
prev: true
---

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1298](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1298)

## Type Declaration

\{ `No`: `null`; \}

### No

> **No**: `null`

\{ `Yes`: `null`; \}

### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.
