---
title: Vote
editUrl: false
next: true
prev: true
---

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1298](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1298)

## Type Declaration

\{ `No`: `null`; \}

### No

> **No**: `null`

\{ `Yes`: `null`; \}

### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.
