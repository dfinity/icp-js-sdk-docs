---
title: ManageNeuronCommandRequest
editUrl: false
next: true
prev: true
---

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](../interfaces/Spawn.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Follow`: [`Follow`](../interfaces/Follow.md); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](../interfaces/DisburseMaturity.md); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](RefreshVotingPower.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `RegisterVote`: [`RegisterVote`](../interfaces/RegisterVote.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SetFollowing`: [`SetFollowing`](../interfaces/SetFollowing.md); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](../interfaces/MakeProposalRequest.md); \} \| \{ `StakeMaturity`: [`StakeMaturity`](../interfaces/StakeMaturity.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L630)

KEEP THIS IN SYNC WITH COMMAND!
