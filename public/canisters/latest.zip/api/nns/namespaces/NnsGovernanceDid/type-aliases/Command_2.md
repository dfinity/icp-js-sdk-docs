---
title: Command_2
editUrl: false
next: true
prev: true
---

> **Command\_2** = \{ `Spawn`: [`NeuronId`](../interfaces/NeuronId.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L148)
