---
title: ManageNeuronProposalCommand
editUrl: false
next: true
prev: true
---

> **ManageNeuronProposalCommand** = \{ `Spawn`: [`Spawn`](../interfaces/Spawn.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Follow`: [`Follow`](../interfaces/Follow.md); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](../interfaces/DisburseMaturity.md); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](RefreshVotingPower.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `RegisterVote`: [`RegisterVote`](../interfaces/RegisterVote.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SetFollowing`: [`SetFollowing`](../interfaces/SetFollowing.md); \} \| \{ `MakeProposal`: [`Proposal`](../interfaces/Proposal.md); \} \| \{ `StakeMaturity`: [`StakeMaturity`](../interfaces/StakeMaturity.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L618)

KEEP THIS IN SYNC WITH ManageNeuronCommandRequest!
