---
title: Command_1
editUrl: false
next: true
prev: true
---

> **Command\_1** = \{ `Error`: [`GovernanceError`](../interfaces/GovernanceError.md); \} \| \{ `Spawn`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `Split`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](../interfaces/DisburseMaturityResponse.md); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPowerResponse`](RefreshVotingPowerResponse.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](../interfaces/ClaimOrRefreshResponse.md); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `Merge`: [`MergeResponse`](../interfaces/MergeResponse.md); \} \| \{ `DisburseToNeuron`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `SetFollowing`: [`SetFollowingResponse`](SetFollowingResponse.md); \} \| \{ `MakeProposal`: [`MakeProposalResponse`](../interfaces/MakeProposalResponse.md); \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](../interfaces/StakeMaturityResponse.md); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](../interfaces/MergeMaturityResponse.md); \} \| \{ `Disburse`: [`DisburseResponse`](../interfaces/DisburseResponse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L131)
