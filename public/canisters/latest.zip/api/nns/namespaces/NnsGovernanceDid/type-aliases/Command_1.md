---
title: Command_1
editUrl: false
next: true
prev: true
---

> **Command\_1** = \{ `Error`: [`GovernanceError`](../interfaces/GovernanceError.md); \} \| \{ `Spawn`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `Split`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](../interfaces/DisburseMaturityResponse.md); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPowerResponse`](RefreshVotingPowerResponse.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](../interfaces/ClaimOrRefreshResponse.md); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `Merge`: [`MergeResponse`](../interfaces/MergeResponse.md); \} \| \{ `DisburseToNeuron`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `SetFollowing`: [`SetFollowingResponse`](SetFollowingResponse.md); \} \| \{ `MakeProposal`: [`MakeProposalResponse`](../interfaces/MakeProposalResponse.md); \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](../interfaces/StakeMaturityResponse.md); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](../interfaces/MergeMaturityResponse.md); \} \| \{ `Disburse`: [`DisburseResponse`](../interfaces/DisburseResponse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L131)
