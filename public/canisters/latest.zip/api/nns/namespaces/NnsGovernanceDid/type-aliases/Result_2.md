---
title: Result_2
editUrl: false
next: true
prev: true
---

> **Result\_2** = \{ `Ok`: [`Neuron`](../interfaces/Neuron.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1105](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1105)
