---
title: Result_3
editUrl: false
next: true
prev: true
---

> **Result\_3** = \{ `Ok`: [`GovernanceCachedMetrics`](../interfaces/GovernanceCachedMetrics.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1146](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1146)
