---
title: Result_3
editUrl: false
next: true
prev: true
---

> **Result\_3** = \{ `Ok`: [`GovernanceCachedMetrics`](../interfaces/GovernanceCachedMetrics.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1146](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1146)
