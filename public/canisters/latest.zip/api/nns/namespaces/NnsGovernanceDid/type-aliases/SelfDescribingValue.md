---
title: SelfDescribingValue
editUrl: false
next: true
prev: true
---

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `SelfDescribingValue`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Null`: `null`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `SelfDescribingValue`[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1189](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance.d.ts#L1189)
