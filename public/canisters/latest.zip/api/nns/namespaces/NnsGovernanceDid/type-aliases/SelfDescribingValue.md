---
title: SelfDescribingValue
editUrl: false
next: true
prev: true
---

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `SelfDescribingValue`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Null`: `null`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `SelfDescribingValue`[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1149](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance.d.ts#L1149)
