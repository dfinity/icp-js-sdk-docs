---
title: SelfDescribingValue
editUrl: false
next: true
prev: true
---

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `SelfDescribingValue`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Null`: `null`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `SelfDescribingValue`[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1189](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance.d.ts#L1189)
