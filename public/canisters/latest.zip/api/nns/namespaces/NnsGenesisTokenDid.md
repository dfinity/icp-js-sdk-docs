---
title: NnsGenesisTokenDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L35)

#### Properties

##### balance

> **balance**: `ActorMethod`\<\[`string`\], `number`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L36)

##### claim\_neurons

> **claim\_neurons**: `ActorMethod`\<\[`string`\], [`Result`](#result)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L37)

##### donate\_account

> **donate\_account**: `ActorMethod`\<\[`string`\], [`Result_1`](#result_1)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L38)

##### forward\_whitelisted\_unclaimed\_accounts

> **forward\_whitelisted\_unclaimed\_accounts**: `ActorMethod`\<\[`null`\], [`Result_1`](#result_1)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L39)

##### get\_account

> **get\_account**: `ActorMethod`\<\[`string`\], [`Result_2`](#result_2)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L40)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L41)

##### len

> **len**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L42)

##### total

> **total**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L43)

***

### AccountState

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L13)

#### Properties

##### authenticated\_principal\_id

> **authenticated\_principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L14)

##### failed\_transferred\_neurons

> **failed\_transferred\_neurons**: [`TransferredNeuron`](#transferredneuron)[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L18)

##### has\_claimed

> **has\_claimed**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L20)

##### has\_donated

> **has\_donated**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L17)

##### has\_forwarded

> **has\_forwarded**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L21)

##### icpts

> **icpts**: `number`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L22)

##### is\_whitelisted\_for\_forwarding

> **is\_whitelisted\_for\_forwarding**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L16)

##### neuron\_ids

> **neuron\_ids**: [`NeuronId`](#neuronid)[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L19)

##### successfully\_transferred\_neurons

> **successfully\_transferred\_neurons**: [`TransferredNeuron`](#transferredneuron)[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L15)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L24)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L25)

***

### TransferredNeuron

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L30)

#### Properties

##### error

> **error**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L31)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid)\]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L33)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L32)

## Type Aliases

### Result

> **Result** = \{ `Ok`: [`NeuronId`](#neuronid)[]; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L27)

***

### Result\_1

> **Result\_1** = \{ `Ok`: `null`; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L28)

***

### Result\_2

> **Result\_2** = \{ `Ok`: [`AccountState`](#accountstate); \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L29)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L45)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/genesis_token.d.ts#L46)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
