---
title: NnsGovernanceDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1436](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1436)

#### Properties

##### claim\_gtc\_neurons

> **claim\_gtc\_neurons**: `ActorMethod`\<\[`Principal`, [`NeuronId`](#neuronid-1)[]\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1437](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1437)

##### claim\_or\_refresh\_neuron\_from\_account

> **claim\_or\_refresh\_neuron\_from\_account**: `ActorMethod`\<\[[`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount)\], [`ClaimOrRefreshNeuronFromAccountResponse`](#claimorrefreshneuronfromaccountresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1438](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1438)

##### create\_neuron

> **create\_neuron**: `ActorMethod`\<\[[`CreateNeuronRequest`](#createneuronrequest)\], [`CreateNeuronResponse`](#createneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1442](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1442)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1443](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1443)

##### get\_full\_neuron

> **get\_full\_neuron**: `ActorMethod`\<\[`bigint`\], [`Result_2`](#result_2)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1444](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1444)

##### get\_full\_neuron\_by\_id\_or\_subaccount

> **get\_full\_neuron\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\], [`Result_2`](#result_2)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1445](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1445)

##### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](#rewardevent)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1449](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1449)

##### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[\], [`Result_3`](#result_3)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1450](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1450)

##### get\_monthly\_node\_provider\_rewards

> **get\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], [`Result_4`](#result_4)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1451](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1451)

##### get\_most\_recent\_monthly\_node\_provider\_rewards

> **get\_most\_recent\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], \[\] \| \[[`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1452](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1452)

##### get\_network\_economics\_parameters

> **get\_network\_economics\_parameters**: `ActorMethod`\<\[\], [`NetworkEconomics`](#networkeconomics)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1456](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1456)

##### get\_neuron\_ids

> **get\_neuron\_ids**: `ActorMethod`\<\[\], `BigUint64Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1457](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1457)

##### get\_neuron\_index

> **get\_neuron\_index**: `ActorMethod`\<\[[`GetNeuronIndexRequest`](#getneuronindexrequest)\], [`GetNeuronIndexResult`](#getneuronindexresult)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1458](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1458)

##### get\_neuron\_info

> **get\_neuron\_info**: `ActorMethod`\<\[`bigint`\], [`Result_5`](#result_5)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1459](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1459)

##### get\_neuron\_info\_by\_id\_or\_subaccount

> **get\_neuron\_info\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\], [`Result_5`](#result_5)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1460](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1460)

##### get\_neurons\_fund\_audit\_info

> **get\_neurons\_fund\_audit\_info**: `ActorMethod`\<\[[`GetNeuronsFundAuditInfoRequest`](#getneuronsfundauditinforequest)\], [`GetNeuronsFundAuditInfoResponse`](#getneuronsfundauditinforesponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1464](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1464)

##### get\_node\_provider\_by\_caller

> **get\_node\_provider\_by\_caller**: `ActorMethod`\<\[`null`\], [`Result_7`](#result_7)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1468](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1468)

##### get\_pending\_proposals

> **get\_pending\_proposals**: `ActorMethod`\<\[\[\] \| \[[`GetPendingProposalsRequest`](#getpendingproposalsrequest)\]\], [`ProposalInfo`](#proposalinfo)[]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1469](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1469)

##### get\_proposal\_info

> **get\_proposal\_info**: `ActorMethod`\<\[`bigint`\], \[\] \| \[[`ProposalInfo`](#proposalinfo)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1473](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1473)

##### get\_restore\_aging\_summary

> **get\_restore\_aging\_summary**: `ActorMethod`\<\[\], [`RestoreAgingSummary`](#restoreagingsummary)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1474](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1474)

##### list\_known\_neurons

> **list\_known\_neurons**: `ActorMethod`\<\[\], [`ListKnownNeuronsResponse`](#listknownneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1475](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1475)

##### list\_neuron\_votes

> **list\_neuron\_votes**: `ActorMethod`\<\[[`ListNeuronVotesRequest`](#listneuronvotesrequest)\], [`ListNeuronVotesResponse`](#listneuronvotesresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1476](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1476)

##### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](#listneurons)\], [`ListNeuronsResponse`](#listneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1480](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1480)

##### list\_node\_provider\_rewards

> **list\_node\_provider\_rewards**: `ActorMethod`\<\[[`ListNodeProviderRewardsRequest`](#listnodeproviderrewardsrequest)\], [`ListNodeProviderRewardsResponse`](#listnodeproviderrewardsresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1481](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1481)

##### list\_node\_providers

> **list\_node\_providers**: `ActorMethod`\<\[\], [`ListNodeProvidersResponse`](#listnodeprovidersresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1485](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1485)

##### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposalInfoRequest`](#listproposalinforequest)\], [`ListProposalInfoResponse`](#listproposalinforesponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1486](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1486)

##### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](#manageneuronrequest)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1490](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1490)

##### settle\_community\_fund\_participation

> **settle\_community\_fund\_participation**: `ActorMethod`\<\[[`SettleCommunityFundParticipation`](#settlecommunityfundparticipation)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1491](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1491)

##### settle\_neurons\_fund\_participation

> **settle\_neurons\_fund\_participation**: `ActorMethod`\<\[[`SettleNeuronsFundParticipationRequest`](#settleneuronsfundparticipationrequest)\], [`SettleNeuronsFundParticipationResponse`](#settleneuronsfundparticipationresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1495](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1495)

##### simulate\_manage\_neuron

> **simulate\_manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](#manageneuronrequest)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1499](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1499)

##### transfer\_gtc\_neuron

> **transfer\_gtc\_neuron**: `ActorMethod`\<\[[`NeuronId`](#neuronid-1), [`NeuronId`](#neuronid-1)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1503](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1503)

##### update\_node\_provider

> **update\_node\_provider**: `ActorMethod`\<\[[`UpdateNodeProvider`](#updatenodeprovider)\], [`Result`](#result-5)\>

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1504](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1504)

***

### Account

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L13)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L15)

***

### AccountIdentifier

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L17)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L18)

***

### AddHotKey

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L43)

#### Properties

##### new\_hot\_key

> **new\_hot\_key**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L44)

***

### AddOrRemoveNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L46)

#### Properties

##### change

> **change**: \[\] \| \[[`Change`](#change-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L47)

***

### Amount

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L49)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L50)

***

### ApproveGenesisKyc

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L52)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L53)

***

### Ballot

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L55)

#### Properties

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L56)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L57)

***

### BallotInfo

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L59)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L61)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L60)

***

### BlessAlternativeGuestOsVersion

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L67)

Declares an approved set of alternative replica virtual machine software for
disaster recovery purposes.

#### Properties

##### base\_guest\_launch\_measurements

> **base\_guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurements`](#guestlaunchmeasurements)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L84)

The version being replaced by this (alternative version) must match this
field (or one of the possibilities therein).

(Here, we refer to the version being replaced as the "base" version.)

##### chip\_ids

> **chip\_ids**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L77)

AMD Secure Processor chip IDs that are allowed to run this software.
Each chip ID must be exactly 64 bytes.

##### rootfs\_hash

> **rootfs\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L72)

Hexadecimal fingerprint of the recovery rootfs.
Must contain only hexadecimal characters (0-9, A-F, a-f).

***

### Canister

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L90)

#### Properties

##### id

> **id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L91)

***

### CanisterSettings

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L93)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L101)

##### controllers

> **controllers**: \[\] \| \[[`Controllers`](#controllers-2)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L96)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L94)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L97)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L100)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L98)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L99)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L95)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L103)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L106)

##### cycles

> **cycles**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L108)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L105)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L109)

##### memory\_size

> **memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L107)

##### module\_hash

> **module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L110)

##### status

> **status**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L104)

***

### CanisterSummary

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L112)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L114)

##### status

> **status**: \[\] \| \[[`CanisterStatusResultV2`](#canisterstatusresultv2)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L113)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L117)

#### Properties

##### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L118)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L120)

#### Properties

##### by

> **by**: \[\] \| \[[`By`](#by-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L121)

***

### ClaimOrRefreshNeuronFromAccount

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L123)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L124)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L125)

***

### ClaimOrRefreshNeuronFromAccountResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L127)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L128)

***

### ClaimOrRefreshResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L130)

#### Properties

##### refreshed\_neuron\_id

> **refreshed\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L131)

***

### Committed

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L160)

#### Properties

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L163)

##### total\_direct\_contribution\_icp\_e8s

> **total\_direct\_contribution\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L161)

##### total\_neurons\_fund\_contribution\_icp\_e8s

> **total\_neurons\_fund\_contribution\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L162)

***

### Committed\_1

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L165)

#### Properties

##### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L168)

##### total\_direct\_participation\_icp\_e8s

> **total\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L166)

##### total\_neurons\_fund\_participation\_icp\_e8s

> **total\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L167)

***

### Configure

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L170)

#### Properties

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L171)

***

### Controllers

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L173)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L174)

***

### Countries

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L176)

#### Properties

##### iso\_codes

> **iso\_codes**: `string`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L177)

***

### CreateCanisterAndInstallCode

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L179)

#### Properties

##### canister\_settings

> **canister\_settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L181)

##### host\_subnet\_id

> **host\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L183)

##### install\_arg\_hash

> **install\_arg\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L182)

##### wasm\_module\_hash

> **wasm\_module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L180)

***

### CreateCanisterAndInstallCodeRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L185)

#### Properties

##### canister\_settings

> **canister\_settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L187)

##### host\_subnet\_id

> **host\_subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L189)

##### install\_arg

> **install\_arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L188)

##### wasm\_module

> **wasm\_module**: \[\] \| \[[`WasmModule`](#wasmmodule)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L186)

***

### CreatedNeuron

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L240)

#### Properties

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L241)

***

### CreateNeuronRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L195)

Request to create a new neuron using ICRC-2 transfer_from.
The caller must have previously approved the governance canister to spend the specified amount.

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L215)

Required. The amount of ICP to stake in e8s.

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L211)

Whether to automatically stake maturity. Defaults to false.

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L199)

The controller of the new neuron. Defaults to the caller.

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L207)

The dissolve delay in seconds. Defaults to 7 days. Clamped to [0, 8 years].

##### dissolving

> **dissolving**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L223)

Whether the neuron should start dissolving immediately. Defaults to false.

##### followees

> **followees**: \[\] \| \[[`SetFollowing`](#setfollowing)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L219)

The followees to set for the new neuron. Defaults to the network's default followees.

##### source\_subaccount

> **source\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L203)

The subaccount of the caller to transfer ICP from. Defaults to the default subaccount.

***

### CreateServiceNervousSystem

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L228)

#### Properties

##### dapp\_canisters

> **dapp\_canisters**: [`Canister`](#canister)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L236)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L235)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L231)

##### governance\_parameters

> **governance\_parameters**: \[\] \| \[[`GovernanceParameters`](#governanceparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L230)

##### initial\_token\_distribution

> **initial\_token\_distribution**: \[\] \| \[[`InitialTokenDistribution`](#initialtokendistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L238)

##### ledger\_parameters

> **ledger\_parameters**: \[\] \| \[[`LedgerParameters`](#ledgerparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L234)

##### logo

> **logo**: \[\] \| \[[`Image`](#image)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L232)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L233)

##### swap\_parameters

> **swap\_parameters**: \[\] \| \[[`SwapParameters`](#swapparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L237)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L229)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L243)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: \[\] \| \[`BigUint64Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L244)

***

### DateRangeFilter

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L246)

#### Properties

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L248)

##### start\_timestamp\_seconds

> **start\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L247)

***

### DateUtc

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L250)

#### Properties

##### day

> **day**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L251)

##### month

> **month**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L252)

##### year

> **year**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L253)

***

### Decimal

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L255)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L256)

***

### DeregisterKnownNeuron

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L258)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L259)

***

### DerivedProposalInformation

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L261)

#### Properties

##### swap\_background\_information

> **swap\_background\_information**: \[\] \| \[[`SwapBackgroundInformation`](#swapbackgroundinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L262)

***

### DeveloperDistribution

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L264)

#### Properties

##### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](#neurondistribution)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L265)

***

### Disburse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L267)

#### Properties

##### amount

> **amount**: \[\] \| \[[`Amount`](#amount)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L269)

##### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L268)

***

### DisburseMaturity

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L271)

#### Properties

##### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L274)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L273)

##### to\_account\_identifier

> **to\_account\_identifier**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L272)

***

### DisburseMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L276)

#### Properties

##### amount\_disbursed\_e8s

> **amount\_disbursed\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L277)

***

### DisburseResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L279)

#### Properties

##### transfer\_block\_height

> **transfer\_block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L280)

***

### DisburseToNeuron

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L282)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L285)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L283)

##### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L284)

##### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L286)

##### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L287)

***

### Duration

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L292)

#### Properties

##### seconds

> **seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L293)

***

### ExecuteNnsFunction

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L295)

#### Properties

##### nns\_function

> **nns\_function**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L296)

##### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L297)

***

### Follow

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L299)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L301)

##### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L300)

***

### Followees

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L303)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L304)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L306)

#### Properties

##### followees

> **followees**: \[\] \| \[[`NeuronId`](#neuronid-1)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L308)

##### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L307)

***

### FulfillSubnetRentalRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L314)

Creates a rented subnet from a rental request (in the Subnet Rental
canister).

#### Properties

##### node\_ids

> **node\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L345)

Which nodes will be members of the subnet.

##### replica\_version\_id

> **replica\_version\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L341)

What software the nodes will run.

This must be approved by a prior proposal to bless an IC OS version.

This is a FULL git commit ID in the ic repo. (Therefore, it must be a 40
character hexidecimal string, not an abbreviated git commit ID.)

One way to find a suitable value is with the following command:

ic-admin \
get-subnet 0 \
--nns-urls https://nns.ic0.app \
| grep replica_version_id

Where to obtain a recent version of ic-admin:

https://github.com/dfinity/ic/releases/latest

##### user

> **user**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L321)

Identifies which rental request to fulfill.

(Identifying the rental request by user works, because a user can have at
most one rental request in the Subnet Rental canister).

***

### GetNeuronIndexRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L347)

#### Properties

##### exclusive\_start\_neuron\_id

> **exclusive\_start\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L349)

##### page\_size

> **page\_size**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L348)

***

### GetNeuronsFundAuditInfoRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L354)

#### Properties

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L355)

***

### GetNeuronsFundAuditInfoResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L357)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_6`](#result_6)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L358)

***

### GetPendingProposalsRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L360)

#### Properties

##### return\_self\_describing\_action

> **return\_self\_describing\_action**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L361)

***

### GlobalTimeOfDay

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L363)

#### Properties

##### seconds\_after\_utc\_midnight

> **seconds\_after\_utc\_midnight**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L364)

***

### Governance

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L366)

#### Properties

##### cached\_daily\_maturity\_modulation\_basis\_points

> **cached\_daily\_maturity\_modulation\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L374)

##### default\_followees

> **default\_followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L367)

##### economics

> **economics**: \[\] \| \[[`NetworkEconomics`](#networkeconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L375)

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L385)

##### in\_flight\_commands

> **in\_flight\_commands**: \[`bigint`, [`NeuronInFlightCommand`](#neuroninflightcommand)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L383)

##### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](#rewardevent)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L378)

##### maturity\_modulation\_last\_updated\_at\_timestamp\_seconds

> **maturity\_modulation\_last\_updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L369)

##### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](#governancecachedmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L371)

##### most\_recent\_monthly\_node\_provider\_rewards

> **most\_recent\_monthly\_node\_provider\_rewards**: \[\] \| \[[`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L368)

##### neuron\_management\_voting\_period\_seconds

> **neuron\_management\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L372)

##### neurons

> **neurons**: \[`bigint`, [`Neuron`](#neuron)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L384)

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L373)

##### proposals

> **proposals**: \[`bigint`, [`ProposalData`](#proposaldata)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L381)

##### restore\_aging\_summary

> **restore\_aging\_summary**: \[\] \| \[[`RestoreAgingSummary`](#restoreagingsummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L376)

##### short\_voting\_period\_seconds

> **short\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L380)

##### spawning\_neurons

> **spawning\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L377)

##### to\_claim\_transfers

> **to\_claim\_transfers**: [`NeuronStakeTransfer`](#neuronstaketransfer)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L379)

##### wait\_for\_quiet\_threshold\_seconds

> **wait\_for\_quiet\_threshold\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L370)

##### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](#xdrconversionrate)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L382)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L387)

#### Properties

##### community\_fund\_total\_maturity\_e8s\_equivalent

> **community\_fund\_total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L401)

##### community\_fund\_total\_staked\_e8s

> **community\_fund\_total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L439)

##### declining\_voting\_power\_neuron\_subset\_metrics

> **declining\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L421)

##### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L400)

##### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L424)

##### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L436)

##### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L431)

##### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L437)

##### dissolving\_neurons\_e8s\_buckets\_ect

> **dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L432)

##### dissolving\_neurons\_e8s\_buckets\_seed

> **dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L426)

##### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L392)

##### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L390)

##### ect\_neuron\_count

> **ect\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L397)

##### fully\_lost\_voting\_power\_neuron\_subset\_metrics

> **fully\_lost\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L413)

##### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L391)

##### neurons\_fund\_total\_active\_neurons

> **neurons\_fund\_total\_active\_neurons**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L416)

##### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L395)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L399)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L427)

##### non\_self\_authenticating\_controller\_neuron\_subset\_metrics

> **non\_self\_authenticating\_controller\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L433)

##### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L414)

##### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L396)

##### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L389)

##### not\_dissolving\_neurons\_e8s\_buckets\_ect

> **not\_dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L419)

##### not\_dissolving\_neurons\_e8s\_buckets\_seed

> **not\_dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L440)

##### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L428)

##### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L423)

##### public\_neuron\_subset\_metrics

> **public\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](#neuronsubsetmetrics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L441)

##### seed\_neuron\_count

> **seed\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L443)

##### spawning\_neurons\_count

> **spawning\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L420)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L442)

##### total\_locked\_e8s

> **total\_locked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L415)

##### total\_maturity\_disbursements\_in\_progress\_e8s\_equivalent

> **total\_maturity\_disbursements\_in\_progress\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L411)

SDK DIVERGENCE: the backend declares this as `nat64` (required) since
ic@3ef6b6f876 (2026-03-06). We keep it `opt nat64` here so the SDK can
still decode responses from canister versions (e.g. bundled dfx wasms,
rolling-release mainnet) that predate the field. Revert to `nat64` once
every consumed canister version is guaranteed to include it.

##### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L388)

##### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L412)

##### total\_staked\_e8s\_ect

> **total\_staked\_e8s\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L422)

##### total\_staked\_e8s\_non\_self\_authenticating\_controller

> **total\_staked\_e8s\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L425)

##### total\_staked\_e8s\_seed

> **total\_staked\_e8s\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L402)

##### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L418)

##### total\_staked\_maturity\_e8s\_equivalent\_ect

> **total\_staked\_maturity\_e8s\_equivalent\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L403)

##### total\_staked\_maturity\_e8s\_equivalent\_seed

> **total\_staked\_maturity\_e8s\_equivalent\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L438)

##### total\_supply\_icp

> **total\_supply\_icp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L398)

##### total\_voting\_power\_non\_self\_authenticating\_controller

> **total\_voting\_power\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L417)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L445)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L446)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L447)

***

### GovernanceParameters

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L449)

#### Properties

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L458)

##### neuron\_maximum\_age\_bonus

> **neuron\_maximum\_age\_bonus**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L454)

##### neuron\_maximum\_age\_for\_age\_bonus

> **neuron\_maximum\_age\_for\_age\_bonus**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L451)

##### neuron\_maximum\_dissolve\_delay

> **neuron\_maximum\_dissolve\_delay**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L452)

##### neuron\_maximum\_dissolve\_delay\_bonus

> **neuron\_maximum\_dissolve\_delay\_bonus**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:450](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L450)

##### neuron\_minimum\_dissolve\_delay\_to\_vote

> **neuron\_minimum\_dissolve\_delay\_to\_vote**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L453)

##### neuron\_minimum\_stake

> **neuron\_minimum\_stake**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L455)

##### proposal\_initial\_voting\_period

> **proposal\_initial\_voting\_period**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L457)

##### proposal\_rejection\_fee

> **proposal\_rejection\_fee**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L459)

##### proposal\_wait\_for\_quiet\_deadline\_increase

> **proposal\_wait\_for\_quiet\_deadline\_increase**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L456)

##### voting\_reward\_parameters

> **voting\_reward\_parameters**: \[\] \| \[[`VotingRewardParameters`](#votingrewardparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L460)

***

### GuestLaunchMeasurement

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L462)

#### Properties

##### measurement

> **measurement**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L470)

SEV-SNP measurement (48 bytes).

##### metadata

> **metadata**: \[\] \| \[[`GuestLaunchMeasurementMetadata`](#guestlaunchmeasurementmetadata-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L466)

Metadata associated with the measurement.

***

### GuestLaunchMeasurementMetadata

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L472)

#### Properties

##### kernel\_cmdline

> **kernel\_cmdline**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L476)

Kernel command line used for this measurement.

***

### GuestLaunchMeasurements

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L478)

#### Properties

##### guest\_launch\_measurements

> **guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurement`](#guestlaunchmeasurement)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:479](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L479)

***

### IdealMatchedParticipationFunction

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L481)

#### Properties

##### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L482)

***

### Image

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L484)

#### Properties

##### base64\_encoding

> **base64\_encoding**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L485)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L487)

#### Properties

##### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L488)

***

### InitialTokenDistribution

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L490)

#### Properties

##### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](#developerdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L492)

##### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](#swapdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L493)

##### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`SwapDistribution`](#swapdistribution)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L491)

***

### InstallCode

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L495)

#### Properties

##### arg\_hash

> **arg\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L499)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L498)

##### install\_mode

> **install\_mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L500)

##### skip\_stopping\_before\_installing

> **skip\_stopping\_before\_installing**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L496)

##### wasm\_module\_hash

> **wasm\_module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L497)

***

### InstallCodeRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L502)

#### Properties

##### arg

> **arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L503)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L511)

##### install\_mode

> **install\_mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L512)

##### skip\_stopping\_before\_installing

> **skip\_stopping\_before\_installing**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L510)

##### wasm\_module

> **wasm\_module**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L509)

If we add support for chunked WASMs later, the WasmModule type should
probably be used in place of this field in order to be consistent with
CreateCanisterAndInstallCodeRequest.

***

### KnownNeuron

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L514)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L515)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L516)

***

### KnownNeuronData

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L518)

#### Properties

##### committed\_topics

> **committed\_topics**: \[\] \| \[(\[\] \| \[[`TopicToFollow`](#topictofollow)\])[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L526)

Topics that the known neuron is committed to always vote on.
Note regarding the type: the first `opt` makes it so that the field can be renamed/deprecated
in the future, and the second `opt` makes it so that an older client not recognizing a new
variant can still get the rest of the `vec`.

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L527)

##### links

> **links**: \[\] \| \[`string`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L531)

Links related to the known neuron. Can be links to social URLs (OpenChat, X, etc.), or a homepage.

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L519)

***

### LedgerParameters

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L533)

#### Properties

##### token\_logo

> **token\_logo**: \[\] \| \[[`Image`](#image)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L536)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L537)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L535)

##### transaction\_fee

> **transaction\_fee**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L534)

***

### ListKnownNeuronsResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L539)

#### Properties

##### known\_neurons

> **known\_neurons**: [`KnownNeuron`](#knownneuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L540)

***

### ListNeurons

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L579)

Parameters of the list_neurons method.

#### Properties

##### include\_empty\_neurons\_readable\_by\_caller

> **include\_empty\_neurons\_readable\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:595](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L595)

Only has an effect when include_neurons_readable_by_caller.

##### include\_neurons\_readable\_by\_caller

> **include\_neurons\_readable\_by\_caller**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:597](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L597)

##### include\_public\_neurons\_in\_full\_neurons

> **include\_public\_neurons\_in\_full\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:586](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L586)

When a public neuron is a member of the result set, include it in the
full_neurons field (of ListNeuronsResponse). This does not affect which
neurons are part of the result set.

##### neuron\_ids

> **neuron\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:590](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L590)

These fields select neurons to be in the result set.

##### neuron\_subaccounts

> **neuron\_subaccounts**: \[\] \| \[[`NeuronSubaccount`](#neuronsubaccount)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L596)

##### page\_number

> **page\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L591)

##### page\_size

> **page\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L580)

***

### ListNeuronsResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:602](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L602)

Output of the list_neurons method.

#### Properties

##### full\_neurons

> **full\_neurons**: [`Neuron`](#neuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L615)

If the caller has the necessary special privileges (or the neuron is
public, and the request sets include_public_neurons_in_full_neurons to
true), then all the information about the neurons in the result set is made
available here.

##### neuron\_infos

> **neuron\_infos**: \[`bigint`, [`NeuronInfo`](#neuroninfo)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:608](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L608)

Per the NeuronInfo type, this is a redacted view of the neurons in the
result set consisting of information that require no special privileges to
view.

##### total\_pages\_available

> **total\_pages\_available**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L616)

***

### ListNeuronVotesRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L542)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L547)

Only fetch the voting history for proposal whose id `< before_proposal`. This can be used as a
pagination token - pass the minimum proposal id as `before_proposal` for the next page.

##### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L552)

The maximum number of votes to fetch. The maximum number allowed is 500, and 500 will be used
if is set as either null or > 500.

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L557)

The neuron id for which the voting history will be returned. Currently, the voting history is
only recorded for known neurons.

***

### ListNodeProviderRewardsRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L618)

#### Properties

##### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](#daterangefilter)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:619](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L619)

***

### ListNodeProviderRewardsResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L621)

#### Properties

##### rewards

> **rewards**: [`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L622)

***

### ListNodeProvidersResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L624)

#### Properties

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L625)

***

### ListProposalInfoRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L627)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L631)

##### exclude\_topic

> **exclude\_topic**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L633)

##### include\_all\_manage\_neuron\_proposals

> **include\_all\_manage\_neuron\_proposals**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L634)

##### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:629](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L629)

##### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L635)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L632)

##### omit\_large\_fields

> **omit\_large\_fields**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L630)

##### return\_self\_describing\_action

> **return\_self\_describing\_action**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:628](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L628)

***

### ListProposalInfoResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:637](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L637)

#### Properties

##### proposal\_info

> **proposal\_info**: [`ProposalInfo`](#proposalinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L638)

***

### LoadCanisterSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L640)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L641)

##### snapshot\_id

> **snapshot\_id**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L642)

***

### MakeProposalRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L644)

#### Properties

##### action

> **action**: \[\] \| \[[`ProposalActionRequest`](#proposalactionrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L647)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:648](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L648)

##### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:646](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L646)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L645)

***

### MakeProposalResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:650](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L650)

#### Properties

##### message

> **message**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L651)

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:652](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L652)

***

### ManageNeuronProposal

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L677)

Not to be confused with ManageNeuronRequest. This is only used to represent a manage neuron proposal.
(Yes, this is very structurally similar to that, but not actually exactly equivalent)

#### Properties

##### command

> **command**: \[\] \| \[[`ManageNeuronProposalCommand`](#manageneuronproposalcommand-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:679](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L679)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:678](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L678)

##### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L680)

***

### ManageNeuronRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:704](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L704)

Parameters of the manage_neuron method.

#### Properties

##### command

> **command**: \[\] \| \[[`ManageNeuronCommandRequest`](#manageneuroncommandrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:712](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L712)

What operation to perform on the neuron.

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:708](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L708)

Deprecated. Use neuron_id_or_subaccount instead.

##### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](#neuronidorsubaccount)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:716](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L716)

Which neuron to operate on.

***

### ManageNeuronResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:721](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L721)

Output of the manage_neuron method.

#### Properties

##### command

> **command**: \[\] \| \[[`Command_1`](#command_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:726](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L726)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.

***

### MaturityDisbursement

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L728)

#### Properties

##### account\_identifier\_to\_disburse\_to

> **account\_identifier\_to\_disburse\_to**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:729](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L729)

##### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L732)

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:731](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L731)

##### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:733](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L733)

##### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:730](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L730)

***

### Merge

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:735](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L735)

#### Properties

##### source\_neuron\_id

> **source\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:736](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L736)

***

### MergeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:738](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L738)

#### Properties

##### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L739)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:741](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L741)

#### Properties

##### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L742)

##### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:743](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L743)

***

### MergeResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:745](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L745)

#### Properties

##### source\_neuron

> **source\_neuron**: \[\] \| \[[`Neuron`](#neuron)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L747)

##### source\_neuron\_info

> **source\_neuron\_info**: \[\] \| \[[`NeuronInfo`](#neuroninfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L749)

##### target\_neuron

> **target\_neuron**: \[\] \| \[[`Neuron`](#neuron)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:746](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L746)

##### target\_neuron\_info

> **target\_neuron\_info**: \[\] \| \[[`NeuronInfo`](#neuroninfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:748](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L748)

***

### MonthlyNodeProviderRewards

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L751)

#### Properties

##### algorithm\_version

> **algorithm\_version**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L752)

##### end\_date

> **end\_date**: \[\] \| \[[`DateUtc`](#dateutc)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L754)

##### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:761](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L761)

##### minimum\_xdr\_permyriad\_per\_icp

> **minimum\_xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:753](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L753)

##### node\_providers

> **node\_providers**: [`NodeProvider`](#nodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:756](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L756)

##### registry\_version

> **registry\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:755](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L755)

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L759)

##### start\_date

> **start\_date**: \[\] \| \[[`DateUtc`](#dateutc)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:757](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L757)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:758](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L758)

##### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](#xdrconversionrate)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:760](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L760)

***

### Motion

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:763](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L763)

#### Properties

##### motion\_text

> **motion\_text**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:764](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L764)

***

### NetworkEconomics

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:766](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L766)

#### Properties

##### max\_proposals\_to\_keep\_per\_topic

> **max\_proposals\_to\_keep\_per\_topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L772)

##### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:778](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L778)

##### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:777](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L777)

##### neuron\_management\_fee\_per\_proposal\_e8s

> **neuron\_management\_fee\_per\_proposal\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:773](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L773)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:767](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L767)

##### neuron\_spawn\_dissolve\_delay\_seconds

> **neuron\_spawn\_dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L776)

##### neurons\_fund\_economics

> **neurons\_fund\_economics**: \[\] \| \[[`NeuronsFundEconomics`](#neuronsfundeconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L779)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:774](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L774)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L775)

##### voting\_power\_economics

> **voting\_power\_economics**: \[\] \| \[[`VotingPowerEconomics`](#votingpowereconomics)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L771)

Parameters that affect the voting power of neurons.

***

### Neuron

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:781](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L781)

#### Properties

##### account

> **account**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:855](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L855)

##### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:853](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L853)

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:852](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L852)

##### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:850](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L850)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:784](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L784)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:851](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L851)

##### deciding\_voting\_power

> **deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:849](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L849)

The amount of "sway" this neuron has when voting on proposals.

When a proposal is created, each eligible neuron gets a "blank" ballot. The
amount of voting power in that ballot is set to the neuron's deciding
voting power at the time of proposal creation. There are two ways that a
proposal can become decided:

1. Early: Either more than half of the total voting power in the ballots
votes in favor (then the proposal is approved), or at least half of the
votal voting power in the ballots votes against (then, the proposal is
rejected).

2. The proposal's voting deadline is reached. At that point, if there is
more voting power in favor than against, and at least 3% of the total
voting power voted in favor, then the proposal is approved. Otherwise, it
is rejected.

If a neuron regularly refreshes its voting power, this has the same value
as potential_voting_power. Actions that cause a refresh are as follows:

1. voting directly (not via following)
2. set following
3. refresh voting power

(All of these actions are performed via the manage_neuron method.)

However, if a neuron has not refreshed in a "long" time, this will be less
than potential voting power. See VotingPowerEconomics. As a further result
of less deciding voting power, not only does it have less influence on the
outcome of proposals, the neuron receives less voting rewards (when it
votes indirectly via following).

For details, see https://dashboard.internetcomputer.org/proposal/132411.

Per NNS policy, this is opt. Nevertheless, it will never be null.

##### dissolve\_state

> **dissolve\_state**: \[\] \| \[[`DissolveState`](#dissolvestate)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L869)

##### eight\_year\_gang\_bonus\_base\_e8s

> **eight\_year\_gang\_bonus\_base\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:863](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L863)

Base value (in e8s) used for the "8-year gang" dissolve delay bonus. For neurons that had the
maximum dissolve delay of 8 years before the maximum was reduced, this is set to the total
staked value net of fees (including staked maturity) captured at the time of migration.
For all other neurons, this is 0.

##### followees

> **followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:870](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L870)

##### hot\_keys

> **hot\_keys**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:854](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L854)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:782](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L782)

##### joined\_community\_fund\_timestamp\_seconds

> **joined\_community\_fund\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L856)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L874)

##### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:787](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L787)

##### maturity\_disbursements\_in\_progress

> **maturity\_disbursements\_in\_progress**: \[\] \| \[[`MaturityDisbursement`](#maturitydisbursement)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:868](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L868)

The maturity disbursements in progress, i.e. the disbursements that are initiated but not
finalized. The finalization happens 7 days after the disbursement is initiated.

##### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:811](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L811)

##### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:871](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L871)

##### neuron\_type

> **neuron\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:809](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L809)

##### not\_for\_profit

> **not\_for\_profit**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:810](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L810)

##### potential\_voting\_power

> **potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:808](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L808)

The amount of "sway" this neuron can have if it refreshes its voting power
frequently enough.

Unlike deciding_voting_power, this does NOT take refreshing into account.
Rather, this only takes three factors into account:

1. (Net) staked amount - This is the "base" of a neuron's voting power.
This primarily consists of the neuron's ICP balance.

2. Age - Neurons with more age have more voting power (all else being
equal).

3. Dissolve delay - Neurons with longer dissolve delay have more voting
power (all else being equal). Neurons with a dissolve delay of less
than six months are not eligible to vote. Therefore, such neurons
are considered to have 0 voting power.

Per NNS policy, this is opt. Nevertheless, it will never be null.

##### recent\_ballots

> **recent\_ballots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:785](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L785)

##### spawn\_at\_timestamp\_seconds

> **spawn\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L875)

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:783](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L783)

##### transfer

> **transfer**: \[\] \| \[[`NeuronStakeTransfer`](#neuronstaketransfer)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L873)

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:872](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L872)

##### voting\_power\_refreshed\_timestamp\_seconds

> **voting\_power\_refreshed\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:786](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L786)

***

### NeuronBasketConstructionParameters

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:877](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L877)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:879](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L879)

##### dissolve\_delay\_interval

> **dissolve\_delay\_interval**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:878](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L878)

***

### NeuronBasketConstructionParameters\_1

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:881](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L881)

#### Properties

##### count

> **count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:883](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L883)

##### dissolve\_delay\_interval\_seconds

> **dissolve\_delay\_interval\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:882](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L882)

***

### NeuronDistribution

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L885)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L886)

##### dissolve\_delay

> **dissolve\_delay**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L887)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L888)

##### stake

> **stake**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L890)

##### vesting\_period

> **vesting\_period**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L889)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:892](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L892)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L893)

***

### NeuronIndexData

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:902](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L902)

#### Properties

##### neurons

> **neurons**: [`NeuronInfo`](#neuroninfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:903](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L903)

***

### NeuronInFlightCommand

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L898)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_2`](#command_2)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:899](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L899)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L900)

***

### NeuronInfo

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L913)

A limit view of Neuron that allows some aspects of all neurons to be read by
anyone (i.e. without having to be the neuron's controller nor one of its
hotkeys).

As such, the meaning of each field in this type is generally the same as the
one of the same (or at least similar) name in Neuron.

#### Properties

##### age\_seconds

> **age\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L949)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:921](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L921)

##### deciding\_voting\_power

> **deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:920](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L920)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L915)

##### eight\_year\_gang\_bonus\_base\_e8s

> **eight\_year\_gang\_bonus\_base\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:935](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L935)

See analogous field in Neuron.

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L914)

##### joined\_community\_fund\_timestamp\_seconds

> **joined\_community\_fund\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:931](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L931)

##### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](#knownneurondata)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:938](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L938)

##### neuron\_type

> **neuron\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:919](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L919)

##### potential\_voting\_power

> **potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:918](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L918)

##### recent\_ballots

> **recent\_ballots**: [`BallotInfo`](#ballotinfo)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L916)

##### retrieved\_at\_timestamp\_seconds

> **retrieved\_at\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:936](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L936)

##### stake\_e8s

> **stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:930](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L930)

The amount of ICP (and staked maturity) locked in this neuron.

This is the foundation of the neuron's voting power.

cached_neuron_stake_e8s - neuron_fees_e8s + staked_maturity_e8s_equivalent

##### state

> **state**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L922)

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:937](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L937)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L948)

Deprecated. Use either deciding_voting_power or potential_voting_power
instead. Has the same value as deciding_voting_power.

Previously, if a neuron had < 6 months dissolve delay (making it ineligible
to vote), this would not get set to 0 (zero). That was pretty confusing.
Now that this is set to deciding_voting_power, this actually does get
zeroed out.

##### voting\_power\_refreshed\_timestamp\_seconds

> **voting\_power\_refreshed\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:917](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L917)

***

### NeuronsFundAuditInfo

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:986](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L986)

#### Properties

##### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:987](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L987)

##### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:988](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L988)

##### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:989](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L989)

***

### NeuronsFundData

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:991](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L991)

#### Properties

##### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:992](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L992)

##### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](#neuronsfundparticipation)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:993](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L993)

##### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:994](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L994)

***

### NeuronsFundEconomics

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:996](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L996)

#### Properties

##### max\_theoretical\_neurons\_fund\_participation\_amount\_xdr

> **max\_theoretical\_neurons\_fund\_participation\_amount\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1001](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1001)

##### maximum\_icp\_xdr\_rate

> **maximum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:997](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L997)

##### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1002](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1002)

##### neurons\_fund\_matched\_funding\_curve\_coefficients

> **neurons\_fund\_matched\_funding\_curve\_coefficients**: \[\] \| \[[`NeuronsFundMatchedFundingCurveCoefficients`](#neuronsfundmatchedfundingcurvecoefficients)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:998](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L998)

***

### NeuronsFundMatchedFundingCurveCoefficients

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1004](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1004)

#### Properties

##### contribution\_threshold\_xdr

> **contribution\_threshold\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1005](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1005)

##### full\_participation\_milestone\_xdr

> **full\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1007](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1007)

##### one\_third\_participation\_milestone\_xdr

> **one\_third\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1006](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1006)

***

### NeuronsFundNeuron

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1009)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1014](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1014)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1010](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1010)

##### hotkeys

> **hotkeys**: \[\] \| \[[`Principals`](#principals-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1011](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1011)

##### is\_capped

> **is\_capped**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1012](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1012)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1013](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1013)

***

### NeuronsFundNeuronPortion

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1016](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1016)

#### Properties

##### amount\_icp\_e8s

> **amount\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1022](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1022)

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1017](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1017)

##### hotkeys

> **hotkeys**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1018](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1018)

##### is\_capped

> **is\_capped**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1019](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1019)

##### maturity\_equivalent\_icp\_e8s

> **maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1020](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1020)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1021](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1021)

***

### NeuronsFundParticipation

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1024](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1024)

#### Properties

##### allocated\_neurons\_fund\_participation\_icp\_e8s

> **allocated\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1034](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1034)

##### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1027](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1027)

##### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](#idealmatchedparticipationfunction)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1031](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1031)

##### intended\_neurons\_fund\_participation\_icp\_e8s

> **intended\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1026](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1026)

##### max\_neurons\_fund\_swap\_participation\_icp\_e8s

> **max\_neurons\_fund\_swap\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1029](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1029)

##### neurons\_fund\_reserves

> **neurons\_fund\_reserves**: \[\] \| \[[`NeuronsFundSnapshot`](#neuronsfundsnapshot)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1030](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1030)

##### swap\_participation\_limits

> **swap\_participation\_limits**: \[\] \| \[[`SwapParticipationLimits`](#swapparticipationlimits)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1028](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1028)

##### total\_maturity\_equivalent\_icp\_e8s

> **total\_maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1025](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1025)

***

### NeuronsFundSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1036](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1036)

#### Properties

##### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuronPortion`](#neuronsfundneuronportion)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1037](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1037)

***

### NeuronStakeTransfer

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:951](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L951)

#### Properties

##### block\_height

> **block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:958](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L958)

##### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:954](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L954)

##### from\_subaccount

> **from\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:956](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L956)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:955](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L955)

##### neuron\_stake\_e8s

> **neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:953](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L953)

##### to\_subaccount

> **to\_subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:952](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L952)

##### transfer\_timestamp

> **transfer\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:957](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L957)

***

### NeuronSubaccount

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:960](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L960)

#### Properties

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:961](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L961)

***

### NeuronSubsetMetrics

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:963](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L963)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:968](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L968)

##### count\_buckets

> **count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:977](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L977)

##### deciding\_voting\_power\_buckets

> **deciding\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:969](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L969)

##### maturity\_e8s\_equivalent\_buckets

> **maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:965](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L965)

##### potential\_voting\_power\_buckets

> **potential\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:976](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L976)

##### staked\_e8s\_buckets

> **staked\_e8s\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:974](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L974)

##### staked\_maturity\_e8s\_equivalent\_buckets

> **staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:973](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L973)

##### total\_deciding\_voting\_power

> **total\_deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:972](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L972)

##### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:964](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L964)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:971](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L971)

##### total\_staked\_e8s

> **total\_staked\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:967](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L967)

##### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:970](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L970)

##### total\_voting\_power

> **total\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:975](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L975)

##### voting\_power\_buckets

> **voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:966](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L966)

***

### NeuronVote

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:979](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L979)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:984](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L984)

##### vote

> **vote**: \[\] \| \[[`Vote`](#vote-4)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:983](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L983)

The vote of the neuron on the specific proposal id.

***

### NodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1039](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1039)

#### Properties

##### id

> **id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1040](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1040)

##### reward\_account

> **reward\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1041](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1041)

***

### Ok

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1043](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1043)

#### Properties

##### neurons\_fund\_audit\_info

> **neurons\_fund\_audit\_info**: \[\] \| \[[`NeuronsFundAuditInfo`](#neuronsfundauditinfo)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1044](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1044)

***

### Ok\_1

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1046](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1046)

#### Properties

##### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuron`](#neuronsfundneuron)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1047](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1047)

***

### OpenSnsTokenSwap

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1049](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1049)

#### Properties

##### community\_fund\_investment\_e8s

> **community\_fund\_investment\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1050](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1050)

##### params

> **params**: \[\] \| \[[`Params`](#params-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1052](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1052)

##### target\_swap\_canister\_id

> **target\_swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1051](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1051)

***

### Params

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1065](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1065)

#### Properties

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1078](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1078)

##### max\_icp\_e8s

> **max\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1070](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1070)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1075](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1075)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1076](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1076)

##### min\_icp\_e8s

> **min\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1077](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1077)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1066](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1066)

##### min\_participants

> **min\_participants**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1072](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1072)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters_1`](#neuronbasketconstructionparameters_1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1067](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1067)

##### sale\_delay\_seconds

> **sale\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1074](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1074)

##### sns\_token\_e8s

> **sns\_token\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1073](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1073)

##### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1071](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1071)

***

### Percentage

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1080](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1080)

#### Properties

##### basis\_points

> **basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1081](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1081)

***

### Principals

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1083](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1083)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1084](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1084)

***

### Proposal

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1086](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1086)

#### Properties

##### action

> **action**: \[\] \| \[[`Action`](#action-3)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1089](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1089)

##### self\_describing\_action

> **self\_describing\_action**: \[\] \| \[[`SelfDescribingProposalAction`](#selfdescribingproposalaction)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1091](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1091)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1090](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1090)

##### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1088](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1088)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1087](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1087)

***

### ProposalData

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1113](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1113)

#### Properties

##### ballots

> **ballots**: \[`bigint`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1117)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1127)

##### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](#derivedproposalinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1123)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1131)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1120)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1116](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1116)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1114)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1124](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1124)

##### neurons\_fund\_data

> **neurons\_fund\_data**: \[\] \| \[[`NeuronsFundData`](#neuronsfunddata)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1121)

##### original\_total\_community\_fund\_maturity\_e8s\_equivalent

> **original\_total\_community\_fund\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1132)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1128)

##### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1118)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1129)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1122)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1119)

##### sns\_token\_swap\_lifecycle

> **sns\_token\_swap\_lifecycle**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1126](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1126)

##### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1115)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1125](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1125)

##### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](#waitforquietstate)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1130](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1130)

***

### ProposalId

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1134)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1135)

***

### ProposalInfo

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1137)

#### Properties

##### ballots

> **ballots**: \[`bigint`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1142](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1142)

##### deadline\_timestamp\_seconds

> **deadline\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1145](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1145)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1152](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1152)

##### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](#derivedproposalinformation)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1148](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1148)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1155](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1155)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1146](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1146)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1141)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1138)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1149](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1149)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1153](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1153)

##### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1143](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1143)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1154](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1154)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1147](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1147)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1144](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1144)

##### reward\_status

> **reward\_status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1151](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1151)

##### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1139](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1139)

##### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1140](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1140)

##### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1150](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1150)

***

### RegisterVote

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1164](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1164)

#### Properties

##### proposal

> **proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1166](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1166)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1165](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1165)

***

### RemoveHotKey

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1168](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1168)

#### Properties

##### hot\_key\_to\_remove

> **hot\_key\_to\_remove**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1169)

***

### RestoreAgingNeuronGroup

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1171)

#### Properties

##### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1172](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1172)

##### current\_total\_stake\_e8s

> **current\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1174)

##### group\_type

> **group\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1175](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1175)

##### previous\_total\_stake\_e8s

> **previous\_total\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1173)

***

### RestoreAgingSummary

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1177)

#### Properties

##### groups

> **groups**: [`RestoreAgingNeuronGroup`](#restoreagingneurongroup)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1178](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1178)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1179](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1179)

***

### RewardEvent

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1196)

#### Properties

##### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1199](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1199)

##### day\_after\_genesis

> **day\_after\_genesis**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1198](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1198)

##### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1202](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1202)

##### latest\_round\_available\_e8s\_equivalent

> **latest\_round\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1201](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1201)

##### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1197](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1197)

##### settled\_proposals

> **settled\_proposals**: [`ProposalId`](#proposalid)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1203)

##### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1200](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1200)

***

### RewardNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1208](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1208)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1211](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1211)

##### node\_provider

> **node\_provider**: \[\] \| \[[`NodeProvider`](#nodeprovider)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1209](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1209)

##### reward\_mode

> **reward\_mode**: \[\] \| \[[`RewardMode`](#rewardmode)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1210](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1210)

***

### RewardNodeProviders

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1213](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1213)

#### Properties

##### rewards

> **rewards**: [`RewardNodeProvider`](#rewardnodeprovider)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1215](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1215)

##### use\_registry\_derived\_rewards

> **use\_registry\_derived\_rewards**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1214](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1214)

***

### RewardToAccount

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1217](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1217)

#### Properties

##### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1218](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1218)

***

### RewardToNeuron

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1220](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1220)

#### Properties

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1221](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1221)

***

### SelfDescribingProposalAction

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1223](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1223)

#### Properties

##### type\_description

> **type\_description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1224](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1224)

##### type\_name

> **type\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1225)

##### value

> **value**: \[\] \| \[[`SelfDescribingValue`](#selfdescribingvalue)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1226](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1226)

***

### SetDefaultFollowees

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1237](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1237)

#### Properties

##### default\_followees

> **default\_followees**: \[`number`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1238](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1238)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1240](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1240)

#### Properties

##### dissolve\_timestamp\_seconds

> **dissolve\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1241](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1241)

***

### SetFollowing

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1243](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1243)

#### Properties

##### topic\_following

> **topic\_following**: \[\] \| \[[`FolloweesForTopic`](#followeesfortopic)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1244](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1244)

***

### SetOpenTimeWindowRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1247](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1247)

#### Properties

##### open\_time\_window

> **open\_time\_window**: \[\] \| \[[`TimeWindow`](#timewindow)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1248](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1248)

***

### SetSnsTokenSwapOpenTimeWindow

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1250](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1250)

#### Properties

##### request

> **request**: \[\] \| \[[`SetOpenTimeWindowRequest`](#setopentimewindowrequest)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1251)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1252](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1252)

***

### SettleCommunityFundParticipation

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1257](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1257)

#### Properties

##### open\_sns\_token\_swap\_proposal\_id

> **open\_sns\_token\_swap\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1259](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1259)

##### result

> **result**: \[\] \| \[[`Result_8`](#result_8)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1258](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1258)

***

### SettleNeuronsFundParticipationRequest

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1261](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1261)

#### Properties

##### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1263](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1263)

##### result

> **result**: \[\] \| \[[`Result_9`](#result_9)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1262](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1262)

***

### SettleNeuronsFundParticipationResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1265](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1265)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_10`](#result_10)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1266](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1266)

***

### SetVisibility

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1254](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1254)

#### Properties

##### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1255](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1255)

***

### Spawn

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1268](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1268)

#### Properties

##### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1270](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1270)

##### nonce

> **nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1271](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1271)

##### percentage\_to\_spawn

> **percentage\_to\_spawn**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1269](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1269)

***

### SpawnResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1273](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1273)

#### Properties

##### created\_neuron\_id

> **created\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1274](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1274)

***

### Split

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1276](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1276)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1278](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1278)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1277](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1277)

***

### StakeMaturity

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1280](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1280)

#### Properties

##### percentage\_to\_stake

> **percentage\_to\_stake**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1281](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1281)

***

### StakeMaturityResponse

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1283](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1283)

#### Properties

##### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1284](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1284)

##### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1285](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1285)

***

### StopOrStartCanister

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1287](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1287)

#### Properties

##### action

> **action**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1288](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1288)

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1289](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1289)

***

### SwapBackgroundInformation

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1291](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1291)

#### Properties

##### dapp\_canister\_summaries

> **dapp\_canister\_summaries**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1299](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1299)

##### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1293](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1293)

##### governance\_canister\_summary

> **governance\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1297](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1297)

##### ledger\_archive\_canister\_summaries

> **ledger\_archive\_canister\_summaries**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1294](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1294)

##### ledger\_canister\_summary

> **ledger\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1295](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1295)

##### ledger\_index\_canister\_summary

> **ledger\_index\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1292](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1292)

##### root\_canister\_summary

> **root\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1298](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1298)

##### swap\_canister\_summary

> **swap\_canister\_summary**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1296](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1296)

***

### SwapDistribution

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1301](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1301)

#### Properties

##### total

> **total**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1302](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1302)

***

### SwapParameters

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1304](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1304)

#### Properties

##### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1311](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1311)

##### duration

> **duration**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1307](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1307)

##### maximum\_direct\_participation\_icp

> **maximum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1317](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1317)

##### maximum\_icp

> **maximum\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1318](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1318)

##### maximum\_participant\_icp

> **maximum\_participant\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1312](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1312)

##### minimum\_direct\_participation\_icp

> **minimum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1314](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1314)

##### minimum\_icp

> **minimum\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1313](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1313)

##### minimum\_participant\_icp

> **minimum\_participant\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1315](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1315)

##### minimum\_participants

> **minimum\_participants**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1305](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1305)

##### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](#neuronbasketconstructionparameters)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1308](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1308)

##### neurons\_fund\_investment\_icp

> **neurons\_fund\_investment\_icp**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1319](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1319)

##### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1306](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1306)

##### restricted\_countries

> **restricted\_countries**: \[\] \| \[[`Countries`](#countries)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1320](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1320)

##### start\_time

> **start\_time**: \[\] \| \[[`GlobalTimeOfDay`](#globaltimeofday)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1316](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1316)

***

### SwapParticipationLimits

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1322](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1322)

#### Properties

##### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1326](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1326)

##### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1324](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1324)

##### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1325](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1325)

##### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1323](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1323)

***

### TakeCanisterSnapshot

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1328](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1328)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1330](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1330)

##### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1329](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1329)

***

### Tally

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1332](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1332)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1333](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1333)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1336](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1336)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1335](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1335)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1334](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1334)

***

### TimeWindow

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1338](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1338)

#### Properties

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1340](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1340)

##### start\_timestamp\_seconds

> **start\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1339](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1339)

***

### Tokens

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1342](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1342)

#### Properties

##### e8s

> **e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1343](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1343)

***

### UpdateCanisterSettings

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1370](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1370)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1371](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1371)

##### settings

> **settings**: \[\] \| \[[`CanisterSettings`](#canistersettings)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1372](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1372)

***

### UpdateNodeProvider

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1374](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1374)

#### Properties

##### reward\_account

> **reward\_account**: \[\] \| \[[`AccountIdentifier`](#accountidentifier)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1375](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1375)

***

### VotingPowerEconomics

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1389](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1389)

Parameters that affect the voting power of neurons.

#### Properties

##### clear\_following\_after\_seconds

> **clear\_following\_after\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1421](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1421)

After a neuron has experienced voting power reduction for this amount of
time, a couple of things happen:

1. Deciding voting power reaches 0.

2. Its following on topics other than NeuronManagement are cleared.

Initially, set to 1/12 years.

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1410](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1410)

The minimum dissolve delay a neuron must have in order to be eligible to vote.

Neurons with a dissolve delay lower than this threshold will not have
voting power, even if they are otherwise active.

This value is an essential part of the staking mechanism, promoting
long-term alignment with the network's governance.

##### start\_reducing\_voting\_power\_after\_seconds

> **start\_reducing\_voting\_power\_after\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1400](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1400)

If a neuron has not "refreshed" its voting power after this amount of time,
its deciding voting power starts decreasing linearly. See also
clear_following_after_seconds.

For explanation of what "refresh" means in this context, see
https://dashboard.internetcomputer.org/proposal/132411

Initially, set to 0.5 years. (The nominal length of a year is 365.25 days).

***

### VotingRewardParameters

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1423](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1423)

#### Properties

##### final\_reward\_rate

> **final\_reward\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1426](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1426)

##### initial\_reward\_rate

> **initial\_reward\_rate**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1425](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1425)

##### reward\_rate\_transition\_duration

> **reward\_rate\_transition\_duration**: \[\] \| \[[`Duration`](#duration)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1424](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1424)

***

### WaitForQuietState

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1428](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1428)

#### Properties

##### current\_deadline\_timestamp\_seconds

> **current\_deadline\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1429](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1429)

***

### XdrConversionRate

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1432](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1432)

#### Properties

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1434](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1434)

##### xdr\_permyriad\_per\_icp

> **xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1433](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1433)

## Type Aliases

### Action

> **Action** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `ManageNeuron`: [`ManageNeuronProposal`](#manageneuronproposal); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `InstallCode`: [`InstallCode`](#installcode); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCode`](#createcanisterandinstallcode); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `OpenSnsTokenSwap`: [`OpenSnsTokenSwap`](#opensnstokenswap); \} \| \{ `SetSnsTokenSwapOpenTimeWindow`: [`SetSnsTokenSwapOpenTimeWindow`](#setsnstokenswapopentimewindow); \} \| \{ `SetDefaultFollowees`: [`SetDefaultFollowees`](#setdefaultfollowees); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics); \} \| \{ `ApproveGenesisKyc`: [`Principals`](#principals-1); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L20)

***

### By

> **By** = \{ `NeuronIdOrSubaccount`: \{ \}; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](#claimorrefreshneuronfromaccount); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L86)

***

### Change

> **Change** = \{ `ToRemove`: [`NodeProvider`](#nodeprovider); \} \| \{ `ToAdd`: [`NodeProvider`](#nodeprovider); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L116)

***

### Command\_1

> **Command\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Spawn`: [`SpawnResponse`](#spawnresponse); \} \| \{ `Split`: [`SpawnResponse`](#spawnresponse); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](#disbursematurityresponse); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPowerResponse`](#refreshvotingpowerresponse); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](#claimorrefreshresponse); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `Merge`: [`MergeResponse`](#mergeresponse); \} \| \{ `DisburseToNeuron`: [`SpawnResponse`](#spawnresponse); \} \| \{ `SetFollowing`: [`SetFollowingResponse`](#setfollowingresponse); \} \| \{ `MakeProposal`: [`MakeProposalResponse`](#makeproposalresponse); \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](#stakematurityresponse); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](#mergematurityresponse); \} \| \{ `Disburse`: [`DisburseResponse`](#disburseresponse); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L133)

***

### Command\_2

> **Command\_2** = \{ `Spawn`: [`NeuronId`](#neuronid-1); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L150)

***

### CreateNeuronResponse

> **CreateNeuronResponse** = \{ `Ok`: [`CreatedNeuron`](#createdneuron); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L225)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L289)

***

### GetNeuronIndexResult

> **GetNeuronIndexResult** = \{ `Ok`: [`NeuronIndexData`](#neuronindexdata); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L351)

***

### ListNeuronVotesResponse

> **ListNeuronVotesResponse** = \{ `Ok`: \{ `all_finalized_before_proposal`: \[\] \| \[[`ProposalId`](#proposalid)\]; `votes`: \[\] \| \[[`NeuronVote`](#neuronvote)[]\]; \}; \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L559)

***

### ManageNeuronCommandRequest

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](#makeproposalrequest); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:657](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L657)

KEEP THIS IN SYNC WITH COMMAND!

***

### ManageNeuronProposalCommand

> **ManageNeuronProposalCommand** = \{ `Spawn`: [`Spawn`](#spawn); \} \| \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](#refreshvotingpower); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `Merge`: [`Merge`](#merge); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](#disbursetoneuron); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L685)

KEEP THIS IN SYNC WITH ManageNeuronCommandRequest!

***

### NeuronIdOrSubaccount

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `Uint8Array`; \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-1); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L895)

***

### Operation

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](#removehotkey); \} \| \{ `AddHotKey`: [`AddHotKey`](#addhotkey); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay); \} \| \{ `SetVisibility`: [`SetVisibility`](#setvisibility); \} \| \{ `JoinCommunityFund`: \{ \}; \} \| \{ `LeaveCommunityFund`: \{ \}; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1054](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1054)

***

### ProposalActionRequest

> **ProposalActionRequest** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](#knownneuron); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](#fulfillsubnetrentalrequest); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](#manageneuronrequest); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](#loadcanistersnapshot); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](#blessalternativeguestosversion); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](#updatecanistersettings); \} \| \{ `InstallCode`: [`InstallCodeRequest`](#installcoderequest); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](#deregisterknownneuron); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](#takecanistersnapshot); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](#stoporstartcanister); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](#createservicenervoussystem); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](#executennsfunction); \} \| \{ `CreateCanisterAndInstallCode`: [`CreateCanisterAndInstallCodeRequest`](#createcanisterandinstallcoderequest); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](#rewardnodeprovider); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](#rewardnodeproviders); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](#networkeconomics); \} \| \{ `ApproveGenesisKyc`: [`Principals`](#principals-1); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](#addorremovenodeprovider); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1093](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1093)

***

### RefreshVotingPower

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1162](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1162)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.

***

### RefreshVotingPowerResponse

> **RefreshVotingPowerResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1163](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1163)

***

### Result

> **Result** = \{ `Ok`: `null`; \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1181](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1181)

***

### Result\_1

> **Result\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `NeuronId`: [`NeuronId`](#neuronid-1); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1182](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1182)

***

### Result\_10

> **Result\_10** = \{ `Ok`: [`Ok_1`](#ok_1); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1183)

***

### Result\_2

> **Result\_2** = \{ `Ok`: [`Neuron`](#neuron); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1184](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1184)

***

### Result\_3

> **Result\_3** = \{ `Ok`: [`GovernanceCachedMetrics`](#governancecachedmetrics); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1185)

***

### Result\_4

> **Result\_4** = \{ `Ok`: [`MonthlyNodeProviderRewards`](#monthlynodeproviderrewards); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1188)

***

### Result\_5

> **Result\_5** = \{ `Ok`: [`NeuronInfo`](#neuroninfo); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1191](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1191)

***

### Result\_6

> **Result\_6** = \{ `Ok`: [`Ok`](#ok); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1192](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1192)

***

### Result\_7

> **Result\_7** = \{ `Ok`: [`NodeProvider`](#nodeprovider); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1193](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1193)

***

### Result\_8

> **Result\_8** = \{ `Committed`: [`Committed`](#committed); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1194](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1194)

***

### Result\_9

> **Result\_9** = \{ `Committed`: [`Committed_1`](#committed_1); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1195)

***

### RewardMode

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](#rewardtoneuron); \} \| \{ `RewardToAccount`: [`RewardToAccount`](#rewardtoaccount); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1205](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1205)

***

### SelfDescribingValue

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`SelfDescribingValue`](#selfdescribingvalue)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Null`: `null`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`SelfDescribingValue`](#selfdescribingvalue)[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1228)

***

### SetFollowingResponse

> **SetFollowingResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1246](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1246)

***

### TopicToFollow

> **TopicToFollow** = \{ `Kyc`: `null`; \} \| \{ `ServiceNervousSystemManagement`: `null`; \} \| \{ `ApiBoundaryNodeManagement`: `null`; \} \| \{ `ApplicationCanisterManagement`: `null`; \} \| \{ `SubnetRental`: `null`; \} \| \{ `NeuronManagement`: `null`; \} \| \{ `NodeProviderRewards`: `null`; \} \| \{ `SubnetManagement`: `null`; \} \| \{ `ExchangeRate`: `null`; \} \| \{ `CatchAll`: `null`; \} \| \{ `NodeAdmin`: `null`; \} \| \{ `IcOsVersionElection`: `null`; \} \| \{ `ProtocolCanisterManagement`: `null`; \} \| \{ `NetworkEconomics`: `null`; \} \| \{ `IcOsVersionDeployment`: `null`; \} \| \{ `ParticipantManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsAndCommunityFund`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1351](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1351)

A topic that can be followed. It is almost the same as the topic on the
proposal, except that the `CatchAll` is a special value and following on this
`topic` will let the neuron follow the votes on all topics except for
Governance and SnsAndCommunityFund.

***

### Vote

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1377](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1377)

#### Type Declaration

\{ `No`: `null`; \}

##### No

> **No**: `null`

\{ `Yes`: `null`; \}

##### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

##### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.

***

### WasmModule

> **WasmModule** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1431](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1431)

#### Properties

##### Inlined

> **Inlined**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1431](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1431)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1506](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1506)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1507](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/nns/governance.d.ts#L1507)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
