---
title: DeveloperDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L250)

## Properties

### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](NeuronDistribution.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L251)
