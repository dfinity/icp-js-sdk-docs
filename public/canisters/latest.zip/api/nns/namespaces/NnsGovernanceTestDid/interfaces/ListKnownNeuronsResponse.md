---
title: ListKnownNeuronsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L472)

## Properties

### known\_neurons

> **known\_neurons**: [`KnownNeuron`](KnownNeuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L473)
