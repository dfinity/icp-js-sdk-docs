---
title: DisburseToNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L268)

## Properties

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L271)

***

### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L269)

***

### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L270)

***

### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L272)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L273)
