---
title: Follow
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L285)

## Properties

### followees

> **followees**: [`NeuronId`](NeuronId.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L287)

***

### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L286)
