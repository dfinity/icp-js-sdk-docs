---
title: Follow
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L245)

## Properties

### followees

> **followees**: [`NeuronId`](NeuronId.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L247)

***

### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L246)
