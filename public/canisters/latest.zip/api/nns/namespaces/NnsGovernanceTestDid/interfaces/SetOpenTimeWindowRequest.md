---
title: SetOpenTimeWindowRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1208](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L1208)

## Properties

### open\_time\_window

> **open\_time\_window**: \[\] \| \[[`TimeWindow`](TimeWindow.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1209](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L1209)
