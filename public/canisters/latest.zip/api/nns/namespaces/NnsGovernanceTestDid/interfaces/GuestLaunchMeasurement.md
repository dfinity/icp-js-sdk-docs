---
title: GuestLaunchMeasurement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L440)

## Properties

### measurement

> **measurement**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L448)

SEV-SNP measurement (48 bytes).

***

### metadata

> **metadata**: \[\] \| \[[`GuestLaunchMeasurementMetadata`](GuestLaunchMeasurementMetadata.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L444)

Metadata associated with the measurement.
