---
title: GuestLaunchMeasurement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L400)

## Properties

### measurement

> **measurement**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L408)

SEV-SNP measurement (48 bytes).

***

### metadata

> **metadata**: \[\] \| \[[`GuestLaunchMeasurementMetadata`](GuestLaunchMeasurementMetadata.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L404)

Metadata associated with the measurement.
