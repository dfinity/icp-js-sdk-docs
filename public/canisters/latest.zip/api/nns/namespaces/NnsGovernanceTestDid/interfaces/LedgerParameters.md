---
title: LedgerParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L466)

## Properties

### token\_logo

> **token\_logo**: \[\] \| \[[`Image`](Image.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L469)

***

### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L470)

***

### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L468)

***

### transaction\_fee

> **transaction\_fee**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L467)
