---
title: BlessAlternativeGuestOsVersion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L66)

Declares an approved set of alternative replica virtual machine software for
disaster recovery purposes.

## Properties

### base\_guest\_launch\_measurements

> **base\_guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurements`](GuestLaunchMeasurements.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L83)

The version being replaced by this (alternative version) must match this
field (or one of the possibilities therein).

(Here, we refer to the version being replaced as the "base" version.)

***

### chip\_ids

> **chip\_ids**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L76)

AMD Secure Processor chip IDs that are allowed to run this software.
Each chip ID must be exactly 64 bytes.

***

### rootfs\_hash

> **rootfs\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L71)

Hexadecimal fingerprint of the recovery rootfs.
Must contain only hexadecimal characters (0-9, A-F, a-f).
