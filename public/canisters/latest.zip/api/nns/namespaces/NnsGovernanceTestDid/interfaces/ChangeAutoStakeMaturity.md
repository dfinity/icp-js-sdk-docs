---
title: ChangeAutoStakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L115)

## Properties

### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L116)
