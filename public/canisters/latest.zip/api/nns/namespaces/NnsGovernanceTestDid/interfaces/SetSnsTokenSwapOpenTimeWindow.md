---
title: SetSnsTokenSwapOpenTimeWindow
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1211](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L1211)

## Properties

### request

> **request**: \[\] \| \[[`SetOpenTimeWindowRequest`](SetOpenTimeWindowRequest.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1212](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L1212)

***

### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1213](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L1213)
