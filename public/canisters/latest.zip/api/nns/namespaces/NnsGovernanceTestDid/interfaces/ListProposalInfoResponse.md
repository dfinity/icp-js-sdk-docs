---
title: ListProposalInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L610)

## Properties

### proposal\_info

> **proposal\_info**: [`ProposalInfo`](ProposalInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L611)
