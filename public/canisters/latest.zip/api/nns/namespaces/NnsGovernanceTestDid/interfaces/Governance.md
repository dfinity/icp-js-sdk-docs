---
title: Governance
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L352)

## Properties

### cached\_daily\_maturity\_modulation\_basis\_points

> **cached\_daily\_maturity\_modulation\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L360)

***

### default\_followees

> **default\_followees**: \[`number`, [`Followees`](Followees.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L353)

***

### economics

> **economics**: \[\] \| \[[`NetworkEconomics`](NetworkEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L361)

***

### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L371)

***

### in\_flight\_commands

> **in\_flight\_commands**: \[`bigint`, [`NeuronInFlightCommand`](NeuronInFlightCommand.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L369)

***

### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](RewardEvent.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L364)

***

### maturity\_modulation\_last\_updated\_at\_timestamp\_seconds

> **maturity\_modulation\_last\_updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L355)

***

### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](GovernanceCachedMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L357)

***

### most\_recent\_monthly\_node\_provider\_rewards

> **most\_recent\_monthly\_node\_provider\_rewards**: \[\] \| \[[`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L354)

***

### neuron\_management\_voting\_period\_seconds

> **neuron\_management\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L358)

***

### neurons

> **neurons**: \[`bigint`, [`Neuron`](Neuron.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L370)

***

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L359)

***

### proposals

> **proposals**: \[`bigint`, [`ProposalData`](ProposalData.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L367)

***

### restore\_aging\_summary

> **restore\_aging\_summary**: \[\] \| \[[`RestoreAgingSummary`](RestoreAgingSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L362)

***

### short\_voting\_period\_seconds

> **short\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L366)

***

### spawning\_neurons

> **spawning\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L363)

***

### to\_claim\_transfers

> **to\_claim\_transfers**: [`NeuronStakeTransfer`](NeuronStakeTransfer.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L365)

***

### wait\_for\_quiet\_threshold\_seconds

> **wait\_for\_quiet\_threshold\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L356)

***

### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](XdrConversionRate.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L368)
