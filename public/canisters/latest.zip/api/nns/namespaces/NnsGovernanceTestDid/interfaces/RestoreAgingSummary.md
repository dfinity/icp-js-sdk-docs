---
title: RestoreAgingSummary
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1098](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1098)

## Properties

### groups

> **groups**: [`RestoreAgingNeuronGroup`](RestoreAgingNeuronGroup.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1099](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1099)

***

### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1100](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1100)
