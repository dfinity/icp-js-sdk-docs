---
title: InstallCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L433)

## Properties

### arg\_hash

> **arg\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L437)

***

### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L436)

***

### install\_mode

> **install\_mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L438)

***

### skip\_stopping\_before\_installing

> **skip\_stopping\_before\_installing**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L434)

***

### wasm\_module\_hash

> **wasm\_module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L435)
