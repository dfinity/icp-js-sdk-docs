---
title: Tally
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1293](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L1293)

## Properties

### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1294](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L1294)

***

### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1297](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L1297)

***

### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1296](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L1296)

***

### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1295](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L1295)
