---
title: SetFollowing
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1204](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L1204)

## Properties

### topic\_following

> **topic\_following**: \[\] \| \[[`FolloweesForTopic`](FolloweesForTopic.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1205](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L1205)
