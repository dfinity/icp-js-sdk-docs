---
title: ProposalData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1034](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1034)

## Properties

### ballots

> **ballots**: \[`bigint`, [`Ballot`](Ballot.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1038](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1038)

***

### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1048](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1048)

***

### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](DerivedProposalInformation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1044](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1044)

***

### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1052](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1052)

***

### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1041](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1041)

***

### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](GovernanceError.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1037](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1037)

***

### id

> **id**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1035](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1035)

***

### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](Tally.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1045](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1045)

***

### neurons\_fund\_data

> **neurons\_fund\_data**: \[\] \| \[[`NeuronsFundData`](NeuronsFundData.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1042](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1042)

***

### original\_total\_community\_fund\_maturity\_e8s\_equivalent

> **original\_total\_community\_fund\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1053](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1053)

***

### proposal

> **proposal**: \[\] \| \[[`Proposal`](Proposal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1049](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1049)

***

### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1039](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1039)

***

### proposer

> **proposer**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1050](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1050)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1043](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1043)

***

### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1040](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1040)

***

### sns\_token\_swap\_lifecycle

> **sns\_token\_swap\_lifecycle**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1047](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1047)

***

### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1036](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1036)

***

### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1046](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1046)

***

### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](WaitForQuietState.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1051](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1051)
