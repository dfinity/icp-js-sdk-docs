---
title: MonthlyNodeProviderRewards
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:724](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L724)

## Properties

### algorithm\_version

> **algorithm\_version**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:725](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L725)

***

### end\_date

> **end\_date**: \[\] \| \[[`DateUtc`](DateUtc.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:727](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L727)

***

### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L734)

***

### minimum\_xdr\_permyriad\_per\_icp

> **minimum\_xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:726](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L726)

***

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:729](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L729)

***

### registry\_version

> **registry\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L728)

***

### rewards

> **rewards**: [`RewardNodeProvider`](RewardNodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L732)

***

### start\_date

> **start\_date**: \[\] \| \[[`DateUtc`](DateUtc.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:730](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L730)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:731](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L731)

***

### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](XdrConversionRate.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:733](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L733)
