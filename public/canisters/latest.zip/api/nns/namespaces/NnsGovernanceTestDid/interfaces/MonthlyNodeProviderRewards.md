---
title: MonthlyNodeProviderRewards
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:684](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L684)

## Properties

### algorithm\_version

> **algorithm\_version**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L685)

***

### end\_date

> **end\_date**: \[\] \| \[[`DateUtc`](DateUtc.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:687](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L687)

***

### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:694](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L694)

***

### minimum\_xdr\_permyriad\_per\_icp

> **minimum\_xdr\_permyriad\_per\_icp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:686](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L686)

***

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L689)

***

### registry\_version

> **registry\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:688](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L688)

***

### rewards

> **rewards**: [`RewardNodeProvider`](RewardNodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:692](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L692)

***

### start\_date

> **start\_date**: \[\] \| \[[`DateUtc`](DateUtc.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:690](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L690)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:691](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L691)

***

### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](XdrConversionRate.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:693](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L693)
