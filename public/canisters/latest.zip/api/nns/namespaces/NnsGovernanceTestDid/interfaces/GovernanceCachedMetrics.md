---
title: GovernanceCachedMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L373)

## Properties

### community\_fund\_total\_maturity\_e8s\_equivalent

> **community\_fund\_total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L387)

***

### community\_fund\_total\_staked\_e8s

> **community\_fund\_total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L417)

***

### declining\_voting\_power\_neuron\_subset\_metrics

> **declining\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L399)

***

### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L386)

***

### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L402)

***

### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L414)

***

### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L409)

***

### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L415)

***

### dissolving\_neurons\_e8s\_buckets\_ect

> **dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L410)

***

### dissolving\_neurons\_e8s\_buckets\_seed

> **dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L404)

***

### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L378)

***

### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L376)

***

### ect\_neuron\_count

> **ect\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L383)

***

### fully\_lost\_voting\_power\_neuron\_subset\_metrics

> **fully\_lost\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L391)

***

### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L377)

***

### neurons\_fund\_total\_active\_neurons

> **neurons\_fund\_total\_active\_neurons**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L394)

***

### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L381)

***

### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L385)

***

### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L405)

***

### non\_self\_authenticating\_controller\_neuron\_subset\_metrics

> **non\_self\_authenticating\_controller\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L411)

***

### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L392)

***

### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L382)

***

### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L375)

***

### not\_dissolving\_neurons\_e8s\_buckets\_ect

> **not\_dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L397)

***

### not\_dissolving\_neurons\_e8s\_buckets\_seed

> **not\_dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L418)

***

### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L406)

***

### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L401)

***

### public\_neuron\_subset\_metrics

> **public\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L419)

***

### seed\_neuron\_count

> **seed\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L421)

***

### spawning\_neurons\_count

> **spawning\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L398)

***

### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L420)

***

### total\_locked\_e8s

> **total\_locked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L393)

***

### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L374)

***

### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L390)

***

### total\_staked\_e8s\_ect

> **total\_staked\_e8s\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L400)

***

### total\_staked\_e8s\_non\_self\_authenticating\_controller

> **total\_staked\_e8s\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L403)

***

### total\_staked\_e8s\_seed

> **total\_staked\_e8s\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L388)

***

### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L396)

***

### total\_staked\_maturity\_e8s\_equivalent\_ect

> **total\_staked\_maturity\_e8s\_equivalent\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L389)

***

### total\_staked\_maturity\_e8s\_equivalent\_seed

> **total\_staked\_maturity\_e8s\_equivalent\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L416)

***

### total\_supply\_icp

> **total\_supply\_icp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L384)

***

### total\_voting\_power\_non\_self\_authenticating\_controller

> **total\_voting\_power\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L395)
