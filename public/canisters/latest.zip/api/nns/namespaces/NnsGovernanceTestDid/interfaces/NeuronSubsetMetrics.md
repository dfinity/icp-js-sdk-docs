---
title: NeuronSubsetMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:925](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L925)

## Properties

### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:930](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L930)

***

### count\_buckets

> **count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:939](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L939)

***

### deciding\_voting\_power\_buckets

> **deciding\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:931](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L931)

***

### maturity\_e8s\_equivalent\_buckets

> **maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:927](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L927)

***

### potential\_voting\_power\_buckets

> **potential\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:938](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L938)

***

### staked\_e8s\_buckets

> **staked\_e8s\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:936](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L936)

***

### staked\_maturity\_e8s\_equivalent\_buckets

> **staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:935](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L935)

***

### total\_deciding\_voting\_power

> **total\_deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:934](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L934)

***

### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:926](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L926)

***

### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:933](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L933)

***

### total\_staked\_e8s

> **total\_staked\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:929](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L929)

***

### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:932](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L932)

***

### total\_voting\_power

> **total\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:937](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L937)

***

### voting\_power\_buckets

> **voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:928](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L928)
