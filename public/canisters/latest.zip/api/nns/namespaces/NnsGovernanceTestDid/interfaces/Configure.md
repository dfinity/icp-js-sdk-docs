---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L168)

## Properties

### operation

> **operation**: \[\] \| \[[`Operation`](../type-aliases/Operation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L169)
