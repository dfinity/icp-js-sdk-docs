---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L168)

## Properties

### operation

> **operation**: \[\] \| \[[`Operation`](../type-aliases/Operation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/governance_test.d.ts#L169)
