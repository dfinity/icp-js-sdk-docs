---
title: IncreaseDissolveDelay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L425)

## Properties

### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L426)
