---
title: IncreaseDissolveDelay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L465)

## Properties

### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/governance_test.d.ts#L466)
