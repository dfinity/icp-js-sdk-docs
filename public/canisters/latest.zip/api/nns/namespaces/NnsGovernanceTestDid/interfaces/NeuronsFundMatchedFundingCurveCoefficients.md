---
title: NeuronsFundMatchedFundingCurveCoefficients
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:926](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L926)

## Properties

### contribution\_threshold\_xdr

> **contribution\_threshold\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:927](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L927)

***

### full\_participation\_milestone\_xdr

> **full\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:929](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L929)

***

### one\_third\_participation\_milestone\_xdr

> **one\_third\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:928](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/governance_test.d.ts#L928)
