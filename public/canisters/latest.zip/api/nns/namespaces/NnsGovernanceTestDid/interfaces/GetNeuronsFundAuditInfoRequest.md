---
title: GetNeuronsFundAuditInfoRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L300)

## Properties

### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L301)
