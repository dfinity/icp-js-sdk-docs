---
title: StakeMaturityResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1204](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1204)

## Properties

### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1205](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1205)

***

### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1206](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1206)
