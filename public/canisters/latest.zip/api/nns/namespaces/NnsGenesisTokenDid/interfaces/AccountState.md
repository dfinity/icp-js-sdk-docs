---
title: AccountState
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L13)

## Properties

### authenticated\_principal\_id

> **authenticated\_principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L14)

***

### failed\_transferred\_neurons

> **failed\_transferred\_neurons**: [`TransferredNeuron`](TransferredNeuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L18)

***

### has\_claimed

> **has\_claimed**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L20)

***

### has\_donated

> **has\_donated**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L17)

***

### has\_forwarded

> **has\_forwarded**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L21)

***

### icpts

> **icpts**: `number`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L22)

***

### is\_whitelisted\_for\_forwarding

> **is\_whitelisted\_for\_forwarding**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L16)

***

### neuron\_ids

> **neuron\_ids**: [`NeuronId`](NeuronId.md)[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L19)

***

### successfully\_transferred\_neurons

> **successfully\_transferred\_neurons**: [`TransferredNeuron`](TransferredNeuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L15)
