---
title: NeuronId
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/genesis_token.d.ts#L24)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/genesis_token.d.ts#L25)
