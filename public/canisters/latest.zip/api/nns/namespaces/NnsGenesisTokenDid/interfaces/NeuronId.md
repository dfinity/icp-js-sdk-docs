---
title: NeuronId
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L24)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L25)
