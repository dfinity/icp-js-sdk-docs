---
title: NnsGenesisTokenDid
editUrl: false
next: true
prev: true
---

## Interfaces

- [\_SERVICE](interfaces/SERVICE.md)
- [AccountState](interfaces/AccountState.md)
- [NeuronId](interfaces/NeuronId.md)
- [TransferredNeuron](interfaces/TransferredNeuron.md)

## Type Aliases

- [Result](type-aliases/Result.md)
- [Result\_1](type-aliases/Result_1.md)
- [Result\_2](type-aliases/Result_2.md)

## Variables

- [idlFactory](variables/idlFactory.md)
- [init](variables/init.md)
