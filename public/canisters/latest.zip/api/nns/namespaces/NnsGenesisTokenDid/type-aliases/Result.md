---
title: Result
editUrl: false
next: true
prev: true
---

> **Result** = \{ `Ok`: [`NeuronId`](../interfaces/NeuronId.md)[]; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/genesis_token.d.ts#L27)
