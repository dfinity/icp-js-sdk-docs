---
title: Result_2
editUrl: false
next: true
prev: true
---

> **Result\_2** = \{ `Ok`: [`AccountState`](../interfaces/AccountState.md); \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/genesis_token.d.ts#L29)
