---
title: Result_2
editUrl: false
next: true
prev: true
---

> **Result\_2** = \{ `Ok`: [`AccountState`](../interfaces/AccountState.md); \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/declarations/nns/genesis_token.d.ts#L29)
