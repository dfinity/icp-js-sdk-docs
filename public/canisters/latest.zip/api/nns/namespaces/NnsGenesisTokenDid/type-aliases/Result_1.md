---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: `null`; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/genesis_token.d.ts#L28)
