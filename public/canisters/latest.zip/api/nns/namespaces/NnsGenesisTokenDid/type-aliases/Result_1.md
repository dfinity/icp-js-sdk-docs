---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: `null`; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/genesis_token.d.ts#L28)
