---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: `null`; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/declarations/nns/genesis_token.d.ts#L28)
