---
title: idlFactory
editUrl: false
next: true
prev: true
---

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/declarations/nns/genesis_token.d.ts#L45)
