---
title: DissolveState
editUrl: false
next: true
prev: true
---

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:169](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L169)
