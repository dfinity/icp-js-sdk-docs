---
title: PrincipalString
editUrl: false
next: true
prev: true
---

> **PrincipalString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:5](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/common.ts#L5)
