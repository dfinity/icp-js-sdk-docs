---
title: Option
editUrl: false
next: true
prev: true
---

> **Option**\<`T`\> = `T` \| `undefined`

Defined in: [packages/canisters/src/nns/types/common.ts:7](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/common.ts#L7)

## Type Parameters

### T

`T`
