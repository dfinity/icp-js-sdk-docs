---
title: Option
editUrl: false
next: true
prev: true
---

> **Option**\<`T`\> = `T` \| `undefined`

Defined in: [packages/canisters/src/nns/types/common.ts:7](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/common.ts#L7)

## Type Parameters

### T

`T`
