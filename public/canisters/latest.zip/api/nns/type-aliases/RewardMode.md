---
title: RewardMode
editUrl: false
next: true
prev: true
---

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](../interfaces/RewardToNeuron.md); \} \| \{ `RewardToAccount`: [`RewardToAccount`](../interfaces/RewardToAccount.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:548](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L548)
