---
title: RewardMode
editUrl: false
next: true
prev: true
---

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](../interfaces/RewardToNeuron.md); \} \| \{ `RewardToAccount`: [`RewardToAccount`](../interfaces/RewardToAccount.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:548](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L548)
