---
title: NeuronIdOrSubaccount
editUrl: false
next: true
prev: true
---

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `number`[]; \} \| \{ `NeuronId`: [`NeuronId`](NeuronId.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:470](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L470)
