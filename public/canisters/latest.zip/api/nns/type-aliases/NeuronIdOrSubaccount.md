---
title: NeuronIdOrSubaccount
editUrl: false
next: true
prev: true
---

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `number`[]; \} \| \{ `NeuronId`: [`NeuronId`](NeuronId.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:470](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L470)
