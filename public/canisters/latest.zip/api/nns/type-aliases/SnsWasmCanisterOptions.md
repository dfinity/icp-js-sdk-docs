---
title: SnsWasmCanisterOptions
editUrl: false
next: true
prev: true
---

> **SnsWasmCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](../namespaces/SnsWasmDid/interfaces/SERVICE.md)\>

Defined in: [packages/canisters/src/nns/types/sns\_wasm.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/sns_wasm.options.ts#L4)
