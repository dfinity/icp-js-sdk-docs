---
title: SnsWasmCanisterOptions
editUrl: false
next: true
prev: true
---

> **SnsWasmCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](../namespaces/SnsWasmDid/interfaces/SERVICE.md)\>

Defined in: [packages/canisters/src/nns/types/sns\_wasm.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/sns_wasm.options.ts#L4)
