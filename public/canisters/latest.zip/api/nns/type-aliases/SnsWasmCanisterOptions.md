---
title: SnsWasmCanisterOptions
editUrl: false
next: true
prev: true
---

> **SnsWasmCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](../namespaces/SnsWasmDid/interfaces/SERVICE.md)\>

Defined in: [packages/canisters/src/nns/types/sns\_wasm.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/sns_wasm.options.ts#L4)
