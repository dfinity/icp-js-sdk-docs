---
title: ManageNeuronCommandRequest
editUrl: false
next: true
prev: true
---

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](../interfaces/Spawn.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Follow`: [`Follow`](../interfaces/Follow.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `RegisterVote`: [`RegisterVote`](../interfaces/RegisterVote.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SetFollowing`: [`SetFollowing`](../interfaces/SetFollowing.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `StakeMaturity`: [`StakeMaturity`](../interfaces/StakeMaturity.md); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](../interfaces/MakeProposalRequest.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](../interfaces/DisburseMaturity.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:126](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L126)
