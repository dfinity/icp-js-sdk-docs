---
title: NeuronId
editUrl: false
next: true
prev: true
---

> **NeuronId** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:2](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/common.ts#L2)
