---
title: NeuronId
editUrl: false
next: true
prev: true
---

> **NeuronId** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:2](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/common.ts#L2)
