---
title: ProposalActionRequest
editUrl: false
next: true
prev: true
---

> **ProposalActionRequest** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](../interfaces/KnownNeuron.md); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](../interfaces/DeregisterKnownNeuron.md); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](../interfaces/ExecuteNnsFunction.md); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](../interfaces/CreateServiceNervousSystem.md); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](../interfaces/ManageNeuronRequest.md); \} \| \{ `InstallCode`: [`InstallCodeRequest`](../interfaces/InstallCodeRequest.md); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](../interfaces/StopOrStartCanister.md); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](../interfaces/UpdateCanisterSettings.md); \} \| \{ `BlessAlternativeGuestOsVersion`: [`BlessAlternativeGuestOsVersion`](../interfaces/BlessAlternativeGuestOsVersion.md); \} \| \{ `ApproveGenesisKyc`: [`ApproveGenesisKyc`](../interfaces/ApproveGenesisKyc.md); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](../interfaces/NetworkEconomics.md); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](../interfaces/RewardNodeProvider.md); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](../interfaces/RewardNodeProviders.md); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](../interfaces/AddOrRemoveNodeProvider.md); \} \| \{ `Motion`: [`Motion`](../interfaces/Motion.md); \} \| \{ `TakeCanisterSnapshot`: [`TakeCanisterSnapshot`](../interfaces/TakeCanisterSnapshot.md); \} \| \{ `LoadCanisterSnapshot`: [`LoadCanisterSnapshot`](../interfaces/LoadCanisterSnapshot.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:49](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L49)
