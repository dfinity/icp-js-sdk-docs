---
title: CanisterIdString
editUrl: false
next: true
prev: true
---

> **CanisterIdString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/common.ts#L1)
