---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](../interfaces/RemoveHotKey.md); \} \| \{ `AddHotKey`: [`AddHotKey`](../interfaces/AddHotKey.md); \} \| \{ `StopDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `StartDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](../interfaces/IncreaseDissolveDelay.md); \} \| \{ `JoinCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `LeaveCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](../interfaces/SetDissolveTimestamp.md); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](../interfaces/ChangeAutoStakeMaturity.md); \} \| \{ `SetVisibility`: [`SetVisibility`](../interfaces/SetVisibility.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:495](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L495)
