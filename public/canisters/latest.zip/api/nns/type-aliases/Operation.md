---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `RemoveHotKey`: [`RemoveHotKey`](../interfaces/RemoveHotKey.md); \} \| \{ `AddHotKey`: [`AddHotKey`](../interfaces/AddHotKey.md); \} \| \{ `StopDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `StartDissolving`: `Record`\<`string`, `never`\>; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](../interfaces/IncreaseDissolveDelay.md); \} \| \{ `JoinCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `LeaveCommunityFund`: `Record`\<`string`, `never`\>; \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](../interfaces/SetDissolveTimestamp.md); \} \| \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](../interfaces/ChangeAutoStakeMaturity.md); \} \| \{ `SetVisibility`: [`SetVisibility`](../interfaces/SetVisibility.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:495](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L495)
