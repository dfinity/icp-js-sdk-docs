---
title: ProposalId
editUrl: false
next: true
prev: true
---

> **ProposalId** = `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:520](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L520)
