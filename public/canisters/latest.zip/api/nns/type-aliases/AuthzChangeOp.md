---
title: AuthzChangeOp
editUrl: false
next: true
prev: true
---

> **AuthzChangeOp** = \{ `Authorize`: \{ `addSelf`: `boolean`; \}; \} \| \{ `Deauthorize`: `null`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:78](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L78)
