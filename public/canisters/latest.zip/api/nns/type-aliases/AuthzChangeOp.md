---
title: AuthzChangeOp
editUrl: false
next: true
prev: true
---

> **AuthzChangeOp** = \{ `Authorize`: \{ `addSelf`: `boolean`; \}; \} \| \{ `Deauthorize`: `null`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:78](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L78)
