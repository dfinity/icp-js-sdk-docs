---
title: NeuronType
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:151](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L151)

## Enumeration Members

### Ect

> **Ect**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:160](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L160)

***

### Seed

> **Seed**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:157](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L157)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:154](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L154)
