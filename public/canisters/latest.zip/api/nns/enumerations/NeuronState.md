---
title: NeuronState
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:7](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L7)

## Enumeration Members

### Dissolved

> **Dissolved**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:11](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L11)

***

### Dissolving

> **Dissolving**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:10](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L10)

***

### Locked

> **Locked**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:9](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L9)

***

### Spawning

> **Spawning**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:12](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L12)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:8](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L8)
