---
title: LogVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:164](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L164)

## Enumeration Members

### Controllers

> **Controllers**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:167](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L167)

***

### Public

> **Public**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:169](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L169)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:165](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L165)
