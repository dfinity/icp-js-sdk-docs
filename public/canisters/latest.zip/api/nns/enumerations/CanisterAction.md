---
title: CanisterAction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:173](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L173)

## Enumeration Members

### Start

> **Start**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:178](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L178)

***

### Stop

> **Stop**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:176](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L176)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:174](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L174)
