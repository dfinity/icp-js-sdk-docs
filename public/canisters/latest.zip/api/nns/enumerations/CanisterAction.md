---
title: CanisterAction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:173](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L173)

## Enumeration Members

### Start

> **Start**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:178](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L178)

***

### Stop

> **Stop**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:176](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L176)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:174](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L174)
