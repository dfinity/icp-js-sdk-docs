---
title: Vote
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:82](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L82)

## Enumeration Members

### No

> **No**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:85](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L85)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:83](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L83)

***

### Yes

> **Yes**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/enums/governance.enums.ts#L84)
