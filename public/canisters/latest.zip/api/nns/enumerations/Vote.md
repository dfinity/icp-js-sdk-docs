---
title: Vote
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:82](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L82)

## Enumeration Members

### No

> **No**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:85](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L85)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:83](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L83)

***

### Yes

> **Yes**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/enums/governance.enums.ts#L84)
