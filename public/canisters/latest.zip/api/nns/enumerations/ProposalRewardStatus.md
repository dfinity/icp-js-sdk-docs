---
title: ProposalRewardStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:42](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/enums/governance.enums.ts#L42)

## Enumeration Members

### AcceptVotes

> **AcceptVotes**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:47](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/enums/governance.enums.ts#L47)

***

### Ineligible

> **Ineligible**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:57](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/enums/governance.enums.ts#L57)

***

### ReadyToSettle

> **ReadyToSettle**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:51](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/enums/governance.enums.ts#L51)

***

### Settled

> **Settled**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:54](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/enums/governance.enums.ts#L54)

***

### Unknown

> **Unknown**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:43](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/enums/governance.enums.ts#L43)
