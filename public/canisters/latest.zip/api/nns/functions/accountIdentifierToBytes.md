---
title: accountIdentifierToBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierToBytes**(`accountIdentifier`): `Uint8Array`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/utils/account_identifier.utils.ts#L15)

## Parameters

### accountIdentifier

`string`

## Returns

`Uint8Array`
