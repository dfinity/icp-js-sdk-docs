---
title: memoToNeuronAccountIdentifier
editUrl: false
next: true
prev: true
---

> **memoToNeuronAccountIdentifier**(`__namedParameters`): [`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/utils/neurons.utils.ts#L122)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### governanceCanisterId

`Principal`

#### memo

`bigint`

## Returns

[`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)
