---
title: memoToNeuronAccountIdentifier
editUrl: false
next: true
prev: true
---

> **memoToNeuronAccountIdentifier**(`__namedParameters`): [`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/utils/neurons.utils.ts#L122)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### governanceCanisterId

`Principal`

#### memo

`bigint`

## Returns

[`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)
