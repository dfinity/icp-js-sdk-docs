---
title: accountIdentifierFromBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierFromBytes**(`accountIdentifier`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:19](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/utils/account_identifier.utils.ts#L19)

## Parameters

### accountIdentifier

`Uint8Array`

## Returns

`string`
