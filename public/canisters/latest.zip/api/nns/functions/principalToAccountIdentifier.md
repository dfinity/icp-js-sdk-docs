---
title: principalToAccountIdentifier
editUrl: false
next: true
prev: true
---

> **principalToAccountIdentifier**(`principal`, `subAccount?`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:24](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/utils/account_identifier.utils.ts#L24)

## Parameters

### principal

`Principal`

### subAccount?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

`string`
