---
title: principalToAccountIdentifier
editUrl: false
next: true
prev: true
---

> **principalToAccountIdentifier**(`principal`, `subAccount?`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:24](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/utils/account_identifier.utils.ts#L24)

## Parameters

### principal

`Principal`

### subAccount?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

`string`
