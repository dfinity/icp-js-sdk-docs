---
title: votedNeurons
editUrl: false
next: true
prev: true
---

> **votedNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:89](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/utils/neurons.utils.ts#L89)

Filter the neurons that have voted for a proposal.

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal for which some neurons might have already voted.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
