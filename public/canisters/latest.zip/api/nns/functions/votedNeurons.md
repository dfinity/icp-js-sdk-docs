---
title: votedNeurons
editUrl: false
next: true
prev: true
---

> **votedNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:89](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/utils/neurons.utils.ts#L89)

Filter the neurons that have voted for a proposal.

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal for which some neurons might have already voted.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
