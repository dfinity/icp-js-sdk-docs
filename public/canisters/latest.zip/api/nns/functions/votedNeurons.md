---
title: votedNeurons
editUrl: false
next: true
prev: true
---

> **votedNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:89](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/utils/neurons.utils.ts#L89)

Filter the neurons that have voted for a proposal.

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal for which some neurons might have already voted.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
