---
title: memoToNeuronSubaccount
editUrl: false
next: true
prev: true
---

> **memoToNeuronSubaccount**(`__namedParameters`): [`SubAccount`](../../ledger/icp/classes/SubAccount.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/utils/neurons.utils.ts#L101)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### memo

`bigint`

## Returns

[`SubAccount`](../../ledger/icp/classes/SubAccount.md)
