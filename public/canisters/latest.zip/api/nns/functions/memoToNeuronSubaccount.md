---
title: memoToNeuronSubaccount
editUrl: false
next: true
prev: true
---

> **memoToNeuronSubaccount**(`__namedParameters`): [`SubAccount`](../../ledger/icp/classes/SubAccount.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/utils/neurons.utils.ts#L101)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### memo

`bigint`

## Returns

[`SubAccount`](../../ledger/icp/classes/SubAccount.md)
