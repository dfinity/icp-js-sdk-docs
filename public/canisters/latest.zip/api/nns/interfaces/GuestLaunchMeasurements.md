---
title: GuestLaunchMeasurements
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:331](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L331)

## Properties

### guestLaunchMeasurements

> **guestLaunchMeasurements**: [`Option`](../type-aliases/Option.md)\<[`GuestLaunchMeasurement`](GuestLaunchMeasurement.md)[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:332](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L332)
