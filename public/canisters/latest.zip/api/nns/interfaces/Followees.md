---
title: Followees
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:180](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L180)

## Properties

### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:182](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L182)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:181](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L181)
