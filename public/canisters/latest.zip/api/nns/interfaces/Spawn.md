---
title: Spawn
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:576](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L576)

## Properties

### newController

> **newController**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:577](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L577)

***

### percentageToSpawn

> **percentageToSpawn**: `number` \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:578](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L578)
