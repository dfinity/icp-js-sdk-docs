---
title: GovernanceParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:749](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L749)

## Properties

### customProposalCriticality

> **customProposalCriticality**: [`Option`](../type-aliases/Option.md)\<[`CustomProposalCriticality`](CustomProposalCriticality.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:760](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L760)

***

### neuronMaximumAgeBonus

> **neuronMaximumAgeBonus**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:754](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L754)

***

### neuronMaximumAgeForAgeBonus

> **neuronMaximumAgeForAgeBonus**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:751](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L751)

***

### neuronMaximumDissolveDelay

> **neuronMaximumDissolveDelay**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:752](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L752)

***

### neuronMaximumDissolveDelayBonus

> **neuronMaximumDissolveDelayBonus**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:750](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L750)

***

### neuronMinimumDissolveDelayToVote

> **neuronMinimumDissolveDelayToVote**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:753](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L753)

***

### neuronMinimumStake

> **neuronMinimumStake**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:755](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L755)

***

### proposalInitialVotingPeriod

> **proposalInitialVotingPeriod**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:757](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L757)

***

### proposalRejectionFee

> **proposalRejectionFee**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:758](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L758)

***

### proposalWaitForQuietDeadlineIncrease

> **proposalWaitForQuietDeadlineIncrease**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:756](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L756)

***

### votingRewardParameters

> **votingRewardParameters**: [`Option`](../type-aliases/Option.md)\<[`VotingRewardParameters`](VotingRewardParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:759](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L759)
