---
title: AddOrRemoveNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:72](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L72)

## Properties

### change

> **change**: [`Option`](../type-aliases/Option.md)\<[`Change`](../type-aliases/Change.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:73](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L73)
