---
title: AddOrRemoveNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:72](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L72)

## Properties

### change

> **change**: [`Option`](../type-aliases/Option.md)\<[`Change`](../type-aliases/Change.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:73](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L73)
