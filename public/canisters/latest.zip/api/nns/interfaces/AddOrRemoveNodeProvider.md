---
title: AddOrRemoveNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:72](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L72)

## Properties

### change

> **change**: [`Option`](../type-aliases/Option.md)\<[`Change`](../type-aliases/Change.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:73](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L73)
