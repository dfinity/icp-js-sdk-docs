---
title: MergeMaturityResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:366](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L366)

## Properties

### mergedMaturityE8s

> **mergedMaturityE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:367](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L367)

***

### newStakeE8s

> **newStakeE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:368](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L368)
