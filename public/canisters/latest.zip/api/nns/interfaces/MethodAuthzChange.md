---
title: MethodAuthzChange
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:370](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L370)

## Properties

### canister

> **canister**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:373](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L373)

***

### methodName

> **methodName**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:372](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L372)

***

### operation

> **operation**: [`AuthzChangeOp`](../type-aliases/AuthzChangeOp.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:374](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L374)

***

### principal

> **principal**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:371](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L371)
