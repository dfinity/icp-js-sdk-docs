---
title: MakeMotionProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:665](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L665)

## Properties

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:666](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L666)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:670](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L670)

***

### text

> **text**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:669](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L669)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:667](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L667)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:668](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L668)
