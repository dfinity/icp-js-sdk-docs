---
title: GuestLaunchMeasurement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:324](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L324)

## Properties

### measurement

> **measurement**: [`Option`](../type-aliases/Option.md)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:329](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L329)

SEV-SNP measurement (48 bytes).

***

### metadata

> **metadata**: [`Option`](../type-aliases/Option.md)\<[`GuestLaunchMeasurementMetadata`](GuestLaunchMeasurementMetadata.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:325](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L325)
