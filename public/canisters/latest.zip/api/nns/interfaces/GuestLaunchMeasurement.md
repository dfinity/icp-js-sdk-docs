---
title: GuestLaunchMeasurement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:324](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L324)

## Properties

### measurement

> **measurement**: [`Option`](../type-aliases/Option.md)\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:329](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L329)

SEV-SNP measurement (48 bytes).

***

### metadata

> **metadata**: [`Option`](../type-aliases/Option.md)\<[`GuestLaunchMeasurementMetadata`](GuestLaunchMeasurementMetadata.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:325](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L325)
