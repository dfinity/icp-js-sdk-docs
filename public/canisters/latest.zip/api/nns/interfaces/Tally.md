---
title: Tally
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:585](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L585)

## Properties

### no

> **no**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:586](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L586)

***

### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:589](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L589)

***

### total

> **total**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:588](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L588)

***

### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:587](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L587)
