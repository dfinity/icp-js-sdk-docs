---
title: Tally
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:585](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L585)

## Properties

### no

> **no**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:586](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L586)

***

### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:589](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L589)

***

### total

> **total**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:588](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L588)

***

### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:587](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L587)
