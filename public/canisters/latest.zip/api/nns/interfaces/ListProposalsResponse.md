---
title: ListProposalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:269](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L269)

## Properties

### proposals

> **proposals**: [`ProposalInfo`](ProposalInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:270](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L270)
