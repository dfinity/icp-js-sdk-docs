---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:804](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L804)

## Properties

### developerDistribution

> **developerDistribution**: [`Option`](../type-aliases/Option.md)\<[`DeveloperDistribution`](DeveloperDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:806](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L806)

***

### swapDistribution

> **swapDistribution**: [`Option`](../type-aliases/Option.md)\<[`SwapDistribution`](SwapDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:807](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L807)

***

### treasuryDistribution

> **treasuryDistribution**: [`Option`](../type-aliases/Option.md)\<[`SwapDistribution`](SwapDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:805](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L805)
