---
title: DisburseToNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:644](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L644)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:648](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L648)

***

### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:646](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L646)

***

### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:647](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L647)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:645](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L645)

***

### newController

> **newController**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:649](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L649)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:650](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L650)
