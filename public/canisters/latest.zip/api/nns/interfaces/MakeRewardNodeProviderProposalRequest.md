---
title: MakeRewardNodeProviderProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:681](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L681)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:687](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L687)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:682](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L682)

***

### nodeProvider

> **nodeProvider**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:686](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L686)

***

### rewardMode

> **rewardMode**: [`Option`](../type-aliases/Option.md)\<[`RewardMode`](../type-aliases/RewardMode.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:688](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L688)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:684](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L684)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:683](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L683)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:685](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L685)
