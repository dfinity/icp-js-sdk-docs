---
title: SetFollowing
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:166](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L166)

## Properties

### topicFollowing

> **topicFollowing**: [`FolloweesForTopic`](FolloweesForTopic.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:167](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L167)
