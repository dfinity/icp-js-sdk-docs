---
title: SetFollowing
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:166](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L166)

## Properties

### topicFollowing

> **topicFollowing**: [`FolloweesForTopic`](FolloweesForTopic.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:167](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L167)
