---
title: MergeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:359](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L359)

## Properties

### percentageToMerge

> **percentageToMerge**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:360](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L360)
