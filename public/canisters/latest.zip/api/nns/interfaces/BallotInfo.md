---
title: BallotInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:86](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L86)

## Properties

### proposalId

> **proposalId**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:88](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L88)

***

### vote

> **vote**: [`Vote`](../enumerations/Vote.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:87](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L87)
