---
title: BlessAlternativeGuestOsVersion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:334](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L334)

## Properties

### baseGuestLaunchMeasurements

> **baseGuestLaunchMeasurements**: [`Option`](../type-aliases/Option.md)\<[`GuestLaunchMeasurements`](GuestLaunchMeasurements.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:337](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L337)

***

### chipIds

> **chipIds**: [`Option`](../type-aliases/Option.md)\<`Uint8Array`\<`ArrayBufferLike`\>[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:336](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L336)

***

### rootfsHash

> **rootfsHash**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:335](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L335)
