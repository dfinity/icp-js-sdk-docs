---
title: StakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:356](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L356)

## Properties

### percentageToStake

> **percentageToStake**: [`Option`](../type-aliases/Option.md)\<`number`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:357](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L357)
