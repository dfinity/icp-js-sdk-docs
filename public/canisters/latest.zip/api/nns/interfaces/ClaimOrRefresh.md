---
title: ClaimOrRefresh
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:98](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L98)

## Properties

### by

> **by**: [`Option`](../type-aliases/Option.md)\<[`By`](../type-aliases/By.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:99](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L99)
