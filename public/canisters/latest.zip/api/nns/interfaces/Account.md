---
title: Account
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:185](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L185)

## Properties

### owner

> **owner**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:186](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L186)

***

### subaccount

> **subaccount**: [`Option`](../type-aliases/Option.md)\<`number`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:187](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L187)
