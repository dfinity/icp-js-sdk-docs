---
title: NeuronInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:473](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L473)

## Properties

### ageSeconds

> **ageSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:486](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L486)

***

### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:478](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L478)

***

### decidingVotingPower

> **decidingVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:484](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L484)

***

### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:475](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L475)

***

### fullNeuron

> **fullNeuron**: [`Option`](../type-aliases/Option.md)\<[`Neuron`](Neuron.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:487](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L487)

***

### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:480](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L480)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:474](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L474)

***

### neuronType

> **neuronType**: [`Option`](../type-aliases/Option.md)\<[`NeuronType`](../enumerations/NeuronType.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:477](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L477)

***

### potentialVotingPower

> **potentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:485](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L485)

***

### recentBallots

> **recentBallots**: [`BallotInfo`](BallotInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:476](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L476)

***

### retrievedAtTimestampSeconds

> **retrievedAtTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:481](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L481)

***

### state

> **state**: [`NeuronState`](../enumerations/NeuronState.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:479](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L479)

***

### visibility

> **visibility**: [`Option`](../type-aliases/Option.md)\<[`NeuronVisibility`](../enumerations/NeuronVisibility.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:488](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L488)

***

### votingPower

> **votingPower**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:482](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L482)

***

### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:483](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L483)
