---
title: NeuronSubsetMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:823](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L823)

## Properties

### count

> **count**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:828](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L828)

***

### countBuckets

> **countBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:837](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L837)

***

### decidingVotingPowerBuckets

> **decidingVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:829](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L829)

***

### maturityE8sEquivalentBuckets

> **maturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:825](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L825)

***

### potentialVotingPowerBuckets

> **potentialVotingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:836](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L836)

***

### stakedE8sBuckets

> **stakedE8sBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:834](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L834)

***

### stakedMaturityE8sEquivalentBuckets

> **stakedMaturityE8sEquivalentBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:833](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L833)

***

### totalDecidingVotingPower

> **totalDecidingVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:832](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L832)

***

### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:824](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L824)

***

### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:831](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L831)

***

### totalStakedE8s

> **totalStakedE8s**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:827](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L827)

***

### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:830](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L830)

***

### totalVotingPower

> **totalVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:835](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L835)

***

### votingPowerBuckets

> **votingPowerBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:826](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L826)
