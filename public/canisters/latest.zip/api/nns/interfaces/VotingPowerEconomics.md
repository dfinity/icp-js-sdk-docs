---
title: VotingPowerEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:425](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L425)

## Properties

### clearFollowingAfterSeconds

> **clearFollowingAfterSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:428](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L428)

***

### neuronMinimumDissolveDelayToVoteSeconds

> **neuronMinimumDissolveDelayToVoteSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:427](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L427)

***

### startReducingVotingPowerAfterSeconds

> **startReducingVotingPowerAfterSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:426](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L426)
