---
title: DisburseMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:189](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L189)

## Properties

### percentageToDisburse

> **percentageToDisburse**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:192](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L192)

***

### toAccount

> **toAccount**: [`Option`](../type-aliases/Option.md)\<[`Account`](Account.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:190](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L190)

***

### toAccountIdentifier

> **toAccountIdentifier**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:191](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L191)
