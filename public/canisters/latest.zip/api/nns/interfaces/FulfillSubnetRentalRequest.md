---
title: FulfillSubnetRentalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:316](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L316)

## Properties

### nodeIds

> **nodeIds**: `Principal`[] \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:319](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L319)

***

### replicaVersionId

> **replicaVersionId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:318](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L318)

***

### user

> **user**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:317](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L317)
