---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:141](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L141)

## Properties

### operation

> **operation**: [`Option`](../type-aliases/Option.md)\<[`Operation`](../type-aliases/Operation.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:142](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L142)
