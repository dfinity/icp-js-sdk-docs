---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:141](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L141)

## Properties

### operation

> **operation**: [`Option`](../type-aliases/Option.md)\<[`Operation`](../type-aliases/Operation.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:142](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L142)
