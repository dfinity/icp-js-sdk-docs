---
title: CanisterAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:94](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L94)

## Properties

### methodsAuthz

> **methodsAuthz**: [`MethodAuthzInfo`](MethodAuthzInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:95](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L95)
