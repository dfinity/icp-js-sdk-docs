---
title: CanisterAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:94](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L94)

## Properties

### methodsAuthz

> **methodsAuthz**: [`MethodAuthzInfo`](MethodAuthzInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:95](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L95)
