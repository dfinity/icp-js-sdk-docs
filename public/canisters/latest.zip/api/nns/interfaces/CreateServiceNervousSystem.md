---
title: CreateServiceNervousSystem
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:810](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L810)

## Properties

### dappCanisters

> **dappCanisters**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:818](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L818)

***

### description

> **description**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:817](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L817)

***

### fallbackControllerPrincipalIds

> **fallbackControllerPrincipalIds**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:813](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L813)

***

### governanceParameters

> **governanceParameters**: [`Option`](../type-aliases/Option.md)\<[`GovernanceParameters`](GovernanceParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:812](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L812)

***

### initialTokenDistribution

> **initialTokenDistribution**: [`Option`](../type-aliases/Option.md)\<[`InitialTokenDistribution`](InitialTokenDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:820](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L820)

***

### ledgerParameters

> **ledgerParameters**: [`Option`](../type-aliases/Option.md)\<[`LedgerParameters`](LedgerParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:816](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L816)

***

### logo

> **logo**: [`Option`](../type-aliases/Option.md)\<[`Image`](Image.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:814](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L814)

***

### name

> **name**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:815](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L815)

***

### swapParameters

> **swapParameters**: [`Option`](../type-aliases/Option.md)\<[`SwapParameters`](SwapParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:819](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L819)

***

### url

> **url**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:811](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L811)
