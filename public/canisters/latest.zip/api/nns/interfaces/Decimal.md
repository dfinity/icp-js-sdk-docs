---
title: Decimal
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:441](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L441)

## Properties

### humanReadable

> **humanReadable**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:442](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L442)
