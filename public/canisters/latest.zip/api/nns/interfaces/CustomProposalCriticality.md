---
title: CustomProposalCriticality
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:763](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L763)

## Properties

### additionalCriticalNativeActionIds

> **additionalCriticalNativeActionIds**: [`Option`](../type-aliases/Option.md)\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L764)
