---
title: CustomProposalCriticality
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:763](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L763)

## Properties

### additionalCriticalNativeActionIds

> **additionalCriticalNativeActionIds**: [`Option`](../type-aliases/Option.md)\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/bb1236278770c6086849e1503c91c5b484aafc81/packages/canisters/src/nns/types/governance_converters.ts#L764)
