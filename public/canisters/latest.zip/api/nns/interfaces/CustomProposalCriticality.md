---
title: CustomProposalCriticality
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:763](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L763)

## Properties

### additionalCriticalNativeActionIds

> **additionalCriticalNativeActionIds**: [`Option`](../type-aliases/Option.md)\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L764)
