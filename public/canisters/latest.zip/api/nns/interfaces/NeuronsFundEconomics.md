---
title: NeuronsFundEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:430](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L430)

## Properties

### maximumIcpXdrRate

> **maximumIcpXdrRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:431](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L431)

***

### maxTheoreticalNeuronsFundParticipationAmountXdr

> **maxTheoreticalNeuronsFundParticipationAmountXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:433](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L433)

***

### minimumIcpXdrRate

> **minimumIcpXdrRate**: [`Option`](../type-aliases/Option.md)\<[`Percentage`](Percentage.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:434](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L434)

***

### neuronsFundMatchedFundingCurveCoefficients

> **neuronsFundMatchedFundingCurveCoefficients**: [`Option`](../type-aliases/Option.md)\<[`NeuronsFundMatchedFundingCurveCoefficients`](NeuronsFundMatchedFundingCurveCoefficients.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:432](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L432)
