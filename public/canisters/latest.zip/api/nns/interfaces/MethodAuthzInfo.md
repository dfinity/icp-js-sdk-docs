---
title: MethodAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:376](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L376)

## Properties

### methodName

> **methodName**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:377](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L377)

***

### principalIds

> **principalIds**: `ArrayBuffer`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:378](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L378)
