---
title: NeuronDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:792](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L792)

## Properties

### controller

> **controller**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:793](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L793)

***

### dissolveDelay

> **dissolveDelay**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:794](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L794)

***

### memo

> **memo**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:795](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L795)

***

### stake

> **stake**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:797](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L797)

***

### vestingPeriod

> **vestingPeriod**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:796](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L796)
