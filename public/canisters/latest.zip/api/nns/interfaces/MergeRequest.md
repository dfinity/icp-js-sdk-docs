---
title: MergeRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:352](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L352)

## Properties

### sourceNeuronId

> **sourceNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:353](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L353)

***

### targetNeuronId

> **targetNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:354](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L354)
