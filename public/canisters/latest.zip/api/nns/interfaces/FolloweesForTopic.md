---
title: FolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:162](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L162)

## Properties

### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:164](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L164)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:163](https://github.com/dfinity/icp-js-canisters/blob/21b8ab47da4f18e566fa2976dc079000f3b6bcdd/packages/canisters/src/nns/types/governance_converters.ts#L163)
