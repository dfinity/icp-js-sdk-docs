---
title: DisburseToNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:155](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L155)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:158](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L158)

***

### dissolveDelaySeconds

> **dissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:156](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L156)

***

### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:157](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L157)

***

### newController

> **newController**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:159](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L159)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:160](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L160)
