---
title: ChangeAutoStakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:219](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L219)

## Properties

### requestedSettingForAutoStakeMaturity

> **requestedSettingForAutoStakeMaturity**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:220](https://github.com/dfinity/icp-js-canisters/blob/f63af148d6669094c28e1da733b28792af28a90e/packages/canisters/src/nns/types/governance_converters.ts#L220)
