---
title: Proposal
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:513](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L513)

## Properties

### action

> **action**: [`Option`](../type-aliases/Option.md)\<[`Action`](../type-aliases/Action.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:516](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L516)

***

### selfDescribingAction

> **selfDescribingAction**: [`Option`](../type-aliases/Option.md)\<[`SelfDescribingProposalAction`](SelfDescribingProposalAction.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:518](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L518)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:517](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L517)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:514](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L514)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:515](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L515)
