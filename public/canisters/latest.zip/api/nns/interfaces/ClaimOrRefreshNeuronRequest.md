---
title: ClaimOrRefreshNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:105](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L105)

## Properties

### by

> **by**: [`Option`](../type-aliases/Option.md)\<[`By`](../type-aliases/By.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:107](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L107)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:106](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L106)
