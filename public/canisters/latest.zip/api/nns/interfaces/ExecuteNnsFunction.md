---
title: ExecuteNnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:172](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L172)

## Properties

### nnsFunctionId

> **nnsFunctionId**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:173](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L173)

***

### payloadBytes?

> `optional` **payloadBytes**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:174](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L174)
