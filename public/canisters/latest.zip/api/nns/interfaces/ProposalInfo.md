---
title: ProposalInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:522](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L522)

## Properties

### ballots

> **ballots**: [`Ballot`](Ballot.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:524](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L524)

***

### deadlineTimestampSeconds

> **deadlineTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:530](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L530)

***

### decidedTimestampSeconds

> **decidedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:529](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L529)

***

### executedTimestampSeconds

> **executedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:534](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L534)

***

### failedTimestampSeconds

> **failedTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:528](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L528)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:523](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L523)

***

### latestTally

> **latestTally**: [`Option`](../type-aliases/Option.md)\<[`Tally`](Tally.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:531](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L531)

***

### proposal

> **proposal**: [`Option`](../type-aliases/Option.md)\<[`Proposal`](Proposal.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:532](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L532)

***

### proposalTimestampSeconds

> **proposalTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:526](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L526)

***

### proposer

> **proposer**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:533](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L533)

***

### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:525](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L525)

***

### rewardEventRound

> **rewardEventRound**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:527](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L527)

***

### rewardStatus

> **rewardStatus**: [`ProposalRewardStatus`](../enumerations/ProposalRewardStatus.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:537](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L537)

***

### status

> **status**: [`ProposalStatus`](../enumerations/ProposalStatus.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:536](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L536)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:535](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L535)

***

### totalPotentialVotingPower

> **totalPotentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:538](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L538)
