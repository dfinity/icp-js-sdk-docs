---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [SnsGovernanceDid](namespaces/SnsGovernanceDid.md)
- [SnsGovernanceTestDid](namespaces/SnsGovernanceTestDid.md)
- [SnsRootDid](namespaces/SnsRootDid.md)
- [SnsSwapDid](namespaces/SnsSwapDid.md)

## Enumerations

### GetOpenTicketErrorType

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L12)

#### Enumeration Members

##### TYPE\_SALE\_CLOSED

> **TYPE\_SALE\_CLOSED**: `2`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L15)

##### TYPE\_SALE\_NOT\_OPEN

> **TYPE\_SALE\_NOT\_OPEN**: `1`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L14)

##### TYPE\_UNSPECIFIED

> **TYPE\_UNSPECIFIED**: `0`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L13)

***

### NewSaleTicketResponseErrorType

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L19)

#### Enumeration Members

##### TYPE\_INVALID\_PRINCIPAL

> **TYPE\_INVALID\_PRINCIPAL**: `6`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L36)

##### TYPE\_INVALID\_SUBACCOUNT

> **TYPE\_INVALID\_SUBACCOUNT**: `5`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:34](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L34)

##### TYPE\_INVALID\_USER\_AMOUNT

> **TYPE\_INVALID\_USER\_AMOUNT**: `4`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L32)

##### TYPE\_SALE\_CLOSED

> **TYPE\_SALE\_CLOSED**: `2`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L22)

##### TYPE\_SALE\_NOT\_OPEN

> **TYPE\_SALE\_NOT\_OPEN**: `1`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L21)

##### TYPE\_TICKET\_EXISTS

> **TYPE\_TICKET\_EXISTS**: `3`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L27)

##### TYPE\_UNSPECIFIED

> **TYPE\_UNSPECIFIED**: `0`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L20)

***

### SnsNeuronPermissionType

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:2](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L2)

#### Enumeration Members

##### NEURON\_PERMISSION\_TYPE\_CONFIGURE\_DISSOLVE\_STATE

> **NEURON\_PERMISSION\_TYPE\_CONFIGURE\_DISSOLVE\_STATE**: `1`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L7)

##### NEURON\_PERMISSION\_TYPE\_DISBURSE

> **NEURON\_PERMISSION\_TYPE\_DISBURSE**: `5`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L24)

##### NEURON\_PERMISSION\_TYPE\_DISBURSE\_MATURITY

> **NEURON\_PERMISSION\_TYPE\_DISBURSE\_MATURITY**: `8`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L38)

##### NEURON\_PERMISSION\_TYPE\_MANAGE\_PRINCIPALS

> **NEURON\_PERMISSION\_TYPE\_MANAGE\_PRINCIPALS**: `2`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L13)

##### NEURON\_PERMISSION\_TYPE\_MANAGE\_VOTING\_PERMISSION

> **NEURON\_PERMISSION\_TYPE\_MANAGE\_VOTING\_PERMISSION**: `10`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L45)

##### ~~NEURON\_PERMISSION\_TYPE\_MERGE\_MATURITY~~

> **NEURON\_PERMISSION\_TYPE\_MERGE\_MATURITY**: `7`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:34](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L34)

###### Deprecated

##### NEURON\_PERMISSION\_TYPE\_SPLIT

> **NEURON\_PERMISSION\_TYPE\_SPLIT**: `6`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L27)

##### NEURON\_PERMISSION\_TYPE\_STAKE\_MATURITY

> **NEURON\_PERMISSION\_TYPE\_STAKE\_MATURITY**: `9`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L41)

##### NEURON\_PERMISSION\_TYPE\_SUBMIT\_PROPOSAL

> **NEURON\_PERMISSION\_TYPE\_SUBMIT\_PROPOSAL**: `3`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L18)

##### NEURON\_PERMISSION\_TYPE\_UNSPECIFIED

> **NEURON\_PERMISSION\_TYPE\_UNSPECIFIED**: `0`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L3)

##### NEURON\_PERMISSION\_TYPE\_VOTE

> **NEURON\_PERMISSION\_TYPE\_VOTE**: `4`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L21)

***

### SnsProposalDecisionStatus

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L67)

#### Enumeration Members

##### PROPOSAL\_DECISION\_STATUS\_ADOPTED

> **PROPOSAL\_DECISION\_STATUS\_ADOPTED**: `3`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L78)

##### PROPOSAL\_DECISION\_STATUS\_EXECUTED

> **PROPOSAL\_DECISION\_STATUS\_EXECUTED**: `4`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L81)

##### PROPOSAL\_DECISION\_STATUS\_FAILED

> **PROPOSAL\_DECISION\_STATUS\_FAILED**: `5`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L84)

##### PROPOSAL\_DECISION\_STATUS\_OPEN

> **PROPOSAL\_DECISION\_STATUS\_OPEN**: `1`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:71](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L71)

##### PROPOSAL\_DECISION\_STATUS\_REJECTED

> **PROPOSAL\_DECISION\_STATUS\_REJECTED**: `2`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:74](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L74)

##### PROPOSAL\_DECISION\_STATUS\_UNSPECIFIED

> **PROPOSAL\_DECISION\_STATUS\_UNSPECIFIED**: `0`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L68)

***

### SnsProposalRewardStatus

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L48)

#### Enumeration Members

##### PROPOSAL\_REWARD\_STATUS\_ACCEPT\_VOTES

> **PROPOSAL\_REWARD\_STATUS\_ACCEPT\_VOTES**: `1`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L56)

##### PROPOSAL\_REWARD\_STATUS\_READY\_TO\_SETTLE

> **PROPOSAL\_REWARD\_STATUS\_READY\_TO\_SETTLE**: `2`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L60)

##### PROPOSAL\_REWARD\_STATUS\_SETTLED

> **PROPOSAL\_REWARD\_STATUS\_SETTLED**: `3`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L64)

##### PROPOSAL\_REWARD\_STATUS\_UNSPECIFIED

> **PROPOSAL\_REWARD\_STATUS\_UNSPECIFIED**: `0`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L49)

***

### SnsSwapLifecycle

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:2](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L2)

#### Enumeration Members

##### Aborted

> **Aborted**: `4`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L7)

##### Adopted

> **Adopted**: `5`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:8](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L8)

##### Committed

> **Committed**: `3`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L6)

##### Open

> **Open**: `2`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L5)

##### Pending

> **Pending**: `1`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L4)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/sns/enums/swap.enums.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/swap.enums.ts#L3)

***

### SnsVote

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L87)

#### Enumeration Members

##### No

> **No**: `2`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L90)

##### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:88](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L88)

##### Yes

> **Yes**: `1`

Defined in: [packages/canisters/src/sns/enums/governance.enums.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/enums/governance.enums.ts#L89)

## Classes

### SnsGovernanceCanister

Defined in: [packages/canisters/src/sns/governance.canister.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L57)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new SnsGovernanceCanister**(`id`, `service`, `certifiedService`): [`SnsGovernanceCanister`](#snsgovernancecanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)

###### Returns

[`SnsGovernanceCanister`](#snsgovernancecanister)

###### Inherited from

`Canister<SnsGovernanceService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### addNeuronPermissions()

> **addNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:217](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L217)

Add permissions to a neuron for a specific principal

###### Parameters

###### params

[`SnsNeuronPermissionsParams`](#snsneuronpermissionsparams)

###### Returns

`Promise`\<`void`\>

##### autoStakeMaturity()

> **autoStakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L345)

Changes auto-stake maturity for a Neuron.

###### Parameters

###### params

[`SnsNeuronAutoStakeMaturityParams`](#snsneuronautostakematurityparams)

###### Returns

`Promise`\<`void`\>

##### claimNeuron()

> **claimNeuron**(`__namedParameters`): `Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:417](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L417)

Claim neuron

###### Parameters

###### \_\_namedParameters

[`SnsClaimNeuronParams`](#snsclaimneuronparams)

###### Returns

`Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)\>

##### disburse()

> **disburse**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:272](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L272)

Disburse neuron on Account

###### Parameters

###### params

[`SnsDisburseNeuronParams`](#snsdisburseneuronparams)

###### Returns

`Promise`\<`void`\>

##### disburseMaturity()

> **disburseMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:328](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L328)

Disburse the maturity of a neuron.

###### Parameters

###### params

[`SnsNeuronDisburseMaturityParams`](#snsneurondisbursematurityparams)

###### Returns

`Promise`\<`void`\>

##### getNeuron()

> **getNeuron**(`params`): `Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:164](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L164)

Get the neuron of the Sns

###### Parameters

###### params

[`SnsGetNeuronParams`](#snsgetneuronparams)

###### Returns

`Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)\>

##### getProposal()

> **getProposal**(`params`): `Promise`\<[`ProposalData`](namespaces/SnsGovernanceDid.md#proposaldata)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L119)

Get the proposal of the Sns

###### Parameters

###### params

[`SnsGetProposalParams`](#snsgetproposalparams)

###### Returns

`Promise`\<[`ProposalData`](namespaces/SnsGovernanceDid.md#proposaldata)\>

##### increaseDissolveDelay()

> **increaseDissolveDelay**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:367](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L367)

Increase dissolve delay of a neuron

###### Parameters

###### params

[`SnsIncreaseDissolveDelayParams`](#snsincreasedissolvedelayparams)

###### Returns

`Promise`\<`void`\>

##### listNervousSystemFunctions()

> **listNervousSystemFunctions**(`params`): `Promise`\<[`ListNervousSystemFunctionsResponse`](namespaces/SnsGovernanceDid.md#listnervoussystemfunctionsresponse)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:140](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L140)

List Nervous System Functions
Neurons can follow other neurons in specific Nervous System Functions.

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`ListNervousSystemFunctionsResponse`](namespaces/SnsGovernanceDid.md#listnervoussystemfunctionsresponse)\>

##### listNeurons()

> **listNeurons**(`params`): `Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)[]\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L77)

List the neurons of the Sns

###### Parameters

###### params

[`SnsListNeuronsParams`](#snslistneuronsparams)

###### Returns

`Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)[]\>

##### listProposals()

> **listProposals**(`params`): `Promise`\<[`ListProposalsResponse`](namespaces/SnsGovernanceDid.md#listproposalsresponse)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L93)

List the proposals of the Sns

###### Parameters

###### params

[`SnsListProposalsParams`](#snslistproposalsparams)

###### Returns

`Promise`\<[`ListProposalsResponse`](namespaces/SnsGovernanceDid.md#listproposalsresponse)\>

##### listTopics()

> **listTopics**(`params`): `Promise`\<[`ListTopicsResponse`](namespaces/SnsGovernanceDid.md#listtopicsresponse)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L108)

List the topics of the Sns

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`ListTopicsResponse`](namespaces/SnsGovernanceDid.md#listtopicsresponse)\>

##### manageNeuron()

> **manageNeuron**(`request`): `Promise`\<[`ManageNeuronResponse`](namespaces/SnsGovernanceDid.md#manageneuronresponse)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L204)

Manage neuron. For advanced users.

###### Parameters

###### request

[`ManageNeuron`](namespaces/SnsGovernanceDid.md#manageneuron)

###### Returns

`Promise`\<[`ManageNeuronResponse`](namespaces/SnsGovernanceDid.md#manageneuronresponse)\>

##### metadata()

> **metadata**(`params`): `Promise`\<[`GetMetadataResponse`](namespaces/SnsGovernanceDid.md#getmetadataresponse)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:148](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L148)

Get the Sns metadata (title, description, etc.)

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`GetMetadataResponse`](namespaces/SnsGovernanceDid.md#getmetadataresponse)\>

##### nervousSystemParameters()

> **nervousSystemParameters**(`params`): `Promise`\<[`NervousSystemParameters`](namespaces/SnsGovernanceDid.md#nervoussystemparameters)\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:156](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L156)

Get the Sns nervous system parameters (default followees, max dissolve delay, max number of neurons, etc.)

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`NervousSystemParameters`](namespaces/SnsGovernanceDid.md#nervoussystemparameters)\>

##### queryNeuron()

> **queryNeuron**(`params`): `Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron) \| `undefined`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:184](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L184)

Same as `getNeuron` but returns undefined instead of raising error when not found.

###### Parameters

###### params

[`SnsGetNeuronParams`](#snsgetneuronparams)

###### Returns

`Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron) \| `undefined`\>

##### refreshNeuron()

> **refreshNeuron**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:405](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L405)

Refresh neuron

###### Parameters

###### neuronId

[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

###### Returns

`Promise`\<`void`\>

##### registerVote()

> **registerVote**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:396](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L396)

Registers vote for a proposal from the neuron passed.

###### Parameters

###### params

[`SnsRegisterVoteParams`](#snsregistervoteparams)

###### Returns

`Promise`\<`void`\>

##### removeNeuronPermissions()

> **removeNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L228)

Remove permissions to a neuron for a specific principal

###### Parameters

###### params

[`SnsNeuronPermissionsParams`](#snsneuronpermissionsparams)

###### Returns

`Promise`\<`void`\>

##### setDissolveTimestamp()

> **setDissolveTimestamp**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:356](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L356)

Increase dissolve delay of a neuron

###### Parameters

###### params

[`SnsSetDissolveTimestampParams`](#snssetdissolvetimestampparams)

###### Returns

`Promise`\<`void`\>

##### setFollowing()

> **setFollowing**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:387](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L387)

Sets followees of a neuron for topics

###### Parameters

###### params

[`SnsSetFollowingParams`](#snssetfollowingparams)

###### Returns

`Promise`\<`void`\>

##### ~~setTopicFollowees()~~

> **setTopicFollowees**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:379](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L379)

Sets followees of a neuron for a specific Nervous System Function

###### Parameters

###### params

[`SnsSetTopicFollowees`](#snssettopicfollowees)

###### Returns

`Promise`\<`void`\>

###### Deprecated

will be replaced by `setFollowing` in the future.

##### splitNeuron()

> **splitNeuron**(`params`): `Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1) \| `undefined`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:239](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L239)

Split neuron

###### Parameters

###### params

[`SnsSplitNeuronParams`](#snssplitneuronparams)

###### Returns

`Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1) \| `undefined`\>

##### stakeMaturity()

> **stakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:307](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L307)

Stake the maturity of a neuron.

###### Parameters

###### params

[`SnsNeuronStakeMaturityParams`](#snsneuronstakematurityparams)

###### Returns

`Promise`\<`void`\>

##### startDissolving()

> **startDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:281](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L281)

Start dissolving process of a neuron

###### Parameters

###### neuronId

[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

###### Returns

`Promise`\<`void`\>

##### stopDissolving()

> **stopDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance.canister.ts:292](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L292)

Stop dissolving process of a neuron

###### Parameters

###### neuronId

[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

###### Returns

`Promise`\<`void`\>

##### create()

> `static` **create**(`options`): [`SnsGovernanceCanister`](#snsgovernancecanister)

Defined in: [packages/canisters/src/sns/governance.canister.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance.canister.ts#L63)

Instantiate a canister to interact with the governance of a Sns project.

###### Parameters

###### options

[`SnsCanisterOptions`](#snscanisteroptions)\<[`_SERVICE`](namespaces/SnsGovernanceDid.md#_service)\>

Miscellaneous options to initialize the canister. Its ID being the only mandatory parammeter.

###### Returns

[`SnsGovernanceCanister`](#snsgovernancecanister)

***

### SnsGovernanceError

Defined in: [packages/canisters/src/sns/errors/governance.errors.ts:1](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/governance.errors.ts#L1)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new SnsGovernanceError**(`message?`): [`SnsGovernanceError`](#snsgovernanceerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`SnsGovernanceError`](#snsgovernanceerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new SnsGovernanceError**(`message?`, `options?`): [`SnsGovernanceError`](#snsgovernanceerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`SnsGovernanceError`](#snsgovernanceerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### SnsGovernanceTestCanister

Defined in: [packages/canisters/src/sns/governance\_test.canister.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance_test.canister.ts#L18)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new SnsGovernanceTestCanister**(`id`, `service`, `certifiedService`): [`SnsGovernanceTestCanister`](#snsgovernancetestcanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)

###### Returns

[`SnsGovernanceTestCanister`](#snsgovernancetestcanister)

###### Inherited from

`Canister<SnsGovernanceTestService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### addMaturity()

> **addMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/governance\_test.canister.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance_test.canister.ts#L38)

Add maturity to a neuron (only for testing purposes. Testnet only.)

###### Parameters

###### params

`SnsAddMaturityParams`

###### Returns

`Promise`\<`void`\>

##### create()

> `static` **create**(`options`): [`SnsGovernanceTestCanister`](#snsgovernancetestcanister)

Defined in: [packages/canisters/src/sns/governance\_test.canister.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/governance_test.canister.ts#L24)

Instantiate a canister to interact with the governance of a Sns project.

###### Parameters

###### options

[`SnsCanisterOptions`](#snscanisteroptions)\<[`_SERVICE`](namespaces/SnsGovernanceTestDid.md#_service)\>

Miscellaneous options to initialize the canister. Its ID being the only mandatory parammeter.

###### Returns

[`SnsGovernanceTestCanister`](#snsgovernancetestcanister)

***

### SnsRootCanister

Defined in: [packages/canisters/src/sns/root.canister.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/root.canister.ts#L10)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/SnsRootDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new SnsRootCanister**(`id`, `service`, `certifiedService`): [`SnsRootCanister`](#snsrootcanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/SnsRootDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/SnsRootDid.md#_service)

###### Returns

[`SnsRootCanister`](#snsrootcanister)

###### Inherited from

`Canister<SnsRootService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/SnsRootDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/SnsRootDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/SnsRootDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/SnsRootDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### listSnsCanisters()

> **listSnsCanisters**(`params`): `Promise`\<[`ListSnsCanistersResponse`](namespaces/SnsRootDid.md#listsnscanistersresponse)\>

Defined in: [packages/canisters/src/sns/root.canister.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/root.canister.ts#L32)

List the canisters that are part of the Sns.

Source code: https://github.com/dfinity/ic/blob/master/rs/sns/root/src/lib.rs

###### Parameters

###### params

###### certified?

`boolean` = `true`

Query or update calls

###### Returns

`Promise`\<[`ListSnsCanistersResponse`](namespaces/SnsRootDid.md#listsnscanistersresponse)\>

- A list of canisters ('root' | 'governance' | 'ledger' | 'dapps' | 'swap' | 'archives')

##### create()

> `static` **create**(`options`): [`SnsRootCanister`](#snsrootcanister)

Defined in: [packages/canisters/src/sns/root.canister.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/root.canister.ts#L11)

###### Parameters

###### options

[`SnsCanisterOptions`](#snscanisteroptions)\<[`_SERVICE`](namespaces/SnsRootDid.md#_service)\>

###### Returns

[`SnsRootCanister`](#snsrootcanister)

***

### SnsSwapCanister

Defined in: [packages/canisters/src/sns/swap.canister.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L24)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/SnsSwapDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new SnsSwapCanister**(`id`, `service`, `certifiedService`): [`SnsSwapCanister`](#snsswapcanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/SnsSwapDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/SnsSwapDid.md#_service)

###### Returns

[`SnsSwapCanister`](#snsswapcanister)

###### Inherited from

`Canister<SnsSwapService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/SnsSwapDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/SnsSwapDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/SnsSwapDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/SnsSwapDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### getDerivedState()

> **getDerivedState**(`__namedParameters`): `Promise`\<[`GetDerivedStateResponse`](namespaces/SnsSwapDid.md#getderivedstateresponse)\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:75](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L75)

Get sale buyers state

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

`Promise`\<[`GetDerivedStateResponse`](namespaces/SnsSwapDid.md#getderivedstateresponse)\>

##### getFinalizationStatus()

> **getFinalizationStatus**(`params`): `Promise`\<[`GetAutoFinalizationStatusResponse`](namespaces/SnsSwapDid.md#getautofinalizationstatusresponse)\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:145](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L145)

Get sale lifecycle state

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`GetAutoFinalizationStatusResponse`](namespaces/SnsSwapDid.md#getautofinalizationstatusresponse)\>

##### getLifecycle()

> **getLifecycle**(`params`): `Promise`\<[`GetLifecycleResponse`](namespaces/SnsSwapDid.md#getlifecycleresponse)\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L137)

Get sale lifecycle state

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`GetLifecycleResponse`](namespaces/SnsSwapDid.md#getlifecycleresponse)\>

##### getOpenTicket()

> **getOpenTicket**(`params`): `Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L91)

Return a sale ticket if created and not yet removed (payment flow)

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

##### getSaleParameters()

> **getSaleParameters**(`__namedParameters`): `Promise`\<[`GetSaleParametersResponse`](namespaces/SnsSwapDid.md#getsaleparametersresponse)\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L83)

Get sale parameters

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

`Promise`\<[`GetSaleParametersResponse`](namespaces/SnsSwapDid.md#getsaleparametersresponse)\>

##### getUserCommitment()

> **getUserCommitment**(`params`): `Promise`\<[`BuyerState`](namespaces/SnsSwapDid.md#buyerstate) \| `undefined`\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L63)

Get user commitment

###### Parameters

###### params

[`GetBuyerStateRequest`](namespaces/SnsSwapDid.md#getbuyerstaterequest) & `QueryParams`

###### Returns

`Promise`\<[`BuyerState`](namespaces/SnsSwapDid.md#buyerstate) \| `undefined`\>

##### newSaleTicket()

> **newSaleTicket**(`params`): `Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1)\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L110)

Create a sale ticket (payment flow)

###### Parameters

###### params

`NewSaleTicketParams`

###### Returns

`Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1)\>

##### notifyParticipation()

> **notifyParticipation**(`params`): `Promise`\<[`RefreshBuyerTokensResponse`](namespaces/SnsSwapDid.md#refreshbuyertokensresponse)\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L55)

Notify of the user participating in the swap

###### Parameters

###### params

[`RefreshBuyerTokensRequest`](namespaces/SnsSwapDid.md#refreshbuyertokensrequest)

###### Returns

`Promise`\<[`RefreshBuyerTokensResponse`](namespaces/SnsSwapDid.md#refreshbuyertokensresponse)\>

##### notifyPaymentFailure()

> **notifyPaymentFailure**(): `Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L45)

Notify of the payment failure to remove the ticket

###### Returns

`Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

##### state()

> **state**(`params`): `Promise`\<[`GetStateResponse`](namespaces/SnsSwapDid.md#getstateresponse)\>

Defined in: [packages/canisters/src/sns/swap.canister.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L39)

Get the state of the swap

###### Parameters

###### params

`QueryParams`

###### Returns

`Promise`\<[`GetStateResponse`](namespaces/SnsSwapDid.md#getstateresponse)\>

##### create()

> `static` **create**(`options`): [`SnsSwapCanister`](#snsswapcanister)

Defined in: [packages/canisters/src/sns/swap.canister.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/swap.canister.ts#L25)

###### Parameters

###### options

[`SnsCanisterOptions`](#snscanisteroptions)\<[`_SERVICE`](namespaces/SnsSwapDid.md#_service)\>

###### Returns

[`SnsSwapCanister`](#snsswapcanister)

***

### SnsSwapGetOpenTicketError

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L28)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new SnsSwapGetOpenTicketError**(`errorType`): [`SnsSwapGetOpenTicketError`](#snsswapgetopenticketerror)

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L29)

###### Parameters

###### errorType

[`GetOpenTicketErrorType`](#getopenticketerrortype)

###### Returns

[`SnsSwapGetOpenTicketError`](#snsswapgetopenticketerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### errorType

> **errorType**: [`GetOpenTicketErrorType`](#getopenticketerrortype)

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L29)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### SnsSwapNewTicketError

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L7)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new SnsSwapNewTicketError**(`__namedParameters`): [`SnsSwapNewTicketError`](#snsswapnewticketerror)

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L12)

###### Parameters

###### \_\_namedParameters

###### errorType

[`NewSaleTicketResponseErrorType`](#newsaleticketresponseerrortype)

###### existingTicket?

[`Ticket`](namespaces/SnsSwapDid.md#ticket-1)

###### invalidUserAmount?

[`InvalidUserAmount`](namespaces/SnsSwapDid.md#invaliduseramount)

###### Returns

[`SnsSwapNewTicketError`](#snsswapnewticketerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### errorType

> **errorType**: [`NewSaleTicketResponseErrorType`](#newsaleticketresponseerrortype)

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L8)

##### existingTicket?

> `optional` **existingTicket**: [`Ticket`](namespaces/SnsSwapDid.md#ticket-1)

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L10)

##### invalidUserAmount?

> `optional` **invalidUserAmount**: [`InvalidUserAmount`](namespaces/SnsSwapDid.md#invaliduseramount)

Defined in: [packages/canisters/src/sns/errors/swap.errors.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/swap.errors.ts#L9)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### SnsWrapper

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L68)

Sns wrapper - notably used by NNS-dapp - ease the access to a particular Sns.
It knows all the Sns' canisters, wrap and enhance their available features.
A wrapper either performs query or update calls.

#### Constructors

##### Constructor

> **new SnsWrapper**(`__namedParameters`): [`SnsWrapper`](#snswrapper)

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L79)

Constructor to instantiate a Sns

###### Parameters

###### \_\_namedParameters

`SnsWrapperOptions`

###### Returns

[`SnsWrapper`](#snswrapper)

#### Accessors

##### canisterIds

###### Get Signature

> **get** **canisterIds**(): `object`

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L98)

Binds the list of canister ids of the Sns.

###### Returns

`object`

###### governanceCanisterId

> **governanceCanisterId**: `Principal`

###### indexCanisterId

> **indexCanisterId**: `Principal`

###### ledgerCanisterId

> **ledgerCanisterId**: `Principal`

###### rootCanisterId

> **rootCanisterId**: `Principal`

###### swapCanisterId

> **swapCanisterId**: `Principal`

#### Methods

##### addNeuronPermissions()

> **addNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:323](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L323)

###### Parameters

###### params

[`SnsNeuronPermissionsParams`](#snsneuronpermissionsparams)

###### Returns

`Promise`\<`void`\>

##### autoStakeMaturity()

> **autoStakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:451](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L451)

###### Parameters

###### params

[`SnsNeuronAutoStakeMaturityParams`](#snsneuronautostakematurityparams)

###### Returns

`Promise`\<`void`\>

##### balance()

> **balance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:164](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L164)

###### Parameters

###### params

`Omit`\<[`BalanceParams`](../ledger/icrc/index.md#balanceparams), `"certified"`\>

###### Returns

`Promise`\<`bigint`\>

##### claimNeuron()

> **claimNeuron**(`params`): `Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:331](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L331)

###### Parameters

###### params

[`SnsClaimNeuronParams`](#snsclaimneuronparams)

###### Returns

`Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)\>

##### disburse()

> **disburse**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:347](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L347)

###### Parameters

###### params

[`SnsDisburseNeuronParams`](#snsdisburseneuronparams)

###### Returns

`Promise`\<`void`\>

##### disburseMaturity()

> **disburseMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:447](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L447)

###### Parameters

###### params

[`SnsNeuronDisburseMaturityParams`](#snsneurondisbursematurityparams)

###### Returns

`Promise`\<`void`\>

##### getDerivedState()

> **getDerivedState**(`params`): `Promise`\<[`GetDerivedStateResponse`](namespaces/SnsSwapDid.md#getderivedstateresponse) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:432](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L432)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`GetDerivedStateResponse`](namespaces/SnsSwapDid.md#getderivedstateresponse) \| `undefined`\>

##### getFinalizationStatus()

> **getFinalizationStatus**(`params`): `Promise`\<[`GetAutoFinalizationStatusResponse`](namespaces/SnsSwapDid.md#getautofinalizationstatusresponse) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:422](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L422)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`GetAutoFinalizationStatusResponse`](namespaces/SnsSwapDid.md#getautofinalizationstatusresponse) \| `undefined`\>

##### getLifecycle()

> **getLifecycle**(`params`): `Promise`\<[`GetLifecycleResponse`](namespaces/SnsSwapDid.md#getlifecycleresponse) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:417](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L417)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`GetLifecycleResponse`](namespaces/SnsSwapDid.md#getlifecycleresponse) \| `undefined`\>

##### getNeuron()

> **getNeuron**(`params`): `Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L173)

###### Parameters

###### params

`Omit`\<[`SnsGetNeuronParams`](#snsgetneuronparams), `"certified"`\>

###### Returns

`Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)\>

##### getNeuronBalance()

> **getNeuronBalance**(`neuronId`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:312](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L312)

###### Parameters

###### neuronId

[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

###### Returns

`Promise`\<`bigint`\>

##### getOpenTicket()

> **getOpenTicket**(`params`): `Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:408](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L408)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

##### getProposal()

> **getProposal**(`params`): `Promise`\<[`ProposalData`](namespaces/SnsGovernanceDid.md#proposaldata)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:124](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L124)

###### Parameters

###### params

`Omit`\<[`SnsGetProposalParams`](#snsgetproposalparams), `"certified"`\>

###### Returns

`Promise`\<[`ProposalData`](namespaces/SnsGovernanceDid.md#proposaldata)\>

##### getSaleParameters()

> **getSaleParameters**(`params`): `Promise`\<[`GetSaleParametersResponse`](namespaces/SnsSwapDid.md#getsaleparametersresponse) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:427](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L427)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`GetSaleParametersResponse`](namespaces/SnsSwapDid.md#getsaleparametersresponse) \| `undefined`\>

##### getTransactions()

> **getTransactions**(`params`): `Promise`\<[`GetTransactions`](../ledger/icrc/namespaces/IcrcIndexDid.md#gettransactions)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:437](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L437)

###### Parameters

###### params

[`GetIndexAccountTransactionsParams`](../ledger/icrc/index.md#getindexaccounttransactionsparams)

###### Returns

`Promise`\<[`GetTransactions`](../ledger/icrc/namespaces/IcrcIndexDid.md#gettransactions)\>

##### getUserCommitment()

> **getUserCommitment**(`params`): `Promise`\<[`BuyerState`](namespaces/SnsSwapDid.md#buyerstate) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:403](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L403)

###### Parameters

###### params

[`GetBuyerStateRequest`](namespaces/SnsSwapDid.md#getbuyerstaterequest)

###### Returns

`Promise`\<[`BuyerState`](namespaces/SnsSwapDid.md#buyerstate) \| `undefined`\>

##### increaseDissolveDelay()

> **increaseDissolveDelay**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L364)

###### Parameters

###### params

[`SnsIncreaseDissolveDelayParams`](#snsincreasedissolvedelayparams)

###### Returns

`Promise`\<`void`\>

##### increaseStakeNeuron()

> **increaseStakeNeuron**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:293](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L293)

Increase the stake of a neuron.

This is a convenient method that transfers the stake to the neuron subaccount and then refresh the neuron.

⚠️ This feature is provided as it without warranty. It does not implement any additional checks of the validity of the payment flow - e.g. it does not handle refund nor calls refresh again in case of errors.

###### Parameters

###### params

[`SnsIncreaseStakeNeuronParams`](#snsincreasestakeneuronparams)

###### Returns

`Promise`\<`void`\>

##### ledgerMetadata()

> **ledgerMetadata**(`params`): `Promise`\<[`IcrcTokenMetadataResponse`](../ledger/icrc/index.md#icrctokenmetadataresponse)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:149](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L149)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`IcrcTokenMetadataResponse`](../ledger/icrc/index.md#icrctokenmetadataresponse)\>

##### listNervousSystemFunctions()

> **listNervousSystemFunctions**(`params`): `Promise`\<[`ListNervousSystemFunctionsResponse`](namespaces/SnsGovernanceDid.md#listnervoussystemfunctionsresponse)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L129)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`ListNervousSystemFunctionsResponse`](namespaces/SnsGovernanceDid.md#listnervoussystemfunctionsresponse)\>

##### listNeurons()

> **listNeurons**(`params`): `Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)[]\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L114)

###### Parameters

###### params

`Omit`\<[`SnsListNeuronsParams`](#snslistneuronsparams), `"certified"`\>

###### Returns

`Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron)[]\>

##### listProposals()

> **listProposals**(`params`): `Promise`\<[`ListProposalsResponse`](namespaces/SnsGovernanceDid.md#listproposalsresponse)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L119)

###### Parameters

###### params

`Omit`\<[`SnsListProposalsParams`](#snslistproposalsparams), `"certified"`\>

###### Returns

`Promise`\<[`ListProposalsResponse`](namespaces/SnsGovernanceDid.md#listproposalsresponse)\>

##### metadata()

> **metadata**(`params`): `Promise`\<\[[`GetMetadataResponse`](namespaces/SnsGovernanceDid.md#getmetadataresponse), [`IcrcTokenMetadataResponse`](../ledger/icrc/index.md#icrctokenmetadataresponse)\]\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L134)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<\[[`GetMetadataResponse`](namespaces/SnsGovernanceDid.md#getmetadataresponse), [`IcrcTokenMetadataResponse`](../ledger/icrc/index.md#icrctokenmetadataresponse)\]\>

##### nervousSystemParameters()

> **nervousSystemParameters**(`params`): `Promise`\<[`NervousSystemParameters`](namespaces/SnsGovernanceDid.md#nervoussystemparameters)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:144](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L144)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`NervousSystemParameters`](namespaces/SnsGovernanceDid.md#nervoussystemparameters)\>

##### newSaleTicket()

> **newSaleTicket**(`params`): `Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:414](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L414)

###### Parameters

###### params

`NewSaleTicketParams`

###### Returns

`Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1)\>

##### nextNeuronAccount()

> **nextNeuronAccount**(`controller`): `Promise`\<\{ `account`: [`IcrcAccount`](../ledger/icrc/index.md#icrcaccount); `index`: `bigint`; \}\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:199](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L199)

Returns the subaccount of the next neuron to be created.

The neuron account is a subaccount of the governance canister.
The subaccount is derived from the controller and an ascending index.

‼️ The id of the neuron is the subaccount (neuron ID = subaccount) ‼️.

If the neuron does not exist for that subaccount, then we use it for the next neuron.

The index is used in the memo of the transfer and when claiming the neuron.
This is how the backend can identify which neuron is being claimed.

###### Parameters

###### controller

`Principal`

###### Returns

`Promise`\<\{ `account`: [`IcrcAccount`](../ledger/icrc/index.md#icrcaccount); `index`: `bigint`; \}\>

##### notifyParticipation()

> **notifyParticipation**(`params`): `Promise`\<[`RefreshBuyerTokensResponse`](namespaces/SnsSwapDid.md#refreshbuyertokensresponse)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:398](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L398)

###### Parameters

###### params

[`RefreshBuyerTokensRequest`](namespaces/SnsSwapDid.md#refreshbuyertokensrequest)

###### Returns

`Promise`\<[`RefreshBuyerTokensResponse`](namespaces/SnsSwapDid.md#refreshbuyertokensresponse)\>

##### notifyPaymentFailure()

> **notifyPaymentFailure**(): `Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:394](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L394)

Returns the ticket if a ticket was found for the caller and the ticket
was removed successfully. Returns None if no ticket was found for the caller.
Only the owner of a ticket can remove it.

Always certified

###### Returns

`Promise`\<[`Ticket`](namespaces/SnsSwapDid.md#ticket-1) \| `undefined`\>

##### queryNeuron()

> **queryNeuron**(`params`): `Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:178](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L178)

###### Parameters

###### params

`Omit`\<[`SnsGetNeuronParams`](#snsgetneuronparams), `"certified"`\>

###### Returns

`Promise`\<[`Neuron`](namespaces/SnsGovernanceDid.md#neuron) \| `undefined`\>

##### refreshNeuron()

> **refreshNeuron**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:327](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L327)

###### Parameters

###### neuronId

[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

###### Returns

`Promise`\<`void`\>

##### registerVote()

> **registerVote**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:377](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L377)

###### Parameters

###### params

[`SnsRegisterVoteParams`](#snsregistervoteparams)

###### Returns

`Promise`\<`void`\>

##### removeNeuronPermissions()

> **removeNeuronPermissions**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:336](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L336)

###### Parameters

###### params

[`SnsNeuronPermissionsParams`](#snsneuronpermissionsparams)

###### Returns

`Promise`\<`void`\>

##### setDissolveTimestamp()

> **setDissolveTimestamp**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:359](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L359)

###### Parameters

###### params

[`SnsSetDissolveTimestampParams`](#snssetdissolvetimestampparams)

###### Returns

`Promise`\<`void`\>

##### setFollowing()

> **setFollowing**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:373](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L373)

###### Parameters

###### params

[`SnsSetFollowingParams`](#snssetfollowingparams)

###### Returns

`Promise`\<`void`\>

##### setTopicFollowees()

> **setTopicFollowees**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:369](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L369)

###### Parameters

###### params

[`SnsSetTopicFollowees`](#snssettopicfollowees)

###### Returns

`Promise`\<`void`\>

##### splitNeuron()

> **splitNeuron**(`params`): `Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1) \| `undefined`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:341](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L341)

###### Parameters

###### params

[`SnsSplitNeuronParams`](#snssplitneuronparams)

###### Returns

`Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1) \| `undefined`\>

##### stakeMaturity()

> **stakeMaturity**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:443](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L443)

###### Parameters

###### params

[`SnsNeuronStakeMaturityParams`](#snsneuronstakematurityparams)

###### Returns

`Promise`\<`void`\>

##### stakeNeuron()

> **stakeNeuron**(`params`): `Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:246](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L246)

Stakes a neuron.

This is a convenient method that transfers the stake to the neuron subaccount and then claims the neuron.

⚠️ This feature is provided as it without warranty. It does not implement any additional checks of the validity of the payment flow - e.g. it does not handle refund nor retries claiming the neuron in case of errors.

###### Parameters

###### params

[`SnsStakeNeuronParams`](#snsstakeneuronparams)

###### Returns

`Promise`\<[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)\>

##### startDissolving()

> **startDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:351](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L351)

###### Parameters

###### neuronId

[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

###### Returns

`Promise`\<`void`\>

##### stopDissolving()

> **stopDissolving**(`neuronId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:355](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L355)

###### Parameters

###### neuronId

[`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

###### Returns

`Promise`\<`void`\>

##### swapState()

> **swapState**(`params`): `Promise`\<[`GetStateResponse`](namespaces/SnsSwapDid.md#getstateresponse)\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:380](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L380)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<[`GetStateResponse`](namespaces/SnsSwapDid.md#getstateresponse)\>

##### totalTokensSupply()

> **totalTokensSupply**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:159](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L159)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<`bigint`\>

##### transactionFee()

> **transactionFee**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:154](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L154)

###### Parameters

###### params

`Omit`\<`QueryParams`, `"certified"`\>

###### Returns

`Promise`\<`bigint`\>

##### transfer()

> **transfer**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/sns/sns.wrapper.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.wrapper.ts#L170)

###### Parameters

###### params

[`TransferParams`](../ledger/icrc/index.md#transferparams)

###### Returns

`Promise`\<`bigint`\>

***

### UnsupportedMethodError

Defined in: [packages/canisters/src/sns/errors/common.errors.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/common.errors.ts#L3)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new UnsupportedMethodError**(`methodName`): [`UnsupportedMethodError`](#unsupportedmethoderror)

Defined in: [packages/canisters/src/sns/errors/common.errors.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/common.errors.ts#L4)

###### Parameters

###### methodName

`string`

###### Returns

[`UnsupportedMethodError`](#unsupportedmethoderror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### methodName

> `readonly` **methodName**: `string`

Defined in: [packages/canisters/src/sns/errors/common.errors.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/errors/common.errors.ts#L4)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

## Interfaces

### InitSnsCanistersOptions

Defined in: [packages/canisters/src/sns/sns.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.ts#L19)

Options to discover and initialize all canisters of a Sns.

#### Extends

- `QueryParams`

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: [packages/canisters/src/sns/sns.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.ts#L21)

An agent that can be used to override the default agent. Useful to target another environment that mainnet.

##### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

###### Inherited from

`QueryParams.certified`

##### rootOptions

> **rootOptions**: `Omit`\<[`SnsCanisterOptions`](#snscanisteroptions)\<[`_SERVICE`](namespaces/SnsRootDid.md#_service)\>, `"agent"`\>

Defined in: [packages/canisters/src/sns/sns.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.ts#L23)

The options that will be used to instantiate the actors of the root canister of the particular Sns.

***

### InitSnsWrapper()

Defined in: [packages/canisters/src/sns/sns.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.ts#L26)

> **InitSnsWrapper**(`options`): `Promise`\<[`SnsWrapper`](#snswrapper)\>

Defined in: [packages/canisters/src/sns/sns.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.ts#L27)

#### Parameters

##### options

[`InitSnsCanistersOptions`](#initsnscanistersoptions)

#### Returns

`Promise`\<[`SnsWrapper`](#snswrapper)\>

***

### SnsCanisterOptions

Defined in: [packages/canisters/src/sns/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/canister.options.ts#L4)

#### Extends

- `Omit`\<`CanisterOptions`\<`T`\>, `"canisterId"`\>

#### Type Parameters

##### T

`T`

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

###### Inherited from

[`NnsGovernanceCanisterOptions`](../nns/index.md#nnsgovernancecanisteroptions).[`agent`](../nns/index.md#agent)

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/sns/types/canister.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/canister.options.ts#L9)

##### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

###### Inherited from

`Omit.certifiedServiceOverride`

##### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

###### Inherited from

`Omit.serviceOverride`

***

### SnsClaimNeuronParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L177)

The parameters to claim a neuron

#### Properties

##### controller

> **controller**: `Principal`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:179](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L179)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:178](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L178)

##### subaccount

> **subaccount**: [`Subaccount`](../ledger/icrc/namespaces/IcrcLedgerDid.md#subaccount-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:180](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L180)

***

### SnsClaimOrRefreshArgs

Defined in: [packages/canisters/src/sns/types/governance.params.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L94)

#### Extends

- `Omit`\<`QueryParams`, `"certified"`\>

#### Properties

##### controller?

> `optional` **controller**: `Principal`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L97)

##### memo?

> `optional` **memo**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L96)

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L95)

***

### SnsDisburseNeuronParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:126](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L126)

The parameters to disburse a neuron

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### amount?

> `optional` **amount**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L127)

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

##### toAccount?

> `optional` **toAccount**: [`IcrcAccount`](../ledger/icrc/index.md#icrcaccount)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L128)

***

### SnsGetNeuronParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:71](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L71)

The parameters to get a Sns neuron

#### Extends

- `QueryParams`

#### Properties

##### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

###### Inherited from

`QueryParams.certified`

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L72)

***

### SnsGetProposalParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L64)

The parameters to get an sns proposal

#### Extends

- `QueryParams`

#### Properties

##### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

###### Inherited from

`QueryParams.certified`

##### proposalId

> **proposalId**: [`ProposalId`](namespaces/SnsGovernanceDid.md#proposalid)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:65](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L65)

***

### SnsIncreaseDissolveDelayParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L141)

The parameters to increase dissolve delay

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### additionalDissolveDelaySeconds

> **additionalDissolveDelaySeconds**: `number`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:142](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L142)

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### SnsIncreaseStakeNeuronParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L84)

#### Extends

- `Omit`\<`QueryParams`, `"certified"`\>

#### Properties

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L90)

##### source

> **source**: [`IcrcAccount`](../ledger/icrc/index.md#icrcaccount)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L89)

##### stakeE8s

> **stakeE8s**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:88](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L88)

***

### SnsListNeuronsParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L16)

The parameters available to list Sns neurons

#### Extends

- `QueryParams`

#### Properties

##### beforeNeuronId?

> `optional` **beforeNeuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L22)

Index the search to returns a list that starts after specified neuron id

##### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

###### Inherited from

`QueryParams.certified`

##### limit?

> `optional` **limit**: `number`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L20)

The maximum number of neurons returned by the method `list_neurons`

##### principal?

> `optional` **principal**: `Principal`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L18)

Scope the query to a particular principal

***

### SnsListProposalsParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L28)

The parameters available to list Sns proposals

#### Extends

- `QueryParams`

#### Properties

##### beforeProposal?

> `optional` **beforeProposal**: [`ProposalId`](namespaces/SnsGovernanceDid.md#proposalid)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L37)

##### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

###### Inherited from

`QueryParams.certified`

##### excludeType?

> `optional` **excludeType**: `bigint`[]

Defined in: [packages/canisters/src/sns/types/governance.params.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L43)

##### includeRewardStatus?

> `optional` **includeRewardStatus**: [`SnsProposalRewardStatus`](#snsproposalrewardstatus)[]

Defined in: [packages/canisters/src/sns/types/governance.params.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L33)

##### includeStatus?

> `optional` **includeStatus**: [`SnsProposalDecisionStatus`](#snsproposaldecisionstatus)[]

Defined in: [packages/canisters/src/sns/types/governance.params.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L48)

##### includeTopics?

> `optional` **includeTopics**: ([`Topic`](namespaces/SnsGovernanceDid.md#topic-6) \| `null`)[]

Defined in: [packages/canisters/src/sns/types/governance.params.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L56)

##### limit?

> `optional` **limit**: `number`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L40)

***

### SnsNeuronAutoStakeMaturityParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:201](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L201)

The parameters to toggle auto stake maturity of a neuron

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### autoStake

> **autoStake**: `boolean`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:202](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L202)

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### SnsNeuronDisburseMaturityParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:193](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L193)

The parameters to disburse maturity of a neuron

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

##### percentageToDisburse

> **percentageToDisburse**: `number`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L195)

##### toAccount?

> `optional` **toAccount**: [`IcrcAccount`](../ledger/icrc/index.md#icrcaccount)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:194](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L194)

***

### SnsNeuronPermissionsParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L110)

The parameters to add permissions to a neuron

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

##### permissions

> **permissions**: [`SnsNeuronPermissionType`](#snsneuronpermissiontype)[]

Defined in: [packages/canisters/src/sns/types/governance.params.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L112)

##### principal

> **principal**: `Principal`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L111)

***

### SnsNeuronStakeMaturityParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L186)

The parameters to stake maturity of a neuron

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

##### percentageToStake?

> `optional` **percentageToStake**: `number`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:187](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L187)

***

### SnsRegisterVoteParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L169)

The parameters to register vote

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

##### proposalId

> **proposalId**: [`ProposalId`](namespaces/SnsGovernanceDid.md#proposalid)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L171)

##### vote

> **vote**: [`SnsVote`](#snsvote)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L170)

***

### SnsSetDissolveTimestampParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L134)

The parameters to set dissolve timestamp

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### dissolveTimestampSeconds

> **dissolveTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L135)

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### SnsSetFollowingParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:156](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L156)

The parameters to follow by topic

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

##### topicFollowing

> **topicFollowing**: `object`[]

Defined in: [packages/canisters/src/sns/types/governance.params.ts:157](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L157)

###### followees

> **followees**: `object`[]

###### topic

> **topic**: [`Topic`](namespaces/SnsGovernanceDid.md#topic-6)

***

### SnsSetTopicFollowees

Defined in: [packages/canisters/src/sns/types/governance.params.ts:148](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L148)

The parameters to follow by ns-function

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### followees

> **followees**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)[]

Defined in: [packages/canisters/src/sns/types/governance.params.ts:150](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L150)

##### functionId

> **functionId**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:149](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L149)

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### SnsSplitNeuronParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L118)

The parameters to split a neuron

#### Extends

- `SnsNeuronManagementParams`

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L119)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L120)

##### neuronId

> **neuronId**: [`NeuronId`](namespaces/SnsGovernanceDid.md#neuronid-1)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L104)

###### Inherited from

`SnsNeuronManagementParams.neuronId`

***

### SnsStakeNeuronParams

Defined in: [packages/canisters/src/sns/types/governance.params.ts:75](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L75)

#### Extends

- `Omit`\<`QueryParams`, `"certified"`\>

#### Properties

##### controller

> **controller**: `Principal`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L78)

##### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L80)

##### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L81)

##### source

> **source**: [`IcrcAccount`](../ledger/icrc/index.md#icrcaccount)

Defined in: [packages/canisters/src/sns/types/governance.params.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L77)

##### stakeE8s

> **stakeE8s**: `bigint`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L76)

## Type Aliases

### SnsListTopicsParams

> **SnsListTopicsParams** = `QueryParams`

Defined in: [packages/canisters/src/sns/types/governance.params.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/types/governance.params.ts#L59)

## Variables

### initSnsWrapper

> `const` **initSnsWrapper**: [`InitSnsWrapper`](#initsnswrapper)

Defined in: [packages/canisters/src/sns/sns.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/sns.ts#L33)

Lookup for the canister ids of a Sns and initialize the wrapper to access its features.

## Functions

### fromCandidAction()

> **fromCandidAction**(`action`): `Action`

Defined in: [packages/canisters/src/sns/converters/governance.converters.ts:335](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/converters/governance.converters.ts#L335)

#### Parameters

##### action

[`Action`](namespaces/SnsGovernanceDid.md#action-2)

#### Returns

`Action`

***

### neuronSubaccount()

> **neuronSubaccount**(`params`): [`Subaccount`](../ledger/icrc/namespaces/IcrcLedgerDid.md#subaccount-1)

Defined in: [packages/canisters/src/sns/utils/governance.utils.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/sns/utils/governance.utils.ts#L18)

Neuron subaccount is calculated as "sha256(0x0c . “neuron-stake” . controller . i)"

#### Parameters

##### params

###### controller

`Principal`

###### index

`number`

#### Returns

[`Subaccount`](../ledger/icrc/namespaces/IcrcLedgerDid.md#subaccount-1)

## References

### SnsWasmDid

Re-exports [SnsWasmDid](../nns/namespaces/SnsWasmDid.md)
