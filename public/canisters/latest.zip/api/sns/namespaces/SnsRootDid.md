---
title: SnsRootDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L195)

#### Properties

##### canister\_status

> **canister\_status**: `ActorMethod`\<\[[`CanisterIdRecord`](#canisteridrecord)\], [`CanisterStatusResult`](#canisterstatusresult)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L196)

##### change\_canister

> **change\_canister**: `ActorMethod`\<\[[`ChangeCanisterRequest`](#changecanisterrequest)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L197)

##### clean\_up\_failed\_register\_extension

> **clean\_up\_failed\_register\_extension**: `ActorMethod`\<\[[`CleanUpFailedRegisterExtensionRequest`](#cleanupfailedregisterextensionrequest)\], [`CleanUpFailedRegisterExtensionResponse`](#cleanupfailedregisterextensionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L198)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L202)

##### get\_sns\_canisters\_summary

> **get\_sns\_canisters\_summary**: `ActorMethod`\<\[[`GetSnsCanistersSummaryRequest`](#getsnscanisterssummaryrequest)\], [`GetSnsCanistersSummaryResponse`](#getsnscanisterssummaryresponse)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L203)

##### get\_timers

> **get\_timers**: `ActorMethod`\<\[\{ \}\], [`GetTimersResponse`](#gettimersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L207)

##### list\_sns\_canisters

> **list\_sns\_canisters**: `ActorMethod`\<\[\{ \}\], [`ListSnsCanistersResponse`](#listsnscanistersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L208)

##### manage\_dapp\_canister\_settings

> **manage\_dapp\_canister\_settings**: `ActorMethod`\<\[[`ManageDappCanisterSettingsRequest`](#managedappcanistersettingsrequest)\], [`ManageDappCanisterSettingsResponse`](#managedappcanistersettingsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L209)

##### register\_dapp\_canister

> **register\_dapp\_canister**: `ActorMethod`\<\[[`RegisterDappCanisterRequest`](#registerdappcanisterrequest)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L213)

##### register\_dapp\_canisters

> **register\_dapp\_canisters**: `ActorMethod`\<\[[`RegisterDappCanistersRequest`](#registerdappcanistersrequest)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L214)

##### register\_extension

> **register\_extension**: `ActorMethod`\<\[[`RegisterExtensionRequest`](#registerextensionrequest)\], [`RegisterExtensionResponse`](#registerextensionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L215)

##### reset\_timers

> **reset\_timers**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L219)

##### set\_dapp\_controllers

> **set\_dapp\_controllers**: `ActorMethod`\<\[[`SetDappControllersRequest`](#setdappcontrollersrequest)\], [`SetDappControllersResponse`](#setdappcontrollersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L220)

***

### CanisterCallError

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L13)

#### Properties

##### code

> **code**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L14)

##### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L15)

***

### CanisterIdRecord

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L17)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L18)

***

### CanisterStatusResult

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L24)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L28)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L31)

##### memory\_metrics

> **memory\_metrics**: \[\] \| \[[`MemoryMetrics`](#memorymetrics)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L25)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L27)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L32)

##### query\_stats

> **query\_stats**: \[\] \| \[[`QueryStats`](#querystats)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L30)

##### reserved\_cycles

> **reserved\_cycles**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L33)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L29)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L26)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L35)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L39)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L42)

##### memory\_metrics

> **memory\_metrics**: \[\] \| \[[`MemoryMetrics`](#memorymetrics)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L36)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L38)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L43)

##### query\_stats

> **query\_stats**: \[\] \| \[[`QueryStats`](#querystats)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L41)

##### settings

> **settings**: [`DefiniteCanisterSettingsArgs`](#definitecanistersettingsargs)

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L40)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L37)

***

### CanisterSummary

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L49)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L51)

##### status

> **status**: \[\] \| \[[`CanisterStatusResultV2`](#canisterstatusresultv2)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L50)

***

### ChangeCanisterRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L53)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L54)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L58)

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L59)

##### mode

> **mode**: [`CanisterInstallMode`](#canisterinstallmode)

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L57)

##### stop\_before\_installing

> **stop\_before\_installing**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L56)

##### wasm\_module

> **wasm\_module**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L55)

***

### ChunkedCanisterWasm

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L61)

#### Properties

##### chunk\_hashes\_list

> **chunk\_hashes\_list**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L63)

##### store\_canister\_id

> **store\_canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L64)

##### wasm\_module\_hash

> **wasm\_module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L62)

***

### CleanUpFailedRegisterExtensionRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L66)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L67)

***

### CleanUpFailedRegisterExtensionResponse

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L69)

#### Properties

##### result

> **result**: \[\] \| \[[`CleanUpFailedRegisterExtensionResult`](#cleanupfailedregisterextensionresult)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L70)

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L75)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L83)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L78)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L76)

##### log\_visibility

> **log\_visibility**: \[\] \| \[[`LogVisibility`](#logvisibility)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L80)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L82)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L79)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L81)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L77)

***

### DefiniteCanisterSettingsArgs

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L85)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L91)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L88)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L86)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L90)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L89)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L87)

***

### Extensions

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L93)

#### Properties

##### extension\_canister\_ids

> **extension\_canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L94)

***

### FailedUpdate

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L96)

#### Properties

##### dapp\_canister\_id

> **dapp\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L98)

##### err

> **err**: \[\] \| \[[`CanisterCallError`](#canistercallerror)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L97)

***

### GetSnsCanistersSummaryRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L100)

#### Properties

##### update\_canister\_list

> **update\_canister\_list**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L101)

***

### GetSnsCanistersSummaryResponse

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L103)

#### Properties

##### archives

> **archives**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L110)

##### dapps

> **dapps**: [`CanisterSummary`](#canistersummary)[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L109)

##### governance

> **governance**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L108)

##### index

> **index**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L107)

##### ledger

> **ledger**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L106)

##### root

> **root**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L104)

##### swap

> **swap**: \[\] \| \[[`CanisterSummary`](#canistersummary)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L105)

***

### GetTimersResponse

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L112)

#### Properties

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L113)

***

### ListSnsCanistersResponse

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L115)

#### Properties

##### archives

> **archives**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L123)

##### dapps

> **dapps**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L122)

##### extensions

> **extensions**: \[\] \| \[[`Extensions`](#extensions)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L118)

##### governance

> **governance**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L121)

##### index

> **index**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L120)

##### ledger

> **ledger**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L119)

##### root

> **root**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L116)

##### swap

> **swap**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L117)

***

### ManageDappCanisterSettingsRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L129)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L132)

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L138)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L130)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L134)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L137)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L133)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L135)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L136)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L131)

***

### ManageDappCanisterSettingsResponse

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L140)

#### Properties

##### failure\_reason

> **failure\_reason**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L141)

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L143)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L146)

##### custom\_sections\_size

> **custom\_sections\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L151)

##### global\_memory\_size

> **global\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L150)

##### snapshots\_size

> **snapshots\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L148)

##### stable\_memory\_size

> **stable\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L147)

##### wasm\_binary\_size

> **wasm\_binary\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L144)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L145)

##### wasm\_memory\_size

> **wasm\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L149)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L153)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L156)

##### num\_instructions\_total

> **num\_instructions\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L155)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L157)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L154)

***

### RegisterDappCanisterRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L159)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L160)

***

### RegisterDappCanistersRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L162)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L163)

***

### RegisterExtensionRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L165)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L166)

***

### RegisterExtensionResponse

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L168)

#### Properties

##### result

> **result**: \[\] \| \[[`RegisterExtensionResult`](#registerextensionresult)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L169)

***

### SetDappControllersRequest

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L172)

#### Properties

##### canister\_ids

> **canister\_ids**: \[\] \| \[[`RegisterDappCanistersRequest`](#registerdappcanistersrequest)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L173)

##### controller\_principal\_ids

> **controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L174)

***

### SetDappControllersResponse

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L176)

#### Properties

##### failed\_updates

> **failed\_updates**: [`FailedUpdate`](#failedupdate)[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L177)

***

### SnsRootCanister

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L179)

#### Properties

##### archive\_canister\_ids

> **archive\_canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L184)

##### dapp\_canister\_ids

> **dapp\_canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L180)

##### extensions

> **extensions**: \[\] \| \[[`Extensions`](#extensions)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L183)

##### governance\_canister\_id

> **governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L185)

##### index\_canister\_id

> **index\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L186)

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L188)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L187)

##### testflight

> **testflight**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L182)

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L181)

***

### Timers

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L190)

#### Properties

##### last\_reset\_timestamp\_seconds

> **last\_reset\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L192)

##### last\_spawned\_timestamp\_seconds

> **last\_spawned\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L191)

##### requires\_periodic\_tasks

> **requires\_periodic\_tasks**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L193)

## Type Aliases

### CanisterInstallMode

> **CanisterInstallMode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: `null`; \} \| \{ `install`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L20)

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L45)

***

### CleanUpFailedRegisterExtensionResult

> **CleanUpFailedRegisterExtensionResult** = \{ `Ok`: \{ \}; \} \| \{ `Err`: [`CanisterCallError`](#canistercallerror); \}

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L72)

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L125)

***

### RegisterExtensionResult

> **RegisterExtensionResult** = \{ `Ok`: \{ \}; \} \| \{ `Err`: [`CanisterCallError`](#canistercallerror); \}

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L171)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L225)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/sns/root.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/root.d.ts#L226)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
