---
title: SnsGovernanceDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:899](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L899)

#### Properties

##### claim\_swap\_neurons

> **claim\_swap\_neurons**: `ActorMethod`\<\[[`ClaimSwapNeuronsRequest`](#claimswapneuronsrequest)\], [`ClaimSwapNeuronsResponse`](#claimswapneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L900)

##### fail\_stuck\_upgrade\_in\_progress

> **fail\_stuck\_upgrade\_in\_progress**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:904](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L904)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:905](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L905)

##### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](#rewardevent)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:906](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L906)

##### get\_maturity\_modulation

> **get\_maturity\_modulation**: `ActorMethod`\<\[\{ \}\], [`GetMaturityModulationResponse`](#getmaturitymodulationresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:907](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L907)

##### get\_metadata

> **get\_metadata**: `ActorMethod`\<\[\{ \}\], [`GetMetadataResponse`](#getmetadataresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:908](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L908)

##### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L909)

##### get\_metrics\_replicated

> **get\_metrics\_replicated**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:910](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L910)

##### get\_mode

> **get\_mode**: `ActorMethod`\<\[\{ \}\], [`GetModeResponse`](#getmoderesponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:911](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L911)

##### get\_nervous\_system\_parameters

> **get\_nervous\_system\_parameters**: `ActorMethod`\<\[`null`\], [`NervousSystemParameters`](#nervoussystemparameters)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:912](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L912)

##### get\_neuron

> **get\_neuron**: `ActorMethod`\<\[[`GetNeuron`](#getneuron)\], [`GetNeuronResponse`](#getneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L913)

##### get\_proposal

> **get\_proposal**: `ActorMethod`\<\[[`GetProposal`](#getproposal)\], [`GetProposalResponse`](#getproposalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L914)

##### get\_root\_canister\_status

> **get\_root\_canister\_status**: `ActorMethod`\<\[`null`\], [`CanisterStatusResultV2`](#canisterstatusresultv2)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L915)

##### get\_running\_sns\_version

> **get\_running\_sns\_version**: `ActorMethod`\<\[\{ \}\], [`GetRunningSnsVersionResponse`](#getrunningsnsversionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L916)

##### get\_sns\_initialization\_parameters

> **get\_sns\_initialization\_parameters**: `ActorMethod`\<\[\{ \}\], [`GetSnsInitializationParametersResponse`](#getsnsinitializationparametersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:917](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L917)

##### get\_timers

> **get\_timers**: `ActorMethod`\<\[\{ \}\], [`GetTimersResponse`](#gettimersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:921](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L921)

##### get\_upgrade\_journal

> **get\_upgrade\_journal**: `ActorMethod`\<\[[`GetUpgradeJournalRequest`](#getupgradejournalrequest)\], [`GetUpgradeJournalResponse`](#getupgradejournalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L922)

##### list\_nervous\_system\_functions

> **list\_nervous\_system\_functions**: `ActorMethod`\<\[\], [`ListNervousSystemFunctionsResponse`](#listnervoussystemfunctionsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:926](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L926)

##### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](#listneurons)\], [`ListNeuronsResponse`](#listneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:930](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L930)

##### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposals`](#listproposals)\], [`ListProposalsResponse`](#listproposalsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:931](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L931)

##### list\_topics

> **list\_topics**: `ActorMethod`\<\[[`ListTopicsRequest`](#listtopicsrequest)\], [`ListTopicsResponse`](#listtopicsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:932](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L932)

##### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuron`](#manageneuron)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:933](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L933)

##### reset\_timers

> **reset\_timers**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:934](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L934)

##### set\_mode

> **set\_mode**: `ActorMethod`\<\[[`SetMode`](#setmode)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:935](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L935)

***

### Account

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L13)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L15)

***

### AddNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L48)

#### Properties

##### permissions\_to\_add

> **permissions\_to\_add**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L49)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L50)

***

### AdvanceSnsTargetVersion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L52)

#### Properties

##### new\_target

> **new\_target**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L53)

***

### AdvanceSnsTargetVersionActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L55)

#### Properties

##### target\_version

> **target\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L56)

***

### Amount

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L58)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L59)

***

### Ballot

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L61)

#### Properties

##### cast\_timestamp\_seconds

> **cast\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L63)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L62)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L64)

***

### CachedUpgradeSteps

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L67)

#### Properties

##### requested\_timestamp\_seconds

> **requested\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L70)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L69)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L68)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L72)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L76)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L79)

##### memory\_metrics

> **memory\_metrics**: \[\] \| \[[`MemoryMetrics`](#memorymetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L73)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L75)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L80)

##### query\_stats

> **query\_stats**: \[\] \| \[[`QueryStats`](#querystats)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L78)

##### settings

> **settings**: [`DefiniteCanisterSettingsArgs`](#definitecanistersettingsargs)

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L77)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L74)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L86)

#### Properties

##### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L87)

***

### ChunkedCanisterWasm

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L89)

#### Properties

##### chunk\_hashes\_list

> **chunk\_hashes\_list**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L91)

##### store\_canister\_id

> **store\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L92)

##### wasm\_module\_hash

> **wasm\_module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L90)

***

### ClaimedSwapNeurons

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L109)

#### Properties

##### swap\_neurons

> **swap\_neurons**: [`SwapNeuron`](#swapneuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L110)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L94)

#### Properties

##### by

> **by**: \[\] \| \[[`By`](#by-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L95)

***

### ClaimOrRefreshResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L97)

#### Properties

##### refreshed\_neuron\_id

> **refreshed\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L98)

***

### ClaimSwapNeuronsRequest

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L100)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: \[\] \| \[[`NeuronRecipes`](#neuronrecipes)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L101)

***

### ClaimSwapNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L103)

#### Properties

##### claim\_swap\_neurons\_result

> **claim\_swap\_neurons\_result**: \[\] \| \[[`ClaimSwapNeuronsResult`](#claimswapneuronsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L104)

***

### Configure

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L156)

#### Properties

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L157)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L159)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L160)

***

### Decimal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:162](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L162)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L163)

***

### DefaultFollowees

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L165)

#### Properties

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L166)

***

### DefiniteCanisterSettingsArgs

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L168)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L174)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L171)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L169)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L173)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L172)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L170)

***

### DeregisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L176)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L177)

##### new\_controllers

> **new\_controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L178)

***

### Disburse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L180)

#### Properties

##### amount

> **amount**: \[\] \| \[[`Amount`](#amount)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L182)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L181)

***

### DisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L184)

#### Properties

##### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L186)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L185)

***

### DisburseMaturityInProgress

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L188)

#### Properties

##### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L191)

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L190)

##### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L192)

##### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L189)

***

### DisburseMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L194)

#### Properties

##### amount\_deducted\_e8s

> **amount\_deducted\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L196)

##### amount\_disbursed\_e8s

> **amount\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L195)

***

### DisburseResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L198)

#### Properties

##### transfer\_block\_height

> **transfer\_block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L199)

***

### ExecuteExtensionOperation

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L204)

#### Properties

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L205)

##### operation\_arg

> **operation\_arg**: \[\] \| \[[`ExtensionOperationArg`](#extensionoperationarg)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L207)

##### operation\_name

> **operation\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L206)

***

### ExecuteGenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L209)

#### Properties

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L210)

##### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L211)

***

### ExtensionInit

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L213)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L214)

***

### ExtensionOperationArg

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:216](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L216)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L217)

***

### ExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L219)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L222)

##### extension\_type

> **extension\_type**: \[\] \| \[[`ExtensionType`](#extensiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L223)

##### operation\_type

> **operation\_type**: \[\] \| \[[`ExtensionOperationType`](#extensionoperationtype)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L221)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L220)

***

### ExtensionUpgradeArg

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L229)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L230)

***

### FinalizeDisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L232)

#### Properties

##### amount\_to\_be\_disbursed\_e8s

> **amount\_to\_be\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L233)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L234)

***

### Follow

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L236)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L238)

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L237)

***

### Followee

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:240](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L240)

#### Properties

##### alias

> **alias**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L241)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L242)

***

### Followees

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L244)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L245)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L247)

#### Properties

##### followees

> **followees**: [`Followee`](#followee)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L249)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L248)

***

### GenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L254)

#### Properties

##### target\_canister\_id

> **target\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:257](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L257)

##### target\_method\_name

> **target\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L259)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L255)

##### validator\_canister\_id

> **validator\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L256)

##### validator\_method\_name

> **validator\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L258)

***

### GetMaturityModulationResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L261)

#### Properties

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L262)

***

### GetMetadataResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L264)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L268)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L266)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L267)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L265)

***

### GetMetricsRequest

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L270)

#### Properties

##### time\_window\_seconds

> **time\_window\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L271)

***

### GetMetricsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L273)

#### Properties

##### get\_metrics\_result

> **get\_metrics\_result**: \[\] \| \[[`GetMetricsResult`](#getmetricsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L274)

***

### GetModeResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L277)

#### Properties

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L278)

***

### GetNeuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L280)

#### Properties

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L281)

***

### GetNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L283)

#### Properties

##### result

> **result**: \[\] \| \[[`Result`](#result-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L284)

***

### GetProposal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L286)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L287)

***

### GetProposalResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L289)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L290)

***

### GetRunningSnsVersionResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L292)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L293)

##### pending\_version

> **pending\_version**: \[\] \| \[\{ `checking_upgrade_lock`: `bigint`; `mark_failed_at_seconds`: `bigint`; `proposal_id`: `bigint`; `target_version`: \[\] \| \[[`Version`](#version)\]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L294)

***

### GetSnsInitializationParametersResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L305)

#### Properties

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L306)

***

### GetTimersResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L308)

#### Properties

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L309)

***

### GetUpgradeJournalRequest

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L311)

#### Properties

##### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L313)

##### offset

> **offset**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L312)

***

### GetUpgradeJournalResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L315)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L319)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L318)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L320)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L316)

##### upgrade\_journal\_entry\_count

> **upgrade\_journal\_entry\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L321)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L317)

***

### Governance

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L323)

#### Properties

##### cached\_upgrade\_steps

> **cached\_upgrade\_steps**: \[\] \| \[[`CachedUpgradeSteps`](#cachedupgradesteps)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L326)

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L334)

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L345)

##### id\_to\_nervous\_system\_functions

> **id\_to\_nervous\_system\_functions**: \[`bigint`, [`NervousSystemFunction`](#nervoussystemfunction)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L327)

##### in\_flight\_commands

> **in\_flight\_commands**: \[`string`, [`NeuronInFlightCommand`](#neuroninflightcommand)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L341)

##### is\_finalizing\_disburse\_maturity

> **is\_finalizing\_disburse\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L333)

##### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](#rewardevent)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L336)

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L339)

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L329)

##### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](#governancecachedmetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L328)

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L331)

##### neurons

> **neurons**: \[`string`, [`Neuron`](#neuron)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L343)

##### parameters

> **parameters**: \[\] \| \[[`NervousSystemParameters`](#nervoussystemparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:332](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L332)

##### pending\_version

> **pending\_version**: \[\] \| \[[`PendingVersion`](#pendingversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L337)

##### proposals

> **proposals**: \[`bigint`, [`ProposalData`](#proposaldata)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L340)

##### root\_canister\_id

> **root\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L324)

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L335)

##### sns\_metadata

> **sns\_metadata**: \[\] \| \[[`ManageSnsMetadata`](#managesnsmetadata)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L342)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L338)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L344)

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L325)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L330)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L347)

#### Properties

##### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L354)

##### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L359)

##### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L362)

##### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L361)

##### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L363)

##### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L350)

##### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L351)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L353)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L360)

##### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L358)

##### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L352)

##### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L349)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L364)

##### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L355)

##### total\_supply\_governance\_tokens

> **total\_supply\_governance\_tokens**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L356)

##### treasury\_metrics

> **treasury\_metrics**: [`TreasuryMetrics`](#treasurymetrics)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L348)

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L357)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L366)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L367)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L368)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L370)

#### Properties

##### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L371)

***

### ListNervousSystemFunctionsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L373)

#### Properties

##### functions

> **functions**: [`NervousSystemFunction`](#nervoussystemfunction)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L375)

##### reserved\_ids

> **reserved\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L374)

***

### ListNeurons

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L377)

#### Properties

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L379)

##### of\_principal

> **of\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L378)

##### start\_page\_at

> **start\_page\_at**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L380)

***

### ListNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L382)

#### Properties

##### neurons

> **neurons**: [`Neuron`](#neuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L383)

***

### ListProposals

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L385)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L387)

##### exclude\_type

> **exclude\_type**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L389)

##### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L386)

##### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L391)

##### include\_topics

> **include\_topics**: \[\] \| \[[`TopicSelector`](#topicselector)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L390)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L388)

***

### ListProposalsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L393)

#### Properties

##### include\_ballots\_by\_caller

> **include\_ballots\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L394)

##### include\_topic\_filtering

> **include\_topic\_filtering**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L396)

##### proposals

> **proposals**: [`ProposalData`](#proposaldata)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L395)

***

### ListTopicsResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L399)

#### Properties

##### topics

> **topics**: \[\] \| \[[`TopicInfo`](#topicinfo)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L401)

##### uncategorized\_functions

> **uncategorized\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L400)

***

### ManageDappCanisterSettings

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L403)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L406)

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L412)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L404)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L408)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L411)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L407)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L409)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L410)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L405)

***

### ManageLedgerParameters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L414)

#### Properties

##### token\_logo

> **token\_logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L417)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L418)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L415)

##### transfer\_fee

> **transfer\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L416)

***

### ManageNeuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L420)

#### Properties

##### command

> **command**: \[\] \| \[[`Command`](#command-3)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L422)

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L421)

***

### ManageNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L424)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_1`](#command_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L425)

***

### ManageSnsMetadata

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L427)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L431)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L429)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L430)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L428)

***

### MaturityModulation

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L433)

#### Properties

##### current\_basis\_points

> **current\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L434)

##### updated\_at\_timestamp\_seconds

> **updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L435)

***

### MemoAndController

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L437)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L438)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L439)

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L441)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L444)

##### custom\_sections\_size

> **custom\_sections\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L449)

##### global\_memory\_size

> **global\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L448)

##### snapshots\_size

> **snapshots\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L446)

##### stable\_memory\_size

> **stable\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L445)

##### wasm\_binary\_size

> **wasm\_binary\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L442)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L443)

##### wasm\_memory\_size

> **wasm\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L447)

***

### MergeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L451)

#### Properties

##### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L452)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L454)

#### Properties

##### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L455)

##### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L456)

***

### Metrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L458)

#### Properties

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L467)

##### last\_ledger\_block\_timestamp

> **last\_ledger\_block\_timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L464)

##### num\_recently\_executed\_proposals

> **num\_recently\_executed\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L465)

##### num\_recently\_submitted\_proposals

> **num\_recently\_submitted\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L466)

##### treasury\_metrics

> **treasury\_metrics**: \[\] \| \[[`TreasuryMetrics`](#treasurymetrics)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L462)

The metrics below are cached (albeit this is an implementation detail).

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L463)

***

### MintSnsTokens

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L469)

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L473)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L472)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L470)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L471)

***

### MintSnsTokensActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L475)

#### Properties

##### valuation

> **valuation**: \[\] \| \[[`Valuation`](#valuation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L476)

***

### Motion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L478)

#### Properties

##### motion\_text

> **motion\_text**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:479](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L479)

***

### NervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L481)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L484)

##### function\_type

> **function\_type**: \[\] \| \[[`FunctionType`](#functiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L485)

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L482)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L483)

***

### NervousSystemParameters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L487)

#### Properties

##### automatically\_advance\_target\_version

> **automatically\_advance\_target\_version**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L492)

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L503)

##### default\_followees

> **default\_followees**: \[\] \| \[[`DefaultFollowees`](#defaultfollowees)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L488)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L496)

##### maturity\_modulation\_disabled

> **maturity\_modulation\_disabled**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L508)

##### max\_age\_bonus\_percentage

> **max\_age\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L505)

##### max\_dissolve\_delay\_bonus\_percentage

> **max\_dissolve\_delay\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L490)

##### max\_dissolve\_delay\_seconds

> **max\_dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L489)

##### max\_followees\_per\_function

> **max\_followees\_per\_function**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L491)

##### max\_neuron\_age\_for\_age\_bonus

> **max\_neuron\_age\_for\_age\_bonus**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L495)

##### max\_number\_of\_neurons

> **max\_number\_of\_neurons**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L501)

##### max\_number\_of\_principals\_per\_neuron

> **max\_number\_of\_principals\_per\_neuron**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L509)

##### max\_number\_of\_proposals\_with\_ballots

> **max\_number\_of\_proposals\_with\_ballots**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L504)

##### max\_proposals\_to\_keep\_per\_action

> **max\_proposals\_to\_keep\_per\_action**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L499)

##### neuron\_claimer\_permissions

> **neuron\_claimer\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L493)

##### neuron\_grantable\_permissions

> **neuron\_grantable\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L506)

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L497)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L494)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L498)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L502)

##### voting\_rewards\_parameters

> **voting\_rewards\_parameters**: \[\] \| \[[`VotingRewardsParameters`](#votingrewardsparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L507)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L500)

***

### Neuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L511)

#### Properties

##### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L523)

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L522)

##### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L516)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L517)

##### disburse\_maturity\_in\_progress

> **disburse\_maturity\_in\_progress**: [`DisburseMaturityInProgress`](#disbursematurityinprogress)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L527)

##### dissolve\_state

> **dissolve\_state**: \[\] \| \[[`DissolveState`](#dissolvestate)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L524)

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L528)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L512)

##### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L515)

##### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L529)

##### permissions

> **permissions**: [`NeuronPermission`](#neuronpermission)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L514)

##### source\_nns\_neuron\_id

> **source\_nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L521)

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L513)

##### topic\_followees

> **topic\_followees**: \[\] \| \[\{ `topic_id_to_followees`: \[`number`, [`FolloweesForTopic`](#followeesfortopic)\][]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L518)

##### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L526)

##### voting\_power\_percentage\_multiplier

> **voting\_power\_percentage\_multiplier**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L525)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L531)

#### Properties

##### id

> **id**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L532)

***

### NeuronIds

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L534)

#### Properties

##### neuron\_ids

> **neuron\_ids**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L535)

***

### NeuronInFlightCommand

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L537)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_2`](#command_2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L538)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L539)

***

### NeuronPermission

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L541)

#### Properties

##### permission\_type

> **permission\_type**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L543)

##### principal

> **principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L542)

***

### NeuronPermissionList

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:545](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L545)

#### Properties

##### permissions

> **permissions**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L546)

***

### NeuronRecipe

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:548](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L548)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L549)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L550)

##### followees

> **followees**: \[\] \| \[[`NeuronIds`](#neuronids)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L553)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L554)

##### participant

> **participant**: \[\] \| \[[`Participant`](#participant-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L551)

##### stake\_e8s

> **stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L552)

***

### NeuronRecipes

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L556)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: [`NeuronRecipe`](#neuronrecipe)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L557)

***

### NeuronsFund

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L559)

#### Properties

##### nns\_neuron\_controller

> **nns\_neuron\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L561)

##### nns\_neuron\_hotkeys

> **nns\_neuron\_hotkeys**: \[\] \| \[[`Principals`](#principals)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L560)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:562](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L562)

***

### PendingVersion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L573)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L575)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L574)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L576)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L577)

***

### Percentage

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L579)

#### Properties

##### basis\_points

> **basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L580)

***

### Principals

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:606](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L606)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:607](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L607)

***

### Proposal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:609](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L609)

#### Properties

##### action

> **action**: \[\] \| \[[`Action`](#action-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:612](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L612)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:613](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L613)

##### title

> **title**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L611)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L610)

***

### ProposalData

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L615)

#### Properties

##### action

> **action**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:619](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L619)

##### action\_auxiliary

> **action\_auxiliary**: \[\] \| \[[`ActionAuxiliary`](#actionauxiliary)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L621)

##### ballots

> **ballots**: \[`string`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:622](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L622)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:632](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L632)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L638)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L625)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:620](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L620)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L616)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:628](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L628)

##### is\_eligible\_for\_rewards

> **is\_eligible\_for\_rewards**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:637](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L637)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L630)

##### minimum\_yes\_proportion\_of\_exercised

> **minimum\_yes\_proportion\_of\_exercised**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:636](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L636)

##### minimum\_yes\_proportion\_of\_total

> **minimum\_yes\_proportion\_of\_total**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:623](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L623)

##### payload\_text\_rendering

> **payload\_text\_rendering**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L617)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L633)

##### proposal\_creation\_timestamp\_seconds

> **proposal\_creation\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L627)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L634)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:629](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L629)

##### reward\_event\_end\_timestamp\_seconds

> **reward\_event\_end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L626)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L624)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L618)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L631)

##### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](#waitforquietstate)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L635)

***

### ProposalId

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L640)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L641)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L643)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:646](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L646)

##### num\_instructions\_total

> **num\_instructions\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L645)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L647)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L644)

***

### RegisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:649](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L649)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:650](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L650)

***

### RegisteredExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:660](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L660)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L662)

##### spec

> **spec**: \[\] \| \[[`ExtensionOperationSpec`](#extensionoperationspec)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:661](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L661)

***

### RegisterExtension

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:652](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L652)

#### Properties

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L653)

##### extension\_init

> **extension\_init**: \[\] \| \[[`ExtensionInit`](#extensioninit)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L654)

***

### RegisterVote

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L656)

#### Properties

##### proposal

> **proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L658)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:657](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L657)

***

### RemoveNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:664](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L664)

#### Properties

##### permissions\_to\_remove

> **permissions\_to\_remove**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:665](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L665)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L666)

***

### RewardEvent

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L670)

#### Properties

##### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:672](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L672)

##### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:675](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L675)

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:673](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L673)

##### round

> **round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L676)

##### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:671](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L671)

##### settled\_proposals

> **settled\_proposals**: [`ProposalId`](#proposalid)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:677](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L677)

##### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L674)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:679](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L679)

#### Properties

##### dissolve\_timestamp\_seconds

> **dissolve\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L680)

***

### SetFollowing

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:682](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L682)

#### Properties

##### topic\_following

> **topic\_following**: [`FolloweesForTopic`](#followeesfortopic)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:683](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L683)

***

### SetMode

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:685](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L685)

#### Properties

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:686](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L686)

***

### SetTopicsForCustomProposals

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:688](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L688)

#### Properties

##### custom\_function\_id\_to\_topic

> **custom\_function\_id\_to\_topic**: \[`bigint`, [`Topic`](#topic-6)\][]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L689)

***

### SnsVersion

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:691](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L691)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:692](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L692)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:696](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L696)

##### index\_wasm\_hash

> **index\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:697](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L697)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:695](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L695)

##### root\_wasm\_hash

> **root\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:693](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L693)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:694](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L694)

***

### Split

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:699](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L699)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:701](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L701)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:700](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L700)

***

### SplitResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:703](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L703)

#### Properties

##### created\_neuron\_id

> **created\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:704](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L704)

***

### StakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:706](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L706)

#### Properties

##### percentage\_to\_stake

> **percentage\_to\_stake**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:707](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L707)

***

### StakeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:709](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L709)

#### Properties

##### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:710](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L710)

##### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:711](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L711)

***

### Subaccount

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:713](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L713)

#### Properties

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:714](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L714)

***

### SwapNeuron

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:716](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L716)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:717](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L717)

##### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:718](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L718)

***

### Tally

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:720](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L720)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:721](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L721)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:724](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L724)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:723](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L723)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:722](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L722)

***

### TargetVersionReset

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:726](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L726)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:727](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L727)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:729](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L729)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L728)

***

### TargetVersionSet

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:731](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L731)

#### Properties

##### is\_advanced\_automatically

> **is\_advanced\_automatically**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L734)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:733](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L733)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L732)

***

### Timers

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:736](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L736)

#### Properties

##### last\_reset\_timestamp\_seconds

> **last\_reset\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:738](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L738)

##### last\_spawned\_timestamp\_seconds

> **last\_spawned\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:737](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L737)

##### requires\_periodic\_tasks

> **requires\_periodic\_tasks**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L739)

***

### Tokens

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:741](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L741)

#### Properties

##### e8s

> **e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L742)

***

### TopicInfo

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L752)

#### Properties

##### custom\_functions

> **custom\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L759)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:758](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L758)

##### extension\_operations

> **extension\_operations**: \[\] \| \[[`RegisteredExtensionOperationSpec`](#registeredextensionoperationspec)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:753](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L753)

##### is\_critical

> **is\_critical**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:756](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L756)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:757](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L757)

##### native\_functions

> **native\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L754)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:755](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L755)

***

### TopicSelector

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:761](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L761)

#### Properties

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:762](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L762)

***

### TransferSnsTreasuryFunds

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:764](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L764)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:769](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L769)

##### from\_treasury

> **from\_treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:765](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L765)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:768](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L768)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:766](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L766)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:767](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L767)

***

### TreasuryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L771)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:784](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L784)

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:783](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L783)

The regularly updated amount of tokens in this treasury.

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:788](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L788)

The source of truth for the treasury balance is this ledger canister / account.

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L775)

A human-readable identified for this treasury, e.g., "ICP".

##### original\_amount\_e8s

> **original\_amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L779)

The amount of tokens in this treasury at the end of swap finalization.

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:796](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L796)

When the metrics were last updated.

##### treasury

> **treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:792](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L792)

Same as, e.g., `TransferSnsTreasuryFunds.from_treasury`.

***

### UpgradeExtension

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:798](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L798)

#### Properties

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[[`ExtensionUpgradeArg`](#extensionupgradearg)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:801](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L801)

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:799](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L799)

##### wasm

> **wasm**: \[\] \| \[[`Wasm`](#wasm-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:800](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L800)

***

### UpgradeInProgress

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:803](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L803)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:805](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L805)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:804](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L804)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:806](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L806)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:807](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L807)

***

### UpgradeJournal

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:809](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L809)

#### Properties

##### entries

> **entries**: [`UpgradeJournalEntry`](#upgradejournalentry)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:810](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L810)

***

### UpgradeJournalEntry

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:812](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L812)

#### Properties

##### event

> **event**: \[\] \| \[\{ `TargetVersionSet`: [`TargetVersionSet`](#targetversionset); \} \| \{ `UpgradeStepsReset`: [`UpgradeStepsReset`](#upgradestepsreset); \} \| \{ `UpgradeOutcome`: [`UpgradeOutcome`](#upgradeoutcome); \} \| \{ `UpgradeStarted`: [`UpgradeStarted`](#upgradestarted); \} \| \{ `UpgradeStepsRefreshed`: [`UpgradeStepsRefreshed`](#upgradestepsrefreshed); \} \| \{ `TargetVersionReset`: [`TargetVersionReset`](#targetversionreset); \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:813](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L813)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:823](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L823)

***

### UpgradeOutcome

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:825](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L825)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:834](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L834)

##### status

> **status**: \[\] \| \[\{ `Success`: \{ \}; \} \| \{ `Timeout`: \{ \}; \} \| \{ `ExternalFailure`: \{ \}; \} \| \{ `InvalidState`: \{ `version`: \[\] \| \[[`Version`](#version)\]; \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:826](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L826)

***

### UpgradeSnsControlledCanister

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:836](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L836)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:839](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L839)

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:841](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L841)

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:840](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L840)

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:838](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L838)

##### new\_canister\_wasm

> **new\_canister\_wasm**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:837](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L837)

***

### UpgradeStarted

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:843](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L843)

#### Properties

##### current\_version

> **current\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:844](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L844)

##### expected\_version

> **expected\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:845](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L845)

##### reason

> **reason**: \[\] \| \[\{ `UpgradeSnsToNextVersionProposal`: [`ProposalId`](#proposalid); \} \| \{ `BehindTargetVersion`: \{ \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:846](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L846)

***

### UpgradeStepsRefreshed

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:853](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L853)

#### Properties

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:854](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L854)

***

### UpgradeStepsReset

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L856)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:857](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L857)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:858](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L858)

***

### Valuation

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:860](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L860)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:862](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L862)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:864](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L864)

##### token

> **token**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:861](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L861)

##### valuation\_factors

> **valuation\_factors**: \[\] \| \[[`ValuationFactors`](#valuationfactors)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:863](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L863)

***

### ValuationFactors

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:866](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L866)

#### Properties

##### icps\_per\_token

> **icps\_per\_token**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:868](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L868)

##### tokens

> **tokens**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:869](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L869)

##### xdrs\_per\_icp

> **xdrs\_per\_icp**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:867](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L867)

***

### Version

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:871](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L871)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:872](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L872)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:876](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L876)

##### index\_wasm\_hash

> **index\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:877](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L877)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L875)

##### root\_wasm\_hash

> **root\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L873)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L874)

***

### Versions

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:879](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L879)

#### Properties

##### versions

> **versions**: [`Version`](#version)[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:880](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L880)

***

### VotingPowerMetrics

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:882](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L882)

#### Properties

##### governance\_total\_potential\_voting\_power

> **governance\_total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:883](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L883)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L887)

When the metrics were last updated.

***

### VotingRewardsParameters

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L889)

#### Properties

##### final\_reward\_rate\_basis\_points

> **final\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L890)

##### initial\_reward\_rate\_basis\_points

> **initial\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L891)

##### reward\_rate\_transition\_duration\_seconds

> **reward\_rate\_transition\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:892](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L892)

##### round\_duration\_seconds

> **round\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L893)

***

### WaitForQuietState

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L895)

#### Properties

##### current\_deadline\_timestamp\_seconds

> **current\_deadline\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:896](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L896)

## Type Aliases

### Action

> **Action** = \{ `ManageNervousSystemParameters`: [`NervousSystemParameters`](#nervoussystemparameters); \} \| \{ `AddGenericNervousSystemFunction`: [`NervousSystemFunction`](#nervoussystemfunction); \} \| \{ `ManageDappCanisterSettings`: [`ManageDappCanisterSettings`](#managedappcanistersettings); \} \| \{ `ExecuteExtensionOperation`: [`ExecuteExtensionOperation`](#executeextensionoperation); \} \| \{ `UpgradeExtension`: [`UpgradeExtension`](#upgradeextension); \} \| \{ `RemoveGenericNervousSystemFunction`: `bigint`; \} \| \{ `SetTopicsForCustomProposals`: [`SetTopicsForCustomProposals`](#settopicsforcustomproposals); \} \| \{ `RegisterExtension`: [`RegisterExtension`](#registerextension); \} \| \{ `UpgradeSnsToNextVersion`: \{ \}; \} \| \{ `RegisterDappCanisters`: [`RegisterDappCanisters`](#registerdappcanisters); \} \| \{ `TransferSnsTreasuryFunds`: [`TransferSnsTreasuryFunds`](#transfersnstreasuryfunds); \} \| \{ `UpgradeSnsControlledCanister`: [`UpgradeSnsControlledCanister`](#upgradesnscontrolledcanister); \} \| \{ `DeregisterDappCanisters`: [`DeregisterDappCanisters`](#deregisterdappcanisters); \} \| \{ `MintSnsTokens`: [`MintSnsTokens`](#mintsnstokens); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersion`](#advancesnstargetversion); \} \| \{ `Unspecified`: \{ \}; \} \| \{ `ManageSnsMetadata`: [`ManageSnsMetadata`](#managesnsmetadata); \} \| \{ `ExecuteGenericNervousSystemFunction`: [`ExecuteGenericNervousSystemFunction`](#executegenericnervoussystemfunction); \} \| \{ `ManageLedgerParameters`: [`ManageLedgerParameters`](#manageledgerparameters); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L17)

***

### ActionAuxiliary

> **ActionAuxiliary** = \{ `TransferSnsTreasuryFunds`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `MintSnsTokens`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersionActionAuxiliary`](#advancesnstargetversionactionauxiliary); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L42)

***

### By

> **By** = \{ `MemoAndController`: [`MemoAndController`](#memoandcontroller); \} \| \{ `NeuronId`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L66)

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L82)

***

### ClaimSwapNeuronsResult

> **ClaimSwapNeuronsResult** = \{ `Ok`: [`ClaimedSwapNeurons`](#claimedswapneurons); \} \| \{ `Err`: `number`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L106)

***

### Command

> **Command** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L112)

***

### Command\_1

> **Command\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Split`: [`SplitResponse`](#splitresponse); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](#disbursematurityresponse); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](#claimorrefreshresponse); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `SetFollowing`: \{ \}; \} \| \{ `MakeProposal`: [`GetProposal`](#getproposal); \} \| \{ `RemoveNeuronPermission`: \{ \}; \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](#stakematurityresponse); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](#mergematurityresponse); \} \| \{ `Disburse`: [`DisburseResponse`](#disburseresponse); \} \| \{ `AddNeuronPermission`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L126)

***

### Command\_2

> **Command\_2** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `FinalizeDisburseMaturity`: [`FinalizeDisburseMaturity`](#finalizedisbursematurity); \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L141)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L201)

***

### ExtensionOperationType

> **ExtensionOperationType** = \{ `TreasuryManagerWithdraw`: `null`; \} \| \{ `TreasuryManagerDeposit`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L225)

***

### ExtensionType

> **ExtensionType** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L228)

#### Properties

##### TreasuryManager

> **TreasuryManager**: `null`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L228)

***

### FunctionType

> **FunctionType** = \{ `NativeNervousSystemFunction`: \{ \}; \} \| \{ `GenericNervousSystemFunction`: [`GenericNervousSystemFunction`](#genericnervoussystemfunction); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L251)

***

### GetMetricsResult

> **GetMetricsResult** = \{ `Ok`: [`Metrics`](#metrics-1); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L276)

***

### ListTopicsRequest

> **ListTopicsRequest** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L398)

***

### Operation

> **Operation** = \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay); \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L564)

***

### Participant

> **Participant** = \{ `NeuronsFund`: [`NeuronsFund`](#neuronsfund); \} \| \{ `Direct`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L572)

***

### PreciseValue

> **PreciseValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`PreciseValue`](#precisevalue)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`PreciseValue`](#precisevalue)[]; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:598](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L598)

This type is equivalant to `ICRC3Value`, but we give it another name since it is used here not
in the context of the ICRC-3 ledger standard. The justification is the same: The candid format
supports sharing information even when the client and the server involved do not have the same
schema (see the Upgrading and subtyping section of the candid spec). While this mechanism allows
to evolve services and clients independently without breaking them, it also means that a client
may not receive all the information that the server is sending, e.g. in case the client schema
lacks some fields that the server schema has.

This loss of information is not an option for SNS voters deciding if an extension with particular
init args should be installed or if an extension function with particular arguments should be
called. The client must receive the same exact data the server sent in order to verify it.

Verification of a priorly installed extension is done by hashing the extension's init arg data
and checking that the result is consistent with what has been certified by the SNS.

***

### Result

> **Result** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Neuron`: [`Neuron`](#neuron); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:668](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L668)

***

### Result\_1

> **Result\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Proposal`: [`ProposalData`](#proposaldata); \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:669](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L669)

***

### Topic

> **Topic** = \{ `DappCanisterManagement`: `null`; \} \| \{ `DaoCommunitySettings`: `null`; \} \| \{ `ApplicationBusinessLogic`: `null`; \} \| \{ `CriticalDappOperations`: `null`; \} \| \{ `TreasuryAssetManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsFrameworkManagement`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:744](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L744)

***

### Wasm

> **Wasm** = \{ `Chunked`: [`ChunkedCanisterWasm`](#chunkedcanisterwasm); \} \| \{ `Bytes`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L898)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:937](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L937)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/sns/governance.d.ts:938](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance.d.ts#L938)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
