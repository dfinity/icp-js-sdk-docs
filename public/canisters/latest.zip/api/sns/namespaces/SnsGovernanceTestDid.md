---
title: SnsGovernanceTestDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:917](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L917)

#### Properties

##### add\_maturity

> **add\_maturity**: `ActorMethod`\<\[[`AddMaturityRequest`](#addmaturityrequest)\], [`AddMaturityResponse`](#addmaturityresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:921](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L921)

The following are methods for feature = "test"

##### advance\_target\_version

> **advance\_target\_version**: `ActorMethod`\<\[[`AdvanceTargetVersionRequest`](#advancetargetversionrequest)\], [`AdvanceTargetVersionResponse`](#advancetargetversionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L922)

##### claim\_swap\_neurons

> **claim\_swap\_neurons**: `ActorMethod`\<\[[`ClaimSwapNeuronsRequest`](#claimswapneuronsrequest)\], [`ClaimSwapNeuronsResponse`](#claimswapneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:926](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L926)

##### fail\_stuck\_upgrade\_in\_progress

> **fail\_stuck\_upgrade\_in\_progress**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:930](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L930)

##### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:931](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L931)

##### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](#rewardevent)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:932](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L932)

##### get\_maturity\_modulation

> **get\_maturity\_modulation**: `ActorMethod`\<\[\{ \}\], [`GetMaturityModulationResponse`](#getmaturitymodulationresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:933](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L933)

##### get\_metadata

> **get\_metadata**: `ActorMethod`\<\[\{ \}\], [`GetMetadataResponse`](#getmetadataresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:934](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L934)

##### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:935](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L935)

##### get\_metrics\_replicated

> **get\_metrics\_replicated**: `ActorMethod`\<\[[`GetMetricsRequest`](#getmetricsrequest)\], [`GetMetricsResponse`](#getmetricsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:936](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L936)

##### get\_mode

> **get\_mode**: `ActorMethod`\<\[\{ \}\], [`GetModeResponse`](#getmoderesponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:937](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L937)

##### get\_nervous\_system\_parameters

> **get\_nervous\_system\_parameters**: `ActorMethod`\<\[`null`\], [`NervousSystemParameters`](#nervoussystemparameters)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:938](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L938)

##### get\_neuron

> **get\_neuron**: `ActorMethod`\<\[[`GetNeuron`](#getneuron)\], [`GetNeuronResponse`](#getneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:939](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L939)

##### get\_proposal

> **get\_proposal**: `ActorMethod`\<\[[`GetProposal`](#getproposal)\], [`GetProposalResponse`](#getproposalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:940](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L940)

##### get\_root\_canister\_status

> **get\_root\_canister\_status**: `ActorMethod`\<\[`null`\], [`CanisterStatusResultV2`](#canisterstatusresultv2)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:941](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L941)

##### get\_running\_sns\_version

> **get\_running\_sns\_version**: `ActorMethod`\<\[\{ \}\], [`GetRunningSnsVersionResponse`](#getrunningsnsversionresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:942](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L942)

##### get\_sns\_initialization\_parameters

> **get\_sns\_initialization\_parameters**: `ActorMethod`\<\[\{ \}\], [`GetSnsInitializationParametersResponse`](#getsnsinitializationparametersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:943](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L943)

##### get\_timers

> **get\_timers**: `ActorMethod`\<\[\{ \}\], [`GetTimersResponse`](#gettimersresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:947](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L947)

##### get\_upgrade\_journal

> **get\_upgrade\_journal**: `ActorMethod`\<\[[`GetUpgradeJournalRequest`](#getupgradejournalrequest)\], [`GetUpgradeJournalResponse`](#getupgradejournalresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L948)

##### list\_nervous\_system\_functions

> **list\_nervous\_system\_functions**: `ActorMethod`\<\[\], [`ListNervousSystemFunctionsResponse`](#listnervoussystemfunctionsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:952](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L952)

##### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](#listneurons)\], [`ListNeuronsResponse`](#listneuronsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:956](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L956)

##### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposals`](#listproposals)\], [`ListProposalsResponse`](#listproposalsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:957](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L957)

##### list\_topics

> **list\_topics**: `ActorMethod`\<\[[`ListTopicsRequest`](#listtopicsrequest)\], [`ListTopicsResponse`](#listtopicsresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:958](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L958)

##### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuron`](#manageneuron)\], [`ManageNeuronResponse`](#manageneuronresponse)\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:959](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L959)

##### mint\_tokens

> **mint\_tokens**: `ActorMethod`\<\[[`MintTokensRequest`](#minttokensrequest)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:960](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L960)

##### refresh\_cached\_upgrade\_steps

> **refresh\_cached\_upgrade\_steps**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:961](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L961)

##### reset\_timers

> **reset\_timers**: `ActorMethod`\<\[\{ \}\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:962](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L962)

##### set\_mode

> **set\_mode**: `ActorMethod`\<\[[`SetMode`](#setmode)\], \{ \}\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:963](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L963)

##### update\_neuron

> **update\_neuron**: `ActorMethod`\<\[[`Neuron`](#neuron)\], \[\] \| \[[`GovernanceError`](#governanceerror)\]\>

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:964](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L964)

***

### Account

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L13)

#### Properties

##### owner

> **owner**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L15)

***

### AddMaturityRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L51)

The following types are for feature = "test"

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L53)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L52)

***

### AddMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L55)

#### Properties

##### new\_maturity\_e8s

> **new\_maturity\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L56)

***

### AddNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L58)

#### Properties

##### permissions\_to\_add

> **permissions\_to\_add**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L59)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L60)

***

### AdvanceSnsTargetVersion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L62)

#### Properties

##### new\_target

> **new\_target**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L63)

***

### AdvanceSnsTargetVersionActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L65)

#### Properties

##### target\_version

> **target\_version**: \[\] \| \[[`SnsVersion`](#snsversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L66)

***

### AdvanceTargetVersionRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L68)

#### Properties

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L69)

***

### Amount

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L72)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L73)

***

### Ballot

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L75)

#### Properties

##### cast\_timestamp\_seconds

> **cast\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L77)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L76)

##### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L78)

***

### CachedUpgradeSteps

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L81)

#### Properties

##### requested\_timestamp\_seconds

> **requested\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L84)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L83)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L82)

***

### CanisterStatusResultV2

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L86)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L90)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L93)

##### memory\_metrics

> **memory\_metrics**: \[\] \| \[[`MemoryMetrics`](#memorymetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L87)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L89)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L94)

##### query\_stats

> **query\_stats**: \[\] \| \[[`QueryStats`](#querystats)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L92)

##### settings

> **settings**: [`DefiniteCanisterSettingsArgs`](#definitecanistersettingsargs)

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L91)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L88)

***

### ChangeAutoStakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L100)

#### Properties

##### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L101)

***

### ChunkedCanisterWasm

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L103)

#### Properties

##### chunk\_hashes\_list

> **chunk\_hashes\_list**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L105)

##### store\_canister\_id

> **store\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L106)

##### wasm\_module\_hash

> **wasm\_module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L104)

***

### ClaimedSwapNeurons

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L123)

#### Properties

##### swap\_neurons

> **swap\_neurons**: [`SwapNeuron`](#swapneuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L124)

***

### ClaimOrRefresh

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L108)

#### Properties

##### by

> **by**: \[\] \| \[[`By`](#by-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L109)

***

### ClaimOrRefreshResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L111)

#### Properties

##### refreshed\_neuron\_id

> **refreshed\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L112)

***

### ClaimSwapNeuronsRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L114)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: \[\] \| \[[`NeuronRecipes`](#neuronrecipes)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L115)

***

### ClaimSwapNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L117)

#### Properties

##### claim\_swap\_neurons\_result

> **claim\_swap\_neurons\_result**: \[\] \| \[[`ClaimSwapNeuronsResult`](#claimswapneuronsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L118)

***

### Configure

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L170)

#### Properties

##### operation

> **operation**: \[\] \| \[[`Operation`](#operation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L171)

***

### CustomProposalCriticality

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L173)

#### Properties

##### additional\_critical\_native\_action\_ids

> **additional\_critical\_native\_action\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L174)

***

### Decimal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L176)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L177)

***

### DefaultFollowees

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:179](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L179)

#### Properties

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L180)

***

### DefiniteCanisterSettingsArgs

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L182)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L188)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L185)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L183)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L187)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L186)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L184)

***

### DeregisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L190)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L191)

##### new\_controllers

> **new\_controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L192)

***

### Disburse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:194](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L194)

#### Properties

##### amount

> **amount**: \[\] \| \[[`Amount`](#amount)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L196)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L195)

***

### DisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L198)

#### Properties

##### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L200)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L199)

***

### DisburseMaturityInProgress

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L202)

#### Properties

##### account\_to\_disburse\_to

> **account\_to\_disburse\_to**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L205)

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L204)

##### finalize\_disbursement\_timestamp\_seconds

> **finalize\_disbursement\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L206)

##### timestamp\_of\_disbursement\_seconds

> **timestamp\_of\_disbursement\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L203)

***

### DisburseMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L208)

#### Properties

##### amount\_deducted\_e8s

> **amount\_deducted\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L210)

##### amount\_disbursed\_e8s

> **amount\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L209)

***

### DisburseResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L212)

#### Properties

##### transfer\_block\_height

> **transfer\_block\_height**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L213)

***

### ExecuteExtensionOperation

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L218)

#### Properties

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L219)

##### operation\_arg

> **operation\_arg**: \[\] \| \[[`ExtensionOperationArg`](#extensionoperationarg)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L221)

##### operation\_name

> **operation\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L220)

***

### ExecuteGenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L223)

#### Properties

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L224)

##### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L225)

***

### ExtensionInit

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L227)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L228)

***

### ExtensionOperationArg

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L230)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L231)

***

### ExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L233)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L236)

##### extension\_type

> **extension\_type**: \[\] \| \[[`ExtensionType`](#extensiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L237)

##### operation\_type

> **operation\_type**: \[\] \| \[[`ExtensionOperationType`](#extensionoperationtype)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L235)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L234)

***

### ExtensionUpgradeArg

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L243)

#### Properties

##### value

> **value**: \[\] \| \[[`PreciseValue`](#precisevalue)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L244)

***

### FinalizeDisburseMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L246)

#### Properties

##### amount\_to\_be\_disbursed\_e8s

> **amount\_to\_be\_disbursed\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L247)

##### to\_account

> **to\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:248](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L248)

***

### Follow

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L250)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L252)

##### function\_id

> **function\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L251)

***

### Followee

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L254)

#### Properties

##### alias

> **alias**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L255)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L256)

***

### Followees

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L258)

#### Properties

##### followees

> **followees**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L259)

***

### FolloweesForTopic

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L261)

#### Properties

##### followees

> **followees**: [`Followee`](#followee)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L263)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L262)

***

### GenericNervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L268)

#### Properties

##### target\_canister\_id

> **target\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L271)

##### target\_method\_name

> **target\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L273)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L269)

##### validator\_canister\_id

> **validator\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L270)

##### validator\_method\_name

> **validator\_method\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L272)

***

### GetMaturityModulationResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L275)

#### Properties

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L276)

***

### GetMetadataResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L278)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L282)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L280)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L281)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L279)

***

### GetMetricsRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L284)

#### Properties

##### time\_window\_seconds

> **time\_window\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L285)

***

### GetMetricsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L287)

#### Properties

##### get\_metrics\_result

> **get\_metrics\_result**: \[\] \| \[[`GetMetricsResult`](#getmetricsresult)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L288)

***

### GetModeResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L291)

#### Properties

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L292)

***

### GetNeuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L294)

#### Properties

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L295)

***

### GetNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L297)

#### Properties

##### result

> **result**: \[\] \| \[[`Result`](#result-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L298)

***

### GetProposal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L300)

#### Properties

##### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L301)

***

### GetProposalResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L303)

#### Properties

##### result

> **result**: \[\] \| \[[`Result_1`](#result_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L304)

***

### GetRunningSnsVersionResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L306)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L307)

##### pending\_version

> **pending\_version**: \[\] \| \[\{ `checking_upgrade_lock`: `bigint`; `mark_failed_at_seconds`: `bigint`; `proposal_id`: `bigint`; `target_version`: \[\] \| \[[`Version`](#version)\]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L308)

***

### GetSnsInitializationParametersResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L319)

#### Properties

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L320)

***

### GetTimersResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L322)

#### Properties

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L323)

***

### GetUpgradeJournalRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L325)

#### Properties

##### limit

> **limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L327)

##### offset

> **offset**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L326)

***

### GetUpgradeJournalResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L329)

#### Properties

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L333)

##### response\_timestamp\_seconds

> **response\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:332](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L332)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L334)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L330)

##### upgrade\_journal\_entry\_count

> **upgrade\_journal\_entry\_count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L335)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L331)

***

### Governance

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L337)

#### Properties

##### cached\_upgrade\_steps

> **cached\_upgrade\_steps**: \[\] \| \[[`CachedUpgradeSteps`](#cachedupgradesteps)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L340)

##### deployed\_version

> **deployed\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L348)

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L359)

##### id\_to\_nervous\_system\_functions

> **id\_to\_nervous\_system\_functions**: \[`bigint`, [`NervousSystemFunction`](#nervoussystemfunction)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L341)

##### in\_flight\_commands

> **in\_flight\_commands**: \[`string`, [`NeuronInFlightCommand`](#neuroninflightcommand)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L355)

##### is\_finalizing\_disburse\_maturity

> **is\_finalizing\_disburse\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L347)

##### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](#rewardevent)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L350)

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L353)

##### maturity\_modulation

> **maturity\_modulation**: \[\] \| \[[`MaturityModulation`](#maturitymodulation)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L343)

##### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](#governancecachedmetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L342)

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L345)

##### neurons

> **neurons**: \[`string`, [`Neuron`](#neuron)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L357)

##### parameters

> **parameters**: \[\] \| \[[`NervousSystemParameters`](#nervoussystemparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L346)

##### pending\_version

> **pending\_version**: \[\] \| \[[`PendingVersion`](#pendingversion)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L351)

##### proposals

> **proposals**: \[`bigint`, [`ProposalData`](#proposaldata)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L354)

##### root\_canister\_id

> **root\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L338)

##### sns\_initialization\_parameters

> **sns\_initialization\_parameters**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L349)

##### sns\_metadata

> **sns\_metadata**: \[\] \| \[[`ManageSnsMetadata`](#managesnsmetadata)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L356)

##### swap\_canister\_id

> **swap\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L352)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L358)

##### timers

> **timers**: \[\] \| \[[`Timers`](#timers-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L339)

##### upgrade\_journal

> **upgrade\_journal**: \[\] \| \[[`UpgradeJournal`](#upgradejournal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L344)

***

### GovernanceCachedMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L361)

#### Properties

##### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L368)

##### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L373)

##### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L376)

##### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L375)

##### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L377)

##### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L364)

##### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L365)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L367)

##### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L374)

##### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L372)

##### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L366)

##### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L363)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L378)

##### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L369)

##### total\_supply\_governance\_tokens

> **total\_supply\_governance\_tokens**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L370)

##### treasury\_metrics

> **treasury\_metrics**: [`TreasuryMetrics`](#treasurymetrics)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L362)

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L371)

***

### GovernanceError

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L380)

#### Properties

##### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L381)

##### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L382)

***

### IncreaseDissolveDelay

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L384)

#### Properties

##### additional\_dissolve\_delay\_seconds

> **additional\_dissolve\_delay\_seconds**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L385)

***

### ListNervousSystemFunctionsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L387)

#### Properties

##### functions

> **functions**: [`NervousSystemFunction`](#nervoussystemfunction)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L389)

##### reserved\_ids

> **reserved\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L388)

***

### ListNeurons

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L391)

#### Properties

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L393)

##### of\_principal

> **of\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L392)

##### start\_page\_at

> **start\_page\_at**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L394)

***

### ListNeuronsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L396)

#### Properties

##### neurons

> **neurons**: [`Neuron`](#neuron)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L397)

***

### ListProposals

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L399)

#### Properties

##### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L401)

##### exclude\_type

> **exclude\_type**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L403)

##### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L400)

##### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L405)

##### include\_topics

> **include\_topics**: \[\] \| \[[`TopicSelector`](#topicselector)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L404)

##### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L402)

***

### ListProposalsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L407)

#### Properties

##### include\_ballots\_by\_caller

> **include\_ballots\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L408)

##### include\_topic\_filtering

> **include\_topic\_filtering**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L410)

##### proposals

> **proposals**: [`ProposalData`](#proposaldata)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L409)

***

### ListTopicsResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L413)

#### Properties

##### topics

> **topics**: \[\] \| \[[`TopicInfo`](#topicinfo)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L415)

##### uncategorized\_functions

> **uncategorized\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L414)

***

### ManageDappCanisterSettings

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L417)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L420)

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L426)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L418)

##### log\_visibility

> **log\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L422)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L425)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L421)

##### snapshot\_visibility

> **snapshot\_visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L423)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L424)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L419)

***

### ManageLedgerParameters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L428)

#### Properties

##### token\_logo

> **token\_logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L431)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L432)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L429)

##### transfer\_fee

> **transfer\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L430)

***

### ManageNeuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L434)

#### Properties

##### command

> **command**: \[\] \| \[[`Command`](#command-3)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L436)

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L435)

***

### ManageNeuronResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L438)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_1`](#command_1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L439)

***

### ManageSnsMetadata

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L441)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L445)

##### logo

> **logo**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L443)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L444)

##### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L442)

***

### MaturityModulation

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L447)

#### Properties

##### current\_basis\_points

> **current\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L448)

##### updated\_at\_timestamp\_seconds

> **updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L449)

***

### MemoAndController

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L451)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L452)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L453)

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L455)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:458](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L458)

##### custom\_sections\_size

> **custom\_sections\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L463)

##### global\_memory\_size

> **global\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L462)

##### snapshots\_size

> **snapshots\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L460)

##### stable\_memory\_size

> **stable\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L459)

##### wasm\_binary\_size

> **wasm\_binary\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L456)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L457)

##### wasm\_memory\_size

> **wasm\_memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:461](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L461)

***

### MergeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L465)

#### Properties

##### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L466)

***

### MergeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L468)

#### Properties

##### merged\_maturity\_e8s

> **merged\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L469)

##### new\_stake\_e8s

> **new\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L470)

***

### Metrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L472)

#### Properties

##### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L481)

##### last\_ledger\_block\_timestamp

> **last\_ledger\_block\_timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L478)

##### num\_recently\_executed\_proposals

> **num\_recently\_executed\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:479](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L479)

##### num\_recently\_submitted\_proposals

> **num\_recently\_submitted\_proposals**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L480)

##### treasury\_metrics

> **treasury\_metrics**: \[\] \| \[[`TreasuryMetrics`](#treasurymetrics)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L476)

The metrics below are cached (albeit this is an implementation detail).

##### voting\_power\_metrics

> **voting\_power\_metrics**: \[\] \| \[[`VotingPowerMetrics`](#votingpowermetrics)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:477](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L477)

***

### MintSnsTokens

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L483)

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L487)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L486)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L484)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L485)

***

### MintSnsTokensActionAuxiliary

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:489](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L489)

#### Properties

##### valuation

> **valuation**: \[\] \| \[[`Valuation`](#valuation-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L490)

***

### MintTokensRequest

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L492)

#### Properties

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L494)

##### recipient

> **recipient**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L493)

***

### Motion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L496)

#### Properties

##### motion\_text

> **motion\_text**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L497)

***

### NervousSystemFunction

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L499)

#### Properties

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L502)

##### function\_type

> **function\_type**: \[\] \| \[[`FunctionType`](#functiontype)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L503)

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L500)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L501)

***

### NervousSystemParameters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L505)

#### Properties

##### automatically\_advance\_target\_version

> **automatically\_advance\_target\_version**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L510)

##### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](#customproposalcriticality)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L521)

##### default\_followees

> **default\_followees**: \[\] \| \[[`DefaultFollowees`](#defaultfollowees)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L506)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L514)

##### maturity\_modulation\_disabled

> **maturity\_modulation\_disabled**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L526)

##### max\_age\_bonus\_percentage

> **max\_age\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L523)

##### max\_dissolve\_delay\_bonus\_percentage

> **max\_dissolve\_delay\_bonus\_percentage**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L508)

##### max\_dissolve\_delay\_seconds

> **max\_dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L507)

##### max\_followees\_per\_function

> **max\_followees\_per\_function**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L509)

##### max\_neuron\_age\_for\_age\_bonus

> **max\_neuron\_age\_for\_age\_bonus**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L513)

##### max\_number\_of\_neurons

> **max\_number\_of\_neurons**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L519)

##### max\_number\_of\_principals\_per\_neuron

> **max\_number\_of\_principals\_per\_neuron**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L527)

##### max\_number\_of\_proposals\_with\_ballots

> **max\_number\_of\_proposals\_with\_ballots**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L522)

##### max\_proposals\_to\_keep\_per\_action

> **max\_proposals\_to\_keep\_per\_action**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L517)

##### neuron\_claimer\_permissions

> **neuron\_claimer\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L511)

##### neuron\_grantable\_permissions

> **neuron\_grantable\_permissions**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L524)

##### neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds

> **neuron\_minimum\_dissolve\_delay\_to\_vote\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L515)

##### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L512)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L516)

##### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L520)

##### voting\_rewards\_parameters

> **voting\_rewards\_parameters**: \[\] \| \[[`VotingRewardsParameters`](#votingrewardsparameters)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L525)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L518)

***

### Neuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L529)

#### Properties

##### aging\_since\_timestamp\_seconds

> **aging\_since\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L541)

##### auto\_stake\_maturity

> **auto\_stake\_maturity**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L540)

##### cached\_neuron\_stake\_e8s

> **cached\_neuron\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L534)

##### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L535)

##### disburse\_maturity\_in\_progress

> **disburse\_maturity\_in\_progress**: [`DisburseMaturityInProgress`](#disbursematurityinprogress)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:545](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L545)

##### dissolve\_state

> **dissolve\_state**: \[\] \| \[[`DissolveState`](#dissolvestate)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L542)

##### followees

> **followees**: \[`bigint`, [`Followees`](#followees-2)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L546)

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L530)

##### maturity\_e8s\_equivalent

> **maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L533)

##### neuron\_fees\_e8s

> **neuron\_fees\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L547)

##### permissions

> **permissions**: [`NeuronPermission`](#neuronpermission)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L532)

##### source\_nns\_neuron\_id

> **source\_nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L539)

##### staked\_maturity\_e8s\_equivalent

> **staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L531)

##### topic\_followees

> **topic\_followees**: \[\] \| \[\{ `topic_id_to_followees`: \[`number`, [`FolloweesForTopic`](#followeesfortopic)\][]; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L536)

##### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:544](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L544)

##### voting\_power\_percentage\_multiplier

> **voting\_power\_percentage\_multiplier**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L543)

***

### NeuronId

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L549)

#### Properties

##### id

> **id**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L550)

***

### NeuronIds

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L552)

#### Properties

##### neuron\_ids

> **neuron\_ids**: [`NeuronId`](#neuronid-1)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L553)

***

### NeuronInFlightCommand

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L555)

#### Properties

##### command

> **command**: \[\] \| \[[`Command_2`](#command_2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L556)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L557)

***

### NeuronPermission

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:559](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L559)

#### Properties

##### permission\_type

> **permission\_type**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L561)

##### principal

> **principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L560)

***

### NeuronPermissionList

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:563](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L563)

#### Properties

##### permissions

> **permissions**: `Int32Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L564)

***

### NeuronRecipe

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:566](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L566)

#### Properties

##### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:567](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L567)

##### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L568)

##### followees

> **followees**: \[\] \| \[[`NeuronIds`](#neuronids)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L571)

##### neuron\_id

> **neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L572)

##### participant

> **participant**: \[\] \| \[[`Participant`](#participant-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L569)

##### stake\_e8s

> **stake\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L570)

***

### NeuronRecipes

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L574)

#### Properties

##### neuron\_recipes

> **neuron\_recipes**: [`NeuronRecipe`](#neuronrecipe)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L575)

***

### NeuronsFund

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L577)

#### Properties

##### nns\_neuron\_controller

> **nns\_neuron\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L579)

##### nns\_neuron\_hotkeys

> **nns\_neuron\_hotkeys**: \[\] \| \[[`Principals`](#principals)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L578)

##### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L580)

***

### PendingVersion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L591)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:593](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L593)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L592)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:594](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L594)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:595](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L595)

***

### Percentage

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:597](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L597)

#### Properties

##### basis\_points

> **basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:598](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L598)

***

### Principals

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:624](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L624)

#### Properties

##### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L625)

***

### Proposal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L627)

#### Properties

##### action

> **action**: \[\] \| \[[`Action`](#action-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:630](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L630)

##### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L631)

##### title

> **title**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:629](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L629)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:628](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L628)

***

### ProposalData

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L633)

#### Properties

##### action

> **action**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:637](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L637)

##### action\_auxiliary

> **action\_auxiliary**: \[\] \| \[[`ActionAuxiliary`](#actionauxiliary)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:639](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L639)

##### ballots

> **ballots**: \[`string`, [`Ballot`](#ballot)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:640](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L640)

##### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:650](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L650)

##### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L656)

##### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L643)

##### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](#governanceerror)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L638)

##### id

> **id**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:634](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L634)

##### initial\_voting\_period\_seconds

> **initial\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:646](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L646)

##### is\_eligible\_for\_rewards

> **is\_eligible\_for\_rewards**: `boolean`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:655](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L655)

##### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](#tally)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:648](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L648)

##### minimum\_yes\_proportion\_of\_exercised

> **minimum\_yes\_proportion\_of\_exercised**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L654)

##### minimum\_yes\_proportion\_of\_total

> **minimum\_yes\_proportion\_of\_total**: \[\] \| \[[`Percentage`](#percentage)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:641](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L641)

##### payload\_text\_rendering

> **payload\_text\_rendering**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L635)

##### proposal

> **proposal**: \[\] \| \[[`Proposal`](#proposal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L651)

##### proposal\_creation\_timestamp\_seconds

> **proposal\_creation\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:645](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L645)

##### proposer

> **proposer**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:652](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L652)

##### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L647)

##### reward\_event\_end\_timestamp\_seconds

> **reward\_event\_end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:644](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L644)

##### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:642](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L642)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:636](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L636)

##### wait\_for\_quiet\_deadline\_increase\_seconds

> **wait\_for\_quiet\_deadline\_increase\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:649](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L649)

##### wait\_for\_quiet\_state

> **wait\_for\_quiet\_state**: \[\] \| \[[`WaitForQuietState`](#waitforquietstate)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L653)

***

### ProposalId

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L658)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L659)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:661](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L661)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:664](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L664)

##### num\_instructions\_total

> **num\_instructions\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:663](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L663)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:665](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L665)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L662)

***

### RegisterDappCanisters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:667](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L667)

#### Properties

##### canister\_ids

> **canister\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:668](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L668)

***

### RegisteredExtensionOperationSpec

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:678](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L678)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:680](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L680)

##### spec

> **spec**: \[\] \| \[[`ExtensionOperationSpec`](#extensionoperationspec)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:679](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L679)

***

### RegisterExtension

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L670)

#### Properties

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:671](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L671)

##### extension\_init

> **extension\_init**: \[\] \| \[[`ExtensionInit`](#extensioninit)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:672](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L672)

***

### RegisterVote

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L674)

#### Properties

##### proposal

> **proposal**: \[\] \| \[[`ProposalId`](#proposalid)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L676)

##### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:675](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L675)

***

### RemoveNeuronPermissions

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:682](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L682)

#### Properties

##### permissions\_to\_remove

> **permissions\_to\_remove**: \[\] \| \[[`NeuronPermissionList`](#neuronpermissionlist)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:683](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L683)

##### principal\_id

> **principal\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:684](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L684)

***

### RewardEvent

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:688](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L688)

#### Properties

##### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:690](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L690)

##### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:693](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L693)

##### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:691](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L691)

##### round

> **round**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:694](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L694)

##### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:689](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L689)

##### settled\_proposals

> **settled\_proposals**: [`ProposalId`](#proposalid)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:695](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L695)

##### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:692](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L692)

***

### SetDissolveTimestamp

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:697](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L697)

#### Properties

##### dissolve\_timestamp\_seconds

> **dissolve\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:698](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L698)

***

### SetFollowing

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:700](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L700)

#### Properties

##### topic\_following

> **topic\_following**: [`FolloweesForTopic`](#followeesfortopic)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:701](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L701)

***

### SetMode

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:703](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L703)

#### Properties

##### mode

> **mode**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:704](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L704)

***

### SetTopicsForCustomProposals

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:706](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L706)

#### Properties

##### custom\_function\_id\_to\_topic

> **custom\_function\_id\_to\_topic**: \[`bigint`, [`Topic`](#topic-6)\][]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:707](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L707)

***

### SnsVersion

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:709](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L709)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:710](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L710)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:714](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L714)

##### index\_wasm\_hash

> **index\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:715](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L715)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:713](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L713)

##### root\_wasm\_hash

> **root\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:711](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L711)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:712](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L712)

***

### Split

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:717](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L717)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:719](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L719)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:718](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L718)

***

### SplitResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:721](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L721)

#### Properties

##### created\_neuron\_id

> **created\_neuron\_id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:722](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L722)

***

### StakeMaturity

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:724](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L724)

#### Properties

##### percentage\_to\_stake

> **percentage\_to\_stake**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:725](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L725)

***

### StakeMaturityResponse

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:727](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L727)

#### Properties

##### maturity\_e8s

> **maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:728](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L728)

##### staked\_maturity\_e8s

> **staked\_maturity\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:729](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L729)

***

### Subaccount

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:731](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L731)

#### Properties

##### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:732](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L732)

***

### SwapNeuron

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:734](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L734)

#### Properties

##### id

> **id**: \[\] \| \[[`NeuronId`](#neuronid-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:735](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L735)

##### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:736](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L736)

***

### Tally

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:738](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L738)

#### Properties

##### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L739)

##### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:742](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L742)

##### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:741](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L741)

##### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:740](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L740)

***

### TargetVersionReset

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:744](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L744)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:745](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L745)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:747](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L747)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:746](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L746)

***

### TargetVersionSet

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:749](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L749)

#### Properties

##### is\_advanced\_automatically

> **is\_advanced\_automatically**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L752)

##### new\_target\_version

> **new\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L751)

##### old\_target\_version

> **old\_target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:750](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L750)

***

### Timers

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:754](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L754)

#### Properties

##### last\_reset\_timestamp\_seconds

> **last\_reset\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:756](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L756)

##### last\_spawned\_timestamp\_seconds

> **last\_spawned\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:755](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L755)

##### requires\_periodic\_tasks

> **requires\_periodic\_tasks**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:757](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L757)

***

### Tokens

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L759)

#### Properties

##### e8s

> **e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:760](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L760)

***

### TopicInfo

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:770](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L770)

#### Properties

##### custom\_functions

> **custom\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:777](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L777)

##### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L776)

##### extension\_operations

> **extension\_operations**: \[\] \| \[[`RegisteredExtensionOperationSpec`](#registeredextensionoperationspec)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L771)

##### is\_critical

> **is\_critical**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:774](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L774)

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L775)

##### native\_functions

> **native\_functions**: \[\] \| \[[`NervousSystemFunction`](#nervoussystemfunction)[]\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L772)

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:773](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L773)

***

### TopicSelector

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:779](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L779)

#### Properties

##### topic

> **topic**: \[\] \| \[[`Topic`](#topic-6)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:780](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L780)

***

### TransferSnsTreasuryFunds

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:782](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L782)

#### Properties

##### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:787](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L787)

##### from\_treasury

> **from\_treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:783](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L783)

##### memo

> **memo**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:786](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L786)

##### to\_principal

> **to\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:784](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L784)

##### to\_subaccount

> **to\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-2)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:785](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L785)

***

### TreasuryMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:789](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L789)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:802](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L802)

##### amount\_e8s

> **amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:801](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L801)

The regularly updated amount of tokens in this treasury.

##### ledger\_canister\_id

> **ledger\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:806](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L806)

The source of truth for the treasury balance is this ledger canister / account.

##### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:793](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L793)

A human-readable identified for this treasury, e.g., "ICP".

##### original\_amount\_e8s

> **original\_amount\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:797](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L797)

The amount of tokens in this treasury at the end of swap finalization.

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:814](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L814)

When the metrics were last updated.

##### treasury

> **treasury**: `number`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:810](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L810)

Same as, e.g., `TransferSnsTreasuryFunds.from_treasury`.

***

### UpgradeExtension

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:816](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L816)

#### Properties

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[[`ExtensionUpgradeArg`](#extensionupgradearg)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:819](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L819)

##### extension\_canister\_id

> **extension\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:817](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L817)

##### wasm

> **wasm**: \[\] \| \[[`Wasm`](#wasm-1)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:818](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L818)

***

### UpgradeInProgress

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:821](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L821)

#### Properties

##### checking\_upgrade\_lock

> **checking\_upgrade\_lock**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:823](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L823)

##### mark\_failed\_at\_seconds

> **mark\_failed\_at\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:822](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L822)

##### proposal\_id

> **proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:824](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L824)

##### target\_version

> **target\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:825](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L825)

***

### UpgradeJournal

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:827](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L827)

#### Properties

##### entries

> **entries**: [`UpgradeJournalEntry`](#upgradejournalentry)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:828](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L828)

***

### UpgradeJournalEntry

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:830](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L830)

#### Properties

##### event

> **event**: \[\] \| \[\{ `TargetVersionSet`: [`TargetVersionSet`](#targetversionset); \} \| \{ `UpgradeStepsReset`: [`UpgradeStepsReset`](#upgradestepsreset); \} \| \{ `UpgradeOutcome`: [`UpgradeOutcome`](#upgradeoutcome); \} \| \{ `UpgradeStarted`: [`UpgradeStarted`](#upgradestarted); \} \| \{ `UpgradeStepsRefreshed`: [`UpgradeStepsRefreshed`](#upgradestepsrefreshed); \} \| \{ `TargetVersionReset`: [`TargetVersionReset`](#targetversionreset); \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:831](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L831)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:841](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L841)

***

### UpgradeOutcome

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:843](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L843)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:852](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L852)

##### status

> **status**: \[\] \| \[\{ `Success`: \{ \}; \} \| \{ `Timeout`: \{ \}; \} \| \{ `ExternalFailure`: \{ \}; \} \| \{ `InvalidState`: \{ `version`: \[\] \| \[[`Version`](#version)\]; \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:844](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L844)

***

### UpgradeSnsControlledCanister

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:854](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L854)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:857](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L857)

##### canister\_upgrade\_arg

> **canister\_upgrade\_arg**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:859](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L859)

##### chunked\_canister\_wasm

> **chunked\_canister\_wasm**: \[\] \| \[[`ChunkedCanisterWasm`](#chunkedcanisterwasm)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:858](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L858)

##### mode

> **mode**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L856)

##### new\_canister\_wasm

> **new\_canister\_wasm**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:855](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L855)

***

### UpgradeStarted

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:861](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L861)

#### Properties

##### current\_version

> **current\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:862](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L862)

##### expected\_version

> **expected\_version**: \[\] \| \[[`Version`](#version)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:863](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L863)

##### reason

> **reason**: \[\] \| \[\{ `UpgradeSnsToNextVersionProposal`: [`ProposalId`](#proposalid); \} \| \{ `BehindTargetVersion`: \{ \}; \}\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:864](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L864)

***

### UpgradeStepsRefreshed

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:871](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L871)

#### Properties

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:872](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L872)

***

### UpgradeStepsReset

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L874)

#### Properties

##### human\_readable

> **human\_readable**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L875)

##### upgrade\_steps

> **upgrade\_steps**: \[\] \| \[[`Versions`](#versions)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:876](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L876)

***

### Valuation

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:878](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L878)

#### Properties

##### account

> **account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:880](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L880)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:882](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L882)

##### token

> **token**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:879](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L879)

##### valuation\_factors

> **valuation\_factors**: \[\] \| \[[`ValuationFactors`](#valuationfactors)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:881](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L881)

***

### ValuationFactors

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:884](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L884)

#### Properties

##### icps\_per\_token

> **icps\_per\_token**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L886)

##### tokens

> **tokens**: \[\] \| \[[`Tokens`](#tokens)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L887)

##### xdrs\_per\_icp

> **xdrs\_per\_icp**: \[\] \| \[[`Decimal`](#decimal)\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L885)

***

### Version

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L889)

#### Properties

##### archive\_wasm\_hash

> **archive\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L890)

##### governance\_wasm\_hash

> **governance\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:894](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L894)

##### index\_wasm\_hash

> **index\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L895)

##### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L893)

##### root\_wasm\_hash

> **root\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L891)

##### swap\_wasm\_hash

> **swap\_wasm\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:892](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L892)

***

### Versions

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:897](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L897)

#### Properties

##### versions

> **versions**: [`Version`](#version)[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L898)

***

### VotingPowerMetrics

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:900](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L900)

#### Properties

##### governance\_total\_potential\_voting\_power

> **governance\_total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L901)

##### timestamp\_seconds

> **timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:905](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L905)

When the metrics were last updated.

***

### VotingRewardsParameters

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:907](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L907)

#### Properties

##### final\_reward\_rate\_basis\_points

> **final\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:908](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L908)

##### initial\_reward\_rate\_basis\_points

> **initial\_reward\_rate\_basis\_points**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:909](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L909)

##### reward\_rate\_transition\_duration\_seconds

> **reward\_rate\_transition\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:910](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L910)

##### round\_duration\_seconds

> **round\_duration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:911](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L911)

***

### WaitForQuietState

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L913)

#### Properties

##### current\_deadline\_timestamp\_seconds

> **current\_deadline\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L914)

## Type Aliases

### Action

> **Action** = \{ `ManageNervousSystemParameters`: [`NervousSystemParameters`](#nervoussystemparameters); \} \| \{ `AddGenericNervousSystemFunction`: [`NervousSystemFunction`](#nervoussystemfunction); \} \| \{ `ManageDappCanisterSettings`: [`ManageDappCanisterSettings`](#managedappcanistersettings); \} \| \{ `ExecuteExtensionOperation`: [`ExecuteExtensionOperation`](#executeextensionoperation); \} \| \{ `UpgradeExtension`: [`UpgradeExtension`](#upgradeextension); \} \| \{ `RemoveGenericNervousSystemFunction`: `bigint`; \} \| \{ `SetTopicsForCustomProposals`: [`SetTopicsForCustomProposals`](#settopicsforcustomproposals); \} \| \{ `RegisterExtension`: [`RegisterExtension`](#registerextension); \} \| \{ `UpgradeSnsToNextVersion`: \{ \}; \} \| \{ `RegisterDappCanisters`: [`RegisterDappCanisters`](#registerdappcanisters); \} \| \{ `TransferSnsTreasuryFunds`: [`TransferSnsTreasuryFunds`](#transfersnstreasuryfunds); \} \| \{ `UpgradeSnsControlledCanister`: [`UpgradeSnsControlledCanister`](#upgradesnscontrolledcanister); \} \| \{ `DeregisterDappCanisters`: [`DeregisterDappCanisters`](#deregisterdappcanisters); \} \| \{ `MintSnsTokens`: [`MintSnsTokens`](#mintsnstokens); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersion`](#advancesnstargetversion); \} \| \{ `Unspecified`: \{ \}; \} \| \{ `ManageSnsMetadata`: [`ManageSnsMetadata`](#managesnsmetadata); \} \| \{ `ExecuteGenericNervousSystemFunction`: [`ExecuteGenericNervousSystemFunction`](#executegenericnervoussystemfunction); \} \| \{ `ManageLedgerParameters`: [`ManageLedgerParameters`](#manageledgerparameters); \} \| \{ `Motion`: [`Motion`](#motion); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L17)

***

### ActionAuxiliary

> **ActionAuxiliary** = \{ `TransferSnsTreasuryFunds`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `MintSnsTokens`: [`MintSnsTokensActionAuxiliary`](#mintsnstokensactionauxiliary); \} \| \{ `AdvanceSnsTargetVersion`: [`AdvanceSnsTargetVersionActionAuxiliary`](#advancesnstargetversionactionauxiliary); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L42)

***

### AdvanceTargetVersionResponse

> **AdvanceTargetVersionResponse** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L71)

***

### By

> **By** = \{ `MemoAndController`: [`MemoAndController`](#memoandcontroller); \} \| \{ `NeuronId`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L80)

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L96)

***

### ClaimSwapNeuronsResult

> **ClaimSwapNeuronsResult** = \{ `Ok`: [`ClaimedSwapNeurons`](#claimedswapneurons); \} \| \{ `Err`: `number`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L120)

***

### Command

> **Command** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `StakeMaturity`: [`StakeMaturity`](#stakematurity); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L126)

***

### Command\_1

> **Command\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Split`: [`SplitResponse`](#splitresponse); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](#disbursematurityresponse); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](#claimorrefreshresponse); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `SetFollowing`: \{ \}; \} \| \{ `MakeProposal`: [`GetProposal`](#getproposal); \} \| \{ `RemoveNeuronPermission`: \{ \}; \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](#stakematurityresponse); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](#mergematurityresponse); \} \| \{ `Disburse`: [`DisburseResponse`](#disburseresponse); \} \| \{ `AddNeuronPermission`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L140)

***

### Command\_2

> **Command\_2** = \{ `Split`: [`Split`](#split); \} \| \{ `Follow`: [`Follow`](#follow); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](#disbursematurity); \} \| \{ `Configure`: [`Configure`](#configure); \} \| \{ `RegisterVote`: [`RegisterVote`](#registervote); \} \| \{ `SetFollowing`: [`SetFollowing`](#setfollowing); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `MakeProposal`: [`Proposal`](#proposal); \} \| \{ `FinalizeDisburseMaturity`: [`FinalizeDisburseMaturity`](#finalizedisbursematurity); \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](#claimorrefresh); \} \| \{ `RemoveNeuronPermissions`: [`RemoveNeuronPermissions`](#removeneuronpermissions); \} \| \{ `AddNeuronPermissions`: [`AddNeuronPermissions`](#addneuronpermissions); \} \| \{ `MergeMaturity`: [`MergeMaturity`](#mergematurity); \} \| \{ `Disburse`: [`Disburse`](#disburse); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L155)

***

### DissolveState

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L215)

***

### ExtensionOperationType

> **ExtensionOperationType** = \{ `TreasuryManagerWithdraw`: `null`; \} \| \{ `TreasuryManagerDeposit`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L239)

***

### ExtensionType

> **ExtensionType** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L242)

#### Properties

##### TreasuryManager

> **TreasuryManager**: `null`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L242)

***

### FunctionType

> **FunctionType** = \{ `NativeNervousSystemFunction`: \{ \}; \} \| \{ `GenericNervousSystemFunction`: [`GenericNervousSystemFunction`](#genericnervoussystemfunction); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L265)

***

### GetMetricsResult

> **GetMetricsResult** = \{ `Ok`: [`Metrics`](#metrics-1); \} \| \{ `Err`: [`GovernanceError`](#governanceerror); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L290)

***

### ListTopicsRequest

> **ListTopicsRequest** = `object`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L412)

***

### Operation

> **Operation** = \{ `ChangeAutoStakeMaturity`: [`ChangeAutoStakeMaturity`](#changeautostakematurity); \} \| \{ `StopDissolving`: \{ \}; \} \| \{ `StartDissolving`: \{ \}; \} \| \{ `IncreaseDissolveDelay`: [`IncreaseDissolveDelay`](#increasedissolvedelay); \} \| \{ `SetDissolveTimestamp`: [`SetDissolveTimestamp`](#setdissolvetimestamp); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:582](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L582)

***

### Participant

> **Participant** = \{ `NeuronsFund`: [`NeuronsFund`](#neuronsfund); \} \| \{ `Direct`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:590](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L590)

***

### PreciseValue

> **PreciseValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`PreciseValue`](#precisevalue)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`PreciseValue`](#precisevalue)[]; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L616)

This type is equivalant to `ICRC3Value`, but we give it another name since it is used here not
in the context of the ICRC-3 ledger standard. The justification is the same: The candid format
supports sharing information even when the client and the server involved do not have the same
schema (see the Upgrading and subtyping section of the candid spec). While this mechanism allows
to evolve services and clients independently without breaking them, it also means that a client
may not receive all the information that the server is sending, e.g. in case the client schema
lacks some fields that the server schema has.

This loss of information is not an option for SNS voters deciding if an extension with particular
init args should be installed or if an extension function with particular arguments should be
called. The client must receive the same exact data the server sent in order to verify it.

Verification of a priorly installed extension is done by hashing the extension's init arg data
and checking that the result is consistent with what has been certified by the SNS.

***

### Result

> **Result** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Neuron`: [`Neuron`](#neuron); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:686](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L686)

***

### Result\_1

> **Result\_1** = \{ `Error`: [`GovernanceError`](#governanceerror); \} \| \{ `Proposal`: [`ProposalData`](#proposaldata); \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:687](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L687)

***

### Topic

> **Topic** = \{ `DappCanisterManagement`: `null`; \} \| \{ `DaoCommunitySettings`: `null`; \} \| \{ `ApplicationBusinessLogic`: `null`; \} \| \{ `CriticalDappOperations`: `null`; \} \| \{ `TreasuryAssetManagement`: `null`; \} \| \{ `Governance`: `null`; \} \| \{ `SnsFrameworkManagement`: `null`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:762](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L762)

***

### Wasm

> **Wasm** = \{ `Chunked`: [`ChunkedCanisterWasm`](#chunkedcanisterwasm); \} \| \{ `Bytes`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L916)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:966](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L966)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/sns/governance\_test.d.ts:967](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/sns/governance_test.d.ts#L967)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
