---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [CyclesLedgerDid](namespaces/CyclesLedgerDid.md)

## Classes

### CyclesLedgerCanister

Defined in: [packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts#L16)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new CyclesLedgerCanister**(`id`, `service`, `certifiedService`): [`CyclesLedgerCanister`](#cyclesledgercanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)

###### Returns

[`CyclesLedgerCanister`](#cyclesledgercanister)

###### Inherited from

`Canister<CyclesLedgerService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### withdraw()

> **withdraw**(`params`): `Promise`\<[`WithdrawResult`](#withdrawresult)\>

Defined in: [packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts#L47)

Withdraws cycles from the ledger to a target canister.

###### Parameters

###### params

[`WithdrawParams`](#withdrawparams)

The withdrawal parameters.

###### Returns

`Promise`\<[`WithdrawResult`](#withdrawresult)\>

The result of the withdrawal operation.

###### See

https://github.com/dfinity/cycles-ledger#withdrawing-cycles

##### create()

> `static` **create**(`__namedParameters`): [`CyclesLedgerCanister`](#cyclesledgercanister)

Defined in: [packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts#L17)

###### Parameters

###### \_\_namedParameters

`CanisterOptions`\<[`_SERVICE`](namespaces/CyclesLedgerDid.md#_service)\>

###### Returns

[`CyclesLedgerCanister`](#cyclesledgercanister)

## Type Aliases

### WithdrawParams

> **WithdrawParams** = `object` & `Omit`\<[`WithdrawArgs`](namespaces/CyclesLedgerDid.md#withdrawargs), `"from_subaccount"` \| `"created_at_time"`\>

Defined in: [packages/canisters/src/ledger/cycles/types/cycles-ledger.params.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ledger/cycles/types/cycles-ledger.params.ts#L3)

#### Type Declaration

##### createdAtTime?

> `optional` **createdAtTime**: `bigint`

##### fromSubaccount?

> `optional` **fromSubaccount**: `Uint8Array`

***

### WithdrawResult

> **WithdrawResult** = \{ `Ok`: [`BlockIndex`](namespaces/CyclesLedgerDid.md#blockindex); \} \| \{ `Err`: [`WithdrawError`](namespaces/CyclesLedgerDid.md#withdrawerror); \}

Defined in: [packages/canisters/src/ledger/cycles/types/cycles-ledger.responses.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ledger/cycles/types/cycles-ledger.responses.ts#L3)
