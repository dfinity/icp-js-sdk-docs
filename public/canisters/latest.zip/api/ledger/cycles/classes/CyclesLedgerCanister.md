---
title: CyclesLedgerCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts#L16)

## Extends

- `Canister`\<[`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new CyclesLedgerCanister**(`id`, `service`, `certifiedService`): `CyclesLedgerCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)

#### Returns

`CyclesLedgerCanister`

#### Inherited from

`Canister<CyclesLedgerService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### withdraw()

> **withdraw**(`params`): `Promise`\<[`WithdrawResult`](../type-aliases/WithdrawResult.md)\>

Defined in: [packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts:47](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts#L47)

Withdraws cycles from the ledger to a target canister.

#### Parameters

##### params

[`WithdrawParams`](../type-aliases/WithdrawParams.md)

The withdrawal parameters.

#### Returns

`Promise`\<[`WithdrawResult`](../type-aliases/WithdrawResult.md)\>

The result of the withdrawal operation.

#### See

https://github.com/dfinity/cycles-ledger#withdrawing-cycles

***

### create()

> `static` **create**(`__namedParameters`): `CyclesLedgerCanister`

Defined in: [packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts:17](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/cycles/cycles-ledger.canister.ts#L17)

#### Parameters

##### \_\_namedParameters

`CanisterOptions`\<[`_SERVICE`](../namespaces/CyclesLedgerDid/interfaces/SERVICE.md)\>

#### Returns

`CyclesLedgerCanister`
