---
title: WithdrawResult
editUrl: false
next: true
prev: true
---

> **WithdrawResult** = \{ `Ok`: [`BlockIndex`](../namespaces/CyclesLedgerDid/type-aliases/BlockIndex.md); \} \| \{ `Err`: [`WithdrawError`](../namespaces/CyclesLedgerDid/type-aliases/WithdrawError.md); \}

Defined in: [packages/canisters/src/ledger/cycles/types/cycles-ledger.responses.ts:3](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/cycles/types/cycles-ledger.responses.ts#L3)
