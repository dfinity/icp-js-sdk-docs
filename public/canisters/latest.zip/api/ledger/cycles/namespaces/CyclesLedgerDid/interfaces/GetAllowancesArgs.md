---
title: GetAllowancesArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L157)

## Properties

### from\_account

> **from\_account**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L160)

***

### prev\_spender

> **prev\_spender**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L159)

***

### take

> **take**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L158)
