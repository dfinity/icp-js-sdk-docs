---
title: TransferFromError
editUrl: false
next: true
prev: true
---

> **TransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L303)
