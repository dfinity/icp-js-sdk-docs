---
title: RejectionCode
editUrl: false
next: true
prev: true
---

> **RejectionCode** = \{ `NoError`: `null`; \} \| \{ `CanisterError`: `null`; \} \| \{ `SysTransient`: `null`; \} \| \{ `DestinationInvalid`: `null`; \} \| \{ `Unknown`: `null`; \} \| \{ `SysFatal`: `null`; \} \| \{ `CanisterReject`: `null`; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L243)
