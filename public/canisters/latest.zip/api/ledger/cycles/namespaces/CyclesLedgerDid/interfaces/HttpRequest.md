---
title: HttpRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L218)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L221)

***

### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L222)

***

### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L220)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L219)
