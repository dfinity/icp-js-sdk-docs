---
title: CreateCanisterArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L73)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L76)

***

### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L75)

***

### creation\_args

> **creation\_args**: \[\] \| \[[`CmcCreateCanisterArgs`](CmcCreateCanisterArgs.md)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L77)

***

### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L74)
