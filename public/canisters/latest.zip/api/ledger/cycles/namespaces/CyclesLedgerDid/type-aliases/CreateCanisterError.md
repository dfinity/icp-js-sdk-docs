---
title: CreateCanisterError
editUrl: false
next: true
prev: true
---

> **CreateCanisterError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `canister_id`: \[\] \| \[`Principal`\]; `duplicate_of`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `FailedToCreate`: \{ `error`: `string`; `fee_block`: \[\] \| \[[`BlockIndex`](BlockIndex.md)\]; `refund_block`: \[\] \| \[[`BlockIndex`](BlockIndex.md)\]; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L79)
