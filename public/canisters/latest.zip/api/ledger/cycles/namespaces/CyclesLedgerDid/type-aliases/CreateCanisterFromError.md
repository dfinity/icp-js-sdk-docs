---
title: CreateCanisterFromError
editUrl: false
next: true
prev: true
---

> **CreateCanisterFromError** = \{ `FailedToCreateFrom`: \{ `approval_refund_block`: \[\] \| \[[`BlockIndex`](BlockIndex.md)\]; `create_from_block`: \[\] \| \[[`BlockIndex`](BlockIndex.md)\]; `refund_block`: \[\] \| \[[`BlockIndex`](BlockIndex.md)\]; `rejection_code`: [`RejectionCode`](RejectionCode.md); `rejection_reason`: `string`; \}; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `canister_id`: \[\] \| \[`Principal`\]; `duplicate_of`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L110)
