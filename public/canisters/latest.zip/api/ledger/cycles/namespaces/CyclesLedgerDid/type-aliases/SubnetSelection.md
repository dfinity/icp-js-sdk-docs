---
title: SubnetSelection
editUrl: false
next: true
prev: true
---

> **SubnetSelection** = \{ `Filter`: [`SubnetFilter`](../interfaces/SubnetFilter.md); \} \| \{ `Subnet`: \{ `subnet`: `Principal`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L254)

## Type Declaration

\{ `Filter`: [`SubnetFilter`](../interfaces/SubnetFilter.md); \}

### Filter

> **Filter**: [`SubnetFilter`](../interfaces/SubnetFilter.md)

Choose a random subnet that satisfies the specified properties.

\{ `Subnet`: \{ `subnet`: `Principal`; \}; \}

### Subnet

> **Subnet**: `object`

/ Choose a specific subnet

#### Subnet.subnet

> **subnet**: `Principal`
