---
title: GetArchivesResult
editUrl: false
next: true
prev: true
---

> **GetArchivesResult** = `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L176)

## Type Declaration

### canister\_id

> **canister\_id**: `Principal`

The id of the archive

### end

> **end**: `bigint`

The last block in the archive

### start

> **start**: `bigint`

The first block in the archive
