---
title: DataCertificate
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L139)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L143)

See https://internetcomputer.org/docs/current/references/ic-interface-spec#certification

***

### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L147)

CBOR encoded hash_tree
