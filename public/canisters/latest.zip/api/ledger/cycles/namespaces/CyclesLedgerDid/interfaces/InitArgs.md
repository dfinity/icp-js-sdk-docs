---
title: InitArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L232)

## Properties

### index\_id

> **index\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L234)

***

### initial\_balances

> **initial\_balances**: \[\] \| \[\[[`Account`](Account.md), `bigint`\][]\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L233)

***

### max\_blocks\_per\_request

> **max\_blocks\_per\_request**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L235)
