---
title: HttpResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L224)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L225)

***

### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L226)

***

### status\_code

> **status\_code**: `number`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L227)
