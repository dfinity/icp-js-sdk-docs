---
title: TransferFromArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L294)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L301)

***

### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L300)

***

### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L296)

***

### from

> **from**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L298)

***

### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L299)

***

### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L297)

***

### to

> **to**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L295)
