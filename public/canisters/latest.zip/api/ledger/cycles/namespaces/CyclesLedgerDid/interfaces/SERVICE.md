---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L376)

## Properties

### create\_canister

> **create\_canister**: `ActorMethod`\<\[[`CreateCanisterArgs`](CreateCanisterArgs.md)\], \{ `Ok`: [`CreateCanisterSuccess`](CreateCanisterSuccess.md); \} \| \{ `Err`: [`CreateCanisterError`](../type-aliases/CreateCanisterError.md); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L377)

***

### create\_canister\_from

> **create\_canister\_from**: `ActorMethod`\<\[[`CreateCanisterFromArgs`](CreateCanisterFromArgs.md)\], \{ `Ok`: [`CreateCanisterSuccess`](CreateCanisterSuccess.md); \} \| \{ `Err`: [`CreateCanisterFromError`](../type-aliases/CreateCanisterFromError.md); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L381)

***

### deposit

> **deposit**: `ActorMethod`\<\[[`DepositArgs`](DepositArgs.md)\], [`DepositResult`](DepositResult.md)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L385)

***

### http\_request

> **http\_request**: `ActorMethod`\<\[[`HttpRequest`](HttpRequest.md)\], [`HttpResponse`](HttpResponse.md)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L386)

***

### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](Account.md)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L392)

***

### icrc1\_decimals

> **icrc1\_decimals**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L393)

***

### icrc1\_fee

> **icrc1\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L394)

***

### icrc1\_metadata

> **icrc1\_metadata**: `ActorMethod`\<\[\], \[`string`, [`MetadataValue`](../type-aliases/MetadataValue.md)\][]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L395)

***

### icrc1\_minting\_account

> **icrc1\_minting\_account**: `ActorMethod`\<\[\], \[\] \| \[[`Account`](Account.md)\]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L396)

***

### icrc1\_name

> **icrc1\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L397)

***

### icrc1\_supported\_standards

> **icrc1\_supported\_standards**: `ActorMethod`\<\[\], [`SupportedStandard`](SupportedStandard.md)[]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L398)

***

### icrc1\_symbol

> **icrc1\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L399)

***

### icrc1\_total\_supply

> **icrc1\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L400)

***

### icrc1\_transfer

> **icrc1\_transfer**: `ActorMethod`\<\[[`TransferArgs`](TransferArgs.md)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`TransferError`](../type-aliases/TransferError.md); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L401)

***

### icrc103\_get\_allowances

> **icrc103\_get\_allowances**: `ActorMethod`\<\[[`GetAllowancesArgs`](GetAllowancesArgs.md)\], [`ICRC103GetAllowancesResponse`](../type-aliases/ICRC103GetAllowancesResponse.md)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L387)

***

### icrc106\_get\_index\_principal

> **icrc106\_get\_index\_principal**: `ActorMethod`\<\[\], [`GetIndexPrincipalResult`](../type-aliases/GetIndexPrincipalResult.md)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L391)

***

### icrc2\_allowance

> **icrc2\_allowance**: `ActorMethod`\<\[[`AllowanceArgs`](AllowanceArgs.md)\], [`Allowance`](Allowance.md)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L405)

***

### icrc2\_approve

> **icrc2\_approve**: `ActorMethod`\<\[[`ApproveArgs`](ApproveArgs.md)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`ApproveError`](../type-aliases/ApproveError.md); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L406)

***

### icrc2\_transfer\_from

> **icrc2\_transfer\_from**: `ActorMethod`\<\[[`TransferFromArgs`](TransferFromArgs.md)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`TransferFromError`](../type-aliases/TransferFromError.md); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L410)

***

### icrc3\_get\_archives

> **icrc3\_get\_archives**: `ActorMethod`\<\[[`GetArchivesArgs`](GetArchivesArgs.md)\], [`GetArchivesResult`](../type-aliases/GetArchivesResult.md)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L414)

***

### icrc3\_get\_blocks

> **icrc3\_get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](../type-aliases/GetBlocksArgs.md)\], [`GetBlocksResult`](GetBlocksResult.md)\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L415)

***

### icrc3\_get\_tip\_certificate

> **icrc3\_get\_tip\_certificate**: `ActorMethod`\<\[\], \[\] \| \[[`DataCertificate`](DataCertificate.md)\]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L416)

***

### icrc3\_supported\_block\_types

> **icrc3\_supported\_block\_types**: `ActorMethod`\<\[\], [`SupportedBlockType`](SupportedBlockType.md)[]\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L417)

***

### withdraw

> **withdraw**: `ActorMethod`\<\[[`WithdrawArgs`](WithdrawArgs.md)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`WithdrawError`](../type-aliases/WithdrawError.md); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L418)

***

### withdraw\_from

> **withdraw\_from**: `ActorMethod`\<\[[`WithdrawFromArgs`](WithdrawFromArgs.md)\], \{ `Ok`: `bigint`; \} \| \{ `Err`: [`WithdrawFromError`](../type-aliases/WithdrawFromError.md); \}\>

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L422)
