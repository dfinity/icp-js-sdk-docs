---
title: GetArchivesArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L167)

## Properties

### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L174)

The last archive seen by the client.
The ledger will return archives coming
after this one if set, otherwise it
will return the first archives.
