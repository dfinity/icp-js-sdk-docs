---
title: GetArchivesArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L167)

## Properties

### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L174)

The last archive seen by the client.
The ledger will return archives coming
after this one if set, otherwise it
will return the first archives.
