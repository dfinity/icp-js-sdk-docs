---
title: ICRC103GetAllowancesResponse
editUrl: false
next: true
prev: true
---

> **ICRC103GetAllowancesResponse** = \{ `Ok`: [`Allowances`](Allowances.md); \} \| \{ `Err`: [`GetAllowancesError`](GetAllowancesError.md); \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L229)
