---
title: WithdrawError
editUrl: false
next: true
prev: true
---

> **WithdrawError** = \{ `FailedToWithdraw`: \{ `fee_block`: \[\] \| \[`bigint`\]; `rejection_code`: [`RejectionCode`](RejectionCode.md); `rejection_reason`: `string`; \}; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `InvalidReceiver`: \{ `receiver`: `Principal`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L333)
