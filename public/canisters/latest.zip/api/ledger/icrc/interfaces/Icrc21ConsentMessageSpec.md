---
title: Icrc21ConsentMessageSpec
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L103)

Specification for the consent message, including metadata and device preferences.

## Param

Metadata of the consent message.

## Param

Information about the device responsible for presenting the consent message to the user.

## Properties

### deriveSpec?

> `optional` **deriveSpec**: [`Icrc21ConsentMessageDeviceSpec`](../type-aliases/Icrc21ConsentMessageDeviceSpec.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L105)

***

### metadata

> **metadata**: [`Icrc21ConsentMessageMetadata`](Icrc21ConsentMessageMetadata.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L104)
