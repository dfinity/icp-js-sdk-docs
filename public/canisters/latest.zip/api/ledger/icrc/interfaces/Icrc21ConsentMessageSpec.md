---
title: Icrc21ConsentMessageSpec
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:103](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L103)

Specification for the consent message, including metadata and device preferences.

## Param

Metadata of the consent message.

## Param

Information about the device responsible for presenting the consent message to the user.

## Properties

### deriveSpec?

> `optional` **deriveSpec**: [`Icrc21ConsentMessageDeviceSpec`](../type-aliases/Icrc21ConsentMessageDeviceSpec.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:105](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L105)

***

### metadata

> **metadata**: [`Icrc21ConsentMessageMetadata`](Icrc21ConsentMessageMetadata.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L104)
