---
title: Icrc21ConsentMessageMetadata
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L80)

Metadata for the consent message in ICRC-21 specification.

## Param

The user's local timezone offset in minutes from UTC. If absent, the default is UTC.

## Param

BCP-47 language tag. See https://www.rfc-editor.org/rfc/bcp/bcp47.txt

## Properties

### language

> **language**: `string`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L82)

***

### utcOffsetMinutes?

> `optional` **utcOffsetMinutes**: `number`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L81)
