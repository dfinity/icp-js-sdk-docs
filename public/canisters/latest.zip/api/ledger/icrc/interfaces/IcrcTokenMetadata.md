---
title: IcrcTokenMetadata
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:23](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L23)

## Properties

### decimals

> **decimals**: `number`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:27](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L27)

***

### fee

> **fee**: `bigint`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:26](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L26)

***

### icon?

> `optional` **icon**: `string`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:28](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L28)

***

### name

> **name**: `string`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:24](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L24)

***

### symbol

> **symbol**: `string`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:25](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L25)
