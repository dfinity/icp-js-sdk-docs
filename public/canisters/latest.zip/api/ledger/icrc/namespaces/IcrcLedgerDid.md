---
title: IcrcLedgerDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L553)

#### Properties

##### archives

> **archives**: `ActorMethod`\<\[\], [`ArchiveInfo`](#archiveinfo)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L554)

##### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`GetBlocksResponse`](#getblocksresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L555)

##### get\_data\_certificate

> **get\_data\_certificate**: `ActorMethod`\<\[\], [`DataCertificate`](#datacertificate)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L556)

##### get\_transactions

> **get\_transactions**: `ActorMethod`\<\[[`GetTransactionsRequest`](#gettransactionsrequest)\], [`GetTransactionsResponse`](#gettransactionsresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L557)

##### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L570)

##### icrc1\_decimals

> **icrc1\_decimals**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L571)

##### icrc1\_fee

> **icrc1\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L572)

##### icrc1\_metadata

> **icrc1\_metadata**: `ActorMethod`\<\[\], \[`string`, [`MetadataValue`](#metadatavalue)\][]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L573)

##### icrc1\_minting\_account

> **icrc1\_minting\_account**: `ActorMethod`\<\[\], \[\] \| \[[`Account`](#account)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L574)

##### icrc1\_name

> **icrc1\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L575)

##### icrc1\_supported\_standards

> **icrc1\_supported\_standards**: `ActorMethod`\<\[\], [`StandardRecord`](#standardrecord)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L576)

##### icrc1\_symbol

> **icrc1\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L577)

##### icrc1\_total\_supply

> **icrc1\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L578)

##### icrc1\_transfer

> **icrc1\_transfer**: `ActorMethod`\<\[[`TransferArg`](#transferarg)\], [`TransferResult`](#transferresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L579)

##### icrc10\_supported\_standards

> **icrc10\_supported\_standards**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:566](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L566)

##### icrc103\_get\_allowances

> **icrc103\_get\_allowances**: `ActorMethod`\<\[[`GetAllowancesArgs`](#getallowancesargs)\], [`icrc103_get_allowances_response`](#icrc103_get_allowances_response)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L561)

##### icrc106\_get\_index\_principal

> **icrc106\_get\_index\_principal**: `ActorMethod`\<\[\], [`GetIndexPrincipalResult`](#getindexprincipalresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L565)

##### icrc2\_allowance

> **icrc2\_allowance**: `ActorMethod`\<\[[`AllowanceArgs`](#allowanceargs)\], [`Allowance`](#allowance)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L584)

##### icrc2\_approve

> **icrc2\_approve**: `ActorMethod`\<\[[`ApproveArgs`](#approveargs)\], [`ApproveResult`](#approveresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L585)

##### icrc2\_transfer\_from

> **icrc2\_transfer\_from**: `ActorMethod`\<\[[`TransferFromArgs`](#transferfromargs)\], [`TransferFromResult`](#transferfromresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:586](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L586)

##### icrc21\_canister\_call\_consent\_message

> **icrc21\_canister\_call\_consent\_message**: `ActorMethod`\<\[[`icrc21_consent_message_request`](#icrc21_consent_message_request)\], [`icrc21_consent_message_response`](#icrc21_consent_message_response)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L580)

##### icrc3\_get\_archives

> **icrc3\_get\_archives**: `ActorMethod`\<\[[`GetArchivesArgs`](#getarchivesargs)\], [`GetArchivesResult`](#getarchivesresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:587](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L587)

##### icrc3\_get\_blocks

> **icrc3\_get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)[]\], [`GetBlocksResult`](#getblocksresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:588](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L588)

##### icrc3\_get\_tip\_certificate

> **icrc3\_get\_tip\_certificate**: `ActorMethod`\<\[\], \[\] \| \[[`ICRC3DataCertificate`](#icrc3datacertificate)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:589](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L589)

##### icrc3\_supported\_block\_types

> **icrc3\_supported\_block\_types**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:590](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L590)

##### is\_ledger\_ready

> **is\_ledger\_ready**: `ActorMethod`\<\[\], `boolean`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:594](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L594)

***

### Account

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L15)

***

### Allowance

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L17)

#### Properties

##### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L18)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L19)

***

### Allowance103

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L21)

#### Properties

##### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L24)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L25)

##### from\_account

> **from\_account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L22)

##### to\_spender

> **to\_spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L23)

***

### AllowanceArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L27)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L28)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L29)

***

### Approve

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L31)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L36)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L35)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L37)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L38)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L32)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L33)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L34)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L39)

***

### ApproveArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L41)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L46)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L45)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L47)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L48)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L42)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L44)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L43)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L49)

***

### ArchiveInfo

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L64)

#### Properties

##### block\_range\_end

> **block\_range\_end**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L65)

##### block\_range\_start

> **block\_range\_start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L67)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L66)

***

### BlockRange

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L74)

A prefix of the block range specified in the [GetBlocksArgs] request.

#### Properties

##### blocks

> **blocks**: [`Value`](#value)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L92)

A prefix of the requested block range.
The index of the first block is equal to [GetBlocksArgs.start].

Note that the number of blocks might be less than the requested
[GetBlocksArgs.length] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the whole range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of blocks can be empty if:

1. [GetBlocksArgs.length] was zero.
2. [GetBlocksArgs.start] was larger than the last block known to
the canister.

***

### Burn

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L94)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L99)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L98)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L95)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L96)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L97)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L100)

***

### ChangeArchiveOptions

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L102)

#### Properties

##### controller\_id

> **controller\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L110)

##### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L108)

##### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L107)

##### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L104)

##### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L106)

##### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L109)

##### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L103)

##### trigger\_threshold

> **trigger\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L105)

***

### DataCertificate

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L116)

Certificate for the block at `block_index`.

#### Properties

##### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L117)

##### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L118)

***

### FeatureFlags

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L124)

#### Properties

##### icrc2

> **icrc2**: `boolean`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L125)

***

### FeeCollector

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L127)

#### Properties

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L131)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L130)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L129)

##### ts

> **ts**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L128)

***

### FieldsDisplay

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L133)

#### Properties

##### fields

> **fields**: \[`string`, [`Icrc21Value`](#icrc21value)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L134)

##### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L135)

***

### GetAllowancesArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L137)

#### Properties

##### from\_account

> **from\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L140)

##### prev\_spender

> **prev\_spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L139)

##### take

> **take**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L138)

***

### GetArchivesArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L147)

#### Properties

##### from

> **from**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L154)

The last archive seen by the client.
The Ledger will return archives coming
after this one if set, otherwise it
will return the first archives.

***

### GetBlocksArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L170)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L178)

Max number of blocks to fetch.

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L174)

The index of the first block to fetch.

***

### GetBlocksResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L183)

The result of a "get_blocks" call.

#### Properties

##### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L212)

Encoding of instructions for fetching archived blocks.

###### callback

> **callback**: \[`Principal`, `string`\]

Callback to fetch the archived blocks.

###### length

> **length**: `bigint`

The number of blocks that can be fetched.

###### start

> **start**: `bigint`

The index of the first archived block.

##### blocks

> **blocks**: [`Value`](#value)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L203)

List of blocks that were available in the ledger when it processed the call.

The blocks form a contiguous range, with the first block having index
[first_block_index] (see below), and the last block having index
[first_block_index] + len(blocks) - 1.

The block range can be an arbitrary sub-range of the originally requested range.

##### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L188)

System certificate for the hash of the latest block in the chain.
Only present if `get_blocks` is called in a non-replicated query context.

##### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L208)

The total number of blocks in the chain.
If the chain length is positive, the index of the last block is `chain_len - 1`.

##### first\_index

> **first\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L193)

The index of the first block in "blocks".
If the blocks vector is empty, the exact value of this field is not specified.

***

### GetBlocksResult

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L227)

#### Properties

##### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L234)

###### args

> **args**: [`GetBlocksArgs`](#getblocksargs)[]

###### callback

> **callback**: \[`Principal`, `string`\]

##### blocks

> **blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L233)

###### block

> **block**: [`ICRC3Value`](#icrc3value)

###### id

> **id**: `bigint`

##### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L232)

Total number of blocks in the
block log

***

### GetTransactionsRequest

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L250)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L258)

The number of transactions to fetch.

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L254)

The index of the first tx to fetch.

***

### GetTransactionsResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L260)

#### Properties

##### archived\_transactions

> **archived\_transactions**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L287)

Encoding of instructions for fetching archived transactions whose indices fall into the
requested range.

For each entry `e` in [archived_transactions], `[e.from, e.from + len)` is a sub-range
of the originally requested transaction range.

###### callback

> **callback**: \[`Principal`, `string`\]

The function you should call to fetch the archived transactions.
The range of the transaction accessible using this function is given by [from]
and [len] fields above.

###### length

> **length**: `bigint`

The number of transactions you can fetch using the callback.

###### start

> **start**: `bigint`

The index of the first archived transaction you can fetch using the [callback].

##### first\_index

> **first\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L265)

The index of the first transaction in [transactions].
If the transaction vector is empty, the exact value of this field is not specified.

##### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L269)

The total number of transactions in the log.

##### transactions

> **transactions**: [`Transaction`](#transaction)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L279)

List of transaction that were available in the ledger when it processed the call.

The transactions form a contiguous range, with the first transaction having index
[first_index] (see below), and the last transaction having index
[first_index] + len(transactions) - 1.

The transaction range can be an arbitrary sub-range of the originally requested range.

***

### HttpRequest

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L304)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L307)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L308)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L306)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L305)

***

### HttpResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:310](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L310)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L311)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L312)

##### status\_code

> **status\_code**: `number`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L313)

***

### icrc21\_consent\_info

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L515)

#### Properties

##### consent\_message

> **consent\_message**: [`icrc21_consent_message`](#icrc21_consent_message)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:517](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L517)

##### metadata

> **metadata**: [`icrc21_consent_message_metadata`](#icrc21_consent_message_metadata)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L516)

***

### icrc21\_consent\_message\_metadata

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L524)

#### Properties

##### language

> **language**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L526)

##### utc\_offset\_minutes

> **utc\_offset\_minutes**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L525)

***

### icrc21\_consent\_message\_request

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L528)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L529)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L530)

##### user\_preferences

> **user\_preferences**: [`icrc21_consent_message_spec`](#icrc21_consent_message_spec)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L531)

***

### icrc21\_consent\_message\_spec

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L536)

#### Properties

##### device\_spec

> **device\_spec**: \[\] \| \[\{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L538)

##### metadata

> **metadata**: [`icrc21_consent_message_metadata`](#icrc21_consent_message_metadata)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L537)

***

### icrc21\_error\_info

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L550)

#### Properties

##### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L551)

***

### ICRC3DataCertificate

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L315)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L319)

See https://internetcomputer.org/docs/current/references/ic-interface-spec#certification

##### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L323)

CBOR encoded hash_tree

***

### InitArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L346)

The initialization parameters of the Ledger

#### Properties

##### archive\_options

> **archive\_options**: `object`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L354)

###### controller\_id

> **controller\_id**: `Principal`

###### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

###### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

###### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

###### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

###### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

###### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: `bigint`

###### trigger\_threshold

> **trigger\_threshold**: `bigint`

##### decimals

> **decimals**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L347)

##### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](#featureflags)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L367)

##### fee\_collector\_account

> **fee\_collector\_account**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L353)

##### index\_principal

> **index\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L365)

##### initial\_balances

> **initial\_balances**: \[[`Account`](#account), `bigint`\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L352)

##### max\_memo\_length

> **max\_memo\_length**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L364)

##### metadata

> **metadata**: \[`string`, [`MetadataValue`](#metadatavalue)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L350)

##### minting\_account

> **minting\_account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L351)

##### token\_name

> **token\_name**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L366)

##### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L348)

##### transfer\_fee

> **transfer\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L349)

***

### Mint

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L379)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L384)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L383)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L381)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L382)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L380)

***

### StandardRecord

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L397)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L399)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L398)

***

### Transaction

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L407)

#### Properties

##### approve

> **approve**: \[\] \| \[[`Approve`](#approve)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L411)

##### burn

> **burn**: \[\] \| \[[`Burn`](#burn)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L408)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`FeeCollector`](#feecollector)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L412)

##### kind

> **kind**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L409)

##### mint

> **mint**: \[\] \| \[[`Mint`](#mint)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L410)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L413)

##### transfer

> **transfer**: \[\] \| \[[`Transfer`](#transfer-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L414)

***

### TransactionRange

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L419)

A prefix of the transaction range specified in the [GetTransactionsRequest] request.

#### Properties

##### transactions

> **transactions**: [`Transaction`](#transaction)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L437)

A prefix of the requested transaction range.
The index of the first transaction is equal to [GetTransactionsRequest.from].

Note that the number of transactions might be less than the requested
[GetTransactionsRequest.length] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the whole range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of transactions can be empty if:

1. [GetTransactionsRequest.length] was zero.
2. [GetTransactionsRequest.from] was larger than the last transaction known to
the canister.

***

### Transfer

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L439)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L445)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L444)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L441)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L442)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L443)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:446](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L446)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L440)

***

### TransferArg

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L448)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L454)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L453)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:450](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L450)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L452)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L451)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L449)

***

### TransferFromArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L467)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L474)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L473)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L469)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L471)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L472)

##### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L470)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L468)

***

### UpgradeArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L493)

#### Properties

##### change\_archive\_options

> **change\_archive\_options**: \[\] \| \[[`ChangeArchiveOptions`](#changearchiveoptions)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L494)

##### change\_fee\_collector

> **change\_fee\_collector**: \[\] \| \[[`ChangeFeeCollector`](#changefeecollector)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L498)

##### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](#featureflags)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L502)

##### index\_principal

> **index\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L500)

##### max\_memo\_length

> **max\_memo\_length**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L499)

##### metadata

> **metadata**: \[\] \| \[\[`string`, [`MetadataValue`](#metadatavalue)\][]\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L497)

##### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L501)

##### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L495)

##### transfer\_fee

> **transfer\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L496)

## Type Aliases

### ApproveError

> **ApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L51)

***

### ApproveResult

> **ApproveResult** = \{ `Ok`: [`BlockIndex`](#blockindex); \} \| \{ `Err`: [`ApproveError`](#approveerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L63)

***

### Block

> **Block** = [`Value`](#value)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L69)

***

### BlockIndex

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L70)

***

### ChangeFeeCollector

> **ChangeFeeCollector** = \{ `SetTo`: [`Account`](#account); \} \| \{ `Unset`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L112)

***

### Duration

> **Duration** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L123)

Number of nanoseconds between two [Timestamp]s.

***

### GetAllowancesError

> **GetAllowancesError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `AccessDenied`: \{ `reason`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L142)

***

### GetArchivesResult

> **GetArchivesResult** = `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L156)

#### Type Declaration

##### canister\_id

> **canister\_id**: `Principal`

The id of the archive

##### end

> **end**: `bigint`

The last block in the archive

##### start

> **start**: `bigint`

The first block in the archive

***

### GetIndexPrincipalError

> **GetIndexPrincipalError** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `IndexPrincipalNotSet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L239)

#### Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

##### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

###### GenericError.description

> **description**: `string`

###### GenericError.error\_code

> **error\_code**: `bigint`

\{ `IndexPrincipalNotSet`: `null`; \}

##### IndexPrincipalNotSet

> **IndexPrincipalNotSet**: `null`

***

### GetIndexPrincipalResult

> **GetIndexPrincipalResult** = \{ `Ok`: `Principal`; \} \| \{ `Err`: [`GetIndexPrincipalError`](#getindexprincipalerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L247)

***

### icrc103\_get\_allowances\_response

> **icrc103\_get\_allowances\_response** = \{ `Ok`: [`Allowance103`](#allowance103)[]; \} \| \{ `Err`: [`GetAllowancesError`](#getallowanceserror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L512)

***

### icrc21\_consent\_message

> **icrc21\_consent\_message** = \{ `FieldsDisplayMessage`: [`FieldsDisplay`](#fieldsdisplay); \} \| \{ `GenericDisplayMessage`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L519)

***

### icrc21\_consent\_message\_response

> **icrc21\_consent\_message\_response** = \{ `Ok`: [`icrc21_consent_info`](#icrc21_consent_info); \} \| \{ `Err`: [`icrc21_error`](#icrc21_error); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L533)

***

### icrc21\_error

> **icrc21\_error** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `InsufficientPayment`: [`icrc21_error_info`](#icrc21_error_info); \} \| \{ `UnsupportedCanisterCall`: [`icrc21_error_info`](#icrc21_error_info); \} \| \{ `ConsentMessageUnavailable`: [`icrc21_error_info`](#icrc21_error_info); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L540)

#### Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

##### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

###### GenericError.description

> **description**: `string`

###### GenericError.error\_code

> **error\_code**: `bigint`

\{ `InsufficientPayment`: [`icrc21_error_info`](#icrc21_error_info); \}

##### InsufficientPayment

> **InsufficientPayment**: [`icrc21_error_info`](#icrc21_error_info)

\{ `UnsupportedCanisterCall`: [`icrc21_error_info`](#icrc21_error_info); \}

##### UnsupportedCanisterCall

> **UnsupportedCanisterCall**: [`icrc21_error_info`](#icrc21_error_info)

\{ `ConsentMessageUnavailable`: [`icrc21_error_info`](#icrc21_error_info); \}

##### ConsentMessageUnavailable

> **ConsentMessageUnavailable**: [`icrc21_error_info`](#icrc21_error_info)

***

### Icrc21Value

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:332](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L332)

***

### ICRC3Value

> **ICRC3Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`ICRC3Value`](#icrc3value)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`ICRC3Value`](#icrc3value)[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L325)

***

### LedgerArg

> **LedgerArg** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](#upgradeargs)\]; \} \| \{ `Init`: [`InitArgs`](#initargs); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L369)

***

### Map

> **Map** = \[`string`, [`Value`](#value)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L370)

***

### MetadataValue

> **MetadataValue** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L374)

The value returned from the [icrc1_metadata] endpoint.

***

### QueryArchiveFn

> **QueryArchiveFn** = `ActorMethod`\<\[[`GetTransactionsRequest`](#gettransactionsrequest)\], [`TransactionRange`](#transactionrange)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L389)

A function for fetching archived transaction.

***

### QueryBlockArchiveFn

> **QueryBlockArchiveFn** = `ActorMethod`\<\[[`GetBlocksArgs`](#getblocksargs)\], [`BlockRange`](#blockrange)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L396)

A function for fetching archived blocks.

***

### Subaccount

> **Subaccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L401)

***

### Timestamp

> **Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L405)

Number of nanoseconds since the UNIX epoch in UTC timezone.

***

### Tokens

> **Tokens** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L406)

***

### TransferError

> **TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Tokens`](#tokens); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Tokens`](#tokens); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Tokens`](#tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:456](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L456)

***

### TransferFromError

> **TransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: [`Tokens`](#tokens); \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Tokens`](#tokens); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](#blockindex); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Tokens`](#tokens); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Timestamp`](#timestamp-1); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Tokens`](#tokens); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L476)

***

### TransferFromResult

> **TransferFromResult** = \{ `Ok`: [`BlockIndex`](#blockindex); \} \| \{ `Err`: [`TransferFromError`](#transferfromerror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L488)

***

### TransferResult

> **TransferResult** = \{ `Ok`: [`BlockIndex`](#blockindex); \} \| \{ `Err`: [`TransferError`](#transfererror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L491)

***

### TxIndex

> **TxIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L492)

***

### Value

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: [`Map`](#map); \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`Value`](#value)[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L504)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L596)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:597](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L597)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
