---
title: IcrcNftLedgerDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L47)

#### Properties

##### icrc7\_atomic\_batch\_transfers

> **icrc7\_atomic\_batch\_transfers**: `ActorMethod`\<\[\], \[\] \| \[`boolean`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L48)

##### icrc7\_balance\_of

> **icrc7\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)[]\], `bigint`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L49)

##### icrc7\_collection\_metadata

> **icrc7\_collection\_metadata**: `ActorMethod`\<\[\], \[`string`, [`Value`](#value)\][]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L50)

##### icrc7\_default\_take\_value

> **icrc7\_default\_take\_value**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L51)

##### icrc7\_description

> **icrc7\_description**: `ActorMethod`\<\[\], \[\] \| \[`string`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L52)

##### icrc7\_logo

> **icrc7\_logo**: `ActorMethod`\<\[\], \[\] \| \[`string`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L53)

##### icrc7\_max\_memo\_size

> **icrc7\_max\_memo\_size**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L54)

##### icrc7\_max\_query\_batch\_size

> **icrc7\_max\_query\_batch\_size**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L55)

##### icrc7\_max\_take\_value

> **icrc7\_max\_take\_value**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L56)

##### icrc7\_max\_update\_batch\_size

> **icrc7\_max\_update\_batch\_size**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L57)

##### icrc7\_name

> **icrc7\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L58)

##### icrc7\_owner\_of

> **icrc7\_owner\_of**: `ActorMethod`\<\[`bigint`[]\], (\[\] \| \[[`Account`](#account)\])[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L59)

##### icrc7\_permitted\_drift

> **icrc7\_permitted\_drift**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L60)

##### icrc7\_supply\_cap

> **icrc7\_supply\_cap**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L61)

##### icrc7\_symbol

> **icrc7\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L62)

##### icrc7\_token\_metadata

> **icrc7\_token\_metadata**: `ActorMethod`\<\[`bigint`[]\], (\[\] \| \[\[`string`, [`Value`](#value)\][]\])[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L63)

##### icrc7\_tokens

> **icrc7\_tokens**: `ActorMethod`\<\[\[\] \| \[`bigint`\], \[\] \| \[`bigint`\]\], `bigint`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L67)

##### icrc7\_tokens\_of

> **icrc7\_tokens\_of**: `ActorMethod`\<\[[`Account`](#account), \[\] \| \[`bigint`\], \[\] \| \[`bigint`\]\], `bigint`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L68)

##### icrc7\_total\_supply

> **icrc7\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L72)

##### icrc7\_transfer

> **icrc7\_transfer**: `ActorMethod`\<\[[`TransferArg`](#transferarg)[]\], (\[\] \| \[[`TransferResult`](#transferresult)\])[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L73)

##### icrc7\_tx\_window

> **icrc7\_tx\_window**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L77)

***

### Account

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L15)

***

### TransferArg

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L18)

#### Properties

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L23)

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L22)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L21)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L19)

##### token\_id

> **token\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L20)

## Type Aliases

### Subaccount

> **Subaccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L17)

***

### TransferError

> **TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `NonExistingTokenId`: `null`; \} \| \{ `Unauthorized`: `null`; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `InvalidRecipient`: `null`; \} \| \{ `GenericBatchError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TooOld`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L25)

***

### TransferResult

> **TransferResult** = \{ `Ok`: `bigint`; \} \| \{ `Err`: [`TransferError`](#transfererror); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L36)

***

### Value

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, [`Value`](#value)\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`Value`](#value)[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L40)

Generic value in accordance with ICRC-3

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L79)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L80)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
