---
title: IcrcNftLedgerDid
editUrl: false
next: true
prev: true
---

## Interfaces

- [\_SERVICE](interfaces/SERVICE.md)
- [Account](interfaces/Account.md)
- [TransferArg](interfaces/TransferArg.md)

## Type Aliases

- [Subaccount](type-aliases/Subaccount.md)
- [TransferError](type-aliases/TransferError.md)
- [TransferResult](type-aliases/TransferResult.md)
- [Value](type-aliases/Value.md)

## Variables

- [idlFactory](variables/idlFactory.md)
- [init](variables/init.md)
