---
title: GetArchivesResult
editUrl: false
next: true
prev: true
---

> **GetArchivesResult** = `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L155)

## Type Declaration

### canister\_id

> **canister\_id**: `Principal`

The id of the archive

### end

> **end**: `bigint`

The last block in the archive

### start

> **start**: `bigint`

The first block in the archive
