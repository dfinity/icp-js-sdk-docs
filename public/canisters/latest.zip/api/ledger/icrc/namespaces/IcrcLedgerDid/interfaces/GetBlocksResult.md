---
title: GetBlocksResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L226)

## Properties

### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L233)

#### args

> **args**: [`GetBlocksArgs`](GetBlocksArgs.md)[]

#### callback

> **callback**: \[`Principal`, `string`\]

***

### blocks

> **blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L232)

#### block

> **block**: [`ICRC3Value`](../type-aliases/ICRC3Value.md)

#### id

> **id**: `bigint`

***

### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L231)

Total number of blocks in the
block log
