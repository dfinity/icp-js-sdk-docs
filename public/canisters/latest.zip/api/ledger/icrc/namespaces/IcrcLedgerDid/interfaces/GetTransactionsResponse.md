---
title: GetTransactionsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:259](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L259)

## Properties

### archived\_transactions

> **archived\_transactions**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L286)

Encoding of instructions for fetching archived transactions whose indices fall into the
requested range.

For each entry `e` in [archived_transactions], `[e.from, e.from + len)` is a sub-range
of the originally requested transaction range.

#### callback

> **callback**: \[`Principal`, `string`\]

The function you should call to fetch the archived transactions.
The range of the transaction accessible using this function is given by [from]
and [len] fields above.

#### length

> **length**: `bigint`

The number of transactions you can fetch using the callback.

#### start

> **start**: `bigint`

The index of the first archived transaction you can fetch using the [callback].

***

### first\_index

> **first\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L264)

The index of the first transaction in [transactions].
If the transaction vector is empty, the exact value of this field is not specified.

***

### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L268)

The total number of transactions in the log.

***

### transactions

> **transactions**: [`Transaction`](Transaction.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L278)

List of transaction that were available in the ledger when it processed the call.

The transactions form a contiguous range, with the first transaction having index
[first_index] (see below), and the last transaction having index
[first_index] + len(transactions) - 1.

The transaction range can be an arbitrary sub-range of the originally requested range.
