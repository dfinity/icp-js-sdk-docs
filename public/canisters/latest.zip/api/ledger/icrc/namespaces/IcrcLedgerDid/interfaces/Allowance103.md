---
title: Allowance103
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L21)

## Properties

### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L24)

***

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L25)

***

### from\_account

> **from\_account**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L22)

***

### to\_spender

> **to\_spender**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L23)
