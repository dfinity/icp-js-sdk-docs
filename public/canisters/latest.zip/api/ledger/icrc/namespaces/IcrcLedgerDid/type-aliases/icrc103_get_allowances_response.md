---
title: icrc103_get_allowances_response
editUrl: false
next: true
prev: true
---

> **icrc103\_get\_allowances\_response** = \{ `Ok`: [`Allowance103`](../interfaces/Allowance103.md)[]; \} \| \{ `Err`: [`GetAllowancesError`](GetAllowancesError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L511)
