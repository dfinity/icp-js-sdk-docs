---
title: BlockRange
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L74)

A prefix of the block range specified in the [GetBlocksArgs] request.

## Properties

### blocks

> **blocks**: [`Value`](../type-aliases/Value.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L92)

A prefix of the requested block range.
The index of the first block is equal to [GetBlocksArgs.start].

Note that the number of blocks might be less than the requested
[GetBlocksArgs.length] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the whole range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of blocks can be empty if:

1. [GetBlocksArgs.length] was zero.
2. [GetBlocksArgs.start] was larger than the last block known to
the canister.
