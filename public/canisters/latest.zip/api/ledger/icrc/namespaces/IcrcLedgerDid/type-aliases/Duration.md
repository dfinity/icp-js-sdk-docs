---
title: Duration
editUrl: false
next: true
prev: true
---

> **Duration** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L123)

Number of nanoseconds between two [Timestamp]s.
