---
title: QueryArchiveFn
editUrl: false
next: true
prev: true
---

> **QueryArchiveFn** = `ActorMethod`\<\[[`GetTransactionsRequest`](../interfaces/GetTransactionsRequest.md)\], [`TransactionRange`](../interfaces/TransactionRange.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L388)

A function for fetching archived transaction.
