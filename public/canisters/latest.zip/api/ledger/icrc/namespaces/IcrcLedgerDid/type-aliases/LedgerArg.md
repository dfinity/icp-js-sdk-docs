---
title: LedgerArg
editUrl: false
next: true
prev: true
---

> **LedgerArg** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](../interfaces/UpgradeArgs.md)\]; \} \| \{ `Init`: [`InitArgs`](../interfaces/InitArgs.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L368)
