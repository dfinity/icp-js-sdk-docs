---
title: Icrc21Value
editUrl: false
next: true
prev: true
---

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L331)
