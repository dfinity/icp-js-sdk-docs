---
title: Subaccount
editUrl: false
next: true
prev: true
---

> **Subaccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L400)
