---
title: DataCertificate
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L116)

Certificate for the block at `block_index`.

## Properties

### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L117)

***

### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L118)
