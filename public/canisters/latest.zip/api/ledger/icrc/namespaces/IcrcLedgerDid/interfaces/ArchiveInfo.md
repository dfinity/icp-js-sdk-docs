---
title: ArchiveInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L64)

## Properties

### block\_range\_end

> **block\_range\_end**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L65)

***

### block\_range\_start

> **block\_range\_start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L67)

***

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L66)
