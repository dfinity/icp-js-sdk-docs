---
title: ICRC3Value
editUrl: false
next: true
prev: true
---

> **ICRC3Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `ICRC3Value`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `ICRC3Value`[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L324)
