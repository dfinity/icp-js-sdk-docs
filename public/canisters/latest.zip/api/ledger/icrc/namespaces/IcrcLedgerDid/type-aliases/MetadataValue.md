---
title: MetadataValue
editUrl: false
next: true
prev: true
---

> **MetadataValue** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L373)

The value returned from the [icrc1_metadata] endpoint.
