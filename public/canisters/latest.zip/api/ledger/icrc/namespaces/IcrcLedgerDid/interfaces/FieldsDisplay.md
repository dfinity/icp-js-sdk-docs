---
title: FieldsDisplay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L132)

## Properties

### fields

> **fields**: \[`string`, [`Icrc21Value`](../type-aliases/Icrc21Value.md)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L133)

***

### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L134)
