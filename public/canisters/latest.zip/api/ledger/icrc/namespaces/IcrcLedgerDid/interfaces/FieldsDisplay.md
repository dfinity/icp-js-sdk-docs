---
title: FieldsDisplay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L132)

## Properties

### fields

> **fields**: \[`string`, [`Icrc21Value`](../type-aliases/Icrc21Value.md)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L133)

***

### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L134)
