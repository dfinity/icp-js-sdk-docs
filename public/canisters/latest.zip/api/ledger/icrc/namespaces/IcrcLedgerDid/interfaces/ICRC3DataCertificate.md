---
title: ICRC3DataCertificate
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L314)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L318)

See https://internetcomputer.org/docs/current/references/ic-interface-spec#certification

***

### hash\_tree

> **hash\_tree**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L322)

CBOR encoded hash_tree
