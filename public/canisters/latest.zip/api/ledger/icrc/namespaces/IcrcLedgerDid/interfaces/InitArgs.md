---
title: InitArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L345)

The initialization parameters of the Ledger

## Properties

### archive\_options

> **archive\_options**: `object`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L353)

#### controller\_id

> **controller\_id**: `Principal`

#### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

#### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

#### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

#### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

#### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

#### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: `bigint`

#### trigger\_threshold

> **trigger\_threshold**: `bigint`

***

### decimals

> **decimals**: \[\] \| \[`number`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L346)

***

### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](FeatureFlags.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L366)

***

### fee\_collector\_account

> **fee\_collector\_account**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L352)

***

### index\_principal

> **index\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L364)

***

### initial\_balances

> **initial\_balances**: \[[`Account`](Account.md), `bigint`\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L351)

***

### max\_memo\_length

> **max\_memo\_length**: \[\] \| \[`number`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L363)

***

### metadata

> **metadata**: \[`string`, [`MetadataValue`](../type-aliases/MetadataValue.md)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L349)

***

### minting\_account

> **minting\_account**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L350)

***

### token\_name

> **token\_name**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L365)

***

### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L347)

***

### transfer\_fee

> **transfer\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L348)
