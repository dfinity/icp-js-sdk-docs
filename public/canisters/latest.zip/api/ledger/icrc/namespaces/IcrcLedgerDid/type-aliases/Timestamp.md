---
title: Timestamp
editUrl: false
next: true
prev: true
---

> **Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L404)

Number of nanoseconds since the UNIX epoch in UTC timezone.
