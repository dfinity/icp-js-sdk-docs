---
title: Timestamp
editUrl: false
next: true
prev: true
---

> **Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L404)

Number of nanoseconds since the UNIX epoch in UTC timezone.
