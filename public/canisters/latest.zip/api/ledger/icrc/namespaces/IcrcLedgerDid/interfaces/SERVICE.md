---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L552)

## Properties

### archives

> **archives**: `ActorMethod`\<\[\], [`ArchiveInfo`](ArchiveInfo.md)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L553)

***

### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](GetBlocksArgs.md)\], [`GetBlocksResponse`](GetBlocksResponse.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L554)

***

### get\_data\_certificate

> **get\_data\_certificate**: `ActorMethod`\<\[\], [`DataCertificate`](DataCertificate.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L555)

***

### get\_transactions

> **get\_transactions**: `ActorMethod`\<\[[`GetTransactionsRequest`](GetTransactionsRequest.md)\], [`GetTransactionsResponse`](GetTransactionsResponse.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L556)

***

### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](Account.md)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L569)

***

### icrc1\_decimals

> **icrc1\_decimals**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L570)

***

### icrc1\_fee

> **icrc1\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L571)

***

### icrc1\_metadata

> **icrc1\_metadata**: `ActorMethod`\<\[\], \[`string`, [`MetadataValue`](../type-aliases/MetadataValue.md)\][]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L572)

***

### icrc1\_minting\_account

> **icrc1\_minting\_account**: `ActorMethod`\<\[\], \[\] \| \[[`Account`](Account.md)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L573)

***

### icrc1\_name

> **icrc1\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L574)

***

### icrc1\_supported\_standards

> **icrc1\_supported\_standards**: `ActorMethod`\<\[\], [`StandardRecord`](StandardRecord.md)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L575)

***

### icrc1\_symbol

> **icrc1\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L576)

***

### icrc1\_total\_supply

> **icrc1\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L577)

***

### icrc1\_transfer

> **icrc1\_transfer**: `ActorMethod`\<\[[`TransferArg`](TransferArg.md)\], [`TransferResult`](../type-aliases/TransferResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L578)

***

### icrc10\_supported\_standards

> **icrc10\_supported\_standards**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L565)

***

### icrc103\_get\_allowances

> **icrc103\_get\_allowances**: `ActorMethod`\<\[[`GetAllowancesArgs`](GetAllowancesArgs.md)\], [`icrc103_get_allowances_response`](../type-aliases/icrc103_get_allowances_response.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L560)

***

### icrc106\_get\_index\_principal

> **icrc106\_get\_index\_principal**: `ActorMethod`\<\[\], [`GetIndexPrincipalResult`](../type-aliases/GetIndexPrincipalResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L564)

***

### icrc2\_allowance

> **icrc2\_allowance**: `ActorMethod`\<\[[`AllowanceArgs`](AllowanceArgs.md)\], [`Allowance`](Allowance.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:583](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L583)

***

### icrc2\_approve

> **icrc2\_approve**: `ActorMethod`\<\[[`ApproveArgs`](ApproveArgs.md)\], [`ApproveResult`](../type-aliases/ApproveResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L584)

***

### icrc2\_transfer\_from

> **icrc2\_transfer\_from**: `ActorMethod`\<\[[`TransferFromArgs`](TransferFromArgs.md)\], [`TransferFromResult`](../type-aliases/TransferFromResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L585)

***

### icrc21\_canister\_call\_consent\_message

> **icrc21\_canister\_call\_consent\_message**: `ActorMethod`\<\[[`icrc21_consent_message_request`](icrc21_consent_message_request.md)\], [`icrc21_consent_message_response`](../type-aliases/icrc21_consent_message_response.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L579)

***

### icrc3\_get\_archives

> **icrc3\_get\_archives**: `ActorMethod`\<\[[`GetArchivesArgs`](GetArchivesArgs.md)\], [`GetArchivesResult`](../type-aliases/GetArchivesResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:586](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L586)

***

### icrc3\_get\_blocks

> **icrc3\_get\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](GetBlocksArgs.md)[]\], [`GetBlocksResult`](GetBlocksResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:587](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L587)

***

### icrc3\_get\_tip\_certificate

> **icrc3\_get\_tip\_certificate**: `ActorMethod`\<\[\], \[\] \| \[[`ICRC3DataCertificate`](ICRC3DataCertificate.md)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:588](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L588)

***

### icrc3\_supported\_block\_types

> **icrc3\_supported\_block\_types**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:589](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L589)

***

### is\_ledger\_ready

> **is\_ledger\_ready**: `ActorMethod`\<\[\], `boolean`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:593](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L593)
