---
title: GetAllowancesError
editUrl: false
next: true
prev: true
---

> **GetAllowancesError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `AccessDenied`: \{ `reason`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L141)
