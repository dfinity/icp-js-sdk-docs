---
title: GetAllowancesError
editUrl: false
next: true
prev: true
---

> **GetAllowancesError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `AccessDenied`: \{ `reason`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L141)
