---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L160)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
