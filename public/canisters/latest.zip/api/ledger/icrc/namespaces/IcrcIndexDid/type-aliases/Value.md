---
title: Value
editUrl: false
next: true
prev: true
---

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: [`Map`](Map.md); \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `Value`[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L139)
