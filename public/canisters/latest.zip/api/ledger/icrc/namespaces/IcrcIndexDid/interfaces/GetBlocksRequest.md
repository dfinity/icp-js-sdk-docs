---
title: GetBlocksRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L59)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L61)

***

### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L60)
