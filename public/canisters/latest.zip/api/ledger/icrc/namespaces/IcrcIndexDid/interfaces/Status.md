---
title: Status
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L103)

## Properties

### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L104)
