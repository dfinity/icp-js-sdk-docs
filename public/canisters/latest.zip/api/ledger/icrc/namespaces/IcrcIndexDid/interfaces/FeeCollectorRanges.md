---
title: FeeCollectorRanges
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L42)

## Properties

### ranges

> **ranges**: \[[`Account`](Account.md), \[`bigint`, `bigint`\][]\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L43)
