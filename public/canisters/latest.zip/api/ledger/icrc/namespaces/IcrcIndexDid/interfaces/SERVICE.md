---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L147)

## Properties

### get\_account\_transactions

> **get\_account\_transactions**: `ActorMethod`\<\[[`GetAccountTransactionsArgs`](GetAccountTransactionsArgs.md)\], [`GetTransactionsResult`](../type-aliases/GetTransactionsResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L148)

***

### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksRequest`](GetBlocksRequest.md)\], [`GetBlocksResponse`](GetBlocksResponse.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L152)

***

### get\_fee\_collectors\_ranges

> **get\_fee\_collectors\_ranges**: `ActorMethod`\<\[\], [`FeeCollectorRanges`](FeeCollectorRanges.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L153)

***

### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](Account.md)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L154)

***

### ledger\_id

> **ledger\_id**: `ActorMethod`\<\[\], `Principal`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L155)

***

### list\_subaccounts

> **list\_subaccounts**: `ActorMethod`\<\[[`ListSubaccountsArgs`](ListSubaccountsArgs.md)\], [`SubAccount`](../type-aliases/SubAccount.md)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L156)

***

### status

> **status**: `ActorMethod`\<\[\], [`Status`](Status.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L157)
