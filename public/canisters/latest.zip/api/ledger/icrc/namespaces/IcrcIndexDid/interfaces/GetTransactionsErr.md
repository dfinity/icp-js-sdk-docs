---
title: GetTransactionsErr
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L75)

## Properties

### message

> **message**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L76)
