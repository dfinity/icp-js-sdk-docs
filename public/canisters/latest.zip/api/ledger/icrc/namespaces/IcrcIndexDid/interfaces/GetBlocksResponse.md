---
title: GetBlocksResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L63)

## Properties

### blocks

> **blocks**: [`Value`](../type-aliases/Value.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L64)

***

### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L65)
