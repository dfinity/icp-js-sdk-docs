---
title: Transaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L108)

## Properties

### approve

> **approve**: \[\] \| \[[`Approve`](Approve.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L112)

***

### burn

> **burn**: \[\] \| \[[`Burn`](Burn.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L109)

***

### fee\_collector

> **fee\_collector**: \[\] \| \[[`FeeCollector`](FeeCollector.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L113)

***

### kind

> **kind**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L110)

***

### mint

> **mint**: \[\] \| \[[`Mint`](Mint.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L111)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L114)

***

### transfer

> **transfer**: \[\] \| \[[`Transfer`](Transfer.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L115)
