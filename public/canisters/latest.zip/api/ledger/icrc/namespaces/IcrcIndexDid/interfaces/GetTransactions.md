---
title: GetTransactions
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L67)

## Properties

### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L68)

***

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L73)

The txid of the oldest transaction the account has

***

### transactions

> **transactions**: [`TransactionWithId`](TransactionWithId.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L69)
