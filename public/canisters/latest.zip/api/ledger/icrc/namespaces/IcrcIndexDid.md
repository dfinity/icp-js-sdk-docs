---
title: IcrcIndexDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L168)

#### Properties

##### get\_account\_transactions

> **get\_account\_transactions**: `ActorMethod`\<\[[`GetAccountTransactionsArgs`](#getaccounttransactionsargs)\], [`GetTransactionsResult`](#gettransactionsresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L169)

##### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksRequest`](#getblocksrequest)\], [`GetBlocksResponse`](#getblocksresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:173](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L173)

##### get\_fee\_collectors\_ranges

> **get\_fee\_collectors\_ranges**: `ActorMethod`\<\[\], [`FeeCollectorRanges`](#feecollectorranges)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L174)

##### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L175)

##### ledger\_id

> **ledger\_id**: `ActorMethod`\<\[\], `Principal`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L176)

##### list\_subaccounts

> **list\_subaccounts**: `ActorMethod`\<\[[`ListSubaccountsArgs`](#listsubaccountsargs)\], [`SubAccount`](#subaccount-1)[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L177)

##### status

> **status**: `ActorMethod`\<\[\], [`Status`](#status-1)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:178](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L178)

***

### Account

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L15)

***

### Approve

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L17)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L22)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L21)

##### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L23)

##### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L24)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L18)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L19)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L20)

##### spender

> **spender**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L25)

***

### Burn

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L29)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L34)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L33)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L30)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L31)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L32)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L35)

***

### FeeCollector

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L37)

#### Properties

##### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L41)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L40)

##### mthd

> **mthd**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L39)

##### ts

> **ts**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L38)

***

### FeeCollectorRanges

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L43)

#### Properties

##### ranges

> **ranges**: \[[`Account`](#account), \[`bigint`, `bigint`\][]\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L44)

***

### GetAccountTransactionsArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L46)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L58)

##### max\_results

> **max\_results**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L50)

Maximum number of transactions to fetch.

##### start

> **start**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L57)

The txid of the last transaction seen by the client.
If None then the results will start from the most recent
txid. If set then the results will start from the next
most recent txid after start (start won't be included).

***

### GetBlocksRequest

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L60)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L62)

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L61)

***

### GetBlocksResponse

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L64)

#### Properties

##### blocks

> **blocks**: [`Value`](#value)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L65)

##### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L66)

***

### GetTransactions

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L68)

#### Properties

##### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L69)

##### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L74)

The txid of the oldest transaction the account has

##### transactions

> **transactions**: [`TransactionWithId`](#transactionwithid)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L70)

***

### GetTransactionsErr

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L76)

#### Properties

##### message

> **message**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L77)

***

### InitArg

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L83)

#### Properties

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L84)

##### max\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **max\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L100)

##### min\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **min\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L99)

The minimum and maximum intervals in seconds in which to retrieve blocks from the ledger.
When a request to the ledger returns an empty response, the interval is increased (up to the maximum).
In case of a non-empty response, the interval is decreased (down to the minimum). A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.

##### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L91)

The legacy parameter to set a fixed interval in seconds in which to retrieve blocks from the ledger.
If set, the index will set both `min_retrieve_blocks_from_ledger_interval_seconds` and
`max_retrieve_blocks_from_ledger_interval_seconds` to the value of `retrieve_blocks_from_ledger_interval_seconds`.
If either the min or max interval parameters are also set, the index will trap during initialization.

***

### ListSubaccountsArgs

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L102)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L103)

##### start

> **start**: \[\] \| \[[`SubAccount`](#subaccount-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L104)

***

### Mint

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L107)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L112)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L111)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L109)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L110)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L108)

***

### Status

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L114)

#### Properties

##### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L115)

***

### Transaction

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L119)

#### Properties

##### approve

> **approve**: \[\] \| \[[`Approve`](#approve)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L123)

##### burn

> **burn**: \[\] \| \[[`Burn`](#burn)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L120)

##### fee\_collector

> **fee\_collector**: \[\] \| \[[`FeeCollector`](#feecollector)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:124](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L124)

##### kind

> **kind**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L121)

##### mint

> **mint**: \[\] \| \[[`Mint`](#mint)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L122)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L125)

##### transfer

> **transfer**: \[\] \| \[[`Transfer`](#transfer-1)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:126](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L126)

***

### TransactionWithId

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L128)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L129)

##### transaction

> **transaction**: [`Transaction`](#transaction)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L130)

***

### Transfer

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L132)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L138)

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L137)

##### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L134)

##### from

> **from**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L135)

##### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L136)

##### spender

> **spender**: \[\] \| \[[`Account`](#account)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L139)

##### to

> **to**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L133)

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L141)

#### Properties

##### ledger\_id

> **ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L142)

##### max\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **max\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L158)

##### min\_retrieve\_blocks\_from\_ledger\_interval\_seconds

> **min\_retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L157)

The minimum and maximum intervals in seconds in which to retrieve blocks from the ledger.
When a request to the ledger returns an empty response, the interval is increased (up to the maximum).
In case of a non-empty response, the interval is decreased (down to the minimum). A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.

##### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L149)

The legacy parameter to set a fixed interval in seconds in which to retrieve blocks from the ledger.
If set, the index will set both `min_retrieve_blocks_from_ledger_interval_seconds` and
`max_retrieve_blocks_from_ledger_interval_seconds` to the value of `retrieve_blocks_from_ledger_interval_seconds`.
If either the min or max interval parameters are also set, the index will trap during post upgrade.

## Type Aliases

### Block

> **Block** = [`Value`](#value)

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L27)

***

### BlockIndex

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L28)

***

### GetTransactionsResult

> **GetTransactionsResult** = \{ `Ok`: [`GetTransactions`](#gettransactions); \} \| \{ `Err`: [`GetTransactionsErr`](#gettransactionserr); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L79)

***

### IndexArg

> **IndexArg** = \{ `Upgrade`: [`UpgradeArg`](#upgradearg); \} \| \{ `Init`: [`InitArg`](#initarg); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L82)

***

### Map

> **Map** = \[`string`, [`Value`](#value)\][]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L106)

***

### SubAccount

> **SubAccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L117)

***

### Tokens

> **Tokens** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L118)

***

### Value

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: [`Map`](#map); \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: [`Value`](#value)[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L160)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:180](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L180)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L181)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
