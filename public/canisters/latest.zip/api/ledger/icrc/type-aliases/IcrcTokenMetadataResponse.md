---
title: IcrcTokenMetadataResponse
editUrl: false
next: true
prev: true
---

> **IcrcTokenMetadataResponse** = \[`string` \| [`IcrcMetadataResponseEntries`](../enumerations/IcrcMetadataResponseEntries.md), [`Value`](../namespaces/IcrcLedgerDid/type-aliases/Value.md)\][]

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:13](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L13)
