---
title: IcrcTokenMetadataResponse
editUrl: false
next: true
prev: true
---

> **IcrcTokenMetadataResponse** = \[`string` \| [`IcrcMetadataResponseEntries`](../enumerations/IcrcMetadataResponseEntries.md), [`Value`](../namespaces/IcrcLedgerDid/type-aliases/Value.md)\][]

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L13)
