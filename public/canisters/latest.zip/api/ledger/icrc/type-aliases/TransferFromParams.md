---
title: TransferFromParams
editUrl: false
next: true
prev: true
---

> **TransferFromParams** = `Omit`\<[`TransferParams`](../interfaces/TransferParams.md), `"from_subaccount"`\> & `object`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:47](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L47)

Params for an icrc2_transfer_from.

## Type Declaration

### from

> **from**: [`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

### spender\_subaccount?

> `optional` **spender\_subaccount**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)

## Param

The account to transfer tokens to.

## Param

The account to transfer tokens from.

## Param

A spender subaccount.

## Param

The Amount of tokens to transfer.

## Param

Transfer memo.

## Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues

## Param

The fee of the transfer when it's not the default fee.
