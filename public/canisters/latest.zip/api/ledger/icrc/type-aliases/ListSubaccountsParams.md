---
title: ListSubaccountsParams
editUrl: false
next: true
prev: true
---

> **ListSubaccountsParams** = `object` & `Pick`\<[`IcrcAccount`](../interfaces/IcrcAccount.md), `"owner"`\> & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/index-ng.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/types/index-ng.params.ts#L11)

## Type Declaration

### start?

> `optional` **start**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)
