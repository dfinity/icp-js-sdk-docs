---
title: ListSubaccountsParams
editUrl: false
next: true
prev: true
---

> **ListSubaccountsParams** = `object` & `Pick`\<[`IcrcAccount`](../interfaces/IcrcAccount.md), `"owner"`\> & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/index-ng.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/types/index-ng.params.ts#L11)

## Type Declaration

### start?

> `optional` **start**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)
