---
title: GetBlocksParams
editUrl: false
next: true
prev: true
---

> **GetBlocksParams** = `QueryParams` & `object`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:125](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L125)

Parameters to get the canister blocks.

## Type Declaration

### args

> **args**: [`GetBlocksArgs`](../namespaces/IcrcLedgerDid/interfaces/GetBlocksArgs.md)[]
