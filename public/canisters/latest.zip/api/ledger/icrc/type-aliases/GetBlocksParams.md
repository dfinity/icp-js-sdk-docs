---
title: GetBlocksParams
editUrl: false
next: true
prev: true
---

> **GetBlocksParams** = `QueryParams` & `object`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:125](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L125)

Parameters to get the canister blocks.

## Type Declaration

### args

> **args**: [`GetBlocksArgs`](../namespaces/IcrcLedgerDid/interfaces/GetBlocksArgs.md)[]
