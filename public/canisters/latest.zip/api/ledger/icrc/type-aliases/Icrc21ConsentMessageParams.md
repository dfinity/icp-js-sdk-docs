---
title: Icrc21ConsentMessageParams
editUrl: false
next: true
prev: true
---

> **Icrc21ConsentMessageParams** = `Omit`\<[`icrc21_consent_message_request`](../namespaces/IcrcLedgerDid/interfaces/icrc21_consent_message_request.md), `"user_preferences"`\> & `object`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:115](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L115)

Parameters for the consent message request.

## Type Declaration

### userPreferences

> **userPreferences**: [`Icrc21ConsentMessageSpec`](../interfaces/Icrc21ConsentMessageSpec.md)

## Param

Method name of the canister call.

## Param

Argument of the canister call.

## Param

User preferences with regards to the consent message presented to the end-user.
