---
title: Icrc21ConsentMessageDeviceSpec
editUrl: false
next: true
prev: true
---

> **Icrc21ConsentMessageDeviceSpec** = \{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:91](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L91)

Device specification for displaying the consent message.

## Param

A generic display able to handle large documents and do line wrapping and pagination / scrolling.  Text must be Markdown formatted, no external resources (e.g. images) are allowed.

## Param

A simple display able to handle multiple fields with a title and content.
