---
title: BalanceParams
editUrl: false
next: true
prev: true
---

> **BalanceParams** = [`IcrcAccount`](../interfaces/IcrcAccount.md) & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:8](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L8)

Params to get the balance of an ICRC-1 account.
