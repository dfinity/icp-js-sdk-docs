---
title: BalanceParams
editUrl: false
next: true
prev: true
---

> **BalanceParams** = [`IcrcAccount`](../interfaces/IcrcAccount.md) & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:8](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L8)

Params to get the balance of an ICRC-1 account.
