---
title: IcrcIndexCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/index.canister.ts:21](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/index.canister.ts#L21)

## Extends

- `IcrcCanister`\<[`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new IcrcIndexCanister**(`id`, `service`, `certifiedService`): `IcrcIndexCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)

#### Returns

`IcrcIndexCanister`

#### Inherited from

`IcrcCanister<IcrcIndexService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)

#### Inherited from

`IcrcCanister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`IcrcCanister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`IcrcCanister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`IcrcCanister.canisterId`

## Methods

### balance()

> **balance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icrc/canister.ts:15](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/canister.ts#L15)

Returns the balance for a given account provided as owner and with optional subaccount.

#### Parameters

##### params

[`BalanceParams`](../type-aliases/BalanceParams.md)

The parameters to get the balance of an account.

#### Returns

`Promise`\<`bigint`\>

The balance of the given account.

#### Inherited from

`IcrcCanister.balance`

***

### getTransactions()

> **getTransactions**(`params`): `Promise`\<[`GetTransactions`](../namespaces/IcrcIndexDid/interfaces/GetTransactions.md)\>

Defined in: [packages/canisters/src/ledger/icrc/index.canister.ts:47](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/index.canister.ts#L47)

Get the transactions of an account.

#### Parameters

##### params

[`GetIndexAccountTransactionsParams`](../type-aliases/GetIndexAccountTransactionsParams.md)

The parameters to get the transactions of an account.

#### Returns

`Promise`\<[`GetTransactions`](../namespaces/IcrcIndexDid/interfaces/GetTransactions.md)\>

The list of transactions and further related information of the given account.

***

### ledgerId()

> **ledgerId**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/canisters/src/ledger/icrc/index.canister.ts:65](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/index.canister.ts#L65)

Returns the ledger canister ID related to the index canister.

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`Principal`\>

***

### listSubaccounts()

> **listSubaccounts**(`params`): `Promise`\<[`SubAccount`](../namespaces/IcrcIndexDid/type-aliases/SubAccount.md)[]\>

Defined in: [packages/canisters/src/ledger/icrc/index.canister.ts:85](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/index.canister.ts#L85)

Returns the list of subaccounts for a given owner.

#### Parameters

##### params

[`ListSubaccountsParams`](../type-aliases/ListSubaccountsParams.md)

The parameters to get the list of subaccounts.

#### Returns

`Promise`\<[`SubAccount`](../namespaces/IcrcIndexDid/type-aliases/SubAccount.md)[]\>

The list of subaccounts.

***

### status()

> **status**(`params`): `Promise`\<[`Status`](../namespaces/IcrcIndexDid/interfaces/Status.md)\>

Defined in: [packages/canisters/src/ledger/icrc/index.canister.ts:76](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/index.canister.ts#L76)

Returns the status of the index canister.

#### Parameters

##### params

`QueryParams`

The parameters to get the status of the index canister.

#### Returns

`Promise`\<[`Status`](../namespaces/IcrcIndexDid/interfaces/Status.md)\>

The status of the index canister.

***

### create()

> `static` **create**(`options`): `IcrcIndexCanister`

Defined in: [packages/canisters/src/ledger/icrc/index.canister.ts:22](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/index.canister.ts#L22)

#### Parameters

##### options

[`IcrcLedgerCanisterOptions`](../interfaces/IcrcLedgerCanisterOptions.md)\<[`_SERVICE`](../namespaces/IcrcIndexDid/interfaces/SERVICE.md)\>

#### Returns

`IcrcIndexCanister`
