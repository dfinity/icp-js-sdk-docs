---
title: IcrcNftLedgerCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/nft-ledger.canister.ts:10](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/nft-ledger.canister.ts#L10)

## Extends

- `Canister`\<[`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new IcrcNftLedgerCanister**(`id`, `service`, `certifiedService`): `IcrcNftLedgerCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)

#### Returns

`IcrcNftLedgerCanister`

#### Inherited from

`Canister<IcrcNftLedgerService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### collectionMetadata()

> **collectionMetadata**(`params`): `Promise`\<[`IcrcTokenMetadataResponse`](../type-aliases/IcrcTokenMetadataResponse.md)\>

Defined in: [packages/canisters/src/ledger/icrc/nft-ledger.canister.ts:30](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/nft-ledger.canister.ts#L30)

The collection metadata.

#### Parameters

##### params

`QueryParams`

The parameters to get the metadata of the collection.

#### Returns

`Promise`\<[`IcrcTokenMetadataResponse`](../type-aliases/IcrcTokenMetadataResponse.md)\>

The metadata as a list of metadata type and its value.

#### Link

https://github.com/dfinity/ICRC/blob/main/ICRCs/ICRC-7/ICRC-7.md#icrc7_collection_metadata

***

### create()

> `static` **create**(`options`): `IcrcNftLedgerCanister`

Defined in: [packages/canisters/src/ledger/icrc/nft-ledger.canister.ts:11](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/nft-ledger.canister.ts#L11)

#### Parameters

##### options

`IcrcLedgerCanisterOptions`\<[`_SERVICE`](../namespaces/IcrcNftLedgerDid/interfaces/SERVICE.md)\>

#### Returns

`IcrcNftLedgerCanister`
