---
title: IcrcLedgerCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L36)

## Extends

- `IcrcCanister`\<[`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new IcrcLedgerCanister**(`id`, `service`, `certifiedService`): `IcrcLedgerCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)

#### Returns

`IcrcLedgerCanister`

#### Inherited from

`IcrcCanister<IcrcLedgerService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)

#### Inherited from

`IcrcCanister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`IcrcCanister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`IcrcCanister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`IcrcCanister.canisterId`

## Methods

### allowance()

> **allowance**(`params`): `Promise`\<[`Allowance`](../namespaces/IcrcLedgerDid/interfaces/Allowance.md)\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:147](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L147)

Returns the token allowance that the `spender` account can transfer from the specified `account`, and the expiration time for that allowance, if any.

Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-2/index.md#icrc2_allowance

#### Parameters

##### params

[`AllowanceParams`](../type-aliases/AllowanceParams.md)

The parameters to call the allowance.

#### Returns

`Promise`\<[`Allowance`](../namespaces/IcrcLedgerDid/interfaces/Allowance.md)\>

The token allowance. If there is no active approval, the ledger MUST return `{ allowance = 0; expires_at = null }`.

***

### approve()

> **approve**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L123)

This method entitles the `spender` to transfer token `amount` on behalf of the caller from account `{ owner = caller; subaccount = from_subaccount }`.

Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-2/index.md#icrc2_approve

#### Parameters

##### params

[`ApproveParams`](../type-aliases/ApproveParams.md)

The parameters to approve.

#### Returns

`Promise`\<`bigint`\>

#### Throws

If the approval fails.

***

### balance()

> **balance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icrc/canister.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/canister.ts#L15)

Returns the balance for a given account provided as owner and with optional subaccount.

#### Parameters

##### params

[`BalanceParams`](../type-aliases/BalanceParams.md)

The parameters to get the balance of an account.

#### Returns

`Promise`\<`bigint`\>

The balance of the given account.

#### Inherited from

`IcrcCanister.balance`

***

### consentMessage()

> **consentMessage**(`params`): `Promise`\<[`icrc21_consent_info`](../namespaces/IcrcLedgerDid/interfaces/icrc21_consent_info.md)\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:165](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L165)

Fetches the consent message for a specified canister call, intended to provide a human-readable message that helps users make informed decisions.

@link: https://github.com/dfinity/wg-identity-authentication/blob/main/topics/ICRC-21/icrc_21_consent_msg.md

#### Parameters

##### params

[`Icrc21ConsentMessageParams`](../type-aliases/Icrc21ConsentMessageParams.md)

The request parameters containing the method name, arguments, and consent preferences (e.g., language).

#### Returns

`Promise`\<[`icrc21_consent_info`](../namespaces/IcrcLedgerDid/interfaces/icrc21_consent_info.md)\>

- A promise that resolves to the consent message response, which includes the consent message in the specified language and other related information.

#### Throws

- This error is reserved for future use, in case payment extensions are introduced. For example, if consent messages, which are currently free, begin to require payments.

#### Throws

- If the specified canister call is not supported.

#### Throws

- If there is no consent message available.

#### Throws

- For any other generic errors.

***

### getBlocks()

> **getBlocks**(`params`): `Promise`\<[`GetBlocksResult`](../namespaces/IcrcLedgerDid/interfaces/GetBlocksResult.md)\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:189](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L189)

Fetches the blocks information from the ledger canister,

#### Parameters

##### params

[`GetBlocksParams`](../type-aliases/GetBlocksParams.md)

The parameters to get the blocks.

#### Returns

`Promise`\<[`GetBlocksResult`](../namespaces/IcrcLedgerDid/interfaces/GetBlocksResult.md)\>

The list of blocks.

***

### getIndexPrincipal()

> **getIndexPrincipal**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L204)

Returns the principal of the index canister for the ledger, if one was defined as such.

@link: https://github.com/dfinity/ICRC/blob/main/ICRCs/ICRC-106/ICRC-106.md

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`Principal`\>

The principal of the index canister.

#### Throws

- For any errors that occur while fetching the index principal.

#### Throws

- If the index principal was not set for the ledger canister.

***

### getMintingAccount()

> **getMintingAccount**(`params`): `Promise`\<`Nullable`\<[`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)\>\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:247](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L247)

Returns the minting account of the Ledger canister.

@link: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/index.md#icrc1_minting_account

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`Nullable`\<[`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)\>\>

The minting account as a Nullable object.

***

### icrc10SupportedStandards()

> **icrc10SupportedStandards**(`params`): `Promise`\<`object`[]\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:235](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L235)

Returns the list of standards this ledger supports by using icrc10_supported_standards.

@link: https://github.com/dfinity/ICRC/blob/main/ICRCs/ICRC-10/ICRC-10.md#icrc10_supported_standards

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`object`[]\>

The list of standards.

***

### icrc1SupportedStandards()

> **icrc1SupportedStandards**(`params`): `Promise`\<[`StandardRecord`](../namespaces/IcrcLedgerDid/interfaces/StandardRecord.md)[]\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:223](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L223)

Returns the list of standards this ledger supports by using icrc1_supported_standards.

@link: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/index.md#icrc1_supported_standards

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`StandardRecord`](../namespaces/IcrcLedgerDid/interfaces/StandardRecord.md)[]\>

The list of standards.

***

### metadata()

> **metadata**(`params`): `Promise`\<[`IcrcTokenMetadataResponse`](../type-aliases/IcrcTokenMetadataResponse.md)\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L51)

The token metadata (name, symbol, etc.).

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<[`IcrcTokenMetadataResponse`](../type-aliases/IcrcTokenMetadataResponse.md)\>

***

### totalTokensSupply()

> **totalTokensSupply**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L87)

Returns the total supply of tokens.

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`bigint`\>

***

### transactionFee()

> **transactionFee**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L59)

The ledger transaction fees.

#### Parameters

##### params

`QueryParams`

#### Returns

`Promise`\<`bigint`\>

The ledger transaction fees in Tokens

***

### transfer()

> **transfer**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L69)

Transfers tokens from the sender to the given account.

#### Parameters

##### params

[`TransferParams`](../interfaces/TransferParams.md)

The parameters to transfer tokens.

#### Returns

`Promise`\<`bigint`\>

#### Throws

If the transfer fails.

***

### transferFrom()

> **transferFrom**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:99](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L99)

Transfers a token amount from the `from` account to the `to` account using the allowance of the spender's account (`SpenderAccount = { owner = caller; subaccount = spender_subaccount }`). The ledger draws the fees from the `from` account.

Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-2/index.md#icrc2_transfer_from

#### Parameters

##### params

[`TransferFromParams`](../type-aliases/TransferFromParams.md)

The parameters to transfer tokens from to.

#### Returns

`Promise`\<`bigint`\>

#### Throws

If the transfer from fails.

***

### create()

> `static` **create**(`options`): `IcrcLedgerCanister`

Defined in: [packages/canisters/src/ledger/icrc/ledger.canister.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/ledger.canister.ts#L37)

#### Parameters

##### options

`IcrcLedgerCanisterOptions`\<[`_SERVICE`](../namespaces/IcrcLedgerDid/interfaces/SERVICE.md)\>

#### Returns

`IcrcLedgerCanister`
