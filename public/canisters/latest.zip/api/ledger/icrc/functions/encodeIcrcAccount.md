---
title: encodeIcrcAccount
editUrl: false
next: true
prev: true
---

> **encodeIcrcAccount**(`account`): `string`

Defined in: [packages/canisters/src/ledger/icrc/utils/ledger.utils.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/utils/ledger.utils.ts#L27)

Encodes an Icrc-1 account compatible into a string.
Formatting Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/TextualEncoding.md

## Parameters

### account

[`IcrcAccount`](../interfaces/IcrcAccount.md)

{ owner: Principal, subaccount?: Uint8Array }

## Returns

`string`

string
