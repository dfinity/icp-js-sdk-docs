---
title: toApproveArgs
editUrl: false
next: true
prev: true
---

> **toApproveArgs**(`__namedParameters`): [`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:43](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L43)

## Parameters

### \_\_namedParameters

[`ApproveParams`](../type-aliases/ApproveParams.md)

## Returns

[`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)
