---
title: toApproveArgs
editUrl: false
next: true
prev: true
---

> **toApproveArgs**(`__namedParameters`): [`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L43)

## Parameters

### \_\_namedParameters

[`ApproveParams`](../type-aliases/ApproveParams.md)

## Returns

[`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)
