---
title: mapTokenMetadata
editUrl: false
next: true
prev: true
---

> **mapTokenMetadata**(`response`): [`IcrcTokenMetadata`](../interfaces/IcrcTokenMetadata.md) \| `undefined`

Defined in: [packages/canisters/src/ledger/icrc/utils/ledger.utils.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/utils/ledger.utils.ts#L118)

Maps the token metadata information from a ledger response into a structured record.

This utility processes an array of metadata key-value pairs provided by the ledger
and extracts specific fields, such as symbol, name, fee, decimals, and logo. It then
constructs a `IcrcTokenMetadata` record. If any required fields are missing,
the function returns `undefined`.

## Parameters

### response

[`IcrcTokenMetadataResponse`](../type-aliases/IcrcTokenMetadataResponse.md)

An array of key-value pairs representing token metadata.

## Returns

[`IcrcTokenMetadata`](../interfaces/IcrcTokenMetadata.md) \| `undefined`

- A structured metadata record or `undefined` if required fields are missing.
