---
title: toCandidAccount
editUrl: false
next: true
prev: true
---

> **toCandidAccount**(`-`): [`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/converters/converters.ts#L29)

Converts an IcrcAccount to a Candid Account object, effectively transforming nullish properties into nullable ones.

## Parameters

### -

[`IcrcAccount`](../interfaces/IcrcAccount.md)

The IcrcAccount object to convert.

## Returns

[`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

- The converted Candid Account object.
