---
title: toCandidAccount
editUrl: false
next: true
prev: true
---

> **toCandidAccount**(`-`): [`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/converters/converters.ts#L29)

Converts an IcrcAccount to a Candid Account object, effectively transforming nullish properties into nullable ones.

## Parameters

### -

[`IcrcAccount`](../interfaces/IcrcAccount.md)

The IcrcAccount object to convert.

## Returns

[`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

- The converted Candid Account object.
