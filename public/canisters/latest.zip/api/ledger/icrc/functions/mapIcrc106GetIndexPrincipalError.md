---
title: mapIcrc106GetIndexPrincipalError
editUrl: false
next: true
prev: true
---

> **mapIcrc106GetIndexPrincipalError**(`err`): [`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)

Defined in: [packages/canisters/src/ledger/icrc/errors/ledger.errors.ts:61](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/errors/ledger.errors.ts#L61)

## Parameters

### err

[`GetIndexPrincipalError`](../namespaces/IcrcLedgerDid/type-aliases/GetIndexPrincipalError.md)

## Returns

[`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)
