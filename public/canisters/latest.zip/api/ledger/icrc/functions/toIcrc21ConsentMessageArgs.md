---
title: toIcrc21ConsentMessageArgs
editUrl: false
next: true
prev: true
---

> **toIcrc21ConsentMessageArgs**(`__namedParameters`): [`icrc21_consent_message_request`](../namespaces/IcrcLedgerDid/interfaces/icrc21_consent_message_request.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:61](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L61)

## Parameters

### \_\_namedParameters

[`Icrc21ConsentMessageParams`](../type-aliases/Icrc21ConsentMessageParams.md)

## Returns

[`icrc21_consent_message_request`](../namespaces/IcrcLedgerDid/interfaces/icrc21_consent_message_request.md)
