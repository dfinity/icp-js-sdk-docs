---
title: mapIcrc21ConsentMessageError
editUrl: false
next: true
prev: true
---

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](../classes/ConsentMessageError.md)

Defined in: [packages/canisters/src/ledger/icrc/errors/ledger.errors.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/errors/ledger.errors.ts#L26)

## Parameters

### rawError

[`icrc21_error`](../namespaces/IcrcLedgerDid/type-aliases/icrc21_error.md)

## Returns

[`ConsentMessageError`](../classes/ConsentMessageError.md)
