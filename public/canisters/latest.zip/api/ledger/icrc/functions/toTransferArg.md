---
title: toTransferArg
editUrl: false
next: true
prev: true
---

> **toTransferArg**(`__namedParameters`): [`TransferArg`](../namespaces/IcrcLedgerDid/interfaces/TransferArg.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:15](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L15)

## Parameters

### \_\_namedParameters

[`TransferParams`](../interfaces/TransferParams.md)

## Returns

[`TransferArg`](../namespaces/IcrcLedgerDid/interfaces/TransferArg.md)
