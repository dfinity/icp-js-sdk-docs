---
title: fromCandidAccount
editUrl: false
next: true
prev: true
---

> **fromCandidAccount**(`-`): [`IcrcAccount`](../interfaces/IcrcAccount.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/converters.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/converters/converters.ts#L11)

Converts a Candid Account object to an IcrcAccount, effectively transforming nullable properties into nullish ones.

## Parameters

### -

[`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

The Candid Account object to convert.

## Returns

[`IcrcAccount`](../interfaces/IcrcAccount.md)

- The converted IcrcAccount object.
