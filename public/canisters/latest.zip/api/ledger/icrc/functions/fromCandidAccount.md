---
title: fromCandidAccount
editUrl: false
next: true
prev: true
---

> **fromCandidAccount**(`-`): [`IcrcAccount`](../interfaces/IcrcAccount.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/converters.ts:11](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/converters/converters.ts#L11)

Converts a Candid Account object to an IcrcAccount, effectively transforming nullable properties into nullish ones.

## Parameters

### -

[`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

The Candid Account object to convert.

## Returns

[`IcrcAccount`](../interfaces/IcrcAccount.md)

- The converted IcrcAccount object.
