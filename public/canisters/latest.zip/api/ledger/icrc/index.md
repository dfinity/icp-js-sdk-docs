---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [IcrcIndexDid](namespaces/IcrcIndexDid/index.md)
- [IcrcLedgerDid](namespaces/IcrcLedgerDid/index.md)
- [IcrcNftLedgerDid](namespaces/IcrcNftLedgerDid/index.md)

## Enumerations

- [IcrcMetadataResponseEntries](enumerations/IcrcMetadataResponseEntries.md)

## Classes

- [ConsentMessageError](classes/ConsentMessageError.md)
- [ConsentMessageUnavailableError](classes/ConsentMessageUnavailableError.md)
- [GenericError](classes/GenericError.md)
- [IcrcIndexCanister](classes/IcrcIndexCanister.md)
- [IcrcLedgerCanister](classes/IcrcLedgerCanister.md)
- [IcrcNftLedgerCanister](classes/IcrcNftLedgerCanister.md)
- [IcrcTransferError](classes/IcrcTransferError.md)
- [IndexError](classes/IndexError.md)
- [IndexPrincipalNotSetError](classes/IndexPrincipalNotSetError.md)
- [InsufficientPaymentError](classes/InsufficientPaymentError.md)
- [UnsupportedCanisterCallError](classes/UnsupportedCanisterCallError.md)

## Interfaces

- [Icrc21ConsentMessageMetadata](interfaces/Icrc21ConsentMessageMetadata.md)
- [Icrc21ConsentMessageSpec](interfaces/Icrc21ConsentMessageSpec.md)
- [IcrcAccount](interfaces/IcrcAccount.md)
- [IcrcLedgerCanisterOptions](interfaces/IcrcLedgerCanisterOptions.md)
- [IcrcTokenMetadata](interfaces/IcrcTokenMetadata.md)
- [TransferParams](interfaces/TransferParams.md)

## Type Aliases

- [AllowanceParams](type-aliases/AllowanceParams.md)
- [ApproveParams](type-aliases/ApproveParams.md)
- [BalanceParams](type-aliases/BalanceParams.md)
- [GetBlocksParams](type-aliases/GetBlocksParams.md)
- [GetIndexAccountTransactionsParams](type-aliases/GetIndexAccountTransactionsParams.md)
- [Icrc21ConsentMessageDeviceSpec](type-aliases/Icrc21ConsentMessageDeviceSpec.md)
- [Icrc21ConsentMessageParams](type-aliases/Icrc21ConsentMessageParams.md)
- [IcrcTokenMetadataResponse](type-aliases/IcrcTokenMetadataResponse.md)
- [ListSubaccountsParams](type-aliases/ListSubaccountsParams.md)
- [TransferFromParams](type-aliases/TransferFromParams.md)

## Functions

- [decodeIcrcAccount](functions/decodeIcrcAccount.md)
- [decodePayment](functions/decodePayment.md)
- [encodeIcrcAccount](functions/encodeIcrcAccount.md)
- [fromCandidAccount](functions/fromCandidAccount.md)
- [mapIcrc106GetIndexPrincipalError](functions/mapIcrc106GetIndexPrincipalError.md)
- [mapIcrc21ConsentMessageError](functions/mapIcrc21ConsentMessageError.md)
- [mapTokenMetadata](functions/mapTokenMetadata.md)
- [toApproveArgs](functions/toApproveArgs.md)
- [toCandidAccount](functions/toCandidAccount.md)
- [toIcrc21ConsentMessageArgs](functions/toIcrc21ConsentMessageArgs.md)
- [toTransferArg](functions/toTransferArg.md)
- [toTransferFromArgs](functions/toTransferFromArgs.md)
