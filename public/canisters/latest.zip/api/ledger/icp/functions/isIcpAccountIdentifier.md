---
title: isIcpAccountIdentifier
editUrl: false
next: true
prev: true
---

> **isIcpAccountIdentifier**(`address`): `boolean`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L41)

Checks if a given string (or undefined) is a valid ICP account identifier.

It uses the `checkAccountId` function to validate the checksum, but it does not throw an error.

## Parameters

### address

The putative ICP account identifier.

`string` | `undefined`

## Returns

`boolean`
