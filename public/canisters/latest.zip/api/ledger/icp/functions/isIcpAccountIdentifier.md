---
title: isIcpAccountIdentifier
editUrl: false
next: true
prev: true
---

> **isIcpAccountIdentifier**(`address`): `boolean`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:41](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L41)

Checks if a given string (or undefined) is a valid ICP account identifier.

It uses the `checkAccountId` function to validate the checksum, but it does not throw an error.

## Parameters

### address

The putative ICP account identifier.

`string` | `undefined`

## Returns

`boolean`
