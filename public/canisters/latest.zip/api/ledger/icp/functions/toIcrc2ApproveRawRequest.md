---
title: toIcrc2ApproveRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc2ApproveRawRequest**(`__namedParameters`): [`ApproveArgs`](../namespaces/IcpLedgerDid/interfaces/ApproveArgs.md)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:59](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L59)

## Parameters

### \_\_namedParameters

[`Icrc2ApproveRequest`](../type-aliases/Icrc2ApproveRequest.md)

## Returns

[`ApproveArgs`](../namespaces/IcpLedgerDid/interfaces/ApproveArgs.md)
