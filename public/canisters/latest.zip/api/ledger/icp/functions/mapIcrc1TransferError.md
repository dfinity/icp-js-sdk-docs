---
title: mapIcrc1TransferError
editUrl: false
next: true
prev: true
---

> **mapIcrc1TransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:104](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L104)

## Parameters

### rawTransferError

[`Icrc1TransferError`](../namespaces/IcpLedgerDid/type-aliases/Icrc1TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
