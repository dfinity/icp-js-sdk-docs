---
title: mapTransferError
editUrl: false
next: true
prev: true
---

> **mapTransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:76](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L76)

## Parameters

### rawTransferError

[`TransferError`](../namespaces/IcpLedgerDid/type-aliases/TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
