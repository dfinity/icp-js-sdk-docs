---
title: mapTransferError
editUrl: false
next: true
prev: true
---

> **mapTransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:76](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L76)

## Parameters

### rawTransferError

[`TransferError`](../namespaces/IcpLedgerDid/type-aliases/TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
