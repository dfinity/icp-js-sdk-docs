---
title: mapTransferError
editUrl: false
next: true
prev: true
---

> **mapTransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L76)

## Parameters

### rawTransferError

[`TransferError`](../namespaces/IcpLedgerDid/type-aliases/TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
