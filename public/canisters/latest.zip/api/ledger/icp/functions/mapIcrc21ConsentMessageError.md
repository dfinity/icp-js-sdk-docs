---
title: mapIcrc21ConsentMessageError
editUrl: false
next: true
prev: true
---

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](../classes/ConsentMessageError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:187](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L187)

## Parameters

### rawError

[`icrc21_error`](../namespaces/IcpLedgerDid/type-aliases/icrc21_error.md)

## Returns

[`ConsentMessageError`](../classes/ConsentMessageError.md)
