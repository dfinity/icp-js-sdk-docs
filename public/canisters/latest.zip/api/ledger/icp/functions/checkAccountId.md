---
title: checkAccountId
editUrl: false
next: true
prev: true
---

> **checkAccountId**(`accountId`): `void`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L15)

Checks account id check sum

## Parameters

### accountId

`string`

## Returns

`void`

## Throws

InvalidAccountIDError
