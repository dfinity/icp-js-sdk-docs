---
title: mapIcrc2ApproveError
editUrl: false
next: true
prev: true
---

> **mapIcrc2ApproveError**(`rawApproveError`): [`ApproveError`](../classes/ApproveError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:130](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L130)

## Parameters

### rawApproveError

[`ApproveError`](../namespaces/IcpLedgerDid/type-aliases/ApproveError.md)

## Returns

[`ApproveError`](../classes/ApproveError.md)
