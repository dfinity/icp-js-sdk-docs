---
title: Icrc2ApproveRequest
editUrl: false
next: true
prev: true
---

> **Icrc2ApproveRequest** = `Omit`\<[`Icrc1TransferRequest`](../interfaces/Icrc1TransferRequest.md), `"to"`\> & `object`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:47](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L47)

Params for an icrc2_approve.

## Type Declaration

### expected\_allowance?

> `optional` **expected\_allowance**: [`Icrc1Tokens`](../namespaces/IcpLedgerDid/type-aliases/Icrc1Tokens.md)

### expires\_at?

> `optional` **expires\_at**: [`Icrc1Timestamp`](../namespaces/IcpLedgerDid/type-aliases/Icrc1Timestamp.md)

### spender

> **spender**: [`Account`](../namespaces/IcpLedgerDid/interfaces/Account.md)

## Param

The account of the spender.

## Param

The amount of tokens to approve.

## Param

The subaccount to transfer tokens from.

## Param

Approve memo.

## Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues

## Param

The fee of the transfer when it's not the default fee.

## Param

The optional allowance expected. If the expected_allowance field is set, the ledger MUST ensure that the current allowance for the spender from the caller's account is equal to the given value and return the AllowanceChanged error otherwise.

## Param

When the approval expires. If the field is set, it's greater than the current ledger time.
