---
title: AccountIdentifierHex
editUrl: false
next: true
prev: true
---

> **AccountIdentifierHex** = `string`

Defined in: [packages/canisters/src/ledger/icp/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icp/types/common.ts#L1)
