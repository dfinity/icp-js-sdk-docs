---
title: AccountIdentifierHex
editUrl: false
next: true
prev: true
---

> **AccountIdentifierHex** = `string`

Defined in: [packages/canisters/src/ledger/icp/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icp/types/common.ts#L1)
