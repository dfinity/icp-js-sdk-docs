---
title: IcpLedgerCanisterOptions
editUrl: false
next: true
prev: true
---

> **IcpLedgerCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)\>

Defined in: [packages/canisters/src/ledger/icp/types/ledger.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icp/types/ledger.options.ts#L4)
