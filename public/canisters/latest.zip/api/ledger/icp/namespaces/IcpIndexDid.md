---
title: IcpIndexDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L131)

#### Properties

##### get\_account\_identifier\_balance

> **get\_account\_identifier\_balance**: `ActorMethod`\<\[`string`\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L132)

##### get\_account\_identifier\_transactions

> **get\_account\_identifier\_transactions**: `ActorMethod`\<\[[`GetAccountIdentifierTransactionsArgs`](#getaccountidentifiertransactionsargs)\], [`GetAccountIdentifierTransactionsResult`](#getaccountidentifiertransactionsresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L133)

##### get\_account\_transactions

> **get\_account\_transactions**: `ActorMethod`\<\[[`GetAccountTransactionsArgs`](#getaccounttransactionsargs)\], [`GetAccountIdentifierTransactionsResult`](#getaccountidentifiertransactionsresult)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L137)

##### get\_blocks

> **get\_blocks**: `ActorMethod`\<\[[`GetBlocksRequest`](#getblocksrequest)\], [`GetBlocksResponse`](#getblocksresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L141)

##### http\_request

> **http\_request**: `ActorMethod`\<\[[`HttpRequest`](#httprequest)\], [`HttpResponse`](#httpresponse)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L142)

##### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](#account)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L143)

##### ledger\_id

> **ledger\_id**: `ActorMethod`\<\[\], `Principal`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L144)

##### status

> **status**: `ActorMethod`\<\[\], [`Status`](#status-1)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L145)

***

### Account

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L13)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L14)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L15)

***

### GetAccountIdentifierTransactionsArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L17)

#### Properties

##### account\_identifier

> **account\_identifier**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L20)

##### max\_results

> **max\_results**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L18)

##### start

> **start**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L19)

***

### GetAccountIdentifierTransactionsError

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L22)

#### Properties

##### message

> **message**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L23)

***

### GetAccountIdentifierTransactionsResponse

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L25)

#### Properties

##### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L26)

##### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L28)

##### transactions

> **transactions**: [`TransactionWithId`](#transactionwithid)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L27)

***

### GetAccountTransactionsArgs

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L35)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L47)

##### max\_results

> **max\_results**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L39)

Maximum number of transactions to fetch.

##### start

> **start**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L46)

The txid of the last transaction seen by the client.
If None then the results will start from the most recent
txid. If set then the results will start from the next
most recent txid after start (start won't be included).

***

### GetBlocksRequest

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L49)

#### Properties

##### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L51)

##### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L50)

***

### GetBlocksResponse

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L53)

#### Properties

##### blocks

> **blocks**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L54)

##### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L55)

***

### HttpRequest

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L57)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L60)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L61)

##### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L59)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L58)

***

### HttpResponse

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L63)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L64)

##### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L65)

##### status\_code

> **status\_code**: `number`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L66)

***

### InitArg

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L69)

#### Properties

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L70)

##### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L76)

The interval in seconds in which to retrieve blocks from the ledger. A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.

***

### Status

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L102)

#### Properties

##### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L103)

***

### TimeStamp

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L105)

#### Properties

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L106)

***

### Tokens

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L108)

#### Properties

##### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L109)

***

### Transaction

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L111)

#### Properties

##### created\_at\_time

> **created\_at\_time**: \[\] \| \[[`TimeStamp`](#timestamp)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L116)

##### icrc1\_memo

> **icrc1\_memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L113)

##### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L112)

##### operation

> **operation**: [`Operation`](#operation-1)

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L114)

##### timestamp

> **timestamp**: \[\] \| \[[`TimeStamp`](#timestamp)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L115)

***

### TransactionWithId

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L118)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L119)

##### transaction

> **transaction**: [`Transaction`](#transaction)

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L120)

***

### UpgradeArg

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L122)

#### Properties

##### ledger\_id

> **ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L123)

##### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L129)

The interval in seconds in which to retrieve blocks from the ledger. A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.

## Type Aliases

### GetAccountIdentifierTransactionsResult

> **GetAccountIdentifierTransactionsResult** = \{ `Ok`: [`GetAccountIdentifierTransactionsResponse`](#getaccountidentifiertransactionsresponse); \} \| \{ `Err`: [`GetAccountIdentifierTransactionsError`](#getaccountidentifiertransactionserror); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L30)

***

### IndexArg

> **IndexArg** = \{ `Upgrade`: [`UpgradeArg`](#upgradearg); \} \| \{ `Init`: [`InitArg`](#initarg); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L68)

***

### Operation

> **Operation** = \{ `Approve`: \{ `allowance`: [`Tokens`](#tokens); `expected_allowance`: \[\] \| \[[`Tokens`](#tokens)\]; `expires_at`: \[\] \| \[[`TimeStamp`](#timestamp)\]; `fee`: [`Tokens`](#tokens); `from`: `string`; `spender`: `string`; \}; \} \| \{ `Burn`: \{ `amount`: [`Tokens`](#tokens); `from`: `string`; `spender`: \[\] \| \[`string`\]; \}; \} \| \{ `Mint`: \{ `amount`: [`Tokens`](#tokens); `to`: `string`; \}; \} \| \{ `Transfer`: \{ `amount`: [`Tokens`](#tokens); `fee`: [`Tokens`](#tokens); `from`: `string`; `spender`: \[\] \| \[`string`\]; `to`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L78)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L147)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ledger-icp/index.d.ts#L148)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
