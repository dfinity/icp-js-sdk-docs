---
title: RemoveApprovalArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L343)

## Properties

### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L344)

***

### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](../type-aliases/SubAccount.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L345)

***

### spender

> **spender**: [`AccountIdentifier`](../type-aliases/AccountIdentifier.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L346)
