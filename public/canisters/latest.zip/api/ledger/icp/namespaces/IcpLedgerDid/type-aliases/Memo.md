---
title: Memo
editUrl: false
next: true
prev: true
---

> **Memo** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L221)

An arbitrary number associated with a transaction.
The caller can set it in a `transfer` call as a correlation identifier.
