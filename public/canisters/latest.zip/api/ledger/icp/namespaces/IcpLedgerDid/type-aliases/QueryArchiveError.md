---
title: QueryArchiveError
editUrl: false
next: true
prev: true
---

> **QueryArchiveError** = \{ `BadFirstBlockIndex`: \{ `first_valid_index`: [`BlockIndex`](BlockIndex.md); `requested_index`: [`BlockIndex`](BlockIndex.md); \}; \} \| \{ `Other`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:257](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L257)

An error indicating that the arguments passed to [QueryArchiveFn] were invalid.

## Type Declaration

\{ `BadFirstBlockIndex`: \{ `first_valid_index`: [`BlockIndex`](BlockIndex.md); `requested_index`: [`BlockIndex`](BlockIndex.md); \}; \}

### BadFirstBlockIndex

> **BadFirstBlockIndex**: `object`

[GetBlocksArgs.from] argument was smaller than the first block
served by the canister that received the request.

#### BadFirstBlockIndex.first\_valid\_index

> **first\_valid\_index**: [`BlockIndex`](BlockIndex.md)

#### BadFirstBlockIndex.requested\_index

> **requested\_index**: [`BlockIndex`](BlockIndex.md)

\{ `Other`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

### Other

> **Other**: `object`

Reserved for future use.

#### Other.error\_code

> **error\_code**: `bigint`

#### Other.error\_message

> **error\_message**: `string`
