---
title: ArchivedBlocksRange
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L84)

## Properties

### callback

> **callback**: \[`Principal`, `string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L90)

The function that should be called to fetch the archived blocks.
The range of the blocks accessible using this function is given by [from]
and [len] fields above.

***

### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L98)

The number of blocks that can be fetch using the callback.

***

### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L94)

The index of the first archived block that can be fetched using the callback.
