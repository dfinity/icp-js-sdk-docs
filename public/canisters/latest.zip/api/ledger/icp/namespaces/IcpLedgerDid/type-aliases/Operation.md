---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `Approve`: \{ `allowance`: [`Tokens`](../interfaces/Tokens.md); `allowance_e8s`: `bigint`; `expected_allowance`: \[\] \| \[[`Tokens`](../interfaces/Tokens.md)\]; `expires_at`: \[\] \| \[[`TimeStamp`](../interfaces/TimeStamp.md)\]; `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: [`AccountIdentifier`](AccountIdentifier.md); `spender`: [`AccountIdentifier`](AccountIdentifier.md); \}; \} \| \{ `Burn`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `from`: [`AccountIdentifier`](AccountIdentifier.md); `spender`: \[\] \| \[[`AccountIdentifier`](AccountIdentifier.md)\]; \}; \} \| \{ `Mint`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `to`: [`AccountIdentifier`](AccountIdentifier.md); \}; \} \| \{ `Transfer`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: [`AccountIdentifier`](AccountIdentifier.md); `spender`: \[\] \| \[`Uint8Array`\]; `to`: [`AccountIdentifier`](AccountIdentifier.md); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L222)
