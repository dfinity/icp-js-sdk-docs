---
title: TransferError
editUrl: false
next: true
prev: true
---

> **TransferError** = \{ `TxTooOld`: \{ `allowed_window_nanos`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Tokens`](../interfaces/Tokens.md); \}; \} \| \{ `TxDuplicate`: \{ `duplicate_of`: [`BlockIndex`](BlockIndex.md); \}; \} \| \{ `TxCreatedInFuture`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Tokens`](../interfaces/Tokens.md); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L434)

## Type Declaration

\{ `TxTooOld`: \{ `allowed_window_nanos`: `bigint`; \}; \}

### TxTooOld

> **TxTooOld**: `object`

The request is too old.
The ledger only accepts requests created within 24 hours window.
This is a non-recoverable error.

#### TxTooOld.allowed\_window\_nanos

> **allowed\_window\_nanos**: `bigint`

\{ `BadFee`: \{ `expected_fee`: [`Tokens`](../interfaces/Tokens.md); \}; \}

### BadFee

> **BadFee**: `object`

The fee that the caller specified in the transfer request was not the one that ledger expects.
The caller can change the transfer fee to the `expected_fee` and retry the request.

#### BadFee.expected\_fee

> **expected\_fee**: [`Tokens`](../interfaces/Tokens.md)

\{ `TxDuplicate`: \{ `duplicate_of`: [`BlockIndex`](BlockIndex.md); \}; \}

### TxDuplicate

> **TxDuplicate**: `object`

The ledger has already executed the request.
`duplicate_of` field is equal to the index of the block containing the original transaction.

#### TxDuplicate.duplicate\_of

> **duplicate\_of**: [`BlockIndex`](BlockIndex.md)

\{ `TxCreatedInFuture`: `null`; \}

### TxCreatedInFuture

> **TxCreatedInFuture**: `null`

The caller specified `created_at_time` that is too far in future.
The caller can retry the request later.

\{ `InsufficientFunds`: \{ `balance`: [`Tokens`](../interfaces/Tokens.md); \}; \}

### InsufficientFunds

> **InsufficientFunds**: `object`

The account specified by the caller doesn't have enough funds.

#### InsufficientFunds.balance

> **balance**: [`Tokens`](../interfaces/Tokens.md)
