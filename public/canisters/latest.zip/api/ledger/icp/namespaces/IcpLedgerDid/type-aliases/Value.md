---
title: Value
editUrl: false
next: true
prev: true
---

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L509)

The value returned from the [icrc1_metadata] endpoint.
