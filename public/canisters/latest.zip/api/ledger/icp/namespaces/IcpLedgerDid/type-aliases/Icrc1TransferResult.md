---
title: Icrc1TransferResult
editUrl: false
next: true
prev: true
---

> **Icrc1TransferResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`Icrc1TransferError`](Icrc1TransferError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L187)
