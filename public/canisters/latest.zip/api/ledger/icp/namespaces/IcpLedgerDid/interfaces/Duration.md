---
title: Duration
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L138)

## Properties

### nanos

> **nanos**: `number`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L140)

***

### secs

> **secs**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L139)
