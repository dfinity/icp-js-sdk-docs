---
title: Transaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L385)

## Properties

### created\_at\_time

> **created\_at\_time**: [`TimeStamp`](TimeStamp.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L389)

***

### icrc1\_memo

> **icrc1\_memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L387)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L386)

***

### operation

> **operation**: \[\] \| \[[`Operation`](../type-aliases/Operation.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L388)
