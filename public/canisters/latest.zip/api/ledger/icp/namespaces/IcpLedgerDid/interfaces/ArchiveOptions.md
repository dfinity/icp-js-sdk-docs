---
title: ArchiveOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L74)

## Properties

### controller\_id

> **controller\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L82)

***

### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L80)

***

### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L79)

***

### max\_transactions\_per\_response

> **max\_transactions\_per\_response**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L76)

***

### more\_controller\_ids

> **more\_controller\_ids**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L78)

***

### node\_max\_memory\_size\_bytes

> **node\_max\_memory\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L81)

***

### num\_blocks\_to\_archive

> **num\_blocks\_to\_archive**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L75)

***

### trigger\_threshold

> **trigger\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L77)
