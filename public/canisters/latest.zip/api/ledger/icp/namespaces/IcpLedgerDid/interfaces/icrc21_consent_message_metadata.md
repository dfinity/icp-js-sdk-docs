---
title: icrc21_consent_message_metadata
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L523)

## Properties

### language

> **language**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L525)

***

### utc\_offset\_minutes

> **utc\_offset\_minutes**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L524)
