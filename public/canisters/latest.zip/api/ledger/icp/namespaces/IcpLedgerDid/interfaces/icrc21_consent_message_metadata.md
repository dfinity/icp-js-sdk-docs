---
title: icrc21_consent_message_metadata
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L523)

## Properties

### language

> **language**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L525)

***

### utc\_offset\_minutes

> **utc\_offset\_minutes**: \[\] \| \[`number`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L524)
