---
title: TipOfChainRes
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L375)

## Properties

### certification

> **certification**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L376)

***

### tip\_index

> **tip\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L377)
