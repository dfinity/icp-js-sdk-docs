---
title: TipOfChainRes
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L375)

## Properties

### certification

> **certification**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L376)

***

### tip\_index

> **tip\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L377)
