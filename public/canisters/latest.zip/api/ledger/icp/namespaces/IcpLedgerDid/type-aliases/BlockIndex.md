---
title: BlockIndex
editUrl: false
next: true
prev: true
---

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L116)

Sequence number of a block produced by the ledger.
