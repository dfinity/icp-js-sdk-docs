---
title: BlockIndex
editUrl: false
next: true
prev: true
---

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L116)

Sequence number of a block produced by the ledger.
