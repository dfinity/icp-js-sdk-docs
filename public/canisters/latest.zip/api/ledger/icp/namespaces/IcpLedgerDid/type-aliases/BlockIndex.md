---
title: BlockIndex
editUrl: false
next: true
prev: true
---

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L116)

Sequence number of a block produced by the ledger.
