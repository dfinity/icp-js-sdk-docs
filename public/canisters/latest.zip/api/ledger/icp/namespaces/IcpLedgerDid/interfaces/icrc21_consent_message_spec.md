---
title: icrc21_consent_message_spec
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L535)

## Properties

### device\_spec

> **device\_spec**: \[\] \| \[\{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L537)

***

### metadata

> **metadata**: [`icrc21_consent_message_metadata`](icrc21_consent_message_metadata.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L536)
