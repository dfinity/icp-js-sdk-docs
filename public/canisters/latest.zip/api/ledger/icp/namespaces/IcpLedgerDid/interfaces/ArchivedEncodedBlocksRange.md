---
title: ArchivedEncodedBlocksRange
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L100)

## Properties

### callback

> **callback**: \[`Principal`, `string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L101)

***

### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L103)

***

### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L102)
