---
title: TransferFee
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L470)

## Properties

### transfer\_fee

> **transfer\_fee**: [`Tokens`](Tokens.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L474)

The fee to pay to perform a transfer
