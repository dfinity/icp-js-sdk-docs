---
title: SubAccount
editUrl: false
next: true
prev: true
---

> **SubAccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L364)

Subaccount is an arbitrary 32-byte byte array.
Ledger uses subaccounts to compute the source address, which enables one
principal to control multiple ledger accounts.
