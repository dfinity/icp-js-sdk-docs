---
title: SubAccount
editUrl: false
next: true
prev: true
---

> **SubAccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L364)

Subaccount is an arbitrary 32-byte byte array.
Ledger uses subaccounts to compute the source address, which enables one
principal to control multiple ledger accounts.
