---
title: LedgerCanisterPayload
editUrl: false
next: true
prev: true
---

> **LedgerCanisterPayload** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](../interfaces/UpgradeArgs.md)\]; \} \| \{ `Init`: [`InitArgs`](../interfaces/InitArgs.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L214)
