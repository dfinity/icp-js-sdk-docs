---
title: Allowance
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L31)

## Properties

### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L32)

***

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L33)
