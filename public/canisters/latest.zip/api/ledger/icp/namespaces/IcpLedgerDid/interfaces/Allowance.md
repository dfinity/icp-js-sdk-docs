---
title: Allowance
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L31)

## Properties

### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L32)

***

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L33)
