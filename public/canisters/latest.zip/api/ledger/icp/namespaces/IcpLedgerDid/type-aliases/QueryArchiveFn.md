---
title: QueryArchiveFn
editUrl: false
next: true
prev: true
---

> **QueryArchiveFn** = `ActorMethod`\<\[[`GetBlocksArgs`](../interfaces/GetBlocksArgs.md)\], [`QueryArchiveResult`](QueryArchiveResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L277)

A function that is used for fetching archived ledger blocks.
