---
title: Tokens
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L382)

Amount of tokens, measured in 10^-8 of a token.

## Properties

### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L383)
