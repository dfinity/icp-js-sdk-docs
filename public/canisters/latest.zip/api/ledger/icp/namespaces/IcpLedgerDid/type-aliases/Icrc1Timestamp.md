---
title: Icrc1Timestamp
editUrl: false
next: true
prev: true
---

> **Icrc1Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L174)

Number of nanoseconds since the UNIX epoch in UTC timezone.
