---
title: Icrc1Timestamp
editUrl: false
next: true
prev: true
---

> **Icrc1Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L174)

Number of nanoseconds since the UNIX epoch in UTC timezone.
