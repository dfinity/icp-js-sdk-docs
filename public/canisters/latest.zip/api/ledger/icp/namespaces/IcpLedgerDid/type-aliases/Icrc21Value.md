---
title: Icrc21Value
editUrl: false
next: true
prev: true
---

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L190)
