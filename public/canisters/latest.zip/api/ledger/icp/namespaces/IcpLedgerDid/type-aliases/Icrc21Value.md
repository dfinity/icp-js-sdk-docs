---
title: Icrc21Value
editUrl: false
next: true
prev: true
---

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L190)
