---
title: Icrc1BlockIndex
editUrl: false
next: true
prev: true
---

> **Icrc1BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L170)
