---
title: icrc21_consent_info
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L514)

## Properties

### consent\_message

> **consent\_message**: [`icrc21_consent_message`](../type-aliases/icrc21_consent_message.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L516)

***

### metadata

> **metadata**: [`icrc21_consent_message_metadata`](icrc21_consent_message_metadata.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L515)
