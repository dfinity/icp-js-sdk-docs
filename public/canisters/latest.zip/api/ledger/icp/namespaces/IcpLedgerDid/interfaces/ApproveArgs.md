---
title: ApproveArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L48)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L53)

***

### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L52)

***

### expected\_allowance

> **expected\_allowance**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L54)

***

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L55)

***

### fee

> **fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L49)

***

### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](../type-aliases/SubAccount.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L51)

***

### memo

> **memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L50)

***

### spender

> **spender**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L56)
