---
title: Status
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L95)

## Properties

### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L96)
