---
title: GetAccountIdentifierTransactionsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L25)

## Properties

### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L26)

***

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L28)

***

### transactions

> **transactions**: [`TransactionWithId`](TransactionWithId.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L27)
