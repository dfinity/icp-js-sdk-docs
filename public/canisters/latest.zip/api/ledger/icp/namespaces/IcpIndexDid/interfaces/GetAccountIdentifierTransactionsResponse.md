---
title: GetAccountIdentifierTransactionsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L25)

## Properties

### balance

> **balance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L26)

***

### oldest\_tx\_id

> **oldest\_tx\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L28)

***

### transactions

> **transactions**: [`TransactionWithId`](TransactionWithId.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L27)
