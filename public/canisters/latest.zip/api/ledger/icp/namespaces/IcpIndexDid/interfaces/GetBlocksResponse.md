---
title: GetBlocksResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L53)

## Properties

### blocks

> **blocks**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L54)

***

### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L55)
