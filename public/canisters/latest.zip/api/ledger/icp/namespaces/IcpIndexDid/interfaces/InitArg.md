---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/index.d.ts#L68)

## Properties

### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/index.d.ts#L69)
