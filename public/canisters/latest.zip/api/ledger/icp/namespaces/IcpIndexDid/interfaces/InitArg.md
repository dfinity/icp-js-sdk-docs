---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L68)

## Properties

### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L69)
