---
title: GetAccountIdentifierTransactionsResult
editUrl: false
next: true
prev: true
---

> **GetAccountIdentifierTransactionsResult** = \{ `Ok`: [`GetAccountIdentifierTransactionsResponse`](../interfaces/GetAccountIdentifierTransactionsResponse.md); \} \| \{ `Err`: [`GetAccountIdentifierTransactionsError`](../interfaces/GetAccountIdentifierTransactionsError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/index.d.ts#L30)
