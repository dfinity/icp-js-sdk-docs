---
title: Tokens
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L101)

## Properties

### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L102)
