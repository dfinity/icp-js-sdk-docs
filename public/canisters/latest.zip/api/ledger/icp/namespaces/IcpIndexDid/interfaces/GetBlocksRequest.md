---
title: GetBlocksRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L49)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L51)

***

### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L50)
