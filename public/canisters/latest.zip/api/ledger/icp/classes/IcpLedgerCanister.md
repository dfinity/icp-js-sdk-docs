---
title: IcpLedgerCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:33](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L33)

## Extends

- `Canister`\<[`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new IcpLedgerCanister**(`id`, `service`, `certifiedService`): `IcpLedgerCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)

#### Returns

`IcpLedgerCanister`

#### Inherited from

`Canister<IcpLedgerService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### accountBalance()

> **accountBalance**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:62](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L62)

Returns the balance of the specified account identifier.

If `certified` is true, the request is fetched as an update call, otherwise
it is fetched using a query call.

#### Parameters

##### params

`AccountBalanceParams`

The parameters to get the balance of an account.

#### Returns

`Promise`\<`bigint`\>

The balance of the given account.

#### Throws

Error

***

### icrc1Transfer()

> **icrc1Transfer**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:132](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L132)

Transfer ICP from the caller to the destination `Account`.
Returns the index of the block containing the tx if it was successful.

#### Parameters

##### request

[`Icrc1TransferRequest`](../interfaces/Icrc1TransferRequest.md)

#### Returns

`Promise`\<`bigint`\>

#### Throws

[TransferError](TransferError.md)

***

### icrc21ConsentMessage()

> **icrc21ConsentMessage**(`params`): `Promise`\<[`icrc21_consent_info`](../namespaces/IcpLedgerDid/interfaces/icrc21_consent_info.md)\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:179](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L179)

Fetches the consent message for a specified canister call, intended to provide a human-readable message that helps users make informed decisions.

@link: https://github.com/dfinity/wg-identity-authentication/blob/main/topics/ICRC-21/icrc_21_consent_msg.md

#### Parameters

##### params

`Icrc21ConsentMessageRequest`

The request parameters containing the method name, arguments, and consent preferences (e.g., language).

#### Returns

`Promise`\<[`icrc21_consent_info`](../namespaces/IcpLedgerDid/interfaces/icrc21_consent_info.md)\>

- A promise that resolves to the consent message response, which includes the consent message in the specified language and other related information.

#### Throws

- This error is reserved for future use, in case payment extensions are introduced. For example, if consent messages, which are currently free, begin to require payments.

#### Throws

- If the specified canister call is not supported.

#### Throws

- If there is no consent message available.

#### Throws

- For any other generic errors.

***

### icrc2Approve()

> **icrc2Approve**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:152](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L152)

This method entitles the `spender` to transfer token `amount` on behalf of the caller from account `{ owner = caller; subaccount = from_subaccount }`.

Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-2/index.md#icrc2_approve

#### Parameters

##### params

[`Icrc2ApproveRequest`](../type-aliases/Icrc2ApproveRequest.md)

The parameters to approve.

#### Returns

`Promise`\<`bigint`\>

The block index of the approved transaction.

#### Throws

If the approval fails.

***

### metadata()

> **metadata**(`params`): `Promise`\<\[`string`, [`Value`](../namespaces/IcpLedgerDid/type-aliases/Value.md)\][]\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:81](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L81)

Fetches the ledger metadata.

#### Parameters

##### params

`QueryParams`

The parameters used to fetch the metadata, notably query or certified call.

#### Returns

`Promise`\<\[`string`, [`Value`](../namespaces/IcpLedgerDid/type-aliases/Value.md)\][]\>

The metadata of the ICP ledger. A promise that resolves to an array of metadata entries, where each entry is a tuple consisting of a string and a value.

***

### transactionFee()

> **transactionFee**(`params?`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:94](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L94)

Returns the transaction fee of the ICP ledger canister.

#### Parameters

##### params?

`QueryParams` = `...`

Optional query parameters for the request, defaulting to `{ certified: false }` for backwards compatibility reason.

#### Returns

`Promise`\<`bigint`\>

A promise that resolves to the transaction fee as a bigint.

***

### transfer()

> **transfer**(`request`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:112](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L112)

Transfer ICP from the caller to the destination `accountIdentifier`.
Returns the index of the block containing the tx if it was successful.

#### Parameters

##### request

[`TransferRequest`](../interfaces/TransferRequest.md)

#### Returns

`Promise`\<`bigint`\>

#### Throws

[TransferError](TransferError.md)

***

### create()

> `static` **create**(`options`): `IcpLedgerCanister`

Defined in: [packages/canisters/src/ledger/icp/ledger.canister.ts:34](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/ledger.canister.ts#L34)

#### Parameters

##### options

[`IcpLedgerCanisterOptions`](../type-aliases/IcpLedgerCanisterOptions.md) = `{}`

#### Returns

`IcpLedgerCanister`
