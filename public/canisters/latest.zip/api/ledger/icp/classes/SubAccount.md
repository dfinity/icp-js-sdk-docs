---
title: SubAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:140](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/account_identifier.ts#L140)

A subaccount in the ICP ledger is a 32-byte identifier that allows a principal (user or canister)
to control multiple independent accounts under the same principal.

## See

https://internetcomputer.org/docs/references/ledger#_accounts

## Methods

### toUint8Array()

> **toUint8Array**(): `Uint8Array`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:218](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/account_identifier.ts#L218)

Returns the raw 32-byte `Uint8Array` representing this subaccount.

#### Returns

`Uint8Array`

A 32-byte array.

***

### fromBytes()

> `static` **fromBytes**(`bytes`): `SubAccount`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:150](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/account_identifier.ts#L150)

Creates a `SubAccount` from a 32‑byte array.

#### Parameters

##### bytes

`Uint8Array`

A `Uint8Array` of exactly 32 bytes.

#### Returns

`SubAccount`

A `SubAccount` instance.

#### Throws

If the byte array length is not 32.

***

### fromID()

> `static` **fromID**(`id`): `SubAccount`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:189](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/account_identifier.ts#L189)

Generates a `SubAccount` from a non‑negative number.

The number is encoded into the last 8 bytes of the 32‑byte array.
This is a common pattern when using numbered subaccounts like 0, 1, 2...

#### Parameters

##### id

`number`

A non-negative integer.

#### Returns

`SubAccount`

A `SubAccount` instance.

#### Throws

If the number is negative or exceeds `Number.MAX_SAFE_INTEGER`.

***

### fromPrincipal()

> `static` **fromPrincipal**(`principal`): `SubAccount`

Defined in: [packages/canisters/src/ledger/icp/account\_identifier.ts:166](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/account_identifier.ts#L166)

Generates a `SubAccount` from a principal.

The principal is embedded into the beginning of a 32‑byte array.

#### Parameters

##### principal

`Principal`

A principal to encode into the subaccount.

#### Returns

`SubAccount`

A `SubAccount` instance.
