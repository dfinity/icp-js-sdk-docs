---
title: Icrc1TransferRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:23](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L23)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:25](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L25)

***

### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:32](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L32)

***

### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:27](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L27)

***

### fromSubAccount?

> `optional` **fromSubAccount**: [`SubAccount`](../namespaces/IcpLedgerDid/type-aliases/SubAccount.md)

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:28](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L28)

***

### icrc1Memo?

> `optional` **icrc1Memo**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:26](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L26)

***

### to

> **to**: [`Account`](../namespaces/IcpLedgerDid/interfaces/Account.md)

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:24](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L24)
