---
title: SnapshotIdText
editUrl: false
next: true
prev: true
---

> **SnapshotIdText** = `string`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L7)
