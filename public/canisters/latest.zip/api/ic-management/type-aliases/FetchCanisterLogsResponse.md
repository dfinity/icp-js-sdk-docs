---
title: FetchCanisterLogsResponse
editUrl: false
next: true
prev: true
---

> **FetchCanisterLogsResponse** = `ServiceResponse`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md), `"fetch_canister_logs"`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.responses.ts#L9)
