---
title: FetchCanisterLogsResponse
editUrl: false
next: true
prev: true
---

> **FetchCanisterLogsResponse** = `ServiceResponse`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md), `"fetch_canister_logs"`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.responses.ts#L9)
