---
title: SnapshotParams
editUrl: false
next: true
prev: true
---

> **SnapshotParams** = `Required`\<[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L14)
