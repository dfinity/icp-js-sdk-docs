---
title: SnapshotParams
editUrl: false
next: true
prev: true
---

> **SnapshotParams** = `Required`\<[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L14)
