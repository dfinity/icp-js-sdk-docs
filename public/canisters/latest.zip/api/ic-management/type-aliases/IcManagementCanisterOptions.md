---
title: IcManagementCanisterOptions
editUrl: false
next: true
prev: true
---

> **IcManagementCanisterOptions** = `Pick`\<`CanisterOptions`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md)\>, `"agent"` \| `"serviceOverride"` \| `"certifiedServiceOverride"`\>

Defined in: [packages/canisters/src/ic-management/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/canister.options.ts#L4)
