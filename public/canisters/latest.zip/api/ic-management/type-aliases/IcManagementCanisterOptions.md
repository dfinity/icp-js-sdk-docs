---
title: IcManagementCanisterOptions
editUrl: false
next: true
prev: true
---

> **IcManagementCanisterOptions** = `Pick`\<`CanisterOptions`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md)\>, `"agent"` \| `"serviceOverride"` \| `"certifiedServiceOverride"`\>

Defined in: [packages/canisters/src/ic-management/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/canister.options.ts#L4)
