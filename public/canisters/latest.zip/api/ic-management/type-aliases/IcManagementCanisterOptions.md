---
title: IcManagementCanisterOptions
editUrl: false
next: true
prev: true
---

> **IcManagementCanisterOptions** = `Pick`\<`CanisterOptions`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md)\>, `"agent"` \| `"serviceOverride"` \| `"certifiedServiceOverride"`\>

Defined in: [packages/canisters/src/ic-management/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/canister.options.ts#L4)
