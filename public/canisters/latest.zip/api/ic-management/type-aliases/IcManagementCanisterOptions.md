---
title: IcManagementCanisterOptions
editUrl: false
next: true
prev: true
---

> **IcManagementCanisterOptions** = `Pick`\<`CanisterOptions`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md)\>, `"agent"` \| `"serviceOverride"` \| `"certifiedServiceOverride"`\>

Defined in: [packages/canisters/src/ic-management/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/canister.options.ts#L4)
