---
title: IcManagementCanisterOptions
editUrl: false
next: true
prev: true
---

> **IcManagementCanisterOptions** = `Pick`\<`CanisterOptions`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md)\>, `"agent"` \| `"serviceOverride"` \| `"certifiedServiceOverride"`\>

Defined in: [packages/canisters/src/ic-management/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/canister.options.ts#L4)
