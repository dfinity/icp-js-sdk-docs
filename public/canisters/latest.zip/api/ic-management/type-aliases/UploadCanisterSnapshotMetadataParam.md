---
title: UploadCanisterSnapshotMetadataParam
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotMetadataParam** = `Pick`\<[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md), `"globals"` \| `"certifiedData"` \| `"globalTimer"` \| `"onLowWasmMemoryHookStatus"` \| `"wasmModuleSize"` \| `"stableMemorySize"` \| `"wasmMemorySize"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:69](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L69)
