---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [IcManagementDid](namespaces/IcManagementDid/index.md)

## Enumerations

- [LogVisibility](enumerations/LogVisibility.md)

## Classes

- [IcManagementCanister](classes/IcManagementCanister.md)
- [UnsupportedLogVisibility](classes/UnsupportedLogVisibility.md)

## Interfaces

- [CanisterSettings](interfaces/CanisterSettings.md)
- [CanisterStatusParams](interfaces/CanisterStatusParams.md)
- [ClearChunkStoreParams](interfaces/ClearChunkStoreParams.md)
- [CreateCanisterParams](interfaces/CreateCanisterParams.md)
- [InstallChunkedCodeParams](interfaces/InstallChunkedCodeParams.md)
- [InstallCodeParams](interfaces/InstallCodeParams.md)
- [OptionSnapshotParams](interfaces/OptionSnapshotParams.md)
- [ProvisionalCreateCanisterWithCyclesParams](interfaces/ProvisionalCreateCanisterWithCyclesParams.md)
- [ReadCanisterSnapshotDataParams](interfaces/ReadCanisterSnapshotDataParams.md)
- [ReadCanisterSnapshotMetadataParams](interfaces/ReadCanisterSnapshotMetadataParams.md)
- [ReadCanisterSnapshotMetadataResponse](interfaces/ReadCanisterSnapshotMetadataResponse.md)
- [StoredChunksParams](interfaces/StoredChunksParams.md)
- [UninstallCodeParams](interfaces/UninstallCodeParams.md)
- [UpdateSettingsParams](interfaces/UpdateSettingsParams.md)
- [UploadCanisterSnapshotDataParams](interfaces/UploadCanisterSnapshotDataParams.md)
- [UploadCanisterSnapshotMetadataParams](interfaces/UploadCanisterSnapshotMetadataParams.md)
- [UploadChunkParams](interfaces/UploadChunkParams.md)

## Type Aliases

- [CanisterSnapshotMetadataKind](type-aliases/CanisterSnapshotMetadataKind.md)
- [CanisterStatusResponse](type-aliases/CanisterStatusResponse.md)
- [FetchCanisterLogsResponse](type-aliases/FetchCanisterLogsResponse.md)
- [IcManagementCanisterOptions](type-aliases/IcManagementCanisterOptions.md)
- [SnapshotIdText](type-aliases/SnapshotIdText.md)
- [SnapshotParams](type-aliases/SnapshotParams.md)
- [UploadCanisterSnapshotDataKind](type-aliases/UploadCanisterSnapshotDataKind.md)
- [UploadCanisterSnapshotMetadataParam](type-aliases/UploadCanisterSnapshotMetadataParam.md)

## Functions

- [decodeSnapshotId](functions/decodeSnapshotId.md)
- [encodeSnapshotId](functions/encodeSnapshotId.md)
- [fromReadCanisterSnapshotMetadataResponse](functions/fromReadCanisterSnapshotMetadataResponse.md)
- [mapSnapshotId](functions/mapSnapshotId.md)
- [toCanisterSettings](functions/toCanisterSettings.md)
- [toCanisterSnapshotMetadataKind](functions/toCanisterSnapshotMetadataKind.md)
- [toReplaceSnapshotArgs](functions/toReplaceSnapshotArgs.md)
- [toSnapshotArgs](functions/toSnapshotArgs.md)
- [toUploadCanisterSnapshotDataKind](functions/toUploadCanisterSnapshotDataKind.md)
- [toUploadCanisterSnapshotMetadata](functions/toUploadCanisterSnapshotMetadata.md)
