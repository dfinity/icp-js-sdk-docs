---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [IcManagementDid](namespaces/IcManagementDid.md)

## Enumerations

### LogVisibility

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L5)

#### Enumeration Members

##### Controllers

> **Controllers**: `0`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L6)

##### Public

> **Public**: `1`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L7)

***

### SnapshotVisibilityType

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L10)

#### Enumeration Members

##### AllowedViewers

> **AllowedViewers**: `2`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L13)

##### Controllers

> **Controllers**: `0`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L11)

##### Public

> **Public**: `1`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L12)

## Classes

### IcManagementCanister

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L50)

#### Methods

##### canisterStatus()

> **canisterStatus**(`params`): `Promise`\<[`canister_status_result`](namespaces/IcManagementDid.md#canister_status_result)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:296](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L296)

Get canister details (memory size, status, etc.)

###### Parameters

###### params

[`CanisterStatusParams`](#canisterstatusparams)

The parameters for the status call.

###### Returns

`Promise`\<[`canister_status_result`](namespaces/IcManagementDid.md#canister_status_result)\>

A promise that resolves with the canister status details.

##### clearChunkStore()

> **clearChunkStore**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:177](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L177)

Clear the entire chunk storage of a canister.

###### Parameters

###### params

[`ClearChunkStoreParams`](#clearchunkstoreparams)

###### Returns

`Promise`\<`void`\>

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-clear_chunk_store

##### createCanister()

> **createCanister**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L83)

Create a new canister

###### Parameters

###### params

[`CreateCanisterParams`](#createcanisterparams) = `{}`

###### Returns

`Promise`\<`Principal`\>

##### deleteCanister()

> **deleteCanister**(`canisterId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:313](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L313)

Deletes a canister

###### Parameters

###### canisterId

`Principal`

###### Returns

`Promise`\<`void`\>

##### deleteCanisterSnapshot()

> **deleteCanisterSnapshot**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:461](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L461)

Deletes a specific snapshot of a canister.

###### Parameters

###### params

[`SnapshotParams`](#snapshotparams)

Parameters for the deletion operation.

###### Returns

`Promise`\<`void`\>

A promise that resolves when the snapshot is successfully deleted.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-delete_canister_snapshot

###### Throws

If the deletion operation fails.

##### fetchCanisterLogs()

> **fetchCanisterLogs**(`canisterId`): `Promise`\<[`fetch_canister_logs_result`](namespaces/IcManagementDid.md#fetch_canister_logs_result)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:351](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L351)

Given a canister ID as input, this method returns a vector of logs of that canister including its trap messages. The canister logs are not collected in canister methods running in non-replicated mode (NRQ, CQ, CRy, CRt, CC, and F modes, as defined in Overview of imports). The total size of all returned logs does not exceed 4KiB. If new logs are added resulting in exceeding the maximum total log size of 4KiB, the oldest logs will be removed. Logs persist across canister upgrades and they are deleted if the canister is reinstalled or uninstalled.

###### Parameters

###### canisterId

`Principal`

###### Returns

`Promise`\<[`fetch_canister_logs_result`](namespaces/IcManagementDid.md#fetch_canister_logs_result)\>

##### installChunkedCode()

> **installChunkedCode**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:221](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L221)

Installs code that had previously been uploaded in chunks.

###### Parameters

###### params

[`InstallChunkedCodeParams`](#installchunkedcodeparams)

###### Returns

`Promise`\<`void`\>

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-install_chunked_code

##### installCode()

> **installCode**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L131)

Install code to a canister

###### Parameters

###### params

[`InstallCodeParams`](#installcodeparams)

###### Returns

`Promise`\<`void`\>

##### listCanisterSnapshots()

> **listCanisterSnapshots**(`params`): `Promise`\<[`list_canister_snapshots_result`](namespaces/IcManagementDid.md#list_canister_snapshots_result)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:408](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L408)

Lists the snapshots of a canister.

###### Parameters

###### params

Parameters for the listing operation.

###### canisterId

`Principal`

The ID of the canister for which snapshots will be listed.

###### Returns

`Promise`\<[`list_canister_snapshots_result`](namespaces/IcManagementDid.md#list_canister_snapshots_result)\>

A promise that resolves with the list of snapshots.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-list_canister_snapshots

###### Throws

If the operation fails.

##### loadCanisterSnapshot()

> **loadCanisterSnapshot**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:434](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L434)

Loads a snapshot of a canister's state.

###### Parameters

###### params

`Required`\<[`OptionSnapshotParams`](#optionsnapshotparams)\> & `object`

Parameters for the snapshot loading operation.

###### Returns

`Promise`\<`void`\>

A promise that resolves when the snapshot is successfully loaded.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-load_canister_snapshot

###### Throws

If the snapshot loading operation fails.

##### provisionalCreateCanisterWithCycles()

> **provisionalCreateCanisterWithCycles**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:328](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L328)

Creates a canister. Only available on development instances.

###### Parameters

###### params

[`ProvisionalCreateCanisterWithCyclesParams`](#provisionalcreatecanisterwithcyclesparams) = `{}`

###### Returns

`Promise`\<`Principal`\>

##### readCanisterSnapshotData()

> **readCanisterSnapshotData**(`params`): `Promise`\<[`read_canister_snapshot_data_response`](namespaces/IcManagementDid.md#read_canister_snapshot_data_response)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:506](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L506)

Reads snapshot data for a specific canister snapshot and kind.

###### Parameters

###### params

[`ReadCanisterSnapshotDataParams`](#readcanistersnapshotdataparams)

Parameters for the data read operation.

###### Returns

`Promise`\<[`read_canister_snapshot_data_response`](namespaces/IcManagementDid.md#read_canister_snapshot_data_response)\>

A promise that resolves with the snapshot data payload.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-read_canister_snapshot_data

###### Throws

If the data read operation fails.

##### readCanisterSnapshotMetadata()

> **readCanisterSnapshotMetadata**(`params`): `Promise`\<[`ReadCanisterSnapshotMetadataResponse`](#readcanistersnapshotmetadataresponse)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:480](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L480)

Reads metadata for a specific canister snapshot.

###### Parameters

###### params

[`SnapshotParams`](#snapshotparams)

Parameters for the metadata read operation.

###### Returns

`Promise`\<[`ReadCanisterSnapshotMetadataResponse`](#readcanistersnapshotmetadataresponse)\>

A promise that resolves with the snapshot metadata.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-read_canister_snapshot_metadata

###### Throws

If the metadata read operation fails.

##### startCanister()

> **startCanister**(`canisterId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:270](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L270)

Start a canister

###### Parameters

###### canisterId

`Principal`

###### Returns

`Promise`\<`void`\>

##### stopCanister()

> **stopCanister**(`canisterId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:282](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L282)

Stop a canister

###### Parameters

###### canisterId

`Principal`

###### Returns

`Promise`\<`void`\>

##### storedChunks()

> **storedChunks**(`params`): `Promise`\<[`chunk_hash`](namespaces/IcManagementDid.md#chunk_hash)[]\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L196)

List the hashes of chunks in the chunk storage of a canister.

###### Parameters

###### params

[`StoredChunksParams`](#storedchunksparams)

###### Returns

`Promise`\<[`chunk_hash`](namespaces/IcManagementDid.md#chunk_hash)[]\>

The list of hash of the stored chunks.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-stored_chunks

##### takeCanisterSnapshot()

> **takeCanisterSnapshot**(`params`): `Promise`\<[`snapshot`](namespaces/IcManagementDid.md#snapshot)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:379](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L379)

This method takes a snapshot of the specified canister. A snapshot consists of the wasm memory, stable memory, certified variables, wasm chunk store and wasm binary.

###### Parameters

###### params

[`OptionSnapshotParams`](#optionsnapshotparams) & `object`

Parameters for the snapshot operation.

###### Returns

`Promise`\<[`snapshot`](namespaces/IcManagementDid.md#snapshot)\>

A promise that resolves with the snapshot details,
including the snapshot ID, total size, and timestamp.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-take_canister_snapshot

###### Throws

If the snapshot operation fails.

##### uninstallCode()

> **uninstallCode**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:252](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L252)

Uninstall code from a canister

###### Parameters

###### params

[`UninstallCodeParams`](#uninstallcodeparams)

###### Returns

`Promise`\<`void`\>

##### updateSettings()

> **updateSettings**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L106)

Update canister settings

###### Parameters

###### params

[`UpdateSettingsParams`](#updatesettingsparams)

###### Returns

`Promise`\<`void`\>

##### uploadCanisterSnapshotData()

> **uploadCanisterSnapshotData**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:559](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L559)

Uploads a chunk of snapshot data for a canister snapshot.

###### Parameters

###### params

[`UploadCanisterSnapshotDataParams`](#uploadcanistersnapshotdataparams)

Parameters for the data upload operation.

###### Returns

`Promise`\<`void`\>

A promise that resolves when the data is successfully uploaded.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-upload_canister_snapshot_data

###### Throws

If the data upload operation fails.

##### uploadCanisterSnapshotMetadata()

> **uploadCanisterSnapshotMetadata**(`params`): `Promise`\<[`upload_canister_snapshot_metadata_response`](namespaces/IcManagementDid.md#upload_canister_snapshot_metadata_response)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:532](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L532)

Uploads snapshot metadata for a canister.

###### Parameters

###### params

[`UploadCanisterSnapshotMetadataParams`](#uploadcanistersnapshotmetadataparams)

Parameters for the metadata upload operation.

###### Returns

`Promise`\<[`upload_canister_snapshot_metadata_response`](namespaces/IcManagementDid.md#upload_canister_snapshot_metadata_response)\>

A promise that resolves with the upload response.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-upload_canister_snapshot_metadata

###### Throws

If the metadata upload operation fails.

##### uploadChunk()

> **uploadChunk**(`params`): `Promise`\<[`chunk_hash`](namespaces/IcManagementDid.md#chunk_hash)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:157](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L157)

Upload chunks of Wasm modules that are too large to fit in a single message for installation purposes.

###### Parameters

###### params

[`UploadChunkParams`](#uploadchunkparams)

###### Returns

`Promise`\<[`chunk_hash`](namespaces/IcManagementDid.md#chunk_hash)\>

The hash of the stored chunk.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-upload_chunk

##### create()

> `static` **create**(`options`): [`IcManagementCanister`](#icmanagementcanister)

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/ic-management.canister.ts#L59)

###### Parameters

###### options

[`IcManagementCanisterOptions`](#icmanagementcanisteroptions)

###### Returns

[`IcManagementCanister`](#icmanagementcanister)

***

### UnsupportedLogVisibility

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:34](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L34)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new UnsupportedLogVisibility**(`message?`): [`UnsupportedLogVisibility`](#unsupportedlogvisibility)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`UnsupportedLogVisibility`](#unsupportedlogvisibility)

###### Inherited from

`Error.constructor`

##### Constructor

> **new UnsupportedLogVisibility**(`message?`, `options?`): [`UnsupportedLogVisibility`](#unsupportedlogvisibility)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`UnsupportedLogVisibility`](#unsupportedlogvisibility)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### UnsupportedSnapshotVisibility

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L35)

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new UnsupportedSnapshotVisibility**(`message?`): [`UnsupportedSnapshotVisibility`](#unsupportedsnapshotvisibility)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`UnsupportedSnapshotVisibility`](#unsupportedsnapshotvisibility)

###### Inherited from

`Error.constructor`

##### Constructor

> **new UnsupportedSnapshotVisibility**(`message?`, `options?`): [`UnsupportedSnapshotVisibility`](#unsupportedsnapshotvisibility)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`UnsupportedSnapshotVisibility`](#unsupportedsnapshotvisibility)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

## Interfaces

### CanisterSettings

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L21)

#### Properties

##### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L25)

##### controllers?

> `optional` **controllers**: `string`[]

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L22)

##### environmentVariables?

> `optional` **environmentVariables**: [`environment_variable`](namespaces/IcManagementDid.md#environment_variable)[]

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L31)

##### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L23)

##### logVisibility?

> `optional` **logVisibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L27)

##### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L24)

##### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L26)

##### snapshotVisibility?

> `optional` **snapshotVisibility**: [`SnapshotVisibility`](#snapshotvisibility-1)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L28)

##### wasmMemoryLimit?

> `optional` **wasmMemoryLimit**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L29)

##### wasmMemoryThreshold?

> `optional` **wasmMemoryThreshold**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L30)

***

### CanisterStatusParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:150](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L150)

#### Extends

- `QueryParams`

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:151](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L151)

##### certified?

> `optional` **certified**: `boolean`

Defined in: packages/utils/dist/types/query.params.d.ts:6

Perform update calls (certified) or query calls (not certified).

###### Inherited from

`QueryParams.certified`

***

### ClearChunkStoreParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L121)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L122)

***

### CreateCanisterParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L95)

#### Properties

##### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L97)

##### settings?

> `optional` **settings**: [`CanisterSettings`](#canistersettings)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L96)

***

### InstallChunkedCodeParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L129)

#### Extends

- `Omit`\<[`InstallCodeParams`](#installcodeparams), `"canisterId"` \| `"wasmModule"`\>

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L110)

###### Inherited from

[`InstallCodeParams`](#installcodeparams).[`arg`](#arg-1)

##### chunkHashesList

> **chunkHashesList**: [`chunk_hash`](namespaces/IcManagementDid.md#chunk_hash)[]

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L133)

##### mode

> **mode**: [`canister_install_mode`](namespaces/IcManagementDid.md#canister_install_mode)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L107)

###### Inherited from

[`InstallCodeParams`](#installcodeparams).[`mode`](#mode-1)

##### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L111)

###### Inherited from

[`InstallCodeParams`](#installcodeparams).[`senderCanisterVersion`](#sendercanisterversion-2)

##### storeCanisterId?

> `optional` **storeCanisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L135)

##### targetCanisterId

> **targetCanisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L134)

##### wasmModuleHash

> **wasmModuleHash**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L136)

***

### InstallCodeParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L106)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L110)

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L108)

##### mode

> **mode**: [`canister_install_mode`](namespaces/IcManagementDid.md#canister_install_mode)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L107)

##### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L111)

##### wasmModule

> **wasmModule**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L109)

***

### OptionSnapshotParams

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L9)

#### Extended by

- [`UploadCanisterSnapshotMetadataParams`](#uploadcanistersnapshotmetadataparams)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

##### snapshotId?

> `optional` **snapshotId**: `string` \| [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

***

### ProvisionalCreateCanisterWithCyclesParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:144](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L144)

#### Properties

##### amount?

> `optional` **amount**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:145](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L145)

##### canisterId?

> `optional` **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:147](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L147)

##### settings?

> `optional` **settings**: [`CanisterSettings`](#canistersettings)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:146](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L146)

***

### ReadCanisterSnapshotDataParams

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L46)

#### Extends

- [`SnapshotParams`](#snapshotparams)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`canisterId`](#canisterid-3)

##### kind

> **kind**: [`CanisterSnapshotMetadataKind`](#canistersnapshotmetadatakind)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L47)

##### snapshotId

> **snapshotId**: `string` \| [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`snapshotId`](#snapshotid)

***

### ReadCanisterSnapshotMetadataParams

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L132)

#### Extends

- [`SnapshotParams`](#snapshotparams)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`canisterId`](#canisterid-3)

##### kind

> **kind**: [`CanisterSnapshotMetadataKind`](#canistersnapshotmetadatakind)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L133)

##### snapshotId

> **snapshotId**: `string` \| [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`snapshotId`](#snapshotid)

***

### ReadCanisterSnapshotMetadataResponse

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L4)

#### Properties

##### canisterVersion

> **canisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L12)

##### certifiedData

> **certifiedData**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L14)

##### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L5)

##### globalTimer?

> `optional` **globalTimer**: \{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L15)

##### onLowWasmMemoryHookStatus?

> `optional` **onLowWasmMemoryHookStatus**: \{ `conditionNotSatisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L16)

##### source

> **source**: \{ `metadataUpload`: `unknown`; \} \| \{ `takenFromCanister`: `unknown`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L13)

##### stableMemorySize

> **stableMemorySize**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L21)

##### takenAtTimestamp

> **takenAtTimestamp**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L23)

##### wasmChunkStore

> **wasmChunkStore**: `object`[]

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L22)

###### hash

> **hash**: `Uint8Array`

##### wasmMemorySize

> **wasmMemorySize**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L24)

##### wasmModuleSize

> **wasmModuleSize**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L20)

***

### StoredChunksParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:125](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L125)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:126](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L126)

***

### UninstallCodeParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:139](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L139)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:140](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L140)

##### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L141)

***

### UpdateSettingsParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L100)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L101)

##### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L102)

##### settings

> **settings**: [`CanisterSettings`](#canistersettings)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L103)

***

### UploadCanisterSnapshotDataParams

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L136)

#### Extends

- [`SnapshotParams`](#snapshotparams)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`canisterId`](#canisterid-3)

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L137)

##### kind

> **kind**: [`UploadCanisterSnapshotDataKind`](#uploadcanistersnapshotdatakind)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L138)

##### snapshotId

> **snapshotId**: `string` \| [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`snapshotId`](#snapshotid)

***

### UploadCanisterSnapshotMetadataParams

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L83)

#### Extends

- [`OptionSnapshotParams`](#optionsnapshotparams)

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`canisterId`](#canisterid-3)

##### metadata

> **metadata**: [`UploadCanisterSnapshotMetadataParam`](#uploadcanistersnapshotmetadataparam)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L84)

##### snapshotId?

> `optional` **snapshotId**: `string` \| [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

###### Inherited from

[`OptionSnapshotParams`](#optionsnapshotparams).[`snapshotId`](#snapshotid)

***

### UploadChunkParams

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:114](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L114)

#### Extends

- `Pick`\<[`upload_chunk_args`](namespaces/IcManagementDid.md#upload_chunk_args), `"chunk"`\>

#### Properties

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L118)

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L471)

###### Inherited from

[`upload_chunk_args`](namespaces/IcManagementDid.md#upload_chunk_args).[`chunk`](namespaces/IcManagementDid.md#chunk-2)

## Type Aliases

### CanisterSnapshotMetadataKind

> **CanisterSnapshotMetadataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmChunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L40)

***

### CanisterStatusResponse

> **CanisterStatusResponse** = `ServiceResponse`\<[`_SERVICE`](namespaces/IcManagementDid.md#_service), `"canister_status"`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.responses.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.responses.ts#L4)

***

### FetchCanisterLogsResponse

> **FetchCanisterLogsResponse** = `ServiceResponse`\<[`_SERVICE`](namespaces/IcManagementDid.md#_service), `"fetch_canister_logs"`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.responses.ts#L9)

***

### IcManagementCanisterOptions

> **IcManagementCanisterOptions** = `Pick`\<`CanisterOptions`\<[`_SERVICE`](namespaces/IcManagementDid.md#_service)\>, `"agent"` \| `"serviceOverride"` \| `"certifiedServiceOverride"`\>

Defined in: [packages/canisters/src/ic-management/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/canister.options.ts#L4)

***

### SnapshotIdText

> **SnapshotIdText** = `string`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L7)

***

### SnapshotParams

> **SnapshotParams** = `Required`\<[`OptionSnapshotParams`](#optionsnapshotparams)\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L14)

***

### SnapshotVisibility

> **SnapshotVisibility** = \{ `type`: [`Controllers`](#controllers-1); \} \| \{ `type`: [`Public`](#public-1); \} \| \{ `type`: [`AllowedViewers`](#allowedviewers); `viewers`: `string`[]; \}

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L16)

***

### UploadCanisterSnapshotDataKind

> **UploadCanisterSnapshotDataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmChunk`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:126](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L126)

***

### UploadCanisterSnapshotMetadataParam

> **UploadCanisterSnapshotMetadataParam** = `Pick`\<[`ReadCanisterSnapshotMetadataResponse`](#readcanistersnapshotmetadataresponse), `"globals"` \| `"certifiedData"` \| `"globalTimer"` \| `"onLowWasmMemoryHookStatus"` \| `"wasmModuleSize"` \| `"stableMemorySize"` \| `"wasmMemorySize"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L72)

## Functions

### decodeSnapshotId()

> **decodeSnapshotId**(`snapshotId`): [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

Defined in: [packages/canisters/src/ic-management/utils/ic-management.utils.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/utils/ic-management.utils.ts#L29)

Decodes a hex string representation of a snapshot ID back into its original format.

A snapshot ID is a tuple `(CanisterId, u64)`, where:
- `CanisterId` is a unique identifier for a canister.
- `u64` is a subnet-local number (incremented for each new snapshot).

#### Parameters

##### snapshotId

`string`

The hex string representation of the snapshot ID.

#### Returns

[`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

The decoded snapshot ID as a `Uint8Array`.

***

### encodeSnapshotId()

> **encodeSnapshotId**(`snapshotId`): `string`

Defined in: [packages/canisters/src/ic-management/utils/ic-management.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/utils/ic-management.utils.ts#L15)

Encodes a snapshot ID into a hex string representation.

A snapshot ID is a tuple `(CanisterId, u64)`, where:
- `CanisterId` is a unique identifier for a canister.
- `u64` is a subnet-local number (incremented for each new snapshot).

#### Parameters

##### snapshotId

[`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

The snapshot ID to encode, represented as a `Uint8Array` or an array of numbers.

#### Returns

`string`

The hex string representation of the snapshot ID.

***

### fromReadCanisterSnapshotMetadataResponse()

> **fromReadCanisterSnapshotMetadataResponse**(`__namedParameters`): [`ReadCanisterSnapshotMetadataResponse`](#readcanistersnapshotmetadataresponse)

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.responses.ts#L27)

#### Parameters

##### \_\_namedParameters

[`read_canister_snapshot_metadata_response`](namespaces/IcManagementDid.md#read_canister_snapshot_metadata_response)

#### Returns

[`ReadCanisterSnapshotMetadataResponse`](#readcanistersnapshotmetadataresponse)

***

### mapSnapshotId()

> **mapSnapshotId**(`snapshotId`): [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

Defined in: [packages/canisters/src/ic-management/utils/ic-management.utils.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/utils/ic-management.utils.ts#L42)

Maps a snapshot ID to the appropriate format for the IC interface.

#### Parameters

##### snapshotId

The snapshot ID to map.
It can either be a `string` (SnapshotIdText) or a `Uint8Array | number[]` (snapshot_id).
If a `string` is provided, it is decoded into a `Uint8Array` using `decodeSnapshotId`.

`string` | [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

#### Returns

[`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

The mapped snapshot ID.

***

### toCanisterSettings()

> **toCanisterSettings**(`__namedParameters`): [`canister_settings`](namespaces/IcManagementDid.md#canister_settings)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/ic-management.params.ts#L37)

#### Parameters

##### \_\_namedParameters

[`CanisterSettings`](#canistersettings) = `{}`

#### Returns

[`canister_settings`](namespaces/IcManagementDid.md#canister_settings)

***

### toCanisterSnapshotMetadataKind()

> **toCanisterSnapshotMetadataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L50)

#### Parameters

##### kind

[`CanisterSnapshotMetadataKind`](#canistersnapshotmetadatakind)

#### Returns

\{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

***

### toReplaceSnapshotArgs()

> **toReplaceSnapshotArgs**(`__namedParameters`): `Pick`\<[`take_canister_snapshot_args`](namespaces/IcManagementDid.md#take_canister_snapshot_args), `"canister_id"` \| `"replace_snapshot"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L27)

#### Parameters

##### \_\_namedParameters

[`OptionSnapshotParams`](#optionsnapshotparams)

#### Returns

`Pick`\<[`take_canister_snapshot_args`](namespaces/IcManagementDid.md#take_canister_snapshot_args), `"canister_id"` \| `"replace_snapshot"`\>

***

### toSnapshotArgs()

> **toSnapshotArgs**(`__namedParameters`): `object`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L16)

#### Parameters

##### \_\_namedParameters

[`SnapshotParams`](#snapshotparams)

#### Returns

`object`

##### canister\_id

> **canister\_id**: `Principal`

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](namespaces/IcManagementDid.md#snapshot_id-6)

***

### toUploadCanisterSnapshotDataKind()

> **toUploadCanisterSnapshotDataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L141)

#### Parameters

##### kind

[`UploadCanisterSnapshotDataKind`](#uploadcanistersnapshotdatakind)

#### Returns

\{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

***

### toUploadCanisterSnapshotMetadata()

> **toUploadCanisterSnapshotMetadata**(`__namedParameters`): `Omit`\<[`upload_canister_snapshot_metadata_args`](namespaces/IcManagementDid.md#upload_canister_snapshot_metadata_args), `"canister_id"` \| `"replace_snapshot"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ic-management/types/snapshot.params.ts#L87)

#### Parameters

##### \_\_namedParameters

[`UploadCanisterSnapshotMetadataParam`](#uploadcanistersnapshotmetadataparam)

#### Returns

`Omit`\<[`upload_canister_snapshot_metadata_args`](namespaces/IcManagementDid.md#upload_canister_snapshot_metadata_args), `"canister_id"` \| `"replace_snapshot"`\>
