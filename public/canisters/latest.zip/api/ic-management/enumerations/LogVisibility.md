---
title: LogVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L5)

## Enumeration Members

### Controllers

> **Controllers**: `0`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L6)

***

### Public

> **Public**: `1`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L7)
