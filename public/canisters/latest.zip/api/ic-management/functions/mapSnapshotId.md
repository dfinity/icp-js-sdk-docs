---
title: mapSnapshotId
editUrl: false
next: true
prev: true
---

> **mapSnapshotId**(`snapshotId`): [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/ic-management/utils/ic-management.utils.ts:42](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/utils/ic-management.utils.ts#L42)

Maps a snapshot ID to the appropriate format for the IC interface.

## Parameters

### snapshotId

The snapshot ID to map.
It can either be a `string` (SnapshotIdText) or a `Uint8Array | number[]` (snapshot_id).
If a `string` is provided, it is decoded into a `Uint8Array` using `decodeSnapshotId`.

`string` | [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

## Returns

[`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

The mapped snapshot ID.
