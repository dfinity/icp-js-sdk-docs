---
title: toUploadCanisterSnapshotMetadata
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotMetadata**(`__namedParameters`): `Omit`\<[`upload_canister_snapshot_metadata_args`](../namespaces/IcManagementDid/interfaces/upload_canister_snapshot_metadata_args.md), `"canister_id"` \| `"replace_snapshot"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:87](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/snapshot.params.ts#L87)

## Parameters

### \_\_namedParameters

[`UploadCanisterSnapshotMetadataParam`](../type-aliases/UploadCanisterSnapshotMetadataParam.md)

## Returns

`Omit`\<[`upload_canister_snapshot_metadata_args`](../namespaces/IcManagementDid/interfaces/upload_canister_snapshot_metadata_args.md), `"canister_id"` \| `"replace_snapshot"`\>
