---
title: decodeSnapshotId
editUrl: false
next: true
prev: true
---

> **decodeSnapshotId**(`snapshotId`): [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/ic-management/utils/ic-management.utils.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/utils/ic-management.utils.ts#L29)

Decodes a hex string representation of a snapshot ID back into its original format.

A snapshot ID is a tuple `(CanisterId, u64)`, where:
- `CanisterId` is a unique identifier for a canister.
- `u64` is a subnet-local number (incremented for each new snapshot).

## Parameters

### snapshotId

`string`

The hex string representation of the snapshot ID.

## Returns

[`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

The decoded snapshot ID as a `Uint8Array`.
