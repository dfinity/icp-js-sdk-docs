---
title: toSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toSnapshotArgs**(`__namedParameters`): `object`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/snapshot.params.ts#L16)

## Parameters

### \_\_namedParameters

[`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Returns

`object`

### canister\_id

> **canister\_id**: `Principal`

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)
