---
title: toSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toSnapshotArgs**(`__namedParameters`): `object`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L16)

## Parameters

### \_\_namedParameters

[`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Returns

`object`

### canister\_id

> **canister\_id**: `Principal`

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)
