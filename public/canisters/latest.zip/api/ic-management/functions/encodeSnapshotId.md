---
title: encodeSnapshotId
editUrl: false
next: true
prev: true
---

> **encodeSnapshotId**(`snapshotId`): `string`

Defined in: [packages/canisters/src/ic-management/utils/ic-management.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/utils/ic-management.utils.ts#L15)

Encodes a snapshot ID into a hex string representation.

A snapshot ID is a tuple `(CanisterId, u64)`, where:
- `CanisterId` is a unique identifier for a canister.
- `u64` is a subnet-local number (incremented for each new snapshot).

## Parameters

### snapshotId

[`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

The snapshot ID to encode, represented as a `Uint8Array` or an array of numbers.

## Returns

`string`

The hex string representation of the snapshot ID.
