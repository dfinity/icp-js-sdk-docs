---
title: toReplaceSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toReplaceSnapshotArgs**(`__namedParameters`): [`take_canister_snapshot_args`](../namespaces/IcManagementDid/interfaces/take_canister_snapshot_args.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:27](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L27)

## Parameters

### \_\_namedParameters

[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)

## Returns

[`take_canister_snapshot_args`](../namespaces/IcManagementDid/interfaces/take_canister_snapshot_args.md)
