---
title: toCanisterSnapshotMetadataKind
editUrl: false
next: true
prev: true
---

> **toCanisterSnapshotMetadataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:50](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L50)

## Parameters

### kind

[`CanisterSnapshotMetadataKind`](../type-aliases/CanisterSnapshotMetadataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}
