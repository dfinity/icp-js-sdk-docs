---
title: fromReadCanisterSnapshotMetadataResponse
editUrl: false
next: true
prev: true
---

> **fromReadCanisterSnapshotMetadataResponse**(`__namedParameters`): [`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:27](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L27)

## Parameters

### \_\_namedParameters

[`read_canister_snapshot_metadata_response`](../namespaces/IcManagementDid/interfaces/read_canister_snapshot_metadata_response.md)

## Returns

[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)
