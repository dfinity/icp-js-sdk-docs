---
title: fromReadCanisterSnapshotMetadataResponse
editUrl: false
next: true
prev: true
---

> **fromReadCanisterSnapshotMetadataResponse**(`__namedParameters`): [`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:27](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.responses.ts#L27)

## Parameters

### \_\_namedParameters

[`read_canister_snapshot_metadata_response`](../namespaces/IcManagementDid/interfaces/read_canister_snapshot_metadata_response.md)

## Returns

[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)
