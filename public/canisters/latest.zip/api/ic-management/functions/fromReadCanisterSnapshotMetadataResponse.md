---
title: fromReadCanisterSnapshotMetadataResponse
editUrl: false
next: true
prev: true
---

> **fromReadCanisterSnapshotMetadataResponse**(`__namedParameters`): [`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:27](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.responses.ts#L27)

## Parameters

### \_\_namedParameters

[`read_canister_snapshot_metadata_response`](../namespaces/IcManagementDid/interfaces/read_canister_snapshot_metadata_response.md)

## Returns

[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)
