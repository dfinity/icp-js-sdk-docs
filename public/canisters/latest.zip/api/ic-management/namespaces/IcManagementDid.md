---
title: IcManagementDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L499)

#### Properties

##### bitcoin\_get\_balance

> **bitcoin\_get\_balance**: `ActorMethod`\<\[[`bitcoin_get_balance_args`](#bitcoin_get_balance_args)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L503)

bitcoin interface

##### bitcoin\_get\_block\_headers

> **bitcoin\_get\_block\_headers**: `ActorMethod`\<\[[`bitcoin_get_block_headers_args`](#bitcoin_get_block_headers_args)\], [`bitcoin_get_block_headers_result`](#bitcoin_get_block_headers_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L507)

##### bitcoin\_get\_current\_fee\_percentiles

> **bitcoin\_get\_current\_fee\_percentiles**: `ActorMethod`\<\[[`bitcoin_get_current_fee_percentiles_args`](#bitcoin_get_current_fee_percentiles_args)\], [`bitcoin_get_current_fee_percentiles_result`](#bitcoin_get_current_fee_percentiles_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L511)

##### bitcoin\_get\_utxos

> **bitcoin\_get\_utxos**: `ActorMethod`\<\[[`bitcoin_get_utxos_args`](#bitcoin_get_utxos_args)\], [`bitcoin_get_utxos_result`](#bitcoin_get_utxos_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:515](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L515)

##### bitcoin\_send\_transaction

> **bitcoin\_send\_transaction**: `ActorMethod`\<\[[`bitcoin_send_transaction_args`](#bitcoin_send_transaction_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L519)

##### canister\_info

> **canister\_info**: `ActorMethod`\<\[[`canister_info_args`](#canister_info_args)\], [`canister_info_result`](#canister_info_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:526](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L526)

Public canister data

##### canister\_metadata

> **canister\_metadata**: `ActorMethod`\<\[[`canister_metadata_args`](#canister_metadata_args)\], [`canister_metadata_result`](#canister_metadata_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L527)

##### canister\_status

> **canister\_status**: `ActorMethod`\<\[[`canister_status_args`](#canister_status_args)\], [`canister_status_result`](#canister_status_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L531)

##### clear\_chunk\_store

> **clear\_chunk\_store**: `ActorMethod`\<\[[`clear_chunk_store_args`](#clear_chunk_store_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L532)

##### create\_canister

> **create\_canister**: `ActorMethod`\<\[[`create_canister_args`](#create_canister_args)\], [`create_canister_result`](#create_canister_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L533)

##### delete\_canister

> **delete\_canister**: `ActorMethod`\<\[[`delete_canister_args`](#delete_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L534)

##### delete\_canister\_snapshot

> **delete\_canister\_snapshot**: `ActorMethod`\<\[[`delete_canister_snapshot_args`](#delete_canister_snapshot_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L535)

##### deposit\_cycles

> **deposit\_cycles**: `ActorMethod`\<\[[`deposit_cycles_args`](#deposit_cycles_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L539)

##### ecdsa\_public\_key

> **ecdsa\_public\_key**: `ActorMethod`\<\[[`ecdsa_public_key_args`](#ecdsa_public_key_args)\], [`ecdsa_public_key_result`](#ecdsa_public_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:543](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L543)

Threshold ECDSA signature

##### fetch\_canister\_logs

> **fetch\_canister\_logs**: `ActorMethod`\<\[[`fetch_canister_logs_args`](#fetch_canister_logs_args)\], [`fetch_canister_logs_result`](#fetch_canister_logs_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L550)

canister logging

##### http\_request

> **http\_request**: `ActorMethod`\<\[[`http_request_args`](#http_request_args)\], [`http_request_result`](#http_request_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:554](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L554)

##### install\_chunked\_code

> **install\_chunked\_code**: `ActorMethod`\<\[[`install_chunked_code_args`](#install_chunked_code_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L555)

##### install\_code

> **install\_code**: `ActorMethod`\<\[[`install_code_args`](#install_code_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L556)

##### list\_canister\_snapshots

> **list\_canister\_snapshots**: `ActorMethod`\<\[[`list_canister_snapshots_args`](#list_canister_snapshots_args)\], [`list_canister_snapshots_result`](#list_canister_snapshots_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L557)

##### load\_canister\_snapshot

> **load\_canister\_snapshot**: `ActorMethod`\<\[[`load_canister_snapshot_args`](#load_canister_snapshot_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L561)

##### node\_metrics\_history

> **node\_metrics\_history**: `ActorMethod`\<\[[`node_metrics_history_args`](#node_metrics_history_args)\], [`node_metrics_history_result`](#node_metrics_history_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L565)

metrics interface

##### provisional\_create\_canister\_with\_cycles

> **provisional\_create\_canister\_with\_cycles**: `ActorMethod`\<\[[`provisional_create_canister_with_cycles_args`](#provisional_create_canister_with_cycles_args)\], [`provisional_create_canister_with_cycles_result`](#provisional_create_canister_with_cycles_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L572)

provisional interfaces for the pre-ledger world

##### provisional\_top\_up\_canister

> **provisional\_top\_up\_canister**: `ActorMethod`\<\[[`provisional_top_up_canister_args`](#provisional_top_up_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L576)

##### raw\_rand

> **raw\_rand**: `ActorMethod`\<\[\], [`raw_rand_result`](#raw_rand_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L580)

##### read\_canister\_snapshot\_data

> **read\_canister\_snapshot\_data**: `ActorMethod`\<\[[`read_canister_snapshot_data_args`](#read_canister_snapshot_data_args)\], [`read_canister_snapshot_data_response`](#read_canister_snapshot_data_response)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L581)

##### read\_canister\_snapshot\_metadata

> **read\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`read_canister_snapshot_metadata_args`](#read_canister_snapshot_metadata_args)\], [`read_canister_snapshot_metadata_response`](#read_canister_snapshot_metadata_response)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L585)

##### schnorr\_public\_key

> **schnorr\_public\_key**: `ActorMethod`\<\[[`schnorr_public_key_args`](#schnorr_public_key_args)\], [`schnorr_public_key_result`](#schnorr_public_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L592)

Threshold Schnorr signature

##### sign\_with\_ecdsa

> **sign\_with\_ecdsa**: `ActorMethod`\<\[[`sign_with_ecdsa_args`](#sign_with_ecdsa_args)\], [`sign_with_ecdsa_result`](#sign_with_ecdsa_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L596)

##### sign\_with\_schnorr

> **sign\_with\_schnorr**: `ActorMethod`\<\[[`sign_with_schnorr_args`](#sign_with_schnorr_args)\], [`sign_with_schnorr_result`](#sign_with_schnorr_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:597](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L597)

##### start\_canister

> **start\_canister**: `ActorMethod`\<\[[`start_canister_args`](#start_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L601)

##### stop\_canister

> **stop\_canister**: `ActorMethod`\<\[[`stop_canister_args`](#stop_canister_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:602](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L602)

##### stored\_chunks

> **stored\_chunks**: `ActorMethod`\<\[[`stored_chunks_args`](#stored_chunks_args)\], [`stored_chunks_result`](#stored_chunks_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:603](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L603)

##### subnet\_info

> **subnet\_info**: `ActorMethod`\<\[[`subnet_info_args`](#subnet_info_args)\], [`subnet_info_result`](#subnet_info_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:607](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L607)

subnet info

##### take\_canister\_snapshot

> **take\_canister\_snapshot**: `ActorMethod`\<\[[`take_canister_snapshot_args`](#take_canister_snapshot_args)\], [`snapshot`](#snapshot)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L611)

Canister snapshots

##### uninstall\_code

> **uninstall\_code**: `ActorMethod`\<\[[`uninstall_code_args`](#uninstall_code_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L615)

##### update\_settings

> **update\_settings**: `ActorMethod`\<\[[`update_settings_args`](#update_settings_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L616)

##### upload\_canister\_snapshot\_data

> **upload\_canister\_snapshot\_data**: `ActorMethod`\<\[[`upload_canister_snapshot_data_args`](#upload_canister_snapshot_data_args)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L617)

##### upload\_canister\_snapshot\_metadata

> **upload\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`upload_canister_snapshot_metadata_args`](#upload_canister_snapshot_metadata_args)\], [`upload_canister_snapshot_metadata_response`](#upload_canister_snapshot_metadata_response)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L621)

##### upload\_chunk

> **upload\_chunk**: `ActorMethod`\<\[[`upload_chunk_args`](#upload_chunk_args)\], [`chunk_hash`](#chunk_hash)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L625)

##### vetkd\_derive\_key

> **vetkd\_derive\_key**: `ActorMethod`\<\[[`vetkd_derive_key_args`](#vetkd_derive_key_args)\], [`vetkd_derive_key_result`](#vetkd_derive_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L626)

##### vetkd\_public\_key

> **vetkd\_public\_key**: `ActorMethod`\<\[[`vetkd_public_key_args`](#vetkd_public_key_args)\], [`vetkd_public_key_result`](#vetkd_public_key_result)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:633](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L633)

Threshold key derivation

***

### bitcoin\_get\_balance\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L17)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L19)

##### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L20)

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L18)

***

### bitcoin\_get\_block\_headers\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L23)

#### Properties

##### end\_height

> **end\_height**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L25)

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L26)

##### start\_height

> **start\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L24)

***

### bitcoin\_get\_block\_headers\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L28)

#### Properties

##### block\_headers

> **block\_headers**: [`bitcoin_block_header`](#bitcoin_block_header)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L30)

##### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L29)

***

### bitcoin\_get\_current\_fee\_percentiles\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L32)

#### Properties

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L33)

***

### bitcoin\_get\_utxos\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L36)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L39)

##### filter

> **filter**: \[\] \| \[\{ `page`: `Uint8Array`; \} \| \{ `min_confirmations`: `number`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L38)

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L37)

***

### bitcoin\_get\_utxos\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L41)

#### Properties

##### next\_page

> **next\_page**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L42)

##### tip\_block\_hash

> **tip\_block\_hash**: [`bitcoin_block_hash`](#bitcoin_block_hash)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L44)

##### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L43)

##### utxos

> **utxos**: [`utxo`](#utxo)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L45)

***

### bitcoin\_send\_transaction\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L48)

#### Properties

##### network

> **network**: [`bitcoin_network`](#bitcoin_network)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L50)

##### transaction

> **transaction**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L49)

***

### canister\_info\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L53)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L54)

##### num\_requested\_changes

> **num\_requested\_changes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L55)

***

### canister\_info\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L57)

#### Properties

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L58)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L59)

##### recent\_changes

> **recent\_changes**: [`change`](#change)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L60)

##### total\_num\_changes

> **total\_num\_changes**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L61)

***

### canister\_log\_record

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L78)

#### Properties

##### content

> **content**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L81)

##### idx

> **idx**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L79)

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L80)

***

### canister\_metadata\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L83)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L85)

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L84)

***

### canister\_metadata\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L87)

#### Properties

##### value

> **value**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L88)

***

### canister\_settings

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L90)

#### Properties

##### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L100)

##### controllers

> **controllers**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L94)

##### environment\_variables

> **environment\_variables**: \[\] \| \[[`environment_variable`](#environment_variable)[]\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L93)

##### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L91)

##### log\_visibility

> **log\_visibility**: \[\] \| \[[`log_visibility`](#log_visibility-2)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L96)

##### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L99)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L95)

##### snapshot\_visibility

> **snapshot\_visibility**: \[\] \| \[[`snapshot_visibility`](#snapshot_visibility-2)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L97)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L98)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L92)

***

### canister\_status\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L102)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L103)

***

### canister\_status\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L105)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L120)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L128)

##### memory\_metrics

> **memory\_metrics**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L106)

###### canister\_history\_size

> **canister\_history\_size**: `bigint`

###### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

###### global\_memory\_size

> **global\_memory\_size**: `bigint`

###### snapshots\_size

> **snapshots\_size**: `bigint`

###### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

###### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

###### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

###### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L117)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L129)

##### query\_stats

> **query\_stats**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L122)

###### num\_calls\_total

> **num\_calls\_total**: `bigint`

###### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

###### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

###### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L118)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L130)

##### settings

> **settings**: [`definite_canister_settings`](#definite_canister_settings)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L121)

##### status

> **status**: \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L116)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L119)

***

### change

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L132)

#### Properties

##### canister\_version

> **canister\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L134)

##### details

> **details**: [`change_details`](#change_details)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L136)

##### origin

> **origin**: [`change_origin`](#change_origin)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L135)

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L133)

***

### chunk\_hash

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L182)

#### Properties

##### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:183](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L183)

***

### clear\_chunk\_store\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L185)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L186)

***

### create\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L188)

#### Properties

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L190)

##### settings

> **settings**: \[\] \| \[[`canister_settings`](#canister_settings)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L189)

***

### create\_canister\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L192)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:193](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L193)

***

### definite\_canister\_settings

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L195)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L205)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L199)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L198)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L196)

##### log\_visibility

> **log\_visibility**: [`log_visibility`](#log_visibility-2)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L201)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L204)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L200)

##### snapshot\_visibility

> **snapshot\_visibility**: [`snapshot_visibility`](#snapshot_visibility-2)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L202)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L203)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L197)

***

### delete\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L207)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L208)

***

### delete\_canister\_snapshot\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L210)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L211)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L212)

***

### deposit\_cycles\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L214)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L215)

***

### ecdsa\_public\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L218)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L220)

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L221)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L219)

###### curve

> **curve**: [`ecdsa_curve`](#ecdsa_curve)

###### name

> **name**: `string`

***

### ecdsa\_public\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L223)

#### Properties

##### chain\_code

> **chain\_code**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L225)

##### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L224)

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L227)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L229)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L228)

***

### fetch\_canister\_logs\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L231)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L232)

***

### fetch\_canister\_logs\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L234)

#### Properties

##### canister\_log\_records

> **canister\_log\_records**: [`canister_log_record`](#canister_log_record)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L235)

***

### http\_header

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L237)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L239)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L238)

***

### http\_request\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:241](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L241)

#### Properties

##### body

> **body**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L250)

##### headers

> **headers**: [`http_header`](#http_header)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L252)

##### is\_replicated

> **is\_replicated**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L253)

##### max\_response\_bytes

> **max\_response\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L249)

##### method

> **method**: \{ `get`: `null`; \} \| \{ `put`: `null`; \} \| \{ `head`: `null`; \} \| \{ `post`: `null`; \} \| \{ `delete`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:243](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L243)

##### transform

> **transform**: \[\] \| \[\{ `context`: `Uint8Array`; `function`: \[`Principal`, `string`\]; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L251)

##### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:242](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L242)

***

### http\_request\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L255)

#### Properties

##### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:257](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L257)

##### headers

> **headers**: [`http_header`](#http_header)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:258](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L258)

##### status

> **status**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:256](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L256)

***

### install\_chunked\_code\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L260)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L261)

##### chunk\_hashes\_list

> **chunk\_hashes\_list**: [`chunk_hash`](#chunk_hash)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L264)

##### mode

> **mode**: [`canister_install_mode`](#canister_install_mode)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:263](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L263)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L267)

##### store\_canister

> **store\_canister**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L266)

##### target\_canister

> **target\_canister**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L265)

##### wasm\_module\_hash

> **wasm\_module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L262)

***

### install\_code\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:269](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L269)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L270)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L273)

##### mode

> **mode**: [`canister_install_mode`](#canister_install_mode)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:272](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L272)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L274)

##### wasm\_module

> **wasm\_module**: [`wasm_module`](#wasm_module-1)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:271](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L271)

***

### list\_canister\_snapshots\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L276)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L277)

***

### load\_canister\_snapshot\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L280)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L281)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L282)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L283)

***

### node\_metrics

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L290)

#### Properties

##### node\_id

> **node\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L292)

##### num\_block\_failures\_total

> **num\_block\_failures\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L291)

##### num\_blocks\_proposed\_total

> **num\_blocks\_proposed\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L293)

***

### node\_metrics\_history\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L295)

#### Properties

##### start\_at\_timestamp\_nanos

> **start\_at\_timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L296)

##### subnet\_id

> **subnet\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L297)

***

### outpoint

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L303)

#### Properties

##### txid

> **txid**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L304)

##### vout

> **vout**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L305)

***

### provisional\_create\_canister\_with\_cycles\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L307)

#### Properties

##### amount

> **amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:310](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L310)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:311](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L311)

##### settings

> **settings**: \[\] \| \[[`canister_settings`](#canister_settings)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L308)

##### specified\_id

> **specified\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L309)

***

### provisional\_create\_canister\_with\_cycles\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L313)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L314)

***

### provisional\_top\_up\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L316)

#### Properties

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L318)

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L317)

***

### read\_canister\_snapshot\_data\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L321)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L327)

##### kind

> **kind**: \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L322)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L328)

***

### read\_canister\_snapshot\_data\_response

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L330)

#### Properties

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L331)

***

### read\_canister\_snapshot\_metadata\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L333)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L334)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L335)

***

### read\_canister\_snapshot\_metadata\_response

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L337)

#### Properties

##### canister\_version

> **canister\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L345)

##### certified\_data

> **certified\_data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L347)

##### global\_timer

> **global\_timer**: \[\] \| \[\{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L348)

##### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L338)

##### on\_low\_wasm\_memory\_hook\_status

> **on\_low\_wasm\_memory\_hook\_status**: \[\] \| \[\{ `condition_not_satisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L349)

##### source

> **source**: \{ `metadata_upload`: `any`; \} \| \{ `taken_from_canister`: `any`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L346)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L357)

##### taken\_at\_timestamp

> **taken\_at\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L359)

##### wasm\_chunk\_store

> **wasm\_chunk\_store**: `object`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L358)

###### hash

> **hash**: `Uint8Array`

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L360)

##### wasm\_module\_size

> **wasm\_module\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L356)

***

### schnorr\_public\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L365)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L367)

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L368)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L366)

###### algorithm

> **algorithm**: [`schnorr_algorithm`](#schnorr_algorithm)

###### name

> **name**: `string`

***

### schnorr\_public\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L370)

#### Properties

##### chain\_code

> **chain\_code**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L372)

##### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L371)

***

### sign\_with\_ecdsa\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L374)

#### Properties

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L376)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L375)

###### curve

> **curve**: [`ecdsa_curve`](#ecdsa_curve)

###### name

> **name**: `string`

##### message\_hash

> **message\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L377)

***

### sign\_with\_ecdsa\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L379)

#### Properties

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L380)

***

### sign\_with\_schnorr\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L382)

#### Properties

##### aux

> **aux**: \[\] \| \[[`schnorr_aux`](#schnorr_aux)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L383)

##### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L385)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L384)

###### algorithm

> **algorithm**: [`schnorr_algorithm`](#schnorr_algorithm)

###### name

> **name**: `string`

##### message

> **message**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:386](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L386)

***

### sign\_with\_schnorr\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L388)

#### Properties

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L389)

***

### snapshot

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L391)

#### Properties

##### id

> **id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L392)

##### taken\_at\_timestamp

> **taken\_at\_timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L394)

##### total\_size

> **total\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L393)

***

### start\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:401](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L401)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L402)

***

### stop\_canister\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L404)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:405](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L405)

***

### stored\_chunks\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L407)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L408)

***

### subnet\_info\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L411)

#### Properties

##### subnet\_id

> **subnet\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L412)

***

### subnet\_info\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L414)

#### Properties

##### registry\_version

> **registry\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L416)

##### replica\_version

> **replica\_version**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L415)

***

### take\_canister\_snapshot\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L418)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L420)

##### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[[`snapshot_id`](#snapshot_id-6)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L419)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L422)

##### uninstall\_code

> **uninstall\_code**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L421)

***

### uninstall\_code\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:425](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L425)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L426)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L427)

***

### update\_settings\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L429)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L430)

##### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L432)

##### settings

> **settings**: [`canister_settings`](#canister_settings)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L431)

***

### upload\_canister\_snapshot\_data\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:434](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L434)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L441)

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:435](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L435)

##### kind

> **kind**: \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L436)

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L442)

***

### upload\_canister\_snapshot\_metadata\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:444](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L444)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L463)

##### certified\_data

> **certified\_data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L453)

##### global\_timer

> **global\_timer**: \[\] \| \[\{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:454](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L454)

##### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:445](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L445)

##### on\_low\_wasm\_memory\_hook\_status

> **on\_low\_wasm\_memory\_hook\_status**: \[\] \| \[\{ `condition_not_satisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L455)

##### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[[`snapshot_id`](#snapshot_id-6)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L452)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L464)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L465)

##### wasm\_module\_size

> **wasm\_module\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L462)

***

### upload\_canister\_snapshot\_metadata\_response

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L467)

#### Properties

##### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](#snapshot_id-6)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L468)

***

### upload\_chunk\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L470)

#### Properties

##### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L472)

##### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L471)

***

### utxo

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L475)

#### Properties

##### height

> **height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L476)

##### outpoint

> **outpoint**: [`outpoint`](#outpoint)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L478)

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:477](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L477)

***

### vetkd\_derive\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L481)

#### Properties

##### context

> **context**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L482)

##### input

> **input**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L484)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L483)

###### curve

> **curve**: [`vetkd_curve`](#vetkd_curve)

###### name

> **name**: `string`

##### transport\_public\_key

> **transport\_public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:485](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L485)

***

### vetkd\_derive\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L487)

#### Properties

##### encrypted\_key

> **encrypted\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L488)

***

### vetkd\_public\_key\_args

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L490)

#### Properties

##### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L493)

##### context

> **context**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L491)

##### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L492)

###### curve

> **curve**: [`vetkd_curve`](#vetkd_curve)

###### name

> **name**: `string`

***

### vetkd\_public\_key\_result

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L495)

#### Properties

##### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L496)

## Type Aliases

### bitcoin\_address

> **bitcoin\_address** = `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L13)

***

### bitcoin\_block\_hash

> **bitcoin\_block\_hash** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L14)

***

### bitcoin\_block\_header

> **bitcoin\_block\_header** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L15)

***

### bitcoin\_block\_height

> **bitcoin\_block\_height** = `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L16)

***

### bitcoin\_get\_balance\_result

> **bitcoin\_get\_balance\_result** = [`satoshi`](#satoshi)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L22)

***

### bitcoin\_get\_current\_fee\_percentiles\_result

> **bitcoin\_get\_current\_fee\_percentiles\_result** = `BigUint64Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L35)

***

### bitcoin\_network

> **bitcoin\_network** = \{ `mainnet`: `null`; \} \| \{ `testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L47)

***

### canister\_id

> **canister\_id** = `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L52)

***

### canister\_install\_mode

> **canister\_install\_mode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; `wasm_memory_persistence`: \[\] \| \[\{ `keep`: `null`; \} \| \{ `replace`: `null`; \}\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L63)

***

### change\_details

> **change\_details** = \{ `creation`: \{ `controllers`: `Principal`[]; `environment_variables_hash`: \[\] \| \[`Uint8Array`\]; \}; \} \| \{ `code_deployment`: \{ `mode`: \{ `reinstall`: `null`; \} \| \{ `upgrade`: `null`; \} \| \{ `install`: `null`; \}; `module_hash`: `Uint8Array`; \}; \} \| \{ `load_snapshot`: \{ `canister_version`: `bigint`; `from_canister_id`: \[\] \| \[`Principal`\]; `snapshot_id`: [`snapshot_id`](#snapshot_id-6); `source`: \{ `metadata_upload`: `any`; \} \| \{ `taken_from_canister`: `any`; \}; `taken_at_timestamp`: `bigint`; \}; \} \| \{ `rename_canister`: \{ `canister_id`: [`canister_id`](#canister_id-28); `rename_to`: \{ `canister_id`: [`canister_id`](#canister_id-28); `total_num_changes`: `bigint`; `version`: `bigint`; \}; `requested_by`: `Principal`; `total_num_changes`: `bigint`; \}; \} \| \{ `controllers_change`: \{ `controllers`: `Principal`[]; \}; \} \| \{ `code_uninstall`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L138)

***

### change\_origin

> **change\_origin** = \{ `from_user`: \{ `user_id`: `Principal`; \}; \} \| \{ `from_canister`: \{ `canister_id`: [`canister_id`](#canister_id-28); `canister_version`: \[\] \| \[`bigint`\]; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:174](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L174)

***

### ecdsa\_curve

> **ecdsa\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L217)

#### Properties

##### secp256k1

> **secp256k1**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L217)

***

### list\_canister\_snapshots\_result

> **list\_canister\_snapshots\_result** = [`snapshot`](#snapshot)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:279](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L279)

***

### log\_visibility

> **log\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L285)

***

### millisatoshi\_per\_byte

> **millisatoshi\_per\_byte** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L289)

***

### node\_metrics\_history\_result

> **node\_metrics\_history\_result** = `object`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L299)

#### Type Declaration

##### node\_metrics

> **node\_metrics**: [`node_metrics`](#node_metrics)[]

##### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

***

### raw\_rand\_result

> **raw\_rand\_result** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L320)

***

### satoshi

> **satoshi** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L362)

***

### schnorr\_algorithm

> **schnorr\_algorithm** = \{ `ed25519`: `null`; \} \| \{ `bip340secp256k1`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L363)

***

### schnorr\_aux

> **schnorr\_aux** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L364)

#### Properties

##### bip341

> **bip341**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L364)

###### merkle\_root\_hash

> **merkle\_root\_hash**: `Uint8Array`

***

### snapshot\_id

> **snapshot\_id** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L396)

***

### snapshot\_visibility

> **snapshot\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L397)

***

### stored\_chunks\_result

> **stored\_chunks\_result** = [`chunk_hash`](#chunk_hash)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L410)

***

### take\_canister\_snapshot\_result

> **take\_canister\_snapshot\_result** = [`snapshot`](#snapshot)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L424)

***

### upload\_chunk\_result

> **upload\_chunk\_result** = [`chunk_hash`](#chunk_hash)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L474)

***

### vetkd\_curve

> **vetkd\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L480)

#### Properties

##### bls12\_381\_g2

> **bls12\_381\_g2**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L480)

***

### wasm\_module

> **wasm\_module** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L498)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:638](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L638)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:639](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L639)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
