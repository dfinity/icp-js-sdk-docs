---
title: bitcoin_address
editUrl: false
next: true
prev: true
---

> **bitcoin\_address** = `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L13)
