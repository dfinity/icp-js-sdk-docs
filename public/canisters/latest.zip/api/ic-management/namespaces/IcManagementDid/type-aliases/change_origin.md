---
title: change_origin
editUrl: false
next: true
prev: true
---

> **change\_origin** = \{ `from_user`: \{ `user_id`: `Principal`; \}; \} \| \{ `from_canister`: \{ `canister_id`: `Principal`; `canister_version`: \[\] \| \[`bigint`\]; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L161)
