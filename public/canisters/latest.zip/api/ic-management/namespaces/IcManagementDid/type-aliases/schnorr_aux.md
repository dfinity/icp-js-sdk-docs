---
title: schnorr_aux
editUrl: false
next: true
prev: true
---

> **schnorr\_aux** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L345)

## Properties

### bip341

> **bip341**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L345)

#### merkle\_root\_hash

> **merkle\_root\_hash**: `Uint8Array`
