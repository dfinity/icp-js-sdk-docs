---
title: bitcoin_network
editUrl: false
next: true
prev: true
---

> **bitcoin\_network** = \{ `mainnet`: `null`; \} \| \{ `testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L47)
