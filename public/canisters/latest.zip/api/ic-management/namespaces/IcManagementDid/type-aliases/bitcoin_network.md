---
title: bitcoin_network
editUrl: false
next: true
prev: true
---

> **bitcoin\_network** = \{ `mainnet`: `null`; \} \| \{ `testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L47)
