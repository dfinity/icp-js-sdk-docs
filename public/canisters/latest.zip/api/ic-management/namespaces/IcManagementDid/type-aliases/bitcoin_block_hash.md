---
title: bitcoin_block_hash
editUrl: false
next: true
prev: true
---

> **bitcoin\_block\_hash** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L14)
