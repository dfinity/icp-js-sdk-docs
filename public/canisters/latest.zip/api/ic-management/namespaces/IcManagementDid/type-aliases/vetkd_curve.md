---
title: vetkd_curve
editUrl: false
next: true
prev: true
---

> **vetkd\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L457)

## Properties

### bls12\_381\_g2

> **bls12\_381\_g2**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:457](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L457)
