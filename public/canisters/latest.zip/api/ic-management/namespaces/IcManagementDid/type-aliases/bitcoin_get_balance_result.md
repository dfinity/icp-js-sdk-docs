---
title: bitcoin_get_balance_result
editUrl: false
next: true
prev: true
---

> **bitcoin\_get\_balance\_result** = [`satoshi`](satoshi.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L22)
