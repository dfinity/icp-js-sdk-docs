---
title: bitcoin_get_balance_result
editUrl: false
next: true
prev: true
---

> **bitcoin\_get\_balance\_result** = [`satoshi`](satoshi.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L22)
