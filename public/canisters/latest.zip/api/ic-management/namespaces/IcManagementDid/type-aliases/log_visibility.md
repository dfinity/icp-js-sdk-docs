---
title: log_visibility
editUrl: false
next: true
prev: true
---

> **log\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L266)
