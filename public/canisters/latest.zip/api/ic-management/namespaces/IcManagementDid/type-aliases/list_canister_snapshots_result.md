---
title: list_canister_snapshots_result
editUrl: false
next: true
prev: true
---

> **list\_canister\_snapshots\_result** = [`snapshot`](../interfaces/snapshot.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L260)
