---
title: canister_install_mode
editUrl: false
next: true
prev: true
---

> **canister\_install\_mode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; `wasm_memory_persistence`: \[\] \| \[\{ `keep`: `null`; \} \| \{ `replace`: `null`; \}\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L63)
