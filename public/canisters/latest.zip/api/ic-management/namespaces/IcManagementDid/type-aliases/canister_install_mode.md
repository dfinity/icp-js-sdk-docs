---
title: canister_install_mode
editUrl: false
next: true
prev: true
---

> **canister\_install\_mode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; `wasm_memory_persistence`: \[\] \| \[\{ `keep`: `null`; \} \| \{ `replace`: `null`; \}\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L63)
