---
title: schnorr_algorithm
editUrl: false
next: true
prev: true
---

> **schnorr\_algorithm** = \{ `ed25519`: `null`; \} \| \{ `bip340secp256k1`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L344)
