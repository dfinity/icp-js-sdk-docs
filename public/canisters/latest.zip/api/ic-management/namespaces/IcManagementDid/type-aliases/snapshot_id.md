---
title: snapshot_id
editUrl: false
next: true
prev: true
---

> **snapshot\_id** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L377)
