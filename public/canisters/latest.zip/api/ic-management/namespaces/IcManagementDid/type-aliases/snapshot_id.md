---
title: snapshot_id
editUrl: false
next: true
prev: true
---

> **snapshot\_id** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L377)
