---
title: bitcoin_block_header
editUrl: false
next: true
prev: true
---

> **bitcoin\_block\_header** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L15)
