---
title: millisatoshi_per_byte
editUrl: false
next: true
prev: true
---

> **millisatoshi\_per\_byte** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L270)
