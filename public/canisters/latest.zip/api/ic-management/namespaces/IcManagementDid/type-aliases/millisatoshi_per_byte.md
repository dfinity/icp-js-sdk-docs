---
title: millisatoshi_per_byte
editUrl: false
next: true
prev: true
---

> **millisatoshi\_per\_byte** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L270)
