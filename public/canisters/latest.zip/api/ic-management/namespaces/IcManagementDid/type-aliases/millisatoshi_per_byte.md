---
title: millisatoshi_per_byte
editUrl: false
next: true
prev: true
---

> **millisatoshi\_per\_byte** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:270](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L270)
