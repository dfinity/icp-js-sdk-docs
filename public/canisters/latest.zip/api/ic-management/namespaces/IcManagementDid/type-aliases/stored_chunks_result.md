---
title: stored_chunks_result
editUrl: false
next: true
prev: true
---

> **stored\_chunks\_result** = [`chunk_hash`](../interfaces/chunk_hash.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L387)
