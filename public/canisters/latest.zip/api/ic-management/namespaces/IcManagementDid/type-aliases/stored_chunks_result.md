---
title: stored_chunks_result
editUrl: false
next: true
prev: true
---

> **stored\_chunks\_result** = [`chunk_hash`](../interfaces/chunk_hash.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L387)
