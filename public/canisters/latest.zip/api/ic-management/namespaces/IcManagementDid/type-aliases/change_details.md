---
title: change_details
editUrl: false
next: true
prev: true
---

> **change\_details** = \{ `creation`: \{ `controllers`: `Principal`[]; `environment_variables_hash`: \[\] \| \[`Uint8Array`\]; \}; \} \| \{ `code_deployment`: \{ `mode`: \{ `reinstall`: `null`; \} \| \{ `upgrade`: `null`; \} \| \{ `install`: `null`; \}; `module_hash`: `Uint8Array`; \}; \} \| \{ `load_snapshot`: \{ `canister_version`: `bigint`; `from_canister_id`: \[\] \| \[`Principal`\]; `snapshot_id`: [`snapshot_id`](snapshot_id.md); `source`: \{ `metadata_upload`: `any`; \} \| \{ `taken_from_canister`: `any`; \}; `taken_at_timestamp`: `bigint`; \}; \} \| \{ `controllers_change`: \{ `controllers`: `Principal`[]; \}; \} \| \{ `code_uninstall`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L137)
