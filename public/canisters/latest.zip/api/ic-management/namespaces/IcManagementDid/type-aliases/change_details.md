---
title: change_details
editUrl: false
next: true
prev: true
---

> **change\_details** = \{ `creation`: \{ `controllers`: `Principal`[]; `environment_variables_hash`: \[\] \| \[`Uint8Array`\]; \}; \} \| \{ `code_deployment`: \{ `mode`: \{ `reinstall`: `null`; \} \| \{ `upgrade`: `null`; \} \| \{ `install`: `null`; \}; `module_hash`: `Uint8Array`; \}; \} \| \{ `load_snapshot`: \{ `canister_version`: `bigint`; `from_canister_id`: \[\] \| \[`Principal`\]; `snapshot_id`: [`snapshot_id`](snapshot_id.md); `source`: \{ `metadata_upload`: `any`; \} \| \{ `taken_from_canister`: `any`; \}; `taken_at_timestamp`: `bigint`; \}; \} \| \{ `controllers_change`: \{ `controllers`: `Principal`[]; \}; \} \| \{ `code_uninstall`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L137)
