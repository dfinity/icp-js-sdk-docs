---
title: take_canister_snapshot_result
editUrl: false
next: true
prev: true
---

> **take\_canister\_snapshot\_result** = [`snapshot`](../interfaces/snapshot.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:399](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L399)
