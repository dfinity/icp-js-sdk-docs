---
title: satoshi
editUrl: false
next: true
prev: true
---

> **satoshi** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L343)
