---
title: satoshi
editUrl: false
next: true
prev: true
---

> **satoshi** = `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L343)
