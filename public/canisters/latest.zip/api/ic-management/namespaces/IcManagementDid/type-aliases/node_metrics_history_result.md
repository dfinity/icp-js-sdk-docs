---
title: node_metrics_history_result
editUrl: false
next: true
prev: true
---

> **node\_metrics\_history\_result** = `object`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L280)

## Type Declaration

### node\_metrics

> **node\_metrics**: [`node_metrics`](../interfaces/node_metrics.md)[]

### timestamp\_nanos

> **timestamp\_nanos**: `bigint`
