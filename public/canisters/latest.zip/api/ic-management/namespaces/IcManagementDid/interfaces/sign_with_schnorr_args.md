---
title: sign_with_schnorr_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L363)

## Properties

### aux

> **aux**: \[\] \| \[[`schnorr_aux`](../type-aliases/schnorr_aux.md)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L364)

***

### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L366)

***

### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L365)

#### algorithm

> **algorithm**: [`schnorr_algorithm`](../type-aliases/schnorr_algorithm.md)

#### name

> **name**: `string`

***

### message

> **message**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:367](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L367)
