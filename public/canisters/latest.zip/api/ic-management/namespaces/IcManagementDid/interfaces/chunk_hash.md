---
title: chunk_hash
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L169)

## Properties

### hash

> **hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L170)
