---
title: vetkd_public_key_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L465)

## Properties

### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L468)

***

### context

> **context**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L466)

***

### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L467)

#### curve

> **curve**: [`vetkd_curve`](../type-aliases/vetkd_curve.md)

#### name

> **name**: `string`
