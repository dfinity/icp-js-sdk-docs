---
title: canister_info_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L57)

## Properties

### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L58)

***

### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L59)

***

### recent\_changes

> **recent\_changes**: [`change`](change.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L60)

***

### total\_num\_changes

> **total\_num\_changes**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L61)
