---
title: change
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L131)

## Properties

### canister\_version

> **canister\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L133)

***

### details

> **details**: [`change_details`](../type-aliases/change_details.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L135)

***

### origin

> **origin**: [`change_origin`](../type-aliases/change_origin.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L134)

***

### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L132)
