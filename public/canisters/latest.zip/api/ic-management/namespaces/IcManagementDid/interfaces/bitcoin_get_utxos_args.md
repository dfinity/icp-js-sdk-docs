---
title: bitcoin_get_utxos_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L36)

## Properties

### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L39)

***

### filter

> **filter**: \[\] \| \[\{ `page`: `Uint8Array`; \} \| \{ `min_confirmations`: `number`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L38)

***

### network

> **network**: [`bitcoin_network`](../type-aliases/bitcoin_network.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L37)
