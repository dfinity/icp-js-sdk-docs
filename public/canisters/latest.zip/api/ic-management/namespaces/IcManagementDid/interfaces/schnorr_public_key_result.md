---
title: schnorr_public_key_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L351)

## Properties

### chain\_code

> **chain\_code**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L353)

***

### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L352)
