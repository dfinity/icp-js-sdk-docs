---
title: schnorr_public_key_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L351)

## Properties

### chain\_code

> **chain\_code**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L353)

***

### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L352)
