---
title: uninstall_code_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L402)

## Properties

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L403)

***

### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L404)
