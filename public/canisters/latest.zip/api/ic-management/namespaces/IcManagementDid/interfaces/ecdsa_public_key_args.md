---
title: ecdsa_public_key_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L204)

## Properties

### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L206)

***

### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L207)

***

### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L205)

#### curve

> **curve**: [`ecdsa_curve`](../type-aliases/ecdsa_curve.md)

#### name

> **name**: `string`
