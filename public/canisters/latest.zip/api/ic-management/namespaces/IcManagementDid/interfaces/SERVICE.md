---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L476)

## Properties

### bitcoin\_get\_balance

> **bitcoin\_get\_balance**: `ActorMethod`\<\[[`bitcoin_get_balance_args`](bitcoin_get_balance_args.md)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:480](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L480)

bitcoin interface

***

### bitcoin\_get\_block\_headers

> **bitcoin\_get\_block\_headers**: `ActorMethod`\<\[[`bitcoin_get_block_headers_args`](bitcoin_get_block_headers_args.md)\], [`bitcoin_get_block_headers_result`](bitcoin_get_block_headers_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L484)

***

### bitcoin\_get\_current\_fee\_percentiles

> **bitcoin\_get\_current\_fee\_percentiles**: `ActorMethod`\<\[[`bitcoin_get_current_fee_percentiles_args`](bitcoin_get_current_fee_percentiles_args.md)\], [`bitcoin_get_current_fee_percentiles_result`](../type-aliases/bitcoin_get_current_fee_percentiles_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:488](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L488)

***

### bitcoin\_get\_utxos

> **bitcoin\_get\_utxos**: `ActorMethod`\<\[[`bitcoin_get_utxos_args`](bitcoin_get_utxos_args.md)\], [`bitcoin_get_utxos_result`](bitcoin_get_utxos_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L492)

***

### bitcoin\_send\_transaction

> **bitcoin\_send\_transaction**: `ActorMethod`\<\[[`bitcoin_send_transaction_args`](bitcoin_send_transaction_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L496)

***

### canister\_info

> **canister\_info**: `ActorMethod`\<\[[`canister_info_args`](canister_info_args.md)\], [`canister_info_result`](canister_info_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L503)

Public canister data

***

### canister\_metadata

> **canister\_metadata**: `ActorMethod`\<\[[`canister_metadata_args`](canister_metadata_args.md)\], [`canister_metadata_result`](canister_metadata_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L504)

***

### canister\_status

> **canister\_status**: `ActorMethod`\<\[[`canister_status_args`](canister_status_args.md)\], [`canister_status_result`](canister_status_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L508)

***

### clear\_chunk\_store

> **clear\_chunk\_store**: `ActorMethod`\<\[[`clear_chunk_store_args`](clear_chunk_store_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L509)

***

### create\_canister

> **create\_canister**: `ActorMethod`\<\[[`create_canister_args`](create_canister_args.md)\], [`create_canister_result`](create_canister_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L510)

***

### delete\_canister

> **delete\_canister**: `ActorMethod`\<\[[`delete_canister_args`](delete_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:511](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L511)

***

### delete\_canister\_snapshot

> **delete\_canister\_snapshot**: `ActorMethod`\<\[[`delete_canister_snapshot_args`](delete_canister_snapshot_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L512)

***

### deposit\_cycles

> **deposit\_cycles**: `ActorMethod`\<\[[`deposit_cycles_args`](deposit_cycles_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:516](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L516)

***

### ecdsa\_public\_key

> **ecdsa\_public\_key**: `ActorMethod`\<\[[`ecdsa_public_key_args`](ecdsa_public_key_args.md)\], [`ecdsa_public_key_result`](ecdsa_public_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:520](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L520)

Threshold ECDSA signature

***

### fetch\_canister\_logs

> **fetch\_canister\_logs**: `ActorMethod`\<\[[`fetch_canister_logs_args`](fetch_canister_logs_args.md)\], [`fetch_canister_logs_result`](fetch_canister_logs_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L527)

canister logging

***

### http\_request

> **http\_request**: `ActorMethod`\<\[[`http_request_args`](http_request_args.md)\], [`http_request_result`](http_request_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L531)

***

### install\_chunked\_code

> **install\_chunked\_code**: `ActorMethod`\<\[[`install_chunked_code_args`](install_chunked_code_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L532)

***

### install\_code

> **install\_code**: `ActorMethod`\<\[[`install_code_args`](install_code_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:533](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L533)

***

### list\_canister\_snapshots

> **list\_canister\_snapshots**: `ActorMethod`\<\[[`list_canister_snapshots_args`](list_canister_snapshots_args.md)\], [`list_canister_snapshots_result`](../type-aliases/list_canister_snapshots_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:534](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L534)

***

### load\_canister\_snapshot

> **load\_canister\_snapshot**: `ActorMethod`\<\[[`load_canister_snapshot_args`](load_canister_snapshot_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:538](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L538)

***

### node\_metrics\_history

> **node\_metrics\_history**: `ActorMethod`\<\[[`node_metrics_history_args`](node_metrics_history_args.md)\], [`node_metrics_history_result`](../type-aliases/node_metrics_history_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:542](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L542)

metrics interface

***

### provisional\_create\_canister\_with\_cycles

> **provisional\_create\_canister\_with\_cycles**: `ActorMethod`\<\[[`provisional_create_canister_with_cycles_args`](provisional_create_canister_with_cycles_args.md)\], [`provisional_create_canister_with_cycles_result`](provisional_create_canister_with_cycles_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L549)

provisional interfaces for the pre-ledger world

***

### provisional\_top\_up\_canister

> **provisional\_top\_up\_canister**: `ActorMethod`\<\[[`provisional_top_up_canister_args`](provisional_top_up_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:553](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L553)

***

### raw\_rand

> **raw\_rand**: `ActorMethod`\<\[\], [`raw_rand_result`](../type-aliases/raw_rand_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L557)

***

### read\_canister\_snapshot\_data

> **read\_canister\_snapshot\_data**: `ActorMethod`\<\[[`read_canister_snapshot_data_args`](read_canister_snapshot_data_args.md)\], [`read_canister_snapshot_data_response`](read_canister_snapshot_data_response.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:558](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L558)

***

### read\_canister\_snapshot\_metadata

> **read\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`read_canister_snapshot_metadata_args`](read_canister_snapshot_metadata_args.md)\], [`read_canister_snapshot_metadata_response`](read_canister_snapshot_metadata_response.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:562](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L562)

***

### schnorr\_public\_key

> **schnorr\_public\_key**: `ActorMethod`\<\[[`schnorr_public_key_args`](schnorr_public_key_args.md)\], [`schnorr_public_key_result`](schnorr_public_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L569)

Threshold Schnorr signature

***

### sign\_with\_ecdsa

> **sign\_with\_ecdsa**: `ActorMethod`\<\[[`sign_with_ecdsa_args`](sign_with_ecdsa_args.md)\], [`sign_with_ecdsa_result`](sign_with_ecdsa_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L573)

***

### sign\_with\_schnorr

> **sign\_with\_schnorr**: `ActorMethod`\<\[[`sign_with_schnorr_args`](sign_with_schnorr_args.md)\], [`sign_with_schnorr_result`](sign_with_schnorr_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L574)

***

### start\_canister

> **start\_canister**: `ActorMethod`\<\[[`start_canister_args`](start_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L578)

***

### stop\_canister

> **stop\_canister**: `ActorMethod`\<\[[`stop_canister_args`](stop_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L579)

***

### stored\_chunks

> **stored\_chunks**: `ActorMethod`\<\[[`stored_chunks_args`](stored_chunks_args.md)\], [`stored_chunks_result`](../type-aliases/stored_chunks_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L580)

***

### subnet\_info

> **subnet\_info**: `ActorMethod`\<\[[`subnet_info_args`](subnet_info_args.md)\], [`subnet_info_result`](subnet_info_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L584)

subnet info

***

### take\_canister\_snapshot

> **take\_canister\_snapshot**: `ActorMethod`\<\[[`take_canister_snapshot_args`](take_canister_snapshot_args.md)\], [`snapshot`](snapshot.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:588](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L588)

Canister snapshots

***

### uninstall\_code

> **uninstall\_code**: `ActorMethod`\<\[[`uninstall_code_args`](uninstall_code_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L592)

***

### update\_settings

> **update\_settings**: `ActorMethod`\<\[[`update_settings_args`](update_settings_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:593](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L593)

***

### upload\_canister\_snapshot\_data

> **upload\_canister\_snapshot\_data**: `ActorMethod`\<\[[`upload_canister_snapshot_data_args`](upload_canister_snapshot_data_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:594](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L594)

***

### upload\_canister\_snapshot\_metadata

> **upload\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`upload_canister_snapshot_metadata_args`](upload_canister_snapshot_metadata_args.md)\], [`upload_canister_snapshot_metadata_response`](upload_canister_snapshot_metadata_response.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:598](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L598)

***

### upload\_chunk

> **upload\_chunk**: `ActorMethod`\<\[[`upload_chunk_args`](upload_chunk_args.md)\], [`chunk_hash`](chunk_hash.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:602](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L602)

***

### vetkd\_derive\_key

> **vetkd\_derive\_key**: `ActorMethod`\<\[[`vetkd_derive_key_args`](vetkd_derive_key_args.md)\], [`vetkd_derive_key_result`](vetkd_derive_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:603](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L603)

***

### vetkd\_public\_key

> **vetkd\_public\_key**: `ActorMethod`\<\[[`vetkd_public_key_args`](vetkd_public_key_args.md)\], [`vetkd_public_key_result`](vetkd_public_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L610)

Threshold key derivation
