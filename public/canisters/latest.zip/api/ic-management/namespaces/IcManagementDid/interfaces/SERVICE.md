---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L474)

## Properties

### bitcoin\_get\_balance

> **bitcoin\_get\_balance**: `ActorMethod`\<\[[`bitcoin_get_balance_args`](bitcoin_get_balance_args.md)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L478)

bitcoin interface

***

### bitcoin\_get\_block\_headers

> **bitcoin\_get\_block\_headers**: `ActorMethod`\<\[[`bitcoin_get_block_headers_args`](bitcoin_get_block_headers_args.md)\], [`bitcoin_get_block_headers_result`](bitcoin_get_block_headers_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L482)

***

### bitcoin\_get\_current\_fee\_percentiles

> **bitcoin\_get\_current\_fee\_percentiles**: `ActorMethod`\<\[[`bitcoin_get_current_fee_percentiles_args`](bitcoin_get_current_fee_percentiles_args.md)\], [`bitcoin_get_current_fee_percentiles_result`](../type-aliases/bitcoin_get_current_fee_percentiles_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L486)

***

### bitcoin\_get\_utxos

> **bitcoin\_get\_utxos**: `ActorMethod`\<\[[`bitcoin_get_utxos_args`](bitcoin_get_utxos_args.md)\], [`bitcoin_get_utxos_result`](bitcoin_get_utxos_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:490](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L490)

***

### bitcoin\_send\_transaction

> **bitcoin\_send\_transaction**: `ActorMethod`\<\[[`bitcoin_send_transaction_args`](bitcoin_send_transaction_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L494)

***

### canister\_info

> **canister\_info**: `ActorMethod`\<\[[`canister_info_args`](canister_info_args.md)\], [`canister_info_result`](canister_info_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L501)

Public canister data

***

### canister\_metadata

> **canister\_metadata**: `ActorMethod`\<\[[`canister_metadata_args`](canister_metadata_args.md)\], [`canister_metadata_result`](canister_metadata_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L502)

***

### canister\_status

> **canister\_status**: `ActorMethod`\<\[[`canister_status_args`](canister_status_args.md)\], [`canister_status_result`](canister_status_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L506)

***

### clear\_chunk\_store

> **clear\_chunk\_store**: `ActorMethod`\<\[[`clear_chunk_store_args`](clear_chunk_store_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:507](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L507)

***

### create\_canister

> **create\_canister**: `ActorMethod`\<\[[`create_canister_args`](create_canister_args.md)\], [`create_canister_result`](create_canister_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L508)

***

### delete\_canister

> **delete\_canister**: `ActorMethod`\<\[[`delete_canister_args`](delete_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L509)

***

### delete\_canister\_snapshot

> **delete\_canister\_snapshot**: `ActorMethod`\<\[[`delete_canister_snapshot_args`](delete_canister_snapshot_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:510](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L510)

***

### deposit\_cycles

> **deposit\_cycles**: `ActorMethod`\<\[[`deposit_cycles_args`](deposit_cycles_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:514](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L514)

***

### ecdsa\_public\_key

> **ecdsa\_public\_key**: `ActorMethod`\<\[[`ecdsa_public_key_args`](ecdsa_public_key_args.md)\], [`ecdsa_public_key_result`](ecdsa_public_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L518)

Threshold ECDSA signature

***

### fetch\_canister\_logs

> **fetch\_canister\_logs**: `ActorMethod`\<\[[`fetch_canister_logs_args`](fetch_canister_logs_args.md)\], [`fetch_canister_logs_result`](fetch_canister_logs_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:525](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L525)

canister logging

***

### http\_request

> **http\_request**: `ActorMethod`\<\[[`http_request_args`](http_request_args.md)\], [`http_request_result`](http_request_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L529)

***

### install\_chunked\_code

> **install\_chunked\_code**: `ActorMethod`\<\[[`install_chunked_code_args`](install_chunked_code_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L530)

***

### install\_code

> **install\_code**: `ActorMethod`\<\[[`install_code_args`](install_code_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L531)

***

### list\_canister\_snapshots

> **list\_canister\_snapshots**: `ActorMethod`\<\[[`list_canister_snapshots_args`](list_canister_snapshots_args.md)\], [`list_canister_snapshots_result`](../type-aliases/list_canister_snapshots_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L532)

***

### load\_canister\_snapshot

> **load\_canister\_snapshot**: `ActorMethod`\<\[[`load_canister_snapshot_args`](load_canister_snapshot_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:536](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L536)

***

### node\_metrics\_history

> **node\_metrics\_history**: `ActorMethod`\<\[[`node_metrics_history_args`](node_metrics_history_args.md)\], [`node_metrics_history_result`](../type-aliases/node_metrics_history_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:540](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L540)

metrics interface

***

### provisional\_create\_canister\_with\_cycles

> **provisional\_create\_canister\_with\_cycles**: `ActorMethod`\<\[[`provisional_create_canister_with_cycles_args`](provisional_create_canister_with_cycles_args.md)\], [`provisional_create_canister_with_cycles_result`](provisional_create_canister_with_cycles_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:547](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L547)

provisional interfaces for the pre-ledger world

***

### provisional\_top\_up\_canister

> **provisional\_top\_up\_canister**: `ActorMethod`\<\[[`provisional_top_up_canister_args`](provisional_top_up_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L551)

***

### raw\_rand

> **raw\_rand**: `ActorMethod`\<\[\], [`raw_rand_result`](../type-aliases/raw_rand_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:555](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L555)

***

### read\_canister\_snapshot\_data

> **read\_canister\_snapshot\_data**: `ActorMethod`\<\[[`read_canister_snapshot_data_args`](read_canister_snapshot_data_args.md)\], [`read_canister_snapshot_data_response`](read_canister_snapshot_data_response.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L556)

***

### read\_canister\_snapshot\_metadata

> **read\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`read_canister_snapshot_metadata_args`](read_canister_snapshot_metadata_args.md)\], [`read_canister_snapshot_metadata_response`](read_canister_snapshot_metadata_response.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L560)

***

### schnorr\_public\_key

> **schnorr\_public\_key**: `ActorMethod`\<\[[`schnorr_public_key_args`](schnorr_public_key_args.md)\], [`schnorr_public_key_result`](schnorr_public_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:567](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L567)

Threshold Schnorr signature

***

### sign\_with\_ecdsa

> **sign\_with\_ecdsa**: `ActorMethod`\<\[[`sign_with_ecdsa_args`](sign_with_ecdsa_args.md)\], [`sign_with_ecdsa_result`](sign_with_ecdsa_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L571)

***

### sign\_with\_schnorr

> **sign\_with\_schnorr**: `ActorMethod`\<\[[`sign_with_schnorr_args`](sign_with_schnorr_args.md)\], [`sign_with_schnorr_result`](sign_with_schnorr_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L572)

***

### start\_canister

> **start\_canister**: `ActorMethod`\<\[[`start_canister_args`](start_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L576)

***

### stop\_canister

> **stop\_canister**: `ActorMethod`\<\[[`stop_canister_args`](stop_canister_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L577)

***

### stored\_chunks

> **stored\_chunks**: `ActorMethod`\<\[[`stored_chunks_args`](stored_chunks_args.md)\], [`stored_chunks_result`](../type-aliases/stored_chunks_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L578)

***

### subnet\_info

> **subnet\_info**: `ActorMethod`\<\[[`subnet_info_args`](subnet_info_args.md)\], [`subnet_info_result`](subnet_info_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:582](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L582)

subnet info

***

### take\_canister\_snapshot

> **take\_canister\_snapshot**: `ActorMethod`\<\[[`take_canister_snapshot_args`](take_canister_snapshot_args.md)\], [`snapshot`](snapshot.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:586](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L586)

Canister snapshots

***

### uninstall\_code

> **uninstall\_code**: `ActorMethod`\<\[[`uninstall_code_args`](uninstall_code_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:590](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L590)

***

### update\_settings

> **update\_settings**: `ActorMethod`\<\[[`update_settings_args`](update_settings_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L591)

***

### upload\_canister\_snapshot\_data

> **upload\_canister\_snapshot\_data**: `ActorMethod`\<\[[`upload_canister_snapshot_data_args`](upload_canister_snapshot_data_args.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L592)

***

### upload\_canister\_snapshot\_metadata

> **upload\_canister\_snapshot\_metadata**: `ActorMethod`\<\[[`upload_canister_snapshot_metadata_args`](upload_canister_snapshot_metadata_args.md)\], [`upload_canister_snapshot_metadata_response`](upload_canister_snapshot_metadata_response.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L596)

***

### upload\_chunk

> **upload\_chunk**: `ActorMethod`\<\[[`upload_chunk_args`](upload_chunk_args.md)\], [`chunk_hash`](chunk_hash.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:600](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L600)

***

### vetkd\_derive\_key

> **vetkd\_derive\_key**: `ActorMethod`\<\[[`vetkd_derive_key_args`](vetkd_derive_key_args.md)\], [`vetkd_derive_key_result`](vetkd_derive_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L601)

***

### vetkd\_public\_key

> **vetkd\_public\_key**: `ActorMethod`\<\[[`vetkd_public_key_args`](vetkd_public_key_args.md)\], [`vetkd_public_key_result`](vetkd_public_key_result.md)\>

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:608](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L608)

Threshold key derivation
