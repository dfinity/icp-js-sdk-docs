---
title: subnet_info_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L391)

## Properties

### registry\_version

> **registry\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L393)

***

### replica\_version

> **replica\_version**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L392)
