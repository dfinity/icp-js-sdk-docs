---
title: subnet_info_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L391)

## Properties

### registry\_version

> **registry\_version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L393)

***

### replica\_version

> **replica\_version**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L392)
