---
title: upload_canister_snapshot_data_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L409)

## Properties

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L416)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L410)

***

### kind

> **kind**: \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L411)

***

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L417)
