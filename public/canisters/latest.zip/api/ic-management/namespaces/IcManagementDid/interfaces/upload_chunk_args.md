---
title: upload_chunk_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:447](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L447)

## Properties

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L449)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L448)
