---
title: canister_status_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L104)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:119](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L119)

***

### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L127)

***

### memory\_metrics

> **memory\_metrics**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L105)

#### canister\_history\_size

> **canister\_history\_size**: `bigint`

#### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

#### global\_memory\_size

> **global\_memory\_size**: `bigint`

#### snapshots\_size

> **snapshots\_size**: `bigint`

#### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

#### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

#### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

#### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

***

### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L116)

***

### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L128)

***

### query\_stats

> **query\_stats**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L121)

#### num\_calls\_total

> **num\_calls\_total**: `bigint`

#### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

#### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

#### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

***

### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L117)

***

### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L129)

***

### settings

> **settings**: [`definite_canister_settings`](definite_canister_settings.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L120)

***

### status

> **status**: \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L115)

***

### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L118)
