---
title: install_code_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:250](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L250)

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L251)

***

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:254](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L254)

***

### mode

> **mode**: [`canister_install_mode`](../type-aliases/canister_install_mode.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:253](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L253)

***

### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:255](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L255)

***

### wasm\_module

> **wasm\_module**: [`wasm_module`](../type-aliases/wasm_module.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:252](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L252)
