---
title: bitcoin_get_block_headers_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L23)

## Properties

### end\_height

> **end\_height**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L25)

***

### network

> **network**: [`bitcoin_network`](../type-aliases/bitcoin_network.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L26)

***

### start\_height

> **start\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L24)
