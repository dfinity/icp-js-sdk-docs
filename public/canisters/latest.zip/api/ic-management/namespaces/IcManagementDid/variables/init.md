---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L616)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
