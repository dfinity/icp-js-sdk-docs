---
title: ClearChunkStoreParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:85](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L85)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:86](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L86)
