---
title: UploadChunkParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:78](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/ic-management.params.ts#L78)

## Extends

- `Pick`\<[`upload_chunk_args`](../namespaces/IcManagementDid/interfaces/upload_chunk_args.md), `"chunk"`\>

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:82](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/ic-management.params.ts#L82)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L448)

#### Inherited from

[`upload_chunk_args`](../namespaces/IcManagementDid/interfaces/upload_chunk_args.md).[`chunk`](../namespaces/IcManagementDid/interfaces/upload_chunk_args.md#chunk)
