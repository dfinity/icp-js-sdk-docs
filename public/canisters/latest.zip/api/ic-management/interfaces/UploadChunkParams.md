---
title: UploadChunkParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:78](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L78)

## Extends

- `Pick`\<[`upload_chunk_args`](../namespaces/IcManagementDid/interfaces/upload_chunk_args.md), `"chunk"`\>

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:82](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L82)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:448](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L448)

#### Inherited from

[`upload_chunk_args`](../namespaces/IcManagementDid/interfaces/upload_chunk_args.md).[`chunk`](../namespaces/IcManagementDid/interfaces/upload_chunk_args.md#chunk)
