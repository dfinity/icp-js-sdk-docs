---
title: UninstallCodeParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:103](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L103)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:104](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L104)

***

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:105](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L105)
