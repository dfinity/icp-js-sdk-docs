---
title: UploadCanisterSnapshotDataParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:136](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L136)

## Extends

- [`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`canisterId`](OptionSnapshotParams.md#canisterid)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:137](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L137)

***

### kind

> **kind**: [`UploadCanisterSnapshotDataKind`](../type-aliases/UploadCanisterSnapshotDataKind.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:138](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L138)

***

### snapshotId

> **snapshotId**: `string` \| [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`snapshotId`](OptionSnapshotParams.md#snapshotid)
