---
title: UploadCanisterSnapshotDataParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L133)

## Extends

- [`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`canisterId`](OptionSnapshotParams.md#canisterid)

***

### chunk

> **chunk**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L134)

***

### kind

> **kind**: [`UploadCanisterSnapshotDataKind`](../type-aliases/UploadCanisterSnapshotDataKind.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L135)

***

### snapshotId

> **snapshotId**: `string` \| [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`snapshotId`](OptionSnapshotParams.md#snapshotid)
