---
title: CkBtcMinterDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:897](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L897)

#### Properties

##### decode\_ledger\_memo

> **decode\_ledger\_memo**: `ActorMethod`\<\[[`DecodeLedgerMemoArgs`](#decodeledgermemoargs)\], [`DecodeLedgerMemoResult`](#decodeledgermemoresult)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:902](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L902)

Section "Transaction Information" {{{
Returns information related to minter transactions.

##### estimate\_withdrawal\_fee

> **estimate\_withdrawal\_fee**: `ActorMethod`\<\[\{ `amount`: \[\] \| \[`bigint`\]; \}\], \{ `bitcoin_fee`: `bigint`; `minter_fee`: `bigint`; \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:910](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L910)

/ Returns an estimate of the user's fee (in Satoshi) for a
/ retrieve_btc request based on the current status of the Bitcoin network.

##### get\_btc\_address

> **get\_btc\_address**: `ActorMethod`\<\[\{ `owner`: \[\] \| \[`Principal`\]; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}\], `string`\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:922](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L922)

Returns the Bitcoin address to which the owner should send BTC
before converting the amount to ckBTC using the [update_balance]
endpoint.

If the owner is not set, it defaults to the caller's principal.
The resolved owner must be a non-anonymous principal.

##### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](#canisterstatusresponse)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:926](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L926)

##### get\_deposit\_fee

> **get\_deposit\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:930](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L930)

/ Returns the fee that the minter will charge for a bitcoin deposit.

##### get\_events

> **get\_events**: `ActorMethod`\<\[\{ `length`: `bigint`; `start`: `bigint`; \}\], [`Event`](#event)[]\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:942](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L942)

The minter keeps track of all state modifications in an internal event log.

This method returns a list of events in the specified range.
The minter can return fewer events than requested. The result is
an empty vector if the start position is greater than the total
number of events.

NOTE: this method exists for debugging purposes.
The ckBTC minter authors do not guarantee backward compatibility for this method.

##### get\_known\_utxos

> **get\_known\_utxos**: `ActorMethod`\<\[\{ `owner`: \[\] \| \[`Principal`\]; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}\], [`Utxo`](#utxo-1)[]\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L949)

Returns UTXOs of the given account known by the minter (with no
guarantee in the ordering of the returned values).

If the owner is not set, it defaults to the caller's principal.

##### get\_minter\_info

> **get\_minter\_info**: `ActorMethod`\<\[\], [`MinterInfo`](#minterinfo)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:957](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L957)

Section "Minter Information" {{{
Returns internal minter parameters.

##### get\_withdrawal\_account

> **get\_withdrawal\_account**: `ActorMethod`\<\[\], [`Account`](#account)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:962](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L962)

Returns the account to which the caller should deposit ckBTC
before withdrawing BTC using the [retrieve_btc] endpoint.

##### retrieve\_btc

> **retrieve\_btc**: `ActorMethod`\<\[[`RetrieveBtcArgs`](#retrievebtcargs)\], \{ `Ok`: [`RetrieveBtcOk`](#retrievebtcok); \} \| \{ `Err`: [`RetrieveBtcError`](#retrievebtcerror); \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:978](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L978)

Submits a request to convert ckBTC to BTC.


The BTC retrieval process is slow.  Instead of
synchronously waiting for a BTC transaction to settle, this
method returns a request ([block_index]) that the caller can use
to query the request status.

# Preconditions

* The caller deposited the requested amount in ckBTC to the account
that the [get_withdrawal_account] endpoint returns.

##### retrieve\_btc\_status

> **retrieve\_btc\_status**: `ActorMethod`\<\[\{ `block_index`: `bigint`; \}\], [`RetrieveBtcStatus`](#retrievebtcstatus)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:986](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L986)

/ [deprecated] Returns the status of a withdrawal request.
/ You should use retrieve_btc_status_v2 to retrieve the status of your withdrawal request.

##### retrieve\_btc\_status\_v2

> **retrieve\_btc\_status\_v2**: `ActorMethod`\<\[\{ `block_index`: `bigint`; \}\], [`RetrieveBtcStatusV2`](#retrievebtcstatusv2)\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:993](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L993)

/ Returns the status of a withdrawal request request using the RetrieveBtcStatusV2 type.

##### retrieve\_btc\_status\_v2\_by\_account

> **retrieve\_btc\_status\_v2\_by\_account**: `ActorMethod`\<\[\[\] \| \[[`Account`](#account)\]\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1005](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1005)

Returns the withdrawal statues by account.

# Note
The _v2_ part indicates that you get a response in line with the retrieve_btc_status_v2 endpoint,
i.e., you get a vector of RetrieveBtcStatusV2 and not RetrieveBtcStatus.

##### retrieve\_btc\_with\_approval

> **retrieve\_btc\_with\_approval**: `ActorMethod`\<\[[`RetrieveBtcWithApprovalArgs`](#retrievebtcwithapprovalargs)\], \{ `Ok`: [`RetrieveBtcOk`](#retrievebtcok); \} \| \{ `Err`: [`RetrieveBtcWithApprovalError`](#retrievebtcwithapprovalerror); \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1024](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1024)

Submits a request to convert ckBTC to BTC.

# Note

The BTC retrieval process is slow.  Instead of
synchronously waiting for a BTC transaction to settle, this
method returns a request ([block_index]) that the caller can use
to query the request status.

# Preconditions

* The caller allowed the minter's principal to spend its funds
using [icrc2_approve] on the ckBTC ledger.

##### update\_balance

> **update\_balance**: `ActorMethod`\<\[\{ `owner`: \[\] \| \[`Principal`\]; `subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; \}\], \{ `Ok`: [`UtxoStatus`](#utxostatus)[]; \} \| \{ `Err`: [`UpdateBalanceError`](#updatebalanceerror); \}\>

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1038](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1038)

Mints ckBTC for newly deposited UTXOs.

If the owner is not set, it defaults to the caller's principal.

# Preconditions

* The owner deposited some BTC to the address that the
[get_btc_address] endpoint returns.

***

### Account

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L16)

Represents an account on the ckBTC ledger.

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L17)

##### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L18)

***

### CanisterStatusResponse

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L80)

#### Properties

##### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L86)

##### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L89)

##### memory\_metrics

> **memory\_metrics**: [`MemoryMetrics`](#memorymetrics)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L81)

##### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L83)

##### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L90)

##### query\_stats

> **query\_stats**: [`QueryStats`](#querystats)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L88)

##### ready\_for\_migration

> **ready\_for\_migration**: `boolean`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L84)

##### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L91)

##### settings

> **settings**: [`DefiniteCanisterSettings`](#definitecanistersettings)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L87)

##### status

> **status**: [`CanisterStatusType`](#canisterstatustype)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L82)

##### version

> **version**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L85)

***

### DecodeLedgerMemoArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L97)

#### Properties

##### encoded\_memo

> **encoded\_memo**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L105)

The encoded memo from a minter transaction on the ledger

##### memo\_type

> **memo\_type**: [`MemoType`](#memotype)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L101)

The encoded memo type

***

### DefiniteCanisterSettings

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:141](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L141)

#### Properties

##### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L150)

##### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L145)

##### environment\_variables

> **environment\_variables**: [`environment_variable`](#environment_variable)[]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L144)

##### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L142)

##### log\_visibility

> **log\_visibility**: [`LogVisibility`](#logvisibility)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L147)

##### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L149)

##### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L146)

##### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L148)

##### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L143)

***

### environment\_variable

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L893)

#### Properties

##### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L895)

##### value

> **value**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:894](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L894)

***

### Event

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L152)

#### Properties

##### payload

> **payload**: [`EventType`](#eventtype)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L154)

##### timestamp

> **timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L153)

***

### InitArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L277)

The initialization parameters of the minter canister.

#### Properties

##### btc\_checker\_principal

> **btc\_checker\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L334)

/ The canister id of the Bitcoin checker canister.

##### btc\_network

> **btc\_network**: [`BtcNetwork`](#btcnetwork)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L318)

The minter will interact with this Bitcoin network.

##### check\_fee

> **check\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L322)

/ The fee paid per Bitcoin check.

##### deposit\_btc\_min\_amount

> **deposit\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L303)

The minimal amount of BTC that can be converted to ckBTC.
UTXOs with lower values will be ignored.

##### ecdsa\_key\_name

> **ecdsa\_key\_name**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L290)

The name of the ECDSA key to use.
E.g., "dfx_test_key" on the local replica.

##### get\_utxos\_cache\_expiration\_seconds

> **get\_utxos\_cache\_expiration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L281)

/ The expiration duration (in seconds) for cached entries in the get_utxos cache.

##### kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L343)

/ The fee paid per check by the KYT canister (deprecated, use check_fee instead).

##### kyt\_principal

> **kyt\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L285)

/ The canister id of the KYT canister (deprecated, use btc_checker_principal instead).

##### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L309)

The principal of the ledger that handles ckBTC transfers.
The default account of the ckBTC minter must be configured as
the minting account of the ledger.

##### max\_num\_inputs\_in\_transaction

> **max\_num\_inputs\_in\_transaction**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L326)

/ The maximum number of input UTXOs allowed in a transaction.

##### max\_time\_in\_queue\_nanos

> **max\_time\_in\_queue\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L314)

/ Maximum time in nanoseconds that a transaction should spend in the queue
/ before being sent.

##### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L339)

/ The minimum number of confirmations required for the minter to
/ accept a Bitcoin transaction.

##### mode

> **mode**: [`Mode`](#mode-2)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L294)

/ The minter's operation mode.

##### retrieve\_btc\_min\_amount

> **retrieve\_btc\_min\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L298)

The minimal amount of ckBTC that can be converted to BTC.

##### utxo\_consolidation\_threshold

> **utxo\_consolidation\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L330)

/ The minimum number of available UTXOs to trigger a consolidation.

***

### MemoryMetrics

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L353)

#### Properties

##### canister\_history\_size

> **canister\_history\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L356)

##### custom\_sections\_size

> **custom\_sections\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L361)

##### global\_memory\_size

> **global\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L360)

##### snapshots\_size

> **snapshots\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L358)

##### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L357)

##### wasm\_binary\_size

> **wasm\_binary\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L354)

##### wasm\_chunk\_store\_size

> **wasm\_chunk\_store\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L355)

##### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L359)

***

### MinterInfo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L416)

#### Properties

##### deposit\_btc\_min\_amount

> **deposit\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:426](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L426)

Minimal amount of BTC that can be deposited to be converted into ckBTC.
UTXOs with lower values will be ignored.

##### kyt\_fee

> **kyt\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L431)

The same as `check_fee`, but the old name is kept here to be backward compatible.

##### min\_confirmations

> **min\_confirmations**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L427)

##### retrieve\_btc\_min\_amount

> **retrieve\_btc\_min\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L421)

This amount is based on the `retrieve_btc_min_amount` setting during canister
initialization or upgrades, but may vary according to current network fees.

***

### PendingUtxo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:461](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L461)

Utxos that don't have enough confirmations to be processed.

#### Properties

##### confirmations

> **confirmations**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:462](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L462)

##### outpoint

> **outpoint**: `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L464)

###### txid

> **txid**: `Uint8Array`

###### vout

> **vout**: `number`

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:463](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L463)

***

### QueryStats

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L466)

#### Properties

##### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:469](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L469)

##### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L468)

##### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L470)

##### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L467)

***

### ReimbursedDeposit

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L472)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L473)

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:475](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L475)

##### mint\_block\_index

> **mint\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L474)

##### reason

> **reason**: [`ReimbursementReason`](#reimbursementreason)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L476)

***

### ReimbursementRequest

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:481](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L481)

#### Properties

##### account

> **account**: [`Account`](#account)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:482](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L482)

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:483](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L483)

##### reason

> **reason**: [`ReimbursementReason`](#reimbursementreason)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:484](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L484)

***

### RetrieveBtcArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:491](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L491)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L495)

The address to which the ckBTC minter should deposit BTC.

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L499)

The amount of ckBTC in Satoshis that the client wants to withdraw.

***

### RetrieveBtcOk

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L541)

#### Properties

##### block\_index

> **block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:546](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L546)

Returns the burn transaction index corresponding to the withdrawal.
You can use this index to query the withdrawal status.

***

### RetrieveBtcWithApprovalArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:662](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L662)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:670](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L670)

The address to which the ckBTC minter should deposit BTC.

##### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:674](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L674)

The amount of ckBTC in Satoshis that the client wants to withdraw.

##### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:666](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L666)

The subaccount to burn ckBTC from.

***

### SuspendedUtxo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:750](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L750)

#### Properties

##### earliest\_retry

> **earliest\_retry**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:752](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L752)

##### reason

> **reason**: [`SuspendedReason`](#suspendedreason)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:753](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L753)

##### utxo

> **utxo**: [`Utxo`](#utxo-1)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:751](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L751)

***

### UpgradeArgs

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:793](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L793)

The upgrade parameters of the minter canister.

#### Properties

##### btc\_checker\_principal

> **btc\_checker\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:835](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L835)

/ The principal of the Bitcoin checker canister.

##### check\_fee

> **check\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:823](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L823)

/ The fee per Bitcoin check.

##### deposit\_btc\_min\_amount

> **deposit\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:814](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L814)

The minimal amount of BTC that can be converted to ckBTC.
UTXOs with lower values will be ignored.

##### get\_utxos\_cache\_expiration\_seconds

> **get\_utxos\_cache\_expiration\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:797](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L797)

/ The expiration duration (in seconds) for cached entries in the get_utxos cache.

##### kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:844](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L844)

/ The fee paid per check by the KYT canister (deprecated, use check_fee instead).

##### kyt\_principal

> **kyt\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:801](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L801)

/ The canister id of the KYT canister (deprecated, use btc_checker_principal instead).

##### max\_num\_inputs\_in\_transaction

> **max\_num\_inputs\_in\_transaction**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:827](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L827)

/ The maximum number of input UTXOs allowed in a transaction.

##### max\_time\_in\_queue\_nanos

> **max\_time\_in\_queue\_nanos**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:819](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L819)

/ Maximum time in nanoseconds that a transaction should spend in the queue
/ before being sent.

##### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:840](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L840)

/ The minimum number of confirmations required for the minter to
/ accept a Bitcoin transaction.

##### mode

> **mode**: \[\] \| \[[`Mode`](#mode-2)\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:805](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L805)

/ If set, overrides the current minter's operation mode.

##### retrieve\_btc\_min\_amount

> **retrieve\_btc\_min\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:809](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L809)

The minimal amount of ckBTC that the minter converts to BTC.

##### utxo\_consolidation\_threshold

> **utxo\_consolidation\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:831](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L831)

/ The minimum number of available UTXOs to trigger a consolidation.

***

### Utxo

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:846](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L846)

#### Properties

##### height

> **height**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:847](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L847)

##### outpoint

> **outpoint**: `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:849](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L849)

###### txid

> **txid**: `Uint8Array`

###### vout

> **vout**: `number`

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:848](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L848)

***

### WithdrawalFee

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L886)

#### Properties

##### bitcoin\_fee

> **bitcoin\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L888)

##### minter\_fee

> **minter\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L887)

## Type Aliases

### BitcoinAddress

> **BitcoinAddress** = \{ `p2wsh_v0`: `Uint8Array`; \} \| \{ `p2tr_v1`: `Uint8Array`; \} \| \{ `p2sh`: `Uint8Array`; \} \| \{ `p2wpkh_v0`: `Uint8Array`; \} \| \{ `p2pkh`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L20)

***

### BtcNetwork

> **BtcNetwork** = \{ `Mainnet`: `null`; \} \| \{ `Regtest`: `null`; \} \| \{ `Testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L26)

#### Type Declaration

\{ `Mainnet`: `null`; \}

##### Mainnet

> **Mainnet**: `null`

The public Bitcoin mainnet.

\{ `Regtest`: `null`; \}

##### Regtest

> **Regtest**: `null`

A local Bitcoin regtest installation.

\{ `Testnet`: `null`; \}

##### Testnet

> **Testnet**: `null`

The public Bitcoin testnet.

***

### BurnMemo

> **BurnMemo** = \{ `Consolidate`: \{ `inputs`: `bigint`; `value`: `bigint`; \}; \} \| \{ `Convert`: \{ `address`: \[\] \| \[`string`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L45)

#### Type Declaration

\{ `Consolidate`: \{ `inputs`: `bigint`; `value`: `bigint`; \}; \}

##### Consolidate

> **Consolidate**: `object`

The minter consolidated UTXOs.

###### Consolidate.inputs

> **inputs**: `bigint`

The number of input UTXOs that were consolidated.

###### Consolidate.value

> **value**: `bigint`

The total value of the consolidated UTXOs.

\{ `Convert`: \{ `address`: \[\] \| \[`string`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \}

##### Convert

> **Convert**: `object`

The minter processed a retrieve_btc request.

###### Convert.address

> **address**: \[\] \| \[`string`\]

The destination of the retrieve BTC request.

###### Convert.kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

The check fee for the burn.

###### Convert.status

> **status**: \[\] \| \[[`Status`](#status-1)\]

The status of the Bitcoin check.

***

### CanisterStatusType

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L93)

***

### DecodedMemo

> **DecodedMemo** = \{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \} \| \{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L128)

#### Type Declaration

\{ `Burn`: \[\] \| \[[`BurnMemo`](#burnmemo)\]; \}

##### Burn

> **Burn**: \[\] \| \[[`BurnMemo`](#burnmemo)\]

The decoded BurnMemo - `opt` since other variants of `BurnMemo` could be added in the future.

\{ `Mint`: \[\] \| \[[`MintMemo`](#mintmemo)\]; \}

##### Mint

> **Mint**: \[\] \| \[[`MintMemo`](#mintmemo)\]

The decoded MintMemo - `opt` since other variants of `MintMemo` could be added in the future.

***

### DecodeLedgerMemoError

> **DecodeLedgerMemoError** = `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L107)

#### Properties

##### InvalidMemo

> **InvalidMemo**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L111)

The provided memo could not be decoded.

***

### DecodeLedgerMemoResult

> **DecodeLedgerMemoResult** = \{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \} \| \{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L113)

#### Type Declaration

\{ `Ok`: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]; \}

##### Ok

> **Ok**: \[\] \| \[[`DecodedMemo`](#decodedmemo)\]

The decoded memo, if the minter was able to decode it. This field is `opt`, so that other memo types can be
added in the future.

\{ `Err`: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]; \}

##### Err

> **Err**: \[\] \| \[[`DecodeLedgerMemoError`](#decodeledgermemoerror)\]

An error in case the minter was not able to decode the provided memo. This field is `opt`, so that other error
types can be added in the future.

***

### EventType

> **EventType** = \{ `received_utxos`: \{ `mint_txid`: \[\] \| \[`bigint`\]; `to_account`: [`Account`](#account); `utxos`: [`Utxo`](#utxo-1)[]; \}; \} \| \{ `schedule_deposit_reimbursement`: \{ `account`: [`Account`](#account); `amount`: `bigint`; `burn_block_index`: `bigint`; `reason`: [`ReimbursementReason`](#reimbursementreason); \}; \} \| \{ `sent_transaction`: \{ `change_output`: \[\] \| \[\{ `value`: `bigint`; `vout`: `number`; \}\]; `fee`: \[\] \| \[`bigint`\]; `requests`: `BigUint64Array`; `signed_tx`: \[\] \| \[`Uint8Array`\]; `submitted_at`: `bigint`; `txid`: `Uint8Array`; `utxos`: [`Utxo`](#utxo-1)[]; `withdrawal_fee`: \[\] \| \[[`WithdrawalFee`](#withdrawalfee)\]; \}; \} \| \{ `distributed_kyt_fee`: \{ `amount`: `bigint`; `block_index`: `bigint`; `kyt_provider`: `Principal`; \}; \} \| \{ `init`: [`InitArgs`](#initargs); \} \| \{ `upgrade`: [`UpgradeArgs`](#upgradeargs); \} \| \{ `retrieve_btc_kyt_failed`: \{ `address`: `string`; `amount`: `bigint`; `block_index`: `bigint`; `kyt_provider`: `Principal`; `owner`: `Principal`; `uuid`: `string`; \}; \} \| \{ `suspended_utxo`: \{ `account`: [`Account`](#account); `reason`: [`SuspendedReason`](#suspendedreason); `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `accepted_retrieve_btc_request`: \{ `address`: [`BitcoinAddress`](#bitcoinaddress); `amount`: `bigint`; `block_index`: `bigint`; `kyt_provider`: \[\] \| \[`Principal`\]; `received_at`: `bigint`; `reimbursement_account`: \[\] \| \[[`Account`](#account)\]; \}; \} \| \{ `checked_utxo`: \{ `clean`: `boolean`; `kyt_provider`: \[\] \| \[`Principal`\]; `utxo`: [`Utxo`](#utxo-1); `uuid`: `string`; \}; \} \| \{ `schedule_withdrawal_reimbursement`: \{ `account`: [`Account`](#account); `amount`: `bigint`; `burn_block_index`: `bigint`; `reason`: [`WithdrawalReimbursementReason`](#withdrawalreimbursementreason); \}; \} \| \{ `quarantined_withdrawal_reimbursement`: \{ `burn_block_index`: `bigint`; \}; \} \| \{ `removed_retrieve_btc_request`: \{ `block_index`: `bigint`; \}; \} \| \{ `confirmed_transaction`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `replaced_transaction`: \{ `change_output`: \{ `value`: `bigint`; `vout`: `number`; \}; `fee`: `bigint`; `new_txid`: `Uint8Array`; `new_utxos`: \[\] \| \[[`Utxo`](#utxo-1)[]\]; `old_txid`: `Uint8Array`; `reason`: \[\] \| \[[`ReplacedReason`](#replacedreason)\]; `submitted_at`: `bigint`; `withdrawal_fee`: \[\] \| \[[`WithdrawalFee`](#withdrawalfee)\]; \}; \} \| \{ `checked_utxo_v2`: \{ `account`: [`Account`](#account); `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `ignored_utxo`: \{ `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `checked_utxo_mint_unknown`: \{ `account`: [`Account`](#account); `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `created_consolidate_utxos_request`: \{ `address`: [`BitcoinAddress`](#bitcoinaddress); `amount`: `bigint`; `block_index`: `bigint`; `received_at`: `bigint`; \}; \} \| \{ `reimbursed_failed_deposit`: \{ `burn_block_index`: `bigint`; `mint_block_index`: `bigint`; \}; \} \| \{ `reimbursed_withdrawal`: \{ `burn_block_index`: `bigint`; `mint_block_index`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L156)

***

### InvalidTransactionError

> **InvalidTransactionError** = `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L345)

#### Properties

##### too\_many\_inputs

> **too\_many\_inputs**: `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L346)

###### max\_num\_inputs

> **max\_num\_inputs**: `bigint`

###### num\_inputs

> **num\_inputs**: `bigint`

***

### LogVisibility

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L348)

***

### MemoType

> **MemoType** = \{ `Burn`: `null`; \} \| \{ `Mint`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L352)

***

### MinterArg

> **MinterArg** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](#upgradeargs)\]; \} \| \{ `Init`: [`InitArgs`](#initargs); \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L415)

***

### MintMemo

> **MintMemo** = \{ `Kyt`: `null`; \} \| \{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \} \| \{ `KytFail`: \{ `associated_burn_index`: \[\] \| \[`bigint`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \} \| \{ `Convert`: \{ `kyt_fee`: \[\] \| \[`bigint`\]; `txid`: \[\] \| \[`Uint8Array`\]; `vout`: \[\] \| \[`number`\]; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L363)

#### Type Declaration

\{ `Kyt`: `null`; \}

##### Kyt

> **Kyt**: `null`

[deprecated] The minter minted accumulated check fees to the KYT provider.

\{ `ReimburseWithdrawal`: \{ `withdrawal_id`: `bigint`; \}; \}

##### ReimburseWithdrawal

> **ReimburseWithdrawal**: `object`

###### ReimburseWithdrawal.withdrawal\_id

> **withdrawal\_id**: `bigint`

The id corresponding to the withdrawal request,
which corresponds to the ledger burn index.

\{ `KytFail`: \{ `associated_burn_index`: \[\] \| \[`bigint`\]; `kyt_fee`: \[\] \| \[`bigint`\]; `status`: \[\] \| \[[`Status`](#status-1)\]; \}; \}

##### KytFail

> **KytFail**: `object`

[deprecated] The minter failed to check retrieve btc destination address
or the destination address is tainted.

###### KytFail.associated\_burn\_index

> **associated\_burn\_index**: \[\] \| \[`bigint`\]

###### KytFail.kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

The Bitcoin check fee.

###### KytFail.status

> **status**: \[\] \| \[[`Status`](#status-1)\]

The status of the Bitcoin check.

\{ `Convert`: \{ `kyt_fee`: \[\] \| \[`bigint`\]; `txid`: \[\] \| \[`Uint8Array`\]; `vout`: \[\] \| \[`number`\]; \}; \}

##### Convert

> **Convert**: `object`

The minter converted a single UTXO to ckBTC.

###### Convert.kyt\_fee

> **kyt\_fee**: \[\] \| \[`bigint`\]

The Bitcoin check fee.

###### Convert.txid

> **txid**: \[\] \| \[`Uint8Array`\]

The transaction ID of the accepted UTXO.

###### Convert.vout

> **vout**: \[\] \| \[`number`\]

UTXO's output index within the BTC transaction.

***

### Mode

> **Mode** = \{ `RestrictedTo`: `Principal`[]; \} \| \{ `DepositsRestrictedTo`: `Principal`[]; \} \| \{ `ReadOnly`: `null`; \} \| \{ `GeneralAvailability`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:433](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L433)

#### Type Declaration

\{ `RestrictedTo`: `Principal`[]; \}

##### RestrictedTo

> **RestrictedTo**: `Principal`[]

Only specified principals can modify minter's state.

\{ `DepositsRestrictedTo`: `Principal`[]; \}

##### DepositsRestrictedTo

> **DepositsRestrictedTo**: `Principal`[]

Only specified principals can convert BTC to ckBTC.

\{ `ReadOnly`: `null`; \}

##### ReadOnly

> **ReadOnly**: `null`

The minter does not allow any state modifications.

\{ `GeneralAvailability`: `null`; \}

##### GeneralAvailability

> **GeneralAvailability**: `null`

Anyone can interact with the minter.

***

### ReimbursementReason

> **ReimbursementReason** = \{ `CallFailed`: `null`; \} \| \{ `TaintedDestination`: \{ `kyt_fee`: `bigint`; `kyt_provider`: `Principal`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:478](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L478)

***

### ReplacedReason

> **ReplacedReason** = \{ `to_cancel`: \{ `reason`: [`WithdrawalReimbursementReason`](#withdrawalreimbursementreason); \}; \} \| \{ `to_retry`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L486)

***

### RetrieveBtcError

> **RetrieveBtcError** = \{ `MalformedAddress`: `string`; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `AlreadyProcessing`: `null`; \} \| \{ `AmountTooLow`: `bigint`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L501)

#### Type Declaration

\{ `MalformedAddress`: `string`; \}

##### MalformedAddress

> **MalformedAddress**: `string`

The minter failed to parse the destination address.

\{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### GenericError

> **GenericError**: `object`

A generic error reserved for future extensions.

###### GenericError.error\_code

> **error\_code**: `bigint`

###### GenericError.error\_message

> **error\_message**: `string`

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `AlreadyProcessing`: `null`; \}

##### AlreadyProcessing

> **AlreadyProcessing**: `null`

The minter is already processing another retrieval request for the same
principal.

\{ `AmountTooLow`: `bigint`; \}

##### AmountTooLow

> **AmountTooLow**: `bigint`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The ckBTC balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

***

### RetrieveBtcStatus

> **RetrieveBtcStatus** = \{ `Signing`: `null`; \} \| \{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Sending`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `AmountTooLow`: `null`; \} \| \{ `Unknown`: `null`; \} \| \{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:548](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L548)

#### Type Declaration

\{ `Signing`: `null`; \}

##### Signing

> **Signing**: `null`

The minter is obtaining all required ECDSA signatures on the
Bitcoin transaction for this request.

\{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \}

##### Confirmed

> **Confirmed**: `object`

The minter received enough confirmations for the Bitcoin
transaction for this request.  The payload contains the
identifier of the transaction on the Bitcoin network.

###### Confirmed.txid

> **txid**: `Uint8Array`

\{ `Sending`: \{ `txid`: `Uint8Array`; \}; \}

##### Sending

> **Sending**: `object`

The minter signed the transaction and is waiting for a reply
from the Bitcoin canister.

###### Sending.txid

> **txid**: `Uint8Array`

\{ `AmountTooLow`: `null`; \}

##### AmountTooLow

> **AmountTooLow**: `null`

The amount was too low to cover the transaction fees.

\{ `Unknown`: `null`; \}

##### Unknown

> **Unknown**: `null`

The minter does not have any information on the specified
retrieval request.  It can be that nobody submitted the
request or the minter pruned the relevant information from the
history to save space.

\{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \}

##### Submitted

> **Submitted**: `object`

The minter sent a transaction for the retrieve request.
The payload contains the identifier of the transaction on the Bitcoin network.

###### Submitted.txid

> **txid**: `Uint8Array`

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

The minter did not send a Bitcoin transaction for this request yet.

***

### RetrieveBtcStatusV2

> **RetrieveBtcStatusV2** = \{ `Signing`: `null`; \} \| \{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Sending`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `AmountTooLow`: `null`; \} \| \{ `WillReimburse`: [`ReimbursementRequest`](#reimbursementrequest); \} \| \{ `Unknown`: `null`; \} \| \{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \} \| \{ `Reimbursed`: [`ReimbursedDeposit`](#reimburseddeposit); \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:599](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L599)

#### Type Declaration

\{ `Signing`: `null`; \}

##### Signing

> **Signing**: `null`

The minter is obtaining all required ECDSA signatures on the
Bitcoin transaction for this request.

\{ `Confirmed`: \{ `txid`: `Uint8Array`; \}; \}

##### Confirmed

> **Confirmed**: `object`

The minter received enough confirmations for the Bitcoin
transaction for this request.  The payload contains the
identifier of the transaction on the Bitcoin network.

###### Confirmed.txid

> **txid**: `Uint8Array`

\{ `Sending`: \{ `txid`: `Uint8Array`; \}; \}

##### Sending

> **Sending**: `object`

The minter signed the transaction and is waiting for a reply
from the Bitcoin canister.

###### Sending.txid

> **txid**: `Uint8Array`

\{ `AmountTooLow`: `null`; \}

##### AmountTooLow

> **AmountTooLow**: `null`

The amount was too low to cover the transaction fees.

\{ `WillReimburse`: [`ReimbursementRequest`](#reimbursementrequest); \}

##### WillReimburse

> **WillReimburse**: [`ReimbursementRequest`](#reimbursementrequest)

/ The minter will try to reimburse this transaction.

\{ `Unknown`: `null`; \}

##### Unknown

> **Unknown**: `null`

The minter does not have any information on the specified
retrieval request.  It can be that nobody submitted the
request or the minter pruned the relevant information from the
history to save space.

\{ `Submitted`: \{ `txid`: `Uint8Array`; \}; \}

##### Submitted

> **Submitted**: `object`

The minter sent a transaction for the retrieve request.
The payload contains the identifier of the transaction on the Bitcoin network.

###### Submitted.txid

> **txid**: `Uint8Array`

\{ `Reimbursed`: [`ReimbursedDeposit`](#reimburseddeposit); \}

##### Reimbursed

> **Reimbursed**: [`ReimbursedDeposit`](#reimburseddeposit)

/ The retrieve Bitcoin request has been reimbursed.

\{ `Pending`: `null`; \}

##### Pending

> **Pending**: `null`

The minter did not send a Bitcoin transaction for this request yet.

***

### RetrieveBtcWithApprovalError

> **RetrieveBtcWithApprovalError** = \{ `MalformedAddress`: `string`; \} \| \{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `AlreadyProcessing`: `null`; \} \| \{ `AmountTooLow`: `bigint`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:676](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L676)

#### Type Declaration

\{ `MalformedAddress`: `string`; \}

##### MalformedAddress

> **MalformedAddress**: `string`

The minter failed to parse the destination address.

\{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### GenericError

> **GenericError**: `object`

A generic error reserved for future extensions.

###### GenericError.error\_code

> **error\_code**: `bigint`

###### GenericError.error\_message

> **error\_message**: `string`

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \}

##### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

###### InsufficientAllowance.allowance

> **allowance**: `bigint`

\{ `AlreadyProcessing`: `null`; \}

##### AlreadyProcessing

> **AlreadyProcessing**: `null`

The minter is already processing another retrieval request for the same
principal.

\{ `AmountTooLow`: `bigint`; \}

##### AmountTooLow

> **AmountTooLow**: `bigint`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

##### InsufficientFunds

> **InsufficientFunds**: `object`

The ckBTC balance of the withdrawal account is too low.

###### InsufficientFunds.balance

> **balance**: `bigint`

***

### Status

> **Status** = \{ `CallFailed`: `null`; \} \| \{ `Rejected`: `null`; \} \| \{ `Accepted`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:722](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L722)

#### Type Declaration

\{ `CallFailed`: `null`; \}

##### CallFailed

> **CallFailed**: `null`

\{ `Rejected`: `null`; \}

##### Rejected

> **Rejected**: `null`

The minter rejected a retrieve_btc due to a failed Bitcoin check.

\{ `Accepted`: `null`; \}

##### Accepted

> **Accepted**: `null`

The minter accepted a retrieve_btc request.

***

### SuspendedReason

> **SuspendedReason** = \{ `ValueTooSmall`: `null`; \} \| \{ `Quarantined`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:736](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L736)

#### Type Declaration

\{ `ValueTooSmall`: `null`; \}

##### ValueTooSmall

> **ValueTooSmall**: `null`

The minter ignored this UTXO because UTXO's value is too small to pay
the check fees.

\{ `Quarantined`: `null`; \}

##### Quarantined

> **Quarantined**: `null`

The Bitcoin checker considered this UTXO to be tainted.

***

### Timestamp

> **Timestamp** = `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:758](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L758)

Number of nanoseconds since the Unix Epoch

***

### UpdateBalanceError

> **UpdateBalanceError** = \{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `string`; \} \| \{ `AlreadyProcessing`: `null`; \} \| \{ `NoNewUtxos`: \{ `current_confirmations`: \[\] \| \[`number`\]; `pending_utxos`: \[\] \| \[[`PendingUtxo`](#pendingutxo)[]\]; `required_confirmations`: `number`; `suspended_utxos`: \[\] \| \[[`SuspendedUtxo`](#suspendedutxo)[]\]; \}; \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:759](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L759)

#### Type Declaration

\{ `GenericError`: \{ `error_code`: `bigint`; `error_message`: `string`; \}; \}

##### GenericError

> **GenericError**: `object`

A generic error reserved for future extensions.

###### GenericError.error\_code

> **error\_code**: `bigint`

###### GenericError.error\_message

> **error\_message**: `string`

\{ `TemporarilyUnavailable`: `string`; \}

##### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter is overloaded, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `AlreadyProcessing`: `null`; \}

##### AlreadyProcessing

> **AlreadyProcessing**: `null`

The minter is already processing another update balance request for the caller.

\{ `NoNewUtxos`: \{ `current_confirmations`: \[\] \| \[`number`\]; `pending_utxos`: \[\] \| \[[`PendingUtxo`](#pendingutxo)[]\]; `required_confirmations`: `number`; `suspended_utxos`: \[\] \| \[[`SuspendedUtxo`](#suspendedutxo)[]\]; \}; \}

##### NoNewUtxos

> **NoNewUtxos**: `object`

There are no new UTXOs to process.

###### NoNewUtxos.current\_confirmations

> **current\_confirmations**: \[\] \| \[`number`\]

###### NoNewUtxos.pending\_utxos

> **pending\_utxos**: \[\] \| \[[`PendingUtxo`](#pendingutxo)[]\]

###### NoNewUtxos.required\_confirmations

> **required\_confirmations**: `number`

###### NoNewUtxos.suspended\_utxos

> **suspended\_utxos**: \[\] \| \[[`SuspendedUtxo`](#suspendedutxo)[]\]

***

### UtxoStatus

> **UtxoStatus** = \{ `ValueTooSmall`: [`Utxo`](#utxo-1); \} \| \{ `Tainted`: [`Utxo`](#utxo-1); \} \| \{ `Minted`: \{ `block_index`: `bigint`; `minted_amount`: `bigint`; `utxo`: [`Utxo`](#utxo-1); \}; \} \| \{ `Checked`: [`Utxo`](#utxo-1); \}

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:854](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L854)

The result of an [update_balance] call.

#### Type Declaration

\{ `ValueTooSmall`: [`Utxo`](#utxo-1); \}

##### ValueTooSmall

> **ValueTooSmall**: [`Utxo`](#utxo-1)

The minter ignored this UTXO because UTXO's value is too small to pay
the check fees.

\{ `Tainted`: [`Utxo`](#utxo-1); \}

##### Tainted

> **Tainted**: [`Utxo`](#utxo-1)

The Bitcoin checker considered this UTXO to be tainted.

\{ `Minted`: \{ `block_index`: `bigint`; `minted_amount`: `bigint`; `utxo`: [`Utxo`](#utxo-1); \}; \}

##### Minted

> **Minted**: `object`

The UTXO passed the Bitcoin check, and ckBTC has been minted.

###### Minted.block\_index

> **block\_index**: `bigint`

###### Minted.minted\_amount

> **minted\_amount**: `bigint`

###### Minted.utxo

> **utxo**: [`Utxo`](#utxo-1)

\{ `Checked`: [`Utxo`](#utxo-1); \}

##### Checked

> **Checked**: [`Utxo`](#utxo-1)

The UTXO passed the Bitcoin check, but the minter failed to mint ckBTC
because the Ledger was unavailable. Retrying the [update_balance] call
should eventually advance the UTXO to the [Minted] state.

***

### WithdrawalReimbursementReason

> **WithdrawalReimbursementReason** = `object`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L890)

#### Properties

##### invalid\_transaction

> **invalid\_transaction**: [`InvalidTransactionError`](#invalidtransactionerror)

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L891)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1043](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1043)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ckbtc/minter.d.ts:1044](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/minter.d.ts#L1044)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
