---
title: BitcoinDid
editUrl: false
next: true
prev: true
---

## Interfaces

### \_SERVICE

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L120)

#### Properties

##### bitcoin\_get\_balance

> **bitcoin\_get\_balance**: `ActorMethod`\<\[[`get_balance_request`](#get_balance_request)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L121)

##### bitcoin\_get\_balance\_query

> **bitcoin\_get\_balance\_query**: `ActorMethod`\<\[[`get_balance_request`](#get_balance_request)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L122)

##### bitcoin\_get\_block\_headers

> **bitcoin\_get\_block\_headers**: `ActorMethod`\<\[[`get_block_headers_request`](#get_block_headers_request)\], [`get_block_headers_response`](#get_block_headers_response)\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L123)

##### bitcoin\_get\_current\_fee\_percentiles

> **bitcoin\_get\_current\_fee\_percentiles**: `ActorMethod`\<\[[`get_current_fee_percentiles_request`](#get_current_fee_percentiles_request)\], `BigUint64Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L127)

##### bitcoin\_get\_utxos

> **bitcoin\_get\_utxos**: `ActorMethod`\<\[[`get_utxos_request`](#get_utxos_request)\], [`get_utxos_response`](#get_utxos_response)\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L131)

##### bitcoin\_get\_utxos\_query

> **bitcoin\_get\_utxos\_query**: `ActorMethod`\<\[[`get_utxos_request`](#get_utxos_request)\], [`get_utxos_response`](#get_utxos_response)\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L132)

##### bitcoin\_send\_transaction

> **bitcoin\_send\_transaction**: `ActorMethod`\<\[[`send_transaction_request`](#send_transaction_request)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L133)

##### get\_blockchain\_info

> **get\_blockchain\_info**: `ActorMethod`\<\[\], [`blockchain_info`](#blockchain_info)\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L134)

##### get\_config

> **get\_config**: `ActorMethod`\<\[\], [`config`](#config)\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:135](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L135)

##### set\_config

> **set\_config**: `ActorMethod`\<\[[`set_config_request`](#set_config_request)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L136)

***

### blockchain\_info

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L17)

#### Properties

##### block\_hash

> **block\_hash**: [`block_hash`](#block_hash-1)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L19)

##### difficulty

> **difficulty**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L20)

##### height

> **height**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L18)

##### timestamp

> **timestamp**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L21)

##### utxos\_length

> **utxos\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L22)

***

### config

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L27)

#### Properties

##### api\_access

> **api\_access**: [`flag`](#flag)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L28)

##### blocks\_source

> **blocks\_source**: `Principal`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L30)

##### burn\_cycles

> **burn\_cycles**: [`flag`](#flag)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L36)

##### disable\_api\_if\_not\_fully\_synced

> **disable\_api\_if\_not\_fully\_synced**: [`flag`](#flag)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L37)

##### fees

> **fees**: [`fees`](#fees-1)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L31)

##### lazily\_evaluate\_fee\_percentiles

> **lazily\_evaluate\_fee\_percentiles**: [`flag`](#flag)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L29)

##### network

> **network**: [`network`](#network-7)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L33)

##### stability\_threshold

> **stability\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:34](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L34)

##### syncing

> **syncing**: [`flag`](#flag)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L35)

##### watchdog\_canister

> **watchdog\_canister**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L32)

***

### fees

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L39)

#### Properties

##### get\_balance

> **get\_balance**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L45)

##### get\_balance\_maximum

> **get\_balance\_maximum**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L49)

##### get\_block\_headers\_base

> **get\_block\_headers\_base**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L47)

##### get\_block\_headers\_cycles\_per\_ten\_instructions

> **get\_block\_headers\_cycles\_per\_ten\_instructions**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L42)

##### get\_block\_headers\_maximum

> **get\_block\_headers\_maximum**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L51)

##### get\_current\_fee\_percentiles

> **get\_current\_fee\_percentiles**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L40)

##### get\_current\_fee\_percentiles\_maximum

> **get\_current\_fee\_percentiles\_maximum**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L43)

##### get\_utxos\_base

> **get\_utxos\_base**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L48)

##### get\_utxos\_cycles\_per\_ten\_instructions

> **get\_utxos\_cycles\_per\_ten\_instructions**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L46)

##### get\_utxos\_maximum

> **get\_utxos\_maximum**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L41)

##### send\_transaction\_base

> **send\_transaction\_base**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L50)

##### send\_transaction\_per\_byte

> **send\_transaction\_per\_byte**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L44)

***

### get\_balance\_request

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L54)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L56)

##### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L57)

##### network

> **network**: [`network`](#network-7)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L55)

***

### get\_block\_headers\_request

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L59)

#### Properties

##### end\_height

> **end\_height**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L61)

##### network

> **network**: [`network`](#network-7)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L62)

##### start\_height

> **start\_height**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L60)

***

### get\_block\_headers\_response

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L64)

#### Properties

##### block\_headers

> **block\_headers**: [`block_header`](#block_header)[]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L66)

##### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L65)

***

### get\_current\_fee\_percentiles\_request

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L68)

#### Properties

##### network

> **network**: [`network`](#network-7)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L69)

***

### get\_utxos\_request

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L71)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L74)

##### filter

> **filter**: \[\] \| \[\{ `page`: `Uint8Array`; \} \| \{ `min_confirmations`: `number`; \}\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L73)

##### network

> **network**: [`network`](#network-7)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L72)

***

### get\_utxos\_response

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L76)

#### Properties

##### next\_page

> **next\_page**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L77)

##### tip\_block\_hash

> **tip\_block\_hash**: [`block_hash`](#block_hash-1)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L79)

##### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L78)

##### utxos

> **utxos**: [`utxo`](#utxo)[]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L80)

***

### init\_config

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L82)

#### Properties

##### api\_access

> **api\_access**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L83)

##### blocks\_source

> **blocks\_source**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L85)

##### burn\_cycles

> **burn\_cycles**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L91)

##### disable\_api\_if\_not\_fully\_synced

> **disable\_api\_if\_not\_fully\_synced**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L92)

##### fees

> **fees**: \[\] \| \[[`fees`](#fees-1)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:86](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L86)

##### lazily\_evaluate\_fee\_percentiles

> **lazily\_evaluate\_fee\_percentiles**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:84](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L84)

##### network

> **network**: \[\] \| \[[`network`](#network-7)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:88](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L88)

##### stability\_threshold

> **stability\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L89)

##### syncing

> **syncing**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L90)

##### watchdog\_canister

> **watchdog\_canister**: \[\] \| \[\[\] \| \[`Principal`\]\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:87](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L87)

***

### outpoint

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L96)

#### Properties

##### txid

> **txid**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L97)

##### vout

> **vout**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L98)

***

### send\_transaction\_request

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L101)

#### Properties

##### network

> **network**: [`network`](#network-7)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L103)

##### transaction

> **transaction**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L102)

***

### set\_config\_request

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L105)

#### Properties

##### api\_access

> **api\_access**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L106)

##### burn\_cycles

> **burn\_cycles**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L112)

##### disable\_api\_if\_not\_fully\_synced

> **disable\_api\_if\_not\_fully\_synced**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L113)

##### fees

> **fees**: \[\] \| \[[`fees`](#fees-1)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L108)

##### lazily\_evaluate\_fee\_percentiles

> **lazily\_evaluate\_fee\_percentiles**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L107)

##### stability\_threshold

> **stability\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L110)

##### syncing

> **syncing**: \[\] \| \[[`flag`](#flag)\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L111)

##### watchdog\_canister

> **watchdog\_canister**: \[\] \| \[\[\] \| \[`Principal`\]\]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L109)

***

### utxo

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L115)

#### Properties

##### height

> **height**: `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L116)

##### outpoint

> **outpoint**: [`outpoint`](#outpoint)

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:118](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L118)

##### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:117](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L117)

## Type Aliases

### address

> **address** = `string`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L13)

***

### block\_hash

> **block\_hash** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L14)

***

### block\_header

> **block\_header** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L15)

***

### block\_height

> **block\_height** = `number`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L16)

***

### canister\_arg

> **canister\_arg** = \{ `init`: [`init_config`](#init_config); \} \| \{ `upgrade`: \[\] \| \[[`set_config_request`](#set_config_request)\]; \}

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L24)

***

### flag

> **flag** = \{ `disabled`: `null`; \} \| \{ `enabled`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L53)

***

### millisatoshi\_per\_byte

> **millisatoshi\_per\_byte** = `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L94)

***

### network

> **network** = \{ `mainnet`: `null`; \} \| \{ `regtest`: `null`; \} \| \{ `testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L95)

***

### satoshi

> **satoshi** = `bigint`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L100)

## Variables

### idlFactory

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L138)

***

### init()

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ckbtc/bitcoin.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/declarations/ckbtc/bitcoin.d.ts#L139)

#### Parameters

##### args

###### IDL

*typeof* `IDL`

#### Returns

`IDL.Type`[]
