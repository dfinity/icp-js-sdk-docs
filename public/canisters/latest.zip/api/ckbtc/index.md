---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [BitcoinDid](namespaces/BitcoinDid.md)
- [CkBtcMinterDid](namespaces/CkBtcMinterDid.md)

## Enumerations

### BtcAddressType

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L10)

#### Enumeration Members

##### P2pkh

> **P2pkh**: `1`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L12)

##### P2sh

> **P2sh**: `2`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L13)

##### P2tr

> **P2tr**: `4`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:15](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L15)

##### P2wpkhV0

> **P2wpkhV0**: `0`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L11)

##### P2wsh

> **P2wsh**: `3`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:14](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L14)

***

### BtcNetwork

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L3)

#### Enumeration Members

##### Mainnet

> **Mainnet**: `0`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L4)

##### Regtest

> **Regtest**: `1`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L5)

##### Testnet

> **Testnet**: `2`

Defined in: [packages/canisters/src/ckbtc/enums/btc.enums.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/enums/btc.enums.ts#L6)

## Classes

### BitcoinCanister

Defined in: [packages/canisters/src/ckbtc/bitcoin.canister.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/bitcoin.canister.ts#L16)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/BitcoinDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new BitcoinCanister**(`id`, `service`, `certifiedService`): [`BitcoinCanister`](#bitcoincanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/BitcoinDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/BitcoinDid.md#_service)

###### Returns

[`BitcoinCanister`](#bitcoincanister)

###### Inherited from

`Canister<BitcoinService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/BitcoinDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/BitcoinDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/BitcoinDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/BitcoinDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### getBalanceQuery()

> **getBalanceQuery**(`params`): `Promise`\<`bigint`\>

Defined in: [packages/canisters/src/ckbtc/bitcoin.canister.ts:63](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/bitcoin.canister.ts#L63)

Given a `get_balance_request`, which must specify a Bitcoin address and a Bitcoin network (`mainnet`, `testnet` or `regtest`), the function returns the current balance of this address in `Satoshi` (10^8 Satoshi = 1 Bitcoin) in the specified Bitcoin network.

⚠️ Note that this method does not support certified calls because only canisters are allowed to get Bitcoin balance via update calls.

###### Parameters

###### params

[`GetBalanceParams`](#getbalanceparams)

###### Returns

`Promise`\<`bigint`\>

The balance is returned in `Satoshi` (10^8 Satoshi = 1 Bitcoin).

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-bitcoin_get_balance

##### getUtxosQuery()

> **getUtxosQuery**(`params`): `Promise`\<[`get_utxos_response`](namespaces/BitcoinDid.md#get_utxos_response)\>

Defined in: [packages/canisters/src/ckbtc/bitcoin.canister.ts:41](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/bitcoin.canister.ts#L41)

Given a `get_utxos_request`, which must specify a Bitcoin address and a Bitcoin network (`mainnet`, `testnet` or `regtest`), the function returns all unspent transaction outputs (UTXOs) associated with the provided address in the specified Bitcoin network based on the current view of the Bitcoin blockchain available to the Bitcoin component.

⚠️ Note that this method does not support certified calls because only canisters are allowed to get UTXOs via update calls.

###### Parameters

###### params

[`GetUtxosParams`](#getutxosparams)

###### Returns

`Promise`\<[`get_utxos_response`](namespaces/BitcoinDid.md#get_utxos_response)\>

The UTXOs are returned sorted by block height in descending order.

###### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-bitcoin_get_utxos

##### create()

> `static` **create**(`options`): [`BitcoinCanister`](#bitcoincanister)

Defined in: [packages/canisters/src/ckbtc/bitcoin.canister.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/bitcoin.canister.ts#L17)

###### Parameters

###### options

[`CkBtcCanisterOptions`](#ckbtccanisteroptions)\<[`_SERVICE`](namespaces/BitcoinDid.md#_service)\>

###### Returns

[`BitcoinCanister`](#bitcoincanister)

***

### CkBtcMinterCanister

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:38](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L38)

#### Extends

- `Canister`\<[`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)\>

#### Constructors

##### Constructor

> `protected` **new CkBtcMinterCanister**(`id`, `service`, `certifiedService`): [`CkBtcMinterCanister`](#ckbtcmintercanister)

Defined in: packages/utils/dist/services/canister.d.ts:7

###### Parameters

###### id

`Principal`

###### service

[`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)

###### certifiedService

[`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)

###### Returns

[`CkBtcMinterCanister`](#ckbtcmintercanister)

###### Inherited from

`Canister<CkBtcMinterService>.constructor`

#### Properties

##### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:9

###### Parameters

###### \_\_namedParameters

`QueryParams`

###### Returns

[`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)

###### Inherited from

`Canister.caller`

##### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:6

###### Inherited from

`Canister.certifiedService`

##### service

> `protected` `readonly` **service**: [`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)

Defined in: packages/utils/dist/services/canister.d.ts:5

###### Inherited from

`Canister.service`

#### Accessors

##### canisterId

###### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

###### Returns

`Principal`

###### Inherited from

`Canister.canisterId`

#### Methods

##### estimateWithdrawalFee()

> **estimateWithdrawalFee**(`params`): `Promise`\<[`EstimateWithdrawalFee`](#estimatewithdrawalfee-2)\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:237](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L237)

Returns an estimation of the user's fee (in Satoshi) for a retrieve_btc request based on the current status of the Bitcoin network and the fee related to the minter.

###### Parameters

###### params

[`EstimateWithdrawalFeeParams`](#estimatewithdrawalfeeparams)

The parameters to estimate the fee.

###### Returns

`Promise`\<[`EstimateWithdrawalFee`](#estimatewithdrawalfee-2)\>

##### getBtcAddress()

> **getBtcAddress**(`params`): `Promise`\<`string`\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L60)

Returns a BTC address for a given account.

Note: an update call is required by the Minter canister.

###### Parameters

###### params

[`MinterParams`](#minterparams)

The parameters for which a BTC address should be resolved.

###### Returns

`Promise`\<`string`\>

The BTC address of the given account.

##### getKnownUtxos()

> **getKnownUtxos**(`params`): `Promise`\<[`Utxo`](namespaces/CkBtcMinterDid.md#utxo-1)[]\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:266](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L266)

Returns UTXOs of the given account known by the minter.

###### Parameters

###### params

[`GetKnownUtxosParams`](#getknownutxosparams)

The parameters for which the known utxos should be resolved.

###### Returns

`Promise`\<[`Utxo`](namespaces/CkBtcMinterDid.md#utxo-1)[]\>

The known utxos (with no guarantee in the ordering).

##### getMinterInfo()

> **getMinterInfo**(`params`): `Promise`\<[`MinterInfo`](namespaces/CkBtcMinterDid.md#minterinfo)\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:251](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L251)

Returns internal minter parameters such as the minimal amount to retrieve BTC, minimal number of confirmations or KYT fee.

###### Parameters

###### params

`QueryParams`

The parameters to get the minter info.

###### Returns

`Promise`\<[`MinterInfo`](namespaces/CkBtcMinterDid.md#minterinfo)\>

##### getWithdrawalAccount()

> **getWithdrawalAccount**(): `Promise`\<[`Account`](namespaces/CkBtcMinterDid.md#account)\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:102](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L102)

Returns the account to which the caller should deposit ckBTC before withdrawing BTC using the [retrieveBtc] endpoint.

###### Returns

`Promise`\<[`Account`](namespaces/CkBtcMinterDid.md#account)\>

The account to which ckBTC needs to be transferred. Provide corresponding information to map an Icrc1 account.

##### retrieveBtc()

> **retrieveBtc**(`params`): `Promise`\<[`RetrieveBtcOk`](namespaces/CkBtcMinterDid.md#retrievebtcok)\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:121](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L121)

Submits a request to convert ckBTC to BTC.

Note:

The BTC retrieval process is slow. Instead of synchronously waiting for a BTC transaction to settle, this method returns a request ([block_index]) that the caller can use to query the request status.

Preconditions:

The caller deposited the requested amount in ckBTC to the account that the [getWithdrawalAccount] endpoint returns.

###### Parameters

###### params

[`RetrieveBtcParams`](#retrievebtcparams)

The parameters are the bitcoin address and amount to convert.

###### Returns

`Promise`\<[`RetrieveBtcOk`](namespaces/CkBtcMinterDid.md#retrievebtcok)\>

The result or the operation.

##### retrieveBtcStatus()

> **retrieveBtcStatus**(`transactionId`): `Promise`\<[`RetrieveBtcStatus`](namespaces/CkBtcMinterDid.md#retrievebtcstatus)\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:185](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L185)

Returns the status of a specific BTC withdrawal based on the transaction ID
of the corresponding burn transaction.

###### Parameters

###### transactionId

The ID of the corresponding burn transaction.

###### certified

`boolean`

###### transactionId

`bigint`

###### Returns

`Promise`\<[`RetrieveBtcStatus`](namespaces/CkBtcMinterDid.md#retrievebtcstatus)\>

The status of the BTC retrieval request.

##### retrieveBtcStatusV2ByAccount()

> **retrieveBtcStatusV2ByAccount**(`certified`): `Promise`\<[`RetrieveBtcStatusV2WithId`](#retrievebtcstatusv2withid)[]\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L203)

Returns the status of all BTC withdrawals for an account.

###### Parameters

###### certified

[`RetrieveBtcStatusV2ByAccountParams`](#retrievebtcstatusv2byaccountparams)

query or update call

###### Returns

`Promise`\<[`RetrieveBtcStatusV2WithId`](#retrievebtcstatusv2withid)[]\>

The statuses of the BTC retrieval requests.

##### retrieveBtcWithApproval()

> **retrieveBtcWithApproval**(`__namedParameters`): `Promise`\<[`RetrieveBtcOk`](namespaces/CkBtcMinterDid.md#retrievebtcok)\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:153](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L153)

Submits a request to convert ckBTC to BTC after making an ICRC-2 approval.


The BTC retrieval process is slow. Instead of synchronously waiting for a BTC transaction to settle, this method returns a request ([block_index]) that the caller can use to query the request status.

# Preconditions

The caller allowed the minter's principal to spend its funds using
[icrc2_approve] on the ckBTC ledger.

###### Parameters

###### \_\_namedParameters

###### address

`string`

###### amount

`bigint`

###### fromSubaccount?

`Uint8Array`\<`ArrayBufferLike`\>

###### Returns

`Promise`\<[`RetrieveBtcOk`](namespaces/CkBtcMinterDid.md#retrievebtcok)\>

The result or the operation.

##### updateBalance()

> **updateBalance**(`params`): `Promise`\<[`UpdateBalanceOk`](#updatebalanceok)\>

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L79)

Notify the minter about the bitcoin transfer.

Upon successful notification, new ckBTC should be available on the targeted address.

###### Parameters

###### params

[`MinterParams`](#minterparams)

The parameters are the address to which bitcoin where transferred.

###### Returns

`Promise`\<[`UpdateBalanceOk`](#updatebalanceok)\>

The result of the balance update.

##### create()

> `static` **create**(`options`): [`CkBtcMinterCanister`](#ckbtcmintercanister)

Defined in: [packages/canisters/src/ckbtc/minter.canister.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/minter.canister.ts#L39)

###### Parameters

###### options

[`CkBtcCanisterOptions`](#ckbtccanisteroptions)\<[`_SERVICE`](namespaces/CkBtcMinterDid.md#_service)\>

###### Returns

[`CkBtcMinterCanister`](#ckbtcmintercanister)

***

### MinterAlreadyProcessingError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L6)

#### Extends

- [`MinterGenericError`](#mintergenericerror)

#### Constructors

##### Constructor

> **new MinterAlreadyProcessingError**(`message?`): [`MinterAlreadyProcessingError`](#minteralreadyprocessingerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterAlreadyProcessingError`](#minteralreadyprocessingerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

##### Constructor

> **new MinterAlreadyProcessingError**(`message?`, `options?`): [`MinterAlreadyProcessingError`](#minteralreadyprocessingerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterAlreadyProcessingError`](#minteralreadyprocessingerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`cause`](#cause-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`prepareStackTrace`](#preparestacktrace-4)

***

### MinterAmountTooLowError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L27)

#### Extends

- [`MinterRetrieveBtcError`](#minterretrievebtcerror)

#### Constructors

##### Constructor

> **new MinterAmountTooLowError**(`message?`): [`MinterAmountTooLowError`](#minteramounttoolowerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterAmountTooLowError`](#minteramounttoolowerror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

##### Constructor

> **new MinterAmountTooLowError**(`message?`, `options?`): [`MinterAmountTooLowError`](#minteramounttoolowerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterAmountTooLowError`](#minteramounttoolowerror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`cause`](#cause-7)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`message`](#message-7)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`name`](#name-7)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stack`](#stack-7)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stackTraceLimit`](#stacktracelimit-7)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`captureStackTrace`](#capturestacktrace-14)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`isError`](#iserror-14)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`prepareStackTrace`](#preparestacktrace-14)

***

### MinterGenericError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L4)

#### Extends

- `Error`

#### Extended by

- [`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)
- [`MinterAlreadyProcessingError`](#minteralreadyprocessingerror)
- [`MinterUpdateBalanceError`](#minterupdatebalanceerror)
- [`MinterRetrieveBtcError`](#minterretrievebtcerror)

#### Constructors

##### Constructor

> **new MinterGenericError**(`message?`): [`MinterGenericError`](#mintergenericerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterGenericError`](#mintergenericerror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new MinterGenericError**(`message?`, `options?`): [`MinterGenericError`](#mintergenericerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterGenericError`](#mintergenericerror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### MinterInsufficientAllowanceError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L29)

#### Extends

- [`MinterRetrieveBtcError`](#minterretrievebtcerror)

#### Constructors

##### Constructor

> **new MinterInsufficientAllowanceError**(`message?`): [`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

##### Constructor

> **new MinterInsufficientAllowanceError**(`message?`, `options?`): [`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`cause`](#cause-7)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`message`](#message-7)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`name`](#name-7)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stack`](#stack-7)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stackTraceLimit`](#stacktracelimit-7)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`captureStackTrace`](#capturestacktrace-14)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`isError`](#iserror-14)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`prepareStackTrace`](#preparestacktrace-14)

***

### MinterInsufficientFundsError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L28)

#### Extends

- [`MinterRetrieveBtcError`](#minterretrievebtcerror)

#### Constructors

##### Constructor

> **new MinterInsufficientFundsError**(`message?`): [`MinterInsufficientFundsError`](#minterinsufficientfundserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterInsufficientFundsError`](#minterinsufficientfundserror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

##### Constructor

> **new MinterInsufficientFundsError**(`message?`, `options?`): [`MinterInsufficientFundsError`](#minterinsufficientfundserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterInsufficientFundsError`](#minterinsufficientfundserror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`cause`](#cause-7)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`message`](#message-7)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`name`](#name-7)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stack`](#stack-7)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stackTraceLimit`](#stacktracelimit-7)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`captureStackTrace`](#capturestacktrace-14)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`isError`](#iserror-14)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`prepareStackTrace`](#preparestacktrace-14)

***

### MinterMalformedAddressError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L26)

#### Extends

- [`MinterRetrieveBtcError`](#minterretrievebtcerror)

#### Constructors

##### Constructor

> **new MinterMalformedAddressError**(`message?`): [`MinterMalformedAddressError`](#mintermalformedaddresserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterMalformedAddressError`](#mintermalformedaddresserror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

##### Constructor

> **new MinterMalformedAddressError**(`message?`, `options?`): [`MinterMalformedAddressError`](#mintermalformedaddresserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterMalformedAddressError`](#mintermalformedaddresserror)

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`constructor`](#constructor-9)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`cause`](#cause-7)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`message`](#message-7)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`name`](#name-7)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stack`](#stack-7)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`stackTraceLimit`](#stacktracelimit-7)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`captureStackTrace`](#capturestacktrace-14)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`isError`](#iserror-14)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterRetrieveBtcError`](#minterretrievebtcerror).[`prepareStackTrace`](#preparestacktrace-14)

***

### MinterNoNewUtxosError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L9)

#### Extends

- [`MinterUpdateBalanceError`](#minterupdatebalanceerror)

#### Constructors

##### Constructor

> **new MinterNoNewUtxosError**(`__namedParameters`): [`MinterNoNewUtxosError`](#minternonewutxoserror)

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L12)

###### Parameters

###### \_\_namedParameters

###### pending_utxos

\[\] \| \[[`PendingUtxo`](namespaces/CkBtcMinterDid.md#pendingutxo)[]\]

###### required_confirmations

`number`

###### Returns

[`MinterNoNewUtxosError`](#minternonewutxoserror)

###### Overrides

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`constructor`](#constructor-11)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`cause`](#cause-9)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`message`](#message-9)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`name`](#name-9)

##### pendingUtxos

> `readonly` **pendingUtxos**: [`PendingUtxo`](namespaces/CkBtcMinterDid.md#pendingutxo)[]

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L10)

##### requiredConfirmations

> `readonly` **requiredConfirmations**: `number`

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`stack`](#stack-9)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`stackTraceLimit`](#stacktracelimit-9)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`captureStackTrace`](#capturestacktrace-18)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`isError`](#iserror-18)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterUpdateBalanceError`](#minterupdatebalanceerror).[`prepareStackTrace`](#preparestacktrace-18)

***

### MinterRetrieveBtcError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L25)

#### Extends

- [`MinterGenericError`](#mintergenericerror)

#### Extended by

- [`MinterMalformedAddressError`](#mintermalformedaddresserror)
- [`MinterAmountTooLowError`](#minteramounttoolowerror)
- [`MinterInsufficientFundsError`](#minterinsufficientfundserror)
- [`MinterInsufficientAllowanceError`](#minterinsufficientallowanceerror)

#### Constructors

##### Constructor

> **new MinterRetrieveBtcError**(`message?`): [`MinterRetrieveBtcError`](#minterretrievebtcerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterRetrieveBtcError`](#minterretrievebtcerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

##### Constructor

> **new MinterRetrieveBtcError**(`message?`, `options?`): [`MinterRetrieveBtcError`](#minterretrievebtcerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterRetrieveBtcError`](#minterretrievebtcerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`cause`](#cause-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`prepareStackTrace`](#preparestacktrace-4)

***

### MinterTemporaryUnavailableError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L5)

#### Extends

- [`MinterGenericError`](#mintergenericerror)

#### Constructors

##### Constructor

> **new MinterTemporaryUnavailableError**(`message?`): [`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

##### Constructor

> **new MinterTemporaryUnavailableError**(`message?`, `options?`): [`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterTemporaryUnavailableError`](#mintertemporaryunavailableerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`cause`](#cause-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`prepareStackTrace`](#preparestacktrace-4)

***

### MinterUpdateBalanceError

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L8)

#### Extends

- [`MinterGenericError`](#mintergenericerror)

#### Extended by

- [`MinterNoNewUtxosError`](#minternonewutxoserror)

#### Constructors

##### Constructor

> **new MinterUpdateBalanceError**(`message?`): [`MinterUpdateBalanceError`](#minterupdatebalanceerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`MinterUpdateBalanceError`](#minterupdatebalanceerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

##### Constructor

> **new MinterUpdateBalanceError**(`message?`, `options?`): [`MinterUpdateBalanceError`](#minterupdatebalanceerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`MinterUpdateBalanceError`](#minterupdatebalanceerror)

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`constructor`](#constructor-4)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`cause`](#cause-2)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`message`](#message-2)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`name`](#name-2)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stack`](#stack-2)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`stackTraceLimit`](#stacktracelimit-2)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`captureStackTrace`](#capturestacktrace-4)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`isError`](#iserror-4)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`MinterGenericError`](#mintergenericerror).[`prepareStackTrace`](#preparestacktrace-4)

***

### ParseBtcAddressBadWitnessLengthError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L5)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressBadWitnessLengthError**(`message?`): [`ParseBtcAddressBadWitnessLengthError`](#parsebtcaddressbadwitnesslengtherror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressBadWitnessLengthError`](#parsebtcaddressbadwitnesslengtherror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressBadWitnessLengthError**(`message?`, `options?`): [`ParseBtcAddressBadWitnessLengthError`](#parsebtcaddressbadwitnesslengtherror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressBadWitnessLengthError`](#parsebtcaddressbadwitnesslengtherror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

***

### ParseBtcAddressError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:1](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L1)

#### Extends

- `Error`

#### Extended by

- [`ParseBtcAddressInvalidError`](#parsebtcaddressinvaliderror)
- [`ParseBtcAddressNoDataError`](#parsebtcaddressnodataerror)
- [`ParseBtcAddressUnsupportedAddressTypeError`](#parsebtcaddressunsupportedaddresstypeerror)
- [`ParseBtcAddressBadWitnessLengthError`](#parsebtcaddressbadwitnesslengtherror)
- [`ParseBtcAddressUnsupportedWitnessVersionError`](#parsebtcaddressunsupportedwitnessversionerror)
- [`ParseBtcAddressUnexpectedHumanReadablePartError`](#parsebtcaddressunexpectedhumanreadableparterror)
- [`ParseBtcAddressMalformedAddressError`](#parsebtcaddressmalformedaddresserror)
- [`ParseBtcAddressWrongNetworkError`](#parsebtcaddresswrongnetworkerror)

#### Constructors

##### Constructor

> **new ParseBtcAddressError**(`message?`): [`ParseBtcAddressError`](#parsebtcaddresserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressError`](#parsebtcaddresserror)

###### Inherited from

`Error.constructor`

##### Constructor

> **new ParseBtcAddressError**(`message?`, `options?`): [`ParseBtcAddressError`](#parsebtcaddresserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressError`](#parsebtcaddresserror)

###### Inherited from

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

`Error.name`

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

`Error.isError`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### ParseBtcAddressInvalidError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:2](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L2)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressInvalidError**(`message?`): [`ParseBtcAddressInvalidError`](#parsebtcaddressinvaliderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressInvalidError`](#parsebtcaddressinvaliderror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressInvalidError**(`message?`, `options?`): [`ParseBtcAddressInvalidError`](#parsebtcaddressinvaliderror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressInvalidError`](#parsebtcaddressinvaliderror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

***

### ParseBtcAddressMalformedAddressError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:8](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L8)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressMalformedAddressError**(`message?`): [`ParseBtcAddressMalformedAddressError`](#parsebtcaddressmalformedaddresserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressMalformedAddressError`](#parsebtcaddressmalformedaddresserror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressMalformedAddressError**(`message?`, `options?`): [`ParseBtcAddressMalformedAddressError`](#parsebtcaddressmalformedaddresserror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressMalformedAddressError`](#parsebtcaddressmalformedaddresserror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

***

### ParseBtcAddressNoDataError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L3)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressNoDataError**(`message?`): [`ParseBtcAddressNoDataError`](#parsebtcaddressnodataerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressNoDataError`](#parsebtcaddressnodataerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressNoDataError**(`message?`, `options?`): [`ParseBtcAddressNoDataError`](#parsebtcaddressnodataerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressNoDataError`](#parsebtcaddressnodataerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

***

### ParseBtcAddressUnexpectedHumanReadablePartError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L7)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressUnexpectedHumanReadablePartError**(`message?`): [`ParseBtcAddressUnexpectedHumanReadablePartError`](#parsebtcaddressunexpectedhumanreadableparterror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressUnexpectedHumanReadablePartError`](#parsebtcaddressunexpectedhumanreadableparterror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressUnexpectedHumanReadablePartError**(`message?`, `options?`): [`ParseBtcAddressUnexpectedHumanReadablePartError`](#parsebtcaddressunexpectedhumanreadableparterror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressUnexpectedHumanReadablePartError`](#parsebtcaddressunexpectedhumanreadableparterror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

***

### ParseBtcAddressUnsupportedAddressTypeError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L4)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressUnsupportedAddressTypeError**(`message?`): [`ParseBtcAddressUnsupportedAddressTypeError`](#parsebtcaddressunsupportedaddresstypeerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressUnsupportedAddressTypeError`](#parsebtcaddressunsupportedaddresstypeerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressUnsupportedAddressTypeError**(`message?`, `options?`): [`ParseBtcAddressUnsupportedAddressTypeError`](#parsebtcaddressunsupportedaddresstypeerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressUnsupportedAddressTypeError`](#parsebtcaddressunsupportedaddresstypeerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

***

### ParseBtcAddressUnsupportedWitnessVersionError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L6)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressUnsupportedWitnessVersionError**(`message?`): [`ParseBtcAddressUnsupportedWitnessVersionError`](#parsebtcaddressunsupportedwitnessversionerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressUnsupportedWitnessVersionError`](#parsebtcaddressunsupportedwitnessversionerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressUnsupportedWitnessVersionError**(`message?`, `options?`): [`ParseBtcAddressUnsupportedWitnessVersionError`](#parsebtcaddressunsupportedwitnessversionerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressUnsupportedWitnessVersionError`](#parsebtcaddressunsupportedwitnessversionerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

***

### ParseBtcAddressWrongNetworkError

Defined in: [packages/canisters/src/ckbtc/errors/btc.errors.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/btc.errors.ts#L9)

#### Extends

- [`ParseBtcAddressError`](#parsebtcaddresserror)

#### Constructors

##### Constructor

> **new ParseBtcAddressWrongNetworkError**(`message?`): [`ParseBtcAddressWrongNetworkError`](#parsebtcaddresswrongnetworkerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### Returns

[`ParseBtcAddressWrongNetworkError`](#parsebtcaddresswrongnetworkerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

##### Constructor

> **new ParseBtcAddressWrongNetworkError**(`message?`, `options?`): [`ParseBtcAddressWrongNetworkError`](#parsebtcaddresswrongnetworkerror)

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1082

###### Parameters

###### message?

`string`

###### options?

`ErrorOptions`

###### Returns

[`ParseBtcAddressWrongNetworkError`](#parsebtcaddresswrongnetworkerror)

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`constructor`](#constructor-13)

#### Properties

##### cause?

> `optional` **cause**: `unknown`

Defined in: node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`cause`](#cause-11)

##### message

> **message**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`message`](#message-11)

##### name

> **name**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1076

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`name`](#name-11)

##### stack?

> `optional` **stack**: `string`

Defined in: node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stack`](#stack-11)

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`stackTraceLimit`](#stacktracelimit-11)

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`captureStackTrace`](#capturestacktrace-22)

##### isError()

> `static` **isError**(`error`): `error is Error`

Defined in: node\_modules/typescript/lib/lib.esnext.error.d.ts:23

Indicates whether the argument provided is a built-in Error instance or not.

###### Parameters

###### error

`unknown`

###### Returns

`error is Error`

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`isError`](#iserror-22)

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

[`ParseBtcAddressError`](#parsebtcaddresserror).[`prepareStackTrace`](#preparestacktrace-22)

## Interfaces

### BtcAddress

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L3)

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L4)

##### network?

> `optional` **network**: [`BtcNetwork`](#btcnetwork)

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L5)

***

### BtcAddressInfo

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:8](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L8)

#### Extends

- `Required`\<[`BtcAddress`](#btcaddress)\>

#### Properties

##### address

> **address**: `string`

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L4)

###### Inherited from

[`BtcAddress`](#btcaddress).[`address`](#address)

##### network

> **network**: [`BtcNetwork`](#btcnetwork)

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L5)

###### Inherited from

[`BtcAddress`](#btcaddress).[`network`](#network)

##### parser

> **parser**: `"bip-173"` \| `"base58"`

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L9)

##### type

> **type**: [`BtcAddressType`](#btcaddresstype)

Defined in: [packages/canisters/src/ckbtc/types/btc.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/btc.ts#L10)

***

### CkBtcCanisterOptions

Defined in: [packages/canisters/src/ckbtc/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/canister.options.ts#L4)

#### Extends

- `Omit`\<`CanisterOptions`\<`T`\>, `"canisterId"`\>

#### Type Parameters

##### T

`T`

#### Properties

##### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

###### Inherited from

[`NnsGovernanceCanisterOptions`](../nns/index.md#nnsgovernancecanisteroptions).[`agent`](../nns/index.md#agent)

##### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ckbtc/types/canister.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/canister.options.ts#L9)

##### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

###### Inherited from

`Omit.certifiedServiceOverride`

##### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

###### Inherited from

`Omit.serviceOverride`

***

### EstimateWithdrawalFee

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L17)

#### Properties

##### bitcoin\_fee

> **bitcoin\_fee**: `bigint`

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L19)

##### minter\_fee

> **minter\_fee**: `bigint`

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L18)

***

### MinterAccount

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L5)

#### Properties

##### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L6)

##### subaccount?

> `optional` **subaccount**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L7)

***

### RetrieveBtcStatusV2WithId

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:22](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L22)

#### Properties

##### id

> **id**: `bigint`

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:23](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L23)

##### status

> **status**: [`RetrieveBtcStatusV2`](namespaces/CkBtcMinterDid.md#retrievebtcstatusv2) \| `undefined`

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L24)

## Type Aliases

### BitcoinNetwork

> **BitcoinNetwork** = `"testnet"` \| `"mainnet"` \| `"regtest"`

Defined in: [packages/canisters/src/ckbtc/types/bitcoin.params.ts:4](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/bitcoin.params.ts#L4)

***

### EstimateWithdrawalFeeParams

> **EstimateWithdrawalFeeParams** = `QueryParams` & `object`

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L32)

Params to estimate the fee of the Bitcoin network.

#### Type Declaration

##### amount

> **amount**: `bigint` \| `undefined`

***

### GetBalanceParams

> **GetBalanceParams** = `Omit`\<[`get_balance_request`](namespaces/BitcoinDid.md#get_balance_request), `"network"` \| `"min_confirmations"`\> & `object` & `Omit`\<`QueryParams`, `"certified"`\>

Defined in: [packages/canisters/src/ckbtc/types/bitcoin.params.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/bitcoin.params.ts#L36)

#### Type Declaration

##### minConfirmations?

> `optional` **minConfirmations**: `number`

##### network

> **network**: [`BitcoinNetwork`](#bitcoinnetwork)

***

### GetBTCAddressParams

> **GetBTCAddressParams** = [`MinterParams`](#minterparams)

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L16)

Params to get a BTC address.

***

### GetKnownUtxosParams

> **GetKnownUtxosParams** = `QueryParams` & [`MinterParams`](#minterparams)

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:46](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L46)

Params to get the known utxos.

***

### GetUtxosParams

> **GetUtxosParams** = `Omit`\<[`get_utxos_request`](namespaces/BitcoinDid.md#get_utxos_request), `"network"` \| `"filter"`\> & `object` & `Omit`\<`QueryParams`, `"certified"`\>

Defined in: [packages/canisters/src/ckbtc/types/bitcoin.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/bitcoin.params.ts#L12)

#### Type Declaration

##### filter?

> `optional` **filter**: \{ `page`: `Uint8Array`; \} \| \{ `minConfirmations`: `number`; \}

##### network

> **network**: [`BitcoinNetwork`](#bitcoinnetwork)

***

### MinterParams

> **MinterParams** = `Omit`\<`QueryParams`, `"certified"`\> & `Partial`\<[`MinterAccount`](#minteraccount)\>

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L10)

***

### RetrieveBtcParams

> **RetrieveBtcParams** = [`RetrieveBtcArgs`](namespaces/CkBtcMinterDid.md#retrievebtcargs) & `Omit`\<`QueryParams`, `"certified"`\>

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:26](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L26)

Params to convert ckBTC to Bitcoin.

***

### RetrieveBtcResponse

> **RetrieveBtcResponse** = \{ `Ok`: [`RetrieveBtcOk`](namespaces/CkBtcMinterDid.md#retrievebtcok); \} \| \{ `Err`: [`RetrieveBtcError`](namespaces/CkBtcMinterDid.md#retrievebtcerror); \}

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L9)

***

### RetrieveBtcStatusV2ByAccountParams

> **RetrieveBtcStatusV2ByAccountParams** = `QueryParams` & `object`

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:39](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L39)

Params to retrieve the status of all BTC withdrawals for an account.

#### Type Declaration

##### account?

> `optional` **account**: [`MinterAccount`](#minteraccount)

***

### RetrieveBtcWithApprovalResponse

> **RetrieveBtcWithApprovalResponse** = \{ `Ok`: [`RetrieveBtcOk`](namespaces/CkBtcMinterDid.md#retrievebtcok); \} \| \{ `Err`: [`RetrieveBtcWithApprovalError`](namespaces/CkBtcMinterDid.md#retrievebtcwithapprovalerror); \}

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:13](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L13)

***

### UpdateBalanceOk

> **UpdateBalanceOk** = [`UtxoStatus`](namespaces/CkBtcMinterDid.md#utxostatus)[]

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:3](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L3)

***

### UpdateBalanceParams

> **UpdateBalanceParams** = [`MinterParams`](#minterparams)

Defined in: [packages/canisters/src/ckbtc/types/minter.params.ts:21](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.params.ts#L21)

Params to update ckBTC balance after a bitcoin transfer.

***

### UpdateBalanceResponse

> **UpdateBalanceResponse** = \{ `Ok`: [`UpdateBalanceOk`](#updatebalanceok); \} \| \{ `Err`: [`UpdateBalanceError`](namespaces/CkBtcMinterDid.md#updatebalanceerror); \}

Defined in: [packages/canisters/src/ckbtc/types/minter.responses.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/minter.responses.ts#L5)

## Functions

### createRetrieveBtcError()

> **createRetrieveBtcError**(`Err`): [`MinterGenericError`](#mintergenericerror)

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:74](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L74)

#### Parameters

##### Err

[`RetrieveBtcError`](namespaces/CkBtcMinterDid.md#retrievebtcerror)

#### Returns

[`MinterGenericError`](#mintergenericerror)

***

### createRetrieveBtcWithApprovalError()

> **createRetrieveBtcWithApprovalError**(`Err`): [`MinterGenericError`](#mintergenericerror)

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:101](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L101)

#### Parameters

##### Err

[`RetrieveBtcWithApprovalError`](namespaces/CkBtcMinterDid.md#retrievebtcwithapprovalerror)

#### Returns

[`MinterGenericError`](#mintergenericerror)

***

### createUpdateBalanceError()

> **createUpdateBalanceError**(`Err`): [`MinterGenericError`](#mintergenericerror)

Defined in: [packages/canisters/src/ckbtc/errors/minter.errors.ts:55](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/errors/minter.errors.ts#L55)

#### Parameters

##### Err

[`UpdateBalanceError`](namespaces/CkBtcMinterDid.md#updatebalanceerror)

#### Returns

[`MinterGenericError`](#mintergenericerror)

***

### parseBtcAddress()

> **parseBtcAddress**(`params`): [`BtcAddressInfo`](#btcaddressinfo)

Defined in: [packages/canisters/src/ckbtc/utils/btc.utils.ts:195](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/utils/btc.utils.ts#L195)

Parse a Bitcoin address.

Parse implementation follows strategy implemented in [Minter canister](https://github.com/dfinity/ic/blob/a8da3aa23dc6f8f4708cb0cb8edce84c5bd8f225/rs/bitcoin/ckbtc/minter/src/address.rs#L54).

Credits: Parts of JavaScript code and test values from [bitcoin-address-validation](https://github.com/ruigomeseu/bitcoin-address-validation).

#### Parameters

##### params

[`BtcAddress`](#btcaddress)

The Bitcoin address and network to parse

#### Returns

[`BtcAddressInfo`](#btcaddressinfo)

***

### toGetBalanceParams()

> **toGetBalanceParams**(`__namedParameters`): [`get_balance_request`](namespaces/BitcoinDid.md#get_balance_request)

Defined in: [packages/canisters/src/ckbtc/types/bitcoin.params.ts:44](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/bitcoin.params.ts#L44)

#### Parameters

##### \_\_namedParameters

[`GetBalanceParams`](#getbalanceparams)

#### Returns

[`get_balance_request`](namespaces/BitcoinDid.md#get_balance_request)

***

### toGetUtxosParams()

> **toGetUtxosParams**(`__namedParameters`): [`get_utxos_request`](namespaces/BitcoinDid.md#get_utxos_request)

Defined in: [packages/canisters/src/ckbtc/types/bitcoin.params.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c8d4fed676e8b86220cb86b565fc50f9ef0a8994/packages/canisters/src/ckbtc/types/bitcoin.params.ts#L20)

#### Parameters

##### \_\_namedParameters

[`GetUtxosParams`](#getutxosparams)

#### Returns

[`get_utxos_request`](namespaces/BitcoinDid.md#get_utxos_request)
