---
title: UpgradeArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:251](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L251)

## Properties

### archive\_compressed\_wasm\_hash

> **archive\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L268)

Hexadecimal encoding of the SHA2-256 archive compressed wasm hash, e.g.,
"b24812976b2cc64f12faf813cf592631f3062bfda837334f77ab807361d64e82".
This exact version will be used for upgrading all existing archive canisters managed by the orchestrator.
Leaving this field empty will not upgrade the archive canisters.

***

### cycles\_management

> **cycles\_management**: \[\] \| \[[`UpdateCyclesManagement`](UpdateCyclesManagement.md)\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L261)

Update the cycles management of the canisters managed by the orchestrator.

***

### git\_commit\_hash

> **git\_commit\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L276)

Hexadecimal encoding of the SHA-1 git commit hash used for this upgrade, e.g.,
"51d01d3936498d4010de54505d6433e9ad5cc62b", corresponding to a git revision in the
[IC repository](https://github.com/dfinity/ic).
If this field is present, the orchestrator will register all embedded wasms (ledger, index, and archive) in its stable memory,
so that those exact wasms can be used to upgrade managed canisters as specified below.

***

### index\_compressed\_wasm\_hash

> **index\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L290)

Hexadecimal encoding of the SHA2-256 index compressed wasm hash, e.g.,
"3a6d39b5e94cdef5203bca62720e75a28cd071ff434d22b9746403ac7ae59614".
This exact version will be used for upgrading all existing index canisters managed by the orchestrator.
Leaving this field empty will not upgrade the index canisters.

***

### ledger\_compressed\_wasm\_hash

> **ledger\_compressed\_wasm\_hash**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L283)

Hexadecimal encoding of the SHA2-256 ledger compressed wasm hash, e.g.,
"3148f7a9f1b0ee39262c8abe3b08813480cf78551eee5a60ab1cf38433b5d9b0".
This exact version will be used for upgrading all existing ledger canisters managed by the orchestrator.
Leaving this field empty will not upgrade the ledger canisters.

***

### manage\_ledger\_suites

> **manage\_ledger\_suites**: \[\] \| \[[`InstalledLedgerSuite`](InstalledLedgerSuite.md)[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:257](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L257)

Add already installed ledger suites to the canisters managed by the orchestrator.
Those ledger suites are *NOT* necessarily ckERC20 tokens.
This assumes that the orchestrator is a controller of all the canisters in the list.
