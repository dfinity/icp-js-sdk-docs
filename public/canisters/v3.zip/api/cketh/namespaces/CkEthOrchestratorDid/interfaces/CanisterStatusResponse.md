---
title: CanisterStatusResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L17)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L20)

***

### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L23)

***

### memory\_size

> **memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L19)

***

### module\_hash

> **module\_hash**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L24)

***

### query\_stats

> **query\_stats**: [`QueryStats`](QueryStats.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L22)

***

### reserved\_cycles

> **reserved\_cycles**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L25)

***

### settings

> **settings**: [`DefiniteCanisterSettings`](DefiniteCanisterSettings.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L21)

***

### status

> **status**: [`CanisterStatusType`](../type-aliases/CanisterStatusType.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L18)
