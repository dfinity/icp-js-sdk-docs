---
title: Erc20Contract
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L58)

## Properties

### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L60)

***

### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L59)
