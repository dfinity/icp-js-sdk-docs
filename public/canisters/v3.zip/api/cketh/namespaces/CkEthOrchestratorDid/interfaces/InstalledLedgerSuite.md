---
title: InstalledLedgerSuite
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L81)

## Properties

### archives

> **archives**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L97)

List of archive canister ids

***

### index

> **index**: [`InstalledCanister`](InstalledCanister.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L93)

Index canister

***

### ledger

> **ledger**: [`InstalledCanister`](InstalledCanister.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L89)

Ledger canister

***

### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:85](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L85)

Token symbol on the ledger
