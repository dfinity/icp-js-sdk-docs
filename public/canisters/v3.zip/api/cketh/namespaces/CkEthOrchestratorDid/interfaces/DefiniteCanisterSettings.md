---
title: DefiniteCanisterSettings
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L49)

## Properties

### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L56)

***

### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L51)

***

### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L50)

***

### log\_visibility

> **log\_visibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L53)

***

### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L55)

***

### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L52)

***

### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L54)
