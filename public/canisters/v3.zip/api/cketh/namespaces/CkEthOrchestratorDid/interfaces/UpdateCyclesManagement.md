---
title: UpdateCyclesManagement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L230)

## Properties

### cycles\_for\_archive\_creation

> **cycles\_for\_archive\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:244](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L244)

Change the number of cycles when creating a new ICRC1 archive canister.
Previously created canisters are not affected.

***

### cycles\_for\_index\_creation

> **cycles\_for\_index\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:249](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L249)

Change the number of cycles when creating a new ICRC1 index canister.
Previously created canisters are not affected.

***

### cycles\_for\_ledger\_creation

> **cycles\_for\_ledger\_creation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L239)

Change the number of cycles when creating a new ICRC1 ledger canister.
Previously created canisters are not affected.

***

### cycles\_top\_up\_increment

> **cycles\_top\_up\_increment**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/orchestrator.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/orchestrator.d.ts#L234)

Change the number of cycles to add to a canister managed by the orchestrator whose cycles balance is running low.
