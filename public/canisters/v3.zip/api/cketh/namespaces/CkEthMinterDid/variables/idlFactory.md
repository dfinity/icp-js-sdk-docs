---
title: idlFactory
editUrl: false
next: true
prev: true
---

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:901](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L901)
