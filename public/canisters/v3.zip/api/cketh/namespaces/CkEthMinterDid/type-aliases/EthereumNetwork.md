---
title: EthereumNetwork
editUrl: false
next: true
prev: true
---

> **EthereumNetwork** = \{ `Mainnet`: `null`; \} \| \{ `Sepolia`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L130)

## Type Declaration

\{ `Mainnet`: `null`; \}

### Mainnet

> **Mainnet**: `null`

The public Ethereum mainnet.

\{ `Sepolia`: `null`; \}

### Sepolia

> **Sepolia**: `null`

The public Ethereum Sepolia testnet.
