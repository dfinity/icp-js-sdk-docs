---
title: EthereumNetwork
editUrl: false
next: true
prev: true
---

> **EthereumNetwork** = \{ `Mainnet`: `null`; \} \| \{ `Sepolia`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L130)

## Type Declaration

\{ `Mainnet`: `null`; \}

### Mainnet

> **Mainnet**: `null`

The public Ethereum mainnet.

\{ `Sepolia`: `null`; \}

### Sepolia

> **Sepolia**: `null`

The public Ethereum Sepolia testnet.
