---
title: ReimbursementIndex
editUrl: false
next: true
prev: true
---

> **ReimbursementIndex** = \{ `CkErc20`: \{ `ckerc20_ledger_burn_index`: `bigint`; `cketh_ledger_burn_index`: `bigint`; `ledger_id`: `Principal`; \}; \} \| \{ `CkEth`: \{ `ledger_burn_index`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:476](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L476)
