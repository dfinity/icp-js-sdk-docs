---
title: WithdrawalSearchParameter
editUrl: false
next: true
prev: true
---

> **WithdrawalSearchParameter** = \{ `ByRecipient`: `string`; \} \| \{ `BySenderAccount`: [`Account`](../interfaces/Account.md); \} \| \{ `ByWithdrawalId`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L776)

Search parameter for withdrawals.

## Type Declaration

\{ `ByRecipient`: `string`; \}

### ByRecipient

> **ByRecipient**: `string`

Search by recipient's ETH address.

\{ `BySenderAccount`: [`Account`](../interfaces/Account.md); \}

### BySenderAccount

> **BySenderAccount**: [`Account`](../interfaces/Account.md)

Search by sender's token account.

\{ `ByWithdrawalId`: `bigint`; \}

### ByWithdrawalId

> **ByWithdrawalId**: `bigint`

Search by ckETH burn index (which is also used to index ckERC20 withdrawals).
