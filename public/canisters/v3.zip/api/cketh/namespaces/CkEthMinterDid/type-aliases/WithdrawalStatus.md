---
title: WithdrawalStatus
editUrl: false
next: true
prev: true
---

> **WithdrawalStatus** = \{ `TxFinalized`: [`TxFinalizedStatus`](TxFinalizedStatus.md); \} \| \{ `TxSent`: [`EthTransaction`](../interfaces/EthTransaction.md); \} \| \{ `TxCreated`: `null`; \} \| \{ `Pending`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:798](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L798)

Status of a withdrawal request.

## Type Declaration

\{ `TxFinalized`: [`TxFinalizedStatus`](TxFinalizedStatus.md); \}

### TxFinalized

> **TxFinalized**: [`TxFinalizedStatus`](TxFinalizedStatus.md)

Transaction already finalized.

\{ `TxSent`: [`EthTransaction`](../interfaces/EthTransaction.md); \}

### TxSent

> **TxSent**: [`EthTransaction`](../interfaces/EthTransaction.md)

Transaction sent but not yet finalized.

\{ `TxCreated`: `null`; \}

### TxCreated

> **TxCreated**: `null`

Transaction created byt not yet sent.

\{ `Pending`: `null`; \}

### Pending

> **Pending**: `null`

Request is pending, i.e. transaction is not yet created.
