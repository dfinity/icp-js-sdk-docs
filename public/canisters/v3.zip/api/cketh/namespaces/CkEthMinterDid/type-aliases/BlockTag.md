---
title: BlockTag
editUrl: false
next: true
prev: true
---

> **BlockTag** = \{ `Safe`: `null`; \} \| \{ `Finalized`: `null`; \} \| \{ `Latest`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L38)

## Type Declaration

\{ `Safe`: `null`; \}

### Safe

> **Safe**: `null`

/ The latest safe head block.

\{ `Finalized`: `null`; \}

### Finalized

> **Finalized**: `null`

/ The latest finalized block.

\{ `Latest`: `null`; \}

### Latest

> **Latest**: `null`

/ The latest mined block.
