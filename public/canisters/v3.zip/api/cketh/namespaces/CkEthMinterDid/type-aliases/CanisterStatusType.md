---
title: CanisterStatusType
editUrl: false
next: true
prev: true
---

> **CanisterStatusType** = \{ `stopped`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `running`: `null`; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L67)
