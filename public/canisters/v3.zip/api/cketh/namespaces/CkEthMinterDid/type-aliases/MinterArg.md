---
title: MinterArg
editUrl: false
next: true
prev: true
---

> **MinterArg** = \{ `UpgradeArg`: [`UpgradeArg`](../interfaces/UpgradeArg.md); \} \| \{ `InitArg`: [`InitArg`](../interfaces/InitArg.md); \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L393)
