---
title: WithdrawalError
editUrl: false
next: true
prev: true
---

> **WithdrawalError** = \{ `TemporarilyUnavailable`: `string`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \} \| \{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:739](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L739)

## Type Declaration

\{ `TemporarilyUnavailable`: `string`; \}

### TemporarilyUnavailable

> **TemporarilyUnavailable**: `string`

The minter or the ckETH ledger is temporarily unavailable, retry the request.
The payload contains a human-readable message explaining what caused the unavailability.

\{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \}

### InsufficientAllowance

> **InsufficientAllowance**: `object`

The allowance given to the minter is too low.

#### InsufficientAllowance.allowance

> **allowance**: `bigint`

\{ `AmountTooLow`: \{ `min_withdrawal_amount`: `bigint`; \}; \}

### AmountTooLow

> **AmountTooLow**: `object`

The withdrawal amount is too low.
The payload contains the minimal withdrawal amount.

#### AmountTooLow.min\_withdrawal\_amount

> **min\_withdrawal\_amount**: `bigint`

\{ `RecipientAddressBlocked`: \{ `address`: `string`; \}; \}

### RecipientAddressBlocked

> **RecipientAddressBlocked**: `object`

Recipient's address is blocked.
No withdrawal can be made to that address.

#### RecipientAddressBlocked.address

> **address**: `string`

\{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

### InsufficientFunds

> **InsufficientFunds**: `object`

The ckETH balance of the withdrawal account is too low.

#### InsufficientFunds.balance

> **balance**: `bigint`
