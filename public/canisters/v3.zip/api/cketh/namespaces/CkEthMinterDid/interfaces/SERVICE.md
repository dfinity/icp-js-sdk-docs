---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:823](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L823)

## Properties

### add\_ckerc20\_token

> **add\_ckerc20\_token**: `ActorMethod`\<\[[`AddCkErc20Token`](AddCkErc20Token.md)\], `undefined`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:828](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L828)

Add a ckERC-20 token to be supported by the minter.
This call is restricted to the orchestrator ID.

***

### eip\_1559\_transaction\_price

> **eip\_1559\_transaction\_price**: `ActorMethod`\<\[\[\] \| \[[`Eip1559TransactionPriceArg`](Eip1559TransactionPriceArg.md)\]\], [`Eip1559TransactionPrice`](Eip1559TransactionPrice.md)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:832](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L832)

Estimate the price of a transaction issued by the minter when converting ckETH to ETH.

***

### get\_canister\_status

> **get\_canister\_status**: `ActorMethod`\<\[\], [`CanisterStatusResponse`](CanisterStatusResponse.md)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:839](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L839)

Retrieve the status of the minter canister.

***

### get\_events

> **get\_events**: `ActorMethod`\<\[\{ `length`: `bigint`; `start`: `bigint`; \}\], \{ `events`: [`Event`](Event.md)[]; `total_event_count`: `bigint`; \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:845](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L845)

Retrieve events from the minter's audit log.
The endpoint can return fewer events than requested to bound the response size.
IMPORTANT: this endpoint is meant as a debugging tool and is not guaranteed to be backwards-compatible.

***

### get\_minter\_info

> **get\_minter\_info**: `ActorMethod`\<\[\], [`MinterInfo`](MinterInfo.md)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:852](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L852)

Returns internal minter parameters

***

### is\_address\_blocked

> **is\_address\_blocked**: `ActorMethod`\<\[`string`\], `boolean`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L856)

Check if an address is blocked by the minter.

***

### minter\_address

> **minter\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:864](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L864)

Retrieve the Ethereum address controlled by the minter:
* Deposits will be transferred from the helper smart contract to this address
* Withdrawals will originate from this address
IMPORTANT: Do NOT send ETH to this address directly. Use the helper smart contract instead so that the minter
knows to which IC principal the funds should be deposited.

***

### retrieve\_eth\_status

> **retrieve\_eth\_status**: `ActorMethod`\<\[`bigint`\], [`RetrieveEthStatus`](../type-aliases/RetrieveEthStatus.md)\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:868](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L868)

Retrieve the status of a Eth withdrawal request.

***

### smart\_contract\_address

> **smart\_contract\_address**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:877](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L877)

Address of the helper smart contract.
Returns "N/A" if the helper smart contract is not set.
IMPORTANT:
* Use this address to send ETH to the minter to convert it to ckETH.
* In case the smart contract needs to be updated the returned address will change!
Always check the address before making a transfer.

***

### withdraw\_erc20

> **withdraw\_erc20**: `ActorMethod`\<\[[`WithdrawErc20Arg`](WithdrawErc20Arg.md)\], \{ `Ok`: [`RetrieveErc20Request`](RetrieveErc20Request.md); \} \| \{ `Err`: [`WithdrawErc20Error`](../type-aliases/WithdrawErc20Error.md); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:881](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L881)

Withdraw the specified amount of ERC-20 tokens to the given Ethereum address.

***

### withdraw\_eth

> **withdraw\_eth**: `ActorMethod`\<\[[`WithdrawalArg`](WithdrawalArg.md)\], \{ `Ok`: [`RetrieveEthRequest`](RetrieveEthRequest.md); \} \| \{ `Err`: [`WithdrawalError`](../type-aliases/WithdrawalError.md); \}\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L889)

Withdraw the specified amount in Wei to the given Ethereum address.
IMPORTANT: The current gas limit is set to 21,000 for a transaction so withdrawals to smart contract addresses will likely fail.

***

### withdrawal\_status

> **withdrawal\_status**: `ActorMethod`\<\[[`WithdrawalSearchParameter`](../type-aliases/WithdrawalSearchParameter.md)\], [`WithdrawalDetail`](WithdrawalDetail.md)[]\>

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:896](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L896)

Return details of all withdrawals matching the given search parameter.
