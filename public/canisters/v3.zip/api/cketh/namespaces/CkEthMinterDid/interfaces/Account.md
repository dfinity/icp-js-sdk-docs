---
title: Account
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L16)

ICRC-1 account type.

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L17)

***

### subaccount

> **subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L18)
