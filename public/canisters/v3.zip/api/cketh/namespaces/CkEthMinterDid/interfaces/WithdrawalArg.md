---
title: WithdrawalArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:688](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L688)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:700](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L700)

The amount of ckETH in Wei that the client wants to withdraw.

***

### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`Subaccount`](../type-aliases/Subaccount.md)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:696](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L696)

The subaccount to burn ckETH from.

***

### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:692](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L692)

The address to which the minter should deposit ETH.
