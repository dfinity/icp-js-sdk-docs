---
title: DefiniteCanisterSettings
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L76)

## Properties

### compute\_allocation

> **compute\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L83)

***

### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L78)

***

### freezing\_threshold

> **freezing\_threshold**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L77)

***

### log\_visibility

> **log\_visibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L80)

***

### memory\_allocation

> **memory\_allocation**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L82)

***

### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L79)

***

### wasm\_memory\_limit

> **wasm\_memory\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L81)
