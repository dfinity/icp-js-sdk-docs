---
title: QueryStats
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:470](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L470)

## Properties

### num\_calls\_total

> **num\_calls\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:473](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L473)

***

### num\_instructions\_total

> **num\_instructions\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:472](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L472)

***

### request\_payload\_bytes\_total

> **request\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:474](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L474)

***

### response\_payload\_bytes\_total

> **response\_payload\_bytes\_total**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:471](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L471)
