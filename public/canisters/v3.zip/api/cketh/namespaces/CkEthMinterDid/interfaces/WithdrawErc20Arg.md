---
title: WithdrawErc20Arg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L627)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:649](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L649)

Amount of tokens to withdraw.
The amount is in the smallest unit of the token, e.g.,
ckUSDC uses 6 decimals and so to withdraw 1 ckUSDC, the amount should be 1_000_000.

***

### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L631)

The ledger ID for that ckERC20 token.

***

### from\_ckerc20\_subaccount

> **from\_ckerc20\_subaccount**: \[\] \| \[[`Subaccount`](../type-aliases/Subaccount.md)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:643](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L643)

The subaccount to burn ckERC20 from.

***

### from\_cketh\_subaccount

> **from\_cketh\_subaccount**: \[\] \| \[[`Subaccount`](../type-aliases/Subaccount.md)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:639](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L639)

The subaccount to burn ckETH from to pay for the transaction fee.

***

### recipient

> **recipient**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:635](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L635)

Ethereum address to withdraw to.
