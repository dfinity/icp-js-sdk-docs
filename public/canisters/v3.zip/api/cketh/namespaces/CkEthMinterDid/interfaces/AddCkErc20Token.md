---
title: AddCkErc20Token
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L20)

## Properties

### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L32)

The Ethereum address of the ERC-20 smart contract.

***

### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L28)

Ethereum chain ID.

***

### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L24)

The ledger ID for that ckERC20 token.

***

### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L36)

The ckERC20 token symbol on the ledger.
