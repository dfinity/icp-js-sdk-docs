---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L304)

The initialization parameters of the minter canister.

## Properties

### ecdsa\_key\_name

> **ecdsa\_key\_name**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L318)

The name of the ECDSA key to use.
E.g., "dfx_test_key" on the local replica.

***

### ethereum\_block\_height

> **ethereum\_block\_height**: [`BlockTag`](../type-aliases/BlockTag.md)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L346)

Determine ethereum block height observed by minter.

***

### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L338)

Address of the helper smart contract.

***

### ethereum\_network

> **ethereum\_network**: [`EthereumNetwork`](../type-aliases/EthereumNetwork.md)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L308)

The minter will interact with this Ethereum network.

***

### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L328)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain. If not specified, uses the production or
staging EVM RPC canister based on the ethereum_network field.

***

### last\_scraped\_block\_number

> **last\_scraped\_block\_number**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L313)

Block number to start scrapping from on the Ethereum network.
Scrapping the logs will resume at `last_scraped_block_number + 1` (inclusive).

***

### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L334)

The principal of the ledger that handles ckETH transfers.
The default account of the ckETH minter must be configured as
the minting account of the ledger.

***

### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L342)

Minimum amount in Wei that can be withdrawn.

***

### next\_transaction\_nonce

> **next\_transaction\_nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L322)

Nonce of the next transaction to be sent to the Ethereum network.
