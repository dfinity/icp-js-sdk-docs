---
title: GasFeeEstimate
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L284)

## Properties

### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L294)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

***

### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L289)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L299)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.
