---
title: GasFeeEstimate
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L284)

## Properties

### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L294)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

***

### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L289)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L299)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.
