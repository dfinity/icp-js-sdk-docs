---
title: EventSource
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:280](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L280)

## Properties

### log\_index

> **log\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L282)

***

### transaction\_hash

> **transaction\_hash**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L281)
