---
title: Eip1559TransactionPriceArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L121)

Argument to Eip1559TransactionPrice.
When specified, it is to lookup transaction price for a ckERC20 token withdrawal.
When not specified (null), it is for ETH withdrawal.

## Properties

### ckerc20\_ledger\_id

> **ckerc20\_ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:125](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L125)

The ledger ID for that ckERC20 token.
