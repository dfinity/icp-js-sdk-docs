---
title: Eip1559TransactionPrice
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L90)

Estimate price of an EIP-1559 transaction
when converting ckETH to ETH or ckERC20 to ERC20, see
https://eips.ethereum.org/EIPS/eip-1559

## Properties

### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L114)

Maximum amount of gas transaction is authorized to consume.

***

### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L100)

Maximum amount of Wei per gas unit that the transaction is willing to pay in total.
This covers the base fee determined by the network and the `max_priority_fee_per_gas`.

***

### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L95)

Maximum amount of Wei per gas unit that the transaction gives to miners
to incentivize them to include their transaction (priority fee).

***

### max\_transaction\_fee

> **max\_transaction\_fee**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L105)

Maximum amount of Wei that can be charged for the transaction,
computed as `max_fee_per_gas * gas_limit`

***

### timestamp

> **timestamp**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/cketh/minter.d.ts#L110)

Timestamp of when the price was estimated.
Nanoseconds since the UNIX epoch.
