---
title: WithdrawalDetail
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:705](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L705)

Details of a withdrawal request and its status.

## Properties

### from

> **from**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:725](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L725)

Sender's principal.

***

### from\_subaccount

> **from\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:729](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L729)

Sender's subaccount (if given).

***

### max\_transaction\_fee

> **max\_transaction\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:733](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L733)

Max transaction fee in Wei (transaction fee paid by the sender).

***

### recipient\_address

> **recipient\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:737](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L737)

Address to send tokens to.

***

### status

> **status**: [`WithdrawalStatus`](../type-aliases/WithdrawalStatus.md)

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:709](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L709)

Withdrawal status

***

### token\_symbol

> **token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:713](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L713)

Symbol of the withdrawal token (either ckETH or ckERC20 token symbol).

***

### withdrawal\_amount

> **withdrawal\_amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:717](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L717)

Amount of tokens in base unit that was withdrawn.

***

### withdrawal\_id

> **withdrawal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:721](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L721)

Withdrawal id (i.e. burn index on the ckETH ledger).
