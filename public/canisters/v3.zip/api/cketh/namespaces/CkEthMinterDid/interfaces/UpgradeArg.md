---
title: UpgradeArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:583](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L583)

## Properties

### deposit\_with\_subaccount\_helper\_contract\_address

> **deposit\_with\_subaccount\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:587](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L587)

Change the deposit with subaccount helper smart contract address.

***

### erc20\_helper\_contract\_address

> **erc20\_helper\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:605](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L605)

Change the ERC-20 helper smart contract address.

***

### ethereum\_block\_height

> **ethereum\_block\_height**: \[\] \| \[[`BlockTag`](../type-aliases/BlockTag.md)\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L625)

Change the ethereum block height observed by the minter.

***

### ethereum\_contract\_address

> **ethereum\_contract\_address**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:613](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L613)

Change the ETH helper smart contract address.

***

### evm\_rpc\_id

> **evm\_rpc\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L596)

The principal of the EVM RPC canister that handles the communication
with the Ethereum blockchain.

***

### last\_deposit\_with\_subaccount\_scraped\_block\_number

> **last\_deposit\_with\_subaccount\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L621)

Change the last scraped block number of the deposit with subaccount helper smart contract.

***

### last\_erc20\_scraped\_block\_number

> **last\_erc20\_scraped\_block\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:609](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L609)

Change the last scraped block number of the ERC-20 helper smart contract.

***

### ledger\_suite\_orchestrator\_id

> **ledger\_suite\_orchestrator\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L601)

The principal of the ledger suite orchestrator that handles the ICRC1 ledger suites
for all ckERC20 tokens.

***

### minimum\_withdrawal\_amount

> **minimum\_withdrawal\_amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:617](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L617)

Change the minimum amount in Wei that can be withdrawn.

***

### next\_transaction\_nonce

> **next\_transaction\_nonce**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L591)

Change the nonce of the next transaction to be sent to the Ethereum network.
