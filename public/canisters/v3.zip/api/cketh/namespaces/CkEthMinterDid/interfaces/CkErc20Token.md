---
title: CkErc20Token
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L71)

## Properties

### ckerc20\_token\_symbol

> **ckerc20\_token\_symbol**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:74](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L74)

***

### erc20\_contract\_address

> **erc20\_contract\_address**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L72)

***

### ledger\_canister\_id

> **ledger\_canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L73)
