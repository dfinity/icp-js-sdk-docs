---
title: Event
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L143)

## Properties

### payload

> **payload**: \{ `SkippedBlock`: \{ `block_number`: `bigint`; `contract_address`: \[\] \| \[`string`\]; \}; \} \| \{ `AcceptedErc20Deposit`: \{ `block_number`: `bigint`; `erc20_contract_address`: `string`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](../type-aliases/Subaccount.md)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `SignedTransaction`: \{ `raw_transaction`: `string`; `withdrawal_id`: `bigint`; \}; \} \| \{ `Upgrade`: [`UpgradeArg`](UpgradeArg.md); \} \| \{ `Init`: [`InitArg`](InitArg.md); \} \| \{ `AddedCkErc20Token`: \{ `address`: `string`; `chain_id`: `bigint`; `ckerc20_ledger_id`: `Principal`; `ckerc20_token_symbol`: `string`; \}; \} \| \{ `SyncedDepositWithSubaccountToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `QuarantinedDeposit`: \{ `event_source`: [`EventSource`](EventSource.md); \}; \} \| \{ `SyncedToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedDeposit`: \{ `block_number`: `bigint`; `from_address`: `string`; `log_index`: `bigint`; `principal`: `Principal`; `subaccount`: \[\] \| \[[`Subaccount`](../type-aliases/Subaccount.md)\]; `transaction_hash`: `string`; `value`: `bigint`; \}; \} \| \{ `ReplacedTransaction`: \{ `transaction`: [`UnsignedTransaction`](UnsignedTransaction.md); `withdrawal_id`: `bigint`; \}; \} \| \{ `QuarantinedReimbursement`: \{ `index`: [`ReimbursementIndex`](../type-aliases/ReimbursementIndex.md); \}; \} \| \{ `MintedCkEth`: \{ `event_source`: [`EventSource`](EventSource.md); `mint_block_index`: `bigint`; \}; \} \| \{ `ReimbursedEthWithdrawal`: \{ `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `FailedErc20WithdrawalRequest`: \{ `reimbursed_amount`: `bigint`; `to`: `Principal`; `to_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `ReimbursedErc20Withdrawal`: \{ `burn_in_block`: `bigint`; `ledger_id`: `Principal`; `reimbursed_amount`: `bigint`; `reimbursed_in_block`: `bigint`; `transaction_hash`: \[\] \| \[`string`\]; `withdrawal_id`: `bigint`; \}; \} \| \{ `MintedCkErc20`: \{ `ckerc20_token_symbol`: `string`; `erc20_contract_address`: `string`; `event_source`: [`EventSource`](EventSource.md); `mint_block_index`: `bigint`; \}; \} \| \{ `CreatedTransaction`: \{ `transaction`: [`UnsignedTransaction`](UnsignedTransaction.md); `withdrawal_id`: `bigint`; \}; \} \| \{ `InvalidDeposit`: \{ `event_source`: [`EventSource`](EventSource.md); `reason`: `string`; \}; \} \| \{ `SyncedErc20ToBlock`: \{ `block_number`: `bigint`; \}; \} \| \{ `AcceptedErc20WithdrawalRequest`: \{ `ckerc20_ledger_burn_index`: `bigint`; `ckerc20_ledger_id`: `Principal`; `cketh_ledger_burn_index`: `bigint`; `created_at`: `bigint`; `destination`: `string`; `erc20_contract_address`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `max_transaction_fee`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `AcceptedEthWithdrawalRequest`: \{ `created_at`: \[\] \| \[`bigint`\]; `destination`: `string`; `from`: `Principal`; `from_subaccount`: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]; `ledger_burn_index`: `bigint`; `withdrawal_amount`: `bigint`; \}; \} \| \{ `FinalizedTransaction`: \{ `transaction_receipt`: [`TransactionReceipt`](TransactionReceipt.md); `withdrawal_id`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L145)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:144](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/cketh/minter.d.ts#L144)
