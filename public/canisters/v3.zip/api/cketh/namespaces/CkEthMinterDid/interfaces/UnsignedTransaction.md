---
title: UnsignedTransaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:572](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L572)

## Properties

### access\_list

> **access\_list**: `object`[]

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L581)

#### address

> **address**: `string`

#### storage\_keys

> **storage\_keys**: `Uint8Array`\<`ArrayBufferLike`\>[]

***

### chain\_id

> **chain\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L578)

***

### data

> **data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L576)

***

### destination

> **destination**: `string`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:573](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L573)

***

### gas\_limit

> **gas\_limit**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L580)

***

### max\_fee\_per\_gas

> **max\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L577)

***

### max\_priority\_fee\_per\_gas

> **max\_priority\_fee\_per\_gas**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L575)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L579)

***

### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/cketh/minter.d.ts:574](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/cketh/minter.d.ts#L574)
