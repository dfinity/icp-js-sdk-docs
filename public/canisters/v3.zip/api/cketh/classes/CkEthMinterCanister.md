---
title: CkEthMinterCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/cketh/minter.canister.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L24)

## Extends

- `Canister`\<[`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)\>

## Constructors

### Constructor

> `protected` **new CkEthMinterCanister**(`id`, `service`, `certifiedService`): `CkEthMinterCanister`

Defined in: packages/utils/dist/services/canister.d.ts:7

#### Parameters

##### id

`Principal`

##### service

[`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)

##### certifiedService

[`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)

#### Returns

`CkEthMinterCanister`

#### Inherited from

`Canister<CkEthMinterService>.constructor`

## Properties

### caller()

> `protected` **caller**: (`__namedParameters`) => [`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:9

#### Parameters

##### \_\_namedParameters

`QueryParams`

#### Returns

[`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)

#### Inherited from

`Canister.caller`

***

### certifiedService

> `protected` `readonly` **certifiedService**: [`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:6

#### Inherited from

`Canister.certifiedService`

***

### service

> `protected` `readonly` **service**: [`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)

Defined in: packages/utils/dist/services/canister.d.ts:5

#### Inherited from

`Canister.service`

## Accessors

### canisterId

#### Get Signature

> **get** **canisterId**(): `Principal`

Defined in: packages/utils/dist/services/canister.d.ts:8

##### Returns

`Principal`

#### Inherited from

`Canister.canisterId`

## Methods

### eip1559TransactionPrice()

> **eip1559TransactionPrice**(`params`): `Promise`\<[`Eip1559TransactionPrice`](../namespaces/CkEthMinterDid/interfaces/Eip1559TransactionPrice.md)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:146](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L146)

Estimate the price of a transaction issued by the minter when converting ckETH to ETH and ckER20 to ERC20.

#### Parameters

##### params

[`Eip1559TransactionPriceParams`](../type-aliases/Eip1559TransactionPriceParams.md)

The parameters to get the minter info.

#### Returns

`Promise`\<[`Eip1559TransactionPrice`](../namespaces/CkEthMinterDid/interfaces/Eip1559TransactionPrice.md)\>

- The estimated gas fee and limit.

***

### getMinterInfo()

> **getMinterInfo**(`params`): `Promise`\<[`MinterInfo`](../namespaces/CkEthMinterDid/interfaces/MinterInfo.md)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L176)

Returns internal minter parameters such as the minimal withdrawal amount, the last observed block number, etc.

#### Parameters

##### params

`QueryParams`

The parameters to get the minter info.

#### Returns

`Promise`\<[`MinterInfo`](../namespaces/CkEthMinterDid/interfaces/MinterInfo.md)\>

***

### getSmartContractAddress()

> **getSmartContractAddress**(`params`): `Promise`\<`string`\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:43](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L43)

The address of the helper smart contract may change in the future when the minter is upgraded. Please verify the address of the helper contract before any important transfer by querying the minter as follows.

#### Parameters

##### params

`QueryParams` = `{}`

The parameters to resolve the ckETH smart contract address.

#### Returns

`Promise`\<`string`\>

Address of the helper smart contract.

***

### retrieveEthStatus()

> **retrieveEthStatus**(`blockIndex`): `Promise`\<[`RetrieveEthStatus`](../namespaces/CkEthMinterDid/type-aliases/RetrieveEthStatus.md)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:161](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L161)

Retrieve the status of a withdrawal request.

#### Parameters

##### blockIndex

`bigint`

#### Returns

`Promise`\<[`RetrieveEthStatus`](../namespaces/CkEthMinterDid/type-aliases/RetrieveEthStatus.md)\>

The current status of an Ethereum transaction for a block index resulting from a withdrawal.

***

### withdrawErc20()

> **withdrawErc20**(`params`): `Promise`\<[`RetrieveErc20Request`](../namespaces/CkEthMinterDid/interfaces/RetrieveErc20Request.md)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:105](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L105)

Submits a request to convert ckErc20 to Erc20 - e.g. ckUSDC to USDC - after making ICRC-2 approvals for the ckETH and related ckErc20 ledgers.

Preconditions:

The caller allowed the minter's principal to spend its funds using
[icrc2_approve] on the ckErc20 ledger and to burn some of the user’s ckETH tokens to pay for the transaction fees on the CkEth ledger.

#### Parameters

##### params

The parameters to withdrawal ckErc20 to Erc20.

###### address

`string`

The destination ETH address.

###### amount

`bigint`

The ETH amount in wei.

###### fromCkErc20Subaccount?

[`Subaccount`](../namespaces/CkEthMinterDid/type-aliases/Subaccount.md)

###### fromCkEthSubaccount?

[`Subaccount`](../namespaces/CkEthMinterDid/type-aliases/Subaccount.md)

The optional subaccount to burn ckETH from to pay for the transaction fee.

###### ledgerCanisterId

`Principal`

#### Returns

`Promise`\<[`RetrieveErc20Request`](../namespaces/CkEthMinterDid/interfaces/RetrieveErc20Request.md)\>

The successful result or the operation.

***

### withdrawEth()

> **withdrawEth**(`params`): `Promise`\<[`RetrieveEthRequest`](../namespaces/CkEthMinterDid/interfaces/RetrieveEthRequest.md)\>

Defined in: [packages/canisters/src/cketh/minter.canister.ts:64](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L64)

Submits a request to convert ckETH to ETH after making an ICRC-2 approval.

Preconditions:

The caller allowed the minter's principal to spend its funds using
[icrc2_approve] on the ckETH ledger.

#### Parameters

##### params

The parameters to withdrawal ckETH to ETH.

###### address

`string`

The destination ETH address.

###### amount

`bigint`

The ETH amount in wei.

###### fromSubaccount?

[`Subaccount`](../namespaces/CkEthMinterDid/type-aliases/Subaccount.md)

The optional subaccount to burn ckETH from.

#### Returns

`Promise`\<[`RetrieveEthRequest`](../namespaces/CkEthMinterDid/interfaces/RetrieveEthRequest.md)\>

The successful result or the operation.

***

### create()

> `static` **create**(`options`): `CkEthMinterCanister`

Defined in: [packages/canisters/src/cketh/minter.canister.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/cketh/minter.canister.ts#L25)

#### Parameters

##### options

[`CkEthMinterCanisterOptions`](../interfaces/CkEthMinterCanisterOptions.md)\<[`_SERVICE`](../namespaces/CkEthMinterDid/interfaces/SERVICE.md)\>

#### Returns

`CkEthMinterCanister`
