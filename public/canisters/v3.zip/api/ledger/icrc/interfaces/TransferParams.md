---
title: TransferParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L27)

Params to make a transfer in an ICRC-1 ledger

## Param

The account to transfer tokens to.

## Param

The Amount of tokens to transfer.

## Param

The subaccount to transfer tokens to.

## Param

Transfer memo.

## Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues
See the link for more details on deduplication
https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/index.md#transaction_deduplication

## Param

The fee of the transfer when it's not the default fee.

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:33](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L33)

***

### created\_at\_time?

> `optional` **created\_at\_time**: `bigint`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:32](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L32)

***

### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L29)

***

### from\_subaccount?

> `optional` **from\_subaccount**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:31](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L31)

***

### memo?

> `optional` **memo**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L30)

***

### to

> **to**: [`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:28](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L28)
