---
title: IcrcAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L18)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L19)

***

### subaccount?

> `optional` **subaccount**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:20](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L20)
