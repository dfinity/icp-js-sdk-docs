---
title: IcrcAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:18](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L18)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:19](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L19)

***

### subaccount?

> `optional` **subaccount**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.responses.ts:20](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.responses.ts#L20)
