---
title: IcrcLedgerCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icrc/types/canister.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/types/canister.options.ts#L4)

## Extends

- `Omit`\<`CanisterOptions`\<`T`\>, `"canisterId"`\>

## Type Parameters

### T

`T`

## Properties

### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

#### Inherited from

[`NnsGovernanceCanisterOptions`](../../../nns/interfaces/NnsGovernanceCanisterOptions.md).[`agent`](../../../nns/interfaces/NnsGovernanceCanisterOptions.md#agent)

***

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ledger/icrc/types/canister.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/types/canister.options.ts#L9)

***

### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

#### Inherited from

`Omit.certifiedServiceOverride`

***

### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<`T`\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

#### Inherited from

`Omit.serviceOverride`
