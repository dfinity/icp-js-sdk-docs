---
title: toApproveArgs
editUrl: false
next: true
prev: true
---

> **toApproveArgs**(`__namedParameters`): [`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:43](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L43)

## Parameters

### \_\_namedParameters

[`ApproveParams`](../type-aliases/ApproveParams.md)

## Returns

[`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)
