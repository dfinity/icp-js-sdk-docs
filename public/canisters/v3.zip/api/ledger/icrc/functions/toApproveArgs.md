---
title: toApproveArgs
editUrl: false
next: true
prev: true
---

> **toApproveArgs**(`__namedParameters`): [`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:43](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L43)

## Parameters

### \_\_namedParameters

[`ApproveParams`](../type-aliases/ApproveParams.md)

## Returns

[`ApproveArgs`](../namespaces/IcrcLedgerDid/interfaces/ApproveArgs.md)
