---
title: decodePayment
editUrl: false
next: true
prev: true
---

> **decodePayment**(`code`): \{ `amount?`: `number`; `identifier`: `string`; `token`: `string`; \} \| `undefined`

Defined in: [packages/canisters/src/ledger/icrc/utils/payment.utils.ts:26](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/utils/payment.utils.ts#L26)

👀 This feature is currently in draft. You can find more information about it at https://github.com/dfinity/ICRC/issues/22.

A naive implementation of a payment parser. Given a code, the function attempts to extract a token name, account identifier (textual representation), and an optional amount.

If the code doesn't match the expected pattern, `undefined` is returned for simplicity.
Similarly, if an optional amount is provided but it's not a valid number, the parser will not throw an exception and returns `undefined`.

Please note that this function doesn't perform any validity checks on the extracted information.
It does not verify if the token is known or if the identifier is a valid address.

```
urn            = token ":" address [ "?" params]
token         = [ ckbtc / icp / chat / bitcoin / ethereum ... ]
address       = STRING
params        = param [ "&" params ]
param         = [ amountparam ]
amountparam   = "amount=" *digit [ "." *digit ]
```

## Parameters

### code

`string`

string

## Returns

\{ `amount?`: `number`; `identifier`: `string`; `token`: `string`; \} \| `undefined`

| undefined
