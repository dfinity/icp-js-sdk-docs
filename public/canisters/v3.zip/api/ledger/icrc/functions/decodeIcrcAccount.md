---
title: decodeIcrcAccount
editUrl: false
next: true
prev: true
---

> **decodeIcrcAccount**(`accountString`): [`IcrcAccount`](../interfaces/IcrcAccount.md)

Defined in: [packages/canisters/src/ledger/icrc/utils/ledger.utils.ts:67](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/utils/ledger.utils.ts#L67)

Decodes a string into an Icrc-1 compatible account.
Formatting Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/TextualEncoding.md

## Parameters

### accountString

`string`

string

## Returns

[`IcrcAccount`](../interfaces/IcrcAccount.md)

IcrcAccount { owner: Principal, subaccount?: Uint8Array }

## Throws

Error if the string is not a valid Icrc-1 account
