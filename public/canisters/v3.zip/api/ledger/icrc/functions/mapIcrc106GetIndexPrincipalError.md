---
title: mapIcrc106GetIndexPrincipalError
editUrl: false
next: true
prev: true
---

> **mapIcrc106GetIndexPrincipalError**(`err`): [`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)

Defined in: [packages/canisters/src/ledger/icrc/errors/ledger.errors.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/errors/ledger.errors.ts#L61)

## Parameters

### err

[`GetIndexPrincipalError`](../namespaces/IcrcLedgerDid/type-aliases/GetIndexPrincipalError.md)

## Returns

[`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)
