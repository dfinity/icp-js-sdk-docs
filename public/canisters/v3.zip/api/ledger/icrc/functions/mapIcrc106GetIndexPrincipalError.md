---
title: mapIcrc106GetIndexPrincipalError
editUrl: false
next: true
prev: true
---

> **mapIcrc106GetIndexPrincipalError**(`err`): [`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)

Defined in: [packages/canisters/src/ledger/icrc/errors/ledger.errors.ts:61](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/errors/ledger.errors.ts#L61)

## Parameters

### err

[`GetIndexPrincipalError`](../namespaces/IcrcLedgerDid/type-aliases/GetIndexPrincipalError.md)

## Returns

[`GenericError`](../classes/GenericError.md) \| [`IndexPrincipalNotSetError`](../classes/IndexPrincipalNotSetError.md)
