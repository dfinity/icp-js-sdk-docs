---
title: encodeIcrcAccount
editUrl: false
next: true
prev: true
---

> **encodeIcrcAccount**(`account`): `string`

Defined in: [packages/canisters/src/ledger/icrc/utils/ledger.utils.ts:27](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/utils/ledger.utils.ts#L27)

Encodes an Icrc-1 account compatible into a string.
Formatting Reference: https://github.com/dfinity/ICRC-1/blob/main/standards/ICRC-1/TextualEncoding.md

## Parameters

### account

[`IcrcAccount`](../interfaces/IcrcAccount.md)

{ owner: Principal, subaccount?: Uint8Array }

## Returns

`string`

string
