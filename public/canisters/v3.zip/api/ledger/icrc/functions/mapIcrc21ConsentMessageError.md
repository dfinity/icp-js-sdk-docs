---
title: mapIcrc21ConsentMessageError
editUrl: false
next: true
prev: true
---

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](../classes/ConsentMessageError.md)

Defined in: [packages/canisters/src/ledger/icrc/errors/ledger.errors.ts:26](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/errors/ledger.errors.ts#L26)

## Parameters

### rawError

[`icrc21_error`](../namespaces/IcrcLedgerDid/type-aliases/icrc21_error.md)

## Returns

[`ConsentMessageError`](../classes/ConsentMessageError.md)
