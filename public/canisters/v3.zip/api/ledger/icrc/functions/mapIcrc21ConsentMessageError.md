---
title: mapIcrc21ConsentMessageError
editUrl: false
next: true
prev: true
---

> **mapIcrc21ConsentMessageError**(`rawError`): [`ConsentMessageError`](../classes/ConsentMessageError.md)

Defined in: [packages/canisters/src/ledger/icrc/errors/ledger.errors.ts:26](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/errors/ledger.errors.ts#L26)

## Parameters

### rawError

[`icrc21_error`](../namespaces/IcrcLedgerDid/type-aliases/icrc21_error.md)

## Returns

[`ConsentMessageError`](../classes/ConsentMessageError.md)
