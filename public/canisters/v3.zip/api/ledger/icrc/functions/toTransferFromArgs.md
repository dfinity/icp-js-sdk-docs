---
title: toTransferFromArgs
editUrl: false
next: true
prev: true
---

> **toTransferFromArgs**(`__namedParameters`): [`TransferFromArgs`](../namespaces/IcrcLedgerDid/interfaces/TransferFromArgs.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L29)

## Parameters

### \_\_namedParameters

[`TransferFromParams`](../type-aliases/TransferFromParams.md)

## Returns

[`TransferFromArgs`](../namespaces/IcrcLedgerDid/interfaces/TransferFromArgs.md)
