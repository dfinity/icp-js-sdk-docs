---
title: toTransferFromArgs
editUrl: false
next: true
prev: true
---

> **toTransferFromArgs**(`__namedParameters`): [`TransferFromArgs`](../namespaces/IcrcLedgerDid/interfaces/TransferFromArgs.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L29)

## Parameters

### \_\_namedParameters

[`TransferFromParams`](../type-aliases/TransferFromParams.md)

## Returns

[`TransferFromArgs`](../namespaces/IcrcLedgerDid/interfaces/TransferFromArgs.md)
