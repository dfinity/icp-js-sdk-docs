---
title: toTransferFromArgs
editUrl: false
next: true
prev: true
---

> **toTransferFromArgs**(`__namedParameters`): [`TransferFromArgs`](../namespaces/IcrcLedgerDid/interfaces/TransferFromArgs.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:29](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L29)

## Parameters

### \_\_namedParameters

[`TransferFromParams`](../type-aliases/TransferFromParams.md)

## Returns

[`TransferFromArgs`](../namespaces/IcrcLedgerDid/interfaces/TransferFromArgs.md)
