---
title: toIcrc21ConsentMessageArgs
editUrl: false
next: true
prev: true
---

> **toIcrc21ConsentMessageArgs**(`__namedParameters`): [`icrc21_consent_message_request`](../namespaces/IcrcLedgerDid/interfaces/icrc21_consent_message_request.md)

Defined in: [packages/canisters/src/ledger/icrc/converters/ledger.converters.ts:61](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/converters/ledger.converters.ts#L61)

## Parameters

### \_\_namedParameters

[`Icrc21ConsentMessageParams`](../type-aliases/Icrc21ConsentMessageParams.md)

## Returns

[`icrc21_consent_message_request`](../namespaces/IcrcLedgerDid/interfaces/icrc21_consent_message_request.md)
