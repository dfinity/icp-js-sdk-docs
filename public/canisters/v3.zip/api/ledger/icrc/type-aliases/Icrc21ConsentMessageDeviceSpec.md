---
title: Icrc21ConsentMessageDeviceSpec
editUrl: false
next: true
prev: true
---

> **Icrc21ConsentMessageDeviceSpec** = \{ `GenericDisplay`: `null`; \} \| \{ `FieldsDisplay`: `null`; \}

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:91](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L91)

Device specification for displaying the consent message.

## Param

A generic display able to handle large documents and do line wrapping and pagination / scrolling.  Text must be Markdown formatted, no external resources (e.g. images) are allowed.

## Param

A simple display able to handle multiple fields with a title and content.
