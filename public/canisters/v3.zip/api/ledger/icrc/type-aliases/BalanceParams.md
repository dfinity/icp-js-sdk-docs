---
title: BalanceParams
editUrl: false
next: true
prev: true
---

> **BalanceParams** = [`IcrcAccount`](../interfaces/IcrcAccount.md) & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:8](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L8)

Params to get the balance of an ICRC-1 account.
