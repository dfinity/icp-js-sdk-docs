---
title: ApproveParams
editUrl: false
next: true
prev: true
---

> **ApproveParams** = `Omit`\<[`TransferParams`](../interfaces/TransferParams.md), `"to"`\> & `object`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:64](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L64)

Params for an icrc2_approve.

## Type Declaration

### expected\_allowance?

> `optional` **expected\_allowance**: [`Tokens`](../namespaces/IcrcLedgerDid/type-aliases/Tokens.md)

### expires\_at?

> `optional` **expires\_at**: [`Timestamp`](../namespaces/IcrcLedgerDid/type-aliases/Timestamp.md)

### spender

> **spender**: [`Account`](../namespaces/IcrcLedgerDid/interfaces/Account.md)

## Param

The account of the spender.

## Param

The Amount of tokens to approve.

## Param

The subaccount to transfer tokens from.

## Param

Transfer memo.

## Param

nanoseconds since unix epoc to trigger deduplication and avoid other issues

## Param

The fee of the transfer when it's not the default fee.

## Param

The optional allowance expected. If the expected_allowance field is set, the ledger MUST ensure that the current allowance for the spender from the caller's account is equal to the given value and return the AllowanceChanged error otherwise.

## Param

When the approval expires. If the field is set, it's greater than the current ledger time.
