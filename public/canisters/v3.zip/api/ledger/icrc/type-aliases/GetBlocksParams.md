---
title: GetBlocksParams
editUrl: false
next: true
prev: true
---

> **GetBlocksParams** = `QueryParams` & `object`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:125](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L125)

Parameters to get the canister blocks.

## Type Declaration

### args

> **args**: [`GetBlocksArgs`](../namespaces/IcrcLedgerDid/interfaces/GetBlocksArgs.md)[]
