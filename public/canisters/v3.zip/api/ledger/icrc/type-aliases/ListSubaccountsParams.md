---
title: ListSubaccountsParams
editUrl: false
next: true
prev: true
---

> **ListSubaccountsParams** = `object` & `Pick`\<[`IcrcAccount`](../interfaces/IcrcAccount.md), `"owner"`\> & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/index-ng.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/index-ng.params.ts#L11)

## Type Declaration

### start?

> `optional` **start**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)
