---
title: ListSubaccountsParams
editUrl: false
next: true
prev: true
---

> **ListSubaccountsParams** = `object` & `Pick`\<[`IcrcAccount`](../interfaces/IcrcAccount.md), `"owner"`\> & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/index-ng.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icrc/types/index-ng.params.ts#L11)

## Type Declaration

### start?

> `optional` **start**: [`Subaccount`](../namespaces/IcrcLedgerDid/type-aliases/Subaccount.md)
