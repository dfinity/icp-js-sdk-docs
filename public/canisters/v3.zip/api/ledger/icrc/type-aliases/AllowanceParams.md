---
title: AllowanceParams
editUrl: false
next: true
prev: true
---

> **AllowanceParams** = [`AllowanceArgs`](../namespaces/IcrcLedgerDid/interfaces/AllowanceArgs.md) & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L73)

Params to get the token allowance that the spender account can transfer from the specified account
