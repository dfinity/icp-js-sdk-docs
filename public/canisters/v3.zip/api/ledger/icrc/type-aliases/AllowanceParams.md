---
title: AllowanceParams
editUrl: false
next: true
prev: true
---

> **AllowanceParams** = [`AllowanceArgs`](../namespaces/IcrcLedgerDid/interfaces/AllowanceArgs.md) & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L73)

Params to get the token allowance that the spender account can transfer from the specified account
