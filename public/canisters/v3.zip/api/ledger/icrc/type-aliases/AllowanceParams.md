---
title: AllowanceParams
editUrl: false
next: true
prev: true
---

> **AllowanceParams** = [`AllowanceArgs`](../namespaces/IcrcLedgerDid/interfaces/AllowanceArgs.md) & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/ledger.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icrc/types/ledger.params.ts#L73)

Params to get the token allowance that the spender account can transfer from the specified account
