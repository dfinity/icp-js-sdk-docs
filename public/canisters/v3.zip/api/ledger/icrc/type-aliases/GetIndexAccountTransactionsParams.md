---
title: GetIndexAccountTransactionsParams
editUrl: false
next: true
prev: true
---

> **GetIndexAccountTransactionsParams** = `object` & `QueryParams`

Defined in: [packages/canisters/src/ledger/icrc/types/index-ng.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icrc/types/index-ng.params.ts#L5)

## Type Declaration

### account

> **account**: [`IcrcAccount`](../interfaces/IcrcAccount.md)

### max\_results

> **max\_results**: `bigint`

### start?

> `optional` **start**: [`BlockIndex`](../namespaces/IcrcIndexDid/type-aliases/BlockIndex.md)
