---
title: SubAccount
editUrl: false
next: true
prev: true
---

> **SubAccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L106)
