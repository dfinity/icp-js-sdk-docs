---
title: idlFactory
editUrl: false
next: true
prev: true
---

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L159)
