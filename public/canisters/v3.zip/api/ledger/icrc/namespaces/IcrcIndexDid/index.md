---
title: IcrcIndexDid
editUrl: false
next: true
prev: true
---

## Interfaces

- [\_SERVICE](interfaces/SERVICE.md)
- [Account](interfaces/Account.md)
- [Approve](interfaces/Approve.md)
- [Burn](interfaces/Burn.md)
- [FeeCollector](interfaces/FeeCollector.md)
- [FeeCollectorRanges](interfaces/FeeCollectorRanges.md)
- [GetAccountTransactionsArgs](interfaces/GetAccountTransactionsArgs.md)
- [GetBlocksRequest](interfaces/GetBlocksRequest.md)
- [GetBlocksResponse](interfaces/GetBlocksResponse.md)
- [GetTransactions](interfaces/GetTransactions.md)
- [GetTransactionsErr](interfaces/GetTransactionsErr.md)
- [InitArg](interfaces/InitArg.md)
- [ListSubaccountsArgs](interfaces/ListSubaccountsArgs.md)
- [Mint](interfaces/Mint.md)
- [Status](interfaces/Status.md)
- [Transaction](interfaces/Transaction.md)
- [TransactionWithId](interfaces/TransactionWithId.md)
- [Transfer](interfaces/Transfer.md)
- [UpgradeArg](interfaces/UpgradeArg.md)

## Type Aliases

- [Block](type-aliases/Block.md)
- [BlockIndex](type-aliases/BlockIndex.md)
- [GetTransactionsResult](type-aliases/GetTransactionsResult.md)
- [IndexArg](type-aliases/IndexArg.md)
- [Map](type-aliases/Map.md)
- [SubAccount](type-aliases/SubAccount.md)
- [Tokens](type-aliases/Tokens.md)
- [Value](type-aliases/Value.md)

## Variables

- [idlFactory](variables/idlFactory.md)
- [init](variables/init.md)
