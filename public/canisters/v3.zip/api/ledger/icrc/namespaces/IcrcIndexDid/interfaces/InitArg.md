---
title: InitArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L82)

## Properties

### ledger\_id

> **ledger\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:83](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L83)

***

### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L89)

The interval in seconds in which to retrieve blocks from the ledger. A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.
