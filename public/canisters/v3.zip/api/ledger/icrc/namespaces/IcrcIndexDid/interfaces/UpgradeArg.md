---
title: UpgradeArg
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L130)

## Properties

### ledger\_id

> **ledger\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L131)

***

### retrieve\_blocks\_from\_ledger\_interval\_seconds

> **retrieve\_blocks\_from\_ledger\_interval\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:137](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L137)

The interval in seconds in which to retrieve blocks from the ledger. A lower value makes the index more
responsive in showing new blocks, but increases the consumption of cycles of both the index and ledger canisters.
A higher values means that it takes longer for new blocks to show up in the index.
