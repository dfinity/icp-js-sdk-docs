---
title: Status
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L103)

## Properties

### num\_blocks\_synced

> **num\_blocks\_synced**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L104)
