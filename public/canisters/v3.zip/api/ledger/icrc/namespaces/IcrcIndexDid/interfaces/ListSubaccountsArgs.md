---
title: ListSubaccountsArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L91)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L92)

***

### start

> **start**: \[\] \| \[[`SubAccount`](../type-aliases/SubAccount.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L93)
