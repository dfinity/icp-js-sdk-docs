---
title: Account
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L13)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L14)

***

### subaccount

> **subaccount**: \[\] \| \[[`SubAccount`](../type-aliases/SubAccount.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L15)
