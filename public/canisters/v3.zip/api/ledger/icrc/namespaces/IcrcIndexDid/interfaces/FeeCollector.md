---
title: FeeCollector
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L37)

## Properties

### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L40)

***

### fee\_collector

> **fee\_collector**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L39)

***

### ts

> **ts**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L38)
