---
title: FeeCollector
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L37)

## Properties

### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L40)

***

### fee\_collector

> **fee\_collector**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L39)

***

### ts

> **ts**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_index.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_index.d.ts#L38)
