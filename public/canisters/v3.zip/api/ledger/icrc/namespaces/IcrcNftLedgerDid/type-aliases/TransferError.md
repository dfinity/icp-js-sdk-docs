---
title: TransferError
editUrl: false
next: true
prev: true
---

> **TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `NonExistingTokenId`: `null`; \} \| \{ `Unauthorized`: `null`; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `InvalidRecipient`: `null`; \} \| \{ `GenericBatchError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TooOld`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L25)
