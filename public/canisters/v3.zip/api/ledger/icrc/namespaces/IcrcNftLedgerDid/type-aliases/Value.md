---
title: Value
editUrl: false
next: true
prev: true
---

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `Value`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `Value`[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L40)

Generic value in accordance with ICRC-3
