---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L80)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
