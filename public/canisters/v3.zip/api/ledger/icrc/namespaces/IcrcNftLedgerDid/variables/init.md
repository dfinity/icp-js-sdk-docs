---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L80)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
