---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L47)

## Properties

### icrc7\_atomic\_batch\_transfers

> **icrc7\_atomic\_batch\_transfers**: `ActorMethod`\<\[\], \[\] \| \[`boolean`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:48](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L48)

***

### icrc7\_balance\_of

> **icrc7\_balance\_of**: `ActorMethod`\<\[[`Account`](Account.md)[]\], `bigint`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:49](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L49)

***

### icrc7\_collection\_metadata

> **icrc7\_collection\_metadata**: `ActorMethod`\<\[\], \[`string`, [`Value`](../type-aliases/Value.md)\][]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:50](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L50)

***

### icrc7\_default\_take\_value

> **icrc7\_default\_take\_value**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L51)

***

### icrc7\_description

> **icrc7\_description**: `ActorMethod`\<\[\], \[\] \| \[`string`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L52)

***

### icrc7\_logo

> **icrc7\_logo**: `ActorMethod`\<\[\], \[\] \| \[`string`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L53)

***

### icrc7\_max\_memo\_size

> **icrc7\_max\_memo\_size**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L54)

***

### icrc7\_max\_query\_batch\_size

> **icrc7\_max\_query\_batch\_size**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L55)

***

### icrc7\_max\_take\_value

> **icrc7\_max\_take\_value**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:56](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L56)

***

### icrc7\_max\_update\_batch\_size

> **icrc7\_max\_update\_batch\_size**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L57)

***

### icrc7\_name

> **icrc7\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L58)

***

### icrc7\_owner\_of

> **icrc7\_owner\_of**: `ActorMethod`\<\[`bigint`[]\], (\[\] \| \[[`Account`](Account.md)\])[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L59)

***

### icrc7\_permitted\_drift

> **icrc7\_permitted\_drift**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L60)

***

### icrc7\_supply\_cap

> **icrc7\_supply\_cap**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L61)

***

### icrc7\_symbol

> **icrc7\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L62)

***

### icrc7\_token\_metadata

> **icrc7\_token\_metadata**: `ActorMethod`\<\[`bigint`[]\], (\[\] \| \[\[`string`, [`Value`](../type-aliases/Value.md)\][]\])[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L63)

***

### icrc7\_tokens

> **icrc7\_tokens**: `ActorMethod`\<\[\[\] \| \[`bigint`\], \[\] \| \[`bigint`\]\], `bigint`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:67](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L67)

***

### icrc7\_tokens\_of

> **icrc7\_tokens\_of**: `ActorMethod`\<\[[`Account`](Account.md), \[\] \| \[`bigint`\], \[\] \| \[`bigint`\]\], `bigint`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L68)

***

### icrc7\_total\_supply

> **icrc7\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:72](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L72)

***

### icrc7\_transfer

> **icrc7\_transfer**: `ActorMethod`\<\[[`TransferArg`](TransferArg.md)[]\], (\[\] \| \[[`TransferResult`](../type-aliases/TransferResult.md)\])[]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L73)

***

### icrc7\_tx\_window

> **icrc7\_tx\_window**: `ActorMethod`\<\[\], \[\] \| \[`bigint`\]\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L77)
