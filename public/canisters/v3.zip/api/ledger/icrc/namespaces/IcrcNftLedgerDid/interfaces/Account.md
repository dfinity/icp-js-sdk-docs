---
title: Account
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:13](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L13)

## Properties

### owner

> **owner**: `Principal`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L14)

***

### subaccount

> **subaccount**: \[\] \| \[[`Subaccount`](../type-aliases/Subaccount.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_nft-ledger.d.ts:15](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_nft-ledger.d.ts#L15)
