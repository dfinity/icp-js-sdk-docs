---
title: TransferFromResult
editUrl: false
next: true
prev: true
---

> **TransferFromResult** = \{ `Ok`: [`BlockIndex`](BlockIndex.md); \} \| \{ `Err`: [`TransferFromError`](TransferFromError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:487](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L487)
