---
title: LedgerArg
editUrl: false
next: true
prev: true
---

> **LedgerArg** = \{ `Upgrade`: \[\] \| \[[`UpgradeArgs`](../interfaces/UpgradeArgs.md)\]; \} \| \{ `Init`: [`InitArgs`](../interfaces/InitArgs.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L368)
