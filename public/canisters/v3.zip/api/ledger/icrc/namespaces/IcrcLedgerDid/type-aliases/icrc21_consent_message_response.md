---
title: icrc21_consent_message_response
editUrl: false
next: true
prev: true
---

> **icrc21\_consent\_message\_response** = \{ `Ok`: [`icrc21_consent_info`](../interfaces/icrc21_consent_info.md); \} \| \{ `Err`: [`icrc21_error`](icrc21_error.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L532)
