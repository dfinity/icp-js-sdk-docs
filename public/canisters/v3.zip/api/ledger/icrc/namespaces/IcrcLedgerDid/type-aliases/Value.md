---
title: Value
editUrl: false
next: true
prev: true
---

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: [`Map`](Map.md); \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `Value`[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L503)
