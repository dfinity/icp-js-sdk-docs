---
title: TransactionRange
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:418](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L418)

A prefix of the transaction range specified in the [GetTransactionsRequest] request.

## Properties

### transactions

> **transactions**: [`Transaction`](Transaction.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:436](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L436)

A prefix of the requested transaction range.
The index of the first transaction is equal to [GetTransactionsRequest.from].

Note that the number of transactions might be less than the requested
[GetTransactionsRequest.length] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the whole range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of transactions can be empty if:

1. [GetTransactionsRequest.length] was zero.
2. [GetTransactionsRequest.from] was larger than the last transaction known to
the canister.
