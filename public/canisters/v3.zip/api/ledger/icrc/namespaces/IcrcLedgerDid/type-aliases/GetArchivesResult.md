---
title: GetArchivesResult
editUrl: false
next: true
prev: true
---

> **GetArchivesResult** = `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L155)

## Type Declaration

### canister\_id

> **canister\_id**: `Principal`

The id of the archive

### end

> **end**: `bigint`

The last block in the archive

### start

> **start**: `bigint`

The first block in the archive
