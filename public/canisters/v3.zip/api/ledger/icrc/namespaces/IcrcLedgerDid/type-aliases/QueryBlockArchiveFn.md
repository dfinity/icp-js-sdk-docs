---
title: QueryBlockArchiveFn
editUrl: false
next: true
prev: true
---

> **QueryBlockArchiveFn** = `ActorMethod`\<\[[`GetBlocksArgs`](../interfaces/GetBlocksArgs.md)\], [`BlockRange`](../interfaces/BlockRange.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L395)

A function for fetching archived blocks.
