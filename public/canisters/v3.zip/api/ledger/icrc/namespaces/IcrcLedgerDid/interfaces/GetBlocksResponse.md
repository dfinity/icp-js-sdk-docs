---
title: GetBlocksResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L182)

The result of a "get_blocks" call.

## Properties

### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L211)

Encoding of instructions for fetching archived blocks.

#### callback

> **callback**: \[`Principal`, `string`\]

Callback to fetch the archived blocks.

#### length

> **length**: `bigint`

The number of blocks that can be fetched.

#### start

> **start**: `bigint`

The index of the first archived block.

***

### blocks

> **blocks**: [`Value`](../type-aliases/Value.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L202)

List of blocks that were available in the ledger when it processed the call.

The blocks form a contiguous range, with the first block having index
[first_block_index] (see below), and the last block having index
[first_block_index] + len(blocks) - 1.

The block range can be an arbitrary sub-range of the originally requested range.

***

### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:187](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L187)

System certificate for the hash of the latest block in the chain.
Only present if `get_blocks` is called in a non-replicated query context.

***

### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L207)

The total number of blocks in the chain.
If the chain length is positive, the index of the last block is `chain_len - 1`.

***

### first\_index

> **first\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:192](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L192)

The index of the first block in "blocks".
If the blocks vector is empty, the exact value of this field is not specified.
