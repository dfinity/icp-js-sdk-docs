---
title: FeeCollector
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:127](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L127)

## Properties

### caller

> **caller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L130)

***

### fee\_collector

> **fee\_collector**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L129)

***

### ts

> **ts**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L128)
