---
title: UpgradeArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L492)

## Properties

### change\_archive\_options

> **change\_archive\_options**: \[\] \| \[[`ChangeArchiveOptions`](ChangeArchiveOptions.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:493](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L493)

***

### change\_fee\_collector

> **change\_fee\_collector**: \[\] \| \[[`ChangeFeeCollector`](../type-aliases/ChangeFeeCollector.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:497](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L497)

***

### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](FeatureFlags.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:501](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L501)

***

### index\_principal

> **index\_principal**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:499](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L499)

***

### max\_memo\_length

> **max\_memo\_length**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L498)

***

### metadata

> **metadata**: \[\] \| \[\[`string`, [`MetadataValue`](../type-aliases/MetadataValue.md)\][]\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:496](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L496)

***

### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:500](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L500)

***

### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:494](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L494)

***

### transfer\_fee

> **transfer\_fee**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:495](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L495)
