---
title: icrc21_error_info
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L549)

## Properties

### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L550)
