---
title: Transaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:406](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L406)

## Properties

### approve

> **approve**: \[\] \| \[[`Approve`](Approve.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L410)

***

### burn

> **burn**: \[\] \| \[[`Burn`](Burn.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L407)

***

### fee\_collector

> **fee\_collector**: \[\] \| \[[`FeeCollector`](FeeCollector.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L411)

***

### kind

> **kind**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L408)

***

### mint

> **mint**: \[\] \| \[[`Mint`](Mint.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:409](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L409)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L412)

***

### transfer

> **transfer**: \[\] \| \[[`Transfer`](Transfer.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:413](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L413)
