---
title: GetIndexPrincipalError
editUrl: false
next: true
prev: true
---

> **GetIndexPrincipalError** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `IndexPrincipalNotSet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L238)

## Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

#### GenericError.description

> **description**: `string`

#### GenericError.error\_code

> **error\_code**: `bigint`

\{ `IndexPrincipalNotSet`: `null`; \}

### IndexPrincipalNotSet

> **IndexPrincipalNotSet**: `null`
