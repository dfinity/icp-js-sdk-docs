---
title: GetIndexPrincipalError
editUrl: false
next: true
prev: true
---

> **GetIndexPrincipalError** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `IndexPrincipalNotSet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L238)

## Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

#### GenericError.description

> **description**: `string`

#### GenericError.error\_code

> **error\_code**: `bigint`

\{ `IndexPrincipalNotSet`: `null`; \}

### IndexPrincipalNotSet

> **IndexPrincipalNotSet**: `null`
