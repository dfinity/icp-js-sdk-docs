---
title: Allowance
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L17)

## Properties

### allowance

> **allowance**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L18)

***

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L19)
