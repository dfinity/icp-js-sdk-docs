---
title: ApproveError
editUrl: false
next: true
prev: true
---

> **ApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](BlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Timestamp`](Timestamp.md); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: [`Timestamp`](Timestamp.md); \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L51)
