---
title: icrc21_error
editUrl: false
next: true
prev: true
---

> **icrc21\_error** = \{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \} \| \{ `InsufficientPayment`: [`icrc21_error_info`](../interfaces/icrc21_error_info.md); \} \| \{ `UnsupportedCanisterCall`: [`icrc21_error_info`](../interfaces/icrc21_error_info.md); \} \| \{ `ConsentMessageUnavailable`: [`icrc21_error_info`](../interfaces/icrc21_error_info.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:539](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L539)

## Type Declaration

\{ `GenericError`: \{ `description`: `string`; `error_code`: `bigint`; \}; \}

### GenericError

> **GenericError**: `object`

Any error not covered by the above variants.

#### GenericError.description

> **description**: `string`

#### GenericError.error\_code

> **error\_code**: `bigint`

\{ `InsufficientPayment`: [`icrc21_error_info`](../interfaces/icrc21_error_info.md); \}

### InsufficientPayment

> **InsufficientPayment**: [`icrc21_error_info`](../interfaces/icrc21_error_info.md)

\{ `UnsupportedCanisterCall`: [`icrc21_error_info`](../interfaces/icrc21_error_info.md); \}

### UnsupportedCanisterCall

> **UnsupportedCanisterCall**: [`icrc21_error_info`](../interfaces/icrc21_error_info.md)

\{ `ConsentMessageUnavailable`: [`icrc21_error_info`](../interfaces/icrc21_error_info.md); \}

### ConsentMessageUnavailable

> **ConsentMessageUnavailable**: [`icrc21_error_info`](../interfaces/icrc21_error_info.md)
