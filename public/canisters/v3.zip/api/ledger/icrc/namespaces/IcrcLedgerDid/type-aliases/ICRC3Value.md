---
title: ICRC3Value
editUrl: false
next: true
prev: true
---

> **ICRC3Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `ICRC3Value`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `ICRC3Value`[]; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L324)
