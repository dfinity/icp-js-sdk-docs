---
title: icrc21_consent_message
editUrl: false
next: true
prev: true
---

> **icrc21\_consent\_message** = \{ `FieldsDisplayMessage`: [`FieldsDisplay`](../interfaces/FieldsDisplay.md); \} \| \{ `GenericDisplayMessage`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:518](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L518)
