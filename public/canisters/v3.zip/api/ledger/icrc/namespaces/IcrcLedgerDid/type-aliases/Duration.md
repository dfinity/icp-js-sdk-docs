---
title: Duration
editUrl: false
next: true
prev: true
---

> **Duration** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L123)

Number of nanoseconds between two [Timestamp]s.
