---
title: QueryArchiveFn
editUrl: false
next: true
prev: true
---

> **QueryArchiveFn** = `ActorMethod`\<\[[`GetTransactionsRequest`](../interfaces/GetTransactionsRequest.md)\], [`TransactionRange`](../interfaces/TransactionRange.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icrc/icrc\_ledger.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icrc/icrc_ledger.d.ts#L388)

A function for fetching archived transaction.
