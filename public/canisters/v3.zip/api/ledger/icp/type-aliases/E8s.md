---
title: E8s
editUrl: false
next: true
prev: true
---

> **E8s** = `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/types/common.ts#L3)
