---
title: E8s
editUrl: false
next: true
prev: true
---

> **E8s** = `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/common.ts:3](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/common.ts#L3)
