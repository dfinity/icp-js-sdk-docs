---
title: IcpLedgerCanisterOptions
editUrl: false
next: true
prev: true
---

> **IcpLedgerCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](../namespaces/IcpLedgerDid/interfaces/SERVICE.md)\>

Defined in: [packages/canisters/src/ledger/icp/types/ledger.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/types/ledger.options.ts#L4)
