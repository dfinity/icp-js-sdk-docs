---
title: TransferRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:5](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L5)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:7](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L7)

***

### createdAt?

> `optional` **createdAt**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:15](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L15)

***

### fee?

> `optional` **fee**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:9](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L9)

***

### fromSubAccount?

> `optional` **fromSubAccount**: `number`[]

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:11](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L11)

***

### memo?

> `optional` **memo**: `bigint`

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:8](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L8)

***

### to

> **to**: [`AccountIdentifier`](../classes/AccountIdentifier.md)

Defined in: [packages/canisters/src/ledger/icp/types/ledger\_converters.ts:6](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/types/ledger_converters.ts#L6)
