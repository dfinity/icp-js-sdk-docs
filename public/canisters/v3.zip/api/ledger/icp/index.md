---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [IcpIndexDid](namespaces/IcpIndexDid/index.md)
- [IcpLedgerDid](namespaces/IcpLedgerDid/index.md)

## Classes

- [AccountIdentifier](classes/AccountIdentifier.md)
- [AllowanceChangedError](classes/AllowanceChangedError.md)
- [ApproveError](classes/ApproveError.md)
- [BadFeeError](classes/BadFeeError.md)
- [ConsentMessageError](classes/ConsentMessageError.md)
- [ConsentMessageUnavailableError](classes/ConsentMessageUnavailableError.md)
- [CreatedInFutureError](classes/CreatedInFutureError.md)
- [DuplicateError](classes/DuplicateError.md)
- [ExpiredError](classes/ExpiredError.md)
- [GenericError](classes/GenericError.md)
- [IcpIndexCanister](classes/IcpIndexCanister.md)
- [IcpLedgerCanister](classes/IcpLedgerCanister.md)
- [IcrcError](classes/IcrcError.md)
- [InsufficientFundsError](classes/InsufficientFundsError.md)
- [InsufficientPaymentError](classes/InsufficientPaymentError.md)
- [InvalidAccountIDError](classes/InvalidAccountIDError.md)
- [InvalidSenderError](classes/InvalidSenderError.md)
- [SubAccount](classes/SubAccount.md)
- [TemporarilyUnavailableError](classes/TemporarilyUnavailableError.md)
- [TooOldError](classes/TooOldError.md)
- [TransferError](classes/TransferError.md)
- [TxCreatedInFutureError](classes/TxCreatedInFutureError.md)
- [TxDuplicateError](classes/TxDuplicateError.md)
- [TxTooOldError](classes/TxTooOldError.md)
- [UnsupportedCanisterCallError](classes/UnsupportedCanisterCallError.md)

## Interfaces

- [Icrc1TransferRequest](interfaces/Icrc1TransferRequest.md)
- [TransferRequest](interfaces/TransferRequest.md)

## Type Aliases

- [AccountIdentifierHex](type-aliases/AccountIdentifierHex.md)
- [BlockHeight](type-aliases/BlockHeight.md)
- [E8s](type-aliases/E8s.md)
- [IcpLedgerCanisterOptions](type-aliases/IcpLedgerCanisterOptions.md)
- [Icrc2ApproveRequest](type-aliases/Icrc2ApproveRequest.md)

## Functions

- [checkAccountId](functions/checkAccountId.md)
- [isIcpAccountIdentifier](functions/isIcpAccountIdentifier.md)
- [mapIcrc1TransferError](functions/mapIcrc1TransferError.md)
- [mapIcrc21ConsentMessageError](functions/mapIcrc21ConsentMessageError.md)
- [mapIcrc2ApproveError](functions/mapIcrc2ApproveError.md)
- [mapTransferError](functions/mapTransferError.md)
- [toIcrc1TransferRawRequest](functions/toIcrc1TransferRawRequest.md)
- [toIcrc21ConsentMessageRawRequest](functions/toIcrc21ConsentMessageRawRequest.md)
- [toIcrc2ApproveRawRequest](functions/toIcrc2ApproveRawRequest.md)
- [toTransferRawRequest](functions/toTransferRawRequest.md)
