---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `Approve`: \{ `allowance`: [`Tokens`](../interfaces/Tokens.md); `expected_allowance`: \[\] \| \[[`Tokens`](../interfaces/Tokens.md)\]; `expires_at`: \[\] \| \[[`TimeStamp`](../interfaces/TimeStamp.md)\]; `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: `string`; \}; \} \| \{ `Burn`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: \[\] \| \[`string`\]; \}; \} \| \{ `Mint`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `to`: `string`; \}; \} \| \{ `Transfer`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: `string`; `spender`: \[\] \| \[`string`\]; `to`: `string`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L71)
