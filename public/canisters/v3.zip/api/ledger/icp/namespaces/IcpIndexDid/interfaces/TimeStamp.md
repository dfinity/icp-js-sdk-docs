---
title: TimeStamp
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L98)

## Properties

### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L99)
