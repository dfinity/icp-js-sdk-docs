---
title: HttpRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:57](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L57)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:60](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L60)

***

### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:61](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L61)

***

### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:59](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L59)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L58)
