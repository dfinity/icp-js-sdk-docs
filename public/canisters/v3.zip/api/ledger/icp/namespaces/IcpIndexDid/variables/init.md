---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:132](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L132)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
