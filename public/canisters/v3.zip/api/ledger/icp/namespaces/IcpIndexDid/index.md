---
title: IcpIndexDid
editUrl: false
next: true
prev: true
---

## Interfaces

- [\_SERVICE](interfaces/SERVICE.md)
- [Account](interfaces/Account.md)
- [GetAccountIdentifierTransactionsArgs](interfaces/GetAccountIdentifierTransactionsArgs.md)
- [GetAccountIdentifierTransactionsError](interfaces/GetAccountIdentifierTransactionsError.md)
- [GetAccountIdentifierTransactionsResponse](interfaces/GetAccountIdentifierTransactionsResponse.md)
- [GetAccountTransactionsArgs](interfaces/GetAccountTransactionsArgs.md)
- [GetBlocksRequest](interfaces/GetBlocksRequest.md)
- [GetBlocksResponse](interfaces/GetBlocksResponse.md)
- [HttpRequest](interfaces/HttpRequest.md)
- [HttpResponse](interfaces/HttpResponse.md)
- [InitArg](interfaces/InitArg.md)
- [Status](interfaces/Status.md)
- [TimeStamp](interfaces/TimeStamp.md)
- [Tokens](interfaces/Tokens.md)
- [Transaction](interfaces/Transaction.md)
- [TransactionWithId](interfaces/TransactionWithId.md)

## Type Aliases

- [GetAccountIdentifierTransactionsResult](type-aliases/GetAccountIdentifierTransactionsResult.md)
- [Operation](type-aliases/Operation.md)

## Variables

- [idlFactory](variables/idlFactory.md)
- [init](variables/init.md)
