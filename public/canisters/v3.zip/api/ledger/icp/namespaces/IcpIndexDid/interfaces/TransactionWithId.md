---
title: TransactionWithId
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L111)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L112)

***

### transaction

> **transaction**: [`Transaction`](Transaction.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L113)
