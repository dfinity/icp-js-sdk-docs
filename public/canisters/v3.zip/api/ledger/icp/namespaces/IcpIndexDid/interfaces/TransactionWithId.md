---
title: TransactionWithId
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L111)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L112)

***

### transaction

> **transaction**: [`Transaction`](Transaction.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:113](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/index.d.ts#L113)
