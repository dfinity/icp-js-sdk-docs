---
title: GetAccountIdentifierTransactionsError
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/index.d.ts#L22)

## Properties

### message

> **message**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/index.d.ts#L23)
