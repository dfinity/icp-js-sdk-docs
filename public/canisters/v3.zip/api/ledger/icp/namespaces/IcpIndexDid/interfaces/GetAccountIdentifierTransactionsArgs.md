---
title: GetAccountIdentifierTransactionsArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L17)

## Properties

### account\_identifier

> **account\_identifier**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L20)

***

### max\_results

> **max\_results**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L18)

***

### start

> **start**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L19)
