---
title: Transaction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L104)

## Properties

### created\_at\_time

> **created\_at\_time**: \[\] \| \[[`TimeStamp`](TimeStamp.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L109)

***

### icrc1\_memo

> **icrc1\_memo**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L106)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L105)

***

### operation

> **operation**: [`Operation`](../type-aliases/Operation.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L107)

***

### timestamp

> **timestamp**: \[\] \| \[[`TimeStamp`](TimeStamp.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L108)
