---
title: GetAccountIdentifierTransactionsResult
editUrl: false
next: true
prev: true
---

> **GetAccountIdentifierTransactionsResult** = \{ `Ok`: [`GetAccountIdentifierTransactionsResponse`](../interfaces/GetAccountIdentifierTransactionsResponse.md); \} \| \{ `Err`: [`GetAccountIdentifierTransactionsError`](../interfaces/GetAccountIdentifierTransactionsError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/index.d.ts#L30)
