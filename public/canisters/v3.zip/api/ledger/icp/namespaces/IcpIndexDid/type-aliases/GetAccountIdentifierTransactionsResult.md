---
title: GetAccountIdentifierTransactionsResult
editUrl: false
next: true
prev: true
---

> **GetAccountIdentifierTransactionsResult** = \{ `Ok`: [`GetAccountIdentifierTransactionsResponse`](../interfaces/GetAccountIdentifierTransactionsResponse.md); \} \| \{ `Err`: [`GetAccountIdentifierTransactionsError`](../interfaces/GetAccountIdentifierTransactionsError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/index.d.ts#L30)
