---
title: HttpResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L63)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:64](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L64)

***

### headers

> **headers**: \[`string`, `string`\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L65)

***

### status\_code

> **status\_code**: `number`

Defined in: [packages/canisters/src/declarations/ledger-icp/index.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/index.d.ts#L66)
