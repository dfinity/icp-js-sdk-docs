---
title: TransferFromError
editUrl: false
next: true
prev: true
---

> **TransferFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: [`Icrc1Timestamp`](Icrc1Timestamp.md); \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:486](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L486)
