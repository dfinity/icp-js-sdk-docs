---
title: TransferFromResult
editUrl: false
next: true
prev: true
---

> **TransferFromResult** = \{ `Ok`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \} \| \{ `Err`: [`TransferFromError`](TransferFromError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:498](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L498)
