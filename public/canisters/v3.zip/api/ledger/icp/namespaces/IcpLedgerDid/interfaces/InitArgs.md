---
title: InitArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L201)

## Properties

### archive\_options

> **archive\_options**: \[\] \| \[[`ArchiveOptions`](ArchiveOptions.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L209)

***

### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](FeatureFlags.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L212)

***

### icrc1\_minting\_account

> **icrc1\_minting\_account**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L208)

***

### initial\_values

> **initial\_values**: \[`string`, [`Tokens`](Tokens.md)\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L210)

***

### max\_message\_size\_bytes

> **max\_message\_size\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L207)

***

### minting\_account

> **minting\_account**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:205](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L205)

***

### send\_whitelist

> **send\_whitelist**: `Principal`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L202)

***

### token\_name

> **token\_name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L211)

***

### token\_symbol

> **token\_symbol**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L203)

***

### transaction\_window

> **transaction\_window**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:206](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L206)

***

### transfer\_fee

> **transfer\_fee**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L204)
