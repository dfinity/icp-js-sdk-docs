---
title: QueryArchiveResult
editUrl: false
next: true
prev: true
---

> **QueryArchiveResult** = \{ `Ok`: [`BlockRange`](../interfaces/BlockRange.md); \} \| \{ `Err`: [`QueryArchiveError`](QueryArchiveError.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:278](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L278)

## Type Declaration

\{ `Ok`: [`BlockRange`](../interfaces/BlockRange.md); \}

### Ok

> **Ok**: [`BlockRange`](../interfaces/BlockRange.md)

Successfully fetched zero or more blocks.

\{ `Err`: [`QueryArchiveError`](QueryArchiveError.md); \}

### Err

> **Err**: [`QueryArchiveError`](QueryArchiveError.md)

The [GetBlocksArgs] request was invalid.
