---
title: TextAccountIdentifier
editUrl: false
next: true
prev: true
---

> **TextAccountIdentifier** = `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:368](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L368)

Account identifier encoded as a 64-byte ASCII hex string.
