---
title: QueryEncodedBlocksResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L336)

## Properties

### archived\_blocks

> **archived\_blocks**: [`ArchivedEncodedBlocksRange`](ArchivedEncodedBlocksRange.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L341)

***

### blocks

> **blocks**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L338)

***

### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L337)

***

### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:339](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L339)

***

### first\_block\_index

> **first\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L340)
