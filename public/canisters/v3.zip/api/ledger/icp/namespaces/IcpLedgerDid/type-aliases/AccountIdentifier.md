---
title: AccountIdentifier
editUrl: false
next: true
prev: true
---

> **AccountIdentifier** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L30)

AccountIdentifier is a 32-byte array.
The first 4 bytes is big-endian encoding of a CRC32 checksum of the last 28 bytes.
