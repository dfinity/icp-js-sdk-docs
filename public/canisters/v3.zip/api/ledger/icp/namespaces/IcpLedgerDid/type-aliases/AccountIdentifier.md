---
title: AccountIdentifier
editUrl: false
next: true
prev: true
---

> **AccountIdentifier** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L30)

AccountIdentifier is a 32-byte array.
The first 4 bytes is big-endian encoding of a CRC32 checksum of the last 28 bytes.
