---
title: Icrc21Value
editUrl: false
next: true
prev: true
---

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L190)
