---
title: Icrc21Value
editUrl: false
next: true
prev: true
---

> **Icrc21Value** = \{ `Text`: \{ `content`: `string`; \}; \} \| \{ `TokenAmount`: \{ `amount`: `bigint`; `decimals`: `number`; `symbol`: `string`; \}; \} \| \{ `TimestampSeconds`: \{ `amount`: `bigint`; \}; \} \| \{ `DurationSeconds`: \{ `amount`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L190)
