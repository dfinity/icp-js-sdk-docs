---
title: Tokens
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L382)

Amount of tokens, measured in 10^-8 of a token.

## Properties

### e8s

> **e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L383)
