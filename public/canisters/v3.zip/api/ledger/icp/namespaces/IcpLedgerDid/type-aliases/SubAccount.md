---
title: SubAccount
editUrl: false
next: true
prev: true
---

> **SubAccount** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L364)

Subaccount is an arbitrary 32-byte byte array.
Ledger uses subaccounts to compute the source address, which enables one
principal to control multiple ledger accounts.
