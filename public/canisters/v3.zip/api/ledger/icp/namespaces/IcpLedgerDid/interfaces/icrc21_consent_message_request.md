---
title: icrc21_consent_message_request
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:527](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L527)

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L528)

***

### method

> **method**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L529)

***

### user\_preferences

> **user\_preferences**: [`icrc21_consent_message_spec`](icrc21_consent_message_spec.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L530)
