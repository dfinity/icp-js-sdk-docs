---
title: ApproveError
editUrl: false
next: true
prev: true
---

> **ApproveError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `AllowanceChanged`: \{ `current_allowance`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `Expired`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:58](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L58)
