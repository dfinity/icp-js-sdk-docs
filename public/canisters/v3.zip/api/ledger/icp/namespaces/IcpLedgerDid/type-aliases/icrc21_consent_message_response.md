---
title: icrc21_consent_message_response
editUrl: false
next: true
prev: true
---

> **icrc21\_consent\_message\_response** = \{ `Ok`: [`icrc21_consent_info`](../interfaces/icrc21_consent_info.md); \} \| \{ `Err`: [`icrc21_error`](icrc21_error.md); \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L532)
