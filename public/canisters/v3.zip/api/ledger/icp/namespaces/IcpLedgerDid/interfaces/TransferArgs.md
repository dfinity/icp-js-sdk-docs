---
title: TransferArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L402)

Arguments for the `transfer` call.

## Properties

### amount

> **amount**: [`Tokens`](Tokens.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L432)

The amount that the caller wants to transfer to the destination address.

***

### created\_at\_time

> **created\_at\_time**: \[\] \| \[[`TimeStamp`](TimeStamp.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L428)

The point in time when the caller created this request.
If null, the ledger uses current IC time as the timestamp.

***

### fee

> **fee**: [`Tokens`](Tokens.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:412](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L412)

The amount that the caller pays for the transaction.
Must be 10000 e8s.

***

### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](../type-aliases/SubAccount.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L423)

The subaccount from which the caller wants to transfer funds.
If null, the ledger uses the default (all zeros) subaccount to compute the source address.
See comments for the `SubAccount` type.

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L417)

Transaction memo.
See comments for the `Memo` type.

***

### to

> **to**: [`AccountIdentifier`](../type-aliases/AccountIdentifier.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:407](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L407)

The destination account.
If the transfer is successful, the balance of this address increases by `amount`.
