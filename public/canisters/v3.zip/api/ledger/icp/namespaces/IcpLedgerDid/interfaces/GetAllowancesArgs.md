---
title: GetAllowancesArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L155)

The arguments for the `get_allowances` endpoint.
The `prev_spender_id` argument can be used for pagination. If specified
the endpoint returns allowances that are lexicographically greater than
(`from_account_id`, `prev_spender_id`) - start with spender after `prev_spender_id`.

## Properties

### from\_account\_id

> **from\_account\_id**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L157)

***

### prev\_spender\_id

> **prev\_spender\_id**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L156)

***

### take

> **take**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L158)
