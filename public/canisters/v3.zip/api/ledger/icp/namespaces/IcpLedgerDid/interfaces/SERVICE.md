---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L552)

## Properties

### account\_balance

> **account\_balance**: `ActorMethod`\<\[[`AccountBalanceArgs`](AccountBalanceArgs.md)\], [`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:556](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L556)

Returns the amount of Tokens on the specified account.

***

### account\_balance\_dfx

> **account\_balance\_dfx**: `ActorMethod`\<\[[`AccountBalanceArgsDfx`](AccountBalanceArgsDfx.md)\], [`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:557](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L557)

***

### account\_identifier

> **account\_identifier**: `ActorMethod`\<\[[`Account`](Account.md)\], [`AccountIdentifier`](../type-aliases/AccountIdentifier.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L561)

Returns the account identifier for the given Principal and subaccount.

***

### archives

> **archives**: `ActorMethod`\<\[\], [`Archives`](Archives.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L565)

Returns the existing archive canisters information.

***

### decimals

> **decimals**: `ActorMethod`\<\[\], \{ `decimals`: `number`; \}\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:569](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L569)

Returns token decimals.

***

### get\_allowances

> **get\_allowances**: `ActorMethod`\<\[[`GetAllowancesArgs`](GetAllowancesArgs.md)\], [`Allowances`](../type-aliases/Allowances.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L570)

***

### icrc1\_balance\_of

> **icrc1\_balance\_of**: `ActorMethod`\<\[[`Account`](Account.md)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:575](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L575)

***

### icrc1\_decimals

> **icrc1\_decimals**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:576](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L576)

***

### icrc1\_fee

> **icrc1\_fee**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L577)

***

### icrc1\_metadata

> **icrc1\_metadata**: `ActorMethod`\<\[\], \[`string`, [`Value`](../type-aliases/Value.md)\][]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L578)

***

### icrc1\_minting\_account

> **icrc1\_minting\_account**: `ActorMethod`\<\[\], \[\] \| \[[`Account`](Account.md)\]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L579)

***

### icrc1\_name

> **icrc1\_name**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L584)

The following methods implement the ICRC-1 Token Standard.
https://github.com/dfinity/ICRC-1/tree/main/standards/ICRC-1

***

### icrc1\_supported\_standards

> **icrc1\_supported\_standards**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:585](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L585)

***

### icrc1\_symbol

> **icrc1\_symbol**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:589](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L589)

***

### icrc1\_total\_supply

> **icrc1\_total\_supply**: `ActorMethod`\<\[\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:590](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L590)

***

### icrc1\_transfer

> **icrc1\_transfer**: `ActorMethod`\<\[[`TransferArg`](TransferArg.md)\], [`Icrc1TransferResult`](../type-aliases/Icrc1TransferResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:591](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L591)

***

### icrc10\_supported\_standards

> **icrc10\_supported\_standards**: `ActorMethod`\<\[\], `object`[]\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L571)

***

### icrc2\_allowance

> **icrc2\_allowance**: `ActorMethod`\<\[[`AllowanceArgs`](AllowanceArgs.md)\], [`Allowance`](Allowance.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L596)

***

### icrc2\_approve

> **icrc2\_approve**: `ActorMethod`\<\[[`ApproveArgs`](ApproveArgs.md)\], [`ApproveResult`](../type-aliases/ApproveResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:597](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L597)

***

### icrc2\_transfer\_from

> **icrc2\_transfer\_from**: `ActorMethod`\<\[[`TransferFromArgs`](TransferFromArgs.md)\], [`TransferFromResult`](../type-aliases/TransferFromResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:598](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L598)

***

### icrc21\_canister\_call\_consent\_message

> **icrc21\_canister\_call\_consent\_message**: `ActorMethod`\<\[[`icrc21_consent_message_request`](icrc21_consent_message_request.md)\], [`icrc21_consent_message_response`](../type-aliases/icrc21_consent_message_response.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L592)

***

### is\_ledger\_ready

> **is\_ledger\_ready**: `ActorMethod`\<\[\], `boolean`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:599](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L599)

***

### name

> **name**: `ActorMethod`\<\[\], \{ `name`: `string`; \}\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:603](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L603)

Returns token name.

***

### query\_blocks

> **query\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](GetBlocksArgs.md)\], [`QueryBlocksResponse`](QueryBlocksResponse.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:607](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L607)

Queries blocks in the specified range.

***

### query\_encoded\_blocks

> **query\_encoded\_blocks**: `ActorMethod`\<\[[`GetBlocksArgs`](GetBlocksArgs.md)\], [`QueryEncodedBlocksResponse`](QueryEncodedBlocksResponse.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L611)

Queries encoded blocks in the specified range

***

### remove\_approval

> **remove\_approval**: `ActorMethod`\<\[[`RemoveApprovalArgs`](RemoveApprovalArgs.md)\], [`ApproveResult`](../type-aliases/ApproveResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:615](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L615)

***

### send\_dfx

> **send\_dfx**: `ActorMethod`\<\[[`SendArgs`](SendArgs.md)\], `bigint`\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:616](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L616)

***

### symbol

> **symbol**: `ActorMethod`\<\[\], \{ `symbol`: `string`; \}\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:620](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L620)

Returns token symbol.

***

### tip\_of\_chain

> **tip\_of\_chain**: `ActorMethod`\<\[\], [`TipOfChainRes`](TipOfChainRes.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:621](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L621)

***

### transfer

> **transfer**: `ActorMethod`\<\[[`TransferArgs`](TransferArgs.md)\], [`TransferResult`](../type-aliases/TransferResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L627)

Transfers tokens from a subaccount of the caller to the destination address.
The source address is computed from the principal of the caller and the specified subaccount.
When successful, returns the index of the block containing the transaction.

***

### transfer\_fee

> **transfer\_fee**: `ActorMethod`\<\[[`TransferFeeArg`](../type-aliases/TransferFeeArg.md)\], [`TransferFee`](TransferFee.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:631](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L631)

Returns the current transfer_fee.
