---
title: BlockRange
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:120](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L120)

A prefix of the block range specified in the [GetBlocksArgs] request.

## Properties

### blocks

> **blocks**: [`Block`](Block.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:136](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L136)

A prefix of the requested block range.
The index of the first block is equal to [GetBlocksArgs.from].

Note that the number of blocks might be less than the requested
[GetBlocksArgs.len] for various reasons, for example:

1. The query might have hit the replica with an outdated state
that doesn't have the full block range yet.
2. The requested range is too large to fit into a single reply.

NOTE: the list of blocks can be empty if:
1. [GetBlocksArgs.len] was zero.
2. [GetBlocksArgs.from] was larger than the last block known to the canister.
