---
title: icrc21_error_info
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L549)

## Properties

### description

> **description**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:550](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L550)
