---
title: QueryBlocksResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L301)

The result of a "query_blocks" call.

The structure of the result is somewhat complicated because the main ledger canister might
not have all the blocks that the caller requested: One or more "archive" canisters might
store some of the requested blocks.

Note: as of Q4 2021 when this interface is authored, the IC doesn't support making nested
query calls within a query call.

## Properties

### archived\_blocks

> **archived\_blocks**: [`ArchivedBlocksRange`](ArchivedBlocksRange.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L334)

Encoding of instructions for fetching archived blocks whose indices fall into the
requested range.

For each entry `e` in [archived_blocks], `[e.from, e.from + len)` is a sub-range
of the originally requested block range.

***

### blocks

> **blocks**: [`Block`](Block.md)[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L316)

List of blocks that were available in the ledger when it processed the call.

The blocks form a contiguous range, with the first block having index
[first_block_index] (see below), and the last block having index
[first_block_index] + len(blocks) - 1.

The block range can be an arbitrary sub-range of the originally requested range.

***

### certificate

> **certificate**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L306)

System certificate for the hash of the latest block in the chain.
Only present if `query_blocks` is called in a non-replicated query context.

***

### chain\_length

> **chain\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L321)

The total number of blocks in the chain.
If the chain length is positive, the index of the last block is `chain_len - 1`.

***

### first\_block\_index

> **first\_block\_index**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L326)

The index of the first block in "blocks".
If the blocks vector is empty, the exact value of this field is not specified.
