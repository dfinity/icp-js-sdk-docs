---
title: Duration
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:138](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L138)

## Properties

### nanos

> **nanos**: `number`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:140](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L140)

***

### secs

> **secs**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:139](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L139)
