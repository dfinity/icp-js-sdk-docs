---
title: Memo
editUrl: false
next: true
prev: true
---

> **Memo** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L221)

An arbitrary number associated with a transaction.
The caller can set it in a `transfer` call as a correlation identifier.
