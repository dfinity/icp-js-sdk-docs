---
title: Memo
editUrl: false
next: true
prev: true
---

> **Memo** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L221)

An arbitrary number associated with a transaction.
The caller can set it in a `transfer` call as a correlation identifier.
