---
title: SendArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L351)

Arguments for the `send_dfx` call.

## Properties

### amount

> **amount**: [`Tokens`](Tokens.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L357)

***

### created\_at\_time

> **created\_at\_time**: \[\] \| \[[`TimeStamp`](TimeStamp.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L356)

***

### fee

> **fee**: [`Tokens`](Tokens.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L353)

***

### from\_subaccount

> **from\_subaccount**: \[\] \| \[[`SubAccount`](../type-aliases/SubAccount.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L355)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L354)

***

### to

> **to**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L352)
