---
title: Icrc1TransferError
editUrl: false
next: true
prev: true
---

> **Icrc1TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `BadBurn`: \{ `min_burn_amount`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`Icrc1BlockIndex`](Icrc1BlockIndex.md); \}; \} \| \{ `BadFee`: \{ `expected_fee`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: [`Icrc1Tokens`](Icrc1Tokens.md); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:176](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L176)
