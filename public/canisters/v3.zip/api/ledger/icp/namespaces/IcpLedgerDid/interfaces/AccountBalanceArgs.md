---
title: AccountBalanceArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L20)

Arguments for the `account_balance` call.

## Properties

### account

> **account**: [`AccountIdentifier`](../type-aliases/AccountIdentifier.md)

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L21)
