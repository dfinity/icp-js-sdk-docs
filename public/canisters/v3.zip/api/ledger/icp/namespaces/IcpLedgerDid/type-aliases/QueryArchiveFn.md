---
title: QueryArchiveFn
editUrl: false
next: true
prev: true
---

> **QueryArchiveFn** = `ActorMethod`\<\[[`GetBlocksArgs`](../interfaces/GetBlocksArgs.md)\], [`QueryArchiveResult`](QueryArchiveResult.md)\>

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L277)

A function that is used for fetching archived ledger blocks.
