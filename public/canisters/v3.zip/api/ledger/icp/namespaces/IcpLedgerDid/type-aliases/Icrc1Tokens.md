---
title: Icrc1Tokens
editUrl: false
next: true
prev: true
---

> **Icrc1Tokens** = `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:175](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L175)
