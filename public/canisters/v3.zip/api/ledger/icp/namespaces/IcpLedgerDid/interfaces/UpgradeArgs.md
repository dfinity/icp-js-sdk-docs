---
title: UpgradeArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L502)

## Properties

### feature\_flags

> **feature\_flags**: \[\] \| \[[`FeatureFlags`](FeatureFlags.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:504](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L504)

***

### icrc1\_minting\_account

> **icrc1\_minting\_account**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L503)
