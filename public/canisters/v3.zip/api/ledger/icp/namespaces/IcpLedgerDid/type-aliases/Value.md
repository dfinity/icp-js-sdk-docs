---
title: Value
editUrl: false
next: true
prev: true
---

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L509)

The value returned from the [icrc1_metadata] endpoint.
