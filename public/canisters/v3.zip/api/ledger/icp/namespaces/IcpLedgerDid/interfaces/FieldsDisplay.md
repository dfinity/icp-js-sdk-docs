---
title: FieldsDisplay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L145)

## Properties

### fields

> **fields**: \[`string`, [`Icrc21Value`](../type-aliases/Icrc21Value.md)\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L146)

***

### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L147)
