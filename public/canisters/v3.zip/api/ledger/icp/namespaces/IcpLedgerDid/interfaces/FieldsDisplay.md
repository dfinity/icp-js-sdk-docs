---
title: FieldsDisplay
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:145](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L145)

## Properties

### fields

> **fields**: \[`string`, [`Icrc21Value`](../type-aliases/Icrc21Value.md)\][]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:146](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L146)

***

### intent

> **intent**: `string`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:147](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L147)
