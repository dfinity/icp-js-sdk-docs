---
title: FeatureFlags
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L142)

## Properties

### icrc2

> **icrc2**: `boolean`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L143)
