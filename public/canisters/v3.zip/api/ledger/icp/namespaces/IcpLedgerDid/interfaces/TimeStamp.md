---
title: TimeStamp
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L372)

Number of nanoseconds from the UNIX epoch in UTC timezone.

## Properties

### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L373)
