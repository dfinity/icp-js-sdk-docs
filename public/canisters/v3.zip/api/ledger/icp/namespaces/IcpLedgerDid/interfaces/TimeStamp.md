---
title: TimeStamp
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:372](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L372)

Number of nanoseconds from the UNIX epoch in UTC timezone.

## Properties

### timestamp\_nanos

> **timestamp\_nanos**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:373](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L373)
