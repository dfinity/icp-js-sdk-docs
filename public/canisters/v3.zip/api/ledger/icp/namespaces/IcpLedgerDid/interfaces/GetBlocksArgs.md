---
title: GetBlocksArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L160)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L168)

Max number of blocks to fetch.

***

### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L164)

The index of the first block to fetch.
