---
title: GetBlocksArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L160)

## Properties

### length

> **length**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L168)

Max number of blocks to fetch.

***

### start

> **start**: `bigint`

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L164)

The index of the first block to fetch.
