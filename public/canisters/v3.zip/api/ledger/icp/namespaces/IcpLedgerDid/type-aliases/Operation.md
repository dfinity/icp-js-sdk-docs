---
title: Operation
editUrl: false
next: true
prev: true
---

> **Operation** = \{ `Approve`: \{ `allowance`: [`Tokens`](../interfaces/Tokens.md); `allowance_e8s`: `bigint`; `expected_allowance`: \[\] \| \[[`Tokens`](../interfaces/Tokens.md)\]; `expires_at`: \[\] \| \[[`TimeStamp`](../interfaces/TimeStamp.md)\]; `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: [`AccountIdentifier`](AccountIdentifier.md); `spender`: [`AccountIdentifier`](AccountIdentifier.md); \}; \} \| \{ `Burn`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `from`: [`AccountIdentifier`](AccountIdentifier.md); `spender`: \[\] \| \[[`AccountIdentifier`](AccountIdentifier.md)\]; \}; \} \| \{ `Mint`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `to`: [`AccountIdentifier`](AccountIdentifier.md); \}; \} \| \{ `Transfer`: \{ `amount`: [`Tokens`](../interfaces/Tokens.md); `fee`: [`Tokens`](../interfaces/Tokens.md); `from`: [`AccountIdentifier`](AccountIdentifier.md); `spender`: \[\] \| \[`Uint8Array`\]; `to`: [`AccountIdentifier`](AccountIdentifier.md); \}; \}

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:222](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L222)
