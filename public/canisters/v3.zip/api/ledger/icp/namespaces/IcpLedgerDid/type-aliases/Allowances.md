---
title: Allowances
editUrl: false
next: true
prev: true
---

> **Allowances** = `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L42)

The allowances returned by the `get_allowances` endpoint.

## Type Declaration

### allowance

> **allowance**: [`Tokens`](../interfaces/Tokens.md)

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

### from\_account\_id

> **from\_account\_id**: [`TextAccountIdentifier`](TextAccountIdentifier.md)

### to\_spender\_id

> **to\_spender\_id**: [`TextAccountIdentifier`](TextAccountIdentifier.md)
