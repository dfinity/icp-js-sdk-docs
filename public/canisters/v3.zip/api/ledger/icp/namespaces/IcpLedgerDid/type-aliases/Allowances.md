---
title: Allowances
editUrl: false
next: true
prev: true
---

> **Allowances** = `object`[]

Defined in: [packages/canisters/src/declarations/ledger-icp/ledger.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ledger-icp/ledger.d.ts#L42)

The allowances returned by the `get_allowances` endpoint.

## Type Declaration

### allowance

> **allowance**: [`Tokens`](../interfaces/Tokens.md)

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

### from\_account\_id

> **from\_account\_id**: [`TextAccountIdentifier`](TextAccountIdentifier.md)

### to\_spender\_id

> **to\_spender\_id**: [`TextAccountIdentifier`](TextAccountIdentifier.md)
