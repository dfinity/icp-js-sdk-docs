---
title: mapIcrc2ApproveError
editUrl: false
next: true
prev: true
---

> **mapIcrc2ApproveError**(`rawApproveError`): [`ApproveError`](../classes/ApproveError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:130](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L130)

## Parameters

### rawApproveError

[`ApproveError`](../namespaces/IcpLedgerDid/type-aliases/ApproveError.md)

## Returns

[`ApproveError`](../classes/ApproveError.md)
