---
title: mapIcrc2ApproveError
editUrl: false
next: true
prev: true
---

> **mapIcrc2ApproveError**(`rawApproveError`): [`ApproveError`](../classes/ApproveError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:130](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L130)

## Parameters

### rawApproveError

[`ApproveError`](../namespaces/IcpLedgerDid/type-aliases/ApproveError.md)

## Returns

[`ApproveError`](../classes/ApproveError.md)
