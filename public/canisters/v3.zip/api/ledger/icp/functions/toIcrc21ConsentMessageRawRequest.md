---
title: toIcrc21ConsentMessageRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc21ConsentMessageRawRequest**(`__namedParameters`): [`icrc21_consent_message_request`](../namespaces/IcpLedgerDid/interfaces/icrc21_consent_message_request.md)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:79](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L79)

## Parameters

### \_\_namedParameters

`Icrc21ConsentMessageRequest`

## Returns

[`icrc21_consent_message_request`](../namespaces/IcpLedgerDid/interfaces/icrc21_consent_message_request.md)
