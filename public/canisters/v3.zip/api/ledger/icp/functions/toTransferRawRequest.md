---
title: toTransferRawRequest
editUrl: false
next: true
prev: true
---

> **toTransferRawRequest**(`__namedParameters`): [`TransferArgs`](../namespaces/IcpLedgerDid/interfaces/TransferArgs.md)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:17](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L17)

## Parameters

### \_\_namedParameters

[`TransferRequest`](../interfaces/TransferRequest.md)

## Returns

[`TransferArgs`](../namespaces/IcpLedgerDid/interfaces/TransferArgs.md)
