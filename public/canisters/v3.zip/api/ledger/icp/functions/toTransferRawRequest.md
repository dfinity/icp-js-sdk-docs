---
title: toTransferRawRequest
editUrl: false
next: true
prev: true
---

> **toTransferRawRequest**(`__namedParameters`): [`TransferArgs`](../namespaces/IcpLedgerDid/interfaces/TransferArgs.md)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:17](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L17)

## Parameters

### \_\_namedParameters

[`TransferRequest`](../interfaces/TransferRequest.md)

## Returns

[`TransferArgs`](../namespaces/IcpLedgerDid/interfaces/TransferArgs.md)
