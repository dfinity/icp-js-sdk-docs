---
title: checkAccountId
editUrl: false
next: true
prev: true
---

> **checkAccountId**(`accountId`): `void`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L15)

Checks account id check sum

## Parameters

### accountId

`string`

## Returns

`void`

## Throws

InvalidAccountIDError
