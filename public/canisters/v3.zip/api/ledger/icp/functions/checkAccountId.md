---
title: checkAccountId
editUrl: false
next: true
prev: true
---

> **checkAccountId**(`accountId`): `void`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L15)

Checks account id check sum

## Parameters

### accountId

`string`

## Returns

`void`

## Throws

InvalidAccountIDError
