---
title: checkAccountId
editUrl: false
next: true
prev: true
---

> **checkAccountId**(`accountId`): `void`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L15)

Checks account id check sum

## Parameters

### accountId

`string`

## Returns

`void`

## Throws

InvalidAccountIDError
