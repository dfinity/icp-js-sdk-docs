---
title: mapTransferError
editUrl: false
next: true
prev: true
---

> **mapTransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:76](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L76)

## Parameters

### rawTransferError

[`TransferError`](../namespaces/IcpLedgerDid/type-aliases/TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
