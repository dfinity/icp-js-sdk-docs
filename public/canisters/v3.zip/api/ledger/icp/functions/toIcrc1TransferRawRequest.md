---
title: toIcrc1TransferRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc1TransferRawRequest**(`__namedParameters`): [`TransferArg`](../namespaces/IcpLedgerDid/interfaces/TransferArg.md)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:43](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L43)

## Parameters

### \_\_namedParameters

[`Icrc1TransferRequest`](../interfaces/Icrc1TransferRequest.md)

## Returns

[`TransferArg`](../namespaces/IcpLedgerDid/interfaces/TransferArg.md)
