---
title: toIcrc1TransferRawRequest
editUrl: false
next: true
prev: true
---

> **toIcrc1TransferRawRequest**(`__namedParameters`): [`TransferArg`](../namespaces/IcpLedgerDid/interfaces/TransferArg.md)

Defined in: [packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts:43](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ledger/icp/canisters/ledger/ledger.request.converts.ts#L43)

## Parameters

### \_\_namedParameters

[`Icrc1TransferRequest`](../interfaces/Icrc1TransferRequest.md)

## Returns

[`TransferArg`](../namespaces/IcpLedgerDid/interfaces/TransferArg.md)
