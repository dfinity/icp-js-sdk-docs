---
title: mapIcrc1TransferError
editUrl: false
next: true
prev: true
---

> **mapIcrc1TransferError**(`rawTransferError`): [`TransferError`](../classes/TransferError.md)

Defined in: [packages/canisters/src/ledger/icp/errors/ledger.errors.ts:104](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ledger/icp/errors/ledger.errors.ts#L104)

## Parameters

### rawTransferError

[`Icrc1TransferError`](../namespaces/IcpLedgerDid/type-aliases/Icrc1TransferError.md)

## Returns

[`TransferError`](../classes/TransferError.md)
