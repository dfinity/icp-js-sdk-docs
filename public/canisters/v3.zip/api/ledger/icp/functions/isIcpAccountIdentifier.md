---
title: isIcpAccountIdentifier
editUrl: false
next: true
prev: true
---

> **isIcpAccountIdentifier**(`address`): `boolean`

Defined in: [packages/canisters/src/ledger/icp/utils/accounts.utils.ts:41](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/icp/utils/accounts.utils.ts#L41)

Checks if a given string (or undefined) is a valid ICP account identifier.

It uses the `checkAccountId` function to validate the checksum, but it does not throw an error.

## Parameters

### address

The putative ICP account identifier.

`string` | `undefined`

## Returns

`boolean`
