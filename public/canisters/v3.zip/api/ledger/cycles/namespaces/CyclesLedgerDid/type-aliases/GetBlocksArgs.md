---
title: GetBlocksArgs
editUrl: false
next: true
prev: true
---

> **GetBlocksArgs** = `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L190)

## Type Declaration

### length

> **length**: `bigint`

### start

> **start**: `bigint`
