---
title: WithdrawFromError
editUrl: false
next: true
prev: true
---

> **WithdrawFromError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `InsufficientAllowance`: \{ `allowance`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: [`BlockIndex`](BlockIndex.md); \}; \} \| \{ `InvalidReceiver`: \{ `receiver`: `Principal`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `FailedToWithdrawFrom`: \{ `approval_refund_block`: \[\] \| \[`bigint`\]; `refund_block`: \[\] \| \[`bigint`\]; `rejection_code`: [`RejectionCode`](RejectionCode.md); `rejection_reason`: `string`; `withdraw_from_block`: \[\] \| \[`bigint`\]; \}; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L356)
