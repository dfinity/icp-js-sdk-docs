---
title: GetBlocksResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L191)

## Properties

### archived\_blocks

> **archived\_blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L202)

The archived_blocks vector is always going to be empty
for this ledger because there is no archive node.

#### args

> **args**: [`GetBlocksArgs`](../type-aliases/GetBlocksArgs.md)

#### callback

> **callback**: \[`Principal`, `string`\]

***

### blocks

> **blocks**: `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L197)

#### block

> **block**: [`Value`](../type-aliases/Value.md)

#### id

> **id**: `bigint`

***

### log\_length

> **log\_length**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L196)

Total number of blocks in the
block log.
