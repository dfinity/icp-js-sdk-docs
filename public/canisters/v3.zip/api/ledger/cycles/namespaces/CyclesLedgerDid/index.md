---
title: CyclesLedgerDid
editUrl: false
next: true
prev: true
---

## Interfaces

- [\_SERVICE](interfaces/SERVICE.md)
- [Account](interfaces/Account.md)
- [Allowance](interfaces/Allowance.md)
- [AllowanceArgs](interfaces/AllowanceArgs.md)
- [ApproveArgs](interfaces/ApproveArgs.md)
- [CanisterSettings](interfaces/CanisterSettings.md)
- [CmcCreateCanisterArgs](interfaces/CmcCreateCanisterArgs.md)
- [CreateCanisterArgs](interfaces/CreateCanisterArgs.md)
- [CreateCanisterFromArgs](interfaces/CreateCanisterFromArgs.md)
- [CreateCanisterSuccess](interfaces/CreateCanisterSuccess.md)
- [DataCertificate](interfaces/DataCertificate.md)
- [DepositArgs](interfaces/DepositArgs.md)
- [DepositResult](interfaces/DepositResult.md)
- [GetAllowancesArgs](interfaces/GetAllowancesArgs.md)
- [GetArchivesArgs](interfaces/GetArchivesArgs.md)
- [GetBlocksResult](interfaces/GetBlocksResult.md)
- [HttpRequest](interfaces/HttpRequest.md)
- [HttpResponse](interfaces/HttpResponse.md)
- [InitArgs](interfaces/InitArgs.md)
- [SubnetFilter](interfaces/SubnetFilter.md)
- [SupportedBlockType](interfaces/SupportedBlockType.md)
- [SupportedStandard](interfaces/SupportedStandard.md)
- [TransferArgs](interfaces/TransferArgs.md)
- [TransferFromArgs](interfaces/TransferFromArgs.md)
- [UpgradeArgs](interfaces/UpgradeArgs.md)
- [WithdrawArgs](interfaces/WithdrawArgs.md)
- [WithdrawFromArgs](interfaces/WithdrawFromArgs.md)

## Type Aliases

- [Allowances](type-aliases/Allowances.md)
- [ApproveError](type-aliases/ApproveError.md)
- [BlockIndex](type-aliases/BlockIndex.md)
- [ChangeIndexId](type-aliases/ChangeIndexId.md)
- [CreateCanisterError](type-aliases/CreateCanisterError.md)
- [CreateCanisterFromError](type-aliases/CreateCanisterFromError.md)
- [GetAllowancesError](type-aliases/GetAllowancesError.md)
- [GetArchivesResult](type-aliases/GetArchivesResult.md)
- [GetBlocksArgs](type-aliases/GetBlocksArgs.md)
- [GetIndexPrincipalError](type-aliases/GetIndexPrincipalError.md)
- [GetIndexPrincipalResult](type-aliases/GetIndexPrincipalResult.md)
- [ICRC103GetAllowancesResponse](type-aliases/ICRC103GetAllowancesResponse.md)
- [LedgerArgs](type-aliases/LedgerArgs.md)
- [MetadataValue](type-aliases/MetadataValue.md)
- [RejectionCode](type-aliases/RejectionCode.md)
- [SubnetSelection](type-aliases/SubnetSelection.md)
- [TransferError](type-aliases/TransferError.md)
- [TransferFromError](type-aliases/TransferFromError.md)
- [Value](type-aliases/Value.md)
- [WithdrawError](type-aliases/WithdrawError.md)
- [WithdrawFromError](type-aliases/WithdrawFromError.md)

## Variables

- [idlFactory](variables/idlFactory.md)
- [init](variables/init.md)
