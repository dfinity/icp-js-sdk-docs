---
title: GetIndexPrincipalResult
editUrl: false
next: true
prev: true
---

> **GetIndexPrincipalResult** = \{ `Ok`: `Principal`; \} \| \{ `Err`: [`GetIndexPrincipalError`](GetIndexPrincipalError.md); \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:215](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L215)
