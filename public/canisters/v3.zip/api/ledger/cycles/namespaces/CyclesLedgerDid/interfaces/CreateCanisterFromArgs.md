---
title: CreateCanisterFromArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:103](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L103)

## Properties

### amount

> **amount**: `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L107)

***

### created\_at\_time

> **created\_at\_time**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:106](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L106)

***

### creation\_args

> **creation\_args**: \[\] \| \[[`CmcCreateCanisterArgs`](CmcCreateCanisterArgs.md)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L108)

***

### from

> **from**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L105)

***

### spender\_subaccount

> **spender\_subaccount**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L104)
