---
title: Allowances
editUrl: false
next: true
prev: true
---

> **Allowances** = `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L25)

## Type Declaration

### allowance

> **allowance**: `bigint`

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

### from\_account

> **from\_account**: [`Account`](../interfaces/Account.md)

### to\_spender

> **to\_spender**: [`Account`](../interfaces/Account.md)
