---
title: Allowances
editUrl: false
next: true
prev: true
---

> **Allowances** = `object`[]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L25)

## Type Declaration

### allowance

> **allowance**: `bigint`

### expires\_at

> **expires\_at**: \[\] \| \[`bigint`\]

### from\_account

> **from\_account**: [`Account`](../interfaces/Account.md)

### to\_spender

> **to\_spender**: [`Account`](../interfaces/Account.md)
