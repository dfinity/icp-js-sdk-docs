---
title: TransferError
editUrl: false
next: true
prev: true
---

> **TransferError** = \{ `GenericError`: \{ `error_code`: `bigint`; `message`: `string`; \}; \} \| \{ `TemporarilyUnavailable`: `null`; \} \| \{ `BadBurn`: \{ `min_burn_amount`: `bigint`; \}; \} \| \{ `Duplicate`: \{ `duplicate_of`: `bigint`; \}; \} \| \{ `BadFee`: \{ `expected_fee`: `bigint`; \}; \} \| \{ `CreatedInFuture`: \{ `ledger_time`: `bigint`; \}; \} \| \{ `TooOld`: `null`; \} \| \{ `InsufficientFunds`: \{ `balance`: `bigint`; \}; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L283)
