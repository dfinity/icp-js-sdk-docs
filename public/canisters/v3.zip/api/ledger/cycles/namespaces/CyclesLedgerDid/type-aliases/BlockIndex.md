---
title: BlockIndex
editUrl: false
next: true
prev: true
---

> **BlockIndex** = `bigint`

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L53)
