---
title: AllowanceArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:21](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L21)

## Properties

### account

> **account**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:22](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L22)

***

### spender

> **spender**: [`Account`](Account.md)

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:23](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L23)
