---
title: Value
editUrl: false
next: true
prev: true
---

> **Value** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `Value`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Nat64`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `Value`[]; \}

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L319)
