---
title: CmcCreateCanisterArgs
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L62)

## Properties

### settings

> **settings**: \[\] \| \[[`CanisterSettings`](CanisterSettings.md)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:71](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L71)

Optional canister settings that, if set, are applied to the newly created canister.
If not specified, the caller is the controller of the canister and the other settings are set to default values.

***

### subnet\_selection

> **subnet\_selection**: \[\] \| \[[`SubnetSelection`](../type-aliases/SubnetSelection.md)\]

Defined in: [packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/cycles-ledger/cycles-ledger.d.ts#L66)

Optional instructions to select on which subnet the new canister will be created on.
