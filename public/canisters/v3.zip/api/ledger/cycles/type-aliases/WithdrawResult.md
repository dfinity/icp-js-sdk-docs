---
title: WithdrawResult
editUrl: false
next: true
prev: true
---

> **WithdrawResult** = \{ `Ok`: [`BlockIndex`](../namespaces/CyclesLedgerDid/type-aliases/BlockIndex.md); \} \| \{ `Err`: [`WithdrawError`](../namespaces/CyclesLedgerDid/type-aliases/WithdrawError.md); \}

Defined in: [packages/canisters/src/ledger/cycles/types/cycles-ledger.responses.ts:3](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/cycles/types/cycles-ledger.responses.ts#L3)
