---
title: WithdrawParams
editUrl: false
next: true
prev: true
---

> **WithdrawParams** = `object` & `Omit`\<[`WithdrawArgs`](../namespaces/CyclesLedgerDid/interfaces/WithdrawArgs.md), `"from_subaccount"` \| `"created_at_time"`\>

Defined in: [packages/canisters/src/ledger/cycles/types/cycles-ledger.params.ts:3](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ledger/cycles/types/cycles-ledger.params.ts#L3)

## Type Declaration

### createdAtTime?

> `optional` **createdAtTime**: `bigint`

### fromSubaccount?

> `optional` **fromSubaccount**: `Uint8Array`
