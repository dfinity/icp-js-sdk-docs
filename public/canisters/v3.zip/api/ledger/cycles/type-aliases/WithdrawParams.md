---
title: WithdrawParams
editUrl: false
next: true
prev: true
---

> **WithdrawParams** = `object` & `Omit`\<[`WithdrawArgs`](../namespaces/CyclesLedgerDid/interfaces/WithdrawArgs.md), `"from_subaccount"` \| `"created_at_time"`\>

Defined in: [packages/canisters/src/ledger/cycles/types/cycles-ledger.params.ts:3](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ledger/cycles/types/cycles-ledger.params.ts#L3)

## Type Declaration

### createdAtTime?

> `optional` **createdAtTime**: `bigint`

### fromSubaccount?

> `optional` **fromSubaccount**: `Uint8Array`
