---
title: CanisterIdString
editUrl: false
next: true
prev: true
---

> **CanisterIdString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:1](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/common.ts#L1)
