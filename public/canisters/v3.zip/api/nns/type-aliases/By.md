---
title: By
editUrl: false
next: true
prev: true
---

> **By** = \{ `NeuronIdOrSubaccount`: `Record`\<`string`, `never`\>; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](../interfaces/ClaimOrRefreshNeuronFromAccount.md); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:84](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L84)
