---
title: By
editUrl: false
next: true
prev: true
---

> **By** = \{ `NeuronIdOrSubaccount`: `Record`\<`string`, `never`\>; \} \| \{ `MemoAndController`: [`ClaimOrRefreshNeuronFromAccount`](../interfaces/ClaimOrRefreshNeuronFromAccount.md); \} \| \{ `Memo`: `bigint`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:90](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L90)
