---
title: Action
editUrl: false
next: true
prev: true
---

> **Action** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](../interfaces/KnownNeuron.md); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](../interfaces/DeregisterKnownNeuron.md); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](../interfaces/ExecuteNnsFunction.md); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](../interfaces/CreateServiceNervousSystem.md); \} \| \{ `ManageNeuron`: [`ManageNeuron`](../interfaces/ManageNeuron.md); \} \| \{ `InstallCode`: [`InstallCode`](../interfaces/InstallCode.md); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](../interfaces/StopOrStartCanister.md); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](../interfaces/UpdateCanisterSettings.md); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](../interfaces/FulfillSubnetRentalRequest.md); \} \| \{ `ApproveGenesisKyc`: [`ApproveGenesisKyc`](../interfaces/ApproveGenesisKyc.md); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](../interfaces/NetworkEconomics.md); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](../interfaces/RewardNodeProvider.md); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](../interfaces/RewardNodeProviders.md); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](../interfaces/AddOrRemoveNodeProvider.md); \} \| \{ `SetDefaultFollowees`: [`SetDefaultFollowees`](../interfaces/SetDefaultFollowees.md); \} \| \{ `Motion`: [`Motion`](../interfaces/Motion.md); \} \| \{ `SetSnsTokenSwapOpenTimeWindow`: [`SetSnsTokenSwapOpenTimeWindow`](../interfaces/SetSnsTokenSwapOpenTimeWindow.md); \} \| \{ `OpenSnsTokenSwap`: [`OpenSnsTokenSwap`](../interfaces/OpenSnsTokenSwap.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:25](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L25)
