---
title: NeuronIdOrSubaccount
editUrl: false
next: true
prev: true
---

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `number`[]; \} \| \{ `NeuronId`: [`NeuronId`](NeuronId.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:436](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L436)
