---
title: ProposalId
editUrl: false
next: true
prev: true
---

> **ProposalId** = `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:520](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L520)
