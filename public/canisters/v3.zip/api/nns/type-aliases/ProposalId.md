---
title: ProposalId
editUrl: false
next: true
prev: true
---

> **ProposalId** = `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:478](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L478)
