---
title: PrincipalString
editUrl: false
next: true
prev: true
---

> **PrincipalString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:5](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/common.ts#L5)
