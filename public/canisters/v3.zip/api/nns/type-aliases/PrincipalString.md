---
title: PrincipalString
editUrl: false
next: true
prev: true
---

> **PrincipalString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:5](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/common.ts#L5)
