---
title: PrincipalString
editUrl: false
next: true
prev: true
---

> **PrincipalString** = `string`

Defined in: [packages/canisters/src/nns/types/common.ts:5](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/common.ts#L5)
