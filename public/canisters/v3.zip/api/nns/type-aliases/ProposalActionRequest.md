---
title: ProposalActionRequest
editUrl: false
next: true
prev: true
---

> **ProposalActionRequest** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](../interfaces/KnownNeuron.md); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](../interfaces/DeregisterKnownNeuron.md); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](../interfaces/ExecuteNnsFunction.md); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](../interfaces/CreateServiceNervousSystem.md); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](../interfaces/ManageNeuronRequest.md); \} \| \{ `InstallCode`: [`InstallCodeRequest`](../interfaces/InstallCodeRequest.md); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](../interfaces/StopOrStartCanister.md); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](../interfaces/UpdateCanisterSettings.md); \} \| \{ `ApproveGenesisKyc`: [`ApproveGenesisKyc`](../interfaces/ApproveGenesisKyc.md); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](../interfaces/NetworkEconomics.md); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](../interfaces/RewardNodeProvider.md); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](../interfaces/RewardNodeProviders.md); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](../interfaces/AddOrRemoveNodeProvider.md); \} \| \{ `Motion`: [`Motion`](../interfaces/Motion.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:46](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L46)
