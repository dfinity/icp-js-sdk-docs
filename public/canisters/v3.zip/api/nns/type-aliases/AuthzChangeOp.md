---
title: AuthzChangeOp
editUrl: false
next: true
prev: true
---

> **AuthzChangeOp** = \{ `Authorize`: \{ `addSelf`: `boolean`; \}; \} \| \{ `Deauthorize`: `null`; \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:72](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L72)
