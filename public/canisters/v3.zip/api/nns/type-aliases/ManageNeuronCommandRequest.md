---
title: ManageNeuronCommandRequest
editUrl: false
next: true
prev: true
---

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](../interfaces/Spawn.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Follow`: [`Follow`](../interfaces/Follow.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `RegisterVote`: [`RegisterVote`](../interfaces/RegisterVote.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SetFollowing`: [`SetFollowing`](../interfaces/SetFollowing.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `StakeMaturity`: [`StakeMaturity`](../interfaces/StakeMaturity.md); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](../interfaces/MakeProposalRequest.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](../interfaces/DisburseMaturity.md); \}

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:120](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L120)
