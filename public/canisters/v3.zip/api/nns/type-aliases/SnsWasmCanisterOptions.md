---
title: SnsWasmCanisterOptions
editUrl: false
next: true
prev: true
---

> **SnsWasmCanisterOptions** = `CanisterOptions`\<[`_SERVICE`](../namespaces/SnsWasmDid/interfaces/SERVICE.md)\>

Defined in: [packages/canisters/src/nns/types/sns\_wasm.options.ts:4](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/sns_wasm.options.ts#L4)
