---
title: NeuronId
editUrl: false
next: true
prev: true
---

> **NeuronId** = `bigint`

Defined in: [packages/canisters/src/nns/types/common.ts:2](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/common.ts#L2)
