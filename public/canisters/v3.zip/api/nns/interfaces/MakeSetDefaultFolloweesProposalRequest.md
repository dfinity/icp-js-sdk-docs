---
title: MakeSetDefaultFolloweesProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:691](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L691)

## Properties

### followees

> **followees**: [`Followees`](Followees.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:696](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L696)

***

### neuronId

> **neuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:692](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L692)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:694](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L694)

***

### title

> **title**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:693](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L693)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:695](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L695)
