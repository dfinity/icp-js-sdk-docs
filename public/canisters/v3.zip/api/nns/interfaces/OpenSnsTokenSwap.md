---
title: OpenSnsTokenSwap
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:383](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L383)

## Properties

### communityFundInvestmentE8s

> **communityFundInvestmentE8s**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:384](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L384)

***

### params

> **params**: [`Option`](../type-aliases/Option.md)\<\{ `maxDirectParticipationIcpE8s`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `maxIcpE8s`: `bigint`; `maxParticipantIcpE8s`: `bigint`; `minDirectParticipationIcpE8s`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `minIcpE8s`: `bigint`; `minParticipantIcpE8s`: `bigint`; `minParticipants`: `number`; `neuronBasketConstructionParameters`: [`Option`](../type-aliases/Option.md)\<\{ `count`: `bigint`; `dissolve_delay_interval_seconds`: `bigint`; \}\>; `saleDelaySeconds`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `snsTokenE8s`: `bigint`; `swapDueTimestampSeconds`: `bigint`; \}\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:386](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L386)

***

### targetSwapCanisterId

> **targetSwapCanisterId**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:385](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L385)
