---
title: OpenSnsTokenSwap
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:349](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L349)

## Properties

### communityFundInvestmentE8s

> **communityFundInvestmentE8s**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:350](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L350)

***

### params

> **params**: [`Option`](../type-aliases/Option.md)\<\{ `maxDirectParticipationIcpE8s`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `maxIcpE8s`: `bigint`; `maxParticipantIcpE8s`: `bigint`; `minDirectParticipationIcpE8s`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `minIcpE8s`: `bigint`; `minParticipantIcpE8s`: `bigint`; `minParticipants`: `number`; `neuronBasketConstructionParameters`: [`Option`](../type-aliases/Option.md)\<\{ `count`: `bigint`; `dissolve_delay_interval_seconds`: `bigint`; \}\>; `saleDelaySeconds`: [`Option`](../type-aliases/Option.md)\<`bigint`\>; `snsTokenE8s`: `bigint`; `swapDueTimestampSeconds`: `bigint`; \}\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:352](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L352)

***

### targetSwapCanisterId

> **targetSwapCanisterId**: [`Option`](../type-aliases/Option.md)\<`Principal`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:351](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L351)
