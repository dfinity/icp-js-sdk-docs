---
title: ListNodeProvidersResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:666](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L666)

## Properties

### nodeProviders

> **nodeProviders**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:667](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L667)
