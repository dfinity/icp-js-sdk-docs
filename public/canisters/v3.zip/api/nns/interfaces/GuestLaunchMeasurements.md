---
title: GuestLaunchMeasurements
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:331](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L331)

## Properties

### guestLaunchMeasurements

> **guestLaunchMeasurements**: [`Option`](../type-aliases/Option.md)\<[`GuestLaunchMeasurement`](GuestLaunchMeasurement.md)[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:332](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L332)
