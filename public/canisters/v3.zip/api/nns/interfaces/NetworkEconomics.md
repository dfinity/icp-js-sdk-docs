---
title: NetworkEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:413](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L413)

## Properties

### maximumNodeProviderRewards

> **maximumNodeProviderRewards**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:421](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L421)

***

### maxProposalsToKeepPerTopic

> **maxProposalsToKeepPerTopic**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:415](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L415)

***

### minimumIcpXdrRate

> **minimumIcpXdrRate**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:420](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L420)

***

### neuronManagementFeePerProposal

> **neuronManagementFeePerProposal**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:416](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L416)

***

### neuronMinimumStake

> **neuronMinimumStake**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:414](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L414)

***

### neuronsFundEconomics

> **neuronsFundEconomics**: [`Option`](../type-aliases/Option.md)\<[`NeuronsFundEconomics`](NeuronsFundEconomics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:422](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L422)

***

### neuronSpawnDissolveDelaySeconds

> **neuronSpawnDissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:419](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L419)

***

### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:417](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L417)

***

### transactionFee

> **transactionFee**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:418](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L418)

***

### votingPowerEconomics

> **votingPowerEconomics**: [`Option`](../type-aliases/Option.md)\<[`VotingPowerEconomics`](VotingPowerEconomics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:423](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L423)
