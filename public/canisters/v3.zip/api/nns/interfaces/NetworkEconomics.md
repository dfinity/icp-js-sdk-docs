---
title: NetworkEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:379](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L379)

## Properties

### maximumNodeProviderRewards

> **maximumNodeProviderRewards**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:387](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L387)

***

### maxProposalsToKeepPerTopic

> **maxProposalsToKeepPerTopic**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:381](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L381)

***

### minimumIcpXdrRate

> **minimumIcpXdrRate**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:386](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L386)

***

### neuronManagementFeePerProposal

> **neuronManagementFeePerProposal**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:382](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L382)

***

### neuronMinimumStake

> **neuronMinimumStake**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:380](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L380)

***

### neuronsFundEconomics

> **neuronsFundEconomics**: [`Option`](../type-aliases/Option.md)\<[`NeuronsFundEconomics`](NeuronsFundEconomics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:388](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L388)

***

### neuronSpawnDissolveDelaySeconds

> **neuronSpawnDissolveDelaySeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:385](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L385)

***

### rejectCost

> **rejectCost**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:383](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L383)

***

### transactionFee

> **transactionFee**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:384](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L384)

***

### votingPowerEconomics

> **votingPowerEconomics**: [`Option`](../type-aliases/Option.md)\<[`VotingPowerEconomics`](VotingPowerEconomics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:389](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L389)
