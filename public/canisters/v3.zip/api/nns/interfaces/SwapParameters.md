---
title: SwapParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:771](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L771)

## Properties

### confirmationText

> **confirmationText**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:775](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L775)

***

### duration

> **duration**: [`Option`](../type-aliases/Option.md)\<[`Duration`](Duration.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:773](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L773)

***

### maxDirectParticipationIcp

> **maxDirectParticipationIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:783](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L783)

***

### maximumIcp

> **maximumIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:781](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L781)

***

### maximumParticipantIcp

> **maximumParticipantIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:776](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L776)

***

### minDirectParticipationIcp

> **minDirectParticipationIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:784](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L784)

***

### minimumIcp

> **minimumIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:778](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L778)

***

### minimumParticipantIcp

> **minimumParticipantIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:779](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L779)

***

### minimumParticipants

> **minimumParticipants**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:772](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L772)

***

### neuronBasketConstructionParameters

> **neuronBasketConstructionParameters**: [`Option`](../type-aliases/Option.md)\<[`NeuronBasketConstructionParameters`](NeuronBasketConstructionParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:774](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L774)

***

### neuronsFundInvestmentIcp

> **neuronsFundInvestmentIcp**: [`Option`](../type-aliases/Option.md)\<[`Tokens`](Tokens.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:777](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L777)

***

### neuronsFundParticipation

> **neuronsFundParticipation**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:785](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L785)

***

### restrictedCountries

> **restrictedCountries**: [`Option`](../type-aliases/Option.md)\<[`Countries`](Countries.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:782](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L782)

***

### startTime

> **startTime**: [`Option`](../type-aliases/Option.md)\<[`GlobalTimeOfDay`](GlobalTimeOfDay.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:780](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L780)
