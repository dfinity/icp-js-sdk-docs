---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:757](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L757)

## Properties

### developerDistribution

> **developerDistribution**: [`Option`](../type-aliases/Option.md)\<[`DeveloperDistribution`](DeveloperDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:759](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L759)

***

### swapDistribution

> **swapDistribution**: [`Option`](../type-aliases/Option.md)\<[`SwapDistribution`](SwapDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:760](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L760)

***

### treasuryDistribution

> **treasuryDistribution**: [`Option`](../type-aliases/Option.md)\<[`SwapDistribution`](SwapDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:758](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L758)
