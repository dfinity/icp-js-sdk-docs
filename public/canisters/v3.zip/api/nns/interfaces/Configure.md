---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:135](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L135)

## Properties

### operation

> **operation**: [`Option`](../type-aliases/Option.md)\<[`Operation`](../type-aliases/Operation.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:136](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L136)
