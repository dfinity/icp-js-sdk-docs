---
title: ManageNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:280](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L280)

## Properties

### command

> **command**: [`Option`](../type-aliases/Option.md)\<[`ManageNeuronCommandRequest`](../type-aliases/ManageNeuronCommandRequest.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:282](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L282)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:281](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L281)

***

### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](../type-aliases/Option.md)\<[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:283](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L283)
