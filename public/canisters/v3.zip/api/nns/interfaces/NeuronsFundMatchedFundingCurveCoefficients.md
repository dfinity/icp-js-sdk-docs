---
title: NeuronsFundMatchedFundingCurveCoefficients
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:436](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L436)

## Properties

### contributionThresholdXdr

> **contributionThresholdXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:437](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L437)

***

### fullParticipationMilestoneXdr

> **fullParticipationMilestoneXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:439](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L439)

***

### oneThirdParticipationMilestoneXdr

> **oneThirdParticipationMilestoneXdr**: [`Option`](../type-aliases/Option.md)\<[`Decimal`](Decimal.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:438](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L438)
