---
title: ApproveGenesisKyc
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:69](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L69)

## Properties

### principals

> **principals**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:70](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L70)
