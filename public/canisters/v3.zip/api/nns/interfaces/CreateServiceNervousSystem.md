---
title: CreateServiceNervousSystem
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:763](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L763)

## Properties

### dappCanisters

> **dappCanisters**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:771](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L771)

***

### description

> **description**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:770](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L770)

***

### fallbackControllerPrincipalIds

> **fallbackControllerPrincipalIds**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:766](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L766)

***

### governanceParameters

> **governanceParameters**: [`Option`](../type-aliases/Option.md)\<[`GovernanceParameters`](GovernanceParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:765](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L765)

***

### initialTokenDistribution

> **initialTokenDistribution**: [`Option`](../type-aliases/Option.md)\<[`InitialTokenDistribution`](InitialTokenDistribution.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:773](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L773)

***

### ledgerParameters

> **ledgerParameters**: [`Option`](../type-aliases/Option.md)\<[`LedgerParameters`](LedgerParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:769](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L769)

***

### logo

> **logo**: [`Option`](../type-aliases/Option.md)\<[`Image`](Image.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:767](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L767)

***

### name

> **name**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:768](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L768)

***

### swapParameters

> **swapParameters**: [`Option`](../type-aliases/Option.md)\<[`SwapParameters`](SwapParameters.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:772](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L772)

***

### url

> **url**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L764)
