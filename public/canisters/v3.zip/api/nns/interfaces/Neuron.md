---
title: Neuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:444](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L444)

## Properties

### accountIdentifier

> **accountIdentifier**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:460](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L460)

***

### agingSinceTimestampSeconds

> **agingSinceTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:456](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L456)

***

### autoStakeMaturity

> **autoStakeMaturity**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:454](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L454)

***

### cachedNeuronStake

> **cachedNeuronStake**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:452](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L452)

***

### controller

> **controller**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:448](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L448)

***

### createdTimestampSeconds

> **createdTimestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:453](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L453)

***

### decidingVotingPower

> **decidingVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:468](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L468)

***

### dissolveState

> **dissolveState**: [`Option`](../type-aliases/Option.md)\<[`DissolveState`](../type-aliases/DissolveState.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:463](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L463)

***

### followees

> **followees**: [`Followees`](Followees.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:464](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L464)

***

### hotKeys

> **hotKeys**: `string`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:459](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L459)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:445](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L445)

***

### joinedCommunityFundTimestampSeconds

> **joinedCommunityFundTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:461](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L461)

***

### kycVerified

> **kycVerified**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:450](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L450)

***

### maturityDisbursementsInProgress

> **maturityDisbursementsInProgress**: [`Option`](../type-aliases/Option.md)\<[`MaturityDisbursement`](MaturityDisbursement.md)[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:462](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L462)

***

### maturityE8sEquivalent

> **maturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:455](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L455)

***

### neuronFees

> **neuronFees**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:458](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L458)

***

### neuronType

> **neuronType**: [`Option`](../type-aliases/Option.md)\<[`NeuronType`](../enumerations/NeuronType.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:446](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L446)

***

### notForProfit

> **notForProfit**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:451](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L451)

***

### potentialVotingPower

> **potentialVotingPower**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:467](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L467)

***

### recentBallots

> **recentBallots**: [`BallotInfo`](BallotInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:449](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L449)

***

### spawnAtTimesSeconds

> **spawnAtTimesSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:457](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L457)

***

### stakedMaturityE8sEquivalent

> **stakedMaturityE8sEquivalent**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:447](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L447)

***

### visibility

> **visibility**: [`Option`](../type-aliases/Option.md)\<[`NeuronVisibility`](../enumerations/NeuronVisibility.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:465](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L465)

***

### votingPowerRefreshedTimestampSeconds

> **votingPowerRefreshedTimestampSeconds**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:466](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L466)
