---
title: ClaimNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:562](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L562)

## Properties

### dissolveDelayInSecs

> **dissolveDelayInSecs**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:565](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L565)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:564](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L564)

***

### publicKey

> **publicKey**: `DerEncodedPublicKey`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:563](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L563)
