---
title: MergeRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:318](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L318)

## Properties

### sourceNeuronId

> **sourceNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:319](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L319)

***

### targetNeuronId

> **targetNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:320](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L320)
