---
title: MergeRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:318](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L318)

## Properties

### sourceNeuronId

> **sourceNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:319](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L319)

***

### targetNeuronId

> **targetNeuronId**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:320](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L320)
