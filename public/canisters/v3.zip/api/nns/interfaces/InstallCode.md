---
title: InstallCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:285](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L285)

## Properties

### argHash

> **argHash**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:286](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L286)

***

### canisterId

> **canisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:289](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L289)

***

### installMode

> **installMode**: [`Option`](../type-aliases/Option.md)\<[`CanisterInstallMode`](../enumerations/CanisterInstallMode.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:290](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L290)

***

### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:288](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L288)

***

### wasmModuleHash

> **wasmModuleHash**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:287](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L287)
