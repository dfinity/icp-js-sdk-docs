---
title: Tally
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:543](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L543)

## Properties

### no

> **no**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:544](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L544)

***

### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:547](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L547)

***

### total

> **total**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:546](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L546)

***

### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:545](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L545)
