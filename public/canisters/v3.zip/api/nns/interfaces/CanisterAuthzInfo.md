---
title: CanisterAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:88](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L88)

## Properties

### methodsAuthz

> **methodsAuthz**: [`MethodAuthzInfo`](MethodAuthzInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:89](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L89)
