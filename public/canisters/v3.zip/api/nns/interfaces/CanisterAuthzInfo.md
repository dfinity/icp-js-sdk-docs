---
title: CanisterAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:88](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L88)

## Properties

### methodsAuthz

> **methodsAuthz**: [`MethodAuthzInfo`](MethodAuthzInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:89](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L89)
