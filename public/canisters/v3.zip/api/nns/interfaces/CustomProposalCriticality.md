---
title: CustomProposalCriticality
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:763](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L763)

## Properties

### additionalCriticalNativeActionIds

> **additionalCriticalNativeActionIds**: [`Option`](../type-aliases/Option.md)\<`bigint`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:764](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L764)
