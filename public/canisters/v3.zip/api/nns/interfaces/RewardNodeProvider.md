---
title: RewardNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:568](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L568)

## Properties

### amountE8s

> **amountE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:571](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L571)

***

### nodeProvider

> **nodeProvider**: [`Option`](../type-aliases/Option.md)\<[`NodeProvider`](NodeProvider.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:569](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L569)

***

### rewardMode

> **rewardMode**: [`Option`](../type-aliases/Option.md)\<[`RewardMode`](../type-aliases/RewardMode.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:570](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L570)
