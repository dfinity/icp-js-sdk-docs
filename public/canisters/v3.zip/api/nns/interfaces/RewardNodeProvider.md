---
title: RewardNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:526](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L526)

## Properties

### amountE8s

> **amountE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:529](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L529)

***

### nodeProvider

> **nodeProvider**: [`Option`](../type-aliases/Option.md)\<[`NodeProvider`](NodeProvider.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:527](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L527)

***

### rewardMode

> **rewardMode**: [`Option`](../type-aliases/Option.md)\<[`RewardMode`](../type-aliases/RewardMode.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:528](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L528)
