---
title: RewardNodeProviders
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:551](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L551)

## Properties

### rewards

> **rewards**: [`RewardNodeProvider`](RewardNodeProvider.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:553](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L553)

***

### useRegistryDerivedRewards

> **useRegistryDerivedRewards**: `boolean` \| `undefined`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:552](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L552)
