---
title: SetSnsTokenSwapOpenTimeWindow
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:404](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L404)

## Properties

### request

> **request**: [`Option`](../type-aliases/Option.md)\<\{ `openTimeWindow`: [`Option`](../type-aliases/Option.md)\<\{ `endTimestampSeconds`: `bigint`; `startTimestampSeconds`: `bigint`; \}\>; \}\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:405](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L405)

***

### swapCanisterId

> **swapCanisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:411](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L411)
