---
title: Motion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:346](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L346)

## Properties

### motionText

> **motionText**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:347](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L347)
