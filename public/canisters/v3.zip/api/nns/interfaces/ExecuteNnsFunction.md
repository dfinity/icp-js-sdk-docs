---
title: ExecuteNnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:172](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L172)

## Properties

### nnsFunctionId

> **nnsFunctionId**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:173](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L173)

***

### payloadBytes?

> `optional` **payloadBytes**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:174](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L174)
