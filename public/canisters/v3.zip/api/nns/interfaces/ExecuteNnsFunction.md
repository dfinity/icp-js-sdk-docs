---
title: ExecuteNnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:166](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L166)

## Properties

### nnsFunctionId

> **nnsFunctionId**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:167](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L167)

***

### payloadBytes?

> `optional` **payloadBytes**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:168](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L168)
