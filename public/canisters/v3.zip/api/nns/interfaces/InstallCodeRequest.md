---
title: InstallCodeRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:292](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L292)

## Properties

### arg

> **arg**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:293](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L293)

***

### canisterId

> **canisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:296](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L296)

***

### installMode

> **installMode**: [`Option`](../type-aliases/Option.md)\<[`CanisterInstallMode`](../enumerations/CanisterInstallMode.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:297](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L297)

***

### skipStoppingBeforeInstalling

> **skipStoppingBeforeInstalling**: [`Option`](../type-aliases/Option.md)\<`boolean`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:295](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L295)

***

### wasmModule

> **wasmModule**: `ArrayBuffer`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:294](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L294)
