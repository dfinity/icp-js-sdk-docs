---
title: ListProposalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:269](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L269)

## Properties

### proposals

> **proposals**: [`ProposalInfo`](ProposalInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:270](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L270)
