---
title: ListProposalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:263](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L263)

## Properties

### proposals

> **proposals**: [`ProposalInfo`](ProposalInfo.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:264](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L264)
