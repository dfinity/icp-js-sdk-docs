---
title: SetFollowing
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:160](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L160)

## Properties

### topicFollowing

> **topicFollowing**: [`FolloweesForTopic`](FolloweesForTopic.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:161](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L161)
