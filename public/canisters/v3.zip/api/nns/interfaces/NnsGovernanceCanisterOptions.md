---
title: NnsGovernanceCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance.options.ts:5](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance.options.ts#L5)

## Extends

- `CanisterOptions`\<[`_SERVICE`](../namespaces/NnsGovernanceDid/interfaces/SERVICE.md)\>

## Properties

### agent?

> `optional` **agent**: `Agent`

Defined in: packages/utils/dist/types/canister.options.d.ts:4

#### Inherited from

`CanisterOptions.agent`

***

### canisterId?

> `optional` **canisterId**: `Principal`

Defined in: packages/utils/dist/types/canister.options.d.ts:5

#### Inherited from

`CanisterOptions.canisterId`

***

### certifiedServiceOverride?

> `optional` **certifiedServiceOverride**: `ActorSubclass`\<[`_SERVICE`](../namespaces/NnsGovernanceDid/interfaces/SERVICE.md)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:7

#### Inherited from

`CanisterOptions.certifiedServiceOverride`

***

### hardwareWallet?

> `optional` **hardwareWallet**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance.options.ts:8](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance.options.ts#L8)

***

### oldListNeuronsServiceOverride?

> `optional` **oldListNeuronsServiceOverride**: `ActorSubclass`\<[`_SERVICE`](../namespaces/NnsGovernanceDid/interfaces/SERVICE.md)\>

Defined in: [packages/canisters/src/nns/types/governance.options.ts:9](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance.options.ts#L9)

***

### serviceOverride?

> `optional` **serviceOverride**: `ActorSubclass`\<[`_SERVICE`](../namespaces/NnsGovernanceDid/interfaces/SERVICE.md)\>

Defined in: packages/utils/dist/types/canister.options.d.ts:6

#### Inherited from

`CanisterOptions.serviceOverride`
