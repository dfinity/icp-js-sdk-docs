---
title: GovernanceCachedMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:840](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L840)

## Properties

### communityFundTotalMaturityE8sEquivalent

> **communityFundTotalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:852](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L852)

***

### communityFundTotalStakedE8s

> **communityFundTotalStakedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:880](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L880)

***

### decliningVotingPowerNeuronSubsetMetrics

> **decliningVotingPowerNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:864](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L864)

***

### dissolvedNeuronsCount

> **dissolvedNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:851](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L851)

***

### dissolvedNeuronsE8s

> **dissolvedNeuronsE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:867](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L867)

***

### dissolvingNeuronsCount

> **dissolvingNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:877](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L877)

***

### dissolvingNeuronsCountBuckets

> **dissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:874](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L874)

***

### dissolvingNeuronsE8sBuckets

> **dissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:878](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L878)

***

### dissolvingNeuronsE8sBucketsEct

> **dissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:875](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L875)

***

### dissolvingNeuronsE8sBucketsSeed

> **dissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:869](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L869)

***

### dissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **dissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:845](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L845)

***

### dissolvingNeuronsStakedMaturityE8sEquivalentSum

> **dissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:843](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L843)

***

### ectNeuronCount

> **ectNeuronCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:848](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L848)

***

### fullyLostVotingPowerNeuronSubsetMetrics

> **fullyLostVotingPowerNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:856](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L856)

***

### garbageCollectableNeuronsCount

> **garbageCollectableNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:844](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L844)

***

### neuronsFundTotalActiveNeurons

> **neuronsFundTotalActiveNeurons**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:859](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L859)

***

### neuronsWithInvalidStakeCount

> **neuronsWithInvalidStakeCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:846](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L846)

***

### neuronsWithLessThan6MonthsDissolveDelayCount

> **neuronsWithLessThan6MonthsDissolveDelayCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:850](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L850)

***

### neuronsWithLessThan6MonthsDissolveDelayE8s

> **neuronsWithLessThan6MonthsDissolveDelayE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:870](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L870)

***

### nonSelfAuthenticatingControllerNeuronSubsetMetrics

> **nonSelfAuthenticatingControllerNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:876](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L876)

***

### notDissolvingNeuronsCount

> **notDissolvingNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:857](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L857)

***

### notDissolvingNeuronsCountBuckets

> **notDissolvingNeuronsCountBuckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:847](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L847)

***

### notDissolvingNeuronsE8sBuckets

> **notDissolvingNeuronsE8sBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:842](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L842)

***

### notDissolvingNeuronsE8sBucketsEct

> **notDissolvingNeuronsE8sBucketsEct**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:862](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L862)

***

### notDissolvingNeuronsE8sBucketsSeed

> **notDissolvingNeuronsE8sBucketsSeed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:881](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L881)

***

### notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets

> **notDissolvingNeuronsStakedMaturityE8sEquivalentBuckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:871](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L871)

***

### notDissolvingNeuronsStakedMaturityE8sEquivalentSum

> **notDissolvingNeuronsStakedMaturityE8sEquivalentSum**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:866](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L866)

***

### publicNeuronSubsetMetrics

> **publicNeuronSubsetMetrics**: [`Option`](../type-aliases/Option.md)\<[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:882](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L882)

***

### seedNeuronCount

> **seedNeuronCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:884](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L884)

***

### spawningNeuronsCount

> **spawningNeuronsCount**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:863](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L863)

***

### timestampSeconds

> **timestampSeconds**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:883](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L883)

***

### totalLockedE8s

> **totalLockedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:858](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L858)

***

### totalMaturityE8sEquivalent

> **totalMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:841](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L841)

***

### totalStakedE8s

> **totalStakedE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:855](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L855)

***

### totalStakedE8sEct

> **totalStakedE8sEct**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:865](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L865)

***

### totalStakedE8sNonSelfAuthenticatingController

> **totalStakedE8sNonSelfAuthenticatingController**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:868](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L868)

***

### totalStakedE8sSeed

> **totalStakedE8sSeed**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:853](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L853)

***

### totalStakedMaturityE8sEquivalent

> **totalStakedMaturityE8sEquivalent**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:861](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L861)

***

### totalStakedMaturityE8sEquivalentEct

> **totalStakedMaturityE8sEquivalentEct**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:854](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L854)

***

### totalStakedMaturityE8sEquivalentSeed

> **totalStakedMaturityE8sEquivalentSeed**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:879](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L879)

***

### totalSupplyIcp

> **totalSupplyIcp**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:849](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L849)

***

### totalVotingPowerNonSelfAuthenticatingController

> **totalVotingPowerNonSelfAuthenticatingController**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:860](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L860)
