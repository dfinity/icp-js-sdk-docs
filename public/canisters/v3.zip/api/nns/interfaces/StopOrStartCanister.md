---
title: StopOrStartCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:293](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L293)

## Properties

### action

> **action**: [`Option`](../type-aliases/Option.md)\<[`CanisterAction`](../enumerations/CanisterAction.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:295](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L295)

***

### canisterId

> **canisterId**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:294](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L294)
