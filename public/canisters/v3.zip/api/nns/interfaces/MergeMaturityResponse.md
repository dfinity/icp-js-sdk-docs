---
title: MergeMaturityResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:332](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L332)

## Properties

### mergedMaturityE8s

> **mergedMaturityE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:333](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L333)

***

### newStakeE8s

> **newStakeE8s**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:334](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L334)
