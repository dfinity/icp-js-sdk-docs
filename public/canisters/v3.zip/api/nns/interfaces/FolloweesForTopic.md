---
title: FolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:156](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L156)

## Properties

### followees

> **followees**: `bigint`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:158](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L158)

***

### topic

> **topic**: [`Topic`](../enumerations/Topic.md)

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:157](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L157)
