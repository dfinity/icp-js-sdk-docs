---
title: MethodAuthzInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:342](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L342)

## Properties

### methodName

> **methodName**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:343](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L343)

***

### principalIds

> **principalIds**: `ArrayBuffer`[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:344](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L344)
