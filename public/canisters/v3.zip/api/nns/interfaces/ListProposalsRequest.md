---
title: ListProposalsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:219](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L219)

## Properties

### beforeProposal

> **beforeProposal**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:228](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L228)

***

### excludeTopic

> **excludeTopic**: [`Topic`](../enumerations/Topic.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:242](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L242)

***

### includeAllManageNeuronProposals

> **includeAllManageNeuronProposals**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:247](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L247)

***

### includeRewardStatus

> **includeRewardStatus**: [`ProposalRewardStatus`](../enumerations/ProposalRewardStatus.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:236](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L236)

***

### includeStatus

> **includeStatus**: [`ProposalStatus`](../enumerations/ProposalStatus.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:252](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L252)

***

### limit

> **limit**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:223](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L223)

***

### omitLargeFields?

> `optional` **omitLargeFields**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:258](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L258)

***

### returnSelfDescribingAction?

> `optional` **returnSelfDescribingAction**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:261](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/types/governance_converters.ts#L261)
