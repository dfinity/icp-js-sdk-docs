---
title: ListProposalsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:225](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L225)

## Properties

### beforeProposal

> **beforeProposal**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:234](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L234)

***

### excludeTopic

> **excludeTopic**: [`Topic`](../enumerations/Topic.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:248](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L248)

***

### includeAllManageNeuronProposals

> **includeAllManageNeuronProposals**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:253](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L253)

***

### includeRewardStatus

> **includeRewardStatus**: [`ProposalRewardStatus`](../enumerations/ProposalRewardStatus.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:242](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L242)

***

### includeStatus

> **includeStatus**: [`ProposalStatus`](../enumerations/ProposalStatus.md)[]

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:258](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L258)

***

### limit

> **limit**: `number`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:229](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L229)

***

### omitLargeFields?

> `optional` **omitLargeFields**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:264](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L264)

***

### returnSelfDescribingAction?

> `optional` **returnSelfDescribingAction**: `boolean`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:267](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/types/governance_converters.ts#L267)
