---
title: KnownNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:200](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L200)

## Properties

### committed\_topics

> **committed\_topics**: [`Option`](../type-aliases/Option.md)\<(\[\] \| \[[`TopicToFollow`](../namespaces/NnsGovernanceDid/type-aliases/TopicToFollow.md)\])[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:205](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L205)

***

### description

> **description**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:203](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L203)

***

### id

> **id**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:201](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L201)

***

### links

> **links**: [`Option`](../type-aliases/Option.md)\<`string`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:204](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L204)

***

### name

> **name**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:202](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/types/governance_converters.ts#L202)
