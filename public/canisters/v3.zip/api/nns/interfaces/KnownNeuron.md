---
title: KnownNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:206](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L206)

## Properties

### committed\_topics

> **committed\_topics**: [`Option`](../type-aliases/Option.md)\<(\[\] \| \[[`TopicToFollow`](../namespaces/NnsGovernanceDid/type-aliases/TopicToFollow.md)\])[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:211](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L211)

***

### description

> **description**: [`Option`](../type-aliases/Option.md)\<`string`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:209](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L209)

***

### id

> **id**: `bigint`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:207](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L207)

***

### links

> **links**: [`Option`](../type-aliases/Option.md)\<`string`[]\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:210](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L210)

***

### name

> **name**: `string`

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:208](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L208)
