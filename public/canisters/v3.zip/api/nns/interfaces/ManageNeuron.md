---
title: ManageNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:275](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L275)

## Properties

### command

> **command**: [`Option`](../type-aliases/Option.md)\<[`Command`](../type-aliases/Command.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:277](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L277)

***

### id

> **id**: [`Option`](../type-aliases/Option.md)\<`bigint`\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:276](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L276)

***

### neuronIdOrSubaccount

> **neuronIdOrSubaccount**: [`Option`](../type-aliases/Option.md)\<[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\>

Defined in: [packages/canisters/src/nns/types/governance\_converters.ts:278](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/types/governance_converters.ts#L278)
