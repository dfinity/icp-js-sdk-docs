---
title: accountIdentifierToBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierToBytes**(`accountIdentifier`): `Uint8Array`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/utils/account_identifier.utils.ts#L15)

## Parameters

### accountIdentifier

`string`

## Returns

`Uint8Array`
