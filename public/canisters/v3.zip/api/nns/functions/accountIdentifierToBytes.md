---
title: accountIdentifierToBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierToBytes**(`accountIdentifier`): `Uint8Array`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:15](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/utils/account_identifier.utils.ts#L15)

## Parameters

### accountIdentifier

`string`

## Returns

`Uint8Array`
