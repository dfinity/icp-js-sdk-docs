---
title: votableNeurons
editUrl: false
next: true
prev: true
---

> **votableNeurons**(`params`): [`NeuronInfo`](../interfaces/NeuronInfo.md)[]

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:66](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/utils/neurons.utils.ts#L66)

Filter the neurons that can vote for a proposal - i.e. the neurons that have not voted yet and are eligible

## Parameters

### params

#### neurons

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]

The neurons to filter.

#### proposal

[`ProposalInfo`](../interfaces/ProposalInfo.md)

The proposal to match against the selected neurons.

## Returns

[`NeuronInfo`](../interfaces/NeuronInfo.md)[]
