---
title: memoToNeuronAccountIdentifier
editUrl: false
next: true
prev: true
---

> **memoToNeuronAccountIdentifier**(`__namedParameters`): [`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/utils/neurons.utils.ts#L122)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### governanceCanisterId

`Principal`

#### memo

`bigint`

## Returns

[`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)
