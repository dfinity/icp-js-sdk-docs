---
title: memoToNeuronAccountIdentifier
editUrl: false
next: true
prev: true
---

> **memoToNeuronAccountIdentifier**(`__namedParameters`): [`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:122](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/utils/neurons.utils.ts#L122)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### governanceCanisterId

`Principal`

#### memo

`bigint`

## Returns

[`AccountIdentifier`](../../ledger/icp/classes/AccountIdentifier.md)
