---
title: accountIdentifierFromBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierFromBytes**(`accountIdentifier`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:19](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/utils/account_identifier.utils.ts#L19)

## Parameters

### accountIdentifier

`Uint8Array`

## Returns

`string`
