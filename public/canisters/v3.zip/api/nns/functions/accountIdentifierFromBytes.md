---
title: accountIdentifierFromBytes
editUrl: false
next: true
prev: true
---

> **accountIdentifierFromBytes**(`accountIdentifier`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:19](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/utils/account_identifier.utils.ts#L19)

## Parameters

### accountIdentifier

`Uint8Array`

## Returns

`string`
