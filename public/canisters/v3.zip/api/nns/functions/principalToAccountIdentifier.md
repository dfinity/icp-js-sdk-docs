---
title: principalToAccountIdentifier
editUrl: false
next: true
prev: true
---

> **principalToAccountIdentifier**(`principal`, `subAccount?`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:24](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/utils/account_identifier.utils.ts#L24)

## Parameters

### principal

`Principal`

### subAccount?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

`string`
