---
title: principalToAccountIdentifier
editUrl: false
next: true
prev: true
---

> **principalToAccountIdentifier**(`principal`, `subAccount?`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:24](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/utils/account_identifier.utils.ts#L24)

## Parameters

### principal

`Principal`

### subAccount?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

`string`
