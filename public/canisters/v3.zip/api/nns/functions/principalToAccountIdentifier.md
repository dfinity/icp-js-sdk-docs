---
title: principalToAccountIdentifier
editUrl: false
next: true
prev: true
---

> **principalToAccountIdentifier**(`principal`, `subAccount?`): `string`

Defined in: [packages/canisters/src/nns/utils/account\_identifier.utils.ts:24](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/utils/account_identifier.utils.ts#L24)

## Parameters

### principal

`Principal`

### subAccount?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

`string`
