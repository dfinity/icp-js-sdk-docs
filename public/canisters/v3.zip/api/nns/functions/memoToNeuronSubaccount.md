---
title: memoToNeuronSubaccount
editUrl: false
next: true
prev: true
---

> **memoToNeuronSubaccount**(`__namedParameters`): [`SubAccount`](../../ledger/icp/classes/SubAccount.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/nns/utils/neurons.utils.ts#L101)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### memo

`bigint`

## Returns

[`SubAccount`](../../ledger/icp/classes/SubAccount.md)
