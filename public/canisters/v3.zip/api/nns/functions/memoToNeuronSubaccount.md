---
title: memoToNeuronSubaccount
editUrl: false
next: true
prev: true
---

> **memoToNeuronSubaccount**(`__namedParameters`): [`SubAccount`](../../ledger/icp/classes/SubAccount.md)

Defined in: [packages/canisters/src/nns/utils/neurons.utils.ts:101](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/utils/neurons.utils.ts#L101)

## Parameters

### \_\_namedParameters

#### controller

`Principal`

#### memo

`bigint`

## Returns

[`SubAccount`](../../ledger/icp/classes/SubAccount.md)
