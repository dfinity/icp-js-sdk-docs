---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:189](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L189)

## Enumeration Members

### Install

> **Install**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:191](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L191)

***

### Reinstall

> **Reinstall**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:192](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L192)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:190](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L190)

***

### Upgrade

> **Upgrade**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:193](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L193)
