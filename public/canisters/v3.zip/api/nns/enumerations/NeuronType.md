---
title: NeuronType
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:151](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L151)

## Enumeration Members

### Ect

> **Ect**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:160](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L160)

***

### Seed

> **Seed**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:157](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L157)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:154](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/nns/enums/governance.enums.ts#L154)
