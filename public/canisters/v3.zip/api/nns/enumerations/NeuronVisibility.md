---
title: NeuronVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:182](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/enums/governance.enums.ts#L182)

## Enumeration Members

### Private

> **Private**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:184](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/enums/governance.enums.ts#L184)

***

### Public

> **Public**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:185](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/enums/governance.enums.ts#L185)

***

### Unspecified

> **Unspecified**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:183](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/nns/enums/governance.enums.ts#L183)
