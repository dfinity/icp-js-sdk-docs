---
title: ProposalStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:62](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L62)

## Enumeration Members

### Accepted

> **Accepted**: `3`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:73](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L73)

***

### Executed

> **Executed**: `4`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:76](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L76)

***

### Failed

> **Failed**: `5`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:79](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L79)

***

### Open

> **Open**: `1`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:66](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L66)

***

### Rejected

> **Rejected**: `2`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:69](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L69)

***

### Unknown

> **Unknown**: `0`

Defined in: [packages/canisters/src/nns/enums/governance.enums.ts:63](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/nns/enums/governance.enums.ts#L63)
