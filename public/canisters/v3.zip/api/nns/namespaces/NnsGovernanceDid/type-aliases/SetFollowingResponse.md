---
title: SetFollowingResponse
editUrl: false
next: true
prev: true
---

> **SetFollowingResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1109](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1109)
