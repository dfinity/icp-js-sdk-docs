---
title: Result_5
editUrl: false
next: true
prev: true
---

> **Result\_5** = \{ `Ok`: [`NeuronInfo`](../interfaces/NeuronInfo.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1056](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1056)
