---
title: Result_6
editUrl: false
next: true
prev: true
---

> **Result\_6** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1057](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1057)
