---
title: Result_6
editUrl: false
next: true
prev: true
---

> **Result\_6** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1057](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1057)
