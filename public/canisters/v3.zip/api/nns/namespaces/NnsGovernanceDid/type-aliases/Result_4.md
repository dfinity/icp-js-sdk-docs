---
title: Result_4
editUrl: false
next: true
prev: true
---

> **Result\_4** = \{ `Ok`: [`MonthlyNodeProviderRewards`](../interfaces/MonthlyNodeProviderRewards.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1109](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1109)
