---
title: DissolveState
editUrl: false
next: true
prev: true
---

> **DissolveState** = \{ `DissolveDelaySeconds`: `bigint`; \} \| \{ `WhenDissolvedTimestampSeconds`: `bigint`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:235](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L235)
