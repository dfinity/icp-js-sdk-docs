---
title: RewardMode
editUrl: false
next: true
prev: true
---

> **RewardMode** = \{ `RewardToNeuron`: [`RewardToNeuron`](../interfaces/RewardToNeuron.md); \} \| \{ `RewardToAccount`: [`RewardToAccount`](../interfaces/RewardToAccount.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1070](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1070)
