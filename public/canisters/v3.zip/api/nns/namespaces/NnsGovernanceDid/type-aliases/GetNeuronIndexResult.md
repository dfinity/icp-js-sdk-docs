---
title: GetNeuronIndexResult
editUrl: false
next: true
prev: true
---

> **GetNeuronIndexResult** = \{ `Ok`: [`NeuronIndexData`](../interfaces/NeuronIndexData.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L268)
