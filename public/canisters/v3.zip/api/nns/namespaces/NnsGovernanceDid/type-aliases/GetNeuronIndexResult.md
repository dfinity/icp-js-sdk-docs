---
title: GetNeuronIndexResult
editUrl: false
next: true
prev: true
---

> **GetNeuronIndexResult** = \{ `Ok`: [`NeuronIndexData`](../interfaces/NeuronIndexData.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L297)
