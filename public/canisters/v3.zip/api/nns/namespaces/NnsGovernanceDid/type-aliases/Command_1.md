---
title: Command_1
editUrl: false
next: true
prev: true
---

> **Command\_1** = \{ `Error`: [`GovernanceError`](../interfaces/GovernanceError.md); \} \| \{ `Spawn`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `Split`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `Follow`: \{ \}; \} \| \{ `DisburseMaturity`: [`DisburseMaturityResponse`](../interfaces/DisburseMaturityResponse.md); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPowerResponse`](RefreshVotingPowerResponse.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefreshResponse`](../interfaces/ClaimOrRefreshResponse.md); \} \| \{ `Configure`: \{ \}; \} \| \{ `RegisterVote`: \{ \}; \} \| \{ `Merge`: [`MergeResponse`](../interfaces/MergeResponse.md); \} \| \{ `DisburseToNeuron`: [`SpawnResponse`](../interfaces/SpawnResponse.md); \} \| \{ `SetFollowing`: [`SetFollowingResponse`](SetFollowingResponse.md); \} \| \{ `MakeProposal`: [`MakeProposalResponse`](../interfaces/MakeProposalResponse.md); \} \| \{ `StakeMaturity`: [`StakeMaturityResponse`](../interfaces/StakeMaturityResponse.md); \} \| \{ `MergeMaturity`: [`MergeMaturityResponse`](../interfaces/MergeMaturityResponse.md); \} \| \{ `Disburse`: [`DisburseResponse`](../interfaces/DisburseResponse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L105)
