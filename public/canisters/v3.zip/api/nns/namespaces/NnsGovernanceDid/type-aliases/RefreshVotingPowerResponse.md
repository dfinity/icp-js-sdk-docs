---
title: RefreshVotingPowerResponse
editUrl: false
next: true
prev: true
---

> **RefreshVotingPowerResponse** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1028](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1028)
