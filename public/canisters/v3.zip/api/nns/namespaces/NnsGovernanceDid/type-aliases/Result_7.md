---
title: Result_7
editUrl: false
next: true
prev: true
---

> **Result\_7** = \{ `Ok`: [`NodeProvider`](../interfaces/NodeProvider.md); \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1114](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1114)
