---
title: Action
editUrl: false
next: true
prev: true
---

> **Action** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](../interfaces/KnownNeuron.md); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](../interfaces/FulfillSubnetRentalRequest.md); \} \| \{ `ManageNeuron`: [`ManageNeuronProposal`](../interfaces/ManageNeuronProposal.md); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](../interfaces/UpdateCanisterSettings.md); \} \| \{ `InstallCode`: [`InstallCode`](../interfaces/InstallCode.md); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](../interfaces/DeregisterKnownNeuron.md); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](../interfaces/StopOrStartCanister.md); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](../interfaces/CreateServiceNervousSystem.md); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](../interfaces/ExecuteNnsFunction.md); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](../interfaces/RewardNodeProvider.md); \} \| \{ `OpenSnsTokenSwap`: [`OpenSnsTokenSwap`](../interfaces/OpenSnsTokenSwap.md); \} \| \{ `SetSnsTokenSwapOpenTimeWindow`: [`SetSnsTokenSwapOpenTimeWindow`](../interfaces/SetSnsTokenSwapOpenTimeWindow.md); \} \| \{ `SetDefaultFollowees`: [`SetDefaultFollowees`](../interfaces/SetDefaultFollowees.md); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](../interfaces/RewardNodeProviders.md); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](../interfaces/NetworkEconomics.md); \} \| \{ `ApproveGenesisKyc`: [`Principals`](../interfaces/Principals.md); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](../interfaces/AddOrRemoveNodeProvider.md); \} \| \{ `Motion`: [`Motion`](../interfaces/Motion.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L20)
