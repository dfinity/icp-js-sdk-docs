---
title: ManageNeuronCommandRequest
editUrl: false
next: true
prev: true
---

> **ManageNeuronCommandRequest** = \{ `Spawn`: [`Spawn`](../interfaces/Spawn.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Follow`: [`Follow`](../interfaces/Follow.md); \} \| \{ `DisburseMaturity`: [`DisburseMaturity`](../interfaces/DisburseMaturity.md); \} \| \{ `RefreshVotingPower`: [`RefreshVotingPower`](RefreshVotingPower.md); \} \| \{ `ClaimOrRefresh`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `RegisterVote`: [`RegisterVote`](../interfaces/RegisterVote.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SetFollowing`: [`SetFollowing`](../interfaces/SetFollowing.md); \} \| \{ `MakeProposal`: [`MakeProposalRequest`](../interfaces/MakeProposalRequest.md); \} \| \{ `StakeMaturity`: [`StakeMaturity`](../interfaces/StakeMaturity.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:537](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L537)

KEEP THIS IN SYNC WITH COMMAND!
