---
title: ListNeuronVotesResponse
editUrl: false
next: true
prev: true
---

> **ListNeuronVotesResponse** = \{ `Ok`: \{ `all_finalized_before_proposal`: \[\] \| \[[`ProposalId`](../interfaces/ProposalId.md)\]; `votes`: \[\] \| \[[`NeuronVote`](../interfaces/NeuronVote.md)[]\]; \}; \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L443)
