---
title: ListNeuronVotesResponse
editUrl: false
next: true
prev: true
---

> **ListNeuronVotesResponse** = \{ `Ok`: \{ `all_finalized_before_proposal`: \[\] \| \[[`ProposalId`](../interfaces/ProposalId.md)\]; `votes`: \[\] \| \[[`NeuronVote`](../interfaces/NeuronVote.md)[]\]; \}; \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:492](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L492)
