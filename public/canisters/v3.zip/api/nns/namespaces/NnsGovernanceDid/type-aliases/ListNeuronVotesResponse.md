---
title: ListNeuronVotesResponse
editUrl: false
next: true
prev: true
---

> **ListNeuronVotesResponse** = \{ `Ok`: \{ `all_finalized_before_proposal`: \[\] \| \[[`ProposalId`](../interfaces/ProposalId.md)\]; `votes`: \[\] \| \[[`NeuronVote`](../interfaces/NeuronVote.md)[]\]; \}; \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:443](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L443)
