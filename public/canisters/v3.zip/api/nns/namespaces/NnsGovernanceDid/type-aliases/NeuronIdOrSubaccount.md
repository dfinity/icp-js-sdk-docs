---
title: NeuronIdOrSubaccount
editUrl: false
next: true
prev: true
---

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `Uint8Array`; \} \| \{ `NeuronId`: [`NeuronId`](../interfaces/NeuronId.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:768](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L768)
