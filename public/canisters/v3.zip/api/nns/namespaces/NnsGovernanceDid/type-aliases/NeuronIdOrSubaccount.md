---
title: NeuronIdOrSubaccount
editUrl: false
next: true
prev: true
---

> **NeuronIdOrSubaccount** = \{ `Subaccount`: `Uint8Array`; \} \| \{ `NeuronId`: [`NeuronId`](../interfaces/NeuronId.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:821](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L821)
