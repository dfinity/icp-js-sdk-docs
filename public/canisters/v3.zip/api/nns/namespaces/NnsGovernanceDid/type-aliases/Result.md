---
title: Result
editUrl: false
next: true
prev: true
---

> **Result** = \{ `Ok`: `null`; \} \| \{ `Err`: [`GovernanceError`](../interfaces/GovernanceError.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1102](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1102)
