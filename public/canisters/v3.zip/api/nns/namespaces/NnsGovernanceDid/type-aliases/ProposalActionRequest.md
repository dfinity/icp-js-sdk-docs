---
title: ProposalActionRequest
editUrl: false
next: true
prev: true
---

> **ProposalActionRequest** = \{ `RegisterKnownNeuron`: [`KnownNeuron`](../interfaces/KnownNeuron.md); \} \| \{ `FulfillSubnetRentalRequest`: [`FulfillSubnetRentalRequest`](../interfaces/FulfillSubnetRentalRequest.md); \} \| \{ `ManageNeuron`: [`ManageNeuronRequest`](../interfaces/ManageNeuronRequest.md); \} \| \{ `UpdateCanisterSettings`: [`UpdateCanisterSettings`](../interfaces/UpdateCanisterSettings.md); \} \| \{ `InstallCode`: [`InstallCodeRequest`](../interfaces/InstallCodeRequest.md); \} \| \{ `DeregisterKnownNeuron`: [`DeregisterKnownNeuron`](../interfaces/DeregisterKnownNeuron.md); \} \| \{ `StopOrStartCanister`: [`StopOrStartCanister`](../interfaces/StopOrStartCanister.md); \} \| \{ `CreateServiceNervousSystem`: [`CreateServiceNervousSystem`](../interfaces/CreateServiceNervousSystem.md); \} \| \{ `ExecuteNnsFunction`: [`ExecuteNnsFunction`](../interfaces/ExecuteNnsFunction.md); \} \| \{ `RewardNodeProvider`: [`RewardNodeProvider`](../interfaces/RewardNodeProvider.md); \} \| \{ `RewardNodeProviders`: [`RewardNodeProviders`](../interfaces/RewardNodeProviders.md); \} \| \{ `ManageNetworkEconomics`: [`NetworkEconomics`](../interfaces/NetworkEconomics.md); \} \| \{ `ApproveGenesisKyc`: [`Principals`](../interfaces/Principals.md); \} \| \{ `AddOrRemoveNodeProvider`: [`AddOrRemoveNodeProvider`](../interfaces/AddOrRemoveNodeProvider.md); \} \| \{ `Motion`: [`Motion`](../interfaces/Motion.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:962](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L962)
