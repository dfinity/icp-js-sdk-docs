---
title: Result_8
editUrl: false
next: true
prev: true
---

> **Result\_8** = \{ `Committed`: [`Committed`](../interfaces/Committed.md); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1115](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1115)
