---
title: SelfDescribingValue
editUrl: false
next: true
prev: true
---

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `SelfDescribingValue`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `SelfDescribingValue`[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1093](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1093)
