---
title: SelfDescribingValue
editUrl: false
next: true
prev: true
---

> **SelfDescribingValue** = \{ `Int`: `bigint`; \} \| \{ `Map`: \[`string`, `SelfDescribingValue`\][]; \} \| \{ `Nat`: `bigint`; \} \| \{ `Blob`: `Uint8Array`; \} \| \{ `Bool`: `boolean`; \} \| \{ `Null`: `null`; \} \| \{ `Text`: `string`; \} \| \{ `Array`: `SelfDescribingValue`[]; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1149](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1149)
