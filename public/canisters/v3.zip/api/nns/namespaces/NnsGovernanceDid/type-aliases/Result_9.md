---
title: Result_9
editUrl: false
next: true
prev: true
---

> **Result\_9** = \{ `Committed`: [`Committed_1`](../interfaces/Committed_1.md); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1060](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1060)
