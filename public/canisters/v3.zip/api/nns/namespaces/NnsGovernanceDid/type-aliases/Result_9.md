---
title: Result_9
editUrl: false
next: true
prev: true
---

> **Result\_9** = \{ `Committed`: [`Committed_1`](../interfaces/Committed_1.md); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1060](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1060)
