---
title: Result_9
editUrl: false
next: true
prev: true
---

> **Result\_9** = \{ `Committed`: [`Committed_1`](../interfaces/Committed_1.md); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1116](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1116)
