---
title: Result_9
editUrl: false
next: true
prev: true
---

> **Result\_9** = \{ `Committed`: [`Committed_1`](../interfaces/Committed_1.md); \} \| \{ `Aborted`: \{ \}; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1116](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1116)
