---
title: RefreshVotingPower
editUrl: false
next: true
prev: true
---

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1083](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1083)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.
