---
title: RefreshVotingPower
editUrl: false
next: true
prev: true
---

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1027](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1027)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.
