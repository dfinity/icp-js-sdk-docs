---
title: RefreshVotingPower
editUrl: false
next: true
prev: true
---

> **RefreshVotingPower** = `object`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1027](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1027)

This is one way for a neuron to make sure that its deciding_voting_power is
not less than its potential_voting_power. See the description of those fields
in Neuron.
