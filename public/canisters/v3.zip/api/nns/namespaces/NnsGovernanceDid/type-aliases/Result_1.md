---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Error`: [`GovernanceError`](../interfaces/GovernanceError.md); \} \| \{ `NeuronId`: [`NeuronId`](../interfaces/NeuronId.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1047](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1047)
