---
title: Vote
editUrl: false
next: true
prev: true
---

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1236](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1236)

## Type Declaration

\{ `No`: `null`; \}

### No

> **No**: `null`

\{ `Yes`: `null`; \}

### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.
