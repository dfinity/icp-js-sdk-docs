---
title: Vote
editUrl: false
next: true
prev: true
---

> **Vote** = \{ `No`: `null`; \} \| \{ `Yes`: `null`; \} \| \{ `Unspecified`: `null`; \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1298](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1298)

## Type Declaration

\{ `No`: `null`; \}

### No

> **No**: `null`

\{ `Yes`: `null`; \}

### Yes

> **Yes**: `null`

\{ `Unspecified`: `null`; \}

### Unspecified

> **Unspecified**: `null`

Abstentions are recorded as Unspecified.
