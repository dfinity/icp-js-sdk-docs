---
title: Command_2
editUrl: false
next: true
prev: true
---

> **Command\_2** = \{ `Spawn`: [`NeuronId`](../interfaces/NeuronId.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L122)
