---
title: Command_2
editUrl: false
next: true
prev: true
---

> **Command\_2** = \{ `Spawn`: [`NeuronId`](../interfaces/NeuronId.md); \} \| \{ `Split`: [`Split`](../interfaces/Split.md); \} \| \{ `Configure`: [`Configure`](../interfaces/Configure.md); \} \| \{ `Merge`: [`Merge`](../interfaces/Merge.md); \} \| \{ `DisburseToNeuron`: [`DisburseToNeuron`](../interfaces/DisburseToNeuron.md); \} \| \{ `SyncCommand`: \{ \}; \} \| \{ `ClaimOrRefreshNeuron`: [`ClaimOrRefresh`](../interfaces/ClaimOrRefresh.md); \} \| \{ `MergeMaturity`: [`MergeMaturity`](../interfaces/MergeMaturity.md); \} \| \{ `Disburse`: [`Disburse`](../interfaces/Disburse.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L148)
