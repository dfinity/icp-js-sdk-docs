---
title: Change
editUrl: false
next: true
prev: true
---

> **Change** = \{ `ToRemove`: [`NodeProvider`](../interfaces/NodeProvider.md); \} \| \{ `ToAdd`: [`NodeProvider`](../interfaces/NodeProvider.md); \}

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:114](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L114)
