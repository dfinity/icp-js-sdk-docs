---
title: Disburse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:184](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L184)

## Properties

### amount

> **amount**: \[\] \| \[[`Amount`](Amount.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:186](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L186)

***

### to\_account

> **to\_account**: \[\] \| \[[`AccountIdentifier`](AccountIdentifier.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:185](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L185)
