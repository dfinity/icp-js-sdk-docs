---
title: NetworkEconomics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:646](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L646)

## Properties

### max\_proposals\_to\_keep\_per\_topic

> **max\_proposals\_to\_keep\_per\_topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:652](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L652)

***

### maximum\_node\_provider\_rewards\_e8s

> **maximum\_node\_provider\_rewards\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:658](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L658)

***

### minimum\_icp\_xdr\_rate

> **minimum\_icp\_xdr\_rate**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:657](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L657)

***

### neuron\_management\_fee\_per\_proposal\_e8s

> **neuron\_management\_fee\_per\_proposal\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:653](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L653)

***

### neuron\_minimum\_stake\_e8s

> **neuron\_minimum\_stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:647](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L647)

***

### neuron\_spawn\_dissolve\_delay\_seconds

> **neuron\_spawn\_dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:656](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L656)

***

### neurons\_fund\_economics

> **neurons\_fund\_economics**: \[\] \| \[[`NeuronsFundEconomics`](NeuronsFundEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L659)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L654)

***

### transaction\_fee\_e8s

> **transaction\_fee\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:655](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L655)

***

### voting\_power\_economics

> **voting\_power\_economics**: \[\] \| \[[`VotingPowerEconomics`](VotingPowerEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:651](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L651)

Parameters that affect the voting power of neurons.
