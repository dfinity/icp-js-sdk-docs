---
title: ClaimOrRefreshNeuronFromAccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:121](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L121)

## Properties

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:122](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L122)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:123](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L123)
