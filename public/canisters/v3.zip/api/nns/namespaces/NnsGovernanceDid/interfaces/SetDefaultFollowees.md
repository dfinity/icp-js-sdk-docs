---
title: SetDefaultFollowees
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1100](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1100)

## Properties

### default\_followees

> **default\_followees**: \[`number`, [`Followees`](Followees.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1101](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1101)
