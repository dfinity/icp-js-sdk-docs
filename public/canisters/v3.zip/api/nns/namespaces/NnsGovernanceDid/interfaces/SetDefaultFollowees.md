---
title: SetDefaultFollowees
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1158](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1158)

## Properties

### default\_followees

> **default\_followees**: \[`number`, [`Followees`](Followees.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1159](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1159)
