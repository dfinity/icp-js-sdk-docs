---
title: RewardNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1073](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1073)

## Properties

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1076](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1076)

***

### node\_provider

> **node\_provider**: \[\] \| \[[`NodeProvider`](NodeProvider.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1074](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1074)

***

### reward\_mode

> **reward\_mode**: \[\] \| \[[`RewardMode`](../type-aliases/RewardMode.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1075](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1075)
