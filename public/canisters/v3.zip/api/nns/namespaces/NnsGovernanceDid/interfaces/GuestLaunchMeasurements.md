---
title: GuestLaunchMeasurements
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:416](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L416)

## Properties

### guest\_launch\_measurements

> **guest\_launch\_measurements**: \[\] \| \[[`GuestLaunchMeasurement`](GuestLaunchMeasurement.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:417](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L417)
