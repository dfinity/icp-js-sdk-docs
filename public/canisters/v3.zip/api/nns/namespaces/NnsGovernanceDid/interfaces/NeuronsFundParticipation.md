---
title: NeuronsFundParticipation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:946](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L946)

## Properties

### allocated\_neurons\_fund\_participation\_icp\_e8s

> **allocated\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:956](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L956)

***

### direct\_participation\_icp\_e8s

> **direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:949](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L949)

***

### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](IdealMatchedParticipationFunction.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:953](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L953)

***

### intended\_neurons\_fund\_participation\_icp\_e8s

> **intended\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:948](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L948)

***

### max\_neurons\_fund\_swap\_participation\_icp\_e8s

> **max\_neurons\_fund\_swap\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:951](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L951)

***

### neurons\_fund\_reserves

> **neurons\_fund\_reserves**: \[\] \| \[[`NeuronsFundSnapshot`](NeuronsFundSnapshot.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:952](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L952)

***

### swap\_participation\_limits

> **swap\_participation\_limits**: \[\] \| \[[`SwapParticipationLimits`](SwapParticipationLimits.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:950](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L950)

***

### total\_maturity\_equivalent\_icp\_e8s

> **total\_maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:947](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L947)
