---
title: Configure
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:142](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L142)

## Properties

### operation

> **operation**: \[\] \| \[[`Operation`](../type-aliases/Operation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:143](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L143)
