---
title: ProposalInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1002](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1002)

## Properties

### ballots

> **ballots**: \[`bigint`, [`Ballot`](Ballot.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1007](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1007)

***

### deadline\_timestamp\_seconds

> **deadline\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1010](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1010)

***

### decided\_timestamp\_seconds

> **decided\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1017](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1017)

***

### derived\_proposal\_information

> **derived\_proposal\_information**: \[\] \| \[[`DerivedProposalInformation`](DerivedProposalInformation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1013](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1013)

***

### executed\_timestamp\_seconds

> **executed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1020](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1020)

***

### failed\_timestamp\_seconds

> **failed\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1011](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1011)

***

### failure\_reason

> **failure\_reason**: \[\] \| \[[`GovernanceError`](GovernanceError.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1006](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1006)

***

### id

> **id**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1003](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1003)

***

### latest\_tally

> **latest\_tally**: \[\] \| \[[`Tally`](Tally.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1014](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1014)

***

### proposal

> **proposal**: \[\] \| \[[`Proposal`](Proposal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1018](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1018)

***

### proposal\_timestamp\_seconds

> **proposal\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1008](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1008)

***

### proposer

> **proposer**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1019](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1019)

***

### reject\_cost\_e8s

> **reject\_cost\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1012](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1012)

***

### reward\_event\_round

> **reward\_event\_round**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1009](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1009)

***

### reward\_status

> **reward\_status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1016](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1016)

***

### status

> **status**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1004](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1004)

***

### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1005](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1005)

***

### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1015](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1015)
