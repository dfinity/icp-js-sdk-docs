---
title: ListNodeProvidersResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:508](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L508)

## Properties

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:509](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L509)
