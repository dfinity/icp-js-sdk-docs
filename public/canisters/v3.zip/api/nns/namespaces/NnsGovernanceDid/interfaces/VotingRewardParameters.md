---
title: VotingRewardParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1344](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1344)

## Properties

### final\_reward\_rate

> **final\_reward\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1347](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1347)

***

### initial\_reward\_rate

> **initial\_reward\_rate**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1346](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1346)

***

### reward\_rate\_transition\_duration

> **reward\_rate\_transition\_duration**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1345](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1345)
