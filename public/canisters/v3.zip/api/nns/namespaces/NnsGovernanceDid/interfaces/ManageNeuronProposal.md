---
title: ManageNeuronProposal
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:610](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L610)

Not to be confused with ManageNeuronRequest. This is only used to represent a manage neuron proposal.
(Yes, this is very structurally similar to that, but not actually exactly equivalent)

## Properties

### command

> **command**: \[\] \| \[[`ManageNeuronProposalCommand`](../type-aliases/ManageNeuronProposalCommand.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:612](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L612)

***

### id

> **id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:611](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L611)

***

### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:613](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L613)
