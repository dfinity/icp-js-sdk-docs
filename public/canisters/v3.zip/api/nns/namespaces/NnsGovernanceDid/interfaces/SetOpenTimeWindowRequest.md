---
title: SetOpenTimeWindowRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1110](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1110)

## Properties

### open\_time\_window

> **open\_time\_window**: \[\] \| \[[`TimeWindow`](TimeWindow.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1111](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1111)
