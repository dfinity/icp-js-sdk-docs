---
title: SwapParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1225](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1225)

## Properties

### confirmation\_text

> **confirmation\_text**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1232](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1232)

***

### duration

> **duration**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1228](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1228)

***

### maximum\_direct\_participation\_icp

> **maximum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1238](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1238)

***

### maximum\_icp

> **maximum\_icp**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1239](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1239)

***

### maximum\_participant\_icp

> **maximum\_participant\_icp**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1233](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1233)

***

### minimum\_direct\_participation\_icp

> **minimum\_direct\_participation\_icp**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1235](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1235)

***

### minimum\_icp

> **minimum\_icp**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1234](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1234)

***

### minimum\_participant\_icp

> **minimum\_participant\_icp**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1236](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1236)

***

### minimum\_participants

> **minimum\_participants**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1226](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1226)

***

### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters`](NeuronBasketConstructionParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1229](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1229)

***

### neurons\_fund\_investment\_icp

> **neurons\_fund\_investment\_icp**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1240](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1240)

***

### neurons\_fund\_participation

> **neurons\_fund\_participation**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1227](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1227)

***

### restricted\_countries

> **restricted\_countries**: \[\] \| \[[`Countries`](Countries.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1241](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1241)

***

### start\_time

> **start\_time**: \[\] \| \[[`GlobalTimeOfDay`](GlobalTimeOfDay.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1237](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1237)
