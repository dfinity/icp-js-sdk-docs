---
title: Principals
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1005](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1005)

## Properties

### principals

> **principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1006](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1006)
