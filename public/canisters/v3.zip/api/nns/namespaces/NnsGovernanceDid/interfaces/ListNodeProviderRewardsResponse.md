---
title: ListNodeProviderRewardsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L505)

## Properties

### rewards

> **rewards**: [`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L506)
