---
title: ListNodeProviderRewardsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:505](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L505)

## Properties

### rewards

> **rewards**: [`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:506](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L506)
