---
title: GovernanceCachedMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L304)

## Properties

### community\_fund\_total\_maturity\_e8s\_equivalent

> **community\_fund\_total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:318](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L318)

***

### community\_fund\_total\_staked\_e8s

> **community\_fund\_total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L348)

***

### declining\_voting\_power\_neuron\_subset\_metrics

> **declining\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:330](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L330)

***

### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:317](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L317)

***

### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L333)

***

### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L345)

***

### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:340](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L340)

***

### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L346)

***

### dissolving\_neurons\_e8s\_buckets\_ect

> **dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L341)

***

### dissolving\_neurons\_e8s\_buckets\_seed

> **dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L335)

***

### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L309)

***

### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:307](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L307)

***

### ect\_neuron\_count

> **ect\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:314](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L314)

***

### fully\_lost\_voting\_power\_neuron\_subset\_metrics

> **fully\_lost\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:322](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L322)

***

### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L308)

***

### neurons\_fund\_total\_active\_neurons

> **neurons\_fund\_total\_active\_neurons**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:325](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L325)

***

### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:312](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L312)

***

### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:316](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L316)

***

### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L336)

***

### non\_self\_authenticating\_controller\_neuron\_subset\_metrics

> **non\_self\_authenticating\_controller\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L342)

***

### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:323](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L323)

***

### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:313](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L313)

***

### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:306](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L306)

***

### not\_dissolving\_neurons\_e8s\_buckets\_ect

> **not\_dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:328](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L328)

***

### not\_dissolving\_neurons\_e8s\_buckets\_seed

> **not\_dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L349)

***

### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L337)

***

### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:332](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L332)

***

### public\_neuron\_subset\_metrics

> **public\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L350)

***

### seed\_neuron\_count

> **seed\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L352)

***

### spawning\_neurons\_count

> **spawning\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:329](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L329)

***

### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L351)

***

### total\_locked\_e8s

> **total\_locked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:324](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L324)

***

### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L305)

***

### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:321](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L321)

***

### total\_staked\_e8s\_ect

> **total\_staked\_e8s\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:331](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L331)

***

### total\_staked\_e8s\_non\_self\_authenticating\_controller

> **total\_staked\_e8s\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L334)

***

### total\_staked\_e8s\_seed

> **total\_staked\_e8s\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:319](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L319)

***

### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:327](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L327)

***

### total\_staked\_maturity\_e8s\_equivalent\_ect

> **total\_staked\_maturity\_e8s\_equivalent\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:320](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L320)

***

### total\_staked\_maturity\_e8s\_equivalent\_seed

> **total\_staked\_maturity\_e8s\_equivalent\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L347)

***

### total\_supply\_icp

> **total\_supply\_icp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:315](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L315)

***

### total\_voting\_power\_non\_self\_authenticating\_controller

> **total\_voting\_power\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:326](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L326)
