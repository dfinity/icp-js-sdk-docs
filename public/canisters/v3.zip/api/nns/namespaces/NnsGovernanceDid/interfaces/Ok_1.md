---
title: Ok_1
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L915)

## Properties

### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuron`](NeuronsFundNeuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L916)
