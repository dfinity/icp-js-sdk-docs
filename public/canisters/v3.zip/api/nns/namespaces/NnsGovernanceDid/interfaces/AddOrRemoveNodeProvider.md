---
title: AddOrRemoveNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L45)

## Properties

### change

> **change**: \[\] \| \[[`Change`](../type-aliases/Change.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L46)
