---
title: AddOrRemoveNodeProvider
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L42)

## Properties

### change

> **change**: \[\] \| \[[`Change`](../type-aliases/Change.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L43)
