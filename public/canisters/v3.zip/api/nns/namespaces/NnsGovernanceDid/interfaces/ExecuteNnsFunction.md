---
title: ExecuteNnsFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:212](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L212)

## Properties

### nns\_function

> **nns\_function**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:213](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L213)

***

### payload

> **payload**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:214](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L214)
