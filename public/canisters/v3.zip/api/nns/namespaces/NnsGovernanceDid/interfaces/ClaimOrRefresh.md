---
title: ClaimOrRefresh
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L92)

## Properties

### by

> **by**: \[\] \| \[[`By`](../type-aliases/By.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L93)
