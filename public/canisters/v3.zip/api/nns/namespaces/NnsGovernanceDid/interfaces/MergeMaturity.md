---
title: MergeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:618](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L618)

## Properties

### percentage\_to\_merge

> **percentage\_to\_merge**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:619](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L619)
