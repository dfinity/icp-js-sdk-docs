---
title: Ok
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:965](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L965)

## Properties

### neurons\_fund\_audit\_info

> **neurons\_fund\_audit\_info**: \[\] \| \[[`NeuronsFundAuditInfo`](NeuronsFundAuditInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:966](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L966)
