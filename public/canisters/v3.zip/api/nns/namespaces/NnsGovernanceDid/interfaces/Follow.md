---
title: Follow
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:245](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L245)

## Properties

### followees

> **followees**: [`NeuronId`](NeuronId.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:247](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L247)

***

### topic

> **topic**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:246](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L246)
