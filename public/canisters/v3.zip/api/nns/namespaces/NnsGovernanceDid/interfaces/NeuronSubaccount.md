---
title: NeuronSubaccount
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:829](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L829)

## Properties

### subaccount

> **subaccount**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:830](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L830)
