---
title: ListNeuronsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:535](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L535)

Output of the list_neurons method.

## Properties

### full\_neurons

> **full\_neurons**: [`Neuron`](Neuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:548](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L548)

If the caller has the necessary special privileges (or the neuron is
public, and the request sets include_public_neurons_in_full_neurons to
true), then all the information about the neurons in the result set is made
available here.

***

### neuron\_infos

> **neuron\_infos**: \[`bigint`, [`NeuronInfo`](NeuronInfo.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:541](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L541)

Per the NeuronInfo type, this is a redacted view of the neurons in the
result set consisting of information that require no special privileges to
view.

***

### total\_pages\_available

> **total\_pages\_available**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:549](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L549)
