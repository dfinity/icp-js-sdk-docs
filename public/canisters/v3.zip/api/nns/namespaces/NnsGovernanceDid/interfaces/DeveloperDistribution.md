---
title: DeveloperDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:181](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L181)

## Properties

### developer\_neurons

> **developer\_neurons**: [`NeuronDistribution`](NeuronDistribution.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:182](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L182)
