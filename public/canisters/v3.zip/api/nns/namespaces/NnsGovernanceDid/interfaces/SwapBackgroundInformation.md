---
title: SwapBackgroundInformation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1212](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1212)

## Properties

### dapp\_canister\_summaries

> **dapp\_canister\_summaries**: [`CanisterSummary`](CanisterSummary.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1220](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1220)

***

### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1214](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1214)

***

### governance\_canister\_summary

> **governance\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1218](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1218)

***

### ledger\_archive\_canister\_summaries

> **ledger\_archive\_canister\_summaries**: [`CanisterSummary`](CanisterSummary.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1215](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1215)

***

### ledger\_canister\_summary

> **ledger\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1216](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1216)

***

### ledger\_index\_canister\_summary

> **ledger\_index\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1213](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1213)

***

### root\_canister\_summary

> **root\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1219](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1219)

***

### swap\_canister\_summary

> **swap\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1217](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1217)
