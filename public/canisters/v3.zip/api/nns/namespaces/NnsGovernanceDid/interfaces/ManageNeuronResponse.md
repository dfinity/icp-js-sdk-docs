---
title: ManageNeuronResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:654](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L654)

Output of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`Command_1`](../type-aliases/Command_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:659](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L659)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.
