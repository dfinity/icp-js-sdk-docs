---
title: ManageNeuronResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:601](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L601)

Output of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`Command_1`](../type-aliases/Command_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:606](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L606)

Corresponds to the command field in ManageNeuronRequest, which determines
what operation was performed.
