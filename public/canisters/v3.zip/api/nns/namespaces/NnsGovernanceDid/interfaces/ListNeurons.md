---
title: ListNeurons
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:512](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L512)

Parameters of the list_neurons method.

## Properties

### include\_empty\_neurons\_readable\_by\_caller

> **include\_empty\_neurons\_readable\_by\_caller**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:528](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L528)

Only has an effect when include_neurons_readable_by_caller.

***

### include\_neurons\_readable\_by\_caller

> **include\_neurons\_readable\_by\_caller**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L530)

***

### include\_public\_neurons\_in\_full\_neurons

> **include\_public\_neurons\_in\_full\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:519](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L519)

When a public neuron is a member of the result set, include it in the
full_neurons field (of ListNeuronsResponse). This does not affect which
neurons are part of the result set.

***

### neuron\_ids

> **neuron\_ids**: `BigUint64Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:523](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L523)

These fields select neurons to be in the result set.

***

### neuron\_subaccounts

> **neuron\_subaccounts**: \[\] \| \[[`NeuronSubaccount`](NeuronSubaccount.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:529](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L529)

***

### page\_number

> **page\_number**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:524](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L524)

***

### page\_size

> **page\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:513](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L513)
