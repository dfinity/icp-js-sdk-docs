---
title: GovernanceError
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:383](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L383)

## Properties

### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:384](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L384)

***

### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:385](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L385)
