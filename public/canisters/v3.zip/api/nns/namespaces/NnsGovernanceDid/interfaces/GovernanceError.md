---
title: GovernanceError
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L354)

## Properties

### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L355)

***

### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L356)
