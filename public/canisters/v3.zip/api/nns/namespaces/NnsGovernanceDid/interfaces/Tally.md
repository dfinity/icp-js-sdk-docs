---
title: Tally
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1191](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1191)

## Properties

### no

> **no**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1192](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1192)

***

### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1195](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1195)

***

### total

> **total**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1194](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1194)

***

### yes

> **yes**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1193](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1193)
