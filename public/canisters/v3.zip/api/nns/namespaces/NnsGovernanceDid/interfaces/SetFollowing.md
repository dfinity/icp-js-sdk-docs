---
title: SetFollowing
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1106](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1106)

## Properties

### topic\_following

> **topic\_following**: \[\] \| \[[`FolloweesForTopic`](FolloweesForTopic.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1107](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1107)
