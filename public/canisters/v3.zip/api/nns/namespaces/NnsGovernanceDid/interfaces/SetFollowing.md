---
title: SetFollowing
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1106](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1106)

## Properties

### topic\_following

> **topic\_following**: \[\] \| \[[`FolloweesForTopic`](FolloweesForTopic.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1107](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1107)
