---
title: Governance
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L283)

## Properties

### cached\_daily\_maturity\_modulation\_basis\_points

> **cached\_daily\_maturity\_modulation\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L291)

***

### default\_followees

> **default\_followees**: \[`number`, [`Followees`](Followees.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L284)

***

### economics

> **economics**: \[\] \| \[[`NetworkEconomics`](NetworkEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L292)

***

### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:302](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L302)

***

### in\_flight\_commands

> **in\_flight\_commands**: \[`bigint`, [`NeuronInFlightCommand`](NeuronInFlightCommand.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L300)

***

### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](RewardEvent.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L295)

***

### maturity\_modulation\_last\_updated\_at\_timestamp\_seconds

> **maturity\_modulation\_last\_updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L286)

***

### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](GovernanceCachedMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L288)

***

### most\_recent\_monthly\_node\_provider\_rewards

> **most\_recent\_monthly\_node\_provider\_rewards**: \[\] \| \[[`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L285)

***

### neuron\_management\_voting\_period\_seconds

> **neuron\_management\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L289)

***

### neurons

> **neurons**: \[`bigint`, [`Neuron`](Neuron.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L301)

***

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L290)

***

### proposals

> **proposals**: \[`bigint`, [`ProposalData`](ProposalData.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L298)

***

### restore\_aging\_summary

> **restore\_aging\_summary**: \[\] \| \[[`RestoreAgingSummary`](RestoreAgingSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L293)

***

### short\_voting\_period\_seconds

> **short\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L297)

***

### spawning\_neurons

> **spawning\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L294)

***

### to\_claim\_transfers

> **to\_claim\_transfers**: [`NeuronStakeTransfer`](NeuronStakeTransfer.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L296)

***

### wait\_for\_quiet\_threshold\_seconds

> **wait\_for\_quiet\_threshold\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L287)

***

### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](XdrConversionRate.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L299)
