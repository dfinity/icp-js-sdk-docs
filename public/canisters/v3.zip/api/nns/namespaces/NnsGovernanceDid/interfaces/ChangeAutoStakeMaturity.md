---
title: ChangeAutoStakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L89)

## Properties

### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L90)
