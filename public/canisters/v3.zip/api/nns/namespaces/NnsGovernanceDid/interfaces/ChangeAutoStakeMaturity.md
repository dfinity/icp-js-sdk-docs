---
title: ChangeAutoStakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:115](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L115)

## Properties

### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:116](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L116)
