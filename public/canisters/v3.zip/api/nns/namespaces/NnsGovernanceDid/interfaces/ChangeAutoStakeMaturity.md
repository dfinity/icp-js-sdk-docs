---
title: ChangeAutoStakeMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:89](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L89)

## Properties

### requested\_setting\_for\_auto\_stake\_maturity

> **requested\_setting\_for\_auto\_stake\_maturity**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L90)
