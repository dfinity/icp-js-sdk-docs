---
title: KnownNeuronData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:402](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L402)

## Properties

### committed\_topics

> **committed\_topics**: \[\] \| \[(\[\] \| \[[`TopicToFollow`](../type-aliases/TopicToFollow.md)\])[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L410)

Topics that the known neuron is committed to always vote on.
Note regarding the type: the first `opt` makes it so that the field can be renamed/deprecated
in the future, and the second `opt` makes it so that an older client not recognizing a new
variant can still get the rest of the `vec`.

***

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:411](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L411)

***

### links

> **links**: \[\] \| \[`string`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:415](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L415)

Links related to the known neuron. Can be links to social URLs (OpenChat, X, etc.), or a homepage.

***

### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:403](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L403)
