---
title: KnownNeuronData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L451)

## Properties

### committed\_topics

> **committed\_topics**: \[\] \| \[(\[\] \| \[[`TopicToFollow`](../type-aliases/TopicToFollow.md)\])[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:459](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L459)

Topics that the known neuron is committed to always vote on.
Note regarding the type: the first `opt` makes it so that the field can be renamed/deprecated
in the future, and the second `opt` makes it so that an older client not recognizing a new
variant can still get the rest of the `vec`.

***

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:460](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L460)

***

### links

> **links**: \[\] \| \[`string`[]\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:464](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L464)

Links related to the known neuron. Can be links to social URLs (OpenChat, X, etc.), or a homepage.

***

### name

> **name**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L452)
