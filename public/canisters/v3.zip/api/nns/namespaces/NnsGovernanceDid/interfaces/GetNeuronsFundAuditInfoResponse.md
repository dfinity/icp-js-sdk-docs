---
title: GetNeuronsFundAuditInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L274)

## Properties

### result

> **result**: \[\] \| \[[`Result_6`](../type-aliases/Result_6.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L275)
