---
title: GetNeuronsFundAuditInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L303)

## Properties

### result

> **result**: \[\] \| \[[`Result_6`](../type-aliases/Result_6.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:304](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L304)
