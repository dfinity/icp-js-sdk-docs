---
title: GuestLaunchMeasurementMetadata
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:410](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L410)

## Properties

### kernel\_cmdline

> **kernel\_cmdline**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:414](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L414)

Kernel command line used for this measurement.
