---
title: NeuronIndexData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L775)

## Properties

### neurons

> **neurons**: [`NeuronInfo`](NeuronInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L776)
