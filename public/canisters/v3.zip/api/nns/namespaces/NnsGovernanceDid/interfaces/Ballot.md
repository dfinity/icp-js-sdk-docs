---
title: Ballot
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:51](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L51)

## Properties

### vote

> **vote**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L52)

***

### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L53)
