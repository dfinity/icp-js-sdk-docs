---
title: NeuronSubsetMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:832](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L832)

## Properties

### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:837](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L837)

***

### count\_buckets

> **count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:846](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L846)

***

### deciding\_voting\_power\_buckets

> **deciding\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:838](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L838)

***

### maturity\_e8s\_equivalent\_buckets

> **maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:834](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L834)

***

### potential\_voting\_power\_buckets

> **potential\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:845](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L845)

***

### staked\_e8s\_buckets

> **staked\_e8s\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:843](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L843)

***

### staked\_maturity\_e8s\_equivalent\_buckets

> **staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:842](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L842)

***

### total\_deciding\_voting\_power

> **total\_deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:841](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L841)

***

### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:833](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L833)

***

### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:840](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L840)

***

### total\_staked\_e8s

> **total\_staked\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:836](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L836)

***

### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:839](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L839)

***

### total\_voting\_power

> **total\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:844](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L844)

***

### voting\_power\_buckets

> **voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:835](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L835)
