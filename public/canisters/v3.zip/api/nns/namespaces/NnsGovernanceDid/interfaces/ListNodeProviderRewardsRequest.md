---
title: ListNodeProviderRewardsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L502)

## Properties

### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](DateRangeFilter.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L503)
