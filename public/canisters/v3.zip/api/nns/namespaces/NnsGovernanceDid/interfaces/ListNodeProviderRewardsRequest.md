---
title: ListNodeProviderRewardsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:502](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L502)

## Properties

### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](DateRangeFilter.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:503](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L503)
