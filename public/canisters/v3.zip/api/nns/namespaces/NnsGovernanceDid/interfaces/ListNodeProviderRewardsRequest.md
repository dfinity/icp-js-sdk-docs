---
title: ListNodeProviderRewardsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:551](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L551)

## Properties

### date\_filter

> **date\_filter**: \[\] \| \[[`DateRangeFilter`](DateRangeFilter.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:552](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L552)
