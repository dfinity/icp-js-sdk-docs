---
title: NeuronsFundSnapshot
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:905](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L905)

## Properties

### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuronPortion`](NeuronsFundNeuronPortion.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:906](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L906)
