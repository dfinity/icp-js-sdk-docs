---
title: NeuronsFundSnapshot
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:958](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L958)

## Properties

### neurons\_fund\_neuron\_portions

> **neurons\_fund\_neuron\_portions**: [`NeuronsFundNeuronPortion`](NeuronsFundNeuronPortion.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:959](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L959)
