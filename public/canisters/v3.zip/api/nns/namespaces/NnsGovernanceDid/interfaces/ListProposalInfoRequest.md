---
title: ListProposalInfoRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:560](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L560)

## Properties

### before\_proposal

> **before\_proposal**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:564](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L564)

***

### exclude\_topic

> **exclude\_topic**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:566](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L566)

***

### include\_all\_manage\_neuron\_proposals

> **include\_all\_manage\_neuron\_proposals**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:567](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L567)

***

### include\_reward\_status

> **include\_reward\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:562](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L562)

***

### include\_status

> **include\_status**: `Int32Array`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:568](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L568)

***

### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:565](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L565)

***

### omit\_large\_fields

> **omit\_large\_fields**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:563](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L563)

***

### return\_self\_describing\_action

> **return\_self\_describing\_action**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:561](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L561)
