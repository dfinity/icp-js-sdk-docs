---
title: RewardEvent
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1061](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1061)

## Properties

### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1064](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1064)

***

### day\_after\_genesis

> **day\_after\_genesis**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1063](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1063)

***

### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1067](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1067)

***

### latest\_round\_available\_e8s\_equivalent

> **latest\_round\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1066](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1066)

***

### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1062](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1062)

***

### settled\_proposals

> **settled\_proposals**: [`ProposalId`](ProposalId.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1068](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1068)

***

### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1065](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L1065)
