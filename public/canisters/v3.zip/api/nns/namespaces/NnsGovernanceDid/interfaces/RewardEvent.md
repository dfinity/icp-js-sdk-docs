---
title: RewardEvent
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1117](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1117)

## Properties

### actual\_timestamp\_seconds

> **actual\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1120](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1120)

***

### day\_after\_genesis

> **day\_after\_genesis**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1119](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1119)

***

### distributed\_e8s\_equivalent

> **distributed\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1123](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1123)

***

### latest\_round\_available\_e8s\_equivalent

> **latest\_round\_available\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1122](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1122)

***

### rounds\_since\_last\_distribution

> **rounds\_since\_last\_distribution**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1118](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1118)

***

### settled\_proposals

> **settled\_proposals**: [`ProposalId`](ProposalId.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1124](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1124)

***

### total\_available\_e8s\_equivalent

> **total\_available\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1121](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L1121)
