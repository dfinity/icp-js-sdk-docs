---
title: NeuronsFundMatchedFundingCurveCoefficients
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:926](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L926)

## Properties

### contribution\_threshold\_xdr

> **contribution\_threshold\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:927](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L927)

***

### full\_participation\_milestone\_xdr

> **full\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:929](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L929)

***

### one\_third\_participation\_milestone\_xdr

> **one\_third\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:928](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L928)
