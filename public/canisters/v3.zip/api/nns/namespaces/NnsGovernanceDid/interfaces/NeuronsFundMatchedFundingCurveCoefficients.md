---
title: NeuronsFundMatchedFundingCurveCoefficients
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:873](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L873)

## Properties

### contribution\_threshold\_xdr

> **contribution\_threshold\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:874](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L874)

***

### full\_participation\_milestone\_xdr

> **full\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:876](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L876)

***

### one\_third\_participation\_milestone\_xdr

> **one\_third\_participation\_milestone\_xdr**: \[\] \| \[[`Decimal`](Decimal.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:875](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L875)
