---
title: SettleNeuronsFundParticipationResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1186](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1186)

## Properties

### result

> **result**: \[\] \| \[[`Result_10`](../type-aliases/Result_10.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1187](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L1187)
