---
title: SettleNeuronsFundParticipationResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1128](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1128)

## Properties

### result

> **result**: \[\] \| \[[`Result_10`](../type-aliases/Result_10.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:1129](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L1129)
