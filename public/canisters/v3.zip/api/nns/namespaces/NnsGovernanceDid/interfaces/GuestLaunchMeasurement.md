---
title: GuestLaunchMeasurement
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:400](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L400)

## Properties

### measurement

> **measurement**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:408](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L408)

SEV-SNP measurement (48 bytes).

***

### metadata

> **metadata**: \[\] \| \[[`GuestLaunchMeasurementMetadata`](GuestLaunchMeasurementMetadata.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:404](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance.d.ts#L404)

Metadata associated with the measurement.
