---
title: CreateServiceNervousSystem
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L151)

## Properties

### dapp\_canisters

> **dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L159)

***

### description

> **description**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L158)

***

### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L154)

***

### governance\_parameters

> **governance\_parameters**: \[\] \| \[[`GovernanceParameters`](GovernanceParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L153)

***

### initial\_token\_distribution

> **initial\_token\_distribution**: \[\] \| \[[`InitialTokenDistribution`](InitialTokenDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L161)

***

### ledger\_parameters

> **ledger\_parameters**: \[\] \| \[[`LedgerParameters`](LedgerParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L157)

***

### logo

> **logo**: \[\] \| \[[`Image`](Image.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L155)

***

### name

> **name**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L156)

***

### swap\_parameters

> **swap\_parameters**: \[\] \| \[[`SwapParameters`](SwapParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:160](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L160)

***

### url

> **url**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L152)
