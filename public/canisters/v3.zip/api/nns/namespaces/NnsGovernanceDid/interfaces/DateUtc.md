---
title: DateUtc
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:196](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L196)

## Properties

### day

> **day**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:197](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L197)

***

### month

> **month**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:198](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L198)

***

### year

> **year**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L199)
