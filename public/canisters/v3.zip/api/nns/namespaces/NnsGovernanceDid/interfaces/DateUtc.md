---
title: DateUtc
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L167)

## Properties

### day

> **day**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L168)

***

### month

> **month**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L169)

***

### year

> **year**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:170](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L170)
