---
title: MergeResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:625](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L625)

## Properties

### source\_neuron

> **source\_neuron**: \[\] \| \[[`Neuron`](Neuron.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:627](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L627)

***

### source\_neuron\_info

> **source\_neuron\_info**: \[\] \| \[[`NeuronInfo`](NeuronInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:629](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L629)

***

### target\_neuron

> **target\_neuron**: \[\] \| \[[`Neuron`](Neuron.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:626](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L626)

***

### target\_neuron\_info

> **target\_neuron\_info**: \[\] \| \[[`NeuronInfo`](NeuronInfo.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:628](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L628)
