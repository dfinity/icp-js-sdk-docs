---
title: ManageNeuronRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:584](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L584)

Parameters of the manage_neuron method.

## Properties

### command

> **command**: \[\] \| \[[`ManageNeuronCommandRequest`](../type-aliases/ManageNeuronCommandRequest.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:592](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L592)

What operation to perform on the neuron.

***

### id

> **id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:588](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L588)

Deprecated. Use neuron_id_or_subaccount instead.

***

### neuron\_id\_or\_subaccount

> **neuron\_id\_or\_subaccount**: \[\] \| \[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:596](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L596)

Which neuron to operate on.
