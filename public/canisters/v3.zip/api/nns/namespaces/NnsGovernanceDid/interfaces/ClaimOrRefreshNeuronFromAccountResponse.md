---
title: ClaimOrRefreshNeuronFromAccountResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L99)

## Properties

### result

> **result**: \[\] \| \[[`Result_1`](../type-aliases/Result_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L100)
