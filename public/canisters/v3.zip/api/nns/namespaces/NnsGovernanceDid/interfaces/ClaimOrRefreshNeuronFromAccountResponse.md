---
title: ClaimOrRefreshNeuronFromAccountResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L99)

## Properties

### result

> **result**: \[\] \| \[[`Result_1`](../type-aliases/Result_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:100](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L100)
