---
title: ListProposalInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L521)

## Properties

### proposal\_info

> **proposal\_info**: [`ProposalInfo`](ProposalInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance.d.ts#L522)
