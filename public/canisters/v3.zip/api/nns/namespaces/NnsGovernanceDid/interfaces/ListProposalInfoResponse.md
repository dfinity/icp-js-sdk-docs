---
title: ListProposalInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:521](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L521)

## Properties

### proposal\_info

> **proposal\_info**: [`ProposalInfo`](ProposalInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:522](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance.d.ts#L522)
