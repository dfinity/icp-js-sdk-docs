---
title: MakeProposalRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:577](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L577)

## Properties

### action

> **action**: \[\] \| \[[`ProposalActionRequest`](../type-aliases/ProposalActionRequest.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:580](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L580)

***

### summary

> **summary**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:581](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L581)

***

### title

> **title**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:579](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L579)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance.d.ts:578](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance.d.ts#L578)
