---
title: NeuronsFundNeuronPortion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L885)

## Properties

### amount\_icp\_e8s

> **amount\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L891)

***

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L886)

***

### hotkeys

> **hotkeys**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L887)

***

### is\_capped

> **is\_capped**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L888)

***

### maturity\_equivalent\_icp\_e8s

> **maturity\_equivalent\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L889)

***

### nns\_neuron\_id

> **nns\_neuron\_id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L890)
