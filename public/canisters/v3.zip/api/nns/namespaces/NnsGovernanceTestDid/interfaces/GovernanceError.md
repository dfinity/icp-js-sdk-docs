---
title: GovernanceError
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L354)

## Properties

### error\_message

> **error\_message**: `string`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L355)

***

### error\_type

> **error\_type**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L356)
