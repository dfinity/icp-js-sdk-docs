---
title: NeuronInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:839](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L839)

A limit view of Neuron that allows some aspects of all neurons to be read by
anyone (i.e. without having to be the neuron's controller nor one of its
hotkeys).

As such, the meaning of each field in this type is generally the same as the
one of the same (or at least similar) name in Neuron.

## Properties

### age\_seconds

> **age\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:871](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L871)

***

### created\_timestamp\_seconds

> **created\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:847](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L847)

***

### deciding\_voting\_power

> **deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:846](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L846)

***

### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:841](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L841)

***

### id

> **id**: \[\] \| \[[`NeuronId`](NeuronId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:840](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L840)

***

### joined\_community\_fund\_timestamp\_seconds

> **joined\_community\_fund\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:857](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L857)

***

### known\_neuron\_data

> **known\_neuron\_data**: \[\] \| \[[`KnownNeuronData`](KnownNeuronData.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:860](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L860)

***

### neuron\_type

> **neuron\_type**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:845](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L845)

***

### potential\_voting\_power

> **potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:844](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L844)

***

### recent\_ballots

> **recent\_ballots**: [`BallotInfo`](BallotInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:842](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L842)

***

### retrieved\_at\_timestamp\_seconds

> **retrieved\_at\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:858](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L858)

***

### stake\_e8s

> **stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:856](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L856)

The amount of ICP (and staked maturity) locked in this neuron.

This is the foundation of the neuron's voting power.

cached_neuron_stake_e8s - neuron_fees_e8s + staked_maturity_e8s_equivalent

***

### state

> **state**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:848](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L848)

***

### visibility

> **visibility**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:859](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L859)

***

### voting\_power

> **voting\_power**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:870](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L870)

Deprecated. Use either deciding_voting_power or potential_voting_power
instead. Has the same value as deciding_voting_power.

Previously, if a neuron had < 6 months dissolve delay (making it ineligible
to vote), this would not get set to 0 (zero). That was pretty confusing.
Now that this is set to deciding_voting_power, this actually does get
zeroed out.

***

### voting\_power\_refreshed\_timestamp\_seconds

> **voting\_power\_refreshed\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:843](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L843)
