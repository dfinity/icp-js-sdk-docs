---
title: DisburseToNeuron
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:199](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L199)

## Properties

### amount\_e8s

> **amount\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:202](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L202)

***

### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:200](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L200)

***

### kyc\_verified

> **kyc\_verified**: `boolean`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:201](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L201)

***

### new\_controller

> **new\_controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L203)

***

### nonce

> **nonce**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:204](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L204)
