---
title: Params
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:987](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L987)

## Properties

### max\_direct\_participation\_icp\_e8s

> **max\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1000](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1000)

***

### max\_icp\_e8s

> **max\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:992](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L992)

***

### max\_participant\_icp\_e8s

> **max\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:997](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L997)

***

### min\_direct\_participation\_icp\_e8s

> **min\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:998](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L998)

***

### min\_icp\_e8s

> **min\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:999](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L999)

***

### min\_participant\_icp\_e8s

> **min\_participant\_icp\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:988](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L988)

***

### min\_participants

> **min\_participants**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:994](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L994)

***

### neuron\_basket\_construction\_parameters

> **neuron\_basket\_construction\_parameters**: \[\] \| \[[`NeuronBasketConstructionParameters_1`](NeuronBasketConstructionParameters_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:989](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L989)

***

### sale\_delay\_seconds

> **sale\_delay\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:996](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L996)

***

### sns\_token\_e8s

> **sns\_token\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:995](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L995)

***

### swap\_due\_timestamp\_seconds

> **swap\_due\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:993](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L993)
