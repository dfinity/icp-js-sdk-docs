---
title: SetOpenTimeWindowRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1110](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L1110)

## Properties

### open\_time\_window

> **open\_time\_window**: \[\] \| \[[`TimeWindow`](TimeWindow.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1111](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L1111)
