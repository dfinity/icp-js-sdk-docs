---
title: GovernanceParameters
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:387](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L387)

## Properties

### custom\_proposal\_criticality

> **custom\_proposal\_criticality**: \[\] \| \[[`CustomProposalCriticality`](CustomProposalCriticality.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:396](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L396)

***

### neuron\_maximum\_age\_bonus

> **neuron\_maximum\_age\_bonus**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:392](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L392)

***

### neuron\_maximum\_age\_for\_age\_bonus

> **neuron\_maximum\_age\_for\_age\_bonus**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:389](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L389)

***

### neuron\_maximum\_dissolve\_delay

> **neuron\_maximum\_dissolve\_delay**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:390](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L390)

***

### neuron\_maximum\_dissolve\_delay\_bonus

> **neuron\_maximum\_dissolve\_delay\_bonus**: \[\] \| \[[`Percentage`](Percentage.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:388](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L388)

***

### neuron\_minimum\_dissolve\_delay\_to\_vote

> **neuron\_minimum\_dissolve\_delay\_to\_vote**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:391](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L391)

***

### neuron\_minimum\_stake

> **neuron\_minimum\_stake**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:393](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L393)

***

### proposal\_initial\_voting\_period

> **proposal\_initial\_voting\_period**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:395](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L395)

***

### proposal\_rejection\_fee

> **proposal\_rejection\_fee**: \[\] \| \[[`Tokens`](Tokens.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:397](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L397)

***

### proposal\_wait\_for\_quiet\_deadline\_increase

> **proposal\_wait\_for\_quiet\_deadline\_increase**: \[\] \| \[[`Duration`](Duration.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:394](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L394)

***

### voting\_reward\_parameters

> **voting\_reward\_parameters**: \[\] \| \[[`VotingRewardParameters`](VotingRewardParameters.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:398](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L398)
