---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1294](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1294)

## Properties

### claim\_gtc\_neurons

> **claim\_gtc\_neurons**: `ActorMethod`\<\[`Principal`, [`NeuronId`](NeuronId.md)[]\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1295](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1295)

***

### claim\_or\_refresh\_neuron\_from\_account

> **claim\_or\_refresh\_neuron\_from\_account**: `ActorMethod`\<\[[`ClaimOrRefreshNeuronFromAccount`](ClaimOrRefreshNeuronFromAccount.md)\], [`ClaimOrRefreshNeuronFromAccountResponse`](ClaimOrRefreshNeuronFromAccountResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1296](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1296)

***

### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1300](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1300)

***

### get\_full\_neuron

> **get\_full\_neuron**: `ActorMethod`\<\[`bigint`\], [`Result_2`](../type-aliases/Result_2.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1301](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1301)

***

### get\_full\_neuron\_by\_id\_or\_subaccount

> **get\_full\_neuron\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\], [`Result_2`](../type-aliases/Result_2.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1302](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1302)

***

### get\_latest\_reward\_event

> **get\_latest\_reward\_event**: `ActorMethod`\<\[\], [`RewardEvent`](RewardEvent.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1306](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1306)

***

### get\_metrics

> **get\_metrics**: `ActorMethod`\<\[\], [`Result_3`](../type-aliases/Result_3.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1307](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1307)

***

### get\_monthly\_node\_provider\_rewards

> **get\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], [`Result_4`](../type-aliases/Result_4.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1308](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1308)

***

### get\_most\_recent\_monthly\_node\_provider\_rewards

> **get\_most\_recent\_monthly\_node\_provider\_rewards**: `ActorMethod`\<\[\], \[\] \| \[[`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1309](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1309)

***

### get\_network\_economics\_parameters

> **get\_network\_economics\_parameters**: `ActorMethod`\<\[\], [`NetworkEconomics`](NetworkEconomics.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1313](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1313)

***

### get\_neuron\_ids

> **get\_neuron\_ids**: `ActorMethod`\<\[\], `BigUint64Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1314](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1314)

***

### get\_neuron\_index

> **get\_neuron\_index**: `ActorMethod`\<\[[`GetNeuronIndexRequest`](GetNeuronIndexRequest.md)\], [`GetNeuronIndexResult`](../type-aliases/GetNeuronIndexResult.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1315](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1315)

***

### get\_neuron\_info

> **get\_neuron\_info**: `ActorMethod`\<\[`bigint`\], [`Result_5`](../type-aliases/Result_5.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1316](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1316)

***

### get\_neuron\_info\_by\_id\_or\_subaccount

> **get\_neuron\_info\_by\_id\_or\_subaccount**: `ActorMethod`\<\[[`NeuronIdOrSubaccount`](../type-aliases/NeuronIdOrSubaccount.md)\], [`Result_5`](../type-aliases/Result_5.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1317](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1317)

***

### get\_neurons\_fund\_audit\_info

> **get\_neurons\_fund\_audit\_info**: `ActorMethod`\<\[[`GetNeuronsFundAuditInfoRequest`](GetNeuronsFundAuditInfoRequest.md)\], [`GetNeuronsFundAuditInfoResponse`](GetNeuronsFundAuditInfoResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1321](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1321)

***

### get\_node\_provider\_by\_caller

> **get\_node\_provider\_by\_caller**: `ActorMethod`\<\[`null`\], [`Result_7`](../type-aliases/Result_7.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1325](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1325)

***

### get\_pending\_proposals

> **get\_pending\_proposals**: `ActorMethod`\<\[\[\] \| \[[`GetPendingProposalsRequest`](GetPendingProposalsRequest.md)\]\], [`ProposalInfo`](ProposalInfo.md)[]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1326](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1326)

***

### get\_proposal\_info

> **get\_proposal\_info**: `ActorMethod`\<\[`bigint`\], \[\] \| \[[`ProposalInfo`](ProposalInfo.md)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1330](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1330)

***

### get\_restore\_aging\_summary

> **get\_restore\_aging\_summary**: `ActorMethod`\<\[\], [`RestoreAgingSummary`](RestoreAgingSummary.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1331](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1331)

***

### list\_known\_neurons

> **list\_known\_neurons**: `ActorMethod`\<\[\], [`ListKnownNeuronsResponse`](ListKnownNeuronsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1332](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1332)

***

### list\_neuron\_votes

> **list\_neuron\_votes**: `ActorMethod`\<\[[`ListNeuronVotesRequest`](ListNeuronVotesRequest.md)\], [`ListNeuronVotesResponse`](../type-aliases/ListNeuronVotesResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1333](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1333)

***

### list\_neurons

> **list\_neurons**: `ActorMethod`\<\[[`ListNeurons`](ListNeurons.md)\], [`ListNeuronsResponse`](ListNeuronsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1337](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1337)

***

### list\_node\_provider\_rewards

> **list\_node\_provider\_rewards**: `ActorMethod`\<\[[`ListNodeProviderRewardsRequest`](ListNodeProviderRewardsRequest.md)\], [`ListNodeProviderRewardsResponse`](ListNodeProviderRewardsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1338](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1338)

***

### list\_node\_providers

> **list\_node\_providers**: `ActorMethod`\<\[\], [`ListNodeProvidersResponse`](ListNodeProvidersResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1342](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1342)

***

### list\_proposals

> **list\_proposals**: `ActorMethod`\<\[[`ListProposalInfoRequest`](ListProposalInfoRequest.md)\], [`ListProposalInfoResponse`](ListProposalInfoResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1343](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1343)

***

### manage\_neuron

> **manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](ManageNeuronRequest.md)\], [`ManageNeuronResponse`](ManageNeuronResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1347](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1347)

***

### settle\_community\_fund\_participation

> **settle\_community\_fund\_participation**: `ActorMethod`\<\[[`SettleCommunityFundParticipation`](SettleCommunityFundParticipation.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1348](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1348)

***

### settle\_neurons\_fund\_participation

> **settle\_neurons\_fund\_participation**: `ActorMethod`\<\[[`SettleNeuronsFundParticipationRequest`](SettleNeuronsFundParticipationRequest.md)\], [`SettleNeuronsFundParticipationResponse`](SettleNeuronsFundParticipationResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1352](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1352)

***

### simulate\_manage\_neuron

> **simulate\_manage\_neuron**: `ActorMethod`\<\[[`ManageNeuronRequest`](ManageNeuronRequest.md)\], [`ManageNeuronResponse`](ManageNeuronResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1356](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1356)

***

### transfer\_gtc\_neuron

> **transfer\_gtc\_neuron**: `ActorMethod`\<\[[`NeuronId`](NeuronId.md), [`NeuronId`](NeuronId.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1360](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1360)

***

### update\_neuron

> **update\_neuron**: `ActorMethod`\<\[[`Neuron`](Neuron.md)\], \[\] \| \[[`GovernanceError`](GovernanceError.md)\]\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1364](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1364)

The following are methods for feature = "test"

***

### update\_node\_provider

> **update\_node\_provider**: `ActorMethod`\<\[[`UpdateNodeProvider`](UpdateNodeProvider.md)\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1365](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1365)
