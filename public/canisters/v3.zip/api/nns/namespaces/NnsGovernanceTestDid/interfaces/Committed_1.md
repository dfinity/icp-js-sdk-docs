---
title: Committed_1
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L163)

## Properties

### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L166)

***

### total\_direct\_participation\_icp\_e8s

> **total\_direct\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L164)

***

### total\_neurons\_fund\_participation\_icp\_e8s

> **total\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L165)
