---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L428)

## Properties

### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](DeveloperDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L430)

***

### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](SwapDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L431)

***

### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`SwapDistribution`](SwapDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L429)
