---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L379)

## Properties

### developer\_distribution

> **developer\_distribution**: \[\] \| \[[`DeveloperDistribution`](DeveloperDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L381)

***

### swap\_distribution

> **swap\_distribution**: \[\] \| \[[`SwapDistribution`](SwapDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:382](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L382)

***

### treasury\_distribution

> **treasury\_distribution**: \[\] \| \[[`SwapDistribution`](SwapDistribution.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L380)
