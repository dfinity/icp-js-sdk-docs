---
title: NeuronSubsetMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:885](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L885)

## Properties

### count

> **count**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:890](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L890)

***

### count\_buckets

> **count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:899](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L899)

***

### deciding\_voting\_power\_buckets

> **deciding\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:891](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L891)

***

### maturity\_e8s\_equivalent\_buckets

> **maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:887](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L887)

***

### potential\_voting\_power\_buckets

> **potential\_voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:898](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L898)

***

### staked\_e8s\_buckets

> **staked\_e8s\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:896](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L896)

***

### staked\_maturity\_e8s\_equivalent\_buckets

> **staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:895](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L895)

***

### total\_deciding\_voting\_power

> **total\_deciding\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:894](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L894)

***

### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:886](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L886)

***

### total\_potential\_voting\_power

> **total\_potential\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:893](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L893)

***

### total\_staked\_e8s

> **total\_staked\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:889](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L889)

***

### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:892](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L892)

***

### total\_voting\_power

> **total\_voting\_power**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:897](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L897)

***

### voting\_power\_buckets

> **voting\_power\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:888](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L888)
