---
title: ListKnownNeuronsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:423](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L423)

## Properties

### known\_neurons

> **known\_neurons**: [`KnownNeuron`](KnownNeuron.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:424](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L424)
