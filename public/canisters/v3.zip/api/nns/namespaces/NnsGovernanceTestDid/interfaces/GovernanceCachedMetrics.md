---
title: GovernanceCachedMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:333](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L333)

## Properties

### community\_fund\_total\_maturity\_e8s\_equivalent

> **community\_fund\_total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:347](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L347)

***

### community\_fund\_total\_staked\_e8s

> **community\_fund\_total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:377](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L377)

***

### declining\_voting\_power\_neuron\_subset\_metrics

> **declining\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:359](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L359)

***

### dissolved\_neurons\_count

> **dissolved\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:346](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L346)

***

### dissolved\_neurons\_e8s

> **dissolved\_neurons\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:362](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L362)

***

### dissolving\_neurons\_count

> **dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:374](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L374)

***

### dissolving\_neurons\_count\_buckets

> **dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:369](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L369)

***

### dissolving\_neurons\_e8s\_buckets

> **dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:375](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L375)

***

### dissolving\_neurons\_e8s\_buckets\_ect

> **dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L370)

***

### dissolving\_neurons\_e8s\_buckets\_seed

> **dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:364](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L364)

***

### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:338](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L338)

***

### dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:336](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L336)

***

### ect\_neuron\_count

> **ect\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:343](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L343)

***

### fully\_lost\_voting\_power\_neuron\_subset\_metrics

> **fully\_lost\_voting\_power\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:351](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L351)

***

### garbage\_collectable\_neurons\_count

> **garbage\_collectable\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:337](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L337)

***

### neurons\_fund\_total\_active\_neurons

> **neurons\_fund\_total\_active\_neurons**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:354](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L354)

***

### neurons\_with\_invalid\_stake\_count

> **neurons\_with\_invalid\_stake\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:341](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L341)

***

### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L345)

***

### neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s

> **neurons\_with\_less\_than\_6\_months\_dissolve\_delay\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:365](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L365)

***

### non\_self\_authenticating\_controller\_neuron\_subset\_metrics

> **non\_self\_authenticating\_controller\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L371)

***

### not\_dissolving\_neurons\_count

> **not\_dissolving\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:352](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L352)

***

### not\_dissolving\_neurons\_count\_buckets

> **not\_dissolving\_neurons\_count\_buckets**: \[`bigint`, `bigint`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:342](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L342)

***

### not\_dissolving\_neurons\_e8s\_buckets

> **not\_dissolving\_neurons\_e8s\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:335](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L335)

***

### not\_dissolving\_neurons\_e8s\_buckets\_ect

> **not\_dissolving\_neurons\_e8s\_buckets\_ect**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L357)

***

### not\_dissolving\_neurons\_e8s\_buckets\_seed

> **not\_dissolving\_neurons\_e8s\_buckets\_seed**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:378](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L378)

***

### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_buckets**: \[`bigint`, `number`\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:366](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L366)

***

### not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum

> **not\_dissolving\_neurons\_staked\_maturity\_e8s\_equivalent\_sum**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:361](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L361)

***

### public\_neuron\_subset\_metrics

> **public\_neuron\_subset\_metrics**: \[\] \| \[[`NeuronSubsetMetrics`](NeuronSubsetMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:379](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L379)

***

### seed\_neuron\_count

> **seed\_neuron\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:381](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L381)

***

### spawning\_neurons\_count

> **spawning\_neurons\_count**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L358)

***

### timestamp\_seconds

> **timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:380](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L380)

***

### total\_locked\_e8s

> **total\_locked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:353](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L353)

***

### total\_maturity\_e8s\_equivalent

> **total\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:334](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L334)

***

### total\_staked\_e8s

> **total\_staked\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:350](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L350)

***

### total\_staked\_e8s\_ect

> **total\_staked\_e8s\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:360](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L360)

***

### total\_staked\_e8s\_non\_self\_authenticating\_controller

> **total\_staked\_e8s\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:363](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L363)

***

### total\_staked\_e8s\_seed

> **total\_staked\_e8s\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:348](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L348)

***

### total\_staked\_maturity\_e8s\_equivalent

> **total\_staked\_maturity\_e8s\_equivalent**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L356)

***

### total\_staked\_maturity\_e8s\_equivalent\_ect

> **total\_staked\_maturity\_e8s\_equivalent\_ect**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:349](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L349)

***

### total\_staked\_maturity\_e8s\_equivalent\_seed

> **total\_staked\_maturity\_e8s\_equivalent\_seed**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:376](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L376)

***

### total\_supply\_icp

> **total\_supply\_icp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L344)

***

### total\_voting\_power\_non\_self\_authenticating\_controller

> **total\_voting\_power\_non\_self\_authenticating\_controller**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L355)
