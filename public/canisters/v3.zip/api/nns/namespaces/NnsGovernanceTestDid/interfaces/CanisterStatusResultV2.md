---
title: CanisterStatusResultV2
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:75](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L75)

## Properties

### controllers

> **controllers**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:78](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L78)

***

### cycles

> **cycles**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:80](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L80)

***

### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:77](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L77)

***

### idle\_cycles\_burned\_per\_day

> **idle\_cycles\_burned\_per\_day**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:81](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L81)

***

### memory\_size

> **memory\_size**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:79](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L79)

***

### module\_hash

> **module\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:82](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L82)

***

### status

> **status**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:76](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L76)
