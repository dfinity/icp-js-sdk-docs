---
title: SettleNeuronsFundParticipationRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1182](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1182)

## Properties

### nns\_proposal\_id

> **nns\_proposal\_id**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1184](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1184)

***

### result

> **result**: \[\] \| \[[`Result_9`](../type-aliases/Result_9.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1183](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1183)
