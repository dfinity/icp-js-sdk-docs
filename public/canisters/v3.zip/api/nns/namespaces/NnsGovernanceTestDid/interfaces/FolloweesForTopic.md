---
title: FolloweesForTopic
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:223](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L223)

## Properties

### followees

> **followees**: \[\] \| \[[`NeuronId`](NeuronId.md)[]\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L225)

***

### topic

> **topic**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L224)
