---
title: SwapBackgroundInformation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1154](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1154)

## Properties

### dapp\_canister\_summaries

> **dapp\_canister\_summaries**: [`CanisterSummary`](CanisterSummary.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1162](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1162)

***

### fallback\_controller\_principal\_ids

> **fallback\_controller\_principal\_ids**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1156](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1156)

***

### governance\_canister\_summary

> **governance\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1160](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1160)

***

### ledger\_archive\_canister\_summaries

> **ledger\_archive\_canister\_summaries**: [`CanisterSummary`](CanisterSummary.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1157](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1157)

***

### ledger\_canister\_summary

> **ledger\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1158](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1158)

***

### ledger\_index\_canister\_summary

> **ledger\_index\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1155](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1155)

***

### root\_canister\_summary

> **root\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1161](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1161)

***

### swap\_canister\_summary

> **swap\_canister\_summary**: \[\] \| \[[`CanisterSummary`](CanisterSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1159](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L1159)
