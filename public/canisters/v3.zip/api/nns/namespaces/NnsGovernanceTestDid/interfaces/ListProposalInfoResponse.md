---
title: ListProposalInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:570](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L570)

## Properties

### proposal\_info

> **proposal\_info**: [`ProposalInfo`](ProposalInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:571](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L571)
