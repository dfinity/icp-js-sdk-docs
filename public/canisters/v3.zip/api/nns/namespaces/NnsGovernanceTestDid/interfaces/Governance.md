---
title: Governance
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:283](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L283)

## Properties

### cached\_daily\_maturity\_modulation\_basis\_points

> **cached\_daily\_maturity\_modulation\_basis\_points**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L291)

***

### default\_followees

> **default\_followees**: \[`number`, [`Followees`](Followees.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:284](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L284)

***

### economics

> **economics**: \[\] \| \[[`NetworkEconomics`](NetworkEconomics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L292)

***

### genesis\_timestamp\_seconds

> **genesis\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:302](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L302)

***

### in\_flight\_commands

> **in\_flight\_commands**: \[`bigint`, [`NeuronInFlightCommand`](NeuronInFlightCommand.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L300)

***

### latest\_reward\_event

> **latest\_reward\_event**: \[\] \| \[[`RewardEvent`](RewardEvent.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:295](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L295)

***

### maturity\_modulation\_last\_updated\_at\_timestamp\_seconds

> **maturity\_modulation\_last\_updated\_at\_timestamp\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L286)

***

### metrics

> **metrics**: \[\] \| \[[`GovernanceCachedMetrics`](GovernanceCachedMetrics.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L288)

***

### most\_recent\_monthly\_node\_provider\_rewards

> **most\_recent\_monthly\_node\_provider\_rewards**: \[\] \| \[[`MonthlyNodeProviderRewards`](MonthlyNodeProviderRewards.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:285](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L285)

***

### neuron\_management\_voting\_period\_seconds

> **neuron\_management\_voting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L289)

***

### neurons

> **neurons**: \[`bigint`, [`Neuron`](Neuron.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L301)

***

### node\_providers

> **node\_providers**: [`NodeProvider`](NodeProvider.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L290)

***

### proposals

> **proposals**: \[`bigint`, [`ProposalData`](ProposalData.md)\][]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:298](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L298)

***

### restore\_aging\_summary

> **restore\_aging\_summary**: \[\] \| \[[`RestoreAgingSummary`](RestoreAgingSummary.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:293](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L293)

***

### short\_voting\_period\_seconds

> **short\_voting\_period\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:297](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L297)

***

### spawning\_neurons

> **spawning\_neurons**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:294](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L294)

***

### to\_claim\_transfers

> **to\_claim\_transfers**: [`NeuronStakeTransfer`](NeuronStakeTransfer.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L296)

***

### wait\_for\_quiet\_threshold\_seconds

> **wait\_for\_quiet\_threshold\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:287](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L287)

***

### xdr\_conversion\_rate

> **xdr\_conversion\_rate**: \[\] \| \[[`XdrConversionRate`](XdrConversionRate.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:299](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L299)
