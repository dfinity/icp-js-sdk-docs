---
title: TimeWindow
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1259](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1259)

## Properties

### end\_timestamp\_seconds

> **end\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1261](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1261)

***

### start\_timestamp\_seconds

> **start\_timestamp\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:1260](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L1260)
