---
title: MakeProposalResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:530](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L530)

## Properties

### message

> **message**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:531](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L531)

***

### proposal\_id

> **proposal\_id**: \[\] \| \[[`ProposalId`](ProposalId.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:532](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L532)
