---
title: DerivedProposalInformation
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:207](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L207)

## Properties

### swap\_background\_information

> **swap\_background\_information**: \[\] \| \[[`SwapBackgroundInformation`](SwapBackgroundInformation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:208](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L208)
