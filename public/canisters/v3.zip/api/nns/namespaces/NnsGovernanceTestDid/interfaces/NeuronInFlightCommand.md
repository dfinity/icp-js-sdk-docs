---
title: NeuronInFlightCommand
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:771](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L771)

## Properties

### command

> **command**: \[\] \| \[[`Command_2`](../type-aliases/Command_2.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:772](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L772)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:773](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L773)
