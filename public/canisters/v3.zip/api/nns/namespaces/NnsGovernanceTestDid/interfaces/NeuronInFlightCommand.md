---
title: NeuronInFlightCommand
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:824](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L824)

## Properties

### command

> **command**: \[\] \| \[[`Command_2`](../type-aliases/Command_2.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:825](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L825)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:826](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L826)
