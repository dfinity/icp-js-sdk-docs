---
title: DisburseMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:188](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L188)

## Properties

### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:191](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L191)

***

### to\_account

> **to\_account**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:190](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L190)

***

### to\_account\_identifier

> **to\_account\_identifier**: \[\] \| \[[`AccountIdentifier`](AccountIdentifier.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:189](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L189)
