---
title: DisburseMaturity
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:217](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L217)

## Properties

### percentage\_to\_disburse

> **percentage\_to\_disburse**: `number`

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L220)

***

### to\_account

> **to\_account**: \[\] \| \[[`Account`](Account.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:219](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L219)

***

### to\_account\_identifier

> **to\_account\_identifier**: \[\] \| \[[`AccountIdentifier`](AccountIdentifier.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:218](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/governance_test.d.ts#L218)
