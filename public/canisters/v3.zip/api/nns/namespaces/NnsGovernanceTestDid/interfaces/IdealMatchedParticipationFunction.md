---
title: IdealMatchedParticipationFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:370](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L370)

## Properties

### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:371](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L371)
