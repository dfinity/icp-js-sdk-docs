---
title: NeuronIndexData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:775](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L775)

## Properties

### neurons

> **neurons**: [`NeuronInfo`](NeuronInfo.md)[]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:776](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/governance_test.d.ts#L776)
