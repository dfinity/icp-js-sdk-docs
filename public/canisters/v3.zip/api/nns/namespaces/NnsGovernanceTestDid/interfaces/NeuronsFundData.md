---
title: NeuronsFundData
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:913](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L913)

## Properties

### final\_neurons\_fund\_participation

> **final\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](NeuronsFundParticipation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:914](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L914)

***

### initial\_neurons\_fund\_participation

> **initial\_neurons\_fund\_participation**: \[\] \| \[[`NeuronsFundParticipation`](NeuronsFundParticipation.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:915](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L915)

***

### neurons\_fund\_refunds

> **neurons\_fund\_refunds**: \[\] \| \[[`NeuronsFundSnapshot`](NeuronsFundSnapshot.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:916](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/governance_test.d.ts#L916)
