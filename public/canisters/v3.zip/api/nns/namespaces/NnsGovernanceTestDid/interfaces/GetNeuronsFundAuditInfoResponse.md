---
title: GetNeuronsFundAuditInfoResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L274)

## Properties

### result

> **result**: \[\] \| \[[`Result_6`](../type-aliases/Result_6.md)\]

Defined in: [packages/canisters/src/declarations/nns/governance\_test.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/governance_test.d.ts#L275)
