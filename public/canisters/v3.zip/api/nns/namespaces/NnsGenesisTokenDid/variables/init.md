---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/genesis_token.d.ts#L46)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
