---
title: init
editUrl: false
next: true
prev: true
---

> `const` **init**: (`args`) => `IDL.Type`[]

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:46](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L46)

## Parameters

### args

#### IDL

*typeof* `IDL`

## Returns

`IDL.Type`[]
