---
title: idlFactory
editUrl: false
next: true
prev: true
---

> `const` **idlFactory**: `IDL.InterfaceFactory`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/genesis_token.d.ts#L45)
