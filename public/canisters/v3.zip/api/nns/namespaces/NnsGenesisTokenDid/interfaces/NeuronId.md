---
title: NeuronId
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:24](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/genesis_token.d.ts#L24)

## Properties

### id

> **id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:25](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/genesis_token.d.ts#L25)
