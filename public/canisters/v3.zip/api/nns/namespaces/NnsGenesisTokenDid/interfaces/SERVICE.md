---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L35)

## Properties

### balance

> **balance**: `ActorMethod`\<\[`string`\], `number`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L36)

***

### claim\_neurons

> **claim\_neurons**: `ActorMethod`\<\[`string`\], [`Result`](../type-aliases/Result.md)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:37](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L37)

***

### donate\_account

> **donate\_account**: `ActorMethod`\<\[`string`\], [`Result_1`](../type-aliases/Result_1.md)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L38)

***

### forward\_whitelisted\_unclaimed\_accounts

> **forward\_whitelisted\_unclaimed\_accounts**: `ActorMethod`\<\[`null`\], [`Result_1`](../type-aliases/Result_1.md)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L39)

***

### get\_account

> **get\_account**: `ActorMethod`\<\[`string`\], [`Result_2`](../type-aliases/Result_2.md)\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L40)

***

### get\_build\_metadata

> **get\_build\_metadata**: `ActorMethod`\<\[\], `string`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L41)

***

### len

> **len**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L42)

***

### total

> **total**: `ActorMethod`\<\[\], `number`\>

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L43)
