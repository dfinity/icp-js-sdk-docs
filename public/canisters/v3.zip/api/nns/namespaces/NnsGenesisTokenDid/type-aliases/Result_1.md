---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: `null`; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L28)
