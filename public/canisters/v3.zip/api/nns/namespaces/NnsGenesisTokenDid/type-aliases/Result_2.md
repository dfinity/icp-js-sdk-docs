---
title: Result_2
editUrl: false
next: true
prev: true
---

> **Result\_2** = \{ `Ok`: [`AccountState`](../interfaces/AccountState.md); \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/genesis_token.d.ts#L29)
