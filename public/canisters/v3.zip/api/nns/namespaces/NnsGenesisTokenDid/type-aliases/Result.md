---
title: Result
editUrl: false
next: true
prev: true
---

> **Result** = \{ `Ok`: [`NeuronId`](../interfaces/NeuronId.md)[]; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/genesis_token.d.ts#L27)
