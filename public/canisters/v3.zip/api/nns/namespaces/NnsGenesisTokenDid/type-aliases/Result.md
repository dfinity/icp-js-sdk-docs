---
title: Result
editUrl: false
next: true
prev: true
---

> **Result** = \{ `Ok`: [`NeuronId`](../interfaces/NeuronId.md)[]; \} \| \{ `Err`: `string`; \}

Defined in: [packages/canisters/src/declarations/nns/genesis\_token.d.ts:27](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/genesis_token.d.ts#L27)
