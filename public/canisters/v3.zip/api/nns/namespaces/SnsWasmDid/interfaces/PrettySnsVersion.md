---
title: PrettySnsVersion
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:163](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L163)

## Properties

### archive\_wasm\_hash

> **archive\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:164](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L164)

***

### governance\_wasm\_hash

> **governance\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:168](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L168)

***

### index\_wasm\_hash

> **index\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:169](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L169)

***

### ledger\_wasm\_hash

> **ledger\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:167](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L167)

***

### root\_wasm\_hash

> **root\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:165](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L165)

***

### swap\_wasm\_hash

> **swap\_wasm\_hash**: `string`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:166](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L166)
