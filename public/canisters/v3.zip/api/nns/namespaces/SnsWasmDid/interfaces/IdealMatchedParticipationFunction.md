---
title: IdealMatchedParticipationFunction
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:101](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L101)

## Properties

### serialized\_representation

> **serialized\_representation**: \[\] \| \[`string`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:102](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L102)
