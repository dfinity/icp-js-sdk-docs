---
title: DappCanistersTransferResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L30)

## Properties

### nns\_controlled\_dapp\_canisters

> **nns\_controlled\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L32)

***

### restored\_dapp\_canisters

> **restored\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:31](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L31)

***

### sns\_controlled\_dapp\_canisters

> **sns\_controlled\_dapp\_canisters**: [`Canister`](Canister.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L33)
