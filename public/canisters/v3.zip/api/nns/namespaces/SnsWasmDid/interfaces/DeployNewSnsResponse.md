---
title: DeployNewSnsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:38](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L38)

## Properties

### canisters

> **canisters**: \[\] \| \[[`SnsCanisterIds`](SnsCanisterIds.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L42)

***

### dapp\_canisters\_transfer\_result

> **dapp\_canisters\_transfer\_result**: \[\] \| \[[`DappCanistersTransferResult`](DappCanistersTransferResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:39](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L39)

***

### error

> **error**: \[\] \| \[[`SnsWasmError`](SnsWasmError.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L41)

***

### subnet\_id

> **subnet\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:40](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L40)
