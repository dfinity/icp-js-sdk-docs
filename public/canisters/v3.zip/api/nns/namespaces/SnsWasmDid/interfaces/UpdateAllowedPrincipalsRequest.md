---
title: UpdateAllowedPrincipalsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L260)

## Properties

### added\_principals

> **added\_principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L261)

***

### removed\_principals

> **removed\_principals**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:262](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L262)
