---
title: NeuronsFundParticipationConstraints
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L155)

## Properties

### coefficient\_intervals

> **coefficient\_intervals**: [`LinearScalingCoefficient`](LinearScalingCoefficient.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L156)

***

### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](IdealMatchedParticipationFunction.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:159](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L159)

***

### max\_neurons\_fund\_participation\_icp\_e8s

> **max\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:157](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L157)

***

### min\_direct\_participation\_threshold\_icp\_e8s

> **min\_direct\_participation\_threshold\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:158](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L158)
