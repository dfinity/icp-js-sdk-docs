---
title: NeuronsFundParticipationConstraints
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L152)

## Properties

### coefficient\_intervals

> **coefficient\_intervals**: [`LinearScalingCoefficient`](LinearScalingCoefficient.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L153)

***

### ideal\_matched\_participation\_function

> **ideal\_matched\_participation\_function**: \[\] \| \[[`IdealMatchedParticipationFunction`](IdealMatchedParticipationFunction.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:156](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L156)

***

### max\_neurons\_fund\_participation\_icp\_e8s

> **max\_neurons\_fund\_participation\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:154](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L154)

***

### min\_direct\_participation\_threshold\_icp\_e8s

> **min\_direct\_participation\_threshold\_icp\_e8s**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:155](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L155)
