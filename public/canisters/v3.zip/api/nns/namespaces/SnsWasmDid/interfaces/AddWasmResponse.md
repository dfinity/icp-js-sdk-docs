---
title: AddWasmResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L18)

## Properties

### result

> **result**: \[\] \| \[[`Result`](../type-aliases/Result.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L19)
