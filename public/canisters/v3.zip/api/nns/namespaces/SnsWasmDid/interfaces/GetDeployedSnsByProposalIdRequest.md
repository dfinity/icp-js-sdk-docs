---
title: GetDeployedSnsByProposalIdRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:62](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L62)

## Properties

### proposal\_id

> **proposal\_id**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:63](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L63)
