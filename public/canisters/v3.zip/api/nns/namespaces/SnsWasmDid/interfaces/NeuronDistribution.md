---
title: NeuronDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L148)

## Properties

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L149)

***

### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L150)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L151)

***

### stake\_e8s

> **stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L152)

***

### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L153)
