---
title: NeuronDistribution
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:148](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L148)

## Properties

### controller

> **controller**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:149](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L149)

***

### dissolve\_delay\_seconds

> **dissolve\_delay\_seconds**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:150](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L150)

***

### memo

> **memo**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:151](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L151)

***

### stake\_e8s

> **stake\_e8s**: `bigint`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:152](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L152)

***

### vesting\_period\_seconds

> **vesting\_period\_seconds**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:153](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L153)
