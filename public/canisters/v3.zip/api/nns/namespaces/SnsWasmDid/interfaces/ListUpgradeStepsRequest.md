---
title: ListUpgradeStepsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:128](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L128)

## Properties

### limit

> **limit**: `number`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:129](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L129)

***

### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:131](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L131)

***

### starting\_at

> **starting\_at**: \[\] \| \[[`SnsVersion`](SnsVersion.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:130](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L130)
