---
title: GetDeployedSnsByProposalIdResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:68](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L68)

## Properties

### get\_deployed\_sns\_by\_proposal\_id\_result

> **get\_deployed\_sns\_by\_proposal\_id\_result**: \[\] \| \[[`GetDeployedSnsByProposalIdResult`](../type-aliases/GetDeployedSnsByProposalIdResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:69](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L69)
