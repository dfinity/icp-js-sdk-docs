---
title: GetDeployedSnsByProposalIdResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:65](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L65)

## Properties

### get\_deployed\_sns\_by\_proposal\_id\_result

> **get\_deployed\_sns\_by\_proposal\_id\_result**: \[\] \| \[[`GetDeployedSnsByProposalIdResult`](../type-aliases/GetDeployedSnsByProposalIdResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:66](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L66)
