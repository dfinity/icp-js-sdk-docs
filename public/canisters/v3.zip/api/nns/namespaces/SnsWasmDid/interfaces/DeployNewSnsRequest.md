---
title: DeployNewSnsRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L35)

## Properties

### sns\_init\_payload

> **sns\_init\_payload**: \[\] \| \[[`SnsInitPayload`](SnsInitPayload.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:36](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L36)
