---
title: UpdateSnsSubnetListRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L266)

## Properties

### sns\_subnet\_ids\_to\_add

> **sns\_subnet\_ids\_to\_add**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:267](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L267)

***

### sns\_subnet\_ids\_to\_remove

> **sns\_subnet\_ids\_to\_remove**: `Principal`[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:268](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L268)
