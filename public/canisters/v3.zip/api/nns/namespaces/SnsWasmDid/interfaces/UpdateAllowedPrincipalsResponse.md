---
title: UpdateAllowedPrincipalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:264](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L264)

## Properties

### update\_allowed\_principals\_result

> **update\_allowed\_principals\_result**: \[\] \| \[[`UpdateAllowedPrincipalsResult`](../type-aliases/UpdateAllowedPrincipalsResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:265](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L265)
