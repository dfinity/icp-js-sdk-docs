---
title: UpdateAllowedPrincipalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L260)

## Properties

### update\_allowed\_principals\_result

> **update\_allowed\_principals\_result**: \[\] \| \[[`UpdateAllowedPrincipalsResult`](../type-aliases/UpdateAllowedPrincipalsResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L261)
