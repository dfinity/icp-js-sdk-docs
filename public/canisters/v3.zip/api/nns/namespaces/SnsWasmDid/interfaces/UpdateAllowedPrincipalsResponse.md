---
title: UpdateAllowedPrincipalsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L260)

## Properties

### update\_allowed\_principals\_result

> **update\_allowed\_principals\_result**: \[\] \| \[[`UpdateAllowedPrincipalsResult`](../type-aliases/UpdateAllowedPrincipalsResult.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:261](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L261)
