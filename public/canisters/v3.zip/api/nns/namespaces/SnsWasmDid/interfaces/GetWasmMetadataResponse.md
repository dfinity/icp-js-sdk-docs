---
title: GetWasmMetadataResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L92)

## Properties

### result

> **result**: \[\] \| \[[`Result_1`](../type-aliases/Result_1.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L93)
