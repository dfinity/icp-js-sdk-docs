---
title: GetWasmResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L98)

## Properties

### wasm

> **wasm**: \[\] \| \[[`SnsWasm`](SnsWasm.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L99)
