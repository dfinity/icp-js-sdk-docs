---
title: _SERVICE
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:273](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L273)

## Properties

### add\_wasm

> **add\_wasm**: `ActorMethod`\<\[[`AddWasmRequest`](AddWasmRequest.md)\], [`AddWasmResponse`](AddWasmResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:274](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L274)

***

### deploy\_new\_sns

> **deploy\_new\_sns**: `ActorMethod`\<\[[`DeployNewSnsRequest`](DeployNewSnsRequest.md)\], [`DeployNewSnsResponse`](DeployNewSnsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:275](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L275)

***

### get\_allowed\_principals

> **get\_allowed\_principals**: `ActorMethod`\<\[\{ \}\], [`GetAllowedPrincipalsResponse`](GetAllowedPrincipalsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:276](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L276)

***

### get\_deployed\_sns\_by\_proposal\_id

> **get\_deployed\_sns\_by\_proposal\_id**: `ActorMethod`\<\[[`GetDeployedSnsByProposalIdRequest`](GetDeployedSnsByProposalIdRequest.md)\], [`GetDeployedSnsByProposalIdResponse`](GetDeployedSnsByProposalIdResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:277](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L277)

***

### get\_latest\_sns\_version\_pretty

> **get\_latest\_sns\_version\_pretty**: `ActorMethod`\<\[`null`\], \[`string`, `string`\][]\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:281](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L281)

***

### get\_next\_sns\_version

> **get\_next\_sns\_version**: `ActorMethod`\<\[[`GetNextSnsVersionRequest`](GetNextSnsVersionRequest.md)\], [`GetNextSnsVersionResponse`](GetNextSnsVersionResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:282](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L282)

***

### get\_proposal\_id\_that\_added\_wasm

> **get\_proposal\_id\_that\_added\_wasm**: `ActorMethod`\<\[[`GetProposalIdThatAddedWasmRequest`](GetProposalIdThatAddedWasmRequest.md)\], [`GetProposalIdThatAddedWasmResponse`](GetProposalIdThatAddedWasmResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:286](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L286)

***

### get\_sns\_subnet\_ids

> **get\_sns\_subnet\_ids**: `ActorMethod`\<\[\{ \}\], [`GetSnsSubnetIdsResponse`](GetSnsSubnetIdsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L290)

***

### get\_wasm

> **get\_wasm**: `ActorMethod`\<\[[`GetWasmRequest`](GetWasmRequest.md)\], [`GetWasmResponse`](GetWasmResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L291)

***

### get\_wasm\_metadata

> **get\_wasm\_metadata**: `ActorMethod`\<\[[`GetWasmMetadataRequest`](GetWasmMetadataRequest.md)\], [`GetWasmMetadataResponse`](GetWasmMetadataResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L292)

***

### insert\_upgrade\_path\_entries

> **insert\_upgrade\_path\_entries**: `ActorMethod`\<\[[`InsertUpgradePathEntriesRequest`](InsertUpgradePathEntriesRequest.md)\], [`InsertUpgradePathEntriesResponse`](InsertUpgradePathEntriesResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:296](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L296)

***

### list\_deployed\_snses

> **list\_deployed\_snses**: `ActorMethod`\<\[\{ \}\], [`ListDeployedSnsesResponse`](ListDeployedSnsesResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:300](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L300)

***

### list\_upgrade\_steps

> **list\_upgrade\_steps**: `ActorMethod`\<\[[`ListUpgradeStepsRequest`](ListUpgradeStepsRequest.md)\], [`ListUpgradeStepsResponse`](ListUpgradeStepsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:301](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L301)

***

### update\_allowed\_principals

> **update\_allowed\_principals**: `ActorMethod`\<\[[`UpdateAllowedPrincipalsRequest`](UpdateAllowedPrincipalsRequest.md)\], [`UpdateAllowedPrincipalsResponse`](UpdateAllowedPrincipalsResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:305](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L305)

***

### update\_sns\_subnet\_list

> **update\_sns\_subnet\_list**: `ActorMethod`\<\[[`UpdateSnsSubnetListRequest`](UpdateSnsSubnetListRequest.md)\], [`UpdateSnsSubnetListResponse`](UpdateSnsSubnetListResponse.md)\>

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L309)
