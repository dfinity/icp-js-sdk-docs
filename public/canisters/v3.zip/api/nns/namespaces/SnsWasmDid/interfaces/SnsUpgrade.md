---
title: SnsUpgrade
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:224](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L224)

## Properties

### current\_version

> **current\_version**: \[\] \| \[[`SnsVersion`](SnsVersion.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:226](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L226)

***

### next\_version

> **next\_version**: \[\] \| \[[`SnsVersion`](SnsVersion.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:225](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L225)
