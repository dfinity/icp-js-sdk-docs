---
title: SnsUpgrade
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L228)

## Properties

### current\_version

> **current\_version**: \[\] \| \[[`SnsVersion`](SnsVersion.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L230)

***

### next\_version

> **next\_version**: \[\] \| \[[`SnsVersion`](SnsVersion.md)\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L229)
