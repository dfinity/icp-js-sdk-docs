---
title: ListUpgradeStepsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:133](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L133)

## Properties

### steps

> **steps**: [`ListUpgradeStep`](ListUpgradeStep.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:134](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L134)
