---
title: InsertUpgradePathEntriesRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L107)

## Properties

### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:109](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L109)

***

### upgrade\_path

> **upgrade\_path**: [`SnsUpgrade`](SnsUpgrade.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L108)
