---
title: InsertUpgradePathEntriesRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:110](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L110)

## Properties

### sns\_governance\_canister\_id

> **sns\_governance\_canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:112](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L112)

***

### upgrade\_path

> **upgrade\_path**: [`SnsUpgrade`](SnsUpgrade.md)[]

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:111](https://github.com/dfinity/icp-js-canisters/blob/0536d7b52f4da3bd092a7ec0f295b8c064d19dd4/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L111)
