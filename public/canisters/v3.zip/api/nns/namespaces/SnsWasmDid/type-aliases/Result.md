---
title: Result
editUrl: false
next: true
prev: true
---

> **Result** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `Hash`: `Uint8Array`; \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:171](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L171)
