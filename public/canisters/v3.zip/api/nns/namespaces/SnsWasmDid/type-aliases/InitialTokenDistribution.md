---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

> **InitialTokenDistribution** = `object`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:104](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L104)

## Properties

### FractionalDeveloperVotingPower

> **FractionalDeveloperVotingPower**: [`FractionalDeveloperVotingPower`](../interfaces/FractionalDeveloperVotingPower.md)

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:105](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L105)
