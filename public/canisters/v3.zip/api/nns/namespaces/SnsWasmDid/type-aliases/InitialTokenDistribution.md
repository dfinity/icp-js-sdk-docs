---
title: InitialTokenDistribution
editUrl: false
next: true
prev: true
---

> **InitialTokenDistribution** = `object`

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:107](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L107)

## Properties

### FractionalDeveloperVotingPower

> **FractionalDeveloperVotingPower**: [`FractionalDeveloperVotingPower`](../interfaces/FractionalDeveloperVotingPower.md)

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:108](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L108)
