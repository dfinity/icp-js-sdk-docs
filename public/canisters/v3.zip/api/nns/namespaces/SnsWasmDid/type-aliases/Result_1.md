---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L172)
