---
title: Result_1
editUrl: false
next: true
prev: true
---

> **Result\_1** = \{ `Ok`: [`Ok`](../interfaces/Ok.md); \} \| \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:172](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L172)
