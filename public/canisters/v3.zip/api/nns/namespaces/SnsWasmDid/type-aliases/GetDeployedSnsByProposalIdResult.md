---
title: GetDeployedSnsByProposalIdResult
editUrl: false
next: true
prev: true
---

> **GetDeployedSnsByProposalIdResult** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `DeployedSns`: [`DeployedSns`](../interfaces/DeployedSns.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:73](https://github.com/dfinity/icp-js-canisters/blob/564356cc13fcb8023ba2c14a30d6ea99d3a1c9b1/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L73)
