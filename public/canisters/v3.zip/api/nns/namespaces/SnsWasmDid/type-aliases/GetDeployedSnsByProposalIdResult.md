---
title: GetDeployedSnsByProposalIdResult
editUrl: false
next: true
prev: true
---

> **GetDeployedSnsByProposalIdResult** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `DeployedSns`: [`DeployedSns`](../interfaces/DeployedSns.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/fe1c4794ec09298905fd2abc3761c29cc98fe647/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L70)
