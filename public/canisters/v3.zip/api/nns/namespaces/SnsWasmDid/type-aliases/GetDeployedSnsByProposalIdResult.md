---
title: GetDeployedSnsByProposalIdResult
editUrl: false
next: true
prev: true
---

> **GetDeployedSnsByProposalIdResult** = \{ `Error`: [`SnsWasmError`](../interfaces/SnsWasmError.md); \} \| \{ `DeployedSns`: [`DeployedSns`](../interfaces/DeployedSns.md); \}

Defined in: [packages/canisters/src/declarations/nns/sns\_wasm.d.ts:70](https://github.com/dfinity/icp-js-canisters/blob/712670ce691071e7379a86cba0371eb90c6d946f/packages/canisters/src/declarations/nns/sns_wasm.d.ts#L70)
