---
title: InstallChunkedCodeParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:93](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L93)

## Extends

- `Omit`\<[`InstallCodeParams`](InstallCodeParams.md), `"canisterId"` \| `"wasmModule"`\>

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:74](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L74)

#### Inherited from

[`InstallCodeParams`](InstallCodeParams.md).[`arg`](InstallCodeParams.md#arg)

***

### chunkHashesList

> **chunkHashesList**: [`chunk_hash`](../namespaces/IcManagementDid/interfaces/chunk_hash.md)[]

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:97](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L97)

***

### mode

> **mode**: [`canister_install_mode`](../namespaces/IcManagementDid/type-aliases/canister_install_mode.md)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:71](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L71)

#### Inherited from

[`InstallCodeParams`](InstallCodeParams.md).[`mode`](InstallCodeParams.md#mode)

***

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:75](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L75)

#### Inherited from

[`InstallCodeParams`](InstallCodeParams.md).[`senderCanisterVersion`](InstallCodeParams.md#sendercanisterversion)

***

### storeCanisterId?

> `optional` **storeCanisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:99](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L99)

***

### targetCanisterId

> **targetCanisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:98](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L98)

***

### wasmModuleHash

> **wasmModuleHash**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:100](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.params.ts#L100)
