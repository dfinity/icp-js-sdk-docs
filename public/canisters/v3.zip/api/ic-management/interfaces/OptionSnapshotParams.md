---
title: OptionSnapshotParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:9](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L9)

## Extended by

- [`UploadCanisterSnapshotMetadataParams`](UploadCanisterSnapshotMetadataParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

***

### snapshotId?

> `optional` **snapshotId**: `string` \| [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)
