---
title: OptionSnapshotParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:9](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L9)

## Extended by

- [`UploadCanisterSnapshotMetadataParams`](UploadCanisterSnapshotMetadataParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

***

### snapshotId?

> `optional` **snapshotId**: `string` \| [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)
