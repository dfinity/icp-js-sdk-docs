---
title: CreateCanisterParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:59](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L59)

## Properties

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:61](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L61)

***

### settings?

> `optional` **settings**: [`CanisterSettings`](CanisterSettings.md)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:60](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L60)
