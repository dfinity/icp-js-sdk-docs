---
title: CanisterSettings
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L10)

## Properties

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L14)

***

### controllers?

> `optional` **controllers**: `string`[]

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L11)

***

### environmentVariables?

> `optional` **environmentVariables**: [`environment_variable`](../namespaces/IcManagementDid/interfaces/environment_variable.md)[]

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:19](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L19)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:12](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L12)

***

### logVisibility?

> `optional` **logVisibility**: [`LogVisibility`](../enumerations/LogVisibility.md)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:16](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L16)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:13](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L13)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:15](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L15)

***

### wasmMemoryLimit?

> `optional` **wasmMemoryLimit**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:17](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L17)

***

### wasmMemoryThreshold?

> `optional` **wasmMemoryThreshold**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:18](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L18)
