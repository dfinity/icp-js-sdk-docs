---
title: ReadCanisterSnapshotMetadataResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:4](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L4)

## Properties

### canisterVersion

> **canisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:12](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L12)

***

### certifiedData

> **certifiedData**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:14](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L14)

***

### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:5](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L5)

***

### globalTimer?

> `optional` **globalTimer**: \{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:15](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L15)

***

### onLowWasmMemoryHookStatus?

> `optional` **onLowWasmMemoryHookStatus**: \{ `conditionNotSatisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:16](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L16)

***

### source

> **source**: \{ `metadataUpload`: `unknown`; \} \| \{ `takenFromCanister`: `unknown`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:13](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L13)

***

### stableMemorySize

> **stableMemorySize**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:21](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L21)

***

### takenAtTimestamp

> **takenAtTimestamp**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:23](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L23)

***

### wasmChunkStore

> **wasmChunkStore**: `object`[]

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:22](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L22)

#### hash

> **hash**: `Uint8Array`

***

### wasmMemorySize

> **wasmMemorySize**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:24](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L24)

***

### wasmModuleSize

> **wasmModuleSize**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:20](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.responses.ts#L20)
