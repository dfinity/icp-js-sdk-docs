---
title: InstallCodeParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:70](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L70)

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:74](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L74)

***

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L72)

***

### mode

> **mode**: [`canister_install_mode`](../namespaces/IcManagementDid/type-aliases/canister_install_mode.md)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:71](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L71)

***

### senderCanisterVersion?

> `optional` **senderCanisterVersion**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:75](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L75)

***

### wasmModule

> **wasmModule**: `Uint8Array`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:73](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/ic-management.params.ts#L73)
