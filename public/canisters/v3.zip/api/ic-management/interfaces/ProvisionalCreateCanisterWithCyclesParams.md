---
title: ProvisionalCreateCanisterWithCyclesParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:108](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L108)

## Properties

### amount?

> `optional` **amount**: `bigint`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:109](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L109)

***

### canisterId?

> `optional` **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:111](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L111)

***

### settings?

> `optional` **settings**: [`CanisterSettings`](CanisterSettings.md)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:110](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.params.ts#L110)
