---
title: ReadCanisterSnapshotDataParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:43](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L43)

## Extends

- [`SnapshotParams`](../type-aliases/SnapshotParams.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:10](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L10)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`canisterId`](OptionSnapshotParams.md#canisterid)

***

### kind

> **kind**: [`CanisterSnapshotMetadataKind`](../type-aliases/CanisterSnapshotMetadataKind.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:44](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L44)

***

### snapshotId

> **snapshotId**: `string` \| [`snapshot_id`](../namespaces/IcManagementDid/type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:11](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L11)

#### Inherited from

[`OptionSnapshotParams`](OptionSnapshotParams.md).[`snapshotId`](OptionSnapshotParams.md#snapshotid)
