---
title: CanisterStatusResponse
editUrl: false
next: true
prev: true
---

> **CanisterStatusResponse** = `ServiceResponse`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md), `"canister_status"`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.responses.ts:4](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/ic-management.responses.ts#L4)
