---
title: CanisterStatusResponse
editUrl: false
next: true
prev: true
---

> **CanisterStatusResponse** = `ServiceResponse`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md), `"canister_status"`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.responses.ts:4](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/ic-management.responses.ts#L4)
