---
title: UploadCanisterSnapshotMetadataParam
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotMetadataParam** = `Pick`\<[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md), `"globals"` \| `"certifiedData"` \| `"globalTimer"` \| `"onLowWasmMemoryHookStatus"` \| `"wasmModuleSize"` \| `"stableMemorySize"` \| `"wasmMemorySize"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:72](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L72)
