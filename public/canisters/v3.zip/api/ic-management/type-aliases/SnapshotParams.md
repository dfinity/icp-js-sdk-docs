---
title: SnapshotParams
editUrl: false
next: true
prev: true
---

> **SnapshotParams** = `Required`\<[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:14](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/snapshot.params.ts#L14)
