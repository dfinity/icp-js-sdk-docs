---
title: SnapshotIdText
editUrl: false
next: true
prev: true
---

> **SnapshotIdText** = `string`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L7)
