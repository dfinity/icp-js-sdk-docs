---
title: SnapshotIdText
editUrl: false
next: true
prev: true
---

> **SnapshotIdText** = `string`

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L7)
