---
title: UploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotDataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmChunk`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:123](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L123)
