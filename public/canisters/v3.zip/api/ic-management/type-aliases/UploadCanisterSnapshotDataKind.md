---
title: UploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotDataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmChunk`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:126](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/snapshot.params.ts#L126)
