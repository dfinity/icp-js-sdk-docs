---
title: UploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **UploadCanisterSnapshotDataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasmChunk`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:123](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L123)
