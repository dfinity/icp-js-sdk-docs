---
title: CanisterSnapshotMetadataKind
editUrl: false
next: true
prev: true
---

> **CanisterSnapshotMetadataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmChunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:37](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L37)
