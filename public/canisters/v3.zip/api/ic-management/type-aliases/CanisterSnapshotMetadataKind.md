---
title: CanisterSnapshotMetadataKind
editUrl: false
next: true
prev: true
---

> **CanisterSnapshotMetadataKind** = \{ `wasmModule`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stableMemory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasmChunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:40](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/snapshot.params.ts#L40)
