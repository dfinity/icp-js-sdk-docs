---
title: FetchCanisterLogsResponse
editUrl: false
next: true
prev: true
---

> **FetchCanisterLogsResponse** = `ServiceResponse`\<[`_SERVICE`](../namespaces/IcManagementDid/interfaces/SERVICE.md), `"fetch_canister_logs"`\>

Defined in: [packages/canisters/src/ic-management/types/ic-management.responses.ts:9](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/ic-management.responses.ts#L9)
