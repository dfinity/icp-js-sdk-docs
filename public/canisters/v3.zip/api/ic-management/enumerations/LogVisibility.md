---
title: LogVisibility
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:5](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/ic-management.params.ts#L5)

## Enumeration Members

### Controllers

> **Controllers**: `0`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:6](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/ic-management.params.ts#L6)

***

### Public

> **Public**: `1`

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:7](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/ic-management.params.ts#L7)
