---
title: toCanisterSettings
editUrl: false
next: true
prev: true
---

> **toCanisterSettings**(`__namedParameters`): [`canister_settings`](../namespaces/IcManagementDid/interfaces/canister_settings.md)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:24](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/types/ic-management.params.ts#L24)

## Parameters

### \_\_namedParameters

[`CanisterSettings`](../interfaces/CanisterSettings.md) = `{}`

## Returns

[`canister_settings`](../namespaces/IcManagementDid/interfaces/canister_settings.md)
