---
title: toCanisterSettings
editUrl: false
next: true
prev: true
---

> **toCanisterSettings**(`__namedParameters`): [`canister_settings`](../namespaces/IcManagementDid/interfaces/canister_settings.md)

Defined in: [packages/canisters/src/ic-management/types/ic-management.params.ts:24](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/ic-management.params.ts#L24)

## Parameters

### \_\_namedParameters

[`CanisterSettings`](../interfaces/CanisterSettings.md) = `{}`

## Returns

[`canister_settings`](../namespaces/IcManagementDid/interfaces/canister_settings.md)
