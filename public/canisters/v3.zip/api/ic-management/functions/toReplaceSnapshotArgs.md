---
title: toReplaceSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toReplaceSnapshotArgs**(`__namedParameters`): [`take_canister_snapshot_args`](../namespaces/IcManagementDid/interfaces/take_canister_snapshot_args.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:27](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/ic-management/types/snapshot.params.ts#L27)

## Parameters

### \_\_namedParameters

[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)

## Returns

[`take_canister_snapshot_args`](../namespaces/IcManagementDid/interfaces/take_canister_snapshot_args.md)
