---
title: toReplaceSnapshotArgs
editUrl: false
next: true
prev: true
---

> **toReplaceSnapshotArgs**(`__namedParameters`): `Pick`\<[`take_canister_snapshot_args`](../namespaces/IcManagementDid/interfaces/take_canister_snapshot_args.md), `"canister_id"` \| `"replace_snapshot"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:27](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/ic-management/types/snapshot.params.ts#L27)

## Parameters

### \_\_namedParameters

[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)

## Returns

`Pick`\<[`take_canister_snapshot_args`](../namespaces/IcManagementDid/interfaces/take_canister_snapshot_args.md), `"canister_id"` \| `"replace_snapshot"`\>
