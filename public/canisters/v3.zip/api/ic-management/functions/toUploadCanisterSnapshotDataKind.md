---
title: toUploadCanisterSnapshotDataKind
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotDataKind**(`kind`): \{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:141](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/snapshot.params.ts#L141)

## Parameters

### kind

[`UploadCanisterSnapshotDataKind`](../type-aliases/UploadCanisterSnapshotDataKind.md)

## Returns

\{ `wasm_module`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; \}; \} \| \{ `wasm_chunk`: `null`; \}
