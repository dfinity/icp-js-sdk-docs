---
title: toUploadCanisterSnapshotMetadata
editUrl: false
next: true
prev: true
---

> **toUploadCanisterSnapshotMetadata**(`__namedParameters`): `Omit`\<[`upload_canister_snapshot_metadata_args`](../namespaces/IcManagementDid/interfaces/upload_canister_snapshot_metadata_args.md), `"canister_id"` \| `"replace_snapshot"`\>

Defined in: [packages/canisters/src/ic-management/types/snapshot.params.ts:84](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/ic-management/types/snapshot.params.ts#L84)

## Parameters

### \_\_namedParameters

[`UploadCanisterSnapshotMetadataParam`](../type-aliases/UploadCanisterSnapshotMetadataParam.md)

## Returns

`Omit`\<[`upload_canister_snapshot_metadata_args`](../namespaces/IcManagementDid/interfaces/upload_canister_snapshot_metadata_args.md), `"canister_id"` \| `"replace_snapshot"`\>
