---
title: fromReadCanisterSnapshotMetadataResponse
editUrl: false
next: true
prev: true
---

> **fromReadCanisterSnapshotMetadataResponse**(`__namedParameters`): [`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)

Defined in: [packages/canisters/src/ic-management/types/snapshot.responses.ts:27](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/ic-management/types/snapshot.responses.ts#L27)

## Parameters

### \_\_namedParameters

[`read_canister_snapshot_metadata_response`](../namespaces/IcManagementDid/interfaces/read_canister_snapshot_metadata_response.md)

## Returns

[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)
