---
title: IcManagementCanister
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:50](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L50)

## Methods

### canisterStatus()

> **canisterStatus**(`params`): `Promise`\<[`canister_status_result`](../namespaces/IcManagementDid/interfaces/canister_status_result.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:296](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L296)

Get canister details (memory size, status, etc.)

#### Parameters

##### params

[`CanisterStatusParams`](../interfaces/CanisterStatusParams.md)

The parameters for the status call.

#### Returns

`Promise`\<[`canister_status_result`](../namespaces/IcManagementDid/interfaces/canister_status_result.md)\>

A promise that resolves with the canister status details.

***

### clearChunkStore()

> **clearChunkStore**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:177](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L177)

Clear the entire chunk storage of a canister.

#### Parameters

##### params

[`ClearChunkStoreParams`](../interfaces/ClearChunkStoreParams.md)

#### Returns

`Promise`\<`void`\>

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-clear_chunk_store

***

### createCanister()

> **createCanister**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:83](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L83)

Create a new canister

#### Parameters

##### params

[`CreateCanisterParams`](../interfaces/CreateCanisterParams.md) = `{}`

#### Returns

`Promise`\<`Principal`\>

***

### deleteCanister()

> **deleteCanister**(`canisterId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:313](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L313)

Deletes a canister

#### Parameters

##### canisterId

`Principal`

#### Returns

`Promise`\<`void`\>

***

### deleteCanisterSnapshot()

> **deleteCanisterSnapshot**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:461](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L461)

Deletes a specific snapshot of a canister.

#### Parameters

##### params

[`SnapshotParams`](../type-aliases/SnapshotParams.md)

Parameters for the deletion operation.

#### Returns

`Promise`\<`void`\>

A promise that resolves when the snapshot is successfully deleted.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-delete_canister_snapshot

#### Throws

If the deletion operation fails.

***

### fetchCanisterLogs()

> **fetchCanisterLogs**(`canisterId`): `Promise`\<[`fetch_canister_logs_result`](../namespaces/IcManagementDid/interfaces/fetch_canister_logs_result.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:351](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L351)

Given a canister ID as input, this method returns a vector of logs of that canister including its trap messages. The canister logs are not collected in canister methods running in non-replicated mode (NRQ, CQ, CRy, CRt, CC, and F modes, as defined in Overview of imports). The total size of all returned logs does not exceed 4KiB. If new logs are added resulting in exceeding the maximum total log size of 4KiB, the oldest logs will be removed. Logs persist across canister upgrades and they are deleted if the canister is reinstalled or uninstalled.

#### Parameters

##### canisterId

`Principal`

#### Returns

`Promise`\<[`fetch_canister_logs_result`](../namespaces/IcManagementDid/interfaces/fetch_canister_logs_result.md)\>

***

### installChunkedCode()

> **installChunkedCode**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:221](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L221)

Installs code that had previously been uploaded in chunks.

#### Parameters

##### params

[`InstallChunkedCodeParams`](../interfaces/InstallChunkedCodeParams.md)

#### Returns

`Promise`\<`void`\>

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-install_chunked_code

***

### installCode()

> **installCode**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:131](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L131)

Install code to a canister

#### Parameters

##### params

[`InstallCodeParams`](../interfaces/InstallCodeParams.md)

#### Returns

`Promise`\<`void`\>

***

### listCanisterSnapshots()

> **listCanisterSnapshots**(`params`): `Promise`\<[`list_canister_snapshots_result`](../namespaces/IcManagementDid/type-aliases/list_canister_snapshots_result.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:408](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L408)

Lists the snapshots of a canister.

#### Parameters

##### params

Parameters for the listing operation.

###### canisterId

`Principal`

The ID of the canister for which snapshots will be listed.

#### Returns

`Promise`\<[`list_canister_snapshots_result`](../namespaces/IcManagementDid/type-aliases/list_canister_snapshots_result.md)\>

A promise that resolves with the list of snapshots.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-list_canister_snapshots

#### Throws

If the operation fails.

***

### loadCanisterSnapshot()

> **loadCanisterSnapshot**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:434](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L434)

Loads a snapshot of a canister's state.

#### Parameters

##### params

`Required`\<[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md)\> & `object`

Parameters for the snapshot loading operation.

#### Returns

`Promise`\<`void`\>

A promise that resolves when the snapshot is successfully loaded.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-load_canister_snapshot

#### Throws

If the snapshot loading operation fails.

***

### provisionalCreateCanisterWithCycles()

> **provisionalCreateCanisterWithCycles**(`params`): `Promise`\<`Principal`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:328](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L328)

Creates a canister. Only available on development instances.

#### Parameters

##### params

[`ProvisionalCreateCanisterWithCyclesParams`](../interfaces/ProvisionalCreateCanisterWithCyclesParams.md) = `{}`

#### Returns

`Promise`\<`Principal`\>

***

### readCanisterSnapshotData()

> **readCanisterSnapshotData**(`params`): `Promise`\<[`read_canister_snapshot_data_response`](../namespaces/IcManagementDid/interfaces/read_canister_snapshot_data_response.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:506](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L506)

Reads snapshot data for a specific canister snapshot and kind.

#### Parameters

##### params

[`ReadCanisterSnapshotDataParams`](../interfaces/ReadCanisterSnapshotDataParams.md)

Parameters for the data read operation.

#### Returns

`Promise`\<[`read_canister_snapshot_data_response`](../namespaces/IcManagementDid/interfaces/read_canister_snapshot_data_response.md)\>

A promise that resolves with the snapshot data payload.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-read_canister_snapshot_data

#### Throws

If the data read operation fails.

***

### readCanisterSnapshotMetadata()

> **readCanisterSnapshotMetadata**(`params`): `Promise`\<[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:480](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L480)

Reads metadata for a specific canister snapshot.

#### Parameters

##### params

[`SnapshotParams`](../type-aliases/SnapshotParams.md)

Parameters for the metadata read operation.

#### Returns

`Promise`\<[`ReadCanisterSnapshotMetadataResponse`](../interfaces/ReadCanisterSnapshotMetadataResponse.md)\>

A promise that resolves with the snapshot metadata.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-read_canister_snapshot_metadata

#### Throws

If the metadata read operation fails.

***

### startCanister()

> **startCanister**(`canisterId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:270](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L270)

Start a canister

#### Parameters

##### canisterId

`Principal`

#### Returns

`Promise`\<`void`\>

***

### stopCanister()

> **stopCanister**(`canisterId`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:282](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L282)

Stop a canister

#### Parameters

##### canisterId

`Principal`

#### Returns

`Promise`\<`void`\>

***

### storedChunks()

> **storedChunks**(`params`): `Promise`\<[`chunk_hash`](../namespaces/IcManagementDid/interfaces/chunk_hash.md)[]\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:196](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L196)

List the hashes of chunks in the chunk storage of a canister.

#### Parameters

##### params

[`StoredChunksParams`](../interfaces/StoredChunksParams.md)

#### Returns

`Promise`\<[`chunk_hash`](../namespaces/IcManagementDid/interfaces/chunk_hash.md)[]\>

The list of hash of the stored chunks.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-stored_chunks

***

### takeCanisterSnapshot()

> **takeCanisterSnapshot**(`params`): `Promise`\<[`snapshot`](../namespaces/IcManagementDid/interfaces/snapshot.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:379](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L379)

This method takes a snapshot of the specified canister. A snapshot consists of the wasm memory, stable memory, certified variables, wasm chunk store and wasm binary.

#### Parameters

##### params

[`OptionSnapshotParams`](../interfaces/OptionSnapshotParams.md) & `object`

Parameters for the snapshot operation.

#### Returns

`Promise`\<[`snapshot`](../namespaces/IcManagementDid/interfaces/snapshot.md)\>

A promise that resolves with the snapshot details,
including the snapshot ID, total size, and timestamp.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-take_canister_snapshot

#### Throws

If the snapshot operation fails.

***

### uninstallCode()

> **uninstallCode**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:252](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L252)

Uninstall code from a canister

#### Parameters

##### params

[`UninstallCodeParams`](../interfaces/UninstallCodeParams.md)

#### Returns

`Promise`\<`void`\>

***

### updateSettings()

> **updateSettings**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:106](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L106)

Update canister settings

#### Parameters

##### params

[`UpdateSettingsParams`](../interfaces/UpdateSettingsParams.md)

#### Returns

`Promise`\<`void`\>

***

### uploadCanisterSnapshotData()

> **uploadCanisterSnapshotData**(`params`): `Promise`\<`void`\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:559](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L559)

Uploads a chunk of snapshot data for a canister snapshot.

#### Parameters

##### params

[`UploadCanisterSnapshotDataParams`](../interfaces/UploadCanisterSnapshotDataParams.md)

Parameters for the data upload operation.

#### Returns

`Promise`\<`void`\>

A promise that resolves when the data is successfully uploaded.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-upload_canister_snapshot_data

#### Throws

If the data upload operation fails.

***

### uploadCanisterSnapshotMetadata()

> **uploadCanisterSnapshotMetadata**(`params`): `Promise`\<[`upload_canister_snapshot_metadata_response`](../namespaces/IcManagementDid/interfaces/upload_canister_snapshot_metadata_response.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:532](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L532)

Uploads snapshot metadata for a canister.

#### Parameters

##### params

[`UploadCanisterSnapshotMetadataParams`](../interfaces/UploadCanisterSnapshotMetadataParams.md)

Parameters for the metadata upload operation.

#### Returns

`Promise`\<[`upload_canister_snapshot_metadata_response`](../namespaces/IcManagementDid/interfaces/upload_canister_snapshot_metadata_response.md)\>

A promise that resolves with the upload response.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec#ic-upload_canister_snapshot_metadata

#### Throws

If the metadata upload operation fails.

***

### uploadChunk()

> **uploadChunk**(`params`): `Promise`\<[`chunk_hash`](../namespaces/IcManagementDid/interfaces/chunk_hash.md)\>

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:157](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L157)

Upload chunks of Wasm modules that are too large to fit in a single message for installation purposes.

#### Parameters

##### params

[`UploadChunkParams`](../interfaces/UploadChunkParams.md)

#### Returns

`Promise`\<[`chunk_hash`](../namespaces/IcManagementDid/interfaces/chunk_hash.md)\>

The hash of the stored chunk.

#### Link

https://internetcomputer.org/docs/current/references/ic-interface-spec/#ic-upload_chunk

***

### create()

> `static` **create**(`options`): `IcManagementCanister`

Defined in: [packages/canisters/src/ic-management/ic-management.canister.ts:59](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/ic-management/ic-management.canister.ts#L59)

#### Parameters

##### options

[`IcManagementCanisterOptions`](../type-aliases/IcManagementCanisterOptions.md)

#### Returns

`IcManagementCanister`
