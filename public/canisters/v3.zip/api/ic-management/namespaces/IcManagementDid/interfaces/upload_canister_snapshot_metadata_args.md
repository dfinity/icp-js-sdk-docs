---
title: upload_canister_snapshot_metadata_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:419](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L419)

## Properties

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:438](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L438)

***

### certified\_data

> **certified\_data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:428](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L428)

***

### global\_timer

> **global\_timer**: \[\] \| \[\{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L429)

***

### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:420](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L420)

***

### on\_low\_wasm\_memory\_hook\_status

> **on\_low\_wasm\_memory\_hook\_status**: \[\] \| \[\{ `condition_not_satisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L430)

***

### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[[`snapshot_id`](../type-aliases/snapshot_id.md)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:427](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L427)

***

### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L439)

***

### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L440)

***

### wasm\_module\_size

> **wasm\_module\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:437](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L437)
