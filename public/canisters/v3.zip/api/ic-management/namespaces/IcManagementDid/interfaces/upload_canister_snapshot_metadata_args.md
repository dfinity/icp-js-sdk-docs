---
title: upload_canister_snapshot_metadata_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:421](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L421)

## Properties

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:440](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L440)

***

### certified\_data

> **certified\_data**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:430](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L430)

***

### global\_timer

> **global\_timer**: \[\] \| \[\{ `active`: `bigint`; \} \| \{ `inactive`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:431](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L431)

***

### globals

> **globals**: (\{ `f32`: `number`; \} \| \{ `f64`: `number`; \} \| \{ `i32`: `number`; \} \| \{ `i64`: `bigint`; \} \| \{ `v128`: `bigint`; \})[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:422](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L422)

***

### on\_low\_wasm\_memory\_hook\_status

> **on\_low\_wasm\_memory\_hook\_status**: \[\] \| \[\{ `condition_not_satisfied`: `null`; \} \| \{ `executed`: `null`; \} \| \{ `ready`: `null`; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:432](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L432)

***

### replace\_snapshot

> **replace\_snapshot**: \[\] \| \[[`snapshot_id`](../type-aliases/snapshot_id.md)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:429](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L429)

***

### stable\_memory\_size

> **stable\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:441](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L441)

***

### wasm\_memory\_size

> **wasm\_memory\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:442](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L442)

***

### wasm\_module\_size

> **wasm\_module\_size**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:439](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L439)
