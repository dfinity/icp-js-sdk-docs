---
title: bitcoin_get_current_fee_percentiles_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:32](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L32)

## Properties

### network

> **network**: [`bitcoin_network`](../type-aliases/bitcoin_network.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:33](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L33)
