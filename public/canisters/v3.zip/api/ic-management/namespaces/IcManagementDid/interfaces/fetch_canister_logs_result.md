---
title: fetch_canister_logs_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:220](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L220)

## Properties

### canister\_log\_records

> **canister\_log\_records**: [`canister_log_record`](canister_log_record.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:221](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L221)
