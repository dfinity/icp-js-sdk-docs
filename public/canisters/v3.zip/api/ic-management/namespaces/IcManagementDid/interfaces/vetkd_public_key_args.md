---
title: vetkd_public_key_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:465](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L465)

## Properties

### canister\_id

> **canister\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:468](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L468)

***

### context

> **context**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:466](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L466)

***

### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:467](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L467)

#### curve

> **curve**: [`vetkd_curve`](../type-aliases/vetkd_curve.md)

#### name

> **name**: `string`
