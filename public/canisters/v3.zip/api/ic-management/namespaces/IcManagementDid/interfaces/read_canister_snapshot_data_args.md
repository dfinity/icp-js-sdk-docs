---
title: read_canister_snapshot_data_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:302](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L302)

## Properties

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:308](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L308)

***

### kind

> **kind**: \{ `wasm_module`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `stable_memory`: \{ `offset`: `bigint`; `size`: `bigint`; \}; \} \| \{ `wasm_chunk`: \{ `hash`: `Uint8Array`; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:303](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L303)

***

### snapshot\_id

> **snapshot\_id**: [`snapshot_id`](../type-aliases/snapshot_id.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:309](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L309)
