---
title: bitcoin_get_block_headers_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:28](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L28)

## Properties

### block\_headers

> **block\_headers**: [`bitcoin_block_header`](../type-aliases/bitcoin_block_header.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:30](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L30)

***

### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:29](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L29)
