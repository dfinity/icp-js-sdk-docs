---
title: bitcoin_get_balance_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:17](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L17)

## Properties

### address

> **address**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:19](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L19)

***

### min\_confirmations

> **min\_confirmations**: \[`number`\] \| \[\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:20](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L20)

***

### network

> **network**: [`bitcoin_network`](../type-aliases/bitcoin_network.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:18](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L18)
