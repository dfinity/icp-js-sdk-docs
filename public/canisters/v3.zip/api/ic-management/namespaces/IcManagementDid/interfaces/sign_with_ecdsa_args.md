---
title: sign_with_ecdsa_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:355](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L355)

## Properties

### derivation\_path

> **derivation\_path**: `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:357](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L357)

***

### key\_id

> **key\_id**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:356](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L356)

#### curve

> **curve**: [`ecdsa_curve`](../type-aliases/ecdsa_curve.md)

#### name

> **name**: `string`

***

### message\_hash

> **message\_hash**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:358](https://github.com/dfinity/icp-js-canisters/blob/2a1f5c1693ac346fa7b0112a62b2174566861fb5/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L358)
