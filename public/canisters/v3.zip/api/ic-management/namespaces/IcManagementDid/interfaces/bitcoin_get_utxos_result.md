---
title: bitcoin_get_utxos_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:41](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L41)

## Properties

### next\_page

> **next\_page**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:42](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L42)

***

### tip\_block\_hash

> **tip\_block\_hash**: [`bitcoin_block_hash`](../type-aliases/bitcoin_block_hash.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:44](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L44)

***

### tip\_height

> **tip\_height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:43](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L43)

***

### utxos

> **utxos**: [`utxo`](utxo.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:45](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L45)
