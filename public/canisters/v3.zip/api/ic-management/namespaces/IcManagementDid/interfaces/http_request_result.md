---
title: http_request_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:236](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L236)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:238](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L238)

***

### headers

> **headers**: [`http_header`](http_header.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:239](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L239)

***

### status

> **status**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:237](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L237)
