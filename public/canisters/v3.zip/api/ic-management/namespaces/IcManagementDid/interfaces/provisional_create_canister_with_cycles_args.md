---
title: provisional_create_canister_with_cycles_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:288](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L288)

## Properties

### amount

> **amount**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:291](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L291)

***

### sender\_canister\_version

> **sender\_canister\_version**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:292](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L292)

***

### settings

> **settings**: \[\] \| \[[`canister_settings`](canister_settings.md)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:289](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L289)

***

### specified\_id

> **specified\_id**: \[\] \| \[`Principal`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:290](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L290)
