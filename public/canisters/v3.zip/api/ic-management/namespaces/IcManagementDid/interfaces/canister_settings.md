---
title: canister_settings
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:90](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L90)

## Properties

### compute\_allocation

> **compute\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:99](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L99)

***

### controllers

> **controllers**: \[\] \| \[`Principal`[]\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:94](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L94)

***

### environment\_variables

> **environment\_variables**: \[\] \| \[[`environment_variable`](environment_variable.md)[]\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:93](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L93)

***

### freezing\_threshold

> **freezing\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:91](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L91)

***

### log\_visibility

> **log\_visibility**: \[\] \| \[[`log_visibility`](../type-aliases/log_visibility.md)\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:96](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L96)

***

### memory\_allocation

> **memory\_allocation**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:98](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L98)

***

### reserved\_cycles\_limit

> **reserved\_cycles\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:95](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L95)

***

### wasm\_memory\_limit

> **wasm\_memory\_limit**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:97](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L97)

***

### wasm\_memory\_threshold

> **wasm\_memory\_threshold**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:92](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L92)
