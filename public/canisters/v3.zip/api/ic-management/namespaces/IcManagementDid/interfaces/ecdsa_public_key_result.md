---
title: ecdsa_public_key_result
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:209](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L209)

## Properties

### chain\_code

> **chain\_code**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:211](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L211)

***

### public\_key

> **public\_key**: `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:210](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L210)
