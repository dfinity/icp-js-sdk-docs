---
title: canister_info_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:53](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L53)

## Properties

### canister\_id

> **canister\_id**: `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:54](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L54)

***

### num\_requested\_changes

> **num\_requested\_changes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:55](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L55)
