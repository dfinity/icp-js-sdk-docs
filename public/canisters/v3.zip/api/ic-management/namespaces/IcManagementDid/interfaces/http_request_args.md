---
title: http_request_args
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:227](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L227)

## Properties

### body

> **body**: \[\] \| \[`Uint8Array`\<`ArrayBufferLike`\>\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:231](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L231)

***

### headers

> **headers**: [`http_header`](http_header.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:233](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L233)

***

### is\_replicated

> **is\_replicated**: \[\] \| \[`boolean`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:234](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L234)

***

### max\_response\_bytes

> **max\_response\_bytes**: \[\] \| \[`bigint`\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:230](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L230)

***

### method

> **method**: \{ `get`: `null`; \} \| \{ `head`: `null`; \} \| \{ `post`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:229](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L229)

***

### transform

> **transform**: \[\] \| \[\{ `context`: `Uint8Array`; `function`: \[`Principal`, `string`\]; \}\]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:232](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L232)

***

### url

> **url**: `string`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:228](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L228)
