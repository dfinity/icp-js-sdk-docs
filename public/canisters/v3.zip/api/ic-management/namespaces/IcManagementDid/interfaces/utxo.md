---
title: utxo
editUrl: false
next: true
prev: true
---

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:450](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L450)

## Properties

### height

> **height**: `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:451](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L451)

***

### outpoint

> **outpoint**: [`outpoint`](outpoint.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:453](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L453)

***

### value

> **value**: `bigint`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:452](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L452)
