---
title: canister_id
editUrl: false
next: true
prev: true
---

> **canister\_id** = `Principal`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:52](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L52)
