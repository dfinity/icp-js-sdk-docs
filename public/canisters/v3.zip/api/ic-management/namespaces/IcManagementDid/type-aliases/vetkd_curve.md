---
title: vetkd_curve
editUrl: false
next: true
prev: true
---

> **vetkd\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L455)

## Properties

### bls12\_381\_g2

> **bls12\_381\_g2**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:455](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L455)
