---
title: bitcoin_get_current_fee_percentiles_result
editUrl: false
next: true
prev: true
---

> **bitcoin\_get\_current\_fee\_percentiles\_result** = `BigUint64Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:35](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L35)
