---
title: upload_chunk_result
editUrl: false
next: true
prev: true
---

> **upload\_chunk\_result** = [`chunk_hash`](../interfaces/chunk_hash.md)

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:449](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L449)
