---
title: ecdsa_curve
editUrl: false
next: true
prev: true
---

> **ecdsa\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L203)

## Properties

### secp256k1

> **secp256k1**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L203)
