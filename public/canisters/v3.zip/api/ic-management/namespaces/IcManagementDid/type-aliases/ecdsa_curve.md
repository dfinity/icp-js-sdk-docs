---
title: ecdsa_curve
editUrl: false
next: true
prev: true
---

> **ecdsa\_curve** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L203)

## Properties

### secp256k1

> **secp256k1**: `null`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:203](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L203)
