---
title: list_canister_snapshots_result
editUrl: false
next: true
prev: true
---

> **list\_canister\_snapshots\_result** = [`snapshot`](../interfaces/snapshot.md)[]

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:260](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L260)
