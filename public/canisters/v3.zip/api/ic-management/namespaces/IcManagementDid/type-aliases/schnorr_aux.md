---
title: schnorr_aux
editUrl: false
next: true
prev: true
---

> **schnorr\_aux** = `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L345)

## Properties

### bip341

> **bip341**: `object`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:345](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L345)

#### merkle\_root\_hash

> **merkle\_root\_hash**: `Uint8Array`
