---
title: bitcoin_block_hash
editUrl: false
next: true
prev: true
---

> **bitcoin\_block\_hash** = `Uint8Array`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:14](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L14)
