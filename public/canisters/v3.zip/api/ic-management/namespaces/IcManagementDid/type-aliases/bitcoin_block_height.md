---
title: bitcoin_block_height
editUrl: false
next: true
prev: true
---

> **bitcoin\_block\_height** = `number`

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:16](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L16)
