---
title: log_visibility
editUrl: false
next: true
prev: true
---

> **log\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L266)
