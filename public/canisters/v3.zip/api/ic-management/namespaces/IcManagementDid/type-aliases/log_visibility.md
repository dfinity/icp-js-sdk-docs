---
title: log_visibility
editUrl: false
next: true
prev: true
---

> **log\_visibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowed_viewers`: `Principal`[]; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:266](https://github.com/dfinity/icp-js-canisters/blob/e78c0942137fecd6ce43dcc38994fca99b7e025a/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L266)
