---
title: bitcoin_network
editUrl: false
next: true
prev: true
---

> **bitcoin\_network** = \{ `mainnet`: `null`; \} \| \{ `testnet`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:47](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L47)
