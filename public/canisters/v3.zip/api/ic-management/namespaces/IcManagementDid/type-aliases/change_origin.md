---
title: change_origin
editUrl: false
next: true
prev: true
---

> **change\_origin** = \{ `from_user`: \{ `user_id`: `Principal`; \}; \} \| \{ `from_canister`: \{ `canister_id`: `Principal`; `canister_version`: \[\] \| \[`bigint`\]; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/c12fa5ec63afe34996feb9e62fb0efbdb4f6ccb4/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L161)
