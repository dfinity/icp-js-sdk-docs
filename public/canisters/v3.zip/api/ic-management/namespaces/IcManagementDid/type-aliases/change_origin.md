---
title: change_origin
editUrl: false
next: true
prev: true
---

> **change\_origin** = \{ `from_user`: \{ `user_id`: `Principal`; \}; \} \| \{ `from_canister`: \{ `canister_id`: `Principal`; `canister_version`: \[\] \| \[`bigint`\]; \}; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:161](https://github.com/dfinity/icp-js-canisters/blob/eb9ab89e53a3ae60d62a4424526be18c59137b39/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L161)
