---
title: schnorr_algorithm
editUrl: false
next: true
prev: true
---

> **schnorr\_algorithm** = \{ `ed25519`: `null`; \} \| \{ `bip340secp256k1`: `null`; \}

Defined in: [packages/canisters/src/declarations/ic-management/ic-management.d.ts:344](https://github.com/dfinity/icp-js-canisters/blob/70d53224d05d55ccd6f77ac50f34c46dfcce66de/packages/canisters/src/declarations/ic-management/ic-management.d.ts#L344)
