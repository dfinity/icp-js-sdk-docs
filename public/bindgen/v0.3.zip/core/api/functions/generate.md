---
title: generate
editUrl: false
next: true
prev: true
---

> **generate**(`options`): `Promise`\<`void`\>

Defined in: [core/generate/index.ts:109](https://github.com/dfinity/icp-js-bindgen/blob/c692d6baa224dc09d406082846589bae8ae5fb16/src/core/generate/index.ts#L109)

Generates the bindings for a `.did` file.

For an explanation of the generated files, see the [Bindings Structure](https://js.icp.build/bindgen/latest/structure) docs page.

## Parameters

### options

[`GenerateOptions`](../type-aliases/GenerateOptions.md)

The options for the generate function.

## Returns

`Promise`\<`void`\>

## Example

Suppose we have a `.did` file in `./canisters/hello_world.did` and we want to generate bindings in `./src/bindings`.

```ts
await generate({
  didFile: './canisters/hello_world.did',
  outDir: './src/bindings',
});
```
