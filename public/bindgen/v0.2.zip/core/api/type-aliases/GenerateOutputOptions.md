---
title: GenerateOutputOptions
editUrl: false
next: true
prev: true
---

> **GenerateOutputOptions** = `object`

Defined in: [core/generate/index.ts:11](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L11)

Options for controlling the generated output files.

## Properties

### actor?

> `optional` **actor**: \{ `disabled`: `true`; \} \| \{ `disabled?`: `false`; `interfaceFile?`: `boolean`; \}

Defined in: [core/generate/index.ts:21](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L21)

Options for controlling the generated actor files.

#### Type Declaration

\{ `disabled`: `true`; \}

#### disabled

> **disabled**: `true`

If `true`, skips generating the actor file (`<service-name>.ts`).

##### Default

```ts
false
```

\{ `disabled?`: `false`; `interfaceFile?`: `boolean`; \}

#### disabled?

> `optional` **disabled**: `false`

#### interfaceFile?

> `optional` **interfaceFile**: `boolean`

If `true`, generates a `<service-name>.d.ts` file that contains the same types of the `<service-name>.ts` file.
Useful to add to LLMs' contexts' to give knowledge about what types are available in the service.

Has no effect if `disabled` is `true`.

##### Default

```ts
false
```

***

### declarations?

> `optional` **declarations**: `object`

Defined in: [core/generate/index.ts:45](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L45)

Options for controlling the generated declarations files.

#### rootExports?

> `optional` **rootExports**: `boolean`

If `true`, exports root types in the declarations JS file (`declarations/<service-name>.did.js`).

##### Default

```ts
false
```

***

### force?

> `optional` **force**: `boolean`

Defined in: [core/generate/index.ts:17](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L17)

If `true`, overwrite existing files. If `false`, abort on collisions.

#### Default

```ts
false
```
