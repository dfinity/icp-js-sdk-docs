---
title: Overview
editUrl: false
next: true
prev: true
---

The Vite plugin is used to generate bindings for a `.did` file during the build process.

## Installation

```bash
npm install -D @icp-sdk/bindgen
```

## Usage

Suppose you have a `./canisters/hello_world.did` file, and you want to output the generated bindings for your Vite app in the `src/bindings/` folder.
Here's how the plugin configuration would look like:

```ts title="vite.config.ts"
import { defineConfig } from "vite";
import { icpBindgen } from '@icp-sdk/bindgen/plugins/vite';

export default defineConfig({
  plugins: [
    // ... other plugins
    icpBindgen({
      didFile: './canisters/hello_world.did',
      outDir: './src/bindings',
    }),
  ],
});
```

For an explanation of the generated files, see the [Bindings Structure](https://js.icp.build/bindgen/latest/structure/) page.

## Interfaces

- [Options](interfaces/Options.md)
