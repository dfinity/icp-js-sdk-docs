---
title: generate
editUrl: false
next: true
prev: true
---

> **generate**(`options`): `Promise`\<`void`\>

Defined in: [core/generate/index.ts:90](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/index.ts#L90)

Generates the bindings for a `.did` file.

For an explanation of the generated files, see the [Bindings Structure](https://js.icp.build/bindgen/latest/structure) docs page.

## Parameters

### options

[`GenerateOptions`](../type-aliases/GenerateOptions.md)

The options for the generate function.

## Returns

`Promise`\<`void`\>

## Example

Suppose we have a `.did` file in `./canisters/hello_world.did` and we want to generate bindings in `./src/bindings`.

```ts
await generate({
  didFile: './canisters/hello_world.did',
  outDir: './src/bindings',
});
```
