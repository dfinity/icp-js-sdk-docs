---
title: GenerateAdditionalFeaturesOptions
editUrl: false
next: true
prev: true
---

> **GenerateAdditionalFeaturesOptions** = `object`

Defined in: [core/generate/features/index.ts:3](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/features/index.ts#L3)

## Properties

### canisterEnv?

> `optional` **canisterEnv**: `object`

Defined in: [core/generate/features/index.ts:7](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/features/index.ts#L7)

If defined, generates a `canister-env.d.ts` file according to the provided options.

#### variableNames

> **variableNames**: `string`[]

The variable names to include in the `canister-env.d.ts` file.
