---
title: GenerateOutputOptions
editUrl: false
next: true
prev: true
---

> **GenerateOutputOptions** = `object`

Defined in: [core/generate/index.ts:11](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L11)

Options for controlling the generated output files.

## Properties

### actor?

> `optional` **actor**: \{ `disabled`: `true`; \} \| \{ `disabled?`: `false`; `interfaceFile?`: `boolean`; \}

Defined in: [core/generate/index.ts:21](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L21)

Options for controlling the generated actor files.

#### Type Declaration

\{ `disabled`: `true`; \}

#### disabled

> **disabled**: `true`

If `true`, skips generating the actor file (`<service-name>.ts`).

##### Default

```ts
false
```

\{ `disabled?`: `false`; `interfaceFile?`: `boolean`; \}

#### disabled?

> `optional` **disabled**: `false`

#### interfaceFile?

> `optional` **interfaceFile**: `boolean`

If `true`, generates a `<service-name>.d.ts` file that contains the same types of the `<service-name>.ts` file.
Useful to add to LLMs' contexts' to give knowledge about what types are available in the service.

Has no effect if `disabled` is `true`.

##### Default

```ts
false
```

***

### declarations?

> `optional` **declarations**: `object`

Defined in: [core/generate/index.ts:45](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L45)

Options for controlling the generated declarations files.

#### flat?

> `optional` **flat**: `boolean`

If `true`, generates declaration files directly in `outDir` instead of in a `declarations/` subfolder.

This is useful for projects that need full control over the output file layout without
post-processing scripts to move or rename the generated files.

##### Default

```ts
false
```

#### rootExports?

> `optional` **rootExports**: `boolean`

If `true`, exports root types in the declarations file.

##### Default

```ts
false
```

#### typescript?

> `optional` **typescript**: `boolean`

If `true`, generates a single `declarations/<service-name>.did.ts` TypeScript file
instead of separate `declarations/<service-name>.did.js` and `declarations/<service-name>.did.d.ts` files.

This eliminates the need for `allowJs: true` in the consumer's TypeScript configuration.

##### Default

```ts
false
```

***

### force?

> `optional` **force**: `boolean`

Defined in: [core/generate/index.ts:17](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L17)

If `true`, overwrite existing files. If `false`, abort on collisions.

#### Default

```ts
false
```
