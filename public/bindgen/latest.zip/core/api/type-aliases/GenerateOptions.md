---
title: GenerateOptions
editUrl: false
next: true
prev: true
---

> **GenerateOptions** = `object`

Defined in: [core/generate/index.ts:76](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L76)

Options for the [generate](../functions/generate.md) function.

## Properties

### didFile

> **didFile**: `string`

Defined in: [core/generate/index.ts:80](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L80)

The path to the `.did` file.

***

### outDir

> **outDir**: `string`

Defined in: [core/generate/index.ts:84](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L84)

The path to the directory where the bindings will be generated.

***

### output?

> `optional` **output**: [`GenerateOutputOptions`](GenerateOutputOptions.md)

Defined in: [core/generate/index.ts:88](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L88)

Options for controlling the generated output files.
