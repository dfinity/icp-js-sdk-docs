---
title: GenerateOptions
editUrl: false
next: true
prev: true
---

> **GenerateOptions** = `object`

Defined in: [core/generate/index.ts:58](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L58)

Options for the [generate](../functions/generate.md) function.

## Properties

### didFile

> **didFile**: `string`

Defined in: [core/generate/index.ts:62](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L62)

The path to the `.did` file.

***

### outDir

> **outDir**: `string`

Defined in: [core/generate/index.ts:66](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L66)

The path to the directory where the bindings will be generated.

***

### output?

> `optional` **output**: [`GenerateOutputOptions`](GenerateOutputOptions.md)

Defined in: [core/generate/index.ts:70](https://github.com/dfinity/icp-js-bindgen/blob/005a29ea7c9bf1fa5ca6fb890176f10b61085adc/src/core/generate/index.ts#L70)

Options for controlling the generated output files.
