---
title: GenerateOptions
editUrl: false
next: true
prev: true
---

> **GenerateOptions** = `object`

Defined in: [core/generate/index.ts:53](https://github.com/dfinity/icp-js-bindgen/blob/7c96fc655f7d7a7b52b3f57f073c79186ef4990a/src/core/generate/index.ts#L53)

Options for the [generate](../functions/generate.md) function.

## Properties

### additionalFeatures?

> `optional` **additionalFeatures**: [`GenerateAdditionalFeaturesOptions`](GenerateAdditionalFeaturesOptions.md)

Defined in: [core/generate/index.ts:69](https://github.com/dfinity/icp-js-bindgen/blob/7c96fc655f7d7a7b52b3f57f073c79186ef4990a/src/core/generate/index.ts#L69)

Additional features to generate bindings with.

***

### didFile

> **didFile**: `string`

Defined in: [core/generate/index.ts:57](https://github.com/dfinity/icp-js-bindgen/blob/7c96fc655f7d7a7b52b3f57f073c79186ef4990a/src/core/generate/index.ts#L57)

The path to the `.did` file.

***

### outDir

> **outDir**: `string`

Defined in: [core/generate/index.ts:61](https://github.com/dfinity/icp-js-bindgen/blob/7c96fc655f7d7a7b52b3f57f073c79186ef4990a/src/core/generate/index.ts#L61)

The path to the directory where the bindings will be generated.

***

### output?

> `optional` **output**: [`GenerateOutputOptions`](GenerateOutputOptions.md)

Defined in: [core/generate/index.ts:65](https://github.com/dfinity/icp-js-bindgen/blob/7c96fc655f7d7a7b52b3f57f073c79186ef4990a/src/core/generate/index.ts#L65)

Options for controlling the generated output files.
