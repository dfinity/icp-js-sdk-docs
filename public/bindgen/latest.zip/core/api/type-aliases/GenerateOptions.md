---
title: GenerateOptions
editUrl: false
next: true
prev: true
---

> **GenerateOptions** = `object`

Defined in: [core/generate/index.ts:53](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/index.ts#L53)

Options for the [generate](../functions/generate.md) function.

## Properties

### additionalFeatures?

> `optional` **additionalFeatures**: [`GenerateAdditionalFeaturesOptions`](GenerateAdditionalFeaturesOptions.md)

Defined in: [core/generate/index.ts:69](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/index.ts#L69)

Additional features to generate bindings with.

***

### didFile

> **didFile**: `string`

Defined in: [core/generate/index.ts:57](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/index.ts#L57)

The path to the `.did` file.

***

### outDir

> **outDir**: `string`

Defined in: [core/generate/index.ts:61](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/index.ts#L61)

The path to the directory where the bindings will be generated.

***

### output?

> `optional` **output**: [`GenerateOutputOptions`](GenerateOutputOptions.md)

Defined in: [core/generate/index.ts:65](https://github.com/dfinity/icp-js-bindgen/blob/9410873b216f8c1b4a4b7f2609c33a71d00486d7/src/core/generate/index.ts#L65)

Options for controlling the generated output files.
