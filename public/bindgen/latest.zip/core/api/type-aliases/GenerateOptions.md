---
title: GenerateOptions
editUrl: false
next: true
prev: true
---

> **GenerateOptions** = `object`

Defined in: [core/generate/index.ts:47](https://github.com/dfinity/icp-js-bindgen/blob/8ddc8a67bb3d4525a7034094f2c979c2fd332160/src/core/generate/index.ts#L47)

Options for the [generate](../functions/generate.md) function.

## Properties

### didFile

> **didFile**: `string`

Defined in: [core/generate/index.ts:51](https://github.com/dfinity/icp-js-bindgen/blob/8ddc8a67bb3d4525a7034094f2c979c2fd332160/src/core/generate/index.ts#L51)

The path to the `.did` file.

***

### outDir

> **outDir**: `string`

Defined in: [core/generate/index.ts:55](https://github.com/dfinity/icp-js-bindgen/blob/8ddc8a67bb3d4525a7034094f2c979c2fd332160/src/core/generate/index.ts#L55)

The path to the directory where the bindings will be generated.

***

### output?

> `optional` **output**: [`GenerateOutputOptions`](GenerateOutputOptions.md)

Defined in: [core/generate/index.ts:59](https://github.com/dfinity/icp-js-bindgen/blob/8ddc8a67bb3d4525a7034094f2c979c2fd332160/src/core/generate/index.ts#L59)

Options for controlling the generated output files.
