---
title: Options
editUrl: false
next: true
prev: true
---

Defined in: [plugins/vite.ts:48](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/plugins/vite.ts#L48)

Options for the Vite plugin.

## Extends

- `Omit`\<[`GenerateOptions`](../../../core/api/type-aliases/GenerateOptions.md), `"output"`\>

## Properties

### didFile

> **didFile**: `string`

Defined in: [core/generate/index.ts:80](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L80)

The path to the `.did` file.

#### Inherited from

`Omit.didFile`

***

### disableWatch?

> `optional` **disableWatch**: `boolean`

Defined in: [plugins/vite.ts:58](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/plugins/vite.ts#L58)

Disables watching for changes in the `.did` file when using the dev server.

#### Default

```ts
false
```

***

### outDir

> **outDir**: `string`

Defined in: [core/generate/index.ts:84](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/core/generate/index.ts#L84)

The path to the directory where the bindings will be generated.

#### Inherited from

`Omit.outDir`

***

### output?

> `optional` **output**: `Omit`\<[`GenerateOutputOptions`](../../../core/api/type-aliases/GenerateOutputOptions.md), `"force"`\>

Defined in: [plugins/vite.ts:52](https://github.com/dfinity/icp-js-bindgen/blob/22da2a74c3be406506164445f3ceb2237d7914c1/src/plugins/vite.ts#L52)

Options for controlling the generated output files.
