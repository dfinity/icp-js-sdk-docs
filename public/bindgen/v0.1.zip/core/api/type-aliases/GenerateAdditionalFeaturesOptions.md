---
title: GenerateAdditionalFeaturesOptions
editUrl: false
next: true
prev: true
---

> **GenerateAdditionalFeaturesOptions** = `object`

Defined in: [core/generate/features/index.ts:3](https://github.com/dfinity/icp-js-bindgen/blob/7c96fc655f7d7a7b52b3f57f073c79186ef4990a/src/core/generate/features/index.ts#L3)

## Properties

### canisterEnv?

> `optional` **canisterEnv**: `object`

Defined in: [core/generate/features/index.ts:7](https://github.com/dfinity/icp-js-bindgen/blob/7c96fc655f7d7a7b52b3f57f073c79186ef4990a/src/core/generate/features/index.ts#L7)

If defined, generates a `canister-env.d.ts` file according to the provided options.

#### variableNames

> **variableNames**: `string`[]

The variable names to include in the `canister-env.d.ts` file.
