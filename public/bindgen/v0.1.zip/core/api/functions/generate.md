---
title: generate
editUrl: false
next: true
prev: true
---

> **generate**(`options`): `Promise`\<`void`\>

Defined in: [core/generate/index.ts:80](https://github.com/dfinity/icp-js-bindgen/blob/25076a0d4a8634db36acb01b8c9d1c78ce0d1d58/src/core/generate/index.ts#L80)

Generates the bindings for a `.did` file.

For an explanation of the generated files, see the [Bindings Structure](https://js.icp.build/bindgen/latest/structure) docs page.

## Parameters

### options

[`GenerateOptions`](../type-aliases/GenerateOptions.md)

The options for the generate function.

## Returns

`Promise`\<`void`\>

## Example

Suppose we have a `.did` file in `./canisters/hello_world.did` and we want to generate bindings in `./src/bindings`.

```ts
await generate({
  didFile: './canisters/hello_world.did',
  outDir: './src/bindings',
});
```
