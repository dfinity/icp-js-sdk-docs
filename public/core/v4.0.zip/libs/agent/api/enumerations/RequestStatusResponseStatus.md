---
title: RequestStatusResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/index.ts:76](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L76)


### Done

> **Done**: `"done"`

Defined in: [packages/agent/src/agent/http/index.ts:82](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L82)

***

### Processing

> **Processing**: `"processing"`

Defined in: [packages/agent/src/agent/http/index.ts:78](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L78)

***

### Received

> **Received**: `"received"`

Defined in: [packages/agent/src/agent/http/index.ts:77](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L77)

***

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/agent/src/agent/http/index.ts:80](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L80)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/agent/src/agent/http/index.ts:79](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L79)

***

### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/agent/src/agent/http/index.ts:81](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L81)
