---
title: SubmitRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:73](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L73)


### Call

> **Call**: `"call"`

Defined in: [packages/agent/src/agent/http/types.ts:74](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L74)
