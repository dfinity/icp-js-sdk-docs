---
title: LookupLabelStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:511](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L511)


### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:512](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L512)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:514](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L514)

***

### Greater

> **Greater**: `"Greater"`

Defined in: [packages/agent/src/certificate.ts:516](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L516)

***

### Less

> **Less**: `"Less"`

Defined in: [packages/agent/src/certificate.ts:515](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L515)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:513](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L513)
