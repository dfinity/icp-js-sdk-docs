---
title: NodeType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:45](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L45)


### Empty

> **Empty**: `0`

Defined in: [packages/agent/src/certificate.ts:46](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L46)

***

### Fork

> **Fork**: `1`

Defined in: [packages/agent/src/certificate.ts:47](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L47)

***

### Labeled

> **Labeled**: `2`

Defined in: [packages/agent/src/certificate.ts:48](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L48)

***

### Leaf

> **Leaf**: `3`

Defined in: [packages/agent/src/certificate.ts:49](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L49)

***

### Pruned

> **Pruned**: `4`

Defined in: [packages/agent/src/certificate.ts:50](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L50)
