---
title: QueryResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:34](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/api.ts#L34)


### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/agent/src/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/api.ts#L36)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/agent/src/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/api.ts#L35)
