---
title: Endpoint
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:8](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L8)

**`Internal`**


### Call

> **Call**: `"call"`

Defined in: [packages/agent/src/agent/http/types.ts:11](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L11)

***

### Query

> **Query**: `"read"`

Defined in: [packages/agent/src/agent/http/types.ts:9](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L9)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/agent/src/agent/http/types.ts:10](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L10)
