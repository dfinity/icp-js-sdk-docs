---
title: ObserveFunction
editUrl: false
next: true
prev: true
---

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/agent/src/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/observable.ts#L3)


### T

`T`

## Parameters

### data

`T`

### rest

...`unknown`[]

## Returns

`void`
