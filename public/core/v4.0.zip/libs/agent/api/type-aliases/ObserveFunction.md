---
title: ObserveFunction
editUrl: false
next: true
prev: true
---

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/agent/src/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/observable.ts#L3)


### T

`T`

## Parameters

### data

`T`

### rest

...`unknown`[]

## Returns

`void`
