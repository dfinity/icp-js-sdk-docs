---
title: PrunedHashTree
editUrl: false
next: true
prev: true
---

> **PrunedHashTree** = \[[`Pruned`](../enumerations/NodeType.md#pruned), [`NodeHash`](NodeHash.md)\]

Defined in: [packages/agent/src/certificate.ts:62](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L62)
