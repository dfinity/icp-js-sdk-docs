---
title: LookupResult
editUrl: false
next: true
prev: true
---

> **LookupResult** = [`LookupPathResultAbsent`](../interfaces/LookupPathResultAbsent.md) \| [`LookupPathResultUnknown`](../interfaces/LookupPathResultUnknown.md) \| [`LookupPathResultFound`](../interfaces/LookupPathResultFound.md) \| [`LookupPathResultError`](../interfaces/LookupPathResultError.md)

Defined in: [packages/agent/src/certificate.ts:481](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L481)
