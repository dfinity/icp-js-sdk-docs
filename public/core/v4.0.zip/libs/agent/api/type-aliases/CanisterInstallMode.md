---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

> **CanisterInstallMode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/agent/src/actor.ts:152](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/actor.ts#L152)

The mode used when installing a canister.
