---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

> **CanisterInstallMode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/agent/src/actor.ts:152](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L152)

The mode used when installing a canister.
