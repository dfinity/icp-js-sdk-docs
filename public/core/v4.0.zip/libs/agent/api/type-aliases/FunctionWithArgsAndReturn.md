---
title: FunctionWithArgsAndReturn
editUrl: false
next: true
prev: true
---

> **FunctionWithArgsAndReturn**\<`Args`, `Ret`\> = (...`args`) => `Ret`

Defined in: [packages/agent/src/actor.ts:131](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L131)


### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Parameters

### args

...`Args`

## Returns

`Ret`
