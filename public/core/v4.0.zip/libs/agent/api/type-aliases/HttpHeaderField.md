---
title: HttpHeaderField
editUrl: false
next: true
prev: true
---

> **HttpHeaderField** = \[`string`, `string`\]

Defined in: [packages/agent/src/agent/http/types.ts:26](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L26)
