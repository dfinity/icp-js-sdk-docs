---
title: LabelLookupResult
editUrl: false
next: true
prev: true
---

> **LabelLookupResult** = [`LookupLabelResultAbsent`](../interfaces/LookupLabelResultAbsent.md) \| [`LookupLabelResultUnknown`](../interfaces/LookupLabelResultUnknown.md) \| [`LookupLabelResultFound`](../interfaces/LookupLabelResultFound.md) \| [`LookupLabelResultGreater`](../interfaces/LookupLabelResultGreater.md) \| [`LookupLabelResultLess`](../interfaces/LookupLabelResultLess.md)

Defined in: [packages/agent/src/certificate.ts:540](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L540)
