---
title: LabelLookupResult
editUrl: false
next: true
prev: true
---

> **LabelLookupResult** = [`LookupLabelResultAbsent`](../interfaces/LookupLabelResultAbsent.md) \| [`LookupLabelResultUnknown`](../interfaces/LookupLabelResultUnknown.md) \| [`LookupLabelResultFound`](../interfaces/LookupLabelResultFound.md) \| [`LookupLabelResultGreater`](../interfaces/LookupLabelResultGreater.md) \| [`LookupLabelResultLess`](../interfaces/LookupLabelResultLess.md)

Defined in: [packages/agent/src/certificate.ts:540](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L540)
