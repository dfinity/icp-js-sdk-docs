---
title: IdentityDescriptor
editUrl: false
next: true
prev: true
---

> **IdentityDescriptor** = [`AnonymousIdentityDescriptor`](../interfaces/AnonymousIdentityDescriptor.md) \| [`PublicKeyIdentityDescriptor`](../interfaces/PublicKeyIdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:133](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/auth.ts#L133)
