---
title: EmptyHashTree
editUrl: false
next: true
prev: true
---

> **EmptyHashTree** = \[[`Empty`](../enumerations/NodeType.md#empty)\]

Defined in: [packages/agent/src/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L58)
