---
title: AgentLog
editUrl: false
next: true
prev: true
---

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](../classes/AgentError.md); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/agent/src/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/observable.ts#L25)
