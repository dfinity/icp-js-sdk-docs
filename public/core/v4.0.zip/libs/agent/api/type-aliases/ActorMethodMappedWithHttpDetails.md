---
title: ActorMethodMappedWithHttpDetails
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedWithHttpDetails**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodWithHttpDetails<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:136](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/actor.ts#L136)


### T

`T`
