---
title: ActorMethodMappedWithHttpDetails
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedWithHttpDetails**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodWithHttpDetails<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:136](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L136)


### T

`T`
