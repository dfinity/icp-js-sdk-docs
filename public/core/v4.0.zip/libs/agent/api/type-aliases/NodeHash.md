---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L56)


### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
