---
title: CallContext
editUrl: false
next: true
prev: true
---

> **CallContext** = `object`

Defined in: [packages/agent/src/errors.ts:31](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/errors.ts#L31)


### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/errors.ts:32](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/errors.ts#L32)

***

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](../interfaces/HttpDetailsResponse.md)

Defined in: [packages/agent/src/errors.ts:34](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/errors.ts#L34)

***

### methodName

> **methodName**: `string`

Defined in: [packages/agent/src/errors.ts:33](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/errors.ts#L33)
