---
title: ActorSubclass
editUrl: false
next: true
prev: true
---

> **ActorSubclass**\<`T`\> = [`Actor`](../classes/Actor.md) & `T`

Defined in: [packages/agent/src/actor.ts:100](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L100)

A subclass of an actor. Actor class itself is meant to be a based class.


### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\>
