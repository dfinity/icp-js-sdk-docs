---
title: LabeledHashTree
editUrl: false
next: true
prev: true
---

> **LabeledHashTree** = \[[`Labeled`](../enumerations/NodeType.md#labeled), [`NodeLabel`](NodeLabel.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/agent/src/certificate.ts:60](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L60)
