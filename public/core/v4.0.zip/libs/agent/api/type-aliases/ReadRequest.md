---
title: ReadRequest
editUrl: false
next: true
prev: true
---

> **ReadRequest** = [`QueryRequest`](../interfaces/QueryRequest.md) \| [`ReadStateRequest`](../interfaces/ReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L103)
