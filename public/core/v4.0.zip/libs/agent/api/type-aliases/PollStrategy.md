---
title: PollStrategy
editUrl: false
next: true
prev: true
---

> **PollStrategy** = (`canisterId`, `requestId`, `status`) => `Promise`\<`void`\>

Defined in: [packages/agent/src/polling/index.ts:28](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/polling/index.ts#L28)


### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](RequestId.md)

### status

[`RequestStatusResponseStatus`](../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`void`\>
