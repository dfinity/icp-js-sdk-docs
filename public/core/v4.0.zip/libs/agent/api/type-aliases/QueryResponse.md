---
title: QueryResponse
editUrl: false
next: true
prev: true
---

> **QueryResponse** = [`QueryResponseReplied`](../interfaces/QueryResponseReplied.md) \| [`QueryResponseRejected`](../interfaces/QueryResponseRejected.md)

Defined in: [packages/agent/src/agent/api.ts:32](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L32)
