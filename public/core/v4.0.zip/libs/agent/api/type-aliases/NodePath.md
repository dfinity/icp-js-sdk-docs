---
title: NodePath
editUrl: false
next: true
prev: true
---

> **NodePath** = (`Uint8Array` \| `string`)[]

Defined in: [packages/agent/src/certificate.ts:53](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L53)
