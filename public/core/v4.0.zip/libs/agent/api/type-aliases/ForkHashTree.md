---
title: ForkHashTree
editUrl: false
next: true
prev: true
---

> **ForkHashTree** = \[[`Fork`](../enumerations/NodeType.md#fork), [`HashTree`](HashTree.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/agent/src/certificate.ts:59](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L59)
