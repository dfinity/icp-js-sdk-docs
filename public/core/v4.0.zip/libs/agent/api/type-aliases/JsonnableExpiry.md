---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

> **JsonnableExpiry** = `object`

Defined in: [packages/agent/src/agent/http/transforms.ts:27](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/transforms.ts#L27)


### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/agent/src/agent/http/transforms.ts:28](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/transforms.ts#L28)
