---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

> **JsonnableExpiry** = `object`

Defined in: [packages/agent/src/agent/http/transforms.ts:27](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/transforms.ts#L27)


### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/agent/src/agent/http/transforms.ts:28](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/transforms.ts#L28)
