---
title: HttpAgentRequest
editUrl: false
next: true
prev: true
---

> **HttpAgentRequest** = [`HttpAgentQueryRequest`](../interfaces/HttpAgentQueryRequest.md) \| [`HttpAgentSubmitRequest`](../interfaces/HttpAgentSubmitRequest.md) \| [`HttpAgentReadStateRequest`](../interfaces/HttpAgentReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:16](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L16)
