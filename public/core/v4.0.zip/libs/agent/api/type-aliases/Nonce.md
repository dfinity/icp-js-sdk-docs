---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/agent/src/agent/http/types.ts:106](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L106)


### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
