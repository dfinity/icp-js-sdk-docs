---
title: ActorConstructor
editUrl: false
next: true
prev: true
---

> **ActorConstructor** = (`config`) => [`ActorSubclass`](ActorSubclass.md)

Defined in: [packages/agent/src/actor.ts:328](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/actor.ts#L328)


### config

[`ActorConfig`](../interfaces/ActorConfig.md)

## Returns

[`ActorSubclass`](ActorSubclass.md)
