---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/agent/src/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/request_id.ts#L8)


### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
