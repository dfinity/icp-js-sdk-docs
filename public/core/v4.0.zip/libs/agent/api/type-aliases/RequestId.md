---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/agent/src/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/request_id.ts#L8)


### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
