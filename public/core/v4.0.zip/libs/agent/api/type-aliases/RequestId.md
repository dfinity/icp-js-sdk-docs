---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/agent/src/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/request_id.ts#L8)


### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
