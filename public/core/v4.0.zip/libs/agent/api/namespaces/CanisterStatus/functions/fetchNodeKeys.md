---
title: fetchNodeKeys
editUrl: false
next: true
prev: true
---

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:285](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/canisterStatus/index.ts#L285)


### certificate

`Uint8Array`

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)
