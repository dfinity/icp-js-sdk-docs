---
title: fetchNodeKeys
editUrl: false
next: true
prev: true
---

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:285](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/canisterStatus/index.ts#L285)


### certificate

`Uint8Array`

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)
