---
title: encodePath
editUrl: false
next: true
prev: true
---

> **encodePath**(`path`, `canisterId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/agent/src/canisterStatus/index.ts:364](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/canisterStatus/index.ts#L364)


### path

[`Path`](../type-aliases/Path.md)

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

## Returns

`Uint8Array`\<`ArrayBufferLike`\>[]
