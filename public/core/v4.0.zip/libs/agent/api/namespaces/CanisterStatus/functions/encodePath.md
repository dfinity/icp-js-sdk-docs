---
title: encodePath
editUrl: false
next: true
prev: true
---

> **encodePath**(`path`, `canisterId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/agent/src/canisterStatus/index.ts:364](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/canisterStatus/index.ts#L364)


### path

[`Path`](../type-aliases/Path.md)

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

## Returns

`Uint8Array`\<`ArrayBufferLike`\>[]
