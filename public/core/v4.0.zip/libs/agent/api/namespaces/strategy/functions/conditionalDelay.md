---
title: conditionalDelay
editUrl: false
next: true
prev: true
---

> **conditionalDelay**(`condition`, `timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:45](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/polling/strategy.ts#L45)

Delay the polling once.


### condition

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

A predicate that indicates when to delay.

### timeInMsec

`number`

The amount of time to delay.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
