---
title: Predicate
editUrl: false
next: true
prev: true
---

> **Predicate**\<`T`\> = (`canisterId`, `requestId`, `status`) => `Promise`\<`T`\>

Defined in: [packages/agent/src/polling/strategy.ts:7](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/polling/strategy.ts#L7)


### T

`T`

## Parameters

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](../../../type-aliases/RequestId.md)

### status

[`RequestStatusResponseStatus`](../../../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`T`\>
