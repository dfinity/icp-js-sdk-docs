---
title: defaultStrategy
editUrl: false
next: true
prev: true
---

> **defaultStrategy**(): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:19](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/polling/strategy.ts#L19)

A best practices polling strategy: wait 2 seconds before the first poll, then 1 second
with an exponential backoff factor of 1.2. Timeout after 5 minutes.


[`PollStrategy`](../../../type-aliases/PollStrategy.md)
