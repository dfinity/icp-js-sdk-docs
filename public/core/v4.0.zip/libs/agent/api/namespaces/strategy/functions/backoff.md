---
title: backoff
editUrl: false
next: true
prev: true
---

> **backoff**(`startingThrottleInMsec`, `backoffFactor`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:114](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/polling/strategy.ts#L114)

A strategy that throttle, but using an exponential backoff strategy.


### startingThrottleInMsec

`number`

The throttle in milliseconds to start with.

### backoffFactor

`number`

The factor to multiple the throttle time between every poll. For
  example if using 2, the throttle will double between every run.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
