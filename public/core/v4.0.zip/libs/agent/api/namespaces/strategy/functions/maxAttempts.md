---
title: maxAttempts
editUrl: false
next: true
prev: true
---

> **maxAttempts**(`count`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:61](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/polling/strategy.ts#L61)

Error out after a maximum number of polling has been done.


### count

`number`

The maximum attempts to poll.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
