---
title: maxAttempts
editUrl: false
next: true
prev: true
---

> **maxAttempts**(`count`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:58](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/polling/strategy.ts#L58)

Error out after a maximum number of polling has been done.


### count

`number`

The maximum attempts to poll.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
