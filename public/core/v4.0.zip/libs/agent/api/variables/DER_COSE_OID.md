---
title: DER_COSE_OID
editUrl: false
next: true
prev: true
---

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:69](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/der.ts#L69)

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE
