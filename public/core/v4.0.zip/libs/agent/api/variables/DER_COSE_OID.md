---
title: DER_COSE_OID
editUrl: false
next: true
prev: true
---

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:69](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/der.ts#L69)

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE
