---
title: ACTOR_METHOD_WITH_CERTIFICATE
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/agent/src/actor.ts:331](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/actor.ts#L331)
