---
title: ACTOR_METHOD_WITH_CERTIFICATE
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/agent/src/actor.ts:331](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L331)
