---
title: JSON_KEY_EXPIRY
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/agent/src/agent/http/transforms.ts:12](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/transforms.ts#L12)
