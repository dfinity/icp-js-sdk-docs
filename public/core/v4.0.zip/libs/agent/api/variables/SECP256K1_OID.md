---
title: SECP256K1_OID
editUrl: false
next: true
prev: true
---

> `const` **SECP256K1\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:87](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/der.ts#L87)

A DER encoded `SEQUENCE(OID)` for secp256k1 with the ECDSA algorithm
