---
title: verify
editUrl: false
next: true
prev: true
---

> **verify**: (`pk`, `sig`, `msg`) => `boolean`

Defined in: [packages/agent/src/utils/bls.ts:4](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/utils/bls.ts#L4)


### pk

`Uint8Array`

### sig

`Uint8Array`

### msg

`Uint8Array`

## Returns

`boolean`
