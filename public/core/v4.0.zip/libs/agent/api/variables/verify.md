---
title: verify
editUrl: false
next: true
prev: true
---

> **verify**: (`pk`, `sig`, `msg`) => `boolean`

Defined in: [packages/agent/src/utils/bls.ts:4](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/utils/bls.ts#L4)


### pk

`Uint8Array`

### sig

`Uint8Array`

### msg

`Uint8Array`

## Returns

`boolean`
