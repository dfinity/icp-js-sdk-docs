---
title: DEFAULT_POLLING_OPTIONS
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_POLLING\_OPTIONS**: [`PollingOptions`](../interfaces/PollingOptions.md)

Defined in: [packages/agent/src/polling/index.ts:69](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/polling/index.ts#L69)
