---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/agent/src/errors.ts:826](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L826)

Special error used to indicate that a code path is unreachable.

For internal use only.
