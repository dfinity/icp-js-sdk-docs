---
title: MANAGEMENT_CANISTER_ID
editUrl: false
next: true
prev: true
---

> `const` **MANAGEMENT\_CANISTER\_ID**: `"aaaaa-aa"` = `'aaaaa-aa'`

Defined in: [packages/agent/src/agent/http/index.ts:97](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/index.ts#L97)
