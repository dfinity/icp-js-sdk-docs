---
title: MANAGEMENT_CANISTER_ID
editUrl: false
next: true
prev: true
---

> `const` **MANAGEMENT\_CANISTER\_ID**: `"aaaaa-aa"` = `'aaaaa-aa'`

Defined in: [packages/agent/src/agent/http/index.ts:97](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/index.ts#L97)
