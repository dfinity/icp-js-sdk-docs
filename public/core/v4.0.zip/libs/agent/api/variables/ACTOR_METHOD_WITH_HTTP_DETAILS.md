---
title: ACTOR_METHOD_WITH_HTTP_DETAILS
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_HTTP\_DETAILS**: `"http-details"` = `'http-details'`

Defined in: [packages/agent/src/actor.ts:330](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/actor.ts#L330)
