---
title: IC_REQUEST_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/constants.ts#L7)

The `\x0Aic-request` domain separator used in the signature of IC requests.
