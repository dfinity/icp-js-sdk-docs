---
title: LookupErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:263](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L263)


- `ErrorCode`

## Constructors

### Constructor

> **new LookupErrorCode**(`message`, `lookupStatus`): `LookupErrorCode`

Defined in: [packages/agent/src/errors.ts:266](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L266)

#### Parameters

##### message

`string`

##### lookupStatus

[`LookupPathStatus`](../enumerations/LookupPathStatus.md) | [`LookupSubtreeStatus`](../enumerations/LookupSubtreeStatus.md)

#### Returns

`LookupErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### lookupStatus

> `readonly` **lookupStatus**: [`LookupPathStatus`](../enumerations/LookupPathStatus.md) \| [`LookupSubtreeStatus`](../enumerations/LookupSubtreeStatus.md)

Defined in: [packages/agent/src/errors.ts:268](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L268)

***

### message

> `readonly` **message**: `string`

Defined in: [packages/agent/src/errors.ts:267](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L267)

***

### name

> **name**: `string` = `'LookupErrorCode'`

Defined in: [packages/agent/src/errors.ts:264](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L264)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:274](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L274)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
