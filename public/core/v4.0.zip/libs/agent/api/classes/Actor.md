---
title: Actor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:191](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L191)

An actor base class. An actor is an object containing only functions that will
return a promise. These functions are derived from the IDL definition.


### Constructor

> `protected` **new Actor**(`metadata`): `Actor`

Defined in: [packages/agent/src/actor.ts:304](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L304)

#### Parameters

##### metadata

`ActorMetadata`

#### Returns

`Actor`

## Methods

### agentOf()

> `static` **agentOf**(`actor`): `undefined` \| [`Agent`](../interfaces/Agent.md)

Defined in: [packages/agent/src/actor.ts:197](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L197)

Get the Agent class this Actor would call, or undefined if the Actor would use
the default agent (global.ic.agent).

#### Parameters

##### actor

`Actor`

The actor to get the agent of.

#### Returns

`undefined` \| [`Agent`](../interfaces/Agent.md)

***

### canisterIdOf()

> `static` **canisterIdOf**(`actor`): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:209](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L209)

#### Parameters

##### actor

`Actor`

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

***

### createActor()

> `static` **createActor**\<`T`\>(`interfaceFactory`, `configuration`): [`ActorSubclass`](../type-aliases/ActorSubclass.md)\<`T`\>

Defined in: [packages/agent/src/actor.ts:256](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L256)

#### Type Parameters

##### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\<`unknown`[], `unknown`\>\>

#### Parameters

##### interfaceFactory

[`InterfaceFactory`](../../../candid/api/namespaces/IDL/type-aliases/InterfaceFactory.md)

##### configuration

[`ActorConfig`](../interfaces/ActorConfig.md)

#### Returns

[`ActorSubclass`](../type-aliases/ActorSubclass.md)\<`T`\>

***

### createActorClass()

> `static` **createActorClass**(`interfaceFactory`, `options?`): [`ActorConstructor`](../type-aliases/ActorConstructor.md)

Defined in: [packages/agent/src/actor.ts:213](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L213)

#### Parameters

##### interfaceFactory

[`InterfaceFactory`](../../../candid/api/namespaces/IDL/type-aliases/InterfaceFactory.md)

##### options?

[`CreateActorClassOpts`](../interfaces/CreateActorClassOpts.md)

#### Returns

[`ActorConstructor`](../type-aliases/ActorConstructor.md)

***

### createActorWithExtendedDetails()

> `static` **createActorWithExtendedDetails**\<`T`\>(`interfaceFactory`, `configuration`, `actorClassOptions`): [`ActorSubclass`](../type-aliases/ActorSubclass.md)\<[`ActorMethodMappedExtended`](../type-aliases/ActorMethodMappedExtended.md)\<`T`\>\>

Defined in: [packages/agent/src/actor.ts:289](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L289)

Returns an actor with methods that return the http response details along with the result

#### Type Parameters

##### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\<`unknown`[], `unknown`\>\>

#### Parameters

##### interfaceFactory

[`InterfaceFactory`](../../../candid/api/namespaces/IDL/type-aliases/InterfaceFactory.md)

the interface factory for the actor

##### configuration

[`ActorConfig`](../interfaces/ActorConfig.md)

the configuration for the actor

##### actorClassOptions

[`CreateActorClassOpts`](../interfaces/CreateActorClassOpts.md) = `...`

options for the actor class extended details to return with the result

#### Returns

[`ActorSubclass`](../type-aliases/ActorSubclass.md)\<[`ActorMethodMappedExtended`](../type-aliases/ActorMethodMappedExtended.md)\<`T`\>\>

***

### ~~createActorWithHttpDetails()~~

> `static` **createActorWithHttpDetails**\<`T`\>(`interfaceFactory`, `configuration`): [`ActorSubclass`](../type-aliases/ActorSubclass.md)\<[`ActorMethodMappedWithHttpDetails`](../type-aliases/ActorMethodMappedWithHttpDetails.md)\<`T`\>\>

Defined in: [packages/agent/src/actor.ts:274](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L274)

Returns an actor with methods that return the http response details along with the result

#### Type Parameters

##### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\<`unknown`[], `unknown`\>\>

#### Parameters

##### interfaceFactory

[`InterfaceFactory`](../../../candid/api/namespaces/IDL/type-aliases/InterfaceFactory.md)

the interface factory for the actor

##### configuration

[`ActorConfig`](../interfaces/ActorConfig.md)

the configuration for the actor

#### Returns

[`ActorSubclass`](../type-aliases/ActorSubclass.md)\<[`ActorMethodMappedWithHttpDetails`](../type-aliases/ActorMethodMappedWithHttpDetails.md)\<`T`\>\>

#### Deprecated

- use createActor with actorClassOptions instead

***

### interfaceOf()

> `static` **interfaceOf**(`actor`): [`ServiceClass`](../../../candid/api/namespaces/IDL/classes/ServiceClass.md)

Defined in: [packages/agent/src/actor.ts:205](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L205)

Get the interface of an actor, in the form of an instance of a Service.

#### Parameters

##### actor

`Actor`

The actor to get the interface of.

#### Returns

[`ServiceClass`](../../../candid/api/namespaces/IDL/classes/ServiceClass.md)
