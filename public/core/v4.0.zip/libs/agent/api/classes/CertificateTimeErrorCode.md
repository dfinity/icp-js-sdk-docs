---
title: CertificateTimeErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:215](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L215)


- `ErrorCode`

## Constructors

### Constructor

> **new CertificateTimeErrorCode**(`maxAgeInMinutes`, `certificateTime`, `currentTime`, `timeDiffMsecs`, `ageType`): `CertificateTimeErrorCode`

Defined in: [packages/agent/src/errors.ts:218](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L218)

#### Parameters

##### maxAgeInMinutes

`number`

##### certificateTime

`Date`

##### currentTime

`Date`

##### timeDiffMsecs

`number`

##### ageType

`"past"` | `"future"`

#### Returns

`CertificateTimeErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### ageType

> `readonly` **ageType**: `"past"` \| `"future"`

Defined in: [packages/agent/src/errors.ts:223](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L223)

***

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### certificateTime

> `readonly` **certificateTime**: `Date`

Defined in: [packages/agent/src/errors.ts:220](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L220)

***

### currentTime

> `readonly` **currentTime**: `Date`

Defined in: [packages/agent/src/errors.ts:221](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L221)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### maxAgeInMinutes

> `readonly` **maxAgeInMinutes**: `number`

Defined in: [packages/agent/src/errors.ts:219](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L219)

***

### name

> **name**: `string` = `'CertificateTimeErrorCode'`

Defined in: [packages/agent/src/errors.ts:216](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L216)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

***

### timeDiffMsecs

> `readonly` **timeDiffMsecs**: `number`

Defined in: [packages/agent/src/errors.ts:222](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L222)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:229](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L229)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
