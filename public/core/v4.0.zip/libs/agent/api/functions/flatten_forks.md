---
title: flatten_forks
editUrl: false
next: true
prev: true
---

> **flatten\_forks**(`t`): ([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

Defined in: [packages/agent/src/certificate.ts:673](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L673)

If the tree is a fork, flatten it into an array of trees


### t

[`HashTree`](../type-aliases/HashTree.md)

the tree to flatten

## Returns

([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

the flattened tree
