---
title: decodeLenBytes
editUrl: false
next: true
prev: true
---

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:47](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/der.ts#L47)


### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
