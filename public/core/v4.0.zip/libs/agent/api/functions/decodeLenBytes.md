---
title: decodeLenBytes
editUrl: false
next: true
prev: true
---

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:47](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/der.ts#L47)


### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
