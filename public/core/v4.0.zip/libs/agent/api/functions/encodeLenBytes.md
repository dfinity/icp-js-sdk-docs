---
title: encodeLenBytes
editUrl: false
next: true
prev: true
---

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/agent/src/der.ts:9](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/der.ts#L9)


### len

`number`

## Returns

`number`
