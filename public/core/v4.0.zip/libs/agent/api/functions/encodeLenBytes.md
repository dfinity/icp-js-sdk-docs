---
title: encodeLenBytes
editUrl: false
next: true
prev: true
---

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/agent/src/der.ts:9](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/der.ts#L9)


### len

`number`

## Returns

`number`
