---
title: requestIdOf
editUrl: false
next: true
prev: true
---

> **requestIdOf**(`request`): [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/request\_id.ts:63](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/request_id.ts#L63)

Get the RequestId of the provided ic-ref request.
RequestId is the result of the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map


### request

`Record`\<`string`, `unknown`\>

ic-ref request to hash into RequestId

## Returns

[`RequestId`](../type-aliases/RequestId.md)
