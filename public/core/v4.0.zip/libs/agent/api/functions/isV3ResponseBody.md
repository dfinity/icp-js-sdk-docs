---
title: isV3ResponseBody
editUrl: false
next: true
prev: true
---

> **isV3ResponseBody**(`body`): `body is v3ResponseBody`

Defined in: [packages/agent/src/agent/api.ts:150](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/api.ts#L150)

Utility function to check if a body is a v3ResponseBody for type safety.


### body

The body to check

`null` | [`v2ResponseBody`](../interfaces/v2ResponseBody.md) | [`v3ResponseBody`](../interfaces/v3ResponseBody.md)

## Returns

`body is v3ResponseBody`

boolean indicating if the body is a v3ResponseBody
