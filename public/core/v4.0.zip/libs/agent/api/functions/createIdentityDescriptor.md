---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L139)

Create an IdentityDescriptor from a @dfinity/identity Identity


### identity

identity describe in returned descriptor

[`SignIdentity`](../classes/SignIdentity.md) | [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
