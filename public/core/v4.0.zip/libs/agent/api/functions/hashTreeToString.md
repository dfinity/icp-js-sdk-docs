---
title: hashTreeToString
editUrl: false
next: true
prev: true
---

> **hashTreeToString**(`tree`): `string`

Defined in: [packages/agent/src/certificate.ts:75](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L75)

Make a human readable string out of a hash tree.


### tree

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to convert to a string

## Returns

`string`
