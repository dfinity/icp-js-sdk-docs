---
title: uint8ToBuf
editUrl: false
next: true
prev: true
---

> **uint8ToBuf**(`arr`): `ArrayBuffer`

Defined in: [packages/agent/src/utils/buffer.ts:41](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/utils/buffer.ts#L41)

Returns a true ArrayBuffer from a Uint8Array, as Uint8Array.buffer is unsafe.


### arr

`Uint8Array`

Uint8Array to convert

## Returns

`ArrayBuffer`

ArrayBuffer
