---
title: uint8ToBuf
editUrl: false
next: true
prev: true
---

> **uint8ToBuf**(`arr`): `ArrayBuffer`

Defined in: [packages/agent/src/utils/buffer.ts:41](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/utils/buffer.ts#L41)

Returns a true ArrayBuffer from a Uint8Array, as Uint8Array.buffer is unsafe.


### arr

`Uint8Array`

Uint8Array to convert

## Returns

`ArrayBuffer`

ArrayBuffer
