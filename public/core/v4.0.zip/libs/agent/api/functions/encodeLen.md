---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/agent/src/der.ts:23](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/der.ts#L23)


### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
