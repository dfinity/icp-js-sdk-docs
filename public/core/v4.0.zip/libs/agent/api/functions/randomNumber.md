---
title: randomNumber
editUrl: false
next: true
prev: true
---

> **randomNumber**(): `number`

Defined in: [packages/agent/src/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff


`number`

a random number
