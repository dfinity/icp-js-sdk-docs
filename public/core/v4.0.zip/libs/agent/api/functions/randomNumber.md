---
title: randomNumber
editUrl: false
next: true
prev: true
---

> **randomNumber**(): `number`

Defined in: [packages/agent/src/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff


`number`

a random number
