---
title: find_label
editUrl: false
next: true
prev: true
---

> **find\_label**(`label`, `tree`): [`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:690](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L690)

Find a label in a tree


### label

[`NodeLabel`](../type-aliases/NodeLabel.md)

the label to find

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

the result of the label lookup
