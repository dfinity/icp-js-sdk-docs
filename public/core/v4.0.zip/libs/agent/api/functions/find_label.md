---
title: find_label
editUrl: false
next: true
prev: true
---

> **find\_label**(`label`, `tree`): [`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:690](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L690)

Find a label in a tree


### label

[`NodeLabel`](../type-aliases/NodeLabel.md)

the label to find

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

the result of the label lookup
