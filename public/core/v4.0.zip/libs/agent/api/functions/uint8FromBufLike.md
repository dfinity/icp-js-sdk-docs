---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/agent/src/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.


### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | `DataView`\<`ArrayBufferLike`\> | \[`number`\] | \{ `buffer`: `ArrayBuffer`; \} | `number`[]

## Returns

`Uint8Array`

Uint8Array
