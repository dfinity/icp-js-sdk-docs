---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:56](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/der.ts#L56)


### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
