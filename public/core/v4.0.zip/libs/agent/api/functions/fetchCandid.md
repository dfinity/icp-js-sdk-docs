---
title: fetchCandid
editUrl: false
next: true
prev: true
---

> **fetchCandid**(`canisterId`, `agent?`): `Promise`\<`string`\>

Defined in: [packages/agent/src/fetch\_candid.ts:13](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/fetch_candid.ts#L13)

Retrieves the Candid interface for the specified canister.


### canisterId

`string`

A string corresponding to the canister ID

### agent?

[`HttpAgent`](../classes/HttpAgent.md)

The agent to use for the request (usually an `HttpAgent`)

## Returns

`Promise`\<`string`\>

Candid source code
