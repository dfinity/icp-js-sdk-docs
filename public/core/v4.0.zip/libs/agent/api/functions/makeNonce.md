---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/agent/src/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L111)

Create a random Nonce, based on random values


[`Nonce`](../type-aliases/Nonce.md)
