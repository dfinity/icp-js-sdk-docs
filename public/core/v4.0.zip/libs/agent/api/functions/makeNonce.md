---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/agent/src/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L111)

Create a random Nonce, based on random values


[`Nonce`](../type-aliases/Nonce.md)
