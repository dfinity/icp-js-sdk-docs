---
title: makeNonceTransform
editUrl: false
next: true
prev: true
---

> **makeNonceTransform**(`nonceFn`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:117](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L117)

Create a Nonce transform, which takes a function that returns a Buffer, and adds it
as the nonce to every call requests.


### nonceFn

() => [`Nonce`](../type-aliases/Nonce.md)

A function that returns a buffer. By default uses a semi-random method.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
