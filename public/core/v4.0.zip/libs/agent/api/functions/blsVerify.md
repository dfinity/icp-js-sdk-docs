---
title: blsVerify
editUrl: false
next: true
prev: true
---

> **blsVerify**(`pk`, `sig`, `msg`): `boolean`

Defined in: [packages/agent/src/utils/bls.ts:13](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/utils/bls.ts#L13)


### pk

`Uint8Array`

primary key: Uint8Array

### sig

`Uint8Array`

signature: Uint8Array

### msg

`Uint8Array`

message: Uint8Array

## Returns

`boolean`

boolean
