---
title: hashOfMap
editUrl: false
next: true
prev: true
---

> **hashOfMap**(`map`): `Uint8Array`

Defined in: [packages/agent/src/request\_id.ts:73](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/request_id.ts#L73)

Hash a map into a Uint8Array using the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map


### map

`Record`\<`string`, `unknown`\>

Any non-nested object

## Returns

`Uint8Array`

Uint8Array
