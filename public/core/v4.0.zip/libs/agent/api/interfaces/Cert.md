---
title: Cert
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:39](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L39)


### delegation?

> `optional` **delegation**: `Delegation`

Defined in: [packages/agent/src/certificate.ts:42](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L42)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:41](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L41)

***

### tree

> **tree**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:40](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L40)
