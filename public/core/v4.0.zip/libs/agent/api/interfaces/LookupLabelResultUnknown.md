---
title: LookupLabelResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:523](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L523)


### status

> **status**: [`Unknown`](../enumerations/LookupLabelStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:524](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L524)
