---
title: KeyPair
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:9](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L9)

A Key Pair, containing a secret and public key.


### publicKey

> **publicKey**: [`PublicKey`](PublicKey.md)

Defined in: [packages/agent/src/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L11)

***

### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/agent/src/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L10)
