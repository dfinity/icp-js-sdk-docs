---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L532)


### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/agent/src/certificate.ts:533](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L533)
