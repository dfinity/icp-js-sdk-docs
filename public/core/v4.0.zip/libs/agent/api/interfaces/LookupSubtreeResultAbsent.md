---
title: LookupSubtreeResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:493](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L493)


### status

> **status**: [`Absent`](../enumerations/LookupSubtreeStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:494](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L494)
