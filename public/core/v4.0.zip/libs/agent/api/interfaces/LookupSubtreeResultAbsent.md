---
title: LookupSubtreeResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:493](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L493)


### status

> **status**: [`Absent`](../enumerations/LookupSubtreeStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:494](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L494)
