---
title: LookupSubtreeResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:493](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L493)


### status

> **status**: [`Absent`](../enumerations/LookupSubtreeStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:494](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L494)
