---
title: UnSigned
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L49)


### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/agent/src/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L50)
