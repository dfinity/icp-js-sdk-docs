---
title: UnSigned
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L49)


### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/agent/src/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L50)
