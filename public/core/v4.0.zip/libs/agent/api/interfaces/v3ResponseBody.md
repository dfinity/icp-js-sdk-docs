---
title: v3ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:141](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L141)


### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:142](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L142)
