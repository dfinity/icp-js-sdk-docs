---
title: HttpAgentBaseRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:21](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L21)


- [`HttpAgentSubmitRequest`](HttpAgentSubmitRequest.md)
- [`HttpAgentQueryRequest`](HttpAgentQueryRequest.md)
- [`HttpAgentReadStateRequest`](HttpAgentReadStateRequest.md)

## Properties

### endpoint

> `readonly` **endpoint**: [`Endpoint`](../enumerations/Endpoint.md)

Defined in: [packages/agent/src/agent/http/types.ts:22](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L22)

***

### request

> **request**: `RequestInit`

Defined in: [packages/agent/src/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L23)
