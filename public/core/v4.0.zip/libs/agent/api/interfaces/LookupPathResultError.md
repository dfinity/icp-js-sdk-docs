---
title: LookupPathResultError
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:477](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L477)


### status

> **status**: [`Error`](../enumerations/LookupPathStatus.md#error)

Defined in: [packages/agent/src/certificate.ts:478](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L478)
