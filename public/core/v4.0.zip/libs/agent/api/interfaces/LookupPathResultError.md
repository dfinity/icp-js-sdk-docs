---
title: LookupPathResultError
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:477](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L477)


### status

> **status**: [`Error`](../enumerations/LookupPathStatus.md#error)

Defined in: [packages/agent/src/certificate.ts:478](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L478)
