---
title: HttpAgentSubmitRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:28](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L28)


- [`HttpAgentBaseRequest`](HttpAgentBaseRequest.md)

## Properties

### body

> **body**: [`CallRequest`](CallRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:30](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L30)

***

### endpoint

> `readonly` **endpoint**: [`Call`](../enumerations/Endpoint.md#call)

Defined in: [packages/agent/src/agent/http/types.ts:29](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L29)

#### Overrides

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`endpoint`](HttpAgentBaseRequest.md#endpoint)

***

### request

> **request**: `RequestInit`

Defined in: [packages/agent/src/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L23)

#### Inherited from

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`request`](HttpAgentBaseRequest.md#request)
