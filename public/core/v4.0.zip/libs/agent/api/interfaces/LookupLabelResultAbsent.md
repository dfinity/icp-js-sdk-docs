---
title: LookupLabelResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:519](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L519)


### status

> **status**: [`Absent`](../enumerations/LookupLabelStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:520](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L520)
