---
title: LookupPathResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:468](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L468)


### status

> **status**: [`Unknown`](../enumerations/LookupPathStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:469](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L469)
