---
title: LookupPathResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:464](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L464)


### status

> **status**: [`Absent`](../enumerations/LookupPathStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:465](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L465)
