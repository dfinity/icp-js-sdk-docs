---
title: Signed
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:43](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/types.ts#L43)


### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/agent/src/agent/http/types.ts:44](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/types.ts#L44)

***

### sender\_pubkey

> **sender\_pubkey**: `ArrayBuffer`

Defined in: [packages/agent/src/agent/http/types.ts:45](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/types.ts#L45)

***

### sender\_sig

> **sender\_sig**: `ArrayBuffer`

Defined in: [packages/agent/src/agent/http/types.ts:46](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/types.ts#L46)
