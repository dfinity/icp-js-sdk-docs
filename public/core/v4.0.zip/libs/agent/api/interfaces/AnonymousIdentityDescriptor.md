---
title: AnonymousIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/auth.ts#L126)


### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/agent/src/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/auth.ts#L127)
