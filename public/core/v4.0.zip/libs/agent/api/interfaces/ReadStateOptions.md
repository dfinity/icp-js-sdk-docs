---
title: ReadStateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:22](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L22)

Options when doing a [Agent.readState](Agent.md#readstate) call.


### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/agent/src/agent/api.ts:26](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L26)

A list of paths to read the state of.
