---
title: ActorMethodExtended
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L122)

An actor method type, defined for each methods of the actor service.


- [`ActorMethod`](ActorMethod.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<\{ `certificate?`: [`Certificate`](../classes/Certificate.md); `httpDetails?`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

Defined in: [packages/agent/src/actor.ts:124](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L124)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`Args`

### Returns

`Promise`\<\{ `certificate?`: [`Certificate`](../classes/Certificate.md); `httpDetails?`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

## Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/agent/src/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L122)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`unknown`[]

### Returns

`Promise`\<`unknown`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/agent/src/actor.ts:108](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L108)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

> (...`args`): `Promise`\<`unknown`\>

##### Parameters

###### args

...`unknown`[]

##### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`ActorMethod`](ActorMethod.md).[`withOptions`](ActorMethod.md#withoptions)
