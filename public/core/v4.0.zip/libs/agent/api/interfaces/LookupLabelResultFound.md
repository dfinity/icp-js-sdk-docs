---
title: LookupLabelResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:527](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L527)


### status

> **status**: [`Found`](../enumerations/LookupLabelStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:528](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L528)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:529](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L529)
