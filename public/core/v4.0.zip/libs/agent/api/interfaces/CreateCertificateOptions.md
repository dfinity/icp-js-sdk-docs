---
title: CreateCertificateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:155](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L155)


### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/agent/src/certificate.ts:195](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L195)

The agent used to sync time with the IC network, if the certificate fails the freshness check.
If the agent does not implement the [HttpAgent.getTimeDiffMsecs](../classes/HttpAgent.md#gettimediffmsecs), [HttpAgent.hasSyncedTime](../classes/HttpAgent.md#hassyncedtime) and [HttpAgent.syncTime](../classes/HttpAgent.md#synctime) methods,
time will not be synced in case of a freshness check failure.

#### Default

```ts
undefined
```

***

### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: [packages/agent/src/certificate.ts:173](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L173)

BLS Verification strategy. Default strategy uses bls12_381 from @noble/curves

***

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/certificate.ts:169](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L169)

The effective canister ID of the request when verifying a response, or
the signing canister ID when verifying a certified variable.

***

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:159](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L159)

The bytes encoding the certificate to be verified

***

### disableTimeVerification?

> `optional` **disableTimeVerification**: `boolean`

Defined in: [packages/agent/src/certificate.ts:187](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L187)

Overrides the maxAgeInMinutes setting and skips comparing the client's time against the certificate. Used for scenarios where the machine's clock is known to be out of sync, or for inspecting expired certificates.

#### Default

```ts
false
```

***

### maxAgeInMinutes?

> `optional` **maxAgeInMinutes**: `number`

Defined in: [packages/agent/src/certificate.ts:181](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L181)

The maximum age of the certificate in minutes. Default is 5 minutes.
This is used to verify the time the certificate was signed, particularly for validating Delegation certificates, which can live for longer than the default window of +/- 5 minutes. If the certificate is
older than the specified age, it will fail verification.

#### Default

```ts
5
```

***

### rootKey

> **rootKey**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:164](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L164)

The root key against which to verify the certificate
(normally, the root key of the IC main network)
