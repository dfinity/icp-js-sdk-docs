---
title: PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:27](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/auth.ts#L27)

A Public Key implementation.


### derKey?

> `optional` **derKey**: [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/agent/src/auth.ts:32](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/auth.ts#L32)

***

### rawKey?

> `optional` **rawKey**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/auth.ts:31](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/auth.ts#L31)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/agent/src/auth.ts:28](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/auth.ts#L28)

#### Returns

[`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

***

### toRaw()?

> `optional` **toRaw**(): `Uint8Array`

Defined in: [packages/agent/src/auth.ts:30](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/auth.ts#L30)

#### Returns

`Uint8Array`
