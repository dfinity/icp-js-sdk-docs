---
title: ReadStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:120](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/api.ts#L120)


### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:121](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/api.ts#L121)
