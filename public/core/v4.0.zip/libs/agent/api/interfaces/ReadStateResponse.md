---
title: ReadStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:120](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L120)


### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:121](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L121)
