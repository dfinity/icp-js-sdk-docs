---
title: v2ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:124](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/api.ts#L124)


### error\_code?

> `optional` **error\_code**: `string`

Defined in: [packages/agent/src/agent/api.ts:125](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/api.ts#L125)

***

### reject\_code

> **reject\_code**: `number`

Defined in: [packages/agent/src/agent/api.ts:126](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/api.ts#L126)

***

### reject\_message

> **reject\_message**: `string`

Defined in: [packages/agent/src/agent/api.ts:127](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/api.ts#L127)
