---
title: Delegation
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:30](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L30)

A single delegation object that is signed by a private key. This is constructed by
`DelegationChain.create()`.

DelegationChain


- [`ToCborValue`](../../../agent/api/classes/ToCborValue.md)

## Constructors

### Constructor

> **new Delegation**(`pubkey`, `expiration`, `targets?`): `Delegation`

Defined in: [packages/identity/src/identity/delegation.ts:31](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L31)

#### Parameters

##### pubkey

`Uint8Array`

##### expiration

`bigint`

##### targets?

[`Principal`](../../../principal/api/classes/Principal.md)[]

#### Returns

`Delegation`

## Properties

### expiration

> `readonly` **expiration**: `bigint`

Defined in: [packages/identity/src/identity/delegation.ts:33](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L33)

***

### pubkey

> `readonly` **pubkey**: `Uint8Array`

Defined in: [packages/identity/src/identity/delegation.ts:32](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L32)

***

### targets?

> `readonly` `optional` **targets**: [`Principal`](../../../principal/api/classes/Principal.md)[]

Defined in: [packages/identity/src/identity/delegation.ts:34](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L34)

## Methods

### toCborValue()

> **toCborValue**(): `object`

Defined in: [packages/identity/src/identity/delegation.ts:37](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L37)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](../../../agent/api/variables/Cbor.md#encode) function.

#### Returns

`object`

##### expiration

> **expiration**: `bigint`

##### pubkey

> **pubkey**: `Uint8Array`\<`ArrayBufferLike`\>

##### targets?

> `optional` **targets**: [`Principal`](../../../principal/api/classes/Principal.md)[]

#### Implementation of

[`ToCborValue`](../../../agent/api/classes/ToCborValue.md).[`toCborValue`](../../../agent/api/classes/ToCborValue.md#tocborvalue)

***

### toJSON()

> **toJSON**(): `JsonnableDelegation`

Defined in: [packages/identity/src/identity/delegation.ts:47](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L47)

#### Returns

`JsonnableDelegation`
