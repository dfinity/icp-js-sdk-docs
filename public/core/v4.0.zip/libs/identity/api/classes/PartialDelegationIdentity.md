---
title: PartialDelegationIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:317](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/delegation.ts#L317)

A partial delegated identity, representing a delegation chain and the public key that it targets


- [`PartialIdentity`](PartialIdentity.md)

## Accessors

### delegation

#### Get Signature

> **get** **delegation**(): [`DelegationChain`](DelegationChain.md)

Defined in: [packages/identity/src/identity/delegation.ts:323](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/delegation.ts#L323)

The Delegation Chain of this identity.

##### Returns

[`DelegationChain`](DelegationChain.md)

***

### derKey

#### Get Signature

> **get** **derKey**(): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/identity/src/identity/partial.ts:20](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/partial.ts#L20)

The DER-encoded public key of this identity.

##### Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`derKey`](PartialIdentity.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/identity/src/identity/partial.ts:13](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/partial.ts#L13)

The raw public key of this identity.

##### Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`rawKey`](PartialIdentity.md#rawkey)

## Methods

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/identity/src/identity/partial.ts:41](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/partial.ts#L41)

The [Principal](../../../principal/api/classes/Principal.md) of this identity.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`getPrincipal`](PartialIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

Defined in: [packages/identity/src/identity/partial.ts:34](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/partial.ts#L34)

The inner [PublicKey](../../../agent/api/interfaces/PublicKey.md) used by this identity.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`getPublicKey`](PartialIdentity.md#getpublickey)

***

### toDer()

> **toDer**(): `Uint8Array`

Defined in: [packages/identity/src/identity/partial.ts:27](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/partial.ts#L27)

The DER-encoded public key of this identity.

#### Returns

`Uint8Array`

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`toDer`](PartialIdentity.md#toder)

***

### transformRequest()

> **transformRequest**(): `Promise`\<`never`\>

Defined in: [packages/identity/src/identity/partial.ts:51](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/partial.ts#L51)

Required for the Identity interface, but cannot implemented for just a public key.

#### Returns

`Promise`\<`never`\>

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`transformRequest`](PartialIdentity.md#transformrequest)

***

### fromDelegation()

> `static` **fromDelegation**(`key`, `delegation`): `PartialDelegationIdentity`

Defined in: [packages/identity/src/identity/delegation.ts:337](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/delegation.ts#L337)

Create a PartialDelegationIdentity from a [PublicKey](../../../agent/api/interfaces/PublicKey.md) and a [DelegationChain](DelegationChain.md).

#### Parameters

##### key

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

The [PublicKey](../../../agent/api/interfaces/PublicKey.md) to delegate to.

##### delegation

[`DelegationChain`](DelegationChain.md)

a [DelegationChain](DelegationChain.md) targeting the inner key.

#### Returns

`PartialDelegationIdentity`
