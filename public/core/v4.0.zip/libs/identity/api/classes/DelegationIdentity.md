---
title: DelegationIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:263](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L263)

An Identity that adds delegation to a request. Everywhere in this class, the name
innerKey refers to the SignIdentity that is being used to sign the requests, while
originalKey is the identity that is being borrowed. More identities can be used
in the middle to delegate.


- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new DelegationIdentity**(`_inner`, `_delegation`): `DelegationIdentity`

Defined in: [packages/identity/src/identity/delegation.ts:276](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L276)

#### Parameters

##### \_inner

`Pick`\<[`SignIdentity`](../../../agent/api/classes/SignIdentity.md), `"sign"`\>

##### \_delegation

[`DelegationChain`](DelegationChain.md)

#### Returns

`DelegationIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:52

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

## Methods

### getDelegation()

> **getDelegation**(): [`DelegationChain`](DelegationChain.md)

Defined in: [packages/identity/src/identity/delegation.ts:283](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L283)

#### Returns

[`DelegationChain`](DelegationChain.md)

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:65

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

Defined in: [packages/identity/src/identity/delegation.ts:287](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L287)

Returns the public key that would match this identity's signature.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`blob`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [packages/identity/src/identity/delegation.ts:293](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L293)

Signs a blob of data, with this identity's private key.

#### Parameters

##### blob

`Uint8Array`

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/identity/src/identity/delegation.ts:297](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L297)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### fromDelegation()

> `static` **fromDelegation**(`key`, `delegation`): `DelegationIdentity`

Defined in: [packages/identity/src/identity/delegation.ts:269](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L269)

Create a delegation without having access to delegateKey.

#### Parameters

##### key

`Pick`\<[`SignIdentity`](../../../agent/api/classes/SignIdentity.md), `"sign"`\>

The key used to sign the requests.

##### delegation

[`DelegationChain`](DelegationChain.md)

A delegation object created using `createDelegation`.

#### Returns

`DelegationIdentity`
