---
title: Secp256k1KeyIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/index.ts:15](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/index.ts#L15)


due to size of dependencies. Use `@dfinity/identity-secp256k1` instead.

## Constructors

### Constructor

> **new Secp256k1KeyIdentity**(): `Secp256k1KeyIdentity`

Defined in: [packages/identity/src/index.ts:16](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/index.ts#L16)

#### Returns

`Secp256k1KeyIdentity`
