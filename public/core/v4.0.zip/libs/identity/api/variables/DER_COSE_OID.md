---
title: DER_COSE_OID
editUrl: false
next: true
prev: true
---

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: packages/agent/lib/esm/der.d.ts:8

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE
