---
title: JsonnableEd25519KeyIdentity
editUrl: false
next: true
prev: true
---

> **JsonnableEd25519KeyIdentity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/identity/src/identity/ed25519.ts:239](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/ed25519.ts#L239)
