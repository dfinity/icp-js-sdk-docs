---
title: SignedDelegation
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:92](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/delegation.ts#L92)

A signed delegation, which lends its identity to the public key in the delegation
object. This is constructed by `DelegationChain.create()`.

DelegationChain


### delegation

> **delegation**: [`Delegation`](../classes/Delegation.md)

Defined in: [packages/identity/src/identity/delegation.ts:93](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/delegation.ts#L93)

***

### signature

> **signature**: [`Signature`](../../../agent/api/type-aliases/Signature.md)

Defined in: [packages/identity/src/identity/delegation.ts:94](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/delegation.ts#L94)
