---
title: JsonnableDelegationChain
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:120](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/identity/delegation.ts#L120)


### delegations

> **delegations**: `object`[]

Defined in: [packages/identity/src/identity/delegation.ts:122](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/identity/delegation.ts#L122)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `string`

##### delegation.pubkey

> **pubkey**: `string`

##### delegation.targets?

> `optional` **targets**: `string`[]

#### signature

> **signature**: `string`

***

### publicKey

> **publicKey**: `string`

Defined in: [packages/identity/src/identity/delegation.ts:121](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/identity/delegation.ts#L121)
