---
title: DelegationValidChecks
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:345](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/identity/src/identity/delegation.ts#L345)

List of things to check for a delegation chain validity.


### scope?

> `optional` **scope**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md) \| (`string` \| [`Principal`](../../../principal/api/classes/Principal.md))[]

Defined in: [packages/identity/src/identity/delegation.ts:349](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/identity/src/identity/delegation.ts#L349)

Check that the scope is amongst the scopes that this delegation has access to.
