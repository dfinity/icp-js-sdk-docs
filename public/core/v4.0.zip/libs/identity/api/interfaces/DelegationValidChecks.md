---
title: DelegationValidChecks
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:345](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/identity/delegation.ts#L345)

List of things to check for a delegation chain validity.


### scope?

> `optional` **scope**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md) \| (`string` \| [`Principal`](../../../principal/api/classes/Principal.md))[]

Defined in: [packages/identity/src/identity/delegation.ts:349](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/identity/delegation.ts#L349)

Check that the scope is amongst the scopes that this delegation has access to.
