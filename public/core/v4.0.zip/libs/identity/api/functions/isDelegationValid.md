---
title: isDelegationValid
editUrl: false
next: true
prev: true
---

> **isDelegationValid**(`chain`, `checks?`): `boolean`

Defined in: [packages/identity/src/identity/delegation.ts:370](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/delegation.ts#L370)

Analyze a DelegationChain and validate that it's valid, ie. not expired and apply to the
scope.


### chain

[`DelegationChain`](../classes/DelegationChain.md)

The chain to validate.

### checks?

[`DelegationValidChecks`](../interfaces/DelegationValidChecks.md)

Various checks to validate on the chain.

## Returns

`boolean`
