---
title: getCrc32
editUrl: false
next: true
prev: true
---

> **getCrc32**(`buf`): `number`

Defined in: [utils/getCrc.ts:42](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/principal/src/utils/getCrc.ts#L42)

Calculate the CRC32 of a Uint8Array.


### buf

`Uint8Array`

The Uint8Array to calculate the CRC32 of.

## Returns

`number`
