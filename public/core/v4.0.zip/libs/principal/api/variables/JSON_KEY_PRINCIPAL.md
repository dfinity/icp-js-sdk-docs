---
title: JSON_KEY_PRINCIPAL
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_PRINCIPAL**: `"__principal__"` = `'__principal__'`

Defined in: [principal.ts:6](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/principal/src/principal.ts#L6)
