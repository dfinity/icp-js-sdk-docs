---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

> **JsonnablePrincipal** = `object`

Defined in: [principal.ts:12](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/principal/src/principal.ts#L12)


### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [principal.ts:13](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/principal/src/principal.ts#L13)
