---
title: Principal
editUrl: false
next: true
prev: true
---

Defined in: [principal.ts:16](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L16)


### Constructor

> `protected` **new Principal**(`_arr`): `Principal`

Defined in: [principal.ts:93](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L93)

#### Parameters

##### \_arr

`Uint8Array`

#### Returns

`Principal`

## Properties

### \_isPrincipal

> `readonly` **\_isPrincipal**: `true` = `true`

Defined in: [principal.ts:91](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L91)

## Methods

### compareTo()

> **compareTo**(`other`): `"lt"` \| `"eq"` \| `"gt"`

Defined in: [principal.ts:141](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L141)

Utility method taking a Principal to compare against. Used for determining canister ranges in certificate verification

#### Parameters

##### other

`Principal`

a Principal to compare

#### Returns

`"lt"` \| `"eq"` \| `"gt"`

`'lt' | 'eq' | 'gt'` a string, representing less than, equal to, or greater than

***

### gtEq()

> **gtEq**(`other`): `boolean`

Defined in: [principal.ts:167](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L167)

Utility method checking whether a provided Principal is greater than or equal to the current one using the [Principal.compareTo](#compareto) method

#### Parameters

##### other

`Principal`

a Principal to compare

#### Returns

`boolean`

boolean

***

### isAnonymous()

> **isAnonymous**(): `boolean`

Defined in: [principal.ts:95](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L95)

#### Returns

`boolean`

***

### ltEq()

> **ltEq**(`other`): `boolean`

Defined in: [principal.ts:157](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L157)

Utility method checking whether a provided Principal is less than or equal to the current one using the [Principal.compareTo](#compareto) method

#### Parameters

##### other

`Principal`

a Principal to compare

#### Returns

`boolean`

boolean

***

### toHex()

> **toHex**(): `string`

Defined in: [principal.ts:103](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L103)

#### Returns

`string`

***

### toJSON()

> **toJSON**(): [`JsonnablePrincipal`](../type-aliases/JsonnablePrincipal.md)

Defined in: [principal.ts:132](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L132)

Serializes to JSON

#### Returns

[`JsonnablePrincipal`](../type-aliases/JsonnablePrincipal.md)

a JSON object with a single key, [JSON\_KEY\_PRINCIPAL](../variables/JSON_KEY_PRINCIPAL.md), whose value is the principal as a string

***

### toString()

> **toString**(): `string`

Defined in: [principal.ts:124](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L124)

#### Returns

`string`

***

### toText()

> **toText**(): `string`

Defined in: [principal.ts:107](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L107)

#### Returns

`string`

***

### toUint8Array()

> **toUint8Array**(): `Uint8Array`

Defined in: [principal.ts:99](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L99)

#### Returns

`Uint8Array`

***

### anonymous()

> `static` **anonymous**(): `Principal`

Defined in: [principal.ts:17](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L17)

#### Returns

`Principal`

***

### from()

> `static` **from**(`other`): `Principal`

Defined in: [principal.ts:34](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L34)

#### Parameters

##### other

`unknown`

#### Returns

`Principal`

***

### fromHex()

> `static` **fromHex**(`hex`): `Principal`

Defined in: [principal.ts:46](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L46)

#### Parameters

##### hex

`string`

#### Returns

`Principal`

***

### fromText()

> `static` **fromText**(`text`): `Principal`

Defined in: [principal.ts:50](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L50)

#### Parameters

##### text

`string`

#### Returns

`Principal`

***

### fromUint8Array()

> `static` **fromUint8Array**(`arr`): `Principal`

Defined in: [principal.ts:75](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L75)

#### Parameters

##### arr

`Uint8Array`

#### Returns

`Principal`

***

### isPrincipal()

> `static` **isPrincipal**(`other`): `other is Principal`

Defined in: [principal.ts:79](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L79)

#### Parameters

##### other

`unknown`

#### Returns

`other is Principal`

***

### managementCanister()

> `static` **managementCanister**(): `Principal`

Defined in: [principal.ts:25](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L25)

Utility method, returning the principal representing the management canister, decoded from the hex string `'aaaaa-aa'`

#### Returns

`Principal`

principal of the management canister

***

### selfAuthenticating()

> `static` **selfAuthenticating**(`publicKey`): `Principal`

Defined in: [principal.ts:29](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/principal/src/principal.ts#L29)

#### Parameters

##### publicKey

`Uint8Array`

#### Returns

`Principal`
