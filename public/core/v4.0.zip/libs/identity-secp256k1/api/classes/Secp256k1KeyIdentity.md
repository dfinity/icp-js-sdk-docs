---
title: Secp256k1KeyIdentity
editUrl: false
next: true
prev: true
---

Defined in: [identity-secp256k1/src/secp256k1.ts:102](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L102)

An Identity that can sign blobs.


- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new Secp256k1KeyIdentity**(`publicKey`, `_privateKey`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:223](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L223)

#### Parameters

##### publicKey

[`Secp256k1PublicKey`](Secp256k1PublicKey.md)

##### \_privateKey

`Uint8Array`

#### Returns

`Secp256k1KeyIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: agent/lib/esm/auth.d.ts:52

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

***

### \_privateKey

> `protected` **\_privateKey**: `Uint8Array`

Defined in: [identity-secp256k1/src/secp256k1.ts:225](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L225)

***

### \_publicKey

> **\_publicKey**: [`Secp256k1PublicKey`](Secp256k1PublicKey.md)

Defined in: [identity-secp256k1/src/secp256k1.ts:221](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L221)

## Methods

### getKeyPair()

> **getKeyPair**(): [`KeyPair`](../../../agent/api/interfaces/KeyPair.md)

Defined in: [identity-secp256k1/src/secp256k1.ts:243](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L243)

Return a copy of the key pair.

#### Returns

[`KeyPair`](../../../agent/api/interfaces/KeyPair.md)

KeyPair

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: agent/lib/esm/auth.d.ts:65

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): `Required`\<[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)\>

Defined in: [identity-secp256k1/src/secp256k1.ts:254](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L254)

Return the public key.

#### Returns

`Required`\<[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)\>

Required<PublicKey>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`data`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [identity-secp256k1/src/secp256k1.ts:263](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L263)

Signs a blob of data, with this identity's private key.

#### Parameters

##### data

`Uint8Array`

bytes to hash and sign with this identity's secretKey, producing a signature

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

signature

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### toJSON()

> **toJSON**(): [`JsonableSecp256k1Identity`](../type-aliases/JsonableSecp256k1Identity.md)

Defined in: [identity-secp256k1/src/secp256k1.ts:235](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L235)

Serialize this key to JSON-serializable object.

#### Returns

[`JsonableSecp256k1Identity`](../type-aliases/JsonableSecp256k1Identity.md)

JsonableSecp256k1Identity

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: agent/lib/esm/auth.d.ts:72

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### fromJSON()

> `static` **fromJSON**(`json`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:145](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L145)

#### Parameters

##### json

`string`

#### Returns

`Secp256k1KeyIdentity`

***

### fromKeyPair()

> `static` **fromKeyPair**(`publicKey`, `privateKey`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:162](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L162)

generates an identity from a public and private key. Please ensure that you are generating these keys securely and protect the user's private key

#### Parameters

##### publicKey

`Uint8Array`

Uint8Array

##### privateKey

`Uint8Array`

Uint8Array

#### Returns

`Secp256k1KeyIdentity`

Secp256k1KeyIdentity

***

### fromParsedJson()

> `static` **fromParsedJson**(`obj`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:137](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L137)

#### Parameters

##### obj

[`JsonableSecp256k1Identity`](../type-aliases/JsonableSecp256k1Identity.md)

#### Returns

`Secp256k1KeyIdentity`

***

### fromPem()

> `static` **fromPem**(`pemKey`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:216](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L216)

Utility method to create a Secp256k1KeyIdentity from a PEM-encoded key.

#### Parameters

##### pemKey

`string`

PEM-encoded key as a string

#### Returns

`Secp256k1KeyIdentity`

- Secp256k1KeyIdentity

***

### fromSecretKey()

> `static` **fromSecretKey**(`secretKey`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:171](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L171)

generates an identity from an existing secret key, and is the correct method to generate an identity from a seed phrase. Please ensure you protect the user's private key.

#### Parameters

##### secretKey

`Uint8Array`

Uint8Array

#### Returns

`Secp256k1KeyIdentity`

- Secp256k1KeyIdentity

***

### fromSeedPhrase()

> `static` **fromSeedPhrase**(`seedPhrase`, `password?`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:183](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L183)

Generates an identity from a seed phrase. Use carefully - seed phrases should only be used in secure contexts, and you should avoid having users copying and pasting seed phrases as much as possible.

#### Parameters

##### seedPhrase

either an array of words or a string of words separated by spaces.

`string` | `string`[]

##### password?

`string`

optional password to be used by bip39

#### Returns

`Secp256k1KeyIdentity`

Secp256k1KeyIdentity

***

### generate()

> `static` **generate**(`seed?`): `Secp256k1KeyIdentity`

Defined in: [identity-secp256k1/src/secp256k1.ts:111](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L111)

Generates an identity. If a seed is provided, the keys are generated from the
seed according to BIP 0032. Otherwise, the key pair is randomly generated.
This method throws an error in case the seed is not 32 bytes long or invalid
for use as a private key.

#### Parameters

##### seed?

`Uint8Array`\<`ArrayBufferLike`\>

the optional seed

#### Returns

`Secp256k1KeyIdentity`

Secp256k1KeyIdentity
