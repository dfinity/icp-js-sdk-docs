---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/types.ts:5](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/types.ts#L5)


- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

\[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
