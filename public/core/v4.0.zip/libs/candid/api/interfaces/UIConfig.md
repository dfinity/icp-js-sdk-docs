---
title: UIConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:10](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-core.ts#L10)


### form?

> `optional` **form**: [`InputForm`](../classes/InputForm.md)

Defined in: [packages/candid/src/candid-core.ts:12](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-core.ts#L12)

***

### input?

> `optional` **input**: `HTMLElement`

Defined in: [packages/candid/src/candid-core.ts:11](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-core.ts#L11)

## Methods

### parse()

> **parse**(`t`, `config`, `v`): `any`

Defined in: [packages/candid/src/candid-core.ts:13](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-core.ts#L13)

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)

##### config

[`ParseConfig`](ParseConfig.md)

##### v

`string`

#### Returns

`any`
