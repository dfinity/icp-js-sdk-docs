---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-core.ts#L6)


### random?

> `optional` **random**: `boolean`

Defined in: [packages/candid/src/candid-core.ts:7](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-core.ts#L7)
