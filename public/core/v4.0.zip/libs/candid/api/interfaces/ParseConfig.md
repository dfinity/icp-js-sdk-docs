---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L6)


### random?

> `optional` **random**: `boolean`

Defined in: [packages/candid/src/candid-core.ts:7](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L7)
