---
title: Rec
editUrl: false
next: true
prev: true
---

> **Rec**(): [`RecClass`](../classes/RecClass.md)

Defined in: [packages/candid/src/idl.ts:2349](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2349)


[`RecClass`](../classes/RecClass.md)

new RecClass
