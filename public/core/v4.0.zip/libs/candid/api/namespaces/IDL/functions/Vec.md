---
title: Vec
editUrl: false
next: true
prev: true
---

> **Vec**\<`T`\>(`t`): [`VecClass`](../classes/VecClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2317](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L2317)


### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`VecClass`](../classes/VecClass.md)\<`T`\>

VecClass from that type
