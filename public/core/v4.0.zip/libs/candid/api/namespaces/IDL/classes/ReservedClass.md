---
title: ReservedClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:509](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L509)

Represents an IDL Reserved


- [`PrimitiveType`](PrimitiveType.md)\<`any`\>

## Constructors

### Constructor

> **new ReservedClass**(): `ReservedClass`

#### Returns

`ReservedClass`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`constructor`](PrimitiveType.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:541](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L541)

##### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`name`](PrimitiveType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:510](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L510)

##### Returns

`IdlTypeName`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`typeName`](PrimitiveType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:278](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L278)

#### Parameters

##### \_typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`_buildTypeTableImpl`](PrimitiveType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:518](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L518)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`accept`](PrimitiveType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L238)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`buildTypeTable`](PrimitiveType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`Type`](Type.md)

Defined in: [packages/candid/src/idl.ts:271](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L271)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`checkType`](PrimitiveType.md#checktype)

***

### covariant()

> **covariant**(`_x`): `_x is any`

Defined in: [packages/candid/src/idl.ts:522](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L522)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### \_x

`any`

#### Returns

`_x is any`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`covariant`](PrimitiveType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `null`

Defined in: [packages/candid/src/idl.ts:534](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L534)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`null`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`decodeValue`](PrimitiveType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:229](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L229)

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`display`](PrimitiveType.md#display)

***

### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:530](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L530)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeType`](PrimitiveType.md#encodetype)

***

### encodeValue()

> **encodeValue**(): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:526](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L526)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeValue`](PrimitiveType.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:233](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L233)

#### Parameters

##### x

`any`

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`valueToString`](PrimitiveType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is ReservedClass`

Defined in: [packages/candid/src/idl.ts:514](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L514)

#### Parameters

##### instance

`any`

#### Returns

`instance is ReservedClass`
