---
title: encode
editUrl: false
next: true
prev: true
---

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1942](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1942)

Encode a array of values


### argTypes

[`Type`](../classes/Type.md)\<`any`\>[]

array of Types

### args

`any`[]

array of values

## Returns

`Uint8Array`

serialised value
