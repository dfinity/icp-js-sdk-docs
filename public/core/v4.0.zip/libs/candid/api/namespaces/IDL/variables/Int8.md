---
title: Int8
editUrl: false
next: true
prev: true
---

> `const` **Int8**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/candid/src/idl.ts:2292](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L2292)
