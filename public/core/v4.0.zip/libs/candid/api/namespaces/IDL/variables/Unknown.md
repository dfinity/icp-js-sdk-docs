---
title: Unknown
editUrl: false
next: true
prev: true
---

> `const` **Unknown**: [`UnknownClass`](../classes/UnknownClass.md)

Defined in: [packages/candid/src/idl.ts:2282](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L2282)

Client-only type for deserializing unknown data. Not supported by Candid, and its use is discouraged.
