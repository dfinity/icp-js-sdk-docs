---
title: Record
editUrl: false
next: true
prev: true
---

> **Record**(`t`): [`RecordClass`](../classes/RecordClass.md)

Defined in: [packages/candid/src/idl.ts:2333](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2333)


### t

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`RecordClass`](../classes/RecordClass.md)

RecordClass of string and Type
