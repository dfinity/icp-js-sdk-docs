---
title: Record
editUrl: false
next: true
prev: true
---

> **Record**(`t`): [`RecordClass`](../classes/RecordClass.md)

Defined in: [packages/candid/src/idl.ts:2333](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L2333)


### t

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`RecordClass`](../classes/RecordClass.md)

RecordClass of string and Type
