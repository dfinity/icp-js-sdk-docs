---
title: Nat32
editUrl: false
next: true
prev: true
---

> `const` **Nat32**: [`FixedNatClass`](../classes/FixedNatClass.md)

Defined in: [packages/candid/src/idl.ts:2299](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L2299)
