---
title: Type
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:223](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L223)

Represents an IDL type.


- [`PrimitiveType`](PrimitiveType.md)
- [`ConstructType`](ConstructType.md)
- [`UnknownClass`](UnknownClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new Type**\<`T`\>(): `Type`\<`T`\>

#### Returns

`Type`\<`T`\>

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/candid/src/idl.ts:225](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L225)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:224](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L224)

## Methods

### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:267](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L267)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:226](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L226)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L238)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### checkType()

> `abstract` **checkType**(`t`): `Type`

Defined in: [packages/candid/src/idl.ts:263](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L263)

#### Parameters

##### t

`Type`

#### Returns

`Type`

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:248](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L248)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:265](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L265)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

`Type`

#### Returns

`T`

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:229](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L229)

#### Returns

`string`

***

### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:261](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L261)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L255)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:233](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L233)

#### Parameters

##### x

`T`

#### Returns

`string`
