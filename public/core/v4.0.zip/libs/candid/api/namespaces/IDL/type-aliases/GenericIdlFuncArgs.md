---
title: GenericIdlFuncArgs
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncArgs** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/candid/src/idl.ts:1711](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L1711)

The generic type of the arguments of an [IDL Function](../functions/Func.md).
