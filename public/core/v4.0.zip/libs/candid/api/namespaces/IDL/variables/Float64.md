---
title: Float64
editUrl: false
next: true
prev: true
---

> `const` **Float64**: [`FloatClass`](../classes/FloatClass.md)

Defined in: [packages/candid/src/idl.ts:2290](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L2290)
