---
title: Service
editUrl: false
next: true
prev: true
---

> **Service**\<`K`, `Fields`\>(`t`): [`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

Defined in: [packages/candid/src/idl.ts:2372](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L2372)


### K

`K` *extends* `string` = `string`

### Fields

`Fields` *extends* [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md) = [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md)

## Parameters

### t

`Fields`

Record of string and FuncClass

## Returns

[`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

ServiceClass
