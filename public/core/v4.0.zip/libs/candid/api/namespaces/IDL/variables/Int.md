---
title: Int
editUrl: false
next: true
prev: true
---

> `const` **Int**: [`IntClass`](../classes/IntClass.md)

Defined in: [packages/candid/src/idl.ts:2286](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2286)
