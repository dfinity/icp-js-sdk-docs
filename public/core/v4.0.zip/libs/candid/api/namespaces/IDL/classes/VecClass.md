---
title: VecClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:882](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L882)

Represents an IDL Array

Arrays of fixed-sized nat/int type (e.g. nat8), are encoded from and decoded to TypedArrays (e.g. Uint8Array).
Arrays of float or other non-primitive types are encoded/decoded as untyped array in Javascript.


## Extends

- [`ConstructType`](ConstructType.md)\<`T`[]\>

## Type Parameters

### T

`T`

## Constructors

### Constructor

> **new VecClass**\<`T`\>(`_type`): `VecClass`\<`T`\>

Defined in: [packages/candid/src/idl.ts:899](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L899)

#### Parameters

##### \_type

[`Type`](Type.md)\<`T`\>

#### Returns

`VecClass`\<`T`\>

#### Overrides

[`ConstructType`](ConstructType.md).[`constructor`](ConstructType.md#constructor)

## Properties

### \_type

> **\_type**: [`Type`](Type.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:899](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L899)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1068](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L1068)

##### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`name`](ConstructType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:883](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L883)

##### Returns

`IdlTypeName`

#### Overrides

[`ConstructType`](ConstructType.md).[`typeName`](ConstructType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:987](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L987)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Overrides

[`ConstructType`](ConstructType.md).[`_buildTypeTableImpl`](ConstructType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:906](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L906)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`ConstructType`](ConstructType.md).[`accept`](ConstructType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L238)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`ConstructType`](ConstructType.md).[`buildTypeTable`](ConstructType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<`T`[]\>

Defined in: [packages/candid/src/idl.ts:285](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L285)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<`T`[]\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`checkType`](ConstructType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is T[]`

Defined in: [packages/candid/src/idl.ts:910](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L910)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T[]`

#### Overrides

[`ConstructType`](ConstructType.md).[`covariant`](ConstructType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `T`[]

Defined in: [packages/candid/src/idl.ts:995](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L995)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`[]

#### Overrides

[`ConstructType`](ConstructType.md).[`decodeValue`](ConstructType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:1072](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L1072)

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`display`](ConstructType.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:295](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L295)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`encodeType`](ConstructType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:935](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L935)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`[]

#### Returns

`Uint8Array`

#### Overrides

[`ConstructType`](ConstructType.md).[`encodeValue`](ConstructType.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:1076](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L1076)

#### Parameters

##### x

`T`[]

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`valueToString`](ConstructType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is VecClass<T>`

Defined in: [packages/candid/src/idl.ts:887](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L887)

#### Type Parameters

##### T

`T`

#### Parameters

##### instance

`any`

#### Returns

`instance is VecClass<T>`
