---
title: Opt
editUrl: false
next: true
prev: true
---

> **Opt**\<`T`\>(`t`): [`OptClass`](../classes/OptClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2333](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L2333)


### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`OptClass`](../classes/OptClass.md)\<`T`\>

OptClass of Type
