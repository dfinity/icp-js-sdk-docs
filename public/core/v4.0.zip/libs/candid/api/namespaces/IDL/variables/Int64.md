---
title: Int64
editUrl: false
next: true
prev: true
---

> `const` **Int64**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/candid/src/idl.ts:2295](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L2295)
