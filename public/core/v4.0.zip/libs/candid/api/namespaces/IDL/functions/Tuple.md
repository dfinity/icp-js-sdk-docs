---
title: Tuple
editUrl: false
next: true
prev: true
---

> **Tuple**\<`T`\>(...`types`): [`TupleClass`](../classes/TupleClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2309](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L2309)


### T

`T` *extends* `any`[]

## Parameters

### types

...`T`

array of any types

## Returns

[`TupleClass`](../classes/TupleClass.md)\<`T`\>

TupleClass from those types
