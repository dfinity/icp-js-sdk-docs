---
title: GenericIdlServiceFields
editUrl: false
next: true
prev: true
---

> **GenericIdlServiceFields** = `Record`\<`string`, [`FuncClass`](../classes/FuncClass.md)\>

Defined in: [packages/candid/src/idl.ts:1840](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1840)

The generic type of the fields of an [IDL Service](../functions/Service.md).
