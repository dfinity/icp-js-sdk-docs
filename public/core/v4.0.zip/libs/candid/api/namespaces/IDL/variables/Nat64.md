---
title: Nat64
editUrl: false
next: true
prev: true
---

> `const` **Nat64**: [`FixedNatClass`](../classes/FixedNatClass.md)

Defined in: [packages/candid/src/idl.ts:2308](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L2308)
