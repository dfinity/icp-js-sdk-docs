---
title: TupleClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:1384](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1384)

Represents Tuple, a syntactic sugar for Record.


## Extends

- [`RecordClass`](RecordClass.md)

## Type Parameters

### T

`T` *extends* `any`[]

## Constructors

### Constructor

> **new TupleClass**\<`T`\>(`_components`): `TupleClass`\<`T`\>

Defined in: [packages/candid/src/idl.ts:1395](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1395)

#### Parameters

##### \_components

[`Type`](Type.md)\<`any`\>[]

#### Returns

`TupleClass`\<`T`\>

#### Overrides

[`RecordClass`](RecordClass.md).[`constructor`](RecordClass.md#constructor)

## Properties

### \_components

> `protected` `readonly` **\_components**: [`Type`](Type.md)\<`any`\>[]

Defined in: [packages/candid/src/idl.ts:1393](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1393)

***

### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](Type.md)\<`any`\>\][]

Defined in: [packages/candid/src/idl.ts:1241](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1241)

#### Inherited from

[`RecordClass`](RecordClass.md).[`_fields`](RecordClass.md#_fields)

## Accessors

### fieldsAsObject

#### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](Type.md)\>

Defined in: [packages/candid/src/idl.ts:1355](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1355)

##### Returns

`Record`\<`number`, [`Type`](Type.md)\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`fieldsAsObject`](RecordClass.md#fieldsasobject)

***

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1363](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1363)

##### Returns

`string`

#### Inherited from

[`RecordClass`](RecordClass.md).[`name`](RecordClass.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1385](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1385)

##### Returns

`IdlTypeName`

#### Overrides

[`RecordClass`](RecordClass.md).[`typeName`](RecordClass.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/candid/src/idl.ts:1290](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1290)

#### Parameters

##### T

`TypeTable`

#### Returns

`void`

#### Inherited from

[`RecordClass`](RecordClass.md).[`_buildTypeTableImpl`](RecordClass.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1402](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1402)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`RecordClass`](RecordClass.md).[`accept`](RecordClass.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`RecordClass`](RecordClass.md).[`buildTypeTable`](RecordClass.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/candid/src/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L293)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`checkType`](RecordClass.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:1406](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1406)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Overrides

[`RecordClass`](RecordClass.md).[`covariant`](RecordClass.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:1430](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1430)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Overrides

[`RecordClass`](RecordClass.md).[`decodeValue`](RecordClass.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:1450](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1450)

#### Returns

`string`

#### Overrides

[`RecordClass`](RecordClass.md).[`display`](RecordClass.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:303](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L303)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`encodeType`](RecordClass.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1425](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1425)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`any`[]

#### Returns

`Uint8Array`

#### Overrides

[`RecordClass`](RecordClass.md).[`encodeValue`](RecordClass.md#encodevalue)

***

### tryAsTuple()

> **tryAsTuple**(): `null` \| [`Type`](Type.md)\<`any`\>[]

Defined in: [packages/candid/src/idl.ts:1252](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1252)

#### Returns

`null` \| [`Type`](Type.md)\<`any`\>[]

#### Inherited from

[`RecordClass`](RecordClass.md).[`tryAsTuple`](RecordClass.md#tryastuple)

***

### valueToString()

> **valueToString**(`values`): `string`

Defined in: [packages/candid/src/idl.ts:1455](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1455)

#### Parameters

##### values

`any`[]

#### Returns

`string`

#### Overrides

[`RecordClass`](RecordClass.md).[`valueToString`](RecordClass.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is TupleClass<T>`

Defined in: [packages/candid/src/idl.ts:1389](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L1389)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### instance

`any`

#### Returns

`instance is TupleClass<T>`

#### Overrides

[`RecordClass`](RecordClass.md).[`[hasInstance]`](RecordClass.md#hasinstance)
