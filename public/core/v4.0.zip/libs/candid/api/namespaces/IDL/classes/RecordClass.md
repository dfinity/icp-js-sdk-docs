---
title: RecordClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:1221](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1221)

Represents an IDL Record


mapping of function name to Type

## Extends

- [`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

## Extended by

- [`TupleClass`](TupleClass.md)

## Constructors

### Constructor

> **new RecordClass**(`fields`): `RecordClass`

Defined in: [packages/candid/src/idl.ts:1235](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1235)

#### Parameters

##### fields

`Record`\<`string`, [`Type`](Type.md)\> = `{}`

#### Returns

`RecordClass`

#### Overrides

[`ConstructType`](ConstructType.md).[`constructor`](ConstructType.md#constructor)

## Properties

### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](Type.md)\<`any`\>\][]

Defined in: [packages/candid/src/idl.ts:1233](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1233)

## Accessors

### fieldsAsObject

#### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](Type.md)\>

Defined in: [packages/candid/src/idl.ts:1347](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1347)

##### Returns

`Record`\<`number`, [`Type`](Type.md)\>

***

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1355](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1355)

##### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`name`](ConstructType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1222](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1222)

##### Returns

`IdlTypeName`

#### Overrides

[`ConstructType`](ConstructType.md).[`typeName`](ConstructType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/candid/src/idl.ts:1282](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1282)

#### Parameters

##### T

`TypeTable`

#### Returns

`void`

#### Overrides

[`ConstructType`](ConstructType.md).[`_buildTypeTableImpl`](ConstructType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1240](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1240)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`ConstructType`](ConstructType.md).[`accept`](ConstructType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L238)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`ConstructType`](ConstructType.md).[`buildTypeTable`](ConstructType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/candid/src/idl.ts:285](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L285)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`checkType`](ConstructType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is Record<string, any>`

Defined in: [packages/candid/src/idl.ts:1256](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1256)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is Record<string, any>`

#### Overrides

[`ConstructType`](ConstructType.md).[`covariant`](ConstructType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `Record`\<`string`, `any`\>

Defined in: [packages/candid/src/idl.ts:1293](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1293)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`Record`\<`string`, `any`\>

#### Overrides

[`ConstructType`](ConstructType.md).[`decodeValue`](ConstructType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:1360](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1360)

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`display`](ConstructType.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:295](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L295)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`encodeType`](ConstructType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1276](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1276)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`Record`\<`string`, `any`\>

#### Returns

`Uint8Array`

#### Overrides

[`ConstructType`](ConstructType.md).[`encodeValue`](ConstructType.md#encodevalue)

***

### tryAsTuple()

> **tryAsTuple**(): `null` \| [`Type`](Type.md)\<`any`\>[]

Defined in: [packages/candid/src/idl.ts:1244](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1244)

#### Returns

`null` \| [`Type`](Type.md)\<`any`\>[]

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:1365](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1365)

#### Parameters

##### x

`Record`\<`string`, `any`\>

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`valueToString`](ConstructType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is RecordClass`

Defined in: [packages/candid/src/idl.ts:1226](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1226)

#### Parameters

##### instance

`any`

#### Returns

`instance is RecordClass`
