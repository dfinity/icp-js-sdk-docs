---
title: inputBox
editUrl: false
next: true
prev: true
---

> **inputBox**(`t`, `config`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:12](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/candid-ui.ts#L12)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`UIConfig`](../interfaces/UIConfig.md)\>

## Returns

[`InputBox`](../classes/InputBox.md)
