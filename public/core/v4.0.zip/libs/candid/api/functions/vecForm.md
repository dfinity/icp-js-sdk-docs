---
title: vecForm
editUrl: false
next: true
prev: true
---

> **vecForm**(`ty`, `config`): [`VecForm`](../classes/VecForm.md)

Defined in: [packages/candid/src/candid-ui.ts:27](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-ui.ts#L27)


### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VecForm`](../classes/VecForm.md)
