---
title: recordForm
editUrl: false
next: true
prev: true
---

> **recordForm**(`fields`, `config`): [`RecordForm`](../classes/RecordForm.md)

Defined in: [packages/candid/src/candid-ui.ts:15](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-ui.ts#L15)


### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`RecordForm`](../classes/RecordForm.md)
