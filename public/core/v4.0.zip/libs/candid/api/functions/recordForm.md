---
title: recordForm
editUrl: false
next: true
prev: true
---

> **recordForm**(`fields`, `config`): [`RecordForm`](../classes/RecordForm.md)

Defined in: [packages/candid/src/candid-ui.ts:15](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/candid-ui.ts#L15)


### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`RecordForm`](../classes/RecordForm.md)
