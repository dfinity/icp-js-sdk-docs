---
title: optForm
editUrl: false
next: true
prev: true
---

> **optForm**(`ty`, `config`): [`OptionForm`](../classes/OptionForm.md)

Defined in: [packages/candid/src/candid-ui.ts:24](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L24)


### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`OptionForm`](../classes/OptionForm.md)
