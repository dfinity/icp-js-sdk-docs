---
title: optForm
editUrl: false
next: true
prev: true
---

> **optForm**(`ty`, `config`): [`OptionForm`](../classes/OptionForm.md)

Defined in: [packages/candid/src/candid-ui.ts:24](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/candid-ui.ts#L24)


### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`OptionForm`](../classes/OptionForm.md)
