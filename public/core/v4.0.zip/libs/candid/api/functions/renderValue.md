---
title: renderValue
editUrl: false
next: true
prev: true
---

> **renderValue**(`t`, `input`, `value`): `void`

Defined in: [packages/candid/src/candid-ui.ts:224](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-ui.ts#L224)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL Type

### input

[`InputBox`](../classes/InputBox.md)

an InputBox

### value

`any`

any

## Returns

`void`

rendering that value to the provided input
