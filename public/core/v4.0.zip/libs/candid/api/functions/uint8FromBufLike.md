---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/candid/src/utils/buffer.ts:153](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/utils/buffer.ts#L153)

Returns a true Uint8Array from an ArrayBufferLike object.


### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `DataView`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | \[`number`\] | `number`[] | \{ `buffer`: `ArrayBuffer`; \}

## Returns

`Uint8Array`

Uint8Array
