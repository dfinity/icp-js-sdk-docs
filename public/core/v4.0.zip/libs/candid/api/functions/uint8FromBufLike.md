---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/candid/src/utils/buffer.ts:153](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/utils/buffer.ts#L153)

Returns a true Uint8Array from an ArrayBufferLike object.


### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `DataView`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | \[`number`\] | `number`[] | \{ `buffer`: `ArrayBuffer`; \}

## Returns

`Uint8Array`

Uint8Array
