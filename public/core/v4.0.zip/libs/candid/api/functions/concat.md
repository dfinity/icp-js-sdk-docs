---
title: concat
editUrl: false
next: true
prev: true
---

> **concat**(...`uint8Arrays`): `Uint8Array`

Defined in: [packages/candid/src/utils/buffer.ts:5](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/utils/buffer.ts#L5)

Concatenate multiple Uint8Arrays.


### uint8Arrays

...`Uint8Array`\<`ArrayBufferLike`\>[]

The Uint8Arrays to concatenate.

## Returns

`Uint8Array`
