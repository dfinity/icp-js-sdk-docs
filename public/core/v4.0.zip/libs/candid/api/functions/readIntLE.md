---
title: readIntLE
editUrl: false
next: true
prev: true
---

> **readIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:224](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/utils/leb128.ts#L224)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
