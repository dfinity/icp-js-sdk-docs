---
title: renderInput
editUrl: false
next: true
prev: true
---

> **renderInput**(`t`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:208](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L208)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL type

## Returns

[`InputBox`](../classes/InputBox.md)

an input for that type
