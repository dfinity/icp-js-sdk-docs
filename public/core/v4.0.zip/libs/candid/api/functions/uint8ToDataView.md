---
title: uint8ToDataView
editUrl: false
next: true
prev: true
---

> **uint8ToDataView**(`uint8`): `DataView`

Defined in: [packages/candid/src/utils/buffer.ts:216](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/utils/buffer.ts#L216)

Helpers to convert a Uint8Array to a DataView.


### uint8

`Uint8Array`

Uint8Array

## Returns

`DataView`

DataView
