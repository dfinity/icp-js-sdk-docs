---
title: safeReadUint8
editUrl: false
next: true
prev: true
---

> **safeReadUint8**(`pipe`): `number`

Defined in: [packages/candid/src/utils/leb128.ts:31](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/utils/leb128.ts#L31)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

PipeArrayBuffer simulating buffer-pipe api

## Returns

`number`
