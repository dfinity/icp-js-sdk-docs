---
title: safeReadUint8
editUrl: false
next: true
prev: true
---

> **safeReadUint8**(`pipe`): `number`

Defined in: [packages/candid/src/utils/leb128.ts:31](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/utils/leb128.ts#L31)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

PipeArrayBuffer simulating buffer-pipe api

## Returns

`number`
