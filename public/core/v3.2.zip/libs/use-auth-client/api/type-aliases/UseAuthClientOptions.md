---
title: UseAuthClientOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **UseAuthClientOptions** = `object`

Defined in: [use-auth-client.ts:42](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L42)

Options for the useAuthClient hook


### actorOptions?

> `optional` **actorOptions**: [`CreateActorOptions`](../interfaces/CreateActorOptions.md) \| `Record`\<`string`, [`CreateActorOptions`](../interfaces/CreateActorOptions.md)\>

Defined in: [use-auth-client.ts:55](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L55)

Options to create an actor using the auth client identity

***

### createOptions?

> `optional` **createOptions**: `Omit`\<[`AuthClientCreateOptions`](../../auth-client/interfaces/AuthClientCreateOptions.md), `"loginOptions"`\>

Defined in: [use-auth-client.ts:47](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L47)

Options passed during the creation of the auth client

***

### createSync?

> `optional` **createSync**: `boolean`

Defined in: [use-auth-client.ts:43](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L43)

***

### loginOptions?

> `optional` **loginOptions**: [`AuthClientLoginOptions`](../../auth-client/interfaces/AuthClientLoginOptions.md)

Defined in: [use-auth-client.ts:51](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L51)

Options passed to the login method of the auth client
