---
title: useAuthClient
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **useAuthClient**(`options?`): `object`

Defined in: [use-auth-client.ts:63](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L63)

React hook to set up the Internet Computer auth client


### options?

[`UseAuthClientOptions`](../type-aliases/UseAuthClientOptions.md)

configuration for the hook

## Returns

### actor

> **actor**: `undefined` \| `null` \| [`ActorSubclass`](../../agent/type-aliases/ActorSubclass.md)

### actors

> **actors**: `Record`\<`string`, [`ActorSubclass`](../../agent/type-aliases/ActorSubclass.md)\>

### authClient

> **authClient**: `null` \| [`AuthClient`](../../auth-client/classes/AuthClient.md)

### identity

> **identity**: `null` \| [`Identity`](../../agent/interfaces/Identity.md)

### isAuthenticated

> **isAuthenticated**: `boolean`

### login()

> **login**: () => `Promise`\<`void` \| [`InternetIdentityAuthResponseSuccess`](../../auth-client/interfaces/InternetIdentityAuthResponseSuccess.md)\>

Login through your configured identity provider
Wraps the onSuccess and onError callbacks with promises for convenience

#### Returns

`Promise`\<`void` \| [`InternetIdentityAuthResponseSuccess`](../../auth-client/interfaces/InternetIdentityAuthResponseSuccess.md)\>

Returns a promise that resolves to the response from the identity provider

### logout()

> **logout**: () => `Promise`\<`void`\>

#### Returns

`Promise`\<`void`\>

## See

[UseAuthClientOptions](../type-aliases/UseAuthClientOptions.md)
