---
title: Overview
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---


- [CreateActorOptions](interfaces/CreateActorOptions.md)

## Type Aliases

- [UseAuthClientOptions](type-aliases/UseAuthClientOptions.md)

## Functions

- [useAuthClient](functions/useAuthClient.md)
