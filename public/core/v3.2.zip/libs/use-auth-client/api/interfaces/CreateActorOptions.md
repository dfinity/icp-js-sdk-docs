---
title: CreateActorOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [use-auth-client.ts:20](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L20)


### actorOptions?

> `optional` **actorOptions**: [`ActorConfig`](../../agent/interfaces/ActorConfig.md)

Defined in: [use-auth-client.ts:32](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L32)

#### See

[ActorConfig](../../agent/interfaces/ActorConfig.md)

***

### agent?

> `optional` **agent**: [`Agent`](../../agent/interfaces/Agent.md)

Defined in: [use-auth-client.ts:24](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L24)

#### See

[Agent](../../agent/interfaces/Agent.md)

***

### agentOptions?

> `optional` **agentOptions**: [`HttpAgentOptions`](../../agent/interfaces/HttpAgentOptions.md)

Defined in: [use-auth-client.ts:28](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L28)

#### See

[HttpAgentOptions](../../agent/interfaces/HttpAgentOptions.md)

***

### canisterId

> **canisterId**: `string` \| [`Principal`](../../principal/classes/Principal.md)

Defined in: [use-auth-client.ts:36](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L36)

***

### idlFactory

> **idlFactory**: [`InterfaceFactory`](../../candid/namespaces/IDL/type-aliases/InterfaceFactory.md)

Defined in: [use-auth-client.ts:34](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/use-auth-client/src/use-auth-client.ts#L34)
