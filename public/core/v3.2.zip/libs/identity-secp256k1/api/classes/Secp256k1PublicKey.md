---
title: Secp256k1PublicKey
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [identity-secp256k1/src/secp256k1.ts:27](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L27)

A Public Key implementation.


- [`PublicKey`](../../agent/interfaces/PublicKey.md)

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

Defined in: [identity-secp256k1/src/secp256k1.ts:83](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L83)

##### Returns

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`derKey`](../../agent/interfaces/PublicKey.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [identity-secp256k1/src/secp256k1.ts:77](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L77)

##### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`rawKey`](../../agent/interfaces/PublicKey.md#rawkey)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

Defined in: [identity-secp256k1/src/secp256k1.ts:93](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L93)

#### Returns

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`toDer`](../../agent/interfaces/PublicKey.md#toder)

***

### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [identity-secp256k1/src/secp256k1.ts:97](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L97)

#### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`toRaw`](../../agent/interfaces/PublicKey.md#toraw)

***

### from()

> `static` **from**(`maybeKey`): `Secp256k1PublicKey`

Defined in: [identity-secp256k1/src/secp256k1.ts:41](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L41)

Construct Secp256k1PublicKey from an existing PublicKey

#### Parameters

##### maybeKey

`unknown`

existing PublicKey, ArrayBuffer, DerEncodedPublicKey, or hex string

#### Returns

`Secp256k1PublicKey`

Instance of Secp256k1PublicKey

***

### fromDer()

> `static` **fromDer**(`derKey`): `Secp256k1PublicKey`

Defined in: [identity-secp256k1/src/secp256k1.ts:32](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L32)

#### Parameters

##### derKey

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

#### Returns

`Secp256k1PublicKey`

***

### fromRaw()

> `static` **fromRaw**(`rawKey`): `Secp256k1PublicKey`

Defined in: [identity-secp256k1/src/secp256k1.ts:28](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L28)

#### Parameters

##### rawKey

`Uint8Array`

#### Returns

`Secp256k1PublicKey`
