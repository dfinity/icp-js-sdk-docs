---
title: JsonableSecp256k1Identity
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **JsonableSecp256k1Identity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [identity-secp256k1/src/secp256k1.ts:19](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity-secp256k1/src/secp256k1.ts#L19)
