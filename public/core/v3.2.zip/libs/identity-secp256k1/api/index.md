---
title: Overview
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---


- [Secp256k1KeyIdentity](classes/Secp256k1KeyIdentity.md)
- [Secp256k1PublicKey](classes/Secp256k1PublicKey.md)

## Type Aliases

- [JsonableSecp256k1Identity](type-aliases/JsonableSecp256k1Identity.md)
