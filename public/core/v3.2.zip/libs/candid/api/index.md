---
title: Overview
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---


- [IDL](namespaces/IDL/index.md)

## Classes

- [InputBox](classes/InputBox.md)
- [InputForm](classes/InputForm.md)
- [OptionForm](classes/OptionForm.md)
- [PipeArrayBuffer](classes/PipeArrayBuffer.md)
- [RecordForm](classes/RecordForm.md)
- [Render](classes/Render.md)
- [TupleForm](classes/TupleForm.md)
- [VariantForm](classes/VariantForm.md)
- [VecForm](classes/VecForm.md)

## Interfaces

- [FormConfig](interfaces/FormConfig.md)
- [JsonArray](interfaces/JsonArray.md)
- [JsonObject](interfaces/JsonObject.md)
- [ParseConfig](interfaces/ParseConfig.md)
- [UIConfig](interfaces/UIConfig.md)

## Type Aliases

- [JsonValue](type-aliases/JsonValue.md)

## Functions

- [compare](functions/compare.md)
- [concat](functions/concat.md)
- [idlLabelToId](functions/idlLabelToId.md)
- [inputBox](functions/inputBox.md)
- [lebDecode](functions/lebDecode.md)
- [lebEncode](functions/lebEncode.md)
- [optForm](functions/optForm.md)
- [readIntLE](functions/readIntLE.md)
- [readUIntLE](functions/readUIntLE.md)
- [recordForm](functions/recordForm.md)
- [renderInput](functions/renderInput.md)
- [renderValue](functions/renderValue.md)
- [safeRead](functions/safeRead.md)
- [safeReadUint8](functions/safeReadUint8.md)
- [slebDecode](functions/slebDecode.md)
- [slebEncode](functions/slebEncode.md)
- [tupleForm](functions/tupleForm.md)
- [uint8Equals](functions/uint8Equals.md)
- [uint8FromBufLike](functions/uint8FromBufLike.md)
- [uint8ToDataView](functions/uint8ToDataView.md)
- [variantForm](functions/variantForm.md)
- [vecForm](functions/vecForm.md)
- [writeIntLE](functions/writeIntLE.md)
- [writeUIntLE](functions/writeUIntLE.md)

## References

### GenericIdlFuncArgs

Re-exports [GenericIdlFuncArgs](namespaces/IDL/type-aliases/GenericIdlFuncArgs.md)

***

### GenericIdlFuncRets

Re-exports [GenericIdlFuncRets](namespaces/IDL/type-aliases/GenericIdlFuncRets.md)

***

### GenericIdlServiceFields

Re-exports [GenericIdlServiceFields](namespaces/IDL/type-aliases/GenericIdlServiceFields.md)
