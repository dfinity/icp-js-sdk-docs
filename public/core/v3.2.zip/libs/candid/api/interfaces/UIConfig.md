---
title: UIConfig
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/candid-core.ts:10](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L10)


### form?

> `optional` **form**: [`InputForm`](../classes/InputForm.md)

Defined in: [packages/candid/src/candid-core.ts:12](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L12)

***

### input?

> `optional` **input**: `HTMLElement`

Defined in: [packages/candid/src/candid-core.ts:11](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L11)

## Methods

### parse()

> **parse**(`t`, `config`, `v`): `any`

Defined in: [packages/candid/src/candid-core.ts:13](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L13)

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)

##### config

[`ParseConfig`](ParseConfig.md)

##### v

`string`

#### Returns

`any`
