---
title: TupleClass
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/idl.ts:1355](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1355)

Represents Tuple, a syntactic sugar for Record.


## Extends

- [`RecordClass`](RecordClass.md)

## Type Parameters

### T

`T` *extends* `any`[]

## Constructors

### Constructor

> **new TupleClass**\<`T`\>(`_components`): `TupleClass`\<`T`\>

Defined in: [packages/candid/src/idl.ts:1366](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1366)

#### Parameters

##### \_components

[`Type`](Type.md)\<`any`\>[]

#### Returns

`TupleClass`\<`T`\>

#### Overrides

[`RecordClass`](RecordClass.md).[`constructor`](RecordClass.md#constructor)

## Properties

### \_components

> `protected` `readonly` **\_components**: [`Type`](Type.md)\<`any`\>[]

Defined in: [packages/candid/src/idl.ts:1364](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1364)

***

### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](Type.md)\<`any`\>\][]

Defined in: [packages/candid/src/idl.ts:1212](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1212)

#### Inherited from

[`RecordClass`](RecordClass.md).[`_fields`](RecordClass.md#_fields)

## Accessors

### fieldsAsObject

#### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](Type.md)\>

Defined in: [packages/candid/src/idl.ts:1326](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1326)

##### Returns

`Record`\<`number`, [`Type`](Type.md)\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`fieldsAsObject`](RecordClass.md#fieldsasobject)

***

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1334](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1334)

##### Returns

`string`

#### Inherited from

[`RecordClass`](RecordClass.md).[`name`](RecordClass.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1356](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1356)

##### Returns

`IdlTypeName`

#### Overrides

[`RecordClass`](RecordClass.md).[`typeName`](RecordClass.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/candid/src/idl.ts:1261](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1261)

#### Parameters

##### T

`TypeTable`

#### Returns

`void`

#### Inherited from

[`RecordClass`](RecordClass.md).[`_buildTypeTableImpl`](RecordClass.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1373](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1373)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`RecordClass`](RecordClass.md).[`accept`](RecordClass.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:217](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L217)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`RecordClass`](RecordClass.md).[`buildTypeTable`](RecordClass.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/candid/src/idl.ts:264](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L264)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`checkType`](RecordClass.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:1377](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1377)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Overrides

[`RecordClass`](RecordClass.md).[`covariant`](RecordClass.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:1401](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1401)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Overrides

[`RecordClass`](RecordClass.md).[`decodeValue`](RecordClass.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:1421](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1421)

#### Returns

`string`

#### Overrides

[`RecordClass`](RecordClass.md).[`display`](RecordClass.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:274](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L274)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`encodeType`](RecordClass.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1396](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1396)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`any`[]

#### Returns

`Uint8Array`

#### Overrides

[`RecordClass`](RecordClass.md).[`encodeValue`](RecordClass.md#encodevalue)

***

### tryAsTuple()

> **tryAsTuple**(): `null` \| [`Type`](Type.md)\<`any`\>[]

Defined in: [packages/candid/src/idl.ts:1223](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1223)

#### Returns

`null` \| [`Type`](Type.md)\<`any`\>[]

#### Inherited from

[`RecordClass`](RecordClass.md).[`tryAsTuple`](RecordClass.md#tryastuple)

***

### valueToString()

> **valueToString**(`values`): `string`

Defined in: [packages/candid/src/idl.ts:1426](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1426)

#### Parameters

##### values

`any`[]

#### Returns

`string`

#### Overrides

[`RecordClass`](RecordClass.md).[`valueToString`](RecordClass.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is TupleClass<T>`

Defined in: [packages/candid/src/idl.ts:1360](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1360)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### instance

`any`

#### Returns

`instance is TupleClass<T>`

#### Overrides

[`RecordClass`](RecordClass.md).[`[hasInstance]`](RecordClass.md#hasinstance)
