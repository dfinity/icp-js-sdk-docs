---
title: BoolClass
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/idl.ts:403](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L403)

Represents an IDL Bool


- [`PrimitiveType`](PrimitiveType.md)\<`boolean`\>

## Constructors

### Constructor

> **new BoolClass**(): `BoolClass`

#### Returns

`BoolClass`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`constructor`](PrimitiveType.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:441](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L441)

##### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`name`](PrimitiveType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:404](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L404)

##### Returns

`IdlTypeName`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`typeName`](PrimitiveType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:257](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L257)

#### Parameters

##### \_typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`_buildTypeTableImpl`](PrimitiveType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:412](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L412)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`accept`](PrimitiveType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:217](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L217)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`buildTypeTable`](PrimitiveType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`Type`](Type.md)

Defined in: [packages/candid/src/idl.ts:250](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L250)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`checkType`](PrimitiveType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is boolean`

Defined in: [packages/candid/src/idl.ts:416](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L416)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is boolean`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`covariant`](PrimitiveType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `boolean`

Defined in: [packages/candid/src/idl.ts:429](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L429)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`boolean`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`decodeValue`](PrimitiveType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:208](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L208)

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`display`](PrimitiveType.md#display)

***

### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:425](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L425)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeType`](PrimitiveType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:421](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L421)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`boolean`

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeValue`](PrimitiveType.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:212](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L212)

#### Parameters

##### x

`boolean`

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`valueToString`](PrimitiveType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is BoolClass`

Defined in: [packages/candid/src/idl.ts:408](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L408)

#### Parameters

##### instance

`any`

#### Returns

`instance is BoolClass`
