---
title: decode
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **decode**(`retTypes`, `bytes`): [`JsonValue`](../../../type-aliases/JsonValue.md)[]

Defined in: [packages/candid/src/idl.ts:1955](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1955)

Decode a binary value


### retTypes

[`Type`](../classes/Type.md)\<`any`\>[]

Types expected in the buffer.

### bytes

`Uint8Array`

hex-encoded string, or buffer.

## Returns

[`JsonValue`](../../../type-aliases/JsonValue.md)[]

Value deserialised to JS type
