---
title: subtype
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/candid/src/idl.ts:2443](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L2443)

Subtyping on Candid types t1 <: t2 (Exported for testing)


### t1

[`Type`](../classes/Type.md)

The potential subtype

### t2

[`Type`](../classes/Type.md)

The potential supertype

## Returns

`boolean`
