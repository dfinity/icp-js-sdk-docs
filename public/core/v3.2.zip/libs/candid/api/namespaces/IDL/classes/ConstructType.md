---
title: ConstructType
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/idl.ts:263](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L263)

Represents an IDL type.


- [`Type`](Type.md)\<`T`\>

## Extended by

- [`VecClass`](VecClass.md)
- [`OptClass`](OptClass.md)
- [`RecordClass`](RecordClass.md)
- [`VariantClass`](VariantClass.md)
- [`RecClass`](RecClass.md)
- [`FuncClass`](FuncClass.md)
- [`ServiceClass`](ServiceClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new ConstructType**\<`T`\>(): `ConstructType`\<`T`\>

#### Returns

`ConstructType`\<`T`\>

#### Inherited from

[`Type`](Type.md).[`constructor`](Type.md#constructor)

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/candid/src/idl.ts:204](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L204)

#### Inherited from

[`Type`](Type.md).[`name`](Type.md#name)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:203](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L203)

#### Inherited from

[`Type`](Type.md).[`typeName`](Type.md#typename)

## Methods

### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`_buildTypeTableImpl`](Type.md#_buildtypetableimpl)

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:205](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L205)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Inherited from

[`Type`](Type.md).[`accept`](Type.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:217](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L217)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`buildTypeTable`](Type.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): `ConstructType`\<`T`\>

Defined in: [packages/candid/src/idl.ts:264](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L264)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

`ConstructType`\<`T`\>

#### Overrides

[`Type`](Type.md).[`checkType`](Type.md#checktype)

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:227](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L227)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Inherited from

[`Type`](Type.md).[`covariant`](Type.md#covariant)

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:244](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L244)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Inherited from

[`Type`](Type.md).[`decodeValue`](Type.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:208](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L208)

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`display`](Type.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:274](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L274)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`Type`](Type.md).[`encodeType`](Type.md#encodetype)

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:234](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L234)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

#### Inherited from

[`Type`](Type.md).[`encodeValue`](Type.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:212](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L212)

#### Parameters

##### x

`T`

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`valueToString`](Type.md#valuetostring)
