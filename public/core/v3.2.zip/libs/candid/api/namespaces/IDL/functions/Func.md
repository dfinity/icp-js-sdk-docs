---
title: Func
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **Func**\<`Args`, `Ret`\>(`args`, `ret`, `annotations`): [`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

Defined in: [packages/candid/src/idl.ts:2339](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L2339)


### Args

`Args` *extends* [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md) = [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md)

### Ret

`Ret` *extends* [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md) = [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md)

## Parameters

### args

`Args`

array of IDL Types

### ret

`Ret`

array of IDL Types

### annotations

`string`[] = `[]`

array of strings, [] by default

## Returns

[`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

new FuncClass
