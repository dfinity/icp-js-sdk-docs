---
title: resetSubtypeCache
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **resetSubtypeCache**(): `void`

Defined in: [packages/candid/src/idl.ts:2418](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L2418)

Resets the global subtyping cache


`void`
