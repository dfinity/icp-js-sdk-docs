---
title: RecClass
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/idl.ts:1559](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1559)

Represents a reference to an IDL type, used for defining recursive data
types.


- [`ConstructType`](ConstructType.md)\<`T`\>

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new RecClass**\<`T`\>(): `RecClass`\<`T`\>

#### Returns

`RecClass`\<`T`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`constructor`](ConstructType.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1615](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1615)

##### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`name`](ConstructType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1560](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1560)

##### Returns

`IdlTypeName`

#### Overrides

[`ConstructType`](ConstructType.md).[`typeName`](ConstructType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:1599](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1599)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Overrides

[`ConstructType`](ConstructType.md).[`_buildTypeTableImpl`](ConstructType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1572](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1572)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`ConstructType`](ConstructType.md).[`accept`](ConstructType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:217](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L217)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`ConstructType`](ConstructType.md).[`buildTypeTable`](ConstructType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:264](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L264)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<`T`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`checkType`](ConstructType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:1587](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1587)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Overrides

[`ConstructType`](ConstructType.md).[`covariant`](ConstructType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:1608](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1608)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Overrides

[`ConstructType`](ConstructType.md).[`decodeValue`](ConstructType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:1619](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1619)

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`display`](ConstructType.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:274](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L274)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`encodeType`](ConstructType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:1592](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1592)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`ConstructType`](ConstructType.md).[`encodeValue`](ConstructType.md#encodevalue)

***

### fill()

> **fill**(`t`): `void`

Defined in: [packages/candid/src/idl.ts:1579](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1579)

#### Parameters

##### t

[`ConstructType`](ConstructType.md)\<`T`\>

#### Returns

`void`

***

### getType()

> **getType**(): `undefined` \| [`ConstructType`](ConstructType.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:1583](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1583)

#### Returns

`undefined` \| [`ConstructType`](ConstructType.md)\<`T`\>

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:1626](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1626)

#### Parameters

##### x

`T`

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`valueToString`](ConstructType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is RecClass<any>`

Defined in: [packages/candid/src/idl.ts:1568](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1568)

#### Parameters

##### instance

`any`

#### Returns

`instance is RecClass<any>`
