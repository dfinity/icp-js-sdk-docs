---
title: Vec
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **Vec**\<`T`\>(`t`): [`VecClass`](../classes/VecClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2296](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L2296)


### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`VecClass`](../classes/VecClass.md)\<`T`\>

VecClass from that type
