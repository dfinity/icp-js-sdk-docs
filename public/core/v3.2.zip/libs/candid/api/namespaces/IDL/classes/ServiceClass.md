---
title: ServiceClass
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/idl.ts:1821](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1821)

Represents an IDL type.


- [`ConstructType`](ConstructType.md)\<[`Principal`](../../../../principal/classes/Principal.md)\>

## Type Parameters

### K

`K` *extends* `string` = `string`

### Fields

`Fields` *extends* [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md) = [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md)

## Constructors

### Constructor

> **new ServiceClass**\<`K`, `Fields`\>(`fields`): `ServiceClass`\<`K`, `Fields`\>

Defined in: [packages/candid/src/idl.ts:1834](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1834)

#### Parameters

##### fields

`Fields`

#### Returns

`ServiceClass`\<`K`, `Fields`\>

#### Overrides

[`ConstructType`](ConstructType.md).[`constructor`](ConstructType.md#constructor)

## Properties

### \_fields

> `readonly` **\_fields**: \[`K`, `Fields`\[`K`\]\][]

Defined in: [packages/candid/src/idl.ts:1833](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1833)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1882](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1882)

##### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`name`](ConstructType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1825](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1825)

##### Returns

`IdlTypeName`

#### Overrides

[`ConstructType`](ConstructType.md).[`typeName`](ConstructType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/candid/src/idl.ts:1860](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1860)

#### Parameters

##### T

`TypeTable`

#### Returns

`void`

#### Overrides

[`ConstructType`](ConstructType.md).[`_buildTypeTableImpl`](ConstructType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1846](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1846)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`ConstructType`](ConstructType.md).[`accept`](ConstructType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:217](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L217)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`ConstructType`](ConstructType.md).[`buildTypeTable`](ConstructType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<[`Principal`](../../../../principal/classes/Principal.md)\>

Defined in: [packages/candid/src/idl.ts:264](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L264)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<[`Principal`](../../../../principal/classes/Principal.md)\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`checkType`](ConstructType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is Principal`

Defined in: [packages/candid/src/idl.ts:1849](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1849)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is Principal`

#### Overrides

[`ConstructType`](ConstructType.md).[`covariant`](ConstructType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): [`Principal`](../../../../principal/classes/Principal.md)

Defined in: [packages/candid/src/idl.ts:1873](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1873)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

[`Principal`](../../../../principal/classes/Principal.md)

#### Overrides

[`ConstructType`](ConstructType.md).[`decodeValue`](ConstructType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:208](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L208)

#### Returns

`string`

#### Inherited from

[`ConstructType`](ConstructType.md).[`display`](ConstructType.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:274](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L274)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`encodeType`](ConstructType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1854](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1854)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

[`Principal`](../../../../principal/classes/Principal.md)

#### Returns

`Uint8Array`

#### Overrides

[`ConstructType`](ConstructType.md).[`encodeValue`](ConstructType.md#encodevalue)

***

### fieldsAsObject()

> **fieldsAsObject**(): `Fields`

Defined in: [packages/candid/src/idl.ts:1891](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1891)

#### Returns

`Fields`

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:1887](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1887)

#### Parameters

##### x

[`Principal`](../../../../principal/classes/Principal.md)

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`valueToString`](ConstructType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is ServiceClass<string, GenericIdlServiceFields>`

Defined in: [packages/candid/src/idl.ts:1829](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L1829)

#### Parameters

##### instance

`any`

#### Returns

`instance is ServiceClass<string, GenericIdlServiceFields>`
