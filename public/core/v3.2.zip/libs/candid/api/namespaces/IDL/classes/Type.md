---
title: Type
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/idl.ts:202](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L202)

Represents an IDL type.


- [`PrimitiveType`](PrimitiveType.md)
- [`ConstructType`](ConstructType.md)
- [`UnknownClass`](UnknownClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new Type**\<`T`\>(): `Type`\<`T`\>

#### Returns

`Type`\<`T`\>

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/candid/src/idl.ts:204](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L204)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:203](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L203)

## Methods

### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:205](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L205)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:217](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L217)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### checkType()

> `abstract` **checkType**(`t`): `Type`

Defined in: [packages/candid/src/idl.ts:242](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L242)

#### Parameters

##### t

`Type`

#### Returns

`Type`

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:227](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L227)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:244](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L244)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

`Type`

#### Returns

`T`

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:208](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L208)

#### Returns

`string`

***

### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:240](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L240)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:234](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L234)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:212](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/idl.ts#L212)

#### Parameters

##### x

`T`

#### Returns

`string`
