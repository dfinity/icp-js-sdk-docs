---
title: uint8ToDataView
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **uint8ToDataView**(`uint8`): `DataView`

Defined in: [packages/candid/src/utils/buffer.ts:216](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/buffer.ts#L216)

Helpers to convert a Uint8Array to a DataView.


### uint8

`Uint8Array`

Uint8Array

## Returns

`DataView`

DataView
