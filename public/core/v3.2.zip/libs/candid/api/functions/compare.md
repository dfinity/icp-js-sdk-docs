---
title: compare
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **compare**(`u1`, `u2`): `number`

Defined in: [packages/candid/src/utils/buffer.ts:189](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/buffer.ts#L189)


### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`number`

number - negative if u1 < u2, positive if u1 > u2, 0 if u1 === u2
