---
title: renderInput
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **renderInput**(`t`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:208](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-ui.ts#L208)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL type

## Returns

[`InputBox`](../classes/InputBox.md)

an input for that type
