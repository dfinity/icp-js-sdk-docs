---
title: safeReadUint8
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **safeReadUint8**(`pipe`): `number`

Defined in: [packages/candid/src/utils/leb128.ts:31](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/leb128.ts#L31)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

PipeArrayBuffer simulating buffer-pipe api

## Returns

`number`
