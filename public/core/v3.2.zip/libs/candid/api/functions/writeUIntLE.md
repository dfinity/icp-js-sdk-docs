---
title: writeUIntLE
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **writeUIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:163](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/leb128.ts#L163)


### value

bigint or number

`number` | `bigint`

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
