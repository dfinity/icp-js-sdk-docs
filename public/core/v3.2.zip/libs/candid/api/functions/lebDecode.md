---
title: lebDecode
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **lebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:74](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/leb128.ts#L74)

Decode a leb encoded buffer into a bigint. The number will always be positive (does not
support signed leb encoding).


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the leb encoded bits.

## Returns

`bigint`
