---
title: uint8Equals
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **uint8Equals**(`u1`, `u2`): `boolean`

Defined in: [packages/candid/src/utils/buffer.ts:207](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/buffer.ts#L207)

Checks two uint8Arrays for equality.


### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`boolean`

boolean
