---
title: renderValue
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **renderValue**(`t`, `input`, `value`): `void`

Defined in: [packages/candid/src/candid-ui.ts:224](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-ui.ts#L224)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL Type

### input

[`InputBox`](../classes/InputBox.md)

an InputBox

### value

`any`

any

## Returns

`void`

rendering that value to the provided input
