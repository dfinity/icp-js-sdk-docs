---
title: slebEncode
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **slebEncode**(`value`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:93](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/leb128.ts#L93)

Encode a number (or bigint) into a Buffer, with support for negative numbers. The number
will be floored to the nearest integer.


### value

The number to encode.

`number` | `bigint`

## Returns

`Uint8Array`
