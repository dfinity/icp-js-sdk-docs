---
title: variantForm
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **variantForm**(`fields`, `config`): [`VariantForm`](../classes/VariantForm.md)

Defined in: [packages/candid/src/candid-ui.ts:21](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-ui.ts#L21)


### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VariantForm`](../classes/VariantForm.md)
