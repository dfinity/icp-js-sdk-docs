---
title: inputBox
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **inputBox**(`t`, `config`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:12](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-ui.ts#L12)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`UIConfig`](../interfaces/UIConfig.md)\>

## Returns

[`InputBox`](../classes/InputBox.md)
