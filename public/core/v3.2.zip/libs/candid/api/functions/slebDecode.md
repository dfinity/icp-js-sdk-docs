---
title: slebDecode
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **slebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:135](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/utils/leb128.ts#L135)

Decode a leb encoded buffer into a bigint. The number is decoded with support for negative
signed-leb encoding.


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the signed leb encoded bits.

## Returns

`bigint`
