---
title: OptionForm
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/candid-core.ts:224](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L224)


- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new OptionForm**(`ty`, `ui`): `OptionForm`

Defined in: [packages/candid/src/candid-core.ts:225](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L225)

#### Parameters

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`OptionForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/candid/src/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L101)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ty

> **ty**: [`Type`](../namespaces/IDL/classes/Type.md)

Defined in: [packages/candid/src/candid-core.ts:226](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L226)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/candid/src/candid-core.ts:227](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L227)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/candid/src/candid-core.ts:231](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L231)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**\<`T`\>(`config`): `undefined` \| \[\] \| \[`T`\]

Defined in: [packages/candid/src/candid-core.ts:239](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L239)

#### Type Parameters

##### T

`T`

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`undefined` \| \[\] \| \[`T`\]

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:114](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L114)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:106](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L106)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
