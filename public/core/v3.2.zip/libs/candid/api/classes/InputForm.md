---
title: InputForm
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/candid/src/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L100)


- [`RecordForm`](RecordForm.md)
- [`TupleForm`](TupleForm.md)
- [`VariantForm`](VariantForm.md)
- [`OptionForm`](OptionForm.md)
- [`VecForm`](VecForm.md)

## Constructors

### Constructor

> **new InputForm**(`ui`): `InputForm`

Defined in: [packages/candid/src/candid-core.ts:102](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L102)

#### Parameters

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`InputForm`

## Properties

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/candid/src/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L101)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/candid/src/candid-core.ts:102](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L102)

## Methods

### generateForm()

> `abstract` **generateForm**(): `any`

Defined in: [packages/candid/src/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L105)

#### Returns

`any`

***

### parse()

> `abstract` **parse**(`config`): `any`

Defined in: [packages/candid/src/candid-core.ts:104](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L104)

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`any`

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:114](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L114)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:106](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/candid/src/candid-core.ts#L106)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`
