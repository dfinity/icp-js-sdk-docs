---
title: Overview
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---


- [Principal](classes/Principal.md)

## Type Aliases

- [JsonnablePrincipal](type-aliases/JsonnablePrincipal.md)

## Variables

- [JSON\_KEY\_PRINCIPAL](variables/JSON_KEY_PRINCIPAL.md)

## Functions

- [getCrc32](functions/getCrc32.md)
