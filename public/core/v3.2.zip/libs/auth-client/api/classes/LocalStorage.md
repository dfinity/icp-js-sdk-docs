---
title: LocalStorage
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [storage.ts:27](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L27)

Legacy implementation of AuthClientStorage, for use where IndexedDb is not available


- [`AuthClientStorage`](../interfaces/AuthClientStorage.md)

## Constructors

### Constructor

> **new LocalStorage**(`prefix`, `_localStorage?`): `LocalStorage`

Defined in: [storage.ts:28](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L28)

#### Parameters

##### prefix

`string` = `'ic-'`

##### \_localStorage?

`Storage`

#### Returns

`LocalStorage`

## Properties

### prefix

> `readonly` **prefix**: `string` = `'ic-'`

Defined in: [storage.ts:29](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L29)

## Methods

### get()

> **get**(`key`): `Promise`\<`null` \| `string`\>

Defined in: [storage.ts:33](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L33)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`null` \| `string`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`get`](../interfaces/AuthClientStorage.md#get)

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [storage.ts:42](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L42)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`remove`](../interfaces/AuthClientStorage.md#remove)

***

### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [storage.ts:37](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L37)

#### Parameters

##### key

`string`

##### value

`string`

#### Returns

`Promise`\<`void`\>

#### Implementation of

[`AuthClientStorage`](../interfaces/AuthClientStorage.md).[`set`](../interfaces/AuthClientStorage.md#set)
