---
title: IdleManager
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [idleManager.ts:31](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L31)

Detects if the user has been idle for a duration of `idleTimeout` ms, and calls `onIdle` and registered callbacks.
By default, the IdleManager will log a user out after 10 minutes of inactivity.
To override these defaults, you can pass an `onIdle` callback, or configure a custom `idleTimeout` in milliseconds


### Constructor

> `protected` **new IdleManager**(`options`): `IdleManager`

Defined in: [idleManager.ts:76](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L76)

#### Parameters

##### options

[`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md) = `{}`

[IdleManagerOptions](../type-aliases/IdleManagerOptions.md)

#### Returns

`IdleManager`

## Properties

### callbacks

> **callbacks**: `IdleCB`[] = `[]`

Defined in: [idleManager.ts:32](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L32)

***

### idleTimeout

> **idleTimeout**: `undefined` \| `number`

Defined in: [idleManager.ts:33](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L33)

***

### timeoutID?

> `optional` **timeoutID**: `number` = `undefined`

Defined in: [idleManager.ts:34](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L34)

## Methods

### \_resetTimer()

> **\_resetTimer**(): `void`

Defined in: [idleManager.ts:138](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L138)

Resets the timeouts during cleanup

#### Returns

`void`

***

### exit()

> **exit**(): `void`

Defined in: [idleManager.ts:124](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L124)

Cleans up the idle manager and its listeners

#### Returns

`void`

***

### registerCallback()

> **registerCallback**(`callback`): `void`

Defined in: [idleManager.ts:117](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L117)

#### Parameters

##### callback

`IdleCB`

function to be called when user goes idle

#### Returns

`void`

***

### create()

> `static` **create**(`options`): `IdleManager`

Defined in: [idleManager.ts:45](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L45)

Creates an IdleManager

#### Parameters

##### options

Optional configuration

###### captureScroll?

`boolean`

capture scroll events

**Default**

```ts
false
```

###### idleTimeout?

`number`

timeout in ms

**Default**

```ts
10 minutes [600_000]
```

###### onIdle?

() => `unknown`

Callback after the user has gone idle

**See**

IdleCB

###### scrollDebounce?

`number`

scroll debounce time in ms

**Default**

```ts
100
```

#### Returns

`IdleManager`

#### See

[IdleManagerOptions](../type-aliases/IdleManagerOptions.md)
