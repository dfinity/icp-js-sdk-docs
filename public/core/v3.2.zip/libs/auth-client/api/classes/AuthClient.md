---
title: AuthClient
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [index.ts:204](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L204)

Tool to manage authentication and identity


AuthClient

## Constructors

### Constructor

> `protected` **new AuthClient**(`_identity`, `_key`, `_chain`, `_storage`, `idleManager`, `_createOptions`, `_idpWindow?`, `_eventHandler?`): `AuthClient`

Defined in: [index.ts:338](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L338)

#### Parameters

##### \_identity

[`PartialIdentity`](../../identity/classes/PartialIdentity.md) | [`Identity`](../../agent/interfaces/Identity.md)

##### \_key

[`SignIdentity`](../../agent/classes/SignIdentity.md) | [`PartialIdentity`](../../identity/classes/PartialIdentity.md)

##### \_chain

`null` | [`DelegationChain`](../../identity/classes/DelegationChain.md)

##### \_storage

[`AuthClientStorage`](../interfaces/AuthClientStorage.md)

##### idleManager

`undefined` | [`IdleManager`](IdleManager.md)

##### \_createOptions

`undefined` | [`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md)

##### \_idpWindow?

`Window`

##### \_eventHandler?

(`event`) => `void`

#### Returns

`AuthClient`

## Properties

### idleManager

> **idleManager**: `undefined` \| [`IdleManager`](IdleManager.md)

Defined in: [index.ts:343](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L343)

## Methods

### getIdentity()

> **getIdentity**(): [`Identity`](../../agent/interfaces/Identity.md)

Defined in: [index.ts:421](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L421)

#### Returns

[`Identity`](../../agent/interfaces/Identity.md)

***

### isAuthenticated()

> **isAuthenticated**(): `Promise`\<`boolean`\>

Defined in: [index.ts:425](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L425)

#### Returns

`Promise`\<`boolean`\>

***

### login()

> **login**(`options?`): `Promise`\<`void`\>

Defined in: [index.ts:458](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L458)

AuthClient Login - Opens up a new window to authenticate with Internet Identity

#### Parameters

##### options?

[`AuthClientLoginOptions`](../interfaces/AuthClientLoginOptions.md)

Options for logging in, merged with the options set during creation if any. Note: we only perform a shallow merge for the `customValues` property.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
const authClient = await AuthClient.create();
authClient.login({
 identityProvider: 'http://<canisterID>.127.0.0.1:8000',
 maxTimeToLive: BigInt (7) * BigInt(24) * BigInt(3_600_000_000_000), // 1 week
 windowOpenerFeatures: "toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100",
 onSuccess: () => {
   console.log('Login Successful!');
 },
 onError: (error) => {
   console.error('Login Failed: ', error);
 }
});
```

***

### logout()

> **logout**(`options`): `Promise`\<`void`\>

Defined in: [index.ts:561](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L561)

#### Parameters

##### options

###### returnTo?

`string`

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `Promise`\<`AuthClient`\>

Defined in: [index.ts:224](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L224)

Create an AuthClient to manage authentication and identity

#### Parameters

##### options

[`AuthClientCreateOptions`](../interfaces/AuthClientCreateOptions.md) = `{}`

Options for creating an AuthClient

#### Returns

`Promise`\<`AuthClient`\>

#### See

 - [AuthClientCreateOptions](../interfaces/AuthClientCreateOptions.md)
 - [SignIdentity](../../agent/classes/SignIdentity.md)
 - [AuthClientStorage](../interfaces/AuthClientStorage.md)
 - [IdleOptions](../interfaces/IdleOptions.md)
Default behavior is to clear stored identity and reload the page when a user goes idle, unless you set the disableDefaultIdleCallback flag or pass in a custom idle callback.

#### Example

```ts
const authClient = await AuthClient.create({
  idleOptions: {
    disableIdle: true
  }
})
```
