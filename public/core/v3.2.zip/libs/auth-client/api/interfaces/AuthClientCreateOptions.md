---
title: AuthClientCreateOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [index.ts:59](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L59)

List of options for creating an [AuthClient](../classes/AuthClient.md).


### identity?

> `optional` **identity**: [`SignIdentity`](../../agent/classes/SignIdentity.md) \| [`PartialIdentity`](../../identity/classes/PartialIdentity.md)

Defined in: [index.ts:63](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L63)

An [SignIdentity](../../agent/classes/SignIdentity.md) or [PartialIdentity](../../identity/classes/PartialIdentity.md) to authenticate via delegation.

***

### idleOptions?

> `optional` **idleOptions**: [`IdleOptions`](IdleOptions.md)

Defined in: [index.ts:83](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L83)

Options to handle idle timeouts

#### Default

```ts
after 10 minutes, invalidates the identity
```

***

### keyType?

> `optional` **keyType**: `BaseKeyType`

Defined in: [index.ts:77](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L77)

Type to use for the base key.

If you are using a custom storage provider that does not support CryptoKey storage,
you should use `Ed25519` as the key type, as it can serialize to a string.

#### Default

```ts
'ECDSA'
```

***

### loginOptions?

> `optional` **loginOptions**: [`AuthClientLoginOptions`](AuthClientLoginOptions.md)

Defined in: [index.ts:88](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L88)

Options to handle login, passed to the login method

***

### storage?

> `optional` **storage**: [`AuthClientStorage`](AuthClientStorage.md)

Defined in: [index.ts:68](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L68)

Optional storage with get, set, and remove. Uses [IdbStorage](../classes/IdbStorage.md) by default.

#### See

[AuthClientStorage](AuthClientStorage.md)
