---
title: InternetIdentityAuthResponseSuccess
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [index.ts:160](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L160)


### authnMethod

> **authnMethod**: `"passkey"` \| `"pin"` \| `"recovery"`

Defined in: [index.ts:171](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L171)

***

### delegations

> **delegations**: `object`[]

Defined in: [index.ts:162](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L162)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `bigint`

##### delegation.pubkey

> **pubkey**: `Uint8Array`

##### delegation.targets?

> `optional` **targets**: [`Principal`](../../principal/classes/Principal.md)[]

#### signature

> **signature**: `Uint8Array`

***

### kind

> **kind**: `"authorize-client-success"`

Defined in: [index.ts:161](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L161)

***

### userPublicKey

> **userPublicKey**: `Uint8Array`

Defined in: [index.ts:170](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L170)
