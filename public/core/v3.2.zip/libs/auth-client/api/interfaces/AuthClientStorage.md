---
title: AuthClientStorage
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [storage.ts:16](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L16)

Interface for persisting user authentication data


### get()

> **get**(`key`): `Promise`\<`null` \| `StoredKey`\>

Defined in: [storage.ts:17](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L17)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`null` \| `StoredKey`\>

***

### remove()

> **remove**(`key`): `Promise`\<`void`\>

Defined in: [storage.ts:21](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L21)

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`void`\>

***

### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [storage.ts:19](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/storage.ts#L19)

#### Parameters

##### key

`string`

##### value

`StoredKey`

#### Returns

`Promise`\<`void`\>
