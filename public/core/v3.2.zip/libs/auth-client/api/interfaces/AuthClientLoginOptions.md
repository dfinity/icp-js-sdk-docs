---
title: AuthClientLoginOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [index.ts:113](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L113)


### allowPinAuthentication?

> `optional` **allowPinAuthentication**: `boolean`

Defined in: [index.ts:127](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L127)

If present, indicates whether or not the Identity Provider should allow the user to authenticate and/or register using a temporary key/PIN identity. Authenticating dapps may want to prevent users from using Temporary keys/PIN identities because Temporary keys/PIN identities are less secure than Passkeys (webauthn credentials) and because Temporary keys/PIN identities generally only live in a browser database (which may get cleared by the browser/OS).

***

### customValues?

> `optional` **customValues**: `Record`\<`string`, `unknown`\>

Defined in: [index.ts:149](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L149)

Extra values to be passed in the login request during the authorize-ready phase

***

### derivationOrigin?

> `optional` **derivationOrigin**: `string` \| `URL`

Defined in: [index.ts:132](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L132)

Origin for Identity Provider to use while generating the delegated identity. For II, the derivation origin must authorize this origin by setting a record at `<derivation-origin>/.well-known/ii-alternative-origins`.

#### See

https://github.com/dfinity/internet-identity/blob/main/docs/internet-identity-spec.adoc

***

### identityProvider?

> `optional` **identityProvider**: `string` \| `URL`

Defined in: [index.ts:118](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L118)

Identity provider

#### Default

```ts
"https://identity.internetcomputer.org"
```

***

### maxTimeToLive?

> `optional` **maxTimeToLive**: `bigint`

Defined in: [index.ts:123](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L123)

Expiration of the authentication in nanoseconds

#### Default

```ts
BigInt(8) hours * BigInt(3_600_000_000_000) nanoseconds
```

***

### onError?

> `optional` **onError**: [`OnErrorFunc`](../type-aliases/OnErrorFunc.md)

Defined in: [index.ts:145](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L145)

Callback in case authentication fails

***

### onSuccess?

> `optional` **onSuccess**: [`OnSuccessFunc`](../type-aliases/OnSuccessFunc.md)

Defined in: [index.ts:141](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L141)

Callback once login has completed

***

### windowOpenerFeatures?

> `optional` **windowOpenerFeatures**: `string`

Defined in: [index.ts:137](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L137)

Auth Window feature config string

#### Example

```ts
"toolbar=0,location=0,menubar=0,width=500,height=500,left=100,top=100"
```
