---
title: IdleOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [index.ts:91](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L91)


- [`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md)

## Properties

### captureScroll?

> `optional` **captureScroll**: `boolean`

Defined in: [idleManager.ts:16](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L16)

capture scroll events

#### Default

```ts
false
```

#### Inherited from

[`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md).[`captureScroll`](../type-aliases/IdleManagerOptions.md#capturescroll)

***

### disableDefaultIdleCallback?

> `optional` **disableDefaultIdleCallback**: `boolean`

Defined in: [index.ts:102](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L102)

Disables default idle behavior - call logout & reload window

#### Default

```ts
false
```

***

### disableIdle?

> `optional` **disableIdle**: `boolean`

Defined in: [index.ts:96](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L96)

Disables idle functionality for [IdleManager](../classes/IdleManager.md)

#### Default

```ts
false
```

***

### idleTimeout?

> `optional` **idleTimeout**: `number`

Defined in: [idleManager.ts:11](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L11)

timeout in ms

#### Default

```ts
30 minutes [600_000]
```

#### Inherited from

[`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md).[`idleTimeout`](../type-aliases/IdleManagerOptions.md#idletimeout)

***

### onIdle?

> `optional` **onIdle**: `IdleCB`

Defined in: [idleManager.ts:6](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L6)

Callback after the user has gone idle

#### Inherited from

[`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md).[`onIdle`](../type-aliases/IdleManagerOptions.md#onidle)

***

### scrollDebounce?

> `optional` **scrollDebounce**: `number`

Defined in: [idleManager.ts:21](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L21)

scroll debounce time in ms

#### Default

```ts
100
```

#### Inherited from

[`IdleManagerOptions`](../type-aliases/IdleManagerOptions.md).[`scrollDebounce`](../type-aliases/IdleManagerOptions.md#scrolldebounce)
