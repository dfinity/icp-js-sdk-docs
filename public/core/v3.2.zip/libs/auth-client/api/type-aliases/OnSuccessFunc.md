---
title: OnSuccessFunc
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **OnSuccessFunc** = () => `void` \| `Promise`\<`void`\> \| (`message`) => `void` \| `Promise`\<`void`\>

Defined in: [index.ts:107](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/index.ts#L107)
