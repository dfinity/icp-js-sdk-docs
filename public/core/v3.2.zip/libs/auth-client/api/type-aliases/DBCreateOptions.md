---
title: DBCreateOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **DBCreateOptions** = `object`

Defined in: [db.ts:50](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/db.ts#L50)


### dbName?

> `optional` **dbName**: `string`

Defined in: [db.ts:51](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/db.ts#L51)

***

### storeName?

> `optional` **storeName**: `string`

Defined in: [db.ts:52](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/db.ts#L52)

***

### version?

> `optional` **version**: `number`

Defined in: [db.ts:53](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/db.ts#L53)
