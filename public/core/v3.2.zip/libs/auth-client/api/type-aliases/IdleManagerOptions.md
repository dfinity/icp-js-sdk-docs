---
title: IdleManagerOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **IdleManagerOptions** = `object`

Defined in: [idleManager.ts:2](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L2)


- [`IdleOptions`](../interfaces/IdleOptions.md)

## Properties

### captureScroll?

> `optional` **captureScroll**: `boolean`

Defined in: [idleManager.ts:16](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L16)

capture scroll events

#### Default

```ts
false
```

***

### idleTimeout?

> `optional` **idleTimeout**: `number`

Defined in: [idleManager.ts:11](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L11)

timeout in ms

#### Default

```ts
30 minutes [600_000]
```

***

### onIdle?

> `optional` **onIdle**: `IdleCB`

Defined in: [idleManager.ts:6](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L6)

Callback after the user has gone idle

***

### scrollDebounce?

> `optional` **scrollDebounce**: `number`

Defined in: [idleManager.ts:21](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/auth-client/src/idleManager.ts#L21)

scroll debounce time in ms

#### Default

```ts
100
```
