---
title: CommitBatchArgs
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [assets/src/index.ts:108](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L108)

Arguments to commit batch in asset manager


### onProgress()?

> `optional` **onProgress**: (`progress`) => `void`

Defined in: [assets/src/index.ts:109](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L109)

#### Parameters

##### progress

[`Progress`](Progress.md)

#### Returns

`void`
