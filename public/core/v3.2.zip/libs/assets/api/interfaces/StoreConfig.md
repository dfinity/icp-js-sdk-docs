---
title: StoreConfig
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [assets/src/index.ts:43](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L43)

Configuration that can be passed to set and override defaults and add progress callback


### contentEncoding?

> `optional` **contentEncoding**: [`ContentEncoding`](../type-aliases/ContentEncoding.md)

Defined in: [assets/src/index.ts:68](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L68)

Content encoding

#### Default

```ts
'identity'
```

***

### contentType?

> `optional` **contentType**: `string`

Defined in: [assets/src/index.ts:58](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L58)

File content type

#### Default

```ts
File/Blob object type or type from file name extension
```

***

### fileName?

> `optional` **fileName**: `string`

Defined in: [assets/src/index.ts:48](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L48)

File name

#### Default

```ts
File object name or name in file path
```

***

### headers?

> `optional` **headers**: \[`string`, `string`\][]

Defined in: [assets/src/index.ts:63](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L63)

Custom headers to be sent with the asset

#### Default

```ts
[]
```

***

### onProgress()?

> `optional` **onProgress**: (`progress`) => `void`

Defined in: [assets/src/index.ts:76](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L76)

Callback method to get upload progress in bytes (current / total)

#### Parameters

##### progress

[`Progress`](Progress.md)

#### Returns

`void`

***

### path?

> `optional` **path**: `string`

Defined in: [assets/src/index.ts:53](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L53)

File path that file will be uploaded to

#### Default

```ts
'/'
```

***

### sha256?

> `optional` **sha256**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [assets/src/index.ts:72](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L72)

File hash generation will be skipped if hash is provided
