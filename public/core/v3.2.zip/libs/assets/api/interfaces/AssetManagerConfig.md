---
title: AssetManagerConfig
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [assets/src/index.ts:117](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L117)

Configuration that can be passed to set the canister id of the
assets canister to be managed, inherits actor configuration and
has additional asset manager specific configuration options.


- [`ActorConfig`](../../agent/interfaces/ActorConfig.md)

## Properties

### agent?

> `optional` **agent**: [`Agent`](../../agent/interfaces/Agent.md)

Defined in: agent/lib/esm/actor.d.ts:14

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`agent`](../../agent/interfaces/ActorConfig.md#agent)

***

### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: agent/lib/esm/actor.d.ts:51

Polyfill for BLS Certificate verification in case wasm is not supported

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`blsVerify`](../../agent/interfaces/ActorConfig.md#blsverify)

***

### canisterId

> **canisterId**: `string` \| [`Principal`](../../principal/classes/Principal.md)

Defined in: agent/lib/esm/actor.d.ts:39

The Canister ID of this Actor. This is required for an Actor.

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`canisterId`](../../agent/interfaces/ActorConfig.md#canisterid)

***

### concurrency?

> `optional` **concurrency**: `number`

Defined in: [assets/src/index.ts:122](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L122)

Max number of concurrent requests to the Internet Computer

#### Default

```ts
16
```

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../principal/classes/Principal.md)

Defined in: agent/lib/esm/actor.d.ts:26

The effective canister ID. This should almost always be ignored.

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`effectiveCanisterId`](../../agent/interfaces/ActorConfig.md#effectivecanisterid)

***

### maxChunkSize?

> `optional` **maxChunkSize**: `number`

Defined in: [assets/src/index.ts:132](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L132)

Size of each chunk in bytes when the asset manager has to chunk a file

#### Default

```ts
1900000
```

***

### maxSingleFileSize?

> `optional` **maxSingleFileSize**: `number`

Defined in: [assets/src/index.ts:127](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L127)

Max file size in bytes that the asset manager shouldn't chunk

#### Default

```ts
1900000
```

***

### nonce?

> `optional` **nonce**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: agent/lib/esm/actor.d.ts:30

The nonce to use for this call. This is used to prevent replay attacks.

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`nonce`](../../agent/interfaces/ActorConfig.md#nonce)

***

### pollingOptions?

> `optional` **pollingOptions**: [`PollingOptions`](../../agent/interfaces/PollingOptions.md)

Defined in: agent/lib/esm/actor.d.ts:55

Polling options to use when making update calls. This will override the default DEFAULT_POLLING_OPTIONS.

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`pollingOptions`](../../agent/interfaces/ActorConfig.md#pollingoptions)

## Methods

### callTransform()?

> `optional` **callTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](../../agent/interfaces/CallConfig.md)\>

Defined in: agent/lib/esm/actor.d.ts:43

An override function for update calls' CallConfig. This will be called on every calls.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](../../agent/interfaces/CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](../../agent/interfaces/CallConfig.md)\>

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`callTransform`](../../agent/interfaces/ActorConfig.md#calltransform)

***

### queryTransform()?

> `optional` **queryTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](../../agent/interfaces/CallConfig.md)\>

Defined in: agent/lib/esm/actor.d.ts:47

An override function for query calls' CallConfig. This will be called on every query.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](../../agent/interfaces/CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](../../agent/interfaces/CallConfig.md)\>

#### Inherited from

[`ActorConfig`](../../agent/interfaces/ActorConfig.md).[`queryTransform`](../../agent/interfaces/ActorConfig.md#querytransform)
