---
title: Overview
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---


- [AssetManager](classes/AssetManager.md)

## Interfaces

- [AssetManagerConfig](interfaces/AssetManagerConfig.md)
- [CommitBatchArgs](interfaces/CommitBatchArgs.md)
- [Progress](interfaces/Progress.md)
- [StoreConfig](interfaces/StoreConfig.md)

## Type Aliases

- [ContentEncoding](type-aliases/ContentEncoding.md)
- [StoreArgs](type-aliases/StoreArgs.md)
- [StoreBlobArgs](type-aliases/StoreBlobArgs.md)
- [StoreBytesArgs](type-aliases/StoreBytesArgs.md)
- [StoreFileArgs](type-aliases/StoreFileArgs.md)
- [StorePathArgs](type-aliases/StorePathArgs.md)
- [StoreReadableArgs](type-aliases/StoreReadableArgs.md)
