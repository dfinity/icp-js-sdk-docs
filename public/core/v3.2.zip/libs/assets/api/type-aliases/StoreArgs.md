---
title: StoreArgs
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **StoreArgs** = [`StoreReadableArgs`](StoreReadableArgs.md) \| [`StoreFileArgs`](StoreFileArgs.md) \| [`StoreBlobArgs`](StoreBlobArgs.md) \| [`StorePathArgs`](StorePathArgs.md) \| [`StoreBytesArgs`](StoreBytesArgs.md)

Defined in: [assets/src/index.ts:98](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L98)

Arguments to store an asset in asset manager
