---
title: AssetManager
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [assets/src/index.ts:135](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L135)


### Constructor

> **new AssetManager**(`config`): `AssetManager`

Defined in: [assets/src/index.ts:145](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L145)

Create assets canister manager instance

#### Parameters

##### config

[`AssetManagerConfig`](../interfaces/AssetManagerConfig.md)

Additional configuration options, canister id is required

#### Returns

`AssetManager`

## Methods

### batch()

> **batch**(): `AssetManagerBatch`

Defined in: [assets/src/index.ts:267](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L267)

Create a batch assets operations instance, commit multiple operations in a single request

#### Returns

`AssetManagerBatch`

***

### clear()

> **clear**(): `Promise`\<`void`\>

Defined in: [assets/src/index.ts:235](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L235)

Delete all files from assets canister

#### Returns

`Promise`\<`void`\>

***

### delete()

> **delete**(`key`): `Promise`\<`void`\>

Defined in: [assets/src/index.ts:228](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L228)

Delete file from assets canister

#### Parameters

##### key

`string`

The path to the file on the assets canister e.g. /folder/to/my_file.txt

#### Returns

`Promise`\<`void`\>

***

### get()

> **get**(`key`, `acceptEncodings?`): `Promise`\<`Asset`\>

Defined in: [assets/src/index.ts:244](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L244)

Get asset instance from assets canister

#### Parameters

##### key

`string`

The path to the file on the assets canister e.g. /folder/to/my_file.txt

##### acceptEncodings?

[`ContentEncoding`](../type-aliases/ContentEncoding.md)[]

The accepted content encodings, defaults to ['identity']

#### Returns

`Promise`\<`Asset`\>

***

### list()

> **list**(): `Promise`\<`object`[]\>

Defined in: [assets/src/index.ts:184](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L184)

Get list of all files in assets canister

#### Returns

`Promise`\<`object`[]\>

All files in asset canister

***

### store()

> **store**(...`args`): `Promise`\<`string`\>

Defined in: [assets/src/index.ts:192](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L192)

Store data on assets canister

#### Parameters

##### args

...[`StoreArgs`](../type-aliases/StoreArgs.md)

Arguments with either a file, blob, path, bytes or custom Readable implementation

#### Returns

`Promise`\<`string`\>

***

### toReadable()

> `static` **toReadable**(...`args`): `Promise`\<`Readable`\>

Defined in: [assets/src/index.ts:157](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/assets/src/index.ts#L157)

Create readable from store arguments

#### Parameters

##### args

...[`StoreArgs`](../type-aliases/StoreArgs.md)

Arguments with either a file, blob, path, bytes or custom Readable implementation

#### Returns

`Promise`\<`Readable`\>
