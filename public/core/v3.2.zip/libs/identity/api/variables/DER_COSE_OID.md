---
title: DER_COSE_OID
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: packages/agent/lib/esm/der.d.ts:8

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE
