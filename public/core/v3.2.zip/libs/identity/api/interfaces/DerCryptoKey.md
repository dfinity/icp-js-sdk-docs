---
title: DerCryptoKey
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/identity/src/identity/ecdsa.ts:25](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L25)


- `CryptoKey`

## Properties

### algorithm

> `readonly` **algorithm**: `KeyAlgorithm`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6462

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/algorithm)

#### Inherited from

`CryptoKey.algorithm`

***

### extractable

> `readonly` **extractable**: `boolean`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6464

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/extractable)

#### Inherited from

`CryptoKey.extractable`

***

### toDer()

> **toDer**: () => [`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ecdsa.ts:26](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L26)

#### Returns

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

***

### type

> `readonly` **type**: `KeyType`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6466

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/type)

#### Inherited from

`CryptoKey.type`

***

### usages

> `readonly` **usages**: `KeyUsage`[]

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6468

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/usages)

#### Inherited from

`CryptoKey.usages`
