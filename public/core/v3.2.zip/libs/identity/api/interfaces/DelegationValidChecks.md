---
title: DelegationValidChecks
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/identity/src/identity/delegation.ts:345](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L345)

List of things to check for a delegation chain validity.


### scope?

> `optional` **scope**: `string` \| [`Principal`](../../principal/classes/Principal.md) \| (`string` \| [`Principal`](../../principal/classes/Principal.md))[]

Defined in: [packages/identity/src/identity/delegation.ts:349](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L349)

Check that the scope is amongst the scopes that this delegation has access to.
