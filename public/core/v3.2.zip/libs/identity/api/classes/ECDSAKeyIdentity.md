---
title: ECDSAKeyIdentity
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/identity/src/identity/ecdsa.ts:52](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L52)

An identity interface that wraps an ECDSA keypair using the P-256 named curve. Supports DER-encoding and decoding for agent calls


- [`SignIdentity`](../../agent/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new ECDSAKeyIdentity**(`keyPair`, `derKey`, `subtleCrypto`): `ECDSAKeyIdentity`

Defined in: [packages/identity/src/identity/ecdsa.ts:108](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L108)

#### Parameters

##### keyPair

`CryptoKeyPair`

##### derKey

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

##### subtleCrypto

`SubtleCrypto`

#### Returns

`ECDSAKeyIdentity`

#### Overrides

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`constructor`](../../agent/classes/SignIdentity.md#constructor)

## Properties

### \_derKey

> `protected` **\_derKey**: [`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ecdsa.ts:103](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L103)

***

### \_keyPair

> `protected` **\_keyPair**: `CryptoKeyPair`

Defined in: [packages/identity/src/identity/ecdsa.ts:104](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L104)

***

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../principal/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:52

#### Inherited from

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`_principal`](../../agent/classes/SignIdentity.md#_principal)

***

### \_subtleCrypto

> `protected` **\_subtleCrypto**: `SubtleCrypto`

Defined in: [packages/identity/src/identity/ecdsa.ts:105](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L105)

## Methods

### getKeyPair()

> **getKeyPair**(): `CryptoKeyPair`

Defined in: [packages/identity/src/identity/ecdsa.ts:123](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L123)

Return the internally-used key pair.

#### Returns

`CryptoKeyPair`

a CryptoKeyPair

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:65

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../principal/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`getPrincipal`](../../agent/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../agent/interfaces/PublicKey.md) & [`DerCryptoKey`](../interfaces/DerCryptoKey.md)

Defined in: [packages/identity/src/identity/ecdsa.ts:131](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L131)

Return the public key.

#### Returns

[`PublicKey`](../../agent/interfaces/PublicKey.md) & [`DerCryptoKey`](../interfaces/DerCryptoKey.md)

an [& DerCryptoKey](../../agent/interfaces/PublicKey.md)

#### Overrides

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`getPublicKey`](../../agent/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`challenge`): `Promise`\<[`Signature`](../../agent/type-aliases/Signature.md)\>

Defined in: [packages/identity/src/identity/ecdsa.ts:146](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L146)

Signs a blob of data, with this identity's private key.

#### Parameters

##### challenge

`Uint8Array`

challenge to sign with this identity's secretKey, producing a signature

#### Returns

`Promise`\<[`Signature`](../../agent/type-aliases/Signature.md)\>

signature

#### Overrides

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`sign`](../../agent/classes/SignIdentity.md#sign)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: packages/agent/lib/esm/auth.d.ts:72

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../agent/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`transformRequest`](../../agent/classes/SignIdentity.md#transformrequest)

***

### fromKeyPair()

> `static` **fromKeyPair**(`keyPair`, `subtleCrypto?`): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [packages/identity/src/identity/ecdsa.ts:89](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L89)

generates an identity from a public and private key. Please ensure that you are generating these keys securely and protect the user's private key

#### Parameters

##### keyPair

a CryptoKeyPair

`CryptoKeyPair` | \{ `privateKey`: `CryptoKey`; `publicKey`: `CryptoKey`; \}

##### subtleCrypto?

`SubtleCrypto`

a SubtleCrypto interface in case one is not available globally

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

an ECDSAKeyIdentity

***

### generate()

> `static` **generate**(`options?`): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [packages/identity/src/identity/ecdsa.ts:61](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ecdsa.ts#L61)

Generates a randomly generated identity for use in calls to the Internet Computer.

#### Parameters

##### options?

[`CryptoKeyOptions`](../type-aliases/CryptoKeyOptions.md)

optional settings

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

a ECDSAKeyIdentity
