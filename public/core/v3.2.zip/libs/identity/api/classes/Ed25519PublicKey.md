---
title: Ed25519PublicKey
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/identity/src/identity/ed25519.ts:21](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L21)

A Public Key implementation.


- [`PublicKey`](../../agent/interfaces/PublicKey.md)

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ed25519.ts:84](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L84)

##### Returns

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`derKey`](../../agent/interfaces/PublicKey.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/identity/src/identity/ed25519.ts:78](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L78)

##### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`rawKey`](../../agent/interfaces/PublicKey.md#rawkey)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ed25519.ts:97](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L97)

#### Returns

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`toDer`](../../agent/interfaces/PublicKey.md#toder)

***

### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/identity/src/identity/ed25519.ts:101](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L101)

#### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../agent/interfaces/PublicKey.md).[`toRaw`](../../agent/interfaces/PublicKey.md#toraw)

***

### from()

> `static` **from**(`maybeKey`): `Ed25519PublicKey`

Defined in: [packages/identity/src/identity/ed25519.ts:27](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L27)

Construct Ed25519PublicKey from an existing PublicKey

#### Parameters

##### maybeKey

`unknown`

existing PublicKey, ArrayBuffer, DerEncodedPublicKey, or hex string

#### Returns

`Ed25519PublicKey`

Instance of Ed25519PublicKey

***

### fromDer()

> `static` **fromDer**(`derKey`): `Ed25519PublicKey`

Defined in: [packages/identity/src/identity/ed25519.ts:55](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L55)

#### Parameters

##### derKey

[`DerEncodedPublicKey`](../../agent/type-aliases/DerEncodedPublicKey.md)

#### Returns

`Ed25519PublicKey`

***

### fromRaw()

> `static` **fromRaw**(`rawKey`): `Ed25519PublicKey`

Defined in: [packages/identity/src/identity/ed25519.ts:51](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/ed25519.ts#L51)

#### Parameters

##### rawKey

`Uint8Array`

#### Returns

`Ed25519PublicKey`
