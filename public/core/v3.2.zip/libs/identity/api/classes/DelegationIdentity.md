---
title: DelegationIdentity
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/identity/src/identity/delegation.ts:263](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L263)

An Identity that adds delegation to a request. Everywhere in this class, the name
innerKey refers to the SignIdentity that is being used to sign the requests, while
originalKey is the identity that is being borrowed. More identities can be used
in the middle to delegate.


- [`SignIdentity`](../../agent/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new DelegationIdentity**(`_inner`, `_delegation`): `DelegationIdentity`

Defined in: [packages/identity/src/identity/delegation.ts:276](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L276)

#### Parameters

##### \_inner

`Pick`\<[`SignIdentity`](../../agent/classes/SignIdentity.md), `"sign"`\>

##### \_delegation

[`DelegationChain`](DelegationChain.md)

#### Returns

`DelegationIdentity`

#### Overrides

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`constructor`](../../agent/classes/SignIdentity.md#constructor)

## Properties

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../principal/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:52

#### Inherited from

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`_principal`](../../agent/classes/SignIdentity.md#_principal)

## Methods

### getDelegation()

> **getDelegation**(): [`DelegationChain`](DelegationChain.md)

Defined in: [packages/identity/src/identity/delegation.ts:283](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L283)

#### Returns

[`DelegationChain`](DelegationChain.md)

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:65

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../principal/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`getPrincipal`](../../agent/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../agent/interfaces/PublicKey.md)

Defined in: [packages/identity/src/identity/delegation.ts:287](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L287)

Returns the public key that would match this identity's signature.

#### Returns

[`PublicKey`](../../agent/interfaces/PublicKey.md)

#### Overrides

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`getPublicKey`](../../agent/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`blob`): `Promise`\<[`Signature`](../../agent/type-aliases/Signature.md)\>

Defined in: [packages/identity/src/identity/delegation.ts:293](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L293)

Signs a blob of data, with this identity's private key.

#### Parameters

##### blob

`Uint8Array`

#### Returns

`Promise`\<[`Signature`](../../agent/type-aliases/Signature.md)\>

#### Overrides

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`sign`](../../agent/classes/SignIdentity.md#sign)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/identity/src/identity/delegation.ts:297](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L297)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../agent/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Overrides

[`SignIdentity`](../../agent/classes/SignIdentity.md).[`transformRequest`](../../agent/classes/SignIdentity.md#transformrequest)

***

### fromDelegation()

> `static` **fromDelegation**(`key`, `delegation`): `DelegationIdentity`

Defined in: [packages/identity/src/identity/delegation.ts:269](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L269)

Create a delegation without having access to delegateKey.

#### Parameters

##### key

`Pick`\<[`SignIdentity`](../../agent/classes/SignIdentity.md), `"sign"`\>

The key used to sign the requests.

##### delegation

[`DelegationChain`](DelegationChain.md)

A delegation object created using `createDelegation`.

#### Returns

`DelegationIdentity`
