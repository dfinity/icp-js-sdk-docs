---
title: PartialIdentity
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/identity/src/identity/partial.ts:7](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L7)

A partial delegated identity, representing a delegation chain and the public key that it targets


- [`PartialDelegationIdentity`](PartialDelegationIdentity.md)

## Implements

- [`Identity`](../../agent/interfaces/Identity.md)

## Constructors

### Constructor

> **new PartialIdentity**(`inner`): `PartialIdentity`

Defined in: [packages/identity/src/identity/partial.ts:57](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L57)

#### Parameters

##### inner

[`PublicKey`](../../agent/interfaces/PublicKey.md)

#### Returns

`PartialIdentity`

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/identity/src/identity/partial.ts:20](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L20)

The DER-encoded public key of this identity.

##### Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/identity/src/identity/partial.ts:13](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L13)

The raw public key of this identity.

##### Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

## Methods

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/classes/Principal.md)

Defined in: [packages/identity/src/identity/partial.ts:41](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L41)

The [Principal](../../principal/classes/Principal.md) of this identity.

#### Returns

[`Principal`](../../principal/classes/Principal.md)

#### Implementation of

[`Identity`](../../agent/interfaces/Identity.md).[`getPrincipal`](../../agent/interfaces/Identity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../agent/interfaces/PublicKey.md)

Defined in: [packages/identity/src/identity/partial.ts:34](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L34)

The inner [PublicKey](../../agent/interfaces/PublicKey.md) used by this identity.

#### Returns

[`PublicKey`](../../agent/interfaces/PublicKey.md)

***

### toDer()

> **toDer**(): `Uint8Array`

Defined in: [packages/identity/src/identity/partial.ts:27](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L27)

The DER-encoded public key of this identity.

#### Returns

`Uint8Array`

***

### transformRequest()

> **transformRequest**(): `Promise`\<`never`\>

Defined in: [packages/identity/src/identity/partial.ts:51](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/partial.ts#L51)

Required for the Identity interface, but cannot implemented for just a public key.

#### Returns

`Promise`\<`never`\>

#### Implementation of

[`Identity`](../../agent/interfaces/Identity.md).[`transformRequest`](../../agent/interfaces/Identity.md#transformrequest)
