---
title: Secp256k1KeyIdentity
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/identity/src/index.ts:11](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/index.ts#L11)


due to size of dependencies. Use `@dfinity/identity-secp256k1` instead.

## Constructors

### Constructor

> **new Secp256k1KeyIdentity**(): `Secp256k1KeyIdentity`

Defined in: [packages/identity/src/index.ts:12](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/index.ts#L12)

#### Returns

`Secp256k1KeyIdentity`
