---
title: isDelegationValid
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **isDelegationValid**(`chain`, `checks?`): `boolean`

Defined in: [packages/identity/src/identity/delegation.ts:358](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/identity/src/identity/delegation.ts#L358)

Analyze a DelegationChain and validate that it's valid, ie. not expired and apply to the
scope.


### chain

[`DelegationChain`](../classes/DelegationChain.md)

The chain to validate.

### checks?

[`DelegationValidChecks`](../interfaces/DelegationValidChecks.md)

Various checks to validate on the chain.

## Returns

`boolean`
