---
title: verify
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **verify**: (`pk`, `sig`, `msg`) => `boolean`

Defined in: [packages/agent/src/utils/bls.ts:4](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/utils/bls.ts#L4)


### pk

`Uint8Array`

### sig

`Uint8Array`

### msg

`Uint8Array`

## Returns

`boolean`
