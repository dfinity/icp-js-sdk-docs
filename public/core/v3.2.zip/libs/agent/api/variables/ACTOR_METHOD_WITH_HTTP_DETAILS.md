---
title: ACTOR_METHOD_WITH_HTTP_DETAILS
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> `const` **ACTOR\_METHOD\_WITH\_HTTP\_DETAILS**: `"http-details"` = `'http-details'`

Defined in: [packages/agent/src/actor.ts:330](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L330)
