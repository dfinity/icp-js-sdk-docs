---
title: IC_RESPONSE_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/constants.ts#L12)

The `\x0Bic-response` domain separator used in the signature of IC responses.
