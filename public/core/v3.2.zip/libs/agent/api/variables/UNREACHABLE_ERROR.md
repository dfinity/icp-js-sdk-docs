---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/agent/src/errors.ts:826](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L826)

Special error used to indicate that a code path is unreachable.

For internal use only.
