---
title: constructRequest
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **constructRequest**(`options`): `Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

Defined in: [packages/agent/src/polling/index.ts:231](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L231)

Constructs a read state request for the given paths.
If the request is already signed and has an expiry, it will be returned as is.
Otherwise, a new request will be created.


### options

The options to use for creating the request.

#### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to create the request.

#### paths

`Uint8Array`\<`ArrayBufferLike`\>[][]

The paths to read from.

#### pollingOptions

[`PollingOptions`](../interfaces/PollingOptions.md)

The options to use for creating the request.

## Returns

`Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

The read state request.
