---
title: wrapDER
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **wrapDER**(`payload`, `oid`): `Uint8Array`

Defined in: [packages/agent/src/der.ts:111](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/der.ts#L111)

Wraps the given `payload` in a DER encoding tagged with the given encoded `oid` like so:
`SEQUENCE(oid, BITSTRING(payload))`


### payload

`Uint8Array`

The payload to encode as the bit string

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) OID to tag the payload with

## Returns

`Uint8Array`
