---
title: makeNonceTransform
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **makeNonceTransform**(`nonceFn`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:117](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/transforms.ts#L117)

Create a Nonce transform, which takes a function that returns a Buffer, and adds it
as the nonce to every call requests.


### nonceFn

() => [`Nonce`](../type-aliases/Nonce.md)

A function that returns a buffer. By default uses a semi-random method.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
