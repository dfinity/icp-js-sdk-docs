---
title: randomNumber
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **randomNumber**(): `number`

Defined in: [packages/agent/src/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff


`number`

a random number
