---
title: check_canister_ranges
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/agent/src/certificate.ts:795](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L795)

Check if a canister ID falls within the canister ranges of a given subnet


### params

the parameters with which to check the canister ranges

#### canisterId

[`Principal`](../../principal/classes/Principal.md)

the canister ID to check

#### subnetId

[`Principal`](../../principal/classes/Principal.md)

the subnet ID from which to check the canister ranges

#### tree

[`HashTree`](../type-aliases/HashTree.md)

the hash tree in which to lookup the subnet's canister ranges

## Returns

`boolean`

`true` if the canister is in the range, `false` otherwise
