---
title: isV3ResponseBody
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **isV3ResponseBody**(`body`): `body is v3ResponseBody`

Defined in: [packages/agent/src/agent/api.ts:150](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L150)

Utility function to check if a body is a v3ResponseBody for type safety.


### body

The body to check

`null` | [`v2ResponseBody`](../interfaces/v2ResponseBody.md) | [`v3ResponseBody`](../interfaces/v3ResponseBody.md)

## Returns

`body is v3ResponseBody`

boolean indicating if the body is a v3ResponseBody
