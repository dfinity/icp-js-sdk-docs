---
title: makeExpiryTransform
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **makeExpiryTransform**(`delayInMilliseconds`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:136](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/transforms.ts#L136)

Create a transform that adds a delay (by default 5 minutes) to the expiry.


### delayInMilliseconds

`number`

The delay to add to the call time, in milliseconds.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
