---
title: pollForResponse
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **pollForResponse**(`agent`, `canisterId`, `requestId`, `options`): `Promise`\<\{ `certificate`: [`Certificate`](../classes/Certificate.md); `reply`: `Uint8Array`; \}\>

Defined in: [packages/agent/src/polling/index.ts:129](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L129)

Polls the IC to check the status of the given request then
returns the response bytes once the request has been processed.


### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to poll read_state.

### canisterId

[`Principal`](../../principal/classes/Principal.md)

The effective canister ID.

### requestId

[`RequestId`](../type-aliases/RequestId.md)

The Request ID to poll status for.

### options

[`PollingOptions`](../interfaces/PollingOptions.md) = `{}`

polling options to control behavior

## Returns

`Promise`\<\{ `certificate`: [`Certificate`](../classes/Certificate.md); `reply`: `Uint8Array`; \}\>
