---
title: domain_sep
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **domain\_sep**(`s`): `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:447](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L447)

Creates a domain separator for hashing by encoding the input string
with its length as a prefix.


### s

`string`

The input string to encode.

## Returns

`Uint8Array`

A Uint8Array containing the encoded domain separator.
