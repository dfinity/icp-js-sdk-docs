---
title: flatten_forks
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **flatten\_forks**(`t`): ([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

Defined in: [packages/agent/src/certificate.ts:673](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L673)

If the tree is a fork, flatten it into an array of trees


### t

[`HashTree`](../type-aliases/HashTree.md)

the tree to flatten

## Returns

([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

the flattened tree
