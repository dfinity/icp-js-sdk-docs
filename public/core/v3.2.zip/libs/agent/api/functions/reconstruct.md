---
title: reconstruct
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **reconstruct**(`t`): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/agent/src/certificate.ts:418](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L418)


### t

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to reconstruct

## Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>
