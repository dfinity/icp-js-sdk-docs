---
title: lookup_subtree
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **lookup\_subtree**(`path`, `tree`): [`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:632](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L632)

Lookup a subtree in a tree.


### path

[`NodePath`](../type-aliases/NodePath.md)

the path to look up

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

the result of the lookup
