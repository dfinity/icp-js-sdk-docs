---
title: encodeLen
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/agent/src/der.ts:23](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/der.ts#L23)


### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
