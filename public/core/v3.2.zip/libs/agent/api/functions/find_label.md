---
title: find_label
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **find\_label**(`label`, `tree`): [`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:690](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L690)

Find a label in a tree


### label

[`NodeLabel`](../type-aliases/NodeLabel.md)

the label to find

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

the result of the label lookup
