---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/auth.ts#L139)

Create an IdentityDescriptor from a @dfinity/identity Identity


### identity

identity describe in returned descriptor

[`SignIdentity`](../classes/SignIdentity.md) | [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
