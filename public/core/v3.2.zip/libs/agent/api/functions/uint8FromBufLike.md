---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/agent/src/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.


### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | `DataView`\<`ArrayBufferLike`\> | \[`number`\] | \{ `buffer`: `ArrayBuffer`; \} | `number`[]

## Returns

`Uint8Array`

Uint8Array
