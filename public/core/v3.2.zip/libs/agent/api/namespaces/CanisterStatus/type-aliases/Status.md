---
title: Status
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **Status** = `string` \| `Uint8Array` \| `Date` \| `Uint8Array`[] \| [`Principal`](../../../../principal/classes/Principal.md)[] \| [`SubnetStatus`](SubnetStatus.md) \| `bigint` \| `null`

Defined in: [packages/agent/src/canisterStatus/index.ts:60](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/canisterStatus/index.ts#L60)

Types of an entry on the canisterStatus map.
An entry of null indicates that the request failed, due to lack of permissions or the result being missing.
