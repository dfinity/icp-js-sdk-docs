---
title: request
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **request**(`options`): `Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:153](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/canisterStatus/index.ts#L153)

Requests information from a canister's `read_state` endpoint.
Can be used to request information about the canister's controllers, time, module hash, candid interface, and more.


### options

[`CanisterStatusOptions`](../type-aliases/CanisterStatusOptions.md)

The configuration for the canister status request.

## Returns

`Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

A map populated with data from the requested paths. Each path is a key in the map, and the value is the data obtained from the certificate for that path.

## See

[CanisterStatusOptions](../type-aliases/CanisterStatusOptions.md) for detailed options.

## Example

```ts
const status = await canisterStatus({
  paths: ['controllers', 'candid'],
  ...options
});

const controllers = status.get('controllers');
```
