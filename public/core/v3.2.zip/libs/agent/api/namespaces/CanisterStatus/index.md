---
title: Overview
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---


- [CustomPath](classes/CustomPath.md)

## Interfaces

- [~~MetaData~~](interfaces/MetaData.md)

## Type Aliases

- [CanisterStatusOptions](type-aliases/CanisterStatusOptions.md)
- [Path](type-aliases/Path.md)
- [Status](type-aliases/Status.md)
- [StatusMap](type-aliases/StatusMap.md)
- [SubnetStatus](type-aliases/SubnetStatus.md)

## Functions

- [encodePath](functions/encodePath.md)
- [fetchNodeKeys](functions/fetchNodeKeys.md)
- [request](functions/request.md)
