---
title: Overview
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---


- [Predicate](type-aliases/Predicate.md)

## Functions

- [backoff](functions/backoff.md)
- [chain](functions/chain.md)
- [conditionalDelay](functions/conditionalDelay.md)
- [defaultStrategy](functions/defaultStrategy.md)
- [maxAttempts](functions/maxAttempts.md)
- [once](functions/once.md)
- [throttle](functions/throttle.md)
- [timeout](functions/timeout.md)
