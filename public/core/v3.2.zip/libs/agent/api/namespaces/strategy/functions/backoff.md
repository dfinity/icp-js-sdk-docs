---
title: backoff
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **backoff**(`startingThrottleInMsec`, `backoffFactor`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:114](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/strategy.ts#L114)

A strategy that throttle, but using an exponential backoff strategy.


### startingThrottleInMsec

`number`

The throttle in milliseconds to start with.

### backoffFactor

`number`

The factor to multiple the throttle time between every poll. For
  example if using 2, the throttle will double between every run.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
