---
title: defaultStrategy
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **defaultStrategy**(): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:19](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/strategy.ts#L19)

A best practices polling strategy: wait 2 seconds before the first poll, then 1 second
with an exponential backoff factor of 1.2. Timeout after 5 minutes.


[`PollStrategy`](../../../type-aliases/PollStrategy.md)
