---
title: timeout
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **timeout**(`timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:89](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/strategy.ts#L89)

Reject a call after a certain amount of time.


### timeInMsec

`number`

Time in milliseconds before the polling should be rejected.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
