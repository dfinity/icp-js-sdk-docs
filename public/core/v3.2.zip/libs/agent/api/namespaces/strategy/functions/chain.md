---
title: chain
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **chain**(...`strategies`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:131](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/strategy.ts#L131)

Chain multiple polling strategy. This _chains_ the strategies, so if you pass in,
say, two throttling strategy of 1 second, it will result in a throttle of 2 seconds.


### strategies

...[`PollStrategy`](../../../type-aliases/PollStrategy.md)[]

A strategy list to chain.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
