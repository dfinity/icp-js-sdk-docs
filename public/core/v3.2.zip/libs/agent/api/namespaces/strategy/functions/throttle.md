---
title: throttle
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **throttle**(`throttleInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:81](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/strategy.ts#L81)

Throttle polling.


### throttleInMsec

`number`

Amount in millisecond to wait between each polling.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
