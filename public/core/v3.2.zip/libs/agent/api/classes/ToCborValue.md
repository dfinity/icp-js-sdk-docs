---
title: ToCborValue
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/cbor.ts:9](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/cbor.ts#L9)

Used to extend classes that need to provide a custom value for the CBOR encoding process.


### Constructor

> **new ToCborValue**(): `ToCborValue`

#### Returns

`ToCborValue`

## Methods

### toCborValue()

> `abstract` **toCborValue**(): `any`

Defined in: [packages/agent/src/cbor.ts:13](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/cbor.ts#L13)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](../variables/Cbor.md#encode) function.

#### Returns

`any`
