---
title: Observable
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/observable.ts:5](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/observable.ts#L5)


- [`ObservableLog`](ObservableLog.md)

## Type Parameters

### T

`T`

## Constructors

### Constructor

> **new Observable**\<`T`\>(): `Observable`\<`T`\>

Defined in: [packages/agent/src/observable.ts:8](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/observable.ts#L8)

#### Returns

`Observable`\<`T`\>

## Properties

### observers

> **observers**: [`ObserveFunction`](../type-aliases/ObserveFunction.md)\<`T`\>[]

Defined in: [packages/agent/src/observable.ts:6](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/observable.ts#L6)

## Methods

### notify()

> **notify**(`data`, ...`rest`): `void`

Defined in: [packages/agent/src/observable.ts:20](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/observable.ts#L20)

#### Parameters

##### data

`T`

##### rest

...`unknown`[]

#### Returns

`void`

***

### subscribe()

> **subscribe**(`func`): `void`

Defined in: [packages/agent/src/observable.ts:12](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/observable.ts#L12)

#### Parameters

##### func

[`ObserveFunction`](../type-aliases/ObserveFunction.md)\<`T`\>

#### Returns

`void`

***

### unsubscribe()

> **unsubscribe**(`func`): `void`

Defined in: [packages/agent/src/observable.ts:16](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/observable.ts#L16)

#### Parameters

##### func

[`ObserveFunction`](../type-aliases/ObserveFunction.md)\<`T`\>

#### Returns

`void`
