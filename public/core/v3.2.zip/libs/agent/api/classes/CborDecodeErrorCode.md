---
title: CborDecodeErrorCode
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/errors.ts:379](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L379)


- `ErrorCode`

## Constructors

### Constructor

> **new CborDecodeErrorCode**(`error`, `input`): `CborDecodeErrorCode`

Defined in: [packages/agent/src/errors.ts:382](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L382)

#### Parameters

##### error

`unknown`

##### input

`Uint8Array`

#### Returns

`CborDecodeErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### error

> `readonly` **error**: `unknown`

Defined in: [packages/agent/src/errors.ts:383](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L383)

***

### input

> `readonly` **input**: `Uint8Array`

Defined in: [packages/agent/src/errors.ts:384](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L384)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'CborDecodeErrorCode'`

Defined in: [packages/agent/src/errors.ts:380](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L380)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:390](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L390)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
