---
title: NodeType
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/certificate.ts:45](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L45)


### Empty

> **Empty**: `0`

Defined in: [packages/agent/src/certificate.ts:46](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L46)

***

### Fork

> **Fork**: `1`

Defined in: [packages/agent/src/certificate.ts:47](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L47)

***

### Labeled

> **Labeled**: `2`

Defined in: [packages/agent/src/certificate.ts:48](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L48)

***

### Leaf

> **Leaf**: `3`

Defined in: [packages/agent/src/certificate.ts:49](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L49)

***

### Pruned

> **Pruned**: `4`

Defined in: [packages/agent/src/certificate.ts:50](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L50)
