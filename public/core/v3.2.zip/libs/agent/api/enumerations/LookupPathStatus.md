---
title: LookupPathStatus
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/certificate.ts:457](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L457)


### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:459](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L459)

***

### Error

> **Error**: `"Error"`

Defined in: [packages/agent/src/certificate.ts:461](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L461)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:460](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L460)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:458](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L458)
