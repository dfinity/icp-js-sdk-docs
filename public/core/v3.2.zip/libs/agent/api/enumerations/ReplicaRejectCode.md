---
title: ReplicaRejectCode
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/agent/api.ts:11](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L11)

Codes used by the replica for rejecting a message.
See [the interface spec](https://sdk.dfinity.org/docs/interface-spec/#reject-codes).


### CanisterError

> **CanisterError**: `5`

Defined in: [packages/agent/src/agent/api.ts:16](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L16)

***

### CanisterReject

> **CanisterReject**: `4`

Defined in: [packages/agent/src/agent/api.ts:15](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L15)

***

### DestinationInvalid

> **DestinationInvalid**: `3`

Defined in: [packages/agent/src/agent/api.ts:14](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L14)

***

### SysFatal

> **SysFatal**: `1`

Defined in: [packages/agent/src/agent/api.ts:12](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L12)

***

### SysTransient

> **SysTransient**: `2`

Defined in: [packages/agent/src/agent/api.ts:13](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L13)
