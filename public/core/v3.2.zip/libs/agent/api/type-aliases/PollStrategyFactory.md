---
title: PollStrategyFactory
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **PollStrategyFactory** = () => [`PollStrategy`](PollStrategy.md)

Defined in: [packages/agent/src/polling/index.ts:34](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L34)


[`PollStrategy`](PollStrategy.md)
