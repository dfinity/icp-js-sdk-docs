---
title: LookupResult
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **LookupResult** = [`LookupPathResultAbsent`](../interfaces/LookupPathResultAbsent.md) \| [`LookupPathResultUnknown`](../interfaces/LookupPathResultUnknown.md) \| [`LookupPathResultFound`](../interfaces/LookupPathResultFound.md) \| [`LookupPathResultError`](../interfaces/LookupPathResultError.md)

Defined in: [packages/agent/src/certificate.ts:481](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L481)
