---
title: ApiQueryResponse
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **ApiQueryResponse** = [`QueryResponse`](QueryResponse.md) & `object`

Defined in: [packages/agent/src/agent/api.ts:46](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L46)


### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](../interfaces/HttpDetailsResponse.md)

### requestId

> **requestId**: [`RequestId`](RequestId.md)
