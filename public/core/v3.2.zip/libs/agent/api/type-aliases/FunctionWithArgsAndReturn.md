---
title: FunctionWithArgsAndReturn
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **FunctionWithArgsAndReturn**\<`Args`, `Ret`\> = (...`args`) => `Ret`

Defined in: [packages/agent/src/actor.ts:131](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L131)


### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Parameters

### args

...`Args`

## Returns

`Ret`
