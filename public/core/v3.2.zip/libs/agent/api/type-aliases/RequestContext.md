---
title: RequestContext
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **RequestContext** = `object`

Defined in: [packages/agent/src/errors.ts:24](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L24)


### ingressExpiry

> **ingressExpiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/agent/src/errors.ts:28](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L28)

***

### requestId?

> `optional` **requestId**: [`RequestId`](RequestId.md)

Defined in: [packages/agent/src/errors.ts:25](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L25)

***

### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/agent/src/errors.ts:26](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L26)

***

### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/agent/src/errors.ts:27](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/errors.ts#L27)
