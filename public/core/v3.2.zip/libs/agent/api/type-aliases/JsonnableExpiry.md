---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **JsonnableExpiry** = `object`

Defined in: [packages/agent/src/agent/http/transforms.ts:27](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/transforms.ts#L27)


### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/agent/src/agent/http/transforms.ts:28](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/transforms.ts#L28)
