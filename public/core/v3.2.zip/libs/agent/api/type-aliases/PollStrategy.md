---
title: PollStrategy
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

> **PollStrategy** = (`canisterId`, `requestId`, `status`) => `Promise`\<`void`\>

Defined in: [packages/agent/src/polling/index.ts:28](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L28)


### canisterId

[`Principal`](../../principal/classes/Principal.md)

### requestId

[`RequestId`](RequestId.md)

### status

[`RequestStatusResponseStatus`](../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`void`\>
