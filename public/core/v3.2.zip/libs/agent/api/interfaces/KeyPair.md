---
title: KeyPair
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/auth.ts:9](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/auth.ts#L9)

A Key Pair, containing a secret and public key.


### publicKey

> **publicKey**: [`PublicKey`](PublicKey.md)

Defined in: [packages/agent/src/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/auth.ts#L11)

***

### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/agent/src/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/auth.ts#L10)
