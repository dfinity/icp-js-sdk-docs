---
title: HttpDetailsResponse
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/agent/api.ts:39](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L39)


### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/agent/api.ts:43](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L43)

***

### ok

> **ok**: `boolean`

Defined in: [packages/agent/src/agent/api.ts:40](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L40)

***

### status

> **status**: `number`

Defined in: [packages/agent/src/agent/api.ts:41](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L41)

***

### statusText

> **statusText**: `string`

Defined in: [packages/agent/src/agent/api.ts:42](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L42)
