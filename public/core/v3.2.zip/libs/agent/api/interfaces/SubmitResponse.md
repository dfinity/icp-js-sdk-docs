---
title: SubmitResponse
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/agent/api.ts:156](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L156)


### requestDetails?

> `optional` **requestDetails**: [`CallRequest`](CallRequest.md)

Defined in: [packages/agent/src/agent/api.ts:165](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L165)

***

### requestId

> **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/agent/api.ts:157](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L157)

***

### response

> **response**: `object`

Defined in: [packages/agent/src/agent/api.ts:158](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/api.ts#L158)

#### body

> **body**: `null` \| [`v2ResponseBody`](v2ResponseBody.md) \| [`v3ResponseBody`](v3ResponseBody.md)

#### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

#### ok

> **ok**: `boolean`

#### status

> **status**: `number`

#### statusText

> **statusText**: `string`
