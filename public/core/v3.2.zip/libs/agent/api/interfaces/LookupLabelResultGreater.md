---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L532)


### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/agent/src/certificate.ts:533](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L533)
