---
title: CallConfig
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/actor.ts:30](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L30)

Configuration to make calls to the Replica.


- [`ActorConfig`](ActorConfig.md)

## Properties

### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/agent/src/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

***

### canisterId?

> `optional` **canisterId**: `string` \| [`Principal`](../../principal/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:45](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L45)

The canister ID of this Actor.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../principal/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L50)

The effective canister ID. This should almost always be ignored.

***

### nonce?

> `optional` **nonce**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/actor.ts:55](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L55)

The nonce to use for this call. This is used to prevent replay attacks.

***

### pollingOptions?

> `optional` **pollingOptions**: [`PollingOptions`](PollingOptions.md)

Defined in: [packages/agent/src/actor.ts:40](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L40)

Options for controlling polling behavior.
