---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/actor.ts:182](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L182)


### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/agent/src/actor.ts:184](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L184)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/agent/src/actor.ts:183](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L183)
