---
title: ReadStateRequest
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/agent/http/types.ts:96](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L96)


- `Record`\<`string`, `any`\>

## Indexable

\[`key`: `string`\]: `any`

## Properties

### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/agent/src/agent/http/types.ts:99](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L99)

***

### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/agent/src/agent/http/types.ts:98](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L98)

***

### request\_type

> **request\_type**: [`ReadState`](../enumerations/ReadRequestType.md#readstate)

Defined in: [packages/agent/src/agent/http/types.ts:97](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L97)

***

### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../principal/classes/Principal.md)

Defined in: [packages/agent/src/agent/http/types.ts:100](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L100)
