---
title: LookupPathResultFound
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/certificate.ts:472](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L472)


### status

> **status**: [`Found`](../enumerations/LookupPathStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:473](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L473)

***

### value

> **value**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:474](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L474)
