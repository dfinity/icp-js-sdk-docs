---
title: PublicKeyIdentityDescriptor
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/auth.ts:129](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/auth.ts#L129)


### publicKey

> **publicKey**: `string`

Defined in: [packages/agent/src/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/auth.ts#L131)

***

### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/agent/src/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/auth.ts#L130)
