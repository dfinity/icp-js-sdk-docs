---
title: LookupSubtreeResultFound
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/certificate.ts:501](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L501)


### status

> **status**: [`Found`](../enumerations/LookupSubtreeStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:502](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L502)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:503](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/certificate.ts#L503)
