---
title: HttpAgentQueryRequest
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/agent/http/types.ts:33](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L33)


- [`HttpAgentBaseRequest`](HttpAgentBaseRequest.md)

## Properties

### body

> **body**: [`ReadRequest`](../type-aliases/ReadRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:35](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L35)

***

### endpoint

> `readonly` **endpoint**: [`Query`](../enumerations/Endpoint.md#query)

Defined in: [packages/agent/src/agent/http/types.ts:34](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L34)

#### Overrides

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`endpoint`](HttpAgentBaseRequest.md#endpoint)

***

### request

> **request**: `RequestInit`

Defined in: [packages/agent/src/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/agent/http/types.ts#L23)

#### Inherited from

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`request`](HttpAgentBaseRequest.md#request)
