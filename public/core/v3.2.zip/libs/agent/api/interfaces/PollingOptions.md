---
title: PollingOptions
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/polling/index.ts:45](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L45)

Options for controlling polling behavior


### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: [packages/agent/src/polling/index.ts:62](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L62)

Optional replacement function that verifies the BLS signature of a certificate.

***

### preSignReadStateRequest?

> `optional` **preSignReadStateRequest**: `boolean`

Defined in: [packages/agent/src/polling/index.ts:57](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L57)

Whether to reuse the same signed request for polling or create a new unsigned request each time.

#### Default

```ts
false
```

***

### request?

> `optional` **request**: [`ReadStateRequest`](ReadStateRequest.md)

Defined in: [packages/agent/src/polling/index.ts:68](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L68)

The request to use for polling. If not provided, a new request will be created.
This is only used if `preSignReadStateRequest` is set to false.

***

### strategy?

> `optional` **strategy**: [`PollStrategy`](../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/index.ts:51](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/polling/index.ts#L51)

A polling strategy that dictates how much and often we should poll the
read_state endpoint to get the result of an update call.

#### Default

```ts
defaultStrategy()
```
