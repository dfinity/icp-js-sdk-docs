---
title: ActorConfig
editUrl: false
next: true
prev: true
banner:
  content: Still using <code>@dfinity/agent</code>? Migrate to <a
    href="/core/latest/upgrading/v4">@icp-sdk/core</a>!
---

Defined in: [packages/agent/src/actor.ts:61](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L61)

Configuration that can be passed to customize the Actor behaviour.


- [`CallConfig`](CallConfig.md)

## Extended by

- [`AssetManagerConfig`](../../assets/interfaces/AssetManagerConfig.md)

## Properties

### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/agent/src/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

#### Inherited from

[`CallConfig`](CallConfig.md).[`agent`](CallConfig.md#agent)

***

### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: [packages/agent/src/actor.ts:88](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L88)

Polyfill for BLS Certificate verification in case wasm is not supported

***

### canisterId

> **canisterId**: `string` \| [`Principal`](../../principal/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:65](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L65)

The Canister ID of this Actor. This is required for an Actor.

#### Overrides

[`CallConfig`](CallConfig.md).[`canisterId`](CallConfig.md#canisterid)

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../principal/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L50)

The effective canister ID. This should almost always be ignored.

#### Inherited from

[`CallConfig`](CallConfig.md).[`effectiveCanisterId`](CallConfig.md#effectivecanisterid)

***

### nonce?

> `optional` **nonce**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/actor.ts:55](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L55)

The nonce to use for this call. This is used to prevent replay attacks.

#### Inherited from

[`CallConfig`](CallConfig.md).[`nonce`](CallConfig.md#nonce)

***

### pollingOptions?

> `optional` **pollingOptions**: [`PollingOptions`](PollingOptions.md)

Defined in: [packages/agent/src/actor.ts:93](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L93)

Polling options to use when making update calls. This will override the default DEFAULT_POLLING_OPTIONS.

#### Overrides

[`CallConfig`](CallConfig.md).[`pollingOptions`](CallConfig.md#pollingoptions)

## Methods

### callTransform()?

> `optional` **callTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

Defined in: [packages/agent/src/actor.ts:70](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L70)

An override function for update calls' CallConfig. This will be called on every calls.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

***

### queryTransform()?

> `optional` **queryTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

Defined in: [packages/agent/src/actor.ts:79](https://github.com/dfinity/icp-js-core/blob/ccf90d36df3732de763299a42713aec04fbe6869/packages/agent/src/actor.ts#L79)

An override function for query calls' CallConfig. This will be called on every query.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>
