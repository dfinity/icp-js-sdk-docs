---
title: TupleForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:172](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L172)


- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new TupleForm**(`components`, `ui`): `TupleForm`

Defined in: [packages/candid/src/candid-core.ts:173](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L173)

#### Parameters

##### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`TupleForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### components

> **components**: [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

Defined in: [packages/candid/src/candid-core.ts:174](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L174)

***

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/candid/src/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L101)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/candid/src/candid-core.ts:175](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L175)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/candid/src/candid-core.ts:179](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L179)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**(`config`): `undefined` \| `any`[]

Defined in: [packages/candid/src/candid-core.ts:185](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L185)

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`undefined` \| `any`[]

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:114](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L114)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:106](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L106)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
