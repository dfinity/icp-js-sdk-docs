---
title: Unknown
editUrl: false
next: true
prev: true
---

> `const` **Unknown**: [`UnknownClass`](../classes/UnknownClass.md)

Defined in: [packages/candid/src/idl.ts:2290](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L2290)

Client-only type for deserializing unknown data. Not supported by Candid, and its use is discouraged.
