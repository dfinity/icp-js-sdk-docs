---
title: subtype
editUrl: false
next: true
prev: true
---

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/candid/src/idl.ts:2472](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L2472)

Subtyping on Candid types t1 <: t2 (Exported for testing)

## Parameters

### t1

[`Type`](../classes/Type.md)

The potential subtype

### t2

[`Type`](../classes/Type.md)

The potential supertype

## Returns

`boolean`
