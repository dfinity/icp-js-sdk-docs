---
title: RecClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:1588](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1588)

Represents a reference to an IDL type, used for defining recursive data
types.

## Extends

- [`ConstructType`](ConstructType.md)\<`T`\>

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new RecClass**\<`T`\>(): `RecClass`\<`T`\>

#### Returns

`RecClass`\<`T`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`constructor`](ConstructType.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1644](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1644)

##### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`name`](ConstructType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1589](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1589)

##### Returns

`IdlTypeName`

#### Overrides

[`ConstructType`](ConstructType.md).[`typeName`](ConstructType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:1628](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1628)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Overrides

[`ConstructType`](ConstructType.md).[`_buildTypeTableImpl`](ConstructType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1601](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1601)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`ConstructType`](ConstructType.md).[`accept`](ConstructType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`ConstructType`](ConstructType.md).[`buildTypeTable`](ConstructType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L293)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<`T`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`checkType`](ConstructType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:1616](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1616)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Overrides

[`ConstructType`](ConstructType.md).[`covariant`](ConstructType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:1637](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1637)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Overrides

[`ConstructType`](ConstructType.md).[`decodeValue`](ConstructType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:1648](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1648)

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`display`](ConstructType.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:303](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L303)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`encodeType`](ConstructType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:1621](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1621)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`ConstructType`](ConstructType.md).[`encodeValue`](ConstructType.md#encodevalue)

***

### fill()

> **fill**(`t`): `void`

Defined in: [packages/candid/src/idl.ts:1608](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1608)

#### Parameters

##### t

[`ConstructType`](ConstructType.md)\<`T`\>

#### Returns

`void`

***

### getType()

> **getType**(): `undefined` \| [`ConstructType`](ConstructType.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:1612](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1612)

#### Returns

`undefined` \| [`ConstructType`](ConstructType.md)\<`T`\>

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:1655](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1655)

#### Parameters

##### x

`T`

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`valueToString`](ConstructType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is RecClass<any>`

Defined in: [packages/candid/src/idl.ts:1597](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1597)

#### Parameters

##### instance

`any`

#### Returns

`instance is RecClass<any>`
