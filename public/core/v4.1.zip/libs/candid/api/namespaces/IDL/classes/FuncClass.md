---
title: FuncClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:1732](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1732)

Represents an IDL function reference.


Argument types.

## Param

Return types.

## Param

Function annotations.

## Extends

- [`ConstructType`](ConstructType.md)\<\[[`Principal`](../../../../../principal/api/classes/Principal.md), `string`\]\>

## Type Parameters

### Args

`Args` *extends* [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md) = [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md)

### Rets

`Rets` *extends* [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md) = [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md)

## Constructors

### Constructor

> **new FuncClass**\<`Args`, `Rets`\>(`argTypes`, `retTypes`, `annotations`): `FuncClass`\<`Args`, `Rets`\>

Defined in: [packages/candid/src/idl.ts:1751](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1751)

#### Parameters

##### argTypes

`Args`

##### retTypes

`Rets`

##### annotations

`string`[] = `[]`

#### Returns

`FuncClass`\<`Args`, `Rets`\>

#### Overrides

[`ConstructType`](ConstructType.md).[`constructor`](ConstructType.md#constructor)

## Properties

### annotations

> **annotations**: `string`[] = `[]`

Defined in: [packages/candid/src/idl.ts:1754](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1754)

***

### argTypes

> **argTypes**: `Args`

Defined in: [packages/candid/src/idl.ts:1752](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1752)

***

### retTypes

> **retTypes**: `Rets`

Defined in: [packages/candid/src/idl.ts:1753](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1753)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1814](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1814)

##### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`name`](ConstructType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1736](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1736)

##### Returns

`IdlTypeName`

#### Overrides

[`ConstructType`](ConstructType.md).[`typeName`](ConstructType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/candid/src/idl.ts:1778](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1778)

#### Parameters

##### T

`TypeTable`

#### Returns

`void`

#### Overrides

[`ConstructType`](ConstructType.md).[`_buildTypeTableImpl`](ConstructType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1759](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1759)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`ConstructType`](ConstructType.md).[`accept`](ConstructType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`ConstructType`](ConstructType.md).[`buildTypeTable`](ConstructType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<\[[`Principal`](../../../../../principal/api/classes/Principal.md), `string`\]\>

Defined in: [packages/candid/src/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L293)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<\[[`Principal`](../../../../../principal/api/classes/Principal.md), `string`\]\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`checkType`](ConstructType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is [Principal, string]`

Defined in: [packages/candid/src/idl.ts:1762](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1762)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is [Principal, string]`

#### Overrides

[`ConstructType`](ConstructType.md).[`covariant`](ConstructType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): \[[`Principal`](../../../../../principal/api/classes/Principal.md), `string`\]

Defined in: [packages/candid/src/idl.ts:1793](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1793)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

\[[`Principal`](../../../../../principal/api/classes/Principal.md), `string`\]

#### Overrides

[`ConstructType`](ConstructType.md).[`decodeValue`](ConstructType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:1825](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1825)

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`display`](ConstructType.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:303](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L303)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`ConstructType`](ConstructType.md).[`encodeType`](ConstructType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`__namedParameters`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:1768](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1768)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### \_\_namedParameters

\[[`Principal`](../../../../../principal/api/classes/Principal.md), `string`\]

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`ConstructType`](ConstructType.md).[`encodeValue`](ConstructType.md#encodevalue)

***

### valueToString()

> **valueToString**(`__namedParameters`): `string`

Defined in: [packages/candid/src/idl.ts:1821](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1821)

#### Parameters

##### \_\_namedParameters

\[[`Principal`](../../../../../principal/api/classes/Principal.md), `string`\]

#### Returns

`string`

#### Overrides

[`ConstructType`](ConstructType.md).[`valueToString`](ConstructType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FuncClass<GenericIdlFuncArgs, GenericIdlFuncRets>`

Defined in: [packages/candid/src/idl.ts:1740](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1740)

#### Parameters

##### instance

`any`

#### Returns

`instance is FuncClass<GenericIdlFuncArgs, GenericIdlFuncRets>`

***

### argsToString()

> `static` **argsToString**(`types`, `v`): `string`

Defined in: [packages/candid/src/idl.ts:1744](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1744)

#### Parameters

##### types

[`Type`](Type.md)\<`any`\>[]

##### v

`any`[]

#### Returns

`string`
