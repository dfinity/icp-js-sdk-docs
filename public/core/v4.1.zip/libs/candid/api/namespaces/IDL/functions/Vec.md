---
title: Vec
editUrl: false
next: true
prev: true
---

> **Vec**\<`T`\>(`t`): [`VecClass`](../classes/VecClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2325](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L2325)

## Type Parameters

### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`VecClass`](../classes/VecClass.md)\<`T`\>

VecClass from that type
