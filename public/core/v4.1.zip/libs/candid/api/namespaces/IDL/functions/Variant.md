---
title: Variant
editUrl: false
next: true
prev: true
---

> **Variant**(`fields`): [`VariantClass`](../classes/VariantClass.md)

Defined in: [packages/candid/src/idl.ts:2350](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L2350)


### fields

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`VariantClass`](../classes/VariantClass.md)

VariantClass
