---
title: Opt
editUrl: false
next: true
prev: true
---

> **Opt**\<`T`\>(`t`): [`OptClass`](../classes/OptClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2333](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L2333)


### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`OptClass`](../classes/OptClass.md)\<`T`\>

OptClass of Type
