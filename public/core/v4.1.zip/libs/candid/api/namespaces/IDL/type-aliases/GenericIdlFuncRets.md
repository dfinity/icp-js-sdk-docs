---
title: GenericIdlFuncRets
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncRets** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/candid/src/idl.ts:1724](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1724)

The generic type of the return values of an [IDL Function](../functions/Func.md).
