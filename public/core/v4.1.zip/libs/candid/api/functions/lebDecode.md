---
title: lebDecode
editUrl: false
next: true
prev: true
---

> **lebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:74](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/utils/leb128.ts#L74)

Decode a leb encoded buffer into a bigint. The number will always be positive (does not
support signed leb encoding).

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the leb encoded bits.

## Returns

`bigint`
