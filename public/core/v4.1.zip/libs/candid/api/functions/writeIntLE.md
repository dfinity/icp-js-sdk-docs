---
title: writeIntLE
editUrl: false
next: true
prev: true
---

> **writeIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:176](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/utils/leb128.ts#L176)

## Parameters

### value

bigint or number

`number` | `bigint`

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
