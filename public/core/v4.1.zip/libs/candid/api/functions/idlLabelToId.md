---
title: idlLabelToId
editUrl: false
next: true
prev: true
---

> **idlLabelToId**(`label`): `number`

Defined in: [packages/candid/src/utils/hash.ts:23](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/utils/hash.ts#L23)

## Parameters

### label

`string`

string

## Returns

`number`

number representing hashed label
