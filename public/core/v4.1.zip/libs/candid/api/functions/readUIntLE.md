---
title: readUIntLE
editUrl: false
next: true
prev: true
---

> **readUIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:203](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/utils/leb128.ts#L203)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
