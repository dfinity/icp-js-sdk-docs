---
title: concat
editUrl: false
next: true
prev: true
---

> **concat**(...`uint8Arrays`): `Uint8Array`

Defined in: [packages/candid/src/utils/buffer.ts:5](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/buffer.ts#L5)

Concatenate multiple Uint8Arrays.


### uint8Arrays

...`Uint8Array`\<`ArrayBufferLike`\>[]

The Uint8Arrays to concatenate.

## Returns

`Uint8Array`
