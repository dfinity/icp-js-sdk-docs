---
title: recordForm
editUrl: false
next: true
prev: true
---

> **recordForm**(`fields`, `config`): [`RecordForm`](../classes/RecordForm.md)

Defined in: [packages/candid/src/candid-ui.ts:15](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/candid-ui.ts#L15)

## Parameters

### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`RecordForm`](../classes/RecordForm.md)
