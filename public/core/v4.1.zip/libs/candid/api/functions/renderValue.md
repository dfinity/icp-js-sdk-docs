---
title: renderValue
editUrl: false
next: true
prev: true
---

> **renderValue**(`t`, `input`, `value`): `void`

Defined in: [packages/candid/src/candid-ui.ts:224](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/candid-ui.ts#L224)

## Parameters

### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL Type

### input

[`InputBox`](../classes/InputBox.md)

an InputBox

### value

`any`

any

## Returns

`void`

rendering that value to the provided input
