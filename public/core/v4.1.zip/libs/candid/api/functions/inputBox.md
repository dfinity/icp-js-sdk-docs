---
title: inputBox
editUrl: false
next: true
prev: true
---

> **inputBox**(`t`, `config`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:12](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/candid-ui.ts#L12)

## Parameters

### t

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`UIConfig`](../interfaces/UIConfig.md)\>

## Returns

[`InputBox`](../classes/InputBox.md)
