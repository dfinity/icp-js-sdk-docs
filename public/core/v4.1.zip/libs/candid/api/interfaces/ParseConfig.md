---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L6)


### random?

> `optional` **random**: `boolean`

Defined in: [packages/candid/src/candid-core.ts:7](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-core.ts#L7)
