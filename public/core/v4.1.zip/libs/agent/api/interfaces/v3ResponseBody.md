---
title: v3ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:141](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/api.ts#L141)


### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:142](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/api.ts#L142)
