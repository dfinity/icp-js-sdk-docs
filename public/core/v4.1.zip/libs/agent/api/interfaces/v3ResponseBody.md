---
title: v3ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:141](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L141)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:142](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L142)
