---
title: LookupLabelResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:519](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L519)


### status

> **status**: [`Absent`](../enumerations/LookupLabelStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:520](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L520)
