---
title: UnSigned
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L49)

## Type Parameters

### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/agent/src/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L50)
