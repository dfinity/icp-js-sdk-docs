---
title: HttpAgentRequestTransformFn
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

Defined in: [packages/agent/src/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L56)

## Parameters

### args

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

## Returns

`Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

## Properties

### priority?

> `optional` **priority**: `number`

Defined in: [packages/agent/src/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L57)
