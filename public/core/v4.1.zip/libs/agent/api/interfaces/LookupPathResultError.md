---
title: LookupPathResultError
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:477](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L477)

## Properties

### status

> **status**: [`Error`](../enumerations/LookupPathStatus.md#error)

Defined in: [packages/agent/src/certificate.ts:478](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L478)
