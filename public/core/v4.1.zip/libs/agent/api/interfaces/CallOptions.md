---
title: CallOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:102](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L102)

Options when doing a [Agent.call](Agent.md#call) call.

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:111](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L111)

A binary encoded argument. This is already encoded and will be sent as is.

***

### effectiveCanisterId

> **effectiveCanisterId**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/agent/api.ts:117](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L117)

An effective canister ID, used for routing. Usually the canister ID, except for management canister calls.

#### See

https://internetcomputer.org/docs/current/references/ic-interface-spec/#http-effective-canister-id

***

### methodName

> **methodName**: `string`

Defined in: [packages/agent/src/agent/api.ts:106](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L106)

The method name to call.
