---
title: LookupPathResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:464](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L464)

## Properties

### status

> **status**: [`Absent`](../enumerations/LookupPathStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:465](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L465)
