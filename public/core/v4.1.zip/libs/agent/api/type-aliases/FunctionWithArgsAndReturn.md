---
title: FunctionWithArgsAndReturn
editUrl: false
next: true
prev: true
---

> **FunctionWithArgsAndReturn**\<`Args`, `Ret`\> = (...`args`) => `Ret`

Defined in: [packages/agent/src/actor.ts:131](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/actor.ts#L131)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Parameters

### args

...`Args`

## Returns

`Ret`
