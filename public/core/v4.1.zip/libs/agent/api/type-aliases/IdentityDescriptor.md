---
title: IdentityDescriptor
editUrl: false
next: true
prev: true
---

> **IdentityDescriptor** = [`AnonymousIdentityDescriptor`](../interfaces/AnonymousIdentityDescriptor.md) \| [`PublicKeyIdentityDescriptor`](../interfaces/PublicKeyIdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:133](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/auth.ts#L133)
