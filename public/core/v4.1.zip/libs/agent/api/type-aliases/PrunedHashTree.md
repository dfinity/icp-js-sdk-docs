---
title: PrunedHashTree
editUrl: false
next: true
prev: true
---

> **PrunedHashTree** = \[[`Pruned`](../enumerations/NodeType.md#pruned), [`NodeHash`](NodeHash.md)\]

Defined in: [packages/agent/src/certificate.ts:62](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L62)
