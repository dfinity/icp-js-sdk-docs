---
title: Envelope
editUrl: false
next: true
prev: true
---

> **Envelope**\<`T`\> = [`Signed`](../interfaces/Signed.md)\<`T`\> \| [`UnSigned`](../interfaces/UnSigned.md)\<`T`\>

Defined in: [packages/agent/src/agent/http/types.ts:53](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L53)

## Type Parameters

### T

`T`
