---
title: EmptyHashTree
editUrl: false
next: true
prev: true
---

> **EmptyHashTree** = \[[`Empty`](../enumerations/NodeType.md#empty)\]

Defined in: [packages/agent/src/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L58)
