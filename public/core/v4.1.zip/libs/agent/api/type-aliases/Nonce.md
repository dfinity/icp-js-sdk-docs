---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/agent/src/agent/http/types.ts:106](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L106)


### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
