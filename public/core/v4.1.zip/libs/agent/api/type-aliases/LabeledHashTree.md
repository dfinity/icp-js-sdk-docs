---
title: LabeledHashTree
editUrl: false
next: true
prev: true
---

> **LabeledHashTree** = \[[`Labeled`](../enumerations/NodeType.md#labeled), [`NodeLabel`](NodeLabel.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/agent/src/certificate.ts:60](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L60)
