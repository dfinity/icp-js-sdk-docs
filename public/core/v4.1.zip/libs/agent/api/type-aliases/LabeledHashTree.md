---
title: LabeledHashTree
editUrl: false
next: true
prev: true
---

> **LabeledHashTree** = \[[`Labeled`](../enumerations/NodeType.md#labeled), [`NodeLabel`](NodeLabel.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/agent/src/certificate.ts:60](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L60)
