---
title: AgentLog
editUrl: false
next: true
prev: true
---

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](../classes/AgentError.md); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/agent/src/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/observable.ts#L25)
