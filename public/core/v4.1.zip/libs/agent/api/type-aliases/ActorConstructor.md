---
title: ActorConstructor
editUrl: false
next: true
prev: true
---

> **ActorConstructor** = (`config`) => [`ActorSubclass`](ActorSubclass.md)

Defined in: [packages/agent/src/actor.ts:357](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/actor.ts#L357)

## Parameters

### config

[`ActorConfig`](../interfaces/ActorConfig.md)

## Returns

[`ActorSubclass`](ActorSubclass.md)
