---
title: SubtreeLookupResult
editUrl: false
next: true
prev: true
---

> **SubtreeLookupResult** = [`LookupSubtreeResultAbsent`](../interfaces/LookupSubtreeResultAbsent.md) \| [`LookupSubtreeResultUnknown`](../interfaces/LookupSubtreeResultUnknown.md) \| [`LookupSubtreeResultFound`](../interfaces/LookupSubtreeResultFound.md)

Defined in: [packages/agent/src/certificate.ts:506](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L506)
