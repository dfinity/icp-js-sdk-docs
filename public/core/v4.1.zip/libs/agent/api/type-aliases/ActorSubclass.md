---
title: ActorSubclass
editUrl: false
next: true
prev: true
---

> **ActorSubclass**\<`T`\> = [`Actor`](../classes/Actor.md) & `T`

Defined in: [packages/agent/src/actor.ts:100](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/actor.ts#L100)

A subclass of an actor. Actor class itself is meant to be a based class.


### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\>
