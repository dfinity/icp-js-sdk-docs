---
title: ApiQueryResponse
editUrl: false
next: true
prev: true
---

> **ApiQueryResponse** = [`QueryResponse`](QueryResponse.md) & `object`

Defined in: [packages/agent/src/agent/api.ts:46](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L46)

## Type declaration

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](../interfaces/HttpDetailsResponse.md)

### requestId

> **requestId**: [`RequestId`](RequestId.md)
