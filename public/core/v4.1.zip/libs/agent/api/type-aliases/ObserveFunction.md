---
title: ObserveFunction
editUrl: false
next: true
prev: true
---

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/agent/src/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/observable.ts#L3)

## Type Parameters

### T

`T`

## Parameters

### data

`T`

### rest

...`unknown`[]

## Returns

`void`
