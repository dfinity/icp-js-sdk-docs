---
title: ActorMethodMappedExtended
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedExtended**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodExtended<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:143](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/actor.ts#L143)

## Type Parameters

### T

`T`
