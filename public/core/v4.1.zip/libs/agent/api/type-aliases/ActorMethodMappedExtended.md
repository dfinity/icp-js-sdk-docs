---
title: ActorMethodMappedExtended
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedExtended**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodExtended<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:143](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/actor.ts#L143)


### T

`T`
