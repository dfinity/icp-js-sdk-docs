---
title: LookupResult
editUrl: false
next: true
prev: true
---

> **LookupResult** = [`LookupPathResultAbsent`](../interfaces/LookupPathResultAbsent.md) \| [`LookupPathResultUnknown`](../interfaces/LookupPathResultUnknown.md) \| [`LookupPathResultFound`](../interfaces/LookupPathResultFound.md) \| [`LookupPathResultError`](../interfaces/LookupPathResultError.md)

Defined in: [packages/agent/src/certificate.ts:481](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L481)
