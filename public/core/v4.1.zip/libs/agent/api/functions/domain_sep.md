---
title: domain_sep
editUrl: false
next: true
prev: true
---

> **domain\_sep**(`s`): `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:447](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L447)

Creates a domain separator for hashing by encoding the input string
with its length as a prefix.

## Parameters

### s

`string`

The input string to encode.

## Returns

`Uint8Array`

A Uint8Array containing the encoded domain separator.
