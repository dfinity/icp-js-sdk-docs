---
title: makeExpiryTransform
editUrl: false
next: true
prev: true
---

> **makeExpiryTransform**(`delayInMilliseconds`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:136](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/transforms.ts#L136)

Create a transform that adds a delay (by default 5 minutes) to the expiry.

## Parameters

### delayInMilliseconds

`number`

The delay to add to the call time, in milliseconds.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
