---
title: encodeLenBytes
editUrl: false
next: true
prev: true
---

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/agent/src/der.ts:9](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/der.ts#L9)


### len

`number`

## Returns

`number`
