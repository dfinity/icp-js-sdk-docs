---
title: blsVerify
editUrl: false
next: true
prev: true
---

> **blsVerify**(`pk`, `sig`, `msg`): `boolean`

Defined in: [packages/agent/src/utils/bls.ts:13](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/utils/bls.ts#L13)

## Parameters

### pk

`Uint8Array`

primary key: Uint8Array

### sig

`Uint8Array`

signature: Uint8Array

### msg

`Uint8Array`

message: Uint8Array

## Returns

`boolean`

boolean
