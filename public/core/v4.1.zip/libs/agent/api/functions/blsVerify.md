---
title: blsVerify
editUrl: false
next: true
prev: true
---

> **blsVerify**(`pk`, `sig`, `msg`): `boolean`

Defined in: [packages/agent/src/utils/bls.ts:13](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/utils/bls.ts#L13)


### pk

`Uint8Array`

primary key: Uint8Array

### sig

`Uint8Array`

signature: Uint8Array

### msg

`Uint8Array`

message: Uint8Array

## Returns

`boolean`

boolean
