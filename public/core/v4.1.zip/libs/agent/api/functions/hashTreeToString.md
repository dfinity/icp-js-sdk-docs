---
title: hashTreeToString
editUrl: false
next: true
prev: true
---

> **hashTreeToString**(`tree`): `string`

Defined in: [packages/agent/src/certificate.ts:75](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L75)

Make a human readable string out of a hash tree.


### tree

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to convert to a string

## Returns

`string`
