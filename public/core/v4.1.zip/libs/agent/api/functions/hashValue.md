---
title: hashValue
editUrl: false
next: true
prev: true
---

> **hashValue**(`value`): `Uint8Array`

Defined in: [packages/agent/src/request\_id.ts:19](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/request_id.ts#L19)

## Parameters

### value

`unknown`

unknown value

## Returns

`Uint8Array`

Uint8Array
