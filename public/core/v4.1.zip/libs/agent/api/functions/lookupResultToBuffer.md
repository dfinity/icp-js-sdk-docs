---
title: lookupResultToBuffer
editUrl: false
next: true
prev: true
---

> **lookupResultToBuffer**(`result`): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/certificate.ts:403](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L403)

Utility function to constrain the type of a lookup result

## Parameters

### result

[`LookupResult`](../type-aliases/LookupResult.md)

the result of a lookup

## Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

the value if the lookup was found, `undefined` otherwise
