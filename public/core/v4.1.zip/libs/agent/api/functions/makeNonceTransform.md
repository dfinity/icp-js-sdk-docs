---
title: makeNonceTransform
editUrl: false
next: true
prev: true
---

> **makeNonceTransform**(`nonceFn`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:117](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/transforms.ts#L117)

Create a Nonce transform, which takes a function that returns a Buffer, and adds it
as the nonce to every call requests.

## Parameters

### nonceFn

() => [`Nonce`](../type-aliases/Nonce.md)

A function that returns a buffer. By default uses a semi-random method.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
