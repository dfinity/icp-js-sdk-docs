---
title: DerDecodeLengthMismatchErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:337](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L337)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new DerDecodeLengthMismatchErrorCode**(`expectedLength`, `actualLength`): `DerDecodeLengthMismatchErrorCode`

Defined in: [packages/agent/src/errors.ts:340](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L340)

#### Parameters

##### expectedLength

`number`

##### actualLength

`number`

#### Returns

`DerDecodeLengthMismatchErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### actualLength

> `readonly` **actualLength**: `number`

Defined in: [packages/agent/src/errors.ts:342](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L342)

***

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/agent/src/errors.ts:341](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L341)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'DerDecodeLengthMismatchErrorCode'`

Defined in: [packages/agent/src/errors.ts:338](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L338)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:348](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L348)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
