---
title: once
editUrl: false
next: true
prev: true
---

> **once**(): [`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

Defined in: [packages/agent/src/polling/strategy.ts:29](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/polling/strategy.ts#L29)

Predicate that returns true once.

## Returns

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>
