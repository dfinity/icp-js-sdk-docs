---
title: Predicate
editUrl: false
next: true
prev: true
---

> **Predicate**\<`T`\> = (`canisterId`, `requestId`, `status`) => `Promise`\<`T`\>

Defined in: [packages/agent/src/polling/strategy.ts:7](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/polling/strategy.ts#L7)

## Type Parameters

### T

`T`

## Parameters

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](../../../type-aliases/RequestId.md)

### status

[`RequestStatusResponseStatus`](../../../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`T`\>
