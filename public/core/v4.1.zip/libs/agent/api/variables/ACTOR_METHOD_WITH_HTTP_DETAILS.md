---
title: ACTOR_METHOD_WITH_HTTP_DETAILS
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_HTTP\_DETAILS**: `"http-details"` = `'http-details'`

Defined in: [packages/agent/src/actor.ts:359](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/actor.ts#L359)
