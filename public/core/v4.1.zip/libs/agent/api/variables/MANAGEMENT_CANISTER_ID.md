---
title: MANAGEMENT_CANISTER_ID
editUrl: false
next: true
prev: true
---

> `const` **MANAGEMENT\_CANISTER\_ID**: `"aaaaa-aa"` = `'aaaaa-aa'`

Defined in: [packages/agent/src/agent/http/index.ts:97](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/index.ts#L97)
