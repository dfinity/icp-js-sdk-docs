---
title: IC_RESPONSE_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/constants.ts#L12)

The `\x0Bic-response` domain separator used in the signature of IC responses.
