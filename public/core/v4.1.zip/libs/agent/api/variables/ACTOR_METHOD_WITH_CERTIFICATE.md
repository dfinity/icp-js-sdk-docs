---
title: ACTOR_METHOD_WITH_CERTIFICATE
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/agent/src/actor.ts:360](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/actor.ts#L360)
