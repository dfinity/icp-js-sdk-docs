---
title: IC_ROOT_KEY
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_KEY**: `string`

Defined in: [packages/agent/src/agent/http/index.ts:91](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/index.ts#L91)
