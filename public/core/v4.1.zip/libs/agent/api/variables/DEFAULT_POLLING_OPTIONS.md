---
title: DEFAULT_POLLING_OPTIONS
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_POLLING\_OPTIONS**: [`PollingOptions`](../interfaces/PollingOptions.md)

Defined in: [packages/agent/src/polling/index.ts:69](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/polling/index.ts#L69)
