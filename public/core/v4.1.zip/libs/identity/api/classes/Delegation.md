---
title: Delegation
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:42](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L42)

A single delegation object that is signed by a private key. This is constructed by
`DelegationChain.create()`.

DelegationChain


- [`ToCborValue`](../../../agent/api/classes/ToCborValue.md)

## Constructors

### Constructor

> **new Delegation**(`pubkey`, `expiration`, `targets?`): `Delegation`

Defined in: [packages/identity/src/identity/delegation.ts:43](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L43)

#### Parameters

##### pubkey

`Uint8Array`

##### expiration

`bigint`

##### targets?

[`Principal`](../../../principal/api/classes/Principal.md)[]

#### Returns

`Delegation`

## Properties

### expiration

> `readonly` **expiration**: `bigint`

Defined in: [packages/identity/src/identity/delegation.ts:45](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L45)

***

### pubkey

> `readonly` **pubkey**: `Uint8Array`

Defined in: [packages/identity/src/identity/delegation.ts:44](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L44)

***

### targets?

> `readonly` `optional` **targets**: [`Principal`](../../../principal/api/classes/Principal.md)[]

Defined in: [packages/identity/src/identity/delegation.ts:46](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L46)

## Methods

### toCborValue()

> **toCborValue**(): `object`

Defined in: [packages/identity/src/identity/delegation.ts:49](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L49)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](../../../agent/api/variables/Cbor.md#encode) function.

#### Returns

`object`

##### expiration

> **expiration**: `bigint`

##### pubkey

> **pubkey**: `Uint8Array`\<`ArrayBufferLike`\>

##### targets?

> `optional` **targets**: [`Principal`](../../../principal/api/classes/Principal.md)[]

#### Implementation of

[`ToCborValue`](../../../agent/api/classes/ToCborValue.md).[`toCborValue`](../../../agent/api/classes/ToCborValue.md#tocborvalue)

***

### toJSON()

> **toJSON**(): `JsonnableDelegation`

Defined in: [packages/identity/src/identity/delegation.ts:59](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L59)

#### Returns

`JsonnableDelegation`
