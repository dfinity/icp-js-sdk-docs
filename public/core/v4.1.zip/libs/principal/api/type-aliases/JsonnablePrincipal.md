---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

> **JsonnablePrincipal** = `object`

Defined in: [principal.ts:12](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/principal/src/principal.ts#L12)

## Properties

### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [principal.ts:13](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/principal/src/principal.ts#L13)
