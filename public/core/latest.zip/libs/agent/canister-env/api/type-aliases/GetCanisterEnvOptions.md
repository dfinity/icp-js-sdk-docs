---
title: GetCanisterEnvOptions
editUrl: false
next: true
prev: true
---

> **GetCanisterEnvOptions** = `object`

Defined in: [packages/agent/src/canister-env/index.ts:72](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/canister-env/index.ts#L72)

**`Experimental`**

Options for the [getCanisterEnv](../functions/getCanisterEnv.md) function

## Properties

### cookieName?

> `optional` **cookieName**: `string`

Defined in: [packages/agent/src/canister-env/index.ts:77](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/canister-env/index.ts#L77)

The name of the cookie to get the environment variables from.

#### Default

```ts
'ic_env'
```
