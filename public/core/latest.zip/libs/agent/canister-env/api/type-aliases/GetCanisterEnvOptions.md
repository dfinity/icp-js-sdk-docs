---
title: GetCanisterEnvOptions
editUrl: false
next: true
prev: true
---

> **GetCanisterEnvOptions** = `object`

Defined in: [packages/agent/src/canister-env/index.ts:72](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canister-env/index.ts#L72)

**`Experimental`**

Options for the [getCanisterEnv](../functions/getCanisterEnv.md) function

## Properties

### cookieName?

> `optional` **cookieName**: `string`

Defined in: [packages/agent/src/canister-env/index.ts:77](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canister-env/index.ts#L77)

The name of the cookie to get the environment variables from.

#### Default

```ts
'ic_env'
```
