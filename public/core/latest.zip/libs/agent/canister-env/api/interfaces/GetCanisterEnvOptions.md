---
title: GetCanisterEnvOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/canister-env/index.ts:73](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canister-env/index.ts#L73)

**`Experimental`**

Options for the [getCanisterEnv](../functions/getCanisterEnv.md) function

## Properties

### cookieName?

> `optional` **cookieName?**: `string`

Defined in: [packages/core/src/agent/canister-env/index.ts:78](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canister-env/index.ts#L78)

**`Experimental`**

The name of the cookie to get the environment variables from.

#### Default

```ts
'ic_env'
```
