---
title: CallConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:30](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L30)

Configuration to make calls to the Replica.

## Properties

### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/agent/src/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

***

### canisterId?

> `optional` **canisterId**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:45](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L45)

The canister ID of this Actor.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L50)

The effective canister ID.

***

### nonce?

> `optional` **nonce**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/actor.ts:55](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L55)

The nonce to use for this call. This is used to prevent replay attacks.

***

### pollingOptions?

> `optional` **pollingOptions**: [`PollingOptions`](PollingOptions.md)

Defined in: [packages/agent/src/actor.ts:40](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L40)

Options for controlling polling behavior.
