---
title: SubmitResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:162](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L162)

## Properties

### requestDetails?

> `optional` **requestDetails?**: [`CallRequest`](CallRequest.md)

Defined in: [packages/core/src/agent/agent/api.ts:171](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L171)

***

### requestId

> **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/agent/api.ts:163](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L163)

***

### response

> **response**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:164](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L164)

#### body

> **body**: [`v2ResponseBody`](v2ResponseBody.md) \| [`v4ResponseBody`](v4ResponseBody.md) \| `null`

#### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

#### ok

> **ok**: `boolean`

#### status

> **status**: `number`

#### statusText

> **statusText**: `string`
