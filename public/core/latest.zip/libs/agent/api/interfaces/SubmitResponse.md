---
title: SubmitResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:156](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L156)

## Properties

### requestDetails?

> `optional` **requestDetails**: [`CallRequest`](CallRequest.md)

Defined in: [packages/agent/src/agent/api.ts:165](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L165)

***

### requestId

> **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/agent/api.ts:157](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L157)

***

### response

> **response**: `object`

Defined in: [packages/agent/src/agent/api.ts:158](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L158)

#### body

> **body**: `null` \| [`v2ResponseBody`](v2ResponseBody.md) \| [`v3ResponseBody`](v3ResponseBody.md)

#### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

#### ok

> **ok**: `boolean`

#### status

> **status**: `number`

#### statusText

> **statusText**: `string`
