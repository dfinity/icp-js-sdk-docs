---
title: SubmitResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:156](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L156)


### requestDetails?

> `optional` **requestDetails**: [`CallRequest`](CallRequest.md)

Defined in: [packages/agent/src/agent/api.ts:165](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L165)

***

### requestId

> **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/agent/api.ts:157](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L157)

***

### response

> **response**: `object`

Defined in: [packages/agent/src/agent/api.ts:158](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L158)

#### body

> **body**: `null` \| [`v2ResponseBody`](v2ResponseBody.md) \| [`v3ResponseBody`](v3ResponseBody.md)

#### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

#### ok

> **ok**: `boolean`

#### status

> **status**: `number`

#### statusText

> **statusText**: `string`
