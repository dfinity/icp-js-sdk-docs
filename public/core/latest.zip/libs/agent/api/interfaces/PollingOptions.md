---
title: PollingOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/polling/index.ts:39](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/polling/index.ts#L39)

Options for controlling polling behavior

## Properties

### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/polling/index.ts:56](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/polling/index.ts#L56)

Optional replacement function that verifies the BLS signature of a certificate.

***

### preSignReadStateRequest?

> `optional` **preSignReadStateRequest?**: `boolean`

Defined in: [packages/core/src/agent/polling/index.ts:51](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/polling/index.ts#L51)

Whether to reuse the same signed request for polling or create a new unsigned request each time.

#### Default

```ts
false
```

***

### request?

> `optional` **request?**: [`ReadStateRequest`](ReadStateRequest.md)

Defined in: [packages/core/src/agent/polling/index.ts:62](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/polling/index.ts#L62)

The request to use for polling. If not provided, a new request will be created.
This is only used if `preSignReadStateRequest` is set to false.

***

### strategy?

> `optional` **strategy?**: [`PollStrategy`](../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/index.ts:45](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/polling/index.ts#L45)

A polling strategy that dictates how much and often we should poll the
read_state endpoint to get the result of an update call.

#### Default

[defaultStrategy](../namespaces/strategy/functions/defaultStrategy.md)
