---
title: QueryFields
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:82](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L82)

Options when doing a [Agent.query](Agent.md#query) call.

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:91](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L91)

A binary encoded argument. This is already encoded and will be sent as is.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/agent/api.ts:96](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L96)

Overrides canister id for path to fetch. This is used for management canister calls.

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:86](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L86)

The method name to call.
