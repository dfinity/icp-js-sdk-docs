---
title: QueryFields
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:82](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L82)

Options when doing a [Agent.query](Agent.md#query) call.


### arg

> **arg**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:91](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L91)

A binary encoded argument. This is already encoded and will be sent as is.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/agent/api.ts:96](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L96)

Overrides canister id for path to fetch. This is used for management canister calls.

***

### methodName

> **methodName**: `string`

Defined in: [packages/agent/src/agent/api.ts:86](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/api.ts#L86)

The method name to call.
