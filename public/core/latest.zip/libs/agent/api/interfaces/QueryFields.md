---
title: QueryFields
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:83](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L83)

Options when doing a [Agent.query](Agent.md#query) call.

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:92](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L92)

A binary encoded argument. This is already encoded and will be sent as is.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId?**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/agent/api.ts:97](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L97)

Overrides canister id for path to fetch. This is used for management canister calls.

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:87](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L87)

The method name to call.
