---
title: LookupSubtreeResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:501](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L501)


### status

> **status**: [`Found`](../enumerations/LookupSubtreeStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:502](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L502)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:503](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L503)
