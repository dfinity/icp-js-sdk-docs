---
title: LookupSubtreeResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:501](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L501)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupSubtreeStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:502](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L502)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:503](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L503)
