---
title: LookupPathResultError
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L537)

## Properties

### status

> **status**: [`Error`](../enumerations/LookupPathStatus.md#error)

Defined in: [packages/core/src/agent/certificate.ts:538](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L538)
