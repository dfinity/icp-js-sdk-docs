---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:592](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L592)

## Properties

### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/core/src/agent/certificate.ts:593](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L593)
