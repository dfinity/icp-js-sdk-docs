---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L532)

## Properties

### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/agent/src/certificate.ts:533](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L533)
