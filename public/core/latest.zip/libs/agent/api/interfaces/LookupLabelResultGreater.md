---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:592](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L592)

## Properties

### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/core/src/agent/certificate.ts:593](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L593)
