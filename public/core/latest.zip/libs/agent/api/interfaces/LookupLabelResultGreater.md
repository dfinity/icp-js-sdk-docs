---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L532)


### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/agent/src/certificate.ts:533](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L533)
