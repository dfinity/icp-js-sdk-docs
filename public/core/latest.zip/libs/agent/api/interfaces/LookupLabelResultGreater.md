---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L532)

## Properties

### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/agent/src/certificate.ts:533](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L533)
