---
title: ReadStateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:22](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L22)

Options when doing a [Agent.readState](Agent.md#readstate) call.

## Properties

### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/agent/src/agent/api.ts:26](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L26)

A list of paths to read the state of.
