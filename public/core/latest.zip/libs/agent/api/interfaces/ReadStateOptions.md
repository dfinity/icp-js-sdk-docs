---
title: ReadStateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:22](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L22)

Options when doing a [Agent.readState](Agent.md#readstate) call.


### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/agent/src/agent/api.ts:26](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L26)

A list of paths to read the state of.
