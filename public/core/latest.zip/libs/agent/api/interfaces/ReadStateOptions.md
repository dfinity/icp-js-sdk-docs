---
title: ReadStateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:22](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L22)

Options when doing a [Agent.readState](Agent.md#readstate) call.

## Properties

### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/agent/src/agent/api.ts:26](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L26)

A list of paths to read the state of.
