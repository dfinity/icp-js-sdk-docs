---
title: ReadStateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:22](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L22)

Options when doing a [Agent.readState](Agent.md#readstate) call.

## Properties

### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/core/src/agent/agent/api.ts:26](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L26)

A list of paths to read the state of.
