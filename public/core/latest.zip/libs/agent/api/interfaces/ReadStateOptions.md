---
title: ReadStateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:22](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L22)

Options when doing a [Agent.readState](Agent.md#readstate) call.

## Properties

### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/agent/src/agent/api.ts:26](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L26)

A list of paths to read the state of.
