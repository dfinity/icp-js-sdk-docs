---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/expiry.ts:20](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L20)

## Properties

### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:21](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L21)
