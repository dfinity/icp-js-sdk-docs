---
title: RequestContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:21](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L21)

## Properties

### ingressExpiry

> **ingressExpiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/errors.ts:25](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L25)

***

### requestId?

> `optional` **requestId?**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:22](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L22)

***

### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:23](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L23)

***

### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:24](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L24)
