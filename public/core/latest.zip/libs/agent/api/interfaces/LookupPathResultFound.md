---
title: LookupPathResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:534](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L534)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupPathStatus.md#found)

Defined in: [packages/core/src/agent/certificate.ts:535](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L535)

***

### value

> **value**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:536](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L536)
