---
title: LookupPathResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:472](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L472)


### status

> **status**: [`Found`](../enumerations/LookupPathStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:473](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L473)

***

### value

> **value**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:474](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L474)
