---
title: LookupPathResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:472](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L472)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupPathStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:473](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L473)

***

### value

> **value**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:474](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L474)
