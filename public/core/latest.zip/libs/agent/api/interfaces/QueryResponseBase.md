---
title: QueryResponseBase
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:52](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L52)

## Extended by

- [`QueryResponseReplied`](QueryResponseReplied.md)
- [`QueryResponseRejected`](QueryResponseRejected.md)

## Properties

### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](QueryRequest.md)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L54)

***

### status

> **status**: [`QueryResponseStatus`](../enumerations/QueryResponseStatus.md)

Defined in: [packages/core/src/agent/agent/api.ts:53](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L53)
