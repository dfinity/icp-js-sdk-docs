---
title: PublicKeyIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:129](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/auth.ts#L129)

## Properties

### publicKey

> **publicKey**: `string`

Defined in: [packages/agent/src/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/auth.ts#L131)

***

### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/agent/src/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/auth.ts#L130)
