---
title: PublicKeyIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:129](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/auth.ts#L129)


### publicKey

> **publicKey**: `string`

Defined in: [packages/agent/src/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/auth.ts#L131)

***

### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/agent/src/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/auth.ts#L130)
