---
title: PublicKeyIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:129](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L129)

## Properties

### publicKey

> **publicKey**: `string`

Defined in: [packages/agent/src/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L131)

***

### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/agent/src/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L130)
