---
title: Agent
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:188](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L188)

An Agent able to make calls and queries to a Replica.

## Properties

### rootKey

> `readonly` **rootKey**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/core/src/agent/agent/api.ts:189](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L189)

## Methods

### call()

> **call**(`canisterId`, `fields`): `Promise`\<[`SubmitResponse`](SubmitResponse.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:220](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L220)

#### Parameters

##### canisterId

`string` \| [`Principal`](../../../principal/api/classes/Principal.md)

##### fields

[`CallOptions`](CallOptions.md)

#### Returns

`Promise`\<[`SubmitResponse`](SubmitResponse.md)\>

***

### createReadStateRequest()?

> `optional` **createReadStateRequest**(`options`, `identity?`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/agent/api.ts:202](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L202)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

#### Parameters

##### options

[`ReadStateOptions`](ReadStateOptions.md)

##### identity?

[`Identity`](Identity.md)

#### Returns

`Promise`\<`unknown`\>

***

### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/agent/api.ts:273](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L273)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

#### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

***

### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:195](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L195)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

#### Returns

`Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

***

### invalidateIdentity()?

> `optional` **invalidateIdentity**(): `void`

Defined in: [packages/core/src/agent/agent/api.ts:280](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L280)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

#### Returns

`void`

***

### query()

> **query**(`canisterId`, `options`, `identity?`): `Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:255](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L255)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

#### Parameters

##### canisterId

`string` \| [`Principal`](../../../principal/api/classes/Principal.md)

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

##### options

[`QueryFields`](QueryFields.md)

Options to use to create and send the query.

##### identity?

[`Identity`](Identity.md) \| `Promise`\<[`Identity`](Identity.md)\>

Sender principal to use when sending the query.

#### Returns

`Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

***

### readState()

> **readState**(`effectiveCanisterId`, `options`, `identity?`, `request?`): `Promise`\<[`ReadStateResponse`](ReadStateResponse.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:213](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L213)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

#### Parameters

##### effectiveCanisterId

`string` \| [`Principal`](../../../principal/api/classes/Principal.md)

A Canister ID related to this call.

##### options

[`ReadStateOptions`](ReadStateOptions.md)

The options for this call.

##### identity?

[`Identity`](Identity.md)

Identity for the call. If not specified, uses the instance identity.

##### request?

`unknown`

The request to send in case it has already been created.

#### Returns

`Promise`\<[`ReadStateResponse`](ReadStateResponse.md)\>

***

### replaceIdentity()?

> `optional` **replaceIdentity**(`identity`): `void`

Defined in: [packages/core/src/agent/agent/api.ts:291](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L291)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@icp-sdk/auth/client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

#### Parameters

##### identity

[`Identity`](Identity.md)

#### Returns

`void`

***

### status()

> **status**(): `Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:242](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L242)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

#### Returns

`Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.

***

### update()

> **update**(`canisterId`, `fields`, `pollingOptions?`): `Promise`\<[`UpdateResult`](UpdateResult.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:229](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L229)

Executes an update call to a canister and returns the certified result.

#### Parameters

##### canisterId

`string` \| [`Principal`](../../../principal/api/classes/Principal.md)

The canister to call.

##### fields

[`CallOptions`](CallOptions.md)

The call options (method name, arg, effective canister ID, optional nonce).

##### pollingOptions?

[`PollingOptions`](PollingOptions.md)

Optional polling configuration.

#### Returns

`Promise`\<[`UpdateResult`](UpdateResult.md)\>

The certified result including the certificate, reply bytes, and raw certificate bytes.
