---
title: Agent
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:171](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L171)

An Agent able to make calls and queries to a Replica.

## Properties

### rootKey

> `readonly` **rootKey**: `null` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/api.ts:172](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L172)

## Methods

### call()

> **call**(`canisterId`, `fields`): `Promise`\<[`SubmitResponse`](SubmitResponse.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:203](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L203)

#### Parameters

##### canisterId

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### fields

[`CallOptions`](CallOptions.md)

#### Returns

`Promise`\<[`SubmitResponse`](SubmitResponse.md)\>

***

### createReadStateRequest()?

> `optional` **createReadStateRequest**(`options`, `identity?`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/agent/api.ts:185](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L185)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

#### Parameters

##### options

[`ReadStateOptions`](ReadStateOptions.md)

##### identity?

[`Identity`](Identity.md)

#### Returns

`Promise`\<`unknown`\>

***

### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/agent/api.ts:243](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L243)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

#### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

***

### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:178](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L178)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

#### Returns

`Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

***

### invalidateIdentity()?

> `optional` **invalidateIdentity**(): `void`

Defined in: [packages/core/src/agent/agent/api.ts:250](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L250)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

#### Returns

`void`

***

### query()

> **query**(`canisterId`, `options`, `identity?`): `Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:225](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L225)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

#### Parameters

##### canisterId

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### options

[`QueryFields`](QueryFields.md)

Options to use to create and send the query.

##### identity?

Sender principal to use when sending the query.

[`Identity`](Identity.md) | `Promise`\<[`Identity`](Identity.md)\>

#### Returns

`Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

***

### readState()

> **readState**(`effectiveCanisterId`, `options`, `identity?`, `request?`): `Promise`\<[`ReadStateResponse`](ReadStateResponse.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:196](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L196)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

#### Parameters

##### effectiveCanisterId

A Canister ID related to this call.

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### options

[`ReadStateOptions`](ReadStateOptions.md)

The options for this call.

##### identity?

[`Identity`](Identity.md)

Identity for the call. If not specified, uses the instance identity.

##### request?

`unknown`

The request to send in case it has already been created.

#### Returns

`Promise`\<[`ReadStateResponse`](ReadStateResponse.md)\>

***

### replaceIdentity()?

> `optional` **replaceIdentity**(`identity`): `void`

Defined in: [packages/core/src/agent/agent/api.ts:261](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L261)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@icp-sdk/auth/client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

#### Parameters

##### identity

[`Identity`](Identity.md)

#### Returns

`void`

***

### status()

> **status**(): `Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

Defined in: [packages/core/src/agent/agent/api.ts:212](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L212)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

#### Returns

`Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.
