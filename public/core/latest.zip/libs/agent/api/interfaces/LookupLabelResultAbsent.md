---
title: LookupLabelResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:519](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L519)

## Properties

### status

> **status**: [`Absent`](../enumerations/LookupLabelStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:520](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L520)
