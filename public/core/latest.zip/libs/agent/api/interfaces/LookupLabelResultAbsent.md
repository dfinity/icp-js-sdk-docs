---
title: LookupLabelResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:519](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L519)

## Properties

### status

> **status**: [`Absent`](../enumerations/LookupLabelStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:520](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L520)
