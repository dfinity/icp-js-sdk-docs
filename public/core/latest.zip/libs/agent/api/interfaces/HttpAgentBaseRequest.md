---
title: HttpAgentBaseRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:21](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L21)


- [`HttpAgentSubmitRequest`](HttpAgentSubmitRequest.md)
- [`HttpAgentQueryRequest`](HttpAgentQueryRequest.md)
- [`HttpAgentReadStateRequest`](HttpAgentReadStateRequest.md)

## Properties

### endpoint

> `readonly` **endpoint**: [`Endpoint`](../enumerations/Endpoint.md)

Defined in: [packages/agent/src/agent/http/types.ts:22](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L22)

***

### request

> **request**: `RequestInit`

Defined in: [packages/agent/src/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L23)
