---
title: HttpAgentBaseRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:21](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L21)

## Extended by

- [`HttpAgentSubmitRequest`](HttpAgentSubmitRequest.md)
- [`HttpAgentQueryRequest`](HttpAgentQueryRequest.md)
- [`HttpAgentReadStateRequest`](HttpAgentReadStateRequest.md)

## Properties

### endpoint

> `readonly` **endpoint**: [`Endpoint`](../enumerations/Endpoint.md)

Defined in: [packages/agent/src/agent/http/types.ts:22](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L22)

***

### request

> **request**: `RequestInit`

Defined in: [packages/agent/src/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L23)
