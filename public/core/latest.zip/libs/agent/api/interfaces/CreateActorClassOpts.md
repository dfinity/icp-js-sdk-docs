---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:182](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/actor.ts#L182)


### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/agent/src/actor.ts:184](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/actor.ts#L184)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/agent/src/actor.ts:183](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/actor.ts#L183)
