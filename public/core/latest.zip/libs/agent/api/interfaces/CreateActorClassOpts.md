---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:182](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/actor.ts#L182)


### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/agent/src/actor.ts:184](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/actor.ts#L184)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/agent/src/actor.ts:183](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/actor.ts#L183)
