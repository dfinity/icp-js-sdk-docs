---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:162](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L162)

## Properties

### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/agent/src/actor.ts:164](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L164)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/agent/src/actor.ts:163](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L163)
