---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:174](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L174)

## Properties

### certificate?

> `optional` **certificate?**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:176](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L176)

***

### httpDetails?

> `optional` **httpDetails?**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:175](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L175)
