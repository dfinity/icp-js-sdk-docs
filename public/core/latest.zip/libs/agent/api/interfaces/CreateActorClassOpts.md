---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:162](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/actor.ts#L162)

## Properties

### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/agent/src/actor.ts:164](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/actor.ts#L164)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/agent/src/actor.ts:163](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/actor.ts#L163)
