---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:182](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L182)


### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/agent/src/actor.ts:184](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L184)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/agent/src/actor.ts:183](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/actor.ts#L183)
