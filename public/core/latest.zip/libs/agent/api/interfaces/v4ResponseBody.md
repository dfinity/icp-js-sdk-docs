---
title: v4ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:147](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L147)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:148](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L148)
