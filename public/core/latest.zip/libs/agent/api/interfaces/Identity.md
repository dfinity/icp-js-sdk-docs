---
title: Identity
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:39](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L39)

A General Identity object. This does not have to be a private key (for example,
the Anonymous identity), but it must be able to transform request.


### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/auth.ts:44](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L44)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/agent/src/auth.ts:51](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L51)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

#### Returns

`Promise`\<`unknown`\>
