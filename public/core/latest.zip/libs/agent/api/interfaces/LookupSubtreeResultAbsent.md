---
title: LookupSubtreeResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:493](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L493)

## Properties

### status

> **status**: [`Absent`](../enumerations/LookupSubtreeStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:494](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L494)
