---
title: PollingCallContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:31](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L31)

Call context for errors that arise during polling.

## Extended by

- [`CallContext`](CallContext.md)

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/errors.ts:32](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L32)

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:33](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L33)
