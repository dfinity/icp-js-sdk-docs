---
title: v2ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:124](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L124)

## Properties

### error\_code?

> `optional` **error\_code**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:125](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L125)

***

### reject\_code

> **reject\_code**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:126](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L126)

***

### reject\_message

> **reject\_message**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:127](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L127)
