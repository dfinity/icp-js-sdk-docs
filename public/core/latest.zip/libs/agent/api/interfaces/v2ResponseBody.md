---
title: v2ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:124](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L124)

## Properties

### error\_code?

> `optional` **error\_code**: `string`

Defined in: [packages/agent/src/agent/api.ts:125](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L125)

***

### reject\_code

> **reject\_code**: `number`

Defined in: [packages/agent/src/agent/api.ts:126](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L126)

***

### reject\_message

> **reject\_message**: `string`

Defined in: [packages/agent/src/agent/api.ts:127](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L127)
