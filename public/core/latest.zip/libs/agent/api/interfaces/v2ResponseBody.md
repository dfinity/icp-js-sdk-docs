---
title: v2ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:124](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L124)

## Properties

### error\_code?

> `optional` **error\_code**: `string`

Defined in: [packages/agent/src/agent/api.ts:125](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L125)

***

### reject\_code

> **reject\_code**: `number`

Defined in: [packages/agent/src/agent/api.ts:126](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L126)

***

### reject\_message

> **reject\_message**: `string`

Defined in: [packages/agent/src/agent/api.ts:127](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L127)
