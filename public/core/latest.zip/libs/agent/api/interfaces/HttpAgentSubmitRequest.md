---
title: HttpAgentSubmitRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:28](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L28)

## Extends

- [`HttpAgentBaseRequest`](HttpAgentBaseRequest.md)

## Properties

### body

> **body**: [`CallRequest`](CallRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:30](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L30)

***

### endpoint

> `readonly` **endpoint**: [`Call`](../enumerations/Endpoint.md#call)

Defined in: [packages/agent/src/agent/http/types.ts:29](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L29)

#### Overrides

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`endpoint`](HttpAgentBaseRequest.md#endpoint)

***

### request

> **request**: `RequestInit`

Defined in: [packages/agent/src/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L23)

#### Inherited from

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`request`](HttpAgentBaseRequest.md#request)
