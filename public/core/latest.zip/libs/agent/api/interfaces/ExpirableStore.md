---
title: ExpirableStore
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/utils/expirableStore.ts:6](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/utils/expirableStore.ts#L6)

Generic interface for a key-value store with time-based expiration.
Keys are strings, values are of type V.
Implementations must handle expiration internally.

## Type Parameters

### V

`V`

## Properties

### expirationTime

> `readonly` **expirationTime**: `number`

Defined in: [packages/core/src/agent/utils/expirableStore.ts:10](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/utils/expirableStore.ts#L10)

Time in milliseconds after which entries expire.

## Methods

### delete()

> **delete**(`key`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:27](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/utils/expirableStore.ts#L27)

Delete the entry for a key.

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`void`\>

***

### get()

> **get**(`key`): `Promise`\<`V` \| `undefined`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:16](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/utils/expirableStore.ts#L16)

Get the value for a key.
Returns undefined if the key is not present or has expired.

#### Parameters

##### key

`string`

#### Returns

`Promise`\<`V` \| `undefined`\>

***

### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:22](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/utils/expirableStore.ts#L22)

Store a value for a key.
Prunes expired entries before inserting.

#### Parameters

##### key

`string`

##### value

`V`

#### Returns

`Promise`\<`void`\>
