---
title: NodeSignature
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:57](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L57)

## Properties

### identity

> **identity**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:63](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L63)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:61](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L61)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/core/src/agent/agent/api.ts:59](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/api.ts#L59)
