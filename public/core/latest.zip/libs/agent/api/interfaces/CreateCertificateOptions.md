---
title: CreateCertificateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:170](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L170)

## Properties

### agent?

> `optional` **agent?**: [`Agent`](Agent.md)

Defined in: [packages/core/src/agent/certificate.ts:209](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L209)

The agent used to sync time with the IC network, if the certificate fails the freshness check.
If the agent does not implement the [HttpAgent.getTimeDiffMsecs](../classes/HttpAgent.md#gettimediffmsecs), [HttpAgent.hasSyncedTime](../classes/HttpAgent.md#hassyncedtime), [HttpAgent.syncTime](../classes/HttpAgent.md#synctime) and [HttpAgent.syncTimeWithSubnet](../classes/HttpAgent.md#synctimewithsubnet) methods,
time will not be synced in case of a freshness check failure.

#### Default

```ts
undefined
```

***

### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/certificate.ts:187](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L187)

BLS Verification strategy. Default strategy uses bls12_381 from `@noble/curves`

***

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:174](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L174)

The bytes encoding the certificate to be verified

***

### disableTimeVerification?

> `optional` **disableTimeVerification?**: `boolean`

Defined in: [packages/core/src/agent/certificate.ts:201](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L201)

Overrides the maxAgeInMinutes setting and skips comparing the client's time against the certificate. Used for scenarios where the machine's clock is known to be out of sync, or for inspecting expired certificates.

#### Default

```ts
false
```

***

### maxAgeInMinutes?

> `optional` **maxAgeInMinutes?**: `number`

Defined in: [packages/core/src/agent/certificate.ts:195](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L195)

The maximum age of the certificate in minutes. Default is 5 minutes.
This is used to verify the time the certificate was signed, particularly for validating Delegation certificates, which can live for longer than the default window of +/- 5 minutes. If the certificate is
older than the specified age, it will fail verification.

#### Default

```ts
5
```

***

### principal

> **principal**: [`CertificatePrincipal`](../type-aliases/CertificatePrincipal.md)

Defined in: [packages/core/src/agent/certificate.ts:183](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L183)

The principal for which the certificate is being verified.

***

### rootKey

> **rootKey**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:179](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L179)

The root key against which to verify the certificate
(normally, the root key of the IC main network)
