---
title: CreateCertificateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:172](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L172)

## Properties

### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/core/src/agent/certificate.ts:211](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L211)

The agent used to sync time with the IC network, if the certificate fails the freshness check.
If the agent does not implement the [HttpAgent.getTimeDiffMsecs](../classes/HttpAgent.md#gettimediffmsecs), [HttpAgent.hasSyncedTime](../classes/HttpAgent.md#hassyncedtime), [HttpAgent.syncTime](../classes/HttpAgent.md#synctime) and [HttpAgent.syncTimeWithSubnet](../classes/HttpAgent.md#synctimewithsubnet) methods,
time will not be synced in case of a freshness check failure.

#### Default

```ts
undefined
```

***

### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: [packages/core/src/agent/certificate.ts:189](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L189)

BLS Verification strategy. Default strategy uses bls12_381 from @noble/curves

***

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:176](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L176)

The bytes encoding the certificate to be verified

***

### disableTimeVerification?

> `optional` **disableTimeVerification**: `boolean`

Defined in: [packages/core/src/agent/certificate.ts:203](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L203)

Overrides the maxAgeInMinutes setting and skips comparing the client's time against the certificate. Used for scenarios where the machine's clock is known to be out of sync, or for inspecting expired certificates.

#### Default

```ts
false
```

***

### maxAgeInMinutes?

> `optional` **maxAgeInMinutes**: `number`

Defined in: [packages/core/src/agent/certificate.ts:197](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L197)

The maximum age of the certificate in minutes. Default is 5 minutes.
This is used to verify the time the certificate was signed, particularly for validating Delegation certificates, which can live for longer than the default window of +/- 5 minutes. If the certificate is
older than the specified age, it will fail verification.

#### Default

```ts
5
```

***

### principal

> **principal**: [`CertificatePrincipal`](../type-aliases/CertificatePrincipal.md)

Defined in: [packages/core/src/agent/certificate.ts:185](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L185)

The principal for which the certificate is being verified.

***

### rootKey

> **rootKey**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:181](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L181)

The root key against which to verify the certificate
(normally, the root key of the IC main network)
