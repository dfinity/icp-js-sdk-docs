---
title: ActorMethodWithHttpDetails
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:114](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L114)

An actor method type, defined for each methods of the actor service.

## Extends

- [`ActorMethod`](ActorMethod.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L116)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`Args`

### Returns

`Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

## Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:114](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L114)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`unknown`[]

### Returns

`Promise`\<`unknown`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:108](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L108)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

> (...`args`): `Promise`\<`unknown`\>

##### Parameters

###### args

...`unknown`[]

##### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`ActorMethod`](ActorMethod.md).[`withOptions`](ActorMethod.md#withoptions)
