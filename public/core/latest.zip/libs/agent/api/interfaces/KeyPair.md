---
title: KeyPair
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/auth.ts:9](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L9)

A Key Pair, containing a secret and public key.

## Properties

### publicKey

> **publicKey**: [`PublicKey`](PublicKey.md)

Defined in: [packages/core/src/agent/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L11)

***

### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/core/src/agent/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L10)
