---
title: KeyPair
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:9](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L9)

A Key Pair, containing a secret and public key.

## Properties

### publicKey

> **publicKey**: [`PublicKey`](PublicKey.md)

Defined in: [packages/agent/src/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L11)

***

### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/agent/src/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L10)
