---
title: PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:27](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L27)

A Public Key implementation.

## Properties

### derKey?

> `optional` **derKey**: [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/agent/src/auth.ts:32](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L32)

***

### rawKey?

> `optional` **rawKey**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/auth.ts:31](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L31)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/agent/src/auth.ts:28](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L28)

#### Returns

[`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

***

### toRaw()?

> `optional` **toRaw**(): `Uint8Array`

Defined in: [packages/agent/src/auth.ts:30](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L30)

#### Returns

`Uint8Array`
