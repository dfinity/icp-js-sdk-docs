---
title: PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/auth.ts:27](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L27)

A Public Key implementation.

## Properties

### derKey?

> `optional` **derKey**: [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/agent/auth.ts:32](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L32)

***

### rawKey?

> `optional` **rawKey**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/auth.ts:31](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L31)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/agent/auth.ts:28](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L28)

#### Returns

[`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

***

### toRaw()?

> `optional` **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/agent/auth.ts:30](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L30)

#### Returns

`Uint8Array`
