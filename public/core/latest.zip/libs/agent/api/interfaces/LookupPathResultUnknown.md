---
title: LookupPathResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:468](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L468)


### status

> **status**: [`Unknown`](../enumerations/LookupPathStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:469](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L469)
