---
title: LookupPathResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:468](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L468)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupPathStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:469](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L469)
