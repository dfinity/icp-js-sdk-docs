---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:113](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L113)

An actor method type, defined for each methods of the actor service.

## Extended by

- [`ActorMethodWithHttpDetails`](ActorMethodWithHttpDetails.md)
- [`ActorMethodExtended`](ActorMethodExtended.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:114](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L114)

An actor method type, defined for each methods of the actor service.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L116)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

(...`args`) => `Promise`\<`Ret`\>
