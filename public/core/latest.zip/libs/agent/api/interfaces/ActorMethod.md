---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:105](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L105)

An actor method type, defined for each methods of the actor service.

## Extended by

- [`ActorMethodWithHttpDetails`](ActorMethodWithHttpDetails.md)
- [`ActorMethodExtended`](ActorMethodExtended.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:106](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L106)

An actor method type, defined for each methods of the actor service.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:108](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L108)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

> (...`args`): `Promise`\<`Ret`\>

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<`Ret`\>
