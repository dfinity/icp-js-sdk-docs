---
title: LookupLabelResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:523](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L523)


### status

> **status**: [`Unknown`](../enumerations/LookupLabelStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:524](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L524)
