---
title: LookupLabelResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:523](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L523)


### status

> **status**: [`Unknown`](../enumerations/LookupLabelStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:524](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L524)
