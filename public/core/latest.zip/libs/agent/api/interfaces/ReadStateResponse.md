---
title: ReadStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:120](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L120)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:121](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L121)
