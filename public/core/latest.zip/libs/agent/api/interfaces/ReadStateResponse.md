---
title: ReadStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:120](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/api.ts#L120)


### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:121](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/api.ts#L121)
