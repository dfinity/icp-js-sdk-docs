---
title: HttpAgentRequestTransformFn
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

Defined in: [packages/agent/src/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L56)

## Parameters

### args

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

## Returns

`Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

## Properties

### priority?

> `optional` **priority**: `number`

Defined in: [packages/agent/src/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L57)
