---
title: HttpAgentRequestTransformFn
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md) \| `undefined`\>

Defined in: [packages/core/src/agent/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/http/types.ts#L56)

## Parameters

### args

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

## Returns

`Promise`\<`void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md) \| `undefined`\>

## Properties

### priority?

> `optional` **priority?**: `number`

Defined in: [packages/core/src/agent/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/http/types.ts#L57)
