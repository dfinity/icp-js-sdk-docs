---
title: HttpAgentRequestTransformFn
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

Defined in: [packages/agent/src/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L56)


### args

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

## Returns

`Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

## Properties

### priority?

> `optional` **priority**: `number`

Defined in: [packages/agent/src/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/agent/http/types.ts#L57)
