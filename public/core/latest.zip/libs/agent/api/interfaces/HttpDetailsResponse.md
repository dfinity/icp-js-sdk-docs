---
title: HttpDetailsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:39](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L39)

## Properties

### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/core/src/agent/agent/api.ts:43](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L43)

***

### ok

> **ok**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L40)

***

### status

> **status**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:41](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L41)

***

### statusText

> **statusText**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L42)
