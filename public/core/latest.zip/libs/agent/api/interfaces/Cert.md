---
title: Cert
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:39](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L39)


### delegation?

> `optional` **delegation**: `Delegation`

Defined in: [packages/agent/src/certificate.ts:42](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L42)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:41](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L41)

***

### tree

> **tree**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:40](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L40)
