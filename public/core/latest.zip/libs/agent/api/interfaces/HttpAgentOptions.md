---
title: HttpAgentOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/index.ts:114](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L114)


### backoffStrategy?

> `optional` **backoffStrategy**: `BackoffStrategyFactory`

Defined in: [packages/agent/src/agent/http/index.ts:161](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L161)

The strategy to use for backoff when retrying requests

***

### callOptions?

> `optional` **callOptions**: `Record`\<`string`, `unknown`\>

Defined in: [packages/agent/src/agent/http/index.ts:124](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L124)

***

### credentials?

> `optional` **credentials**: `object`

Defined in: [packages/agent/src/agent/http/index.ts:140](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L140)

#### name

> **name**: `string`

#### password?

> `optional` **password**: `string`

***

### fetch()?

> `optional` **fetch**: \{(`input`, `init?`): `Promise`\<`Response`\>; (`input`, `init?`): `Promise`\<`Response`\>; \}

Defined in: [packages/agent/src/agent/http/index.ts:116](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L116)

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`RequestInfo` | `URL`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`string` | `Request` | `URL`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

***

### fetchOptions?

> `optional` **fetchOptions**: `Record`\<`string`, `unknown`\>

Defined in: [packages/agent/src/agent/http/index.ts:121](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L121)

***

### host?

> `optional` **host**: `string`

Defined in: [packages/agent/src/agent/http/index.ts:128](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L128)

***

### identity?

> `optional` **identity**: [`Identity`](Identity.md) \| `Promise`\<[`Identity`](Identity.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:132](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L132)

***

### ingressExpiryInMinutes?

> `optional` **ingressExpiryInMinutes**: `number`

Defined in: [packages/agent/src/agent/http/index.ts:138](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L138)

The maximum time a request can be delayed before being rejected.

#### Default

```ts
5 minutes
```

***

### logToConsole?

> `optional` **logToConsole**: `boolean`

Defined in: [packages/agent/src/agent/http/index.ts:170](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L170)

Whether to log to the console. Defaults to false.

***

### retryTimes?

> `optional` **retryTimes**: `number`

Defined in: [packages/agent/src/agent/http/index.ts:157](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L157)

Number of times to retry requests before throwing an error

#### Default

```ts
3
```

***

### rootKey?

> `optional` **rootKey**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/agent/http/index.ts:175](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L175)

Alternate root key to use for verifying certificates. If not provided, the default IC root key will be used.

***

### shouldFetchRootKey?

> `optional` **shouldFetchRootKey**: `boolean`

Defined in: [packages/agent/src/agent/http/index.ts:180](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L180)

Whether or not the root key should be automatically fetched during construction. Defaults to false.

***

### shouldSyncTime?

> `optional` **shouldSyncTime**: `boolean`

Defined in: [packages/agent/src/agent/http/index.ts:185](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L185)

Whether or not to sync the time with the network during construction. Defaults to false.

***

### useQueryNonces?

> `optional` **useQueryNonces**: `boolean`

Defined in: [packages/agent/src/agent/http/index.ts:152](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L152)

Adds a unique [Nonce](../type-aliases/Nonce.md) with each query.
Enabling will prevent queries from being answered with a cached response.

#### Example

```ts
const agent = new HttpAgent({ useQueryNonces: true });
agent.addTransform(makeNonceTransform(makeNonce);
```

#### Default

```ts
false
```

***

### verifyQuerySignatures?

> `optional` **verifyQuerySignatures**: `boolean`

Defined in: [packages/agent/src/agent/http/index.ts:166](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/http/index.ts#L166)

Whether the agent should verify signatures signed by node keys on query responses. Increases security, but adds overhead and must make a separate request to cache the node keys for the canister's subnet.

#### Default

```ts
true
```
