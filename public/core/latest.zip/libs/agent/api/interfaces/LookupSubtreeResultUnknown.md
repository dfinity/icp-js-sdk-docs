---
title: LookupSubtreeResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:557](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L557)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupSubtreeStatus.md#unknown)

Defined in: [packages/core/src/agent/certificate.ts:558](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L558)
