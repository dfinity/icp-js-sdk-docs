---
title: LookupSubtreeResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:557](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L557)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupSubtreeStatus.md#unknown)

Defined in: [packages/core/src/agent/certificate.ts:558](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L558)
