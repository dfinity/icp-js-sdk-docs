---
title: LookupSubtreeResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:559](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L559)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupSubtreeStatus.md#unknown)

Defined in: [packages/core/src/agent/certificate.ts:560](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L560)
