---
title: LookupLabelResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:527](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L527)


### status

> **status**: [`Found`](../enumerations/LookupLabelStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:528](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L528)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:529](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L529)
