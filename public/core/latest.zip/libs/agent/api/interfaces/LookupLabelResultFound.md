---
title: LookupLabelResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:587](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L587)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupLabelStatus.md#found)

Defined in: [packages/core/src/agent/certificate.ts:588](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L588)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/core/src/agent/certificate.ts:589](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L589)
