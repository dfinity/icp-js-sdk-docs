---
title: UnSigned
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/http/types.ts#L49)

## Type Parameters

### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/http/types.ts#L50)
