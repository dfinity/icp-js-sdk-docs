---
title: UnSigned
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L49)

## Type Parameters

### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/agent/src/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L50)
