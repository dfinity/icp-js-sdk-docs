---
title: LookupPathResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:464](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L464)


### status

> **status**: [`Absent`](../enumerations/LookupPathStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:465](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L465)
