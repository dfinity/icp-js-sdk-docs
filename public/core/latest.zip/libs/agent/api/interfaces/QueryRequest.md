---
title: QueryRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:85](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L85)


- `Record`\<`string`, `any`\>

## Indexable

\[`key`: `string`\]: `any`

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/agent/src/agent/http/types.ts:89](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L89)

***

### canister\_id

> **canister\_id**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/agent/http/types.ts:87](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L87)

***

### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/agent/src/agent/http/types.ts:91](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L91)

***

### method\_name

> **method\_name**: `string`

Defined in: [packages/agent/src/agent/http/types.ts:88](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L88)

***

### nonce?

> `optional` **nonce**: [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/agent/src/agent/http/types.ts:92](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L92)

***

### request\_type

> **request\_type**: [`Query`](../enumerations/ReadRequestType.md#query)

Defined in: [packages/agent/src/agent/http/types.ts:86](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L86)

***

### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/agent/http/types.ts:90](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/types.ts#L90)
