---
title: AnonymousIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/auth.ts#L126)

## Properties

### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/agent/src/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/auth.ts#L127)
