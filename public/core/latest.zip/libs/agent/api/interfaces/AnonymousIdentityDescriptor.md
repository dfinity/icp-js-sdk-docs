---
title: AnonymousIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/auth.ts#L126)

## Properties

### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/core/src/agent/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/auth.ts#L127)
