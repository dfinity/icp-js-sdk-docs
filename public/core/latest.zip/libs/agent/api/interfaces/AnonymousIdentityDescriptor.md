---
title: AnonymousIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L126)

## Properties

### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/agent/src/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L127)
