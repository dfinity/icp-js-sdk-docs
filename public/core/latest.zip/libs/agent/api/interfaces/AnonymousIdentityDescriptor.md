---
title: AnonymousIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/auth.ts#L126)


### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/agent/src/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/auth.ts#L127)
