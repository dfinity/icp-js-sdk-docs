---
title: LookupLabelResultLess
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:536](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L536)

## Properties

### status

> **status**: [`Less`](../enumerations/LookupLabelStatus.md#less)

Defined in: [packages/agent/src/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L537)
