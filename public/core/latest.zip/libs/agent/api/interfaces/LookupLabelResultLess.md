---
title: LookupLabelResultLess
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:536](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L536)


### status

> **status**: [`Less`](../enumerations/LookupLabelStatus.md#less)

Defined in: [packages/agent/src/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L537)
