---
title: LookupLabelResultLess
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:536](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L536)

## Properties

### status

> **status**: [`Less`](../enumerations/LookupLabelStatus.md#less)

Defined in: [packages/agent/src/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L537)
