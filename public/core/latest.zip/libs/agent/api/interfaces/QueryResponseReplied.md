---
title: QueryResponseReplied
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:65](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L65)


- [`QueryResponseBase`](QueryResponseBase.md)

## Properties

### reply

> **reply**: `object`

Defined in: [packages/agent/src/agent/api.ts:67](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L67)

#### arg

> **arg**: `Uint8Array`

***

### requestDetails?

> `optional` **requestDetails**: [`QueryRequest`](QueryRequest.md)

Defined in: [packages/agent/src/agent/api.ts:53](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L53)

#### Inherited from

[`QueryResponseBase`](QueryResponseBase.md).[`requestDetails`](QueryResponseBase.md#requestdetails)

***

### signatures?

> `optional` **signatures**: [`NodeSignature`](../type-aliases/NodeSignature.md)[]

Defined in: [packages/agent/src/agent/api.ts:68](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L68)

***

### status

> **status**: [`Replied`](../enumerations/QueryResponseStatus.md#replied)

Defined in: [packages/agent/src/agent/api.ts:66](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/agent/api.ts#L66)

#### Overrides

[`QueryResponseBase`](QueryResponseBase.md).[`status`](QueryResponseBase.md#status)
