---
title: IC_STATE_ROOT_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/constants.ts#L7)

The `\x0Dic-state-root` domain separator used in the root hash of IC certificates.
