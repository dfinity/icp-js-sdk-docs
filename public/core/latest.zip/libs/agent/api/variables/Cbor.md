---
title: Cbor
editUrl: false
next: true
prev: true
---

> `const` **Cbor**: `object`

Defined in: [packages/agent/src/cbor.ts:60](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/cbor.ts#L60)

The CanisterStatus utility is used to request structured data directly from the IC public API. This data can be accessed using agent.readState, but CanisterStatus provides a helpful abstraction with some known paths.

You can request a canisters Controllers, ModuleHash, Candid interface, Subnet, or Time, or provide a custom path [CanisterStatus.CustomPath](../namespaces/CanisterStatus/classes/CustomPath.md) and pass arbitrary buffers for valid paths identified in https://internetcomputer.org/docs/current/references/ic-interface-spec.

The primary method for this namespace is [CanisterStatus.request](../namespaces/CanisterStatus/functions/request.md)

## Type declaration

### decode()

> **decode**: \<`T`\>(`input`) => `T`

Decode a CBOR encoded value into a JavaScript value.

#### Type Parameters

##### T

`T`

#### Parameters

##### input

`Uint8Array`

The CBOR encoded value

#### Returns

`T`

### encode()

> **encode**: (`value`) => `Uint8Array`

Encode a JavaScript value into CBOR. If the value is an instance of [ToCborValue](../classes/ToCborValue.md),
the [ToCborValue.toCborValue](../classes/ToCborValue.md#tocborvalue) method will be called to get the value to encode.

#### Parameters

##### value

`unknown`

The value to encode

#### Returns

`Uint8Array`
