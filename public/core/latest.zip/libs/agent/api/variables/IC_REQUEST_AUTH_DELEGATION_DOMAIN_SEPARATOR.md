---
title: IC_REQUEST_AUTH_DELEGATION_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_AUTH\_DELEGATION\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:17](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/constants.ts#L17)

The `\x1Aic-request-auth-delegation` domain separator used in the signature of delegations.
