---
title: IC_REQUEST_AUTH_DELEGATION_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_AUTH\_DELEGATION\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:22](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/constants.ts#L22)

The `\x1Aic-request-auth-delegation` domain separator used in the signature of delegations.
