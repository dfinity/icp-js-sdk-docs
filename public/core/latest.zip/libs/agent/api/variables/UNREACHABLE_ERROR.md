---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/core/src/agent/errors.ts:933](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L933)

Special error used to indicate that a code path is unreachable.

For internal use only.
