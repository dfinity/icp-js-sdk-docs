---
title: SECP256K1_OID
editUrl: false
next: true
prev: true
---

> `const` **SECP256K1\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:87](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/der.ts#L87)

A DER encoded `SEQUENCE(OID)` for secp256k1 with the ECDSA algorithm
