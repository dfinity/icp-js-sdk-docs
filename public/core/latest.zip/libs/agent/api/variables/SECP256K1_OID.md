---
title: SECP256K1_OID
editUrl: false
next: true
prev: true
---

> `const` **SECP256K1\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:108](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/der.ts#L108)

A DER encoded `SEQUENCE(OID)` for secp256k1 with the ECDSA algorithm
