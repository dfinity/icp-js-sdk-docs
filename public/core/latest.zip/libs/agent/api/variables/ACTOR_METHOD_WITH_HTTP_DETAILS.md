---
title: ACTOR_METHOD_WITH_HTTP_DETAILS
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_HTTP\_DETAILS**: `"http-details"` = `'http-details'`

Defined in: [packages/agent/src/actor.ts:364](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/actor.ts#L364)
