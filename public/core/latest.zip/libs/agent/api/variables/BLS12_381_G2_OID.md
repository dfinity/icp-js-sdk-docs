---
title: BLS12_381_G2_OID
editUrl: false
next: true
prev: true
---

> `const` **BLS12\_381\_G2\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:95](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/der.ts#L95)
