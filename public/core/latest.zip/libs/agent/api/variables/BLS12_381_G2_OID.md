---
title: BLS12_381_G2_OID
editUrl: false
next: true
prev: true
---

> `const` **BLS12\_381\_G2\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:116](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/der.ts#L116)
