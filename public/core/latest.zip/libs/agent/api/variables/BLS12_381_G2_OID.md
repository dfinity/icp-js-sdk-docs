---
title: BLS12_381_G2_OID
editUrl: false
next: true
prev: true
---

> `const` **BLS12\_381\_G2\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:95](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/der.ts#L95)
