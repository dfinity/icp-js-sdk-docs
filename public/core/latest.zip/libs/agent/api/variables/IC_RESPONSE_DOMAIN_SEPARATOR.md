---
title: IC_RESPONSE_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/constants.ts#L12)

The `\x0Bic-response` domain separator used in the signature of IC responses.
