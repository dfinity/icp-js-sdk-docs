---
title: IC_RESPONSE_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/constants.ts#L12)

The `\x0Bic-response` domain separator used in the signature of IC responses.
