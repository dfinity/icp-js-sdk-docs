---
title: IC_REQUEST_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/constants.ts#L12)

The `\x0Aic-request` domain separator used in the signature of IC requests.
