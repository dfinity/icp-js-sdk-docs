---
title: IC_REQUEST_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/constants.ts#L7)

The `\x0Aic-request` domain separator used in the signature of IC requests.
