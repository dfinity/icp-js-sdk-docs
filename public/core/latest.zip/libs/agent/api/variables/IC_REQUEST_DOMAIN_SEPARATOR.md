---
title: IC_REQUEST_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/constants.ts#L7)

The `\x0Aic-request` domain separator used in the signature of IC requests.
