---
title: verify
editUrl: false
next: true
prev: true
---

> **verify**: (`pk`, `sig`, `msg`) => `boolean`

Defined in: [packages/agent/src/utils/bls.ts:4](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/utils/bls.ts#L4)


### pk

`Uint8Array`

### sig

`Uint8Array`

### msg

`Uint8Array`

## Returns

`boolean`
