---
title: DEFAULT_POLLING_OPTIONS
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_POLLING\_OPTIONS**: [`PollingOptions`](../interfaces/PollingOptions.md)

Defined in: [packages/agent/src/polling/index.ts:71](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/polling/index.ts#L71)
