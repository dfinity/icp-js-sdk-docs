---
title: DEFAULT_POLLING_OPTIONS
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_POLLING\_OPTIONS**: [`PollingOptions`](../interfaces/PollingOptions.md)

Defined in: [packages/agent/src/polling/index.ts:69](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/polling/index.ts#L69)
