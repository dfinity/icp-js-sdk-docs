---
title: ACTOR_METHOD_WITH_CERTIFICATE
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/agent/src/actor.ts:365](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L365)
