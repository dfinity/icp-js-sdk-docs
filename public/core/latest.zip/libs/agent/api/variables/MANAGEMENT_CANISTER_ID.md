---
title: MANAGEMENT_CANISTER_ID
editUrl: false
next: true
prev: true
---

> `const` **MANAGEMENT\_CANISTER\_ID**: `"aaaaa-aa"` = `'aaaaa-aa'`

Defined in: [packages/agent/src/agent/http/index.ts:97](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/index.ts#L97)
