---
title: JSON_KEY_EXPIRY
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:4](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/http/expiry.ts#L4)
