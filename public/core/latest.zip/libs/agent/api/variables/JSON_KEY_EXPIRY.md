---
title: JSON_KEY_EXPIRY
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/agent/src/agent/http/transforms.ts:12](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/transforms.ts#L12)
