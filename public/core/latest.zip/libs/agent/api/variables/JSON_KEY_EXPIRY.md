---
title: JSON_KEY_EXPIRY
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/agent/src/agent/http/transforms.ts:12](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/transforms.ts#L12)
