---
title: IC_ROOT_KEY
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_KEY**: `string`

Defined in: [packages/agent/src/agent/http/index.ts:91](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/index.ts#L91)
