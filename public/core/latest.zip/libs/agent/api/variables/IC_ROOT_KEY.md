---
title: IC_ROOT_KEY
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_KEY**: `string`

Defined in: [packages/agent/src/agent/http/index.ts:91](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/index.ts#L91)
