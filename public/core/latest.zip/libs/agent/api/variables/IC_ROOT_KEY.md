---
title: IC_ROOT_KEY
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_KEY**: `string`

Defined in: [packages/agent/src/agent/http/index.ts:91](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/index.ts#L91)
