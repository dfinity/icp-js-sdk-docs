---
title: lookup_path
editUrl: false
next: true
prev: true
---

> **lookup\_path**(`path`, `tree`): [`LookupResult`](../type-aliases/LookupResult.md)

Defined in: [packages/agent/src/certificate.ts:553](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L553)

Lookup a path in a tree. If the path is a subtree, use [lookup\_subtree](lookup_subtree.md) instead.

## Parameters

### path

[`NodePath`](../type-aliases/NodePath.md)

the path to look up

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LookupResult`](../type-aliases/LookupResult.md)

the result of the lookup
