---
title: lookup_path
editUrl: false
next: true
prev: true
---

> **lookup\_path**(`path`, `tree`): [`LookupResult`](../type-aliases/LookupResult.md)

Defined in: [packages/agent/src/certificate.ts:553](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L553)

Lookup a path in a tree. If the path is a subtree, use [lookup\_subtree](lookup_subtree.md) instead.


### path

[`NodePath`](../type-aliases/NodePath.md)

the path to look up

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LookupResult`](../type-aliases/LookupResult.md)

the result of the lookup
