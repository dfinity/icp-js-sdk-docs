---
title: isV3ResponseBody
editUrl: false
next: true
prev: true
---

> **isV3ResponseBody**(`body`): `body is v3ResponseBody`

Defined in: [packages/agent/src/agent/api.ts:150](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L150)

Utility function to check if a body is a v3ResponseBody for type safety.

## Parameters

### body

The body to check

`null` | [`v2ResponseBody`](../interfaces/v2ResponseBody.md) | [`v3ResponseBody`](../interfaces/v3ResponseBody.md)

## Returns

`body is v3ResponseBody`

boolean indicating if the body is a v3ResponseBody
