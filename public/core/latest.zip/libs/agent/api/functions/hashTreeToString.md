---
title: hashTreeToString
editUrl: false
next: true
prev: true
---

> **hashTreeToString**(`tree`): `string`

Defined in: [packages/core/src/agent/certificate.ts:77](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L77)

Make a human readable string out of a hash tree.

## Parameters

### tree

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to convert to a string

## Returns

`string`
