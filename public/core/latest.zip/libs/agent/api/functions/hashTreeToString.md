---
title: hashTreeToString
editUrl: false
next: true
prev: true
---

> **hashTreeToString**(`tree`): `string`

Defined in: [packages/agent/src/certificate.ts:75](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L75)

Make a human readable string out of a hash tree.


### tree

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to convert to a string

## Returns

`string`
