---
title: getSubnetIdFromCertificate
editUrl: false
next: true
prev: true
---

> **getSubnetIdFromCertificate**(`certificate`, `rootKey`): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/certificate.ts:1054](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L1054)

Get the subnet ID from a certificate
If the certificate has a delegation, it returns the subnet ID from the delegation.
If the certificate has no delegation, it returns the root subnet ID.

## Parameters

### certificate

[`Cert`](../interfaces/Cert.md)

the certificate to get the subnet ID from

### rootKey

`Uint8Array`

the root key to use to get the subnet ID

## Returns

[`Principal`](../../../principal/api/classes/Principal.md)

the subnet ID
