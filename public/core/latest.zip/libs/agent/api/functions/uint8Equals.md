---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`a`, `b`): `boolean`

Defined in: [packages/core/src/agent/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/utils/buffer.ts#L54)

Compares two Uint8Arrays for equality.

## Parameters

### a

`Uint8Array`

The first Uint8Array.

### b

`Uint8Array`

The second Uint8Array.

## Returns

`boolean`

True if the Uint8Arrays are equal, false otherwise.
