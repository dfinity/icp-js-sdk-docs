---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`a`, `b`): `boolean`

Defined in: [packages/agent/src/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/utils/buffer.ts#L54)

Compares two Uint8Arrays for equality.


### a

`Uint8Array`

The first Uint8Array.

### b

`Uint8Array`

The second Uint8Array.

## Returns

`boolean`

True if the Uint8Arrays are equal, false otherwise.
