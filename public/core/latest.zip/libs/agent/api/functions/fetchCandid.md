---
title: fetchCandid
editUrl: false
next: true
prev: true
---

> **fetchCandid**(`canisterId`, `agent?`): `Promise`\<`string`\>

Defined in: [packages/core/src/agent/fetch\_candid.ts:13](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/fetch_candid.ts#L13)

Retrieves the Candid interface for the specified canister.

## Parameters

### canisterId

`string`

A string corresponding to the canister ID

### agent?

[`HttpAgent`](../classes/HttpAgent.md)

The agent to use for the request (usually an `HttpAgent`)

## Returns

`Promise`\<`string`\>

Candid source code
