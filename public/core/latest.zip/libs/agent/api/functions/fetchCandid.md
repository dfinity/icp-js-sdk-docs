---
title: fetchCandid
editUrl: false
next: true
prev: true
---

> **fetchCandid**(`canisterId`, `agent?`): `Promise`\<`string`\>

Defined in: [packages/core/src/agent/fetch\_candid.ts:13](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/fetch_candid.ts#L13)

Retrieves the Candid interface for the specified canister.

## Parameters

### canisterId

`string`

A string corresponding to the canister ID

### agent?

[`HttpAgent`](../classes/HttpAgent.md)

The agent to use for the request (usually an `HttpAgent`)

## Returns

`Promise`\<`string`\>

Candid source code
