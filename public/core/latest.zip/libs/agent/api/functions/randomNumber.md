---
title: randomNumber
editUrl: false
next: true
prev: true
---

> **randomNumber**(): `number`

Defined in: [packages/agent/src/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff

## Returns

`number`

a random number
