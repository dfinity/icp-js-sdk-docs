---
title: randomNumber
editUrl: false
next: true
prev: true
---

> **randomNumber**(): `number`

Defined in: [packages/agent/src/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff

## Returns

`number`

a random number
