---
title: reconstruct
editUrl: false
next: true
prev: true
---

> **reconstruct**(`t`): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/agent/src/certificate.ts:418](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L418)

## Parameters

### t

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to reconstruct

## Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>
