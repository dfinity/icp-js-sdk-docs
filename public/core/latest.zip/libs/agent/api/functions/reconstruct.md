---
title: reconstruct
editUrl: false
next: true
prev: true
---

> **reconstruct**(`t`): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/agent/src/certificate.ts:418](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L418)


### t

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to reconstruct

## Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>
