---
title: reconstruct
editUrl: false
next: true
prev: true
---

> **reconstruct**(`t`): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/agent/src/certificate.ts:418](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L418)


### t

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to reconstruct

## Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>
