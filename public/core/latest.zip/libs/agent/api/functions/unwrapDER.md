---
title: unwrapDER
editUrl: false
next: true
prev: true
---

> **unwrapDER**(`derEncoded`, `oid`): `Uint8Array`

Defined in: [packages/agent/src/der.ts:144](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/der.ts#L144)

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`


### derEncoded

`Uint8Array`

The DER encoded and tagged data

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

## Returns

`Uint8Array`

The unwrapped payload
