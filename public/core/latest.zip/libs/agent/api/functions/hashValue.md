---
title: hashValue
editUrl: false
next: true
prev: true
---

> **hashValue**(`value`): `Uint8Array`

Defined in: [packages/agent/src/request\_id.ts:19](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/request_id.ts#L19)

## Parameters

### value

`unknown`

unknown value

## Returns

`Uint8Array`

Uint8Array
