---
title: hashValue
editUrl: false
next: true
prev: true
---

> **hashValue**(`value`): `Uint8Array`

Defined in: [packages/agent/src/request\_id.ts:19](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/request_id.ts#L19)

## Parameters

### value

`unknown`

unknown value

## Returns

`Uint8Array`

Uint8Array
