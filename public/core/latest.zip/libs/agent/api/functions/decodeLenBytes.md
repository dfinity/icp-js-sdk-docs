---
title: decodeLenBytes
editUrl: false
next: true
prev: true
---

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:47](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/der.ts#L47)


### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
