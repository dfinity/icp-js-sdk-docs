---
title: decodeLenBytes
editUrl: false
next: true
prev: true
---

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:47](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/der.ts#L47)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
