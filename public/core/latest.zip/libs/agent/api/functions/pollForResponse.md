---
title: pollForResponse
editUrl: false
next: true
prev: true
---

> **pollForResponse**(`agent`, `canisterId`, `requestId`, `options`): `Promise`\<\{ `certificate`: [`Certificate`](../classes/Certificate.md); `reply`: `Uint8Array`; \}\>

Defined in: [packages/agent/src/polling/index.ts:126](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/index.ts#L126)

Polls the IC to check the status of the given request then
returns the response bytes once the request has been processed.

## Parameters

### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to poll read_state.

### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

The effective canister ID.

### requestId

[`RequestId`](../type-aliases/RequestId.md)

The Request ID to poll status for.

### options

[`PollingOptions`](../interfaces/PollingOptions.md) = `{}`

polling options to control behavior

## Returns

`Promise`\<\{ `certificate`: [`Certificate`](../classes/Certificate.md); `reply`: `Uint8Array`; \}\>
