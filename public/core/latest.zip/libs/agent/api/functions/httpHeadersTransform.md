---
title: httpHeadersTransform
editUrl: false
next: true
prev: true
---

> **httpHeadersTransform**(`headers`): [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/agent/http/transforms.ts:147](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/transforms.ts#L147)

Maps the default fetch headers field to the serializable HttpHeaderField.


### headers

`Headers`

Fetch definition of the headers type

## Returns

[`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

array of header fields
