---
title: httpHeadersTransform
editUrl: false
next: true
prev: true
---

> **httpHeadersTransform**(`headers`): [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/agent/http/transforms.ts:147](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/transforms.ts#L147)

Maps the default fetch headers field to the serializable HttpHeaderField.


### headers

`Headers`

Fetch definition of the headers type

## Returns

[`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

array of header fields
