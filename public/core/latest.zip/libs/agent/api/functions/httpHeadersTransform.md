---
title: httpHeadersTransform
editUrl: false
next: true
prev: true
---

> **httpHeadersTransform**(`headers`): [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/agent/http/transforms.ts:152](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/transforms.ts#L152)

Maps the default fetch headers field to the serializable HttpHeaderField.

## Parameters

### headers

`Headers`

Fetch definition of the headers type

## Returns

[`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

array of header fields
