---
title: flatten_forks
editUrl: false
next: true
prev: true
---

> **flatten\_forks**(`t`): ([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

Defined in: [packages/core/src/agent/certificate.ts:735](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L735)

If the tree is a fork, flatten it into an array of trees

## Parameters

### t

[`HashTree`](../type-aliases/HashTree.md)

the tree to flatten

## Returns

([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

the flattened tree
