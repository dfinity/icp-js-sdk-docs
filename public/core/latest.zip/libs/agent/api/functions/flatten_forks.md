---
title: flatten_forks
editUrl: false
next: true
prev: true
---

> **flatten\_forks**(`t`): ([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

Defined in: [packages/agent/src/certificate.ts:673](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L673)

If the tree is a fork, flatten it into an array of trees

## Parameters

### t

[`HashTree`](../type-aliases/HashTree.md)

the tree to flatten

## Returns

([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

the flattened tree
