---
title: flatten_forks
editUrl: false
next: true
prev: true
---

> **flatten\_forks**(`t`): ([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

Defined in: [packages/agent/src/certificate.ts:673](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L673)

If the tree is a fork, flatten it into an array of trees


### t

[`HashTree`](../type-aliases/HashTree.md)

the tree to flatten

## Returns

([`LabeledHashTree`](../type-aliases/LabeledHashTree.md) \| [`LeafHashTree`](../type-aliases/LeafHashTree.md) \| [`PrunedHashTree`](../type-aliases/PrunedHashTree.md))[]

the flattened tree
