---
title: isV4ResponseBody
editUrl: false
next: true
prev: true
---

> **isV4ResponseBody**(`body`): `body is v4ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:150](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L150)

Utility function to check if a body is a v4ResponseBody for type safety.

## Parameters

### body

The body to check

`null` | [`v2ResponseBody`](../interfaces/v2ResponseBody.md) | [`v4ResponseBody`](../interfaces/v4ResponseBody.md)

## Returns

`body is v4ResponseBody`

boolean indicating if the body is a v4ResponseBody
