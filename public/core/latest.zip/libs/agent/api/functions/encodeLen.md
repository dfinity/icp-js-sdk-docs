---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/agent/src/der.ts:23](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/der.ts#L23)


### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
