---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/agent/src/der.ts:23](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/der.ts#L23)


### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
