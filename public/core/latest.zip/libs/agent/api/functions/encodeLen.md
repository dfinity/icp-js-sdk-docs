---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/agent/src/der.ts:23](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/der.ts#L23)

## Parameters

### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
