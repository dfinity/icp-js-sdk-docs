---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/core/src/agent/der.ts:25](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/der.ts#L25)

## Parameters

### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
