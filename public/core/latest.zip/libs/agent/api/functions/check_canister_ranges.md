---
title: check_canister_ranges
editUrl: false
next: true
prev: true
---

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/core/src/agent/certificate.ts:896](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L896)

Check if a canister ID falls within the canister ranges of a given subnet

## Parameters

### params

[`CheckCanisterRangesParams`](../interfaces/CheckCanisterRangesParams.md)

the parameters with which to check the canister ranges

## Returns

`boolean`

`true` if the canister is in the range, `false` otherwise
