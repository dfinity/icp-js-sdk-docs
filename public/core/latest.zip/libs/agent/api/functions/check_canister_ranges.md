---
title: check_canister_ranges
editUrl: false
next: true
prev: true
---

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/core/src/agent/certificate.ts:896](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L896)

Check if a canister ID falls within the canister ranges of a given subnet

## Parameters

### params

[`CheckCanisterRangesParams`](../interfaces/CheckCanisterRangesParams.md)

the parameters with which to check the canister ranges

## Returns

`boolean`

`true` if the canister is in the range, `false` otherwise
