---
title: check_canister_ranges
editUrl: false
next: true
prev: true
---

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/core/src/agent/certificate.ts:898](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L898)

Check if a canister ID falls within the canister ranges of a given subnet

## Parameters

### params

[`CheckCanisterRangesParams`](../type-aliases/CheckCanisterRangesParams.md)

the parameters with which to check the canister ranges

## Returns

`boolean`

`true` if the canister is in the range, `false` otherwise
