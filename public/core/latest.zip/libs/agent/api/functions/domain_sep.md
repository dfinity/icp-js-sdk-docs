---
title: domain_sep
editUrl: false
next: true
prev: true
---

> **domain\_sep**(`s`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:509](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L509)

Creates a domain separator for hashing by encoding the input string
with its length as a prefix.

## Parameters

### s

`string`

The input string to encode.

## Returns

`Uint8Array`

A Uint8Array containing the encoded domain separator.
