---
title: requestIdOf
editUrl: false
next: true
prev: true
---

> **requestIdOf**(`request`): [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/request\_id.ts:70](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/request_id.ts#L70)

Get the RequestId of the provided ic-ref request.
RequestId is the result of the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

## Parameters

### request

`Record`\<`string`, `unknown`\>

ic-ref request to hash into RequestId

## Returns

[`RequestId`](../type-aliases/RequestId.md)
