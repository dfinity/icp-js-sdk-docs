---
title: isV2ResponseBody
editUrl: false
next: true
prev: true
---

> **isV2ResponseBody**(`body`): `body is v2ResponseBody`

Defined in: [packages/agent/src/agent/api.ts:135](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L135)

Utility function to check if a body is a v2ResponseBody for type safety.

## Parameters

### body

The body to check

`null` | [`v2ResponseBody`](../interfaces/v2ResponseBody.md) | [`v3ResponseBody`](../interfaces/v3ResponseBody.md)

## Returns

`body is v2ResponseBody`

boolean indicating if the body is a v2ResponseBody
