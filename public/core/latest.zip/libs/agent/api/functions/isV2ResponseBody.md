---
title: isV2ResponseBody
editUrl: false
next: true
prev: true
---

> **isV2ResponseBody**(`body`): `body is v2ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:141](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/api.ts#L141)

Utility function to check if a body is a v2ResponseBody for type safety.

## Parameters

### body

[`v2ResponseBody`](../interfaces/v2ResponseBody.md) \| [`v4ResponseBody`](../interfaces/v4ResponseBody.md) \| `null`

The body to check

## Returns

`body is v2ResponseBody`

boolean indicating if the body is a v2ResponseBody
