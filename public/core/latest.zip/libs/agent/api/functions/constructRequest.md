---
title: constructRequest
editUrl: false
next: true
prev: true
---

> **constructRequest**(`options`): `Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

Defined in: [packages/agent/src/polling/index.ts:231](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/polling/index.ts#L231)

Constructs a read state request for the given paths.
If the request is already signed and has an expiry, it will be returned as is.
Otherwise, a new request will be created.

## Parameters

### options

The options to use for creating the request.

#### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to create the request.

#### paths

`Uint8Array`\<`ArrayBufferLike`\>[][]

The paths to read from.

#### pollingOptions

[`PollingOptions`](../interfaces/PollingOptions.md)

The options to use for creating the request.

## Returns

`Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

The read state request.
