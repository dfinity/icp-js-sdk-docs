---
title: constructRequest
editUrl: false
next: true
prev: true
---

> **constructRequest**(`options`): `Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

Defined in: [packages/agent/src/polling/index.ts:231](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/polling/index.ts#L231)

Constructs a read state request for the given paths.
If the request is already signed and has an expiry, it will be returned as is.
Otherwise, a new request will be created.


### options

The options to use for creating the request.

#### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to create the request.

#### paths

`Uint8Array`\<`ArrayBufferLike`\>[][]

The paths to read from.

#### pollingOptions

[`PollingOptions`](../interfaces/PollingOptions.md)

The options to use for creating the request.

## Returns

`Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

The read state request.
