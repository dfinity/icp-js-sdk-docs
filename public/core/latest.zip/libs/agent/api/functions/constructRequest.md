---
title: constructRequest
editUrl: false
next: true
prev: true
---

> **constructRequest**(`options`): `Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

Defined in: [packages/core/src/agent/polling/index.ts:219](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/polling/index.ts#L219)

Constructs a read state request for the given paths.
If the request is already signed and has an expiry, it will be returned as is.
Otherwise, a new request will be created.

## Parameters

### options

The options to use for creating the request.

#### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to create the request.

#### paths

`Uint8Array`\<`ArrayBufferLike`\>[][]

The paths to read from.

#### pollingOptions

[`PollingOptions`](../interfaces/PollingOptions.md)

The options to use for creating the request.

## Returns

`Promise`\<[`ReadStateRequest`](../interfaces/ReadStateRequest.md)\>

The read state request.
