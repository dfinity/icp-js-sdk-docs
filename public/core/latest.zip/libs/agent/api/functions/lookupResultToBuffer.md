---
title: lookupResultToBuffer
editUrl: false
next: true
prev: true
---

> **lookupResultToBuffer**(`result`): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/certificate.ts:403](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L403)

Utility function to constrain the type of a lookup result


### result

[`LookupResult`](../type-aliases/LookupResult.md)

the result of a lookup

## Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

the value if the lookup was found, `undefined` otherwise
