---
title: lookupResultToBuffer
editUrl: false
next: true
prev: true
---

> **lookupResultToBuffer**(`result`): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/certificate.ts:403](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L403)

Utility function to constrain the type of a lookup result

## Parameters

### result

[`LookupResult`](../type-aliases/LookupResult.md)

the result of a lookup

## Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

the value if the lookup was found, `undefined` otherwise
