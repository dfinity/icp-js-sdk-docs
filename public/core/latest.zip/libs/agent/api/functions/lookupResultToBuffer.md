---
title: lookupResultToBuffer
editUrl: false
next: true
prev: true
---

> **lookupResultToBuffer**(`result`): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/agent/certificate.ts:463](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L463)

Utility function to constrain the type of a lookup result

## Parameters

### result

[`LookupResult`](../type-aliases/LookupResult.md)

the result of a lookup

## Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

the value if the lookup was found, `undefined` otherwise
