---
title: makeExpiryTransform
editUrl: false
next: true
prev: true
---

> **makeExpiryTransform**(`delayInMilliseconds`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:136](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/transforms.ts#L136)

Create a transform that adds a delay (by default 5 minutes) to the expiry.


### delayInMilliseconds

`number`

The delay to add to the call time, in milliseconds.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
