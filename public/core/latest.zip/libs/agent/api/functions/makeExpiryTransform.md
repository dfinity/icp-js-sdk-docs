---
title: makeExpiryTransform
editUrl: false
next: true
prev: true
---

> **makeExpiryTransform**(`delayInMilliseconds`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:141](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/transforms.ts#L141)

Create a transform that adds a delay (by default 5 minutes) to the expiry.

## Parameters

### delayInMilliseconds

`number`

The delay to add to the call time, in milliseconds.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
