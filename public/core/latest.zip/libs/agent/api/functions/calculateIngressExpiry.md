---
title: calculateIngressExpiry
editUrl: false
next: true
prev: true
---

> **calculateIngressExpiry**(`maxIngressExpiryInMinutes`, `timeDiffMsecs`): [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/agent/http/index.ts:1711](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/agent/http/index.ts#L1711)

Calculates the ingress expiry time based on the maximum allowed expiry in minutes and the time difference in milliseconds.
The expiry is rounded down according to the [Expiry.fromDeltaInMilliseconds](../classes/Expiry.md#fromdeltainmilliseconds) method.

## Parameters

### maxIngressExpiryInMinutes

`number`

The maximum ingress expiry time in minutes.

### timeDiffMsecs

`number`

The time difference in milliseconds to adjust the expiry.

## Returns

[`Expiry`](../classes/Expiry.md)

The calculated ingress expiry as an Expiry object.
