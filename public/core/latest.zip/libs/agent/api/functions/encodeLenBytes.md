---
title: encodeLenBytes
editUrl: false
next: true
prev: true
---

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/agent/src/der.ts:9](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/der.ts#L9)

## Parameters

### len

`number`

## Returns

`number`
