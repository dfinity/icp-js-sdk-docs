---
title: encodeLenBytes
editUrl: false
next: true
prev: true
---

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/agent/src/der.ts:9](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/der.ts#L9)

## Parameters

### len

`number`

## Returns

`number`
