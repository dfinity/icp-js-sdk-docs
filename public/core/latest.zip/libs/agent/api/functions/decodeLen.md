---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:70](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/der.ts#L70)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
