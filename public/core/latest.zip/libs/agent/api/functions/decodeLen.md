---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:56](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/der.ts#L56)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
