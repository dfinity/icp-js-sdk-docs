---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:56](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/der.ts#L56)


### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
