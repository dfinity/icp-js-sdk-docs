---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:56](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/der.ts#L56)


### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
