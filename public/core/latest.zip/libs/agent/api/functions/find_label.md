---
title: find_label
editUrl: false
next: true
prev: true
---

> **find\_label**(`label`, `tree`): [`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:690](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L690)

Find a label in a tree


### label

[`NodeLabel`](../type-aliases/NodeLabel.md)

the label to find

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

the result of the label lookup
