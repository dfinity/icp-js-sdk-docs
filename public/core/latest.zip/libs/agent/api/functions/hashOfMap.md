---
title: hashOfMap
editUrl: false
next: true
prev: true
---

> **hashOfMap**(`map`): `Uint8Array`

Defined in: [packages/core/src/agent/request\_id.ts:80](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/request_id.ts#L80)

Hash a map into a Uint8Array using the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

## Parameters

### map

`Record`\<`string`, `unknown`\>

Any non-nested object

## Returns

`Uint8Array`

Uint8Array
