---
title: hashOfMap
editUrl: false
next: true
prev: true
---

> **hashOfMap**(`map`): `Uint8Array`

Defined in: [packages/agent/src/request\_id.ts:73](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/request_id.ts#L73)

Hash a map into a Uint8Array using the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

## Parameters

### map

`Record`\<`string`, `unknown`\>

Any non-nested object

## Returns

`Uint8Array`

Uint8Array
