---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/agent/src/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.


### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | `DataView`\<`ArrayBufferLike`\> | \[`number`\] | \{ `buffer`: `ArrayBuffer`; \} | `number`[]

## Returns

`Uint8Array`

Uint8Array
