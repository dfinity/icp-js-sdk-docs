---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/agent/src/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.


### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | `DataView`\<`ArrayBufferLike`\> | \[`number`\] | \{ `buffer`: `ArrayBuffer`; \} | `number`[]

## Returns

`Uint8Array`

Uint8Array
