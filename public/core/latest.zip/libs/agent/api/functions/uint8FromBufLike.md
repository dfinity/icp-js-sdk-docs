---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/agent/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.

## Parameters

### bufLike

`ArrayBufferLike` \| `Uint8Array`\<`ArrayBufferLike`\> \| `number`[] \| `DataView`\<`ArrayBufferLike`\> \| `ArrayBufferView`\<`ArrayBufferLike`\> \| \[`number`\] \| \{ `buffer`: `ArrayBuffer`; \}

a buffer-like object

## Returns

`Uint8Array`

Uint8Array
