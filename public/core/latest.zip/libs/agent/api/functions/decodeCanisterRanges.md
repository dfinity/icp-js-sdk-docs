---
title: decodeCanisterRanges
editUrl: false
next: true
prev: true
---

> **decodeCanisterRanges**(`lookupValue`): [`CanisterRanges`](../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/certificate.ts:975](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L975)

Decode canister ranges from CBOR-encoded buffer

## Parameters

### lookupValue

`Uint8Array`

the CBOR-encoded value read from the certificate

## Returns

[`CanisterRanges`](../type-aliases/CanisterRanges.md)

an array of canister range tuples [start, end]
