---
title: decodeCanisterRanges
editUrl: false
next: true
prev: true
---

> **decodeCanisterRanges**(`lookupValue`): [`CanisterRanges`](../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/certificate.ts:973](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L973)

Decode canister ranges from CBOR-encoded buffer

## Parameters

### lookupValue

`Uint8Array`

the CBOR-encoded value read from the certificate

## Returns

[`CanisterRanges`](../type-aliases/CanisterRanges.md)

an array of canister range tuples [start, end]
