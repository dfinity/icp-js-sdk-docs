---
title: lookupCanisterRanges
editUrl: false
next: true
prev: true
---

> **lookupCanisterRanges**(`params`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:919](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L919)

Lookup the canister ranges using the `/canister_ranges/<subnet_id>/<ranges>` path.
Certificates returned by `/api/v4/canister/<effective_canister_id>/call`
and `/api/v3/canister/<effective_canister_id>/read_state` use this path.

If the new lookup is not found, it tries the fallback lookup with [lookupCanisterRangesFallback](lookupCanisterRangesFallback.md).

## Parameters

### params

[`CheckCanisterRangesParams`](../interfaces/CheckCanisterRangesParams.md)

the parameters with which to lookup the canister ranges

## Returns

`Uint8Array`

the encoded canister ranges. Use [decodeCanisterRanges](decodeCanisterRanges.md) to decode them.

## See

 - https://internetcomputer.org/docs/references/ic-interface-spec#http-read-state
 - https://internetcomputer.org/docs/references/ic-interface-spec#state-tree-canister-ranges
