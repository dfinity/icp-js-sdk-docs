---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/agent/src/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L111)

Create a random Nonce, based on random values

## Returns

[`Nonce`](../type-aliases/Nonce.md)
