---
title: lookup_subtree
editUrl: false
next: true
prev: true
---

> **lookup\_subtree**(`path`, `tree`): [`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:632](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L632)

Lookup a subtree in a tree.


### path

[`NodePath`](../type-aliases/NodePath.md)

the path to look up

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

the result of the lookup
