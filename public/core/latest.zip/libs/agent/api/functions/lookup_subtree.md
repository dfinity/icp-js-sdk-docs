---
title: lookup_subtree
editUrl: false
next: true
prev: true
---

> **lookup\_subtree**(`path`, `tree`): [`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

Defined in: [packages/core/src/agent/certificate.ts:692](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L692)

Lookup a subtree in a tree.

## Parameters

### path

[`NodePath`](../type-aliases/NodePath.md)

the path to look up

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

the result of the lookup
