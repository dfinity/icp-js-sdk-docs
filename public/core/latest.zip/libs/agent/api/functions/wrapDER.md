---
title: wrapDER
editUrl: false
next: true
prev: true
---

> **wrapDER**(`payload`, `oid`): `Uint8Array`

Defined in: [packages/agent/src/der.ts:111](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/der.ts#L111)

Wraps the given `payload` in a DER encoding tagged with the given encoded `oid` like so:
`SEQUENCE(oid, BITSTRING(payload))`


### payload

`Uint8Array`

The payload to encode as the bit string

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) OID to tag the payload with

## Returns

`Uint8Array`
