---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/auth.ts#L139)

Create an IdentityDescriptor from a @dfinity/identity Identity

## Parameters

### identity

identity describe in returned descriptor

[`SignIdentity`](../classes/SignIdentity.md) | [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
