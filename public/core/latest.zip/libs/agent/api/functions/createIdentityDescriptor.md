---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/core/src/agent/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/auth.ts#L139)

Create an IdentityDescriptor from an Identity

## Parameters

### identity

[`SignIdentity`](../classes/SignIdentity.md) \| [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

identity describe in returned descriptor

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
