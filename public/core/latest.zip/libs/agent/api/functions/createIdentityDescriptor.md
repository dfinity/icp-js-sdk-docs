---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/core/src/agent/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/auth.ts#L139)

Create an IdentityDescriptor from an Identity

## Parameters

### identity

[`SignIdentity`](../classes/SignIdentity.md) \| [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

identity describe in returned descriptor

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
