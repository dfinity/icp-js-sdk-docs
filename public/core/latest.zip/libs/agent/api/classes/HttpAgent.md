---
title: HttpAgent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/index.ts:286](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L286)

A HTTP agent allows users to interact with a client of the internet computer
using the available methods. It exposes an API that closely follows the
public view of the internet computer, and is not intended to be exposed
directly to the majority of users due to its low-level interface.
There is a pipeline to apply transformations to the request before sending
it to the client. This is to decouple signature, nonce generation and
other computations so that this class can stay as simple as possible while
allowing extensions.


- [`Agent`](../interfaces/Agent.md)

## Constructors

### Constructor

> **new HttpAgent**(`options`): `HttpAgent`

Defined in: [packages/agent/src/agent/http/index.ts:327](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L327)

#### Parameters

##### options

[`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

Options for the HttpAgent

#### Returns

`HttpAgent`

#### Deprecated

Use `HttpAgent.create` or `HttpAgent.createSync` instead

## Properties

### \_isAgent

> `readonly` **\_isAgent**: `true` = `true`

Defined in: [packages/agent/src/agent/http/index.ts:310](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L310)

***

### config

> **config**: [`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

Defined in: [packages/agent/src/agent/http/index.ts:311](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L311)

***

### host

> `readonly` **host**: `URL`

Defined in: [packages/agent/src/agent/http/index.ts:300](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L300)

***

### log

> **log**: [`ObservableLog`](ObservableLog.md)

Defined in: [packages/agent/src/agent/http/index.ts:313](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L313)

***

### rootKey

> **rootKey**: `null` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/agent/http/index.ts:287](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L287)

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`rootKey`](../interfaces/Agent.md#rootkey)

## Methods

### \_transform()

> `protected` **\_transform**(`request`): `Promise`\<[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:1369](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1369)

#### Parameters

##### request

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

#### Returns

`Promise`\<[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

***

### addTransform()

> **addTransform**(`type`, `fn`, `priority`): `void`

Defined in: [packages/agent/src/agent/http/index.ts:444](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L444)

#### Parameters

##### type

`"query"` | `"update"`

##### fn

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

##### priority

`number` = `...`

#### Returns

`void`

***

### call()

> **call**(`canisterId`, `options`, `identity?`): `Promise`\<[`SubmitResponse`](../interfaces/SubmitResponse.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:487](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L487)

Makes a call to a canister method.

#### Parameters

##### canisterId

The ID of the canister to call. Can be a Principal or a string.

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### options

Options for the call.

###### arg

`Uint8Array`

The argument to pass to the method, as a Uint8Array.

###### callSync?

`boolean`

(Optional) Whether to use synchronous call mode. Defaults to true.

###### effectiveCanisterId?

`string` \| [`Principal`](../../../principal/api/classes/Principal.md)

(Optional) The effective canister ID, if different from the target canister ID.

###### methodName

`string`

The name of the method to call.

###### nonce?

`Uint8Array`\<`ArrayBufferLike`\> \| [`Nonce`](../type-aliases/Nonce.md)

(Optional) A unique nonce for the request. If provided, it will override any nonce set by transforms.

##### identity?

(Optional) The identity to use for the call. If not provided, the agent's current identity will be used.

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

#### Returns

`Promise`\<[`SubmitResponse`](../interfaces/SubmitResponse.md)\>

A promise that resolves to the response of the call, including the request ID and response details.

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`call`](../interfaces/Agent.md#call)

***

### createReadStateRequest()

> **createReadStateRequest**(`fields`, `identity?`): `Promise`\<`any`\>

Defined in: [packages/agent/src/agent/http/index.ts:1053](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1053)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

#### Parameters

##### fields

[`ReadStateOptions`](../interfaces/ReadStateOptions.md)

##### identity?

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

#### Returns

`Promise`\<`any`\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`createReadStateRequest`](../interfaces/Agent.md#createreadstaterequest)

***

### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/agent/src/agent/http/index.ts:1302](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1302)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

#### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`fetchRootKey`](../interfaces/Agent.md#fetchrootkey)

***

### fetchSubnetKeys()

> **fetchSubnetKeys**(`canisterId`): `Promise`\<`undefined` \| [`SubnetStatus`](../namespaces/CanisterStatus/type-aliases/SubnetStatus.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:1351](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1351)

#### Parameters

##### canisterId

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

#### Returns

`Promise`\<`undefined` \| [`SubnetStatus`](../namespaces/CanisterStatus/type-aliases/SubnetStatus.md)\>

***

### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:468](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L468)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

#### Returns

`Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`getPrincipal`](../interfaces/Agent.md#getprincipal)

***

### getTimeDiffMsecs()

> **getTimeDiffMsecs**(): `number`

Defined in: [packages/agent/src/agent/http/index.ts:1390](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1390)

Returns the time difference in milliseconds between the IC network clock and the client's clock,
after the clock has been synced.

If the time has not been synced, returns `0`.

#### Returns

`number`

***

### hasSyncedTime()

> **hasSyncedTime**(): `boolean`

Defined in: [packages/agent/src/agent/http/index.ts:1397](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1397)

Returns `true` if the time has been synced at least once with the IC network, `false` otherwise.

#### Returns

`boolean`

***

### invalidateIdentity()

> **invalidateIdentity**(): `void`

Defined in: [packages/agent/src/agent/http/index.ts:1343](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1343)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

#### Returns

`void`

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`invalidateIdentity`](../interfaces/Agent.md#invalidateidentity)

***

### isLocal()

> **isLocal**(): `boolean`

Defined in: [packages/agent/src/agent/http/index.ts:439](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L439)

#### Returns

`boolean`

***

### parseTimeFromResponse()

> **parseTimeFromResponse**(`response`): `number`

Defined in: [packages/agent/src/agent/http/index.ts:1174](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1174)

#### Parameters

##### response

###### certificate

`Uint8Array`

#### Returns

`number`

***

### query()

> **query**(`canisterId`, `fields`, `identity?`): `Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:869](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L869)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

#### Parameters

##### canisterId

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### fields

[`QueryFields`](../interfaces/QueryFields.md)

Options to use to create and send the query.

##### identity?

Sender principal to use when sending the query.

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

#### Returns

`Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`query`](../interfaces/Agent.md#query)

***

### readState()

> **readState**(`canisterId`, `fields`, `_identity?`, `request?`): `Promise`\<[`ReadStateResponse`](../interfaces/ReadStateResponse.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:1089](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1089)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

#### Parameters

##### canisterId

A Canister ID related to this call.

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### fields

[`ReadStateOptions`](../interfaces/ReadStateOptions.md)

The options for this call.

##### \_identity?

Identity for the call. If not specified, uses the instance identity.

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

##### request?

`any`

The request to send in case it has already been created.

#### Returns

`Promise`\<[`ReadStateResponse`](../interfaces/ReadStateResponse.md)\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`readState`](../interfaces/Agent.md#readstate)

***

### replaceIdentity()

> **replaceIdentity**(`identity`): `void`

Defined in: [packages/agent/src/agent/http/index.ts:1347](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1347)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@dfinity/auth-client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

#### Parameters

##### identity

[`Identity`](../interfaces/Identity.md)

#### Returns

`void`

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`replaceIdentity`](../interfaces/Agent.md#replaceidentity)

***

### status()

> **status**(): `Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

Defined in: [packages/agent/src/agent/http/index.ts:1284](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1284)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

#### Returns

`Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`status`](../interfaces/Agent.md#status)

***

### syncTime()

> **syncTime**(`canisterIdOverride?`): `Promise`\<`void`\>

Defined in: [packages/agent/src/agent/http/index.ts:1214](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L1214)

Allows agent to sync its time with the network. Can be called during intialization or mid-lifecycle if the device's clock has drifted away from the network time. This is necessary to set the Expiry for a request

#### Parameters

##### canisterIdOverride?

[`Principal`](../../../principal/api/classes/Principal.md)

Pass a canister ID if you need to sync the time with a particular subnet. Uses the ICP ledger canister by default.

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `Promise`\<`HttpAgent`\>

Defined in: [packages/agent/src/agent/http/index.ts:414](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L414)

#### Parameters

##### options

[`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

#### Returns

`Promise`\<`HttpAgent`\>

***

### createSync()

> `static` **createSync**(`options`): `HttpAgent`

Defined in: [packages/agent/src/agent/http/index.ts:410](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L410)

#### Parameters

##### options

[`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

#### Returns

`HttpAgent`

***

### from()

> `static` **from**(`agent`): `Promise`\<`HttpAgent`\>

Defined in: [packages/agent/src/agent/http/index.ts:420](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/index.ts#L420)

#### Parameters

##### agent

`V1HttpAgentInterface` | `Pick`\<`HttpAgent`, `"config"`\>

#### Returns

`Promise`\<`HttpAgent`\>
