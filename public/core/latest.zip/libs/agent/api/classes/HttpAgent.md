---
title: HttpAgent
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:295](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L295)

A HTTP agent allows users to interact with a client of the internet computer
using the available methods. It exposes an API that closely follows the
public view of the internet computer, and is not intended to be exposed
directly to the majority of users due to its low-level interface.
There is a pipeline to apply transformations to the request before sending
it to the client. This is to decouple signature, nonce generation and
other computations so that this class can stay as simple as possible while
allowing extensions.

## Implements

- [`Agent`](../interfaces/Agent.md)

## Constructors

### Constructor

> **new HttpAgent**(`options`): `HttpAgent`

Defined in: [packages/core/src/agent/agent/http/index.ts:336](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L336)

#### Parameters

##### options

[`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

Options for the HttpAgent

#### Returns

`HttpAgent`

#### Deprecated

Use `HttpAgent.create` or `HttpAgent.createSync` instead

## Properties

### \_isAgent

> `readonly` **\_isAgent**: `true` = `true`

Defined in: [packages/core/src/agent/agent/http/index.ts:319](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L319)

***

### config

> **config**: [`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

Defined in: [packages/core/src/agent/agent/http/index.ts:320](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L320)

***

### host

> `readonly` **host**: `URL`

Defined in: [packages/core/src/agent/agent/http/index.ts:309](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L309)

***

### log

> **log**: [`ObservableLog`](ObservableLog.md)

Defined in: [packages/core/src/agent/agent/http/index.ts:322](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L322)

***

### rootKey

> **rootKey**: `null` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:296](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L296)

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`rootKey`](../interfaces/Agent.md#rootkey)

## Methods

### \_transform()

> `protected` **\_transform**(`request`): `Promise`\<[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1511](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1511)

#### Parameters

##### request

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

#### Returns

`Promise`\<[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

***

### addTransform()

> **addTransform**(`type`, `fn`, `priority`): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:453](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L453)

#### Parameters

##### type

`"query"` | `"update"`

##### fn

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

##### priority

`number` = `...`

#### Returns

`void`

***

### call()

> **call**(`canisterId`, `options`, `identity?`): `Promise`\<[`SubmitResponse`](../interfaces/SubmitResponse.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:496](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L496)

Makes a call to a canister method.

#### Parameters

##### canisterId

The ID of the canister to call. Can be a Principal or a string.

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### options

Options for the call.

###### arg

`Uint8Array`

The argument to pass to the method, as a Uint8Array.

###### callSync?

`boolean`

(Optional) Whether to use synchronous call mode. Defaults to true.

###### effectiveCanisterId?

`string` \| [`Principal`](../../../principal/api/classes/Principal.md)

(Optional) The effective canister ID, if different from the target canister ID.

###### methodName

`string`

The name of the method to call.

###### nonce?

`Uint8Array`\<`ArrayBufferLike`\> \| [`Nonce`](../type-aliases/Nonce.md)

(Optional) A unique nonce for the request. If provided, it will override any nonce set by transforms.

##### identity?

(Optional) The identity to use for the call. If not provided, the agent's current identity will be used.

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

#### Returns

`Promise`\<[`SubmitResponse`](../interfaces/SubmitResponse.md)\>

A promise that resolves to the response of the call, including the request ID and response details.

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`call`](../interfaces/Agent.md#call)

***

### createReadStateRequest()

> **createReadStateRequest**(`fields`, `identity?`): `Promise`\<`any`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1069](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1069)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

#### Parameters

##### fields

[`ReadStateOptions`](../interfaces/ReadStateOptions.md)

##### identity?

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

#### Returns

`Promise`\<`any`\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`createReadStateRequest`](../interfaces/Agent.md#createreadstaterequest)

***

### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1403](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1403)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

#### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`fetchRootKey`](../interfaces/Agent.md#fetchrootkey)

***

### fetchSubnetKeys()

> **fetchSubnetKeys**(`canisterId`): `Promise`\<`SubnetNodeKeys`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1452](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1452)

#### Parameters

##### canisterId

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

#### Returns

`Promise`\<`SubnetNodeKeys`\>

***

### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:477](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L477)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

#### Returns

`Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`getPrincipal`](../interfaces/Agent.md#getprincipal)

***

### getSubnetIdFromCanister()

> **getSubnetIdFromCanister**(`canisterId`): `Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1494](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1494)

Returns the subnet ID for a given canister ID, by looking at the certificate delegation
returned by the canister's state obtained by requesting the `/time` path with [readState](#readstate).

#### Parameters

##### canisterId

The canister ID to get the subnet ID for.

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

#### Returns

`Promise`\<[`Principal`](../../../principal/api/classes/Principal.md)\>

The subnet ID for the given canister ID.

***

### getTimeDiffMsecs()

> **getTimeDiffMsecs**(): `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:1532](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1532)

Returns the time difference in milliseconds between the IC network clock and the client's clock,
after the clock has been synced.

If the time has not been synced, returns `0`.

#### Returns

`number`

***

### hasSyncedTime()

> **hasSyncedTime**(): `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:1539](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1539)

Returns `true` if the time has been synced at least once with the IC network, `false` otherwise.

#### Returns

`boolean`

***

### invalidateIdentity()

> **invalidateIdentity**(): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:1444](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1444)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

#### Returns

`void`

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`invalidateIdentity`](../interfaces/Agent.md#invalidateidentity)

***

### isLocal()

> **isLocal**(): `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:448](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L448)

#### Returns

`boolean`

***

### parseTimeFromResponse()

> **parseTimeFromResponse**(`response`): `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:1224](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1224)

#### Parameters

##### response

###### certificate

`Uint8Array`

#### Returns

`number`

***

### query()

> **query**(`canisterId`, `fields`, `identity?`): `Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:877](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L877)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

#### Parameters

##### canisterId

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### fields

[`QueryFields`](../interfaces/QueryFields.md)

##### identity?

Sender principal to use when sending the query.

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

#### Returns

`Promise`\<[`ApiQueryResponse`](../type-aliases/ApiQueryResponse.md)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`query`](../interfaces/Agent.md#query)

***

### readState()

> **readState**(`canisterId`, `fields`, `_identity?`, `request?`): `Promise`\<[`ReadStateResponse`](../interfaces/ReadStateResponse.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1105](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1105)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

#### Parameters

##### canisterId

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### fields

[`ReadStateOptions`](../interfaces/ReadStateOptions.md)

##### \_identity?

[`Identity`](../interfaces/Identity.md) | `Promise`\<[`Identity`](../interfaces/Identity.md)\>

##### request?

`any`

The request to send in case it has already been created.

#### Returns

`Promise`\<[`ReadStateResponse`](../interfaces/ReadStateResponse.md)\>

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`readState`](../interfaces/Agent.md#readstate)

***

### readSubnetState()

> **readSubnetState**(`subnetId`, `options`): `Promise`\<[`ReadStateResponse`](../interfaces/ReadStateResponse.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1155](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1155)

Reads the state of a subnet from the `/api/v3/subnet/{subnetId}/read_state` endpoint.

#### Parameters

##### subnetId

The ID of the subnet to read the state of. If you have a canister ID, you can use [getSubnetIdFromCanister](#getsubnetidfromcanister) to get the subnet ID.

`string` | [`Principal`](../../../principal/api/classes/Principal.md)

##### options

[`ReadStateOptions`](../interfaces/ReadStateOptions.md)

The options for the read state request.

#### Returns

`Promise`\<[`ReadStateResponse`](../interfaces/ReadStateResponse.md)\>

The response from the read state request.

***

### replaceIdentity()

> **replaceIdentity**(`identity`): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:1448](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1448)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@icp-sdk/auth/client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

#### Parameters

##### identity

[`Identity`](../interfaces/Identity.md)

#### Returns

`void`

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`replaceIdentity`](../interfaces/Agent.md#replaceidentity)

***

### status()

> **status**(): `Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1384](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1384)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

#### Returns

`Promise`\<[`JsonObject`](../../../candid/api/interfaces/JsonObject.md)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.

#### Implementation of

[`Agent`](../interfaces/Agent.md).[`status`](../interfaces/Agent.md#status)

***

### syncTime()

> **syncTime**(`canisterIdOverride?`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1264](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1264)

Allows agent to sync its time with the network. Can be called during initialization or mid-lifecycle if the device's clock has drifted away from the network time. This is necessary to set the Expiry for a request

#### Parameters

##### canisterIdOverride?

[`Principal`](../../../principal/api/classes/Principal.md)

Pass a canister ID if you need to sync the time with a particular subnet. Uses the ICP ledger canister by default.

#### Returns

`Promise`\<`void`\>

***

### syncTimeWithSubnet()

> **syncTimeWithSubnet**(`subnetId`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1327](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L1327)

Allows agent to sync its time with the network.

#### Parameters

##### subnetId

[`Principal`](../../../principal/api/classes/Principal.md)

Pass the subnet ID you need to sync the time with.

#### Returns

`Promise`\<`void`\>

***

### create()

> `static` **create**(`options`): `Promise`\<`HttpAgent`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:423](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L423)

#### Parameters

##### options

[`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

#### Returns

`Promise`\<`HttpAgent`\>

***

### createSync()

> `static` **createSync**(`options`): `HttpAgent`

Defined in: [packages/core/src/agent/agent/http/index.ts:419](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L419)

#### Parameters

##### options

[`HttpAgentOptions`](../interfaces/HttpAgentOptions.md) = `{}`

#### Returns

`HttpAgent`

***

### from()

> `static` **from**(`agent`): `Promise`\<`HttpAgent`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:429](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L429)

#### Parameters

##### agent

`V1HttpAgentInterface` | `Pick`\<`HttpAgent`, `"config"`\>

#### Returns

`Promise`\<`HttpAgent`\>
