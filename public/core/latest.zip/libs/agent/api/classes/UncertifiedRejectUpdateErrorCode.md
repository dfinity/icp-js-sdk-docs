---
title: UncertifiedRejectUpdateErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:518](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L518)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new UncertifiedRejectUpdateErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`): `UncertifiedRejectUpdateErrorCode`

Defined in: [packages/agent/src/errors.ts:521](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L521)

#### Parameters

##### requestId

[`RequestId`](../type-aliases/RequestId.md)

##### rejectCode

[`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

##### rejectMessage

`string`

##### rejectErrorCode

`undefined` | `string`

#### Returns

`UncertifiedRejectUpdateErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'UncertifiedRejectUpdateErrorCode'`

Defined in: [packages/agent/src/errors.ts:519](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L519)

***

### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

Defined in: [packages/agent/src/errors.ts:523](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L523)

***

### rejectErrorCode

> `readonly` **rejectErrorCode**: `undefined` \| `string`

Defined in: [packages/agent/src/errors.ts:525](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L525)

***

### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/agent/src/errors.ts:524](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L524)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

***

### requestId

> `readonly` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/errors.ts:522](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L522)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:531](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L531)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
