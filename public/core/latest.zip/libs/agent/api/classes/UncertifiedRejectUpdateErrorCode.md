---
title: UncertifiedRejectUpdateErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:532](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L532)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new UncertifiedRejectUpdateErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`): `UncertifiedRejectUpdateErrorCode`

Defined in: [packages/core/src/agent/errors.ts:535](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L535)

#### Parameters

##### requestId

[`RequestId`](../type-aliases/RequestId.md)

##### rejectCode

[`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

##### rejectMessage

`string`

##### rejectErrorCode

`undefined` | `string`

#### Returns

`UncertifiedRejectUpdateErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/core/src/agent/errors.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L40)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L42)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'UncertifiedRejectUpdateErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:533](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L533)

***

### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

Defined in: [packages/core/src/agent/errors.ts:537](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L537)

***

### rejectErrorCode

> `readonly` **rejectErrorCode**: `undefined` \| `string`

Defined in: [packages/core/src/agent/errors.ts:539](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L539)

***

### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:538](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L538)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L39)

#### Inherited from

`ErrorCode.requestContext`

***

### requestId

> `readonly` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:536](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L536)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:545](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L545)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L46)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
