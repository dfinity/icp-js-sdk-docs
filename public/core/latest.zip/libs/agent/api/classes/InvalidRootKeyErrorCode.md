---
title: InvalidRootKeyErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:810](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L810)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new InvalidRootKeyErrorCode**(`rootKey`, `expectedLength`): `InvalidRootKeyErrorCode`

Defined in: [packages/agent/src/errors.ts:813](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L813)

#### Parameters

##### rootKey

`Uint8Array`

##### expectedLength

`number`

#### Returns

`InvalidRootKeyErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/agent/src/errors.ts:815](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L815)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'InvalidRootKeyErrorCode'`

Defined in: [packages/agent/src/errors.ts:811](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L811)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

***

### rootKey

> `readonly` **rootKey**: `Uint8Array`

Defined in: [packages/agent/src/errors.ts:814](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L814)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:821](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L821)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
