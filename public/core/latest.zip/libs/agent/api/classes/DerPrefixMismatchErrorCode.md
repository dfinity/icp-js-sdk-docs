---
title: DerPrefixMismatchErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:375](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L375)

## Extends

- [`ErrorCode`](ErrorCode.md)

## Constructors

### Constructor

> **new DerPrefixMismatchErrorCode**(`expectedPrefix`, `actualPrefix`): `DerPrefixMismatchErrorCode`

Defined in: [packages/core/src/agent/errors.ts:378](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L378)

#### Parameters

##### expectedPrefix

`Uint8Array`

##### actualPrefix

`Uint8Array`

#### Returns

`DerPrefixMismatchErrorCode`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`constructor`](ErrorCode.md#constructor)

## Properties

### actualPrefix

> `readonly` **actualPrefix**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:380](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L380)

***

### callContext?

> `optional` **callContext?**: [`CallContext`](../interfaces/CallContext.md) \| [`PollingCallContext`](../interfaces/PollingCallContext.md)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L78)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`callContext`](ErrorCode.md#callcontext)

***

### expectedPrefix

> `readonly` **expectedPrefix**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:379](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L379)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L80)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`isCertified`](ErrorCode.md#iscertified)

***

### name

> **name**: `string` = `'DerPrefixMismatchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:376](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L376)

***

### requestContext?

> `optional` **requestContext?**: [`RequestContext`](../interfaces/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L77)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`requestContext`](ErrorCode.md#requestcontext)

***

### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](../enumerations/ErrorVerbosity.md) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L75)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`verbosity`](ErrorCode.md#verbosity)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:386](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L386)

#### Returns

`string`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`toErrorMessage`](ErrorCode.md#toerrormessage)

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L84)

#### Returns

`string`

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`toString`](ErrorCode.md#tostring)
