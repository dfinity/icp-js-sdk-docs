---
title: UncertifiedRejectErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:493](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L493)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new UncertifiedRejectErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`, `signatures`): `UncertifiedRejectErrorCode`

Defined in: [packages/agent/src/errors.ts:496](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L496)

#### Parameters

##### requestId

[`RequestId`](../type-aliases/RequestId.md)

##### rejectCode

[`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

##### rejectMessage

`string`

##### rejectErrorCode

`undefined` | `string`

##### signatures

`undefined` | [`NodeSignature`](../type-aliases/NodeSignature.md)[]

#### Returns

`UncertifiedRejectErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'UncertifiedRejectErrorCode'`

Defined in: [packages/agent/src/errors.ts:494](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L494)

***

### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

Defined in: [packages/agent/src/errors.ts:498](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L498)

***

### rejectErrorCode

> `readonly` **rejectErrorCode**: `undefined` \| `string`

Defined in: [packages/agent/src/errors.ts:500](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L500)

***

### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/agent/src/errors.ts:499](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L499)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

***

### requestId

> `readonly` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/errors.ts:497](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L497)

***

### signatures

> `readonly` **signatures**: `undefined` \| [`NodeSignature`](../type-aliases/NodeSignature.md)[]

Defined in: [packages/agent/src/errors.ts:501](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L501)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:507](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L507)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
