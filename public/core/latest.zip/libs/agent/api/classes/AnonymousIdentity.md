---
title: AnonymousIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:101](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/auth.ts#L101)

A General Identity object. This does not have to be a private key (for example,
the Anonymous identity), but it must be able to transform request.


- [`Identity`](../interfaces/Identity.md)

## Constructors

### Constructor

> **new AnonymousIdentity**(): `AnonymousIdentity`

#### Returns

`AnonymousIdentity`

## Methods

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/auth.ts:102](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/auth.ts#L102)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Implementation of

[`Identity`](../interfaces/Identity.md).[`getPrincipal`](../interfaces/Identity.md#getprincipal)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/agent/src/auth.ts:106](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/auth.ts#L106)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

#### Returns

`Promise`\<`unknown`\>

#### Implementation of

[`Identity`](../interfaces/Identity.md).[`transformRequest`](../interfaces/Identity.md#transformrequest)
