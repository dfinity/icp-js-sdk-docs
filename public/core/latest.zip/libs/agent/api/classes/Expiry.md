---
title: Expiry
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/transforms.ts:31](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L31)


### \_isExpiry

> `readonly` **\_isExpiry**: `true` = `true`

Defined in: [packages/agent/src/agent/http/transforms.ts:32](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L32)

## Methods

### toBigInt()

> **toBigInt**(): `bigint`

Defined in: [packages/agent/src/agent/http/transforms.ts:59](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L59)

#### Returns

`bigint`

***

### toHash()

> **toHash**(): `Uint8Array`

Defined in: [packages/agent/src/agent/http/transforms.ts:63](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L63)

#### Returns

`Uint8Array`

***

### toJSON()

> **toJSON**(): [`JsonnableExpiry`](../type-aliases/JsonnableExpiry.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:75](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L75)

Serializes to JSON

#### Returns

[`JsonnableExpiry`](../type-aliases/JsonnableExpiry.md)

a JSON object with a single key, [JSON\_KEY\_EXPIRY](../variables/JSON_KEY_EXPIRY.md), whose value is the expiry as a string

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/agent/http/transforms.ts:67](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L67)

#### Returns

`string`

***

### fromDeltaInMilliseconds()

> `static` **fromDeltaInMilliseconds**(`deltaInMs`, `clockDriftMs`): `Expiry`

Defined in: [packages/agent/src/agent/http/transforms.ts:44](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L44)

Creates an Expiry object from a delta in milliseconds.
If the delta is less than 90 seconds, the expiry is rounded down to the nearest second.
Otherwise, the expiry is rounded down to the nearest minute.

#### Parameters

##### deltaInMs

`number`

The milliseconds to add to the current time.

##### clockDriftMs

`number` = `0`

The milliseconds to add to the current time, typically the clock drift between IC network clock and the client's clock. Defaults to `0` if not provided.

#### Returns

`Expiry`

The constructed Expiry object.

***

### fromJSON()

> `static` **fromJSON**(`input`): `Expiry`

Defined in: [packages/agent/src/agent/http/transforms.ts:84](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L84)

Deserializes a [JsonnableExpiry](../type-aliases/JsonnableExpiry.md) object from a JSON string.

#### Parameters

##### input

`string`

The JSON string to deserialize.

#### Returns

`Expiry`

The deserialized Expiry object.

***

### isExpiry()

> `static` **isExpiry**(`other`): `other is Expiry`

Defined in: [packages/agent/src/agent/http/transforms.ts:99](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/http/transforms.ts#L99)

#### Parameters

##### other

`unknown`

#### Returns

`other is Expiry`
