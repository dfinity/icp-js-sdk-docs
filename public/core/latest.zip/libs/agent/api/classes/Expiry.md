---
title: Expiry
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/expiry.ts:24](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L24)

## Properties

### \_isExpiry

> `readonly` **\_isExpiry**: `true` = `true`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:25](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L25)

## Methods

### toBigInt()

> **toBigInt**(): `bigint`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:56](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L56)

#### Returns

`bigint`

***

### toHash()

> **toHash**(): `Uint8Array`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:60](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L60)

#### Returns

`Uint8Array`

***

### toJSON()

> **toJSON**(): [`JsonnableExpiry`](../interfaces/JsonnableExpiry.md)

Defined in: [packages/core/src/agent/agent/http/expiry.ts:72](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L72)

Serializes to JSON

#### Returns

[`JsonnableExpiry`](../interfaces/JsonnableExpiry.md)

a JSON object with a single key, [JSON\_KEY\_EXPIRY](../variables/JSON_KEY_EXPIRY.md), whose value is the expiry as a string

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:64](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L64)

#### Returns

`string`

***

### fromDeltaInMilliseconds()

> `static` **fromDeltaInMilliseconds**(`deltaInMs`, `clockDriftInMs?`): `Expiry`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:39](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L39)

Creates an Expiry object from a delta in milliseconds.
The expiry is calculated as: current_time + delta + clock_drift
The resulting expiry is then rounded:
- If rounding down to the nearest minute still provides at least 60 seconds in the future, use minute precision
- Otherwise, use second precision

#### Parameters

##### deltaInMs

`number`

The milliseconds to add to the current time.

##### clockDriftInMs?

`number` = `0`

The milliseconds to add to the current time, typically the clock drift between IC network clock and the client's clock. Defaults to `0` if not provided.

#### Returns

`Expiry`

The constructed Expiry object.

***

### fromJSON()

> `static` **fromJSON**(`input`): `Expiry`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:81](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L81)

Deserializes a [JsonnableExpiry](../interfaces/JsonnableExpiry.md) object from a JSON string.

#### Parameters

##### input

`string`

The JSON string to deserialize.

#### Returns

`Expiry`

The deserialized Expiry object.

***

### isExpiry()

> `static` **isExpiry**(`other`): `other is Expiry`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:96](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/expiry.ts#L96)

#### Parameters

##### other

`unknown`

#### Returns

`other is Expiry`
