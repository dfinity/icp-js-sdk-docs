---
title: ToCborValue
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/cbor.ts:9](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/cbor.ts#L9)

Used to extend classes that need to provide a custom value for the CBOR encoding process.


### Constructor

> **new ToCborValue**(): `ToCborValue`

#### Returns

`ToCborValue`

## Methods

### toCborValue()

> `abstract` **toCborValue**(): `any`

Defined in: [packages/agent/src/cbor.ts:13](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/cbor.ts#L13)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](../variables/Cbor.md#encode) function.

#### Returns

`any`
