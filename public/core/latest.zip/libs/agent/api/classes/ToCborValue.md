---
title: ToCborValue
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/cbor.ts:9](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/cbor.ts#L9)

Used to extend classes that need to provide a custom value for the CBOR encoding process.

## Constructors

### Constructor

> **new ToCborValue**(): `ToCborValue`

#### Returns

`ToCborValue`

## Methods

### toCborValue()

> `abstract` **toCborValue**(): `any`

Defined in: [packages/core/src/agent/cbor.ts:13](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/cbor.ts#L13)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](../variables/Cbor.md#encode) function.

#### Returns

`any`
