---
title: ToCborValue
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/cbor.ts:9](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/cbor.ts#L9)

Used to extend classes that need to provide a custom value for the CBOR encoding process.


### Constructor

> **new ToCborValue**(): `ToCborValue`

#### Returns

`ToCborValue`

## Methods

### toCborValue()

> `abstract` **toCborValue**(): `any`

Defined in: [packages/agent/src/cbor.ts:13](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/cbor.ts#L13)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](../variables/Cbor.md#encode) function.

#### Returns

`any`
