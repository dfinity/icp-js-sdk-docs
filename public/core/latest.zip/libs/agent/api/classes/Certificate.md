---
title: Certificate
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:214](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L214)

## Properties

### cert

> **cert**: [`Cert`](../interfaces/Cert.md)

Defined in: [packages/core/src/agent/certificate.ts:215](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L215)

## Methods

### lookup\_path()

> **lookup\_path**(`path`): [`LookupResult`](../type-aliases/LookupResult.md)

Defined in: [packages/core/src/agent/certificate.ts:276](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L276)

Lookup a path in the certificate tree, using [lookup\_path](../functions/lookup_path.md).

#### Parameters

##### path

[`NodePath`](../type-aliases/NodePath.md)

The path to lookup.

#### Returns

[`LookupResult`](../type-aliases/LookupResult.md)

The result of the lookup.

***

### lookup\_subtree()

> **lookup\_subtree**(`path`): [`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

Defined in: [packages/core/src/agent/certificate.ts:285](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L285)

Lookup a subtree in the certificate tree, using [lookup\_subtree](../functions/lookup_subtree.md).

#### Parameters

##### path

[`NodePath`](../type-aliases/NodePath.md)

The path to lookup.

#### Returns

[`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

The result of the lookup.

***

### create()

> `static` **create**(`options`): `Promise`\<`Certificate`\>

Defined in: [packages/core/src/agent/certificate.ts:226](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L226)

Create a new instance of a certificate, automatically verifying it.

#### Parameters

##### options

[`CreateCertificateOptions`](../interfaces/CreateCertificateOptions.md)

[CreateCertificateOptions](../interfaces/CreateCertificateOptions.md)

#### Returns

`Promise`\<`Certificate`\>

#### Throws

if the verification of the certificate fails
