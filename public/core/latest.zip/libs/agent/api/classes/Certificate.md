---
title: Certificate
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:198](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L198)

## Properties

### cert

> **cert**: [`Cert`](../interfaces/Cert.md)

Defined in: [packages/agent/src/certificate.ts:199](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L199)

## Methods

### lookup\_path()

> **lookup\_path**(`path`): [`LookupResult`](../type-aliases/LookupResult.md)

Defined in: [packages/agent/src/certificate.ts:250](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L250)

Lookup a path in the certificate tree, using [lookup\_path](../functions/lookup_path.md).

#### Parameters

##### path

[`NodePath`](../type-aliases/NodePath.md)

The path to lookup.

#### Returns

[`LookupResult`](../type-aliases/LookupResult.md)

The result of the lookup.

***

### lookup\_subtree()

> **lookup\_subtree**(`path`): [`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:259](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L259)

Lookup a subtree in the certificate tree, using [lookup\_subtree](../functions/lookup_subtree.md).

#### Parameters

##### path

[`NodePath`](../type-aliases/NodePath.md)

The path to lookup.

#### Returns

[`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

The result of the lookup.

***

### create()

> `static` **create**(`options`): `Promise`\<`Certificate`\>

Defined in: [packages/agent/src/certificate.ts:209](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L209)

Create a new instance of a certificate, automatically verifying it.

#### Parameters

##### options

[`CreateCertificateOptions`](../interfaces/CreateCertificateOptions.md)

[CreateCertificateOptions](../interfaces/CreateCertificateOptions.md)

#### Returns

`Promise`\<`Certificate`\>

#### Throws

if the verification of the certificate fails
