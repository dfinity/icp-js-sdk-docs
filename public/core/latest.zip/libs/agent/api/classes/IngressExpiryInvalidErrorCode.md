---
title: IngressExpiryInvalidErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:613](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L613)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new IngressExpiryInvalidErrorCode**(`message`, `providedIngressExpiryInMinutes`): `IngressExpiryInvalidErrorCode`

Defined in: [packages/agent/src/errors.ts:616](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L616)

#### Parameters

##### message

`string`

##### providedIngressExpiryInMinutes

`number`

#### Returns

`IngressExpiryInvalidErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### message

> `readonly` **message**: `string`

Defined in: [packages/agent/src/errors.ts:617](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L617)

***

### name

> **name**: `string` = `'IngressExpiryInvalidErrorCode'`

Defined in: [packages/agent/src/errors.ts:614](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L614)

***

### providedIngressExpiryInMinutes

> `readonly` **providedIngressExpiryInMinutes**: `number`

Defined in: [packages/agent/src/errors.ts:618](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L618)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:624](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L624)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
