---
title: ErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:69](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L69)

## Extended by

- [`CertificateVerificationErrorCode`](CertificateVerificationErrorCode.md)
- [`CertificateTimeErrorCode`](CertificateTimeErrorCode.md)
- [`CertificateHasTooManyDelegationsErrorCode`](CertificateHasTooManyDelegationsErrorCode.md)
- [`CertificateNotAuthorizedErrorCode`](CertificateNotAuthorizedErrorCode.md)
- [`CertificateNotAuthorizedForSubnetErrorCode`](CertificateNotAuthorizedForSubnetErrorCode.md)
- [`LookupErrorCode`](LookupErrorCode.md)
- [`MalformedLookupFoundValueErrorCode`](MalformedLookupFoundValueErrorCode.md)
- [`MissingLookupValueErrorCode`](MissingLookupValueErrorCode.md)
- [`DerKeyLengthMismatchErrorCode`](DerKeyLengthMismatchErrorCode.md)
- [`DerPrefixMismatchErrorCode`](DerPrefixMismatchErrorCode.md)
- [`DerDecodeLengthMismatchErrorCode`](DerDecodeLengthMismatchErrorCode.md)
- [`DerDecodeErrorCode`](DerDecodeErrorCode.md)
- [`DerEncodeErrorCode`](DerEncodeErrorCode.md)
- [`CborDecodeErrorCode`](CborDecodeErrorCode.md)
- [`CborEncodeErrorCode`](CborEncodeErrorCode.md)
- [`HexDecodeErrorCode`](HexDecodeErrorCode.md)
- [`TimeoutWaitingForResponseErrorCode`](TimeoutWaitingForResponseErrorCode.md)
- [`CertificateOutdatedErrorCode`](CertificateOutdatedErrorCode.md)
- [`CertifiedRejectErrorCode`](CertifiedRejectErrorCode.md)
- [`UncertifiedRejectErrorCode`](UncertifiedRejectErrorCode.md)
- [`UncertifiedRejectUpdateErrorCode`](UncertifiedRejectUpdateErrorCode.md)
- [`RequestStatusDoneNoReplyErrorCode`](RequestStatusDoneNoReplyErrorCode.md)
- [`MissingRootKeyErrorCode`](MissingRootKeyErrorCode.md)
- [`HashValueErrorCode`](HashValueErrorCode.md)
- [`IdentityInvalidErrorCode`](IdentityInvalidErrorCode.md)
- [`IngressExpiryInvalidErrorCode`](IngressExpiryInvalidErrorCode.md)
- [`MissingFetchErrorCode`](MissingFetchErrorCode.md)
- [`CreateHttpAgentErrorCode`](CreateHttpAgentErrorCode.md)
- [`ExcessiveSignaturesErrorCode`](ExcessiveSignaturesErrorCode.md)
- [`MalformedSignatureErrorCode`](MalformedSignatureErrorCode.md)
- [`MissingSignatureErrorCode`](MissingSignatureErrorCode.md)
- [`MalformedPublicKeyErrorCode`](MalformedPublicKeyErrorCode.md)
- [`QuerySignatureVerificationFailedErrorCode`](QuerySignatureVerificationFailedErrorCode.md)
- [`UnexpectedErrorCode`](UnexpectedErrorCode.md)
- [`HashTreeDecodeErrorCode`](HashTreeDecodeErrorCode.md)
- [`HttpErrorCode`](HttpErrorCode.md)
- [`HttpV4ApiNotSupportedErrorCode`](HttpV4ApiNotSupportedErrorCode.md)
- [`HttpFetchErrorCode`](HttpFetchErrorCode.md)
- [`MissingCanisterIdErrorCode`](MissingCanisterIdErrorCode.md)
- [`InvalidReadStateRequestErrorCode`](InvalidReadStateRequestErrorCode.md)
- [`ExpiryJsonDeserializeErrorCode`](ExpiryJsonDeserializeErrorCode.md)
- [`InvalidRootKeyErrorCode`](InvalidRootKeyErrorCode.md)
- [`MissingCookieErrorCode`](MissingCookieErrorCode.md)
- [`EmptyCookieErrorCode`](EmptyCookieErrorCode.md)

## Constructors

### Constructor

> **new ErrorCode**(`isCertified?`): `ErrorCode`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L75)

#### Parameters

##### isCertified?

`boolean` = `false`

#### Returns

`ErrorCode`

## Properties

### callContext?

> `optional` **callContext?**: [`CallContext`](../interfaces/CallContext.md) \| [`PollingCallContext`](../interfaces/PollingCallContext.md)

Defined in: [packages/core/src/agent/errors.ts:73](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L73)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L75)

***

### requestContext?

> `optional` **requestContext?**: [`RequestContext`](../interfaces/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:72](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L72)

***

### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](../enumerations/ErrorVerbosity.md) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:70](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L70)

## Methods

### toErrorMessage()

> `abstract` **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L77)

#### Returns

`string`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L79)

#### Returns

`string`
