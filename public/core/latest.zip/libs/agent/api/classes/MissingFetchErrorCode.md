---
title: MissingFetchErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:665](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L665)

## Extends

- [`ErrorCode`](ErrorCode.md)

## Constructors

### Constructor

> **new MissingFetchErrorCode**(): `MissingFetchErrorCode`

Defined in: [packages/core/src/agent/errors.ts:668](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L668)

#### Returns

`MissingFetchErrorCode`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`constructor`](ErrorCode.md#constructor)

## Properties

### callContext?

> `optional` **callContext?**: [`CallContext`](../interfaces/CallContext.md) \| [`PollingCallContext`](../interfaces/PollingCallContext.md)

Defined in: [packages/core/src/agent/errors.ts:73](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L73)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`callContext`](ErrorCode.md#callcontext)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L75)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`isCertified`](ErrorCode.md#iscertified)

***

### name

> **name**: `string` = `'MissingFetchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:666](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L666)

***

### requestContext?

> `optional` **requestContext?**: [`RequestContext`](../interfaces/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:72](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L72)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`requestContext`](ErrorCode.md#requestcontext)

***

### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](../enumerations/ErrorVerbosity.md) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:70](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L70)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`verbosity`](ErrorCode.md#verbosity)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:673](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L673)

#### Returns

`string`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`toErrorMessage`](ErrorCode.md#toerrormessage)

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L79)

#### Returns

`string`

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`toString`](ErrorCode.md#tostring)
