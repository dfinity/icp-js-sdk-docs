---
title: HashValueErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:588](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L588)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new HashValueErrorCode**(`value`): `HashValueErrorCode`

Defined in: [packages/core/src/agent/errors.ts:591](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L591)

#### Parameters

##### value

`unknown`

#### Returns

`HashValueErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/core/src/agent/errors.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L40)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L42)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'HashValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:589](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L589)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L39)

#### Inherited from

`ErrorCode.requestContext`

***

### value

> `readonly` **value**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:591](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L591)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:596](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L596)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L46)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
