---
title: HttpV3ApiNotSupportedErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:745](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L745)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new HttpV3ApiNotSupportedErrorCode**(): `HttpV3ApiNotSupportedErrorCode`

Defined in: [packages/agent/src/errors.ts:748](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L748)

#### Returns

`HttpV3ApiNotSupportedErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'HttpV3ApiNotSupportedErrorCode'`

Defined in: [packages/agent/src/errors.ts:746](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L746)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:753](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L753)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
