---
title: Ed25519PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/public\_key.ts:5](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L5)

A Public Key implementation.

## Implements

- [`PublicKey`](../interfaces/PublicKey.md)

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/agent/src/public\_key.ts:43](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L43)

##### Returns

[`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../interfaces/PublicKey.md).[`derKey`](../interfaces/PublicKey.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/agent/src/public\_key.ts:37](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L37)

##### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../interfaces/PublicKey.md).[`rawKey`](../interfaces/PublicKey.md#rawkey)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/agent/src/public\_key.ts:58](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L58)

#### Returns

[`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../interfaces/PublicKey.md).[`toDer`](../interfaces/PublicKey.md#toder)

***

### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/agent/src/public\_key.ts:62](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L62)

#### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../interfaces/PublicKey.md).[`toRaw`](../interfaces/PublicKey.md#toraw)

***

### from()

> `static` **from**(`key`): `Ed25519PublicKey`

Defined in: [packages/agent/src/public\_key.ts:6](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L6)

#### Parameters

##### key

[`PublicKey`](../interfaces/PublicKey.md)

#### Returns

`Ed25519PublicKey`

***

### fromDer()

> `static` **fromDer**(`derKey`): `Ed25519PublicKey`

Defined in: [packages/agent/src/public\_key.ts:14](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L14)

#### Parameters

##### derKey

[`DerEncodedPublicKey`](../type-aliases/DerEncodedPublicKey.md)

#### Returns

`Ed25519PublicKey`

***

### fromRaw()

> `static` **fromRaw**(`rawKey`): `Ed25519PublicKey`

Defined in: [packages/agent/src/public\_key.ts:10](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/public_key.ts#L10)

#### Parameters

##### rawKey

`Uint8Array`

#### Returns

`Ed25519PublicKey`
