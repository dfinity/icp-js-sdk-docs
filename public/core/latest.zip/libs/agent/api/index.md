---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [CanisterStatus](namespaces/CanisterStatus.md)
- [polling](namespaces/polling.md)
- [strategy](namespaces/strategy.md)
- [SubnetStatus](namespaces/SubnetStatus-1.md)

## Enumerations

### Endpoint

Defined in: [packages/core/src/agent/agent/http/types.ts:8](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L8)

**`Internal`**

#### Enumeration Members

##### Call

> **Call**: `"call"`

Defined in: [packages/core/src/agent/agent/http/types.ts:11](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L11)

##### Query

> **Query**: `"read"`

Defined in: [packages/core/src/agent/agent/http/types.ts:9](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L9)

##### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/core/src/agent/agent/http/types.ts:10](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L10)

***

### ErrorKindEnum

Defined in: [packages/core/src/agent/errors.ts:15](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L15)

#### Enumeration Members

##### External

> **External**: `"External"`

Defined in: [packages/core/src/agent/errors.ts:20](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L20)

##### Input

> **Input**: `"Input"`

Defined in: [packages/core/src/agent/errors.ts:22](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L22)

##### Limit

> **Limit**: `"Limit"`

Defined in: [packages/core/src/agent/errors.ts:21](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L21)

##### Protocol

> **Protocol**: `"Protocol"`

Defined in: [packages/core/src/agent/errors.ts:17](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L17)

##### Reject

> **Reject**: `"Reject"`

Defined in: [packages/core/src/agent/errors.ts:18](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L18)

##### Transport

> **Transport**: `"Transport"`

Defined in: [packages/core/src/agent/errors.ts:19](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L19)

##### Trust

> **Trust**: `"Trust"`

Defined in: [packages/core/src/agent/errors.ts:16](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L16)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/errors.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L23)

***

### ErrorVerbosity

Defined in: [packages/core/src/agent/errors.ts:55](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L55)

Controls the level of detail included in error messages.
- `Normal` (default): includes error message, call context, and HTTP details, but omits large binary fields (arg, certificate, nonce).
- `Verbose`: same as Normal, but includes hex-encoded binary fields.

To enable verbose mode: `ErrorCode.verbosity = ErrorVerbosity.Verbose`

#### Enumeration Members

##### Normal

> **Normal**: `"normal"`

Defined in: [packages/core/src/agent/errors.ts:56](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L56)

##### Verbose

> **Verbose**: `"verbose"`

Defined in: [packages/core/src/agent/errors.ts:57](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L57)

***

### LookupLabelStatus

Defined in: [packages/core/src/agent/certificate.ts:571](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L571)

#### Enumeration Members

##### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:572](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L572)

##### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:574](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L574)

##### Greater

> **Greater**: `"Greater"`

Defined in: [packages/core/src/agent/certificate.ts:576](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L576)

##### Less

> **Less**: `"Less"`

Defined in: [packages/core/src/agent/certificate.ts:575](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L575)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:573](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L573)

***

### LookupPathStatus

Defined in: [packages/core/src/agent/certificate.ts:517](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L517)

#### Enumeration Members

##### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:519](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L519)

##### Error

> **Error**: `"Error"`

Defined in: [packages/core/src/agent/certificate.ts:521](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L521)

##### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:520](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L520)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:518](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L518)

***

### LookupSubtreeStatus

Defined in: [packages/core/src/agent/certificate.ts:547](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L547)

#### Enumeration Members

##### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:548](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L548)

##### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:550](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L550)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:549](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L549)

***

### NodeType

Defined in: [packages/core/src/agent/certificate.ts:47](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L47)

#### Enumeration Members

##### Empty

> **Empty**: `0`

Defined in: [packages/core/src/agent/certificate.ts:48](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L48)

##### Fork

> **Fork**: `1`

Defined in: [packages/core/src/agent/certificate.ts:49](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L49)

##### Labeled

> **Labeled**: `2`

Defined in: [packages/core/src/agent/certificate.ts:50](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L50)

##### Leaf

> **Leaf**: `3`

Defined in: [packages/core/src/agent/certificate.ts:51](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L51)

##### Pruned

> **Pruned**: `4`

Defined in: [packages/core/src/agent/certificate.ts:52](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L52)

***

### QueryResponseStatus

Defined in: [packages/core/src/agent/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L35)

#### Enumeration Members

##### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/api.ts:37](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L37)

##### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L36)

***

### ReadRequestType

Defined in: [packages/core/src/agent/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L78)

#### Enumeration Members

##### Query

> **Query**: `"query"`

Defined in: [packages/core/src/agent/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L79)

##### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/core/src/agent/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L80)

***

### ReplicaRejectCode

Defined in: [packages/core/src/agent/agent/api.ts:12](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L12)

Codes used by the replica for rejecting a message.
See [the interface spec](https://sdk.dfinity.org/docs/interface-spec/#reject-codes).

#### Enumeration Members

##### CanisterError

> **CanisterError**: `5`

Defined in: [packages/core/src/agent/agent/api.ts:17](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L17)

##### CanisterReject

> **CanisterReject**: `4`

Defined in: [packages/core/src/agent/agent/api.ts:16](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L16)

##### DestinationInvalid

> **DestinationInvalid**: `3`

Defined in: [packages/core/src/agent/agent/api.ts:15](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L15)

##### SysFatal

> **SysFatal**: `1`

Defined in: [packages/core/src/agent/agent/api.ts:13](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L13)

##### SysTransient

> **SysTransient**: `2`

Defined in: [packages/core/src/agent/agent/api.ts:14](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L14)

***

### RequestStatusResponseStatus

Defined in: [packages/core/src/agent/agent/http/types.ts:109](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L109)

Possible values for the request status in the IC state tree.

#### See

https://internetcomputer.org/docs/references/ic-interface-spec#state-tree-request-status

#### Enumeration Members

##### Done

> **Done**: `"done"`

Defined in: [packages/core/src/agent/agent/http/types.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L121)

The IC has pruned the response data but remembers the request to prevent replay attacks.

##### Processing

> **Processing**: `"processing"`

Defined in: [packages/core/src/agent/agent/http/types.ts:113](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L113)

The initial effect of the call has happened or will happen.

##### Received

> **Received**: `"received"`

Defined in: [packages/core/src/agent/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L111)

The call has made it past the endpoint into the IC's state.

##### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/http/types.ts:117](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L117)

The call failed; reject code and message are available at `/request_status/<id>/reject_code` and `/request_status/<id>/reject_message`.

##### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/http/types.ts:115](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L115)

The call completed successfully; the reply is available at `/request_status/<id>/reply`.

##### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/core/src/agent/agent/http/types.ts:119](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L119)

The request status path is absent from the state tree, the request is unknown to the IC (never received or pruned after expiry).

***

### SubmitRequestType

Defined in: [packages/core/src/agent/agent/http/types.ts:73](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L73)

#### Enumeration Members

##### Call

> **Call**: `"call"`

Defined in: [packages/core/src/agent/agent/http/types.ts:74](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L74)

## Classes

### Actor

Defined in: [packages/core/src/agent/actor.ts:183](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L183)

An actor base class. An actor is an object containing only functions that will
return a promise. These functions are derived from the IDL definition.

#### Constructors

##### Constructor

> `protected` **new Actor**(`metadata`): [`Actor`](#actor)

Defined in: [packages/core/src/agent/actor.ts:350](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L350)

###### Parameters

###### metadata

`ActorMetadata`

###### Returns

[`Actor`](#actor)

#### Methods

##### agentOf()

> `static` **agentOf**(`actor`): [`Agent`](#agent-1) \| `undefined`

Defined in: [packages/core/src/agent/actor.ts:189](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L189)

Get the Agent class this Actor would call, or undefined if the Actor would use
the default agent (global.ic.agent).

###### Parameters

###### actor

[`Actor`](#actor)

The actor to get the agent of.

###### Returns

[`Agent`](#agent-1) \| `undefined`

##### canisterIdOf()

> `static` **canisterIdOf**(`actor`): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:201](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L201)

###### Parameters

###### actor

[`Actor`](#actor)

###### Returns

[`Principal`](../../principal/api.md#principal)

##### createActor()

> `static` **createActor**\<`T`\>(`interfaceFactory`, `configuration`): [`ActorSubclass`](#actorsubclass)\<`T`\>

Defined in: [packages/core/src/agent/actor.ts:302](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L302)

Creates an actor with the given interface factory and configuration.

The [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package can be used to generate the interface factory for your canister.

###### Type Parameters

###### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\<`unknown`[], `unknown`\>\>

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

the interface factory for the actor, typically generated by the [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package

###### configuration

[`ActorConfig`](#actorconfig)

the configuration for the actor

###### Returns

[`ActorSubclass`](#actorsubclass)\<`T`\>

an actor with the given interface factory and configuration

###### See

The [Canister Environment Guide](https://js.icp.build/core/latest/canister-environment/) for more details on how to configure an actor using the canister environment.

###### Examples

Using the interface factory generated by the [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package:
```ts
import { Actor, HttpAgent } from '@icp-sdk/core/agent';
import { Principal } from '@icp-sdk/core/principal';
import { idlFactory } from './api/declarations/hello-world.did';

// For a convenient way to get the canister ID,
// see the https://js.icp.build/core/latest/canister-environment/ guide.
const canisterId = Principal.fromText('rrkah-fqaaa-aaaaa-aaaaq-cai');

const agent = await HttpAgent.create({
  host: 'https://icp-api.io',
});

const actor = Actor.createActor(idlFactory, {
  agent,
  canisterId,
});

const response = await actor.greet('world');
console.log(response);
```

Using the `createActor` wrapper function generated by the [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package:
```ts
import { HttpAgent } from '@icp-sdk/core/agent';
import { Principal } from '@icp-sdk/core/principal';
import { createActor } from './api/hello-world';

// For a convenient way to get the canister ID,
// see the https://js.icp.build/core/latest/canister-environment/ guide.
const canisterId = Principal.fromText('rrkah-fqaaa-aaaaa-aaaaq-cai');

const agent = await HttpAgent.create({
  host: 'https://icp-api.io',
});

const actor = createActor(canisterId, {
  agent,
});

const response = await actor.greet('world');
console.log(response);
```

##### createActorClass()

> `static` **createActorClass**(`interfaceFactory`, `options?`): [`ActorConstructor`](#actorconstructor-1)

Defined in: [packages/core/src/agent/actor.ts:205](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L205)

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

###### options?

[`CreateActorClassOpts`](#createactorclassopts)

###### Returns

[`ActorConstructor`](#actorconstructor-1)

##### createActorWithExtendedDetails()

> `static` **createActorWithExtendedDetails**\<`T`\>(`interfaceFactory`, `configuration`, `actorClassOptions?`): [`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedExtended`](#actormethodmappedextended)\<`T`\>\>

Defined in: [packages/core/src/agent/actor.ts:335](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L335)

Returns an actor with methods that return the http response details along with the result

###### Type Parameters

###### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\<`unknown`[], `unknown`\>\>

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

the interface factory for the actor

###### configuration

[`ActorConfig`](#actorconfig)

the configuration for the actor

###### actorClassOptions?

[`CreateActorClassOpts`](#createactorclassopts) = `...`

options for the actor class extended details to return with the result

###### Returns

[`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedExtended`](#actormethodmappedextended)\<`T`\>\>

##### ~~createActorWithHttpDetails()~~

> `static` **createActorWithHttpDetails**\<`T`\>(`interfaceFactory`, `configuration`): [`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedWithHttpDetails`](#actormethodmappedwithhttpdetails)\<`T`\>\>

Defined in: [packages/core/src/agent/actor.ts:320](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L320)

Returns an actor with methods that return the http response details along with the result

###### Type Parameters

###### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\<`unknown`[], `unknown`\>\>

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

the interface factory for the actor

###### configuration

[`ActorConfig`](#actorconfig)

the configuration for the actor

###### Returns

[`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedWithHttpDetails`](#actormethodmappedwithhttpdetails)\<`T`\>\>

###### Deprecated

- use createActor with actorClassOptions instead

##### interfaceOf()

> `static` **interfaceOf**(`actor`): [`ServiceClass`](../../candid/api/namespaces/IDL.md#serviceclass)

Defined in: [packages/core/src/agent/actor.ts:197](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L197)

Get the interface of an actor, in the form of an instance of a Service.

###### Parameters

###### actor

[`Actor`](#actor)

The actor to get the interface of.

###### Returns

[`ServiceClass`](../../candid/api/namespaces/IDL.md#serviceclass)

***

### AgentError

Defined in: [packages/core/src/agent/errors.ts:113](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L113)

An error that happens in the Agent. This is the root of all errors and should be used
everywhere in the Agent code (this package).

To know if the error is certified, use the `isCertified` getter.

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new AgentError**(`code`, `kind`): [`AgentError`](#agenterror)

Defined in: [packages/core/src/agent/errors.ts:140](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L140)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

[`AgentError`](#agenterror)

###### Overrides

`Error.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Overrides

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string` = `'AgentError'`

Defined in: [packages/core/src/agent/errors.ts:114](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L114)

###### Overrides

`Error.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### AnonymousIdentity

Defined in: [packages/core/src/agent/auth.ts:101](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L101)

A General Identity object. This does not have to be a private key (for example,
the Anonymous identity), but it must be able to transform request.

#### Implements

- [`Identity`](#identity-1)

#### Constructors

##### Constructor

> **new AnonymousIdentity**(): [`AnonymousIdentity`](#anonymousidentity)

###### Returns

[`AnonymousIdentity`](#anonymousidentity)

#### Methods

##### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/auth.ts:102](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L102)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

###### Returns

[`Principal`](../../principal/api.md#principal)

###### Implementation of

[`Identity`](#identity-1).[`getPrincipal`](#getprincipal-4)

##### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:106](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L106)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

###### Returns

`Promise`\<`unknown`\>

###### Implementation of

[`Identity`](#identity-1).[`transformRequest`](#transformrequest-2)

***

### CborDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:433](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L433)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CborDecodeErrorCode**(`error`, `input`): [`CborDecodeErrorCode`](#cbordecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:436](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L436)

###### Parameters

###### error

`unknown`

###### input

`Uint8Array`

###### Returns

[`CborDecodeErrorCode`](#cbordecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:437](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L437)

##### input

> `readonly` **input**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:438](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L438)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CborDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:434](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L434)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:444](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L444)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CborEncodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:449](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L449)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CborEncodeErrorCode**(`error`, `value`): [`CborEncodeErrorCode`](#cborencodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:452](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L452)

###### Parameters

###### error

`unknown`

###### value

`unknown`

###### Returns

[`CborEncodeErrorCode`](#cborencodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:453](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L453)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CborEncodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:450](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L450)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### value

> `readonly` **value**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:454](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L454)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:460](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L460)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### Certificate

Defined in: [packages/core/src/agent/certificate.ts:212](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L212)

#### Properties

##### cert

> **cert**: [`Cert`](#cert-1)

Defined in: [packages/core/src/agent/certificate.ts:213](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L213)

#### Methods

##### lookup\_path()

> **lookup\_path**(`path`): [`LookupResult`](#lookupresult)

Defined in: [packages/core/src/agent/certificate.ts:274](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L274)

Lookup a path in the certificate tree, using [lookup\_path](#lookup_path-1).

###### Parameters

###### path

[`NodePath`](#nodepath)

The path to lookup.

###### Returns

[`LookupResult`](#lookupresult)

The result of the lookup.

##### lookup\_subtree()

> **lookup\_subtree**(`path`): [`SubtreeLookupResult`](#subtreelookupresult)

Defined in: [packages/core/src/agent/certificate.ts:283](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L283)

Lookup a subtree in the certificate tree, using [lookup\_subtree](#lookup_subtree-1).

###### Parameters

###### path

[`NodePath`](#nodepath)

The path to lookup.

###### Returns

[`SubtreeLookupResult`](#subtreelookupresult)

The result of the lookup.

##### create()

> `static` **create**(`options`): `Promise`\<[`Certificate`](#certificate)\>

Defined in: [packages/core/src/agent/certificate.ts:224](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L224)

Create a new instance of a certificate, automatically verifying it.

###### Parameters

###### options

[`CreateCertificateOptions`](#createcertificateoptions)

[CreateCertificateOptions](#createcertificateoptions)

###### Returns

`Promise`\<[`Certificate`](#certificate)\>

###### Throws

if the verification of the certificate fails

***

### CertificateHasTooManyDelegationsErrorCode

Defined in: [packages/core/src/agent/errors.ts:275](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L275)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateHasTooManyDelegationsErrorCode**(): [`CertificateHasTooManyDelegationsErrorCode`](#certificatehastoomanydelegationserrorcode)

Defined in: [packages/core/src/agent/errors.ts:278](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L278)

###### Returns

[`CertificateHasTooManyDelegationsErrorCode`](#certificatehastoomanydelegationserrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CertificateHasTooManyDelegationsErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:276](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L276)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:283](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L283)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CertificateNotAuthorizedErrorCode

Defined in: [packages/core/src/agent/errors.ts:288](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L288)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateNotAuthorizedErrorCode**(`canisterId`, `subnetId`): [`CertificateNotAuthorizedErrorCode`](#certificatenotauthorizederrorcode)

Defined in: [packages/core/src/agent/errors.ts:291](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L291)

###### Parameters

###### canisterId

[`Principal`](../../principal/api.md#principal)

###### subnetId

[`Principal`](../../principal/api.md#principal)

###### Returns

[`CertificateNotAuthorizedErrorCode`](#certificatenotauthorizederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### canisterId

> `readonly` **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:292](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L292)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CertificateNotAuthorizedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:289](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L289)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### subnetId

> `readonly` **subnetId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L293)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:299](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L299)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CertificateNotAuthorizedForSubnetErrorCode

Defined in: [packages/core/src/agent/errors.ts:304](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L304)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateNotAuthorizedForSubnetErrorCode**(`subnetId`): [`CertificateNotAuthorizedForSubnetErrorCode`](#certificatenotauthorizedforsubneterrorcode)

Defined in: [packages/core/src/agent/errors.ts:307](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L307)

###### Parameters

###### subnetId

[`Principal`](../../principal/api.md#principal)

###### Returns

[`CertificateNotAuthorizedForSubnetErrorCode`](#certificatenotauthorizedforsubneterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CertificateNotAuthorizedForSubnetErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:305](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L305)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### subnetId

> `readonly` **subnetId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:307](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L307)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:312](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L312)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CertificateOutdatedErrorCode

Defined in: [packages/core/src/agent/errors.ts:502](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L502)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateOutdatedErrorCode**(`maxIngressExpiryInMinutes`, `requestId`, `retryTimes?`): [`CertificateOutdatedErrorCode`](#certificateoutdatederrorcode)

Defined in: [packages/core/src/agent/errors.ts:505](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L505)

###### Parameters

###### maxIngressExpiryInMinutes

`number`

###### requestId

[`RequestId`](#requestid-9)

###### retryTimes?

`number`

###### Returns

[`CertificateOutdatedErrorCode`](#certificateoutdatederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### maxIngressExpiryInMinutes

> `readonly` **maxIngressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:506](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L506)

##### name

> **name**: `string` = `'CertificateOutdatedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:503](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L503)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:507](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L507)

##### retryTimes?

> `readonly` `optional` **retryTimes?**: `number`

Defined in: [packages/core/src/agent/errors.ts:508](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L508)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:514](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L514)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CertificateTimeErrorCode

Defined in: [packages/core/src/agent/errors.ts:256](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L256)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateTimeErrorCode**(`maxAgeInMinutes`, `certificateTime`, `currentTime`, `timeDiffMsecs`, `ageType`): [`CertificateTimeErrorCode`](#certificatetimeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:259](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L259)

###### Parameters

###### maxAgeInMinutes

`number`

###### certificateTime

`Date`

###### currentTime

`Date`

###### timeDiffMsecs

`number`

###### ageType

`"past"` \| `"future"`

###### Returns

[`CertificateTimeErrorCode`](#certificatetimeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### ageType

> `readonly` **ageType**: `"past"` \| `"future"`

Defined in: [packages/core/src/agent/errors.ts:264](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L264)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### certificateTime

> `readonly` **certificateTime**: `Date`

Defined in: [packages/core/src/agent/errors.ts:261](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L261)

##### currentTime

> `readonly` **currentTime**: `Date`

Defined in: [packages/core/src/agent/errors.ts:262](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L262)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### maxAgeInMinutes

> `readonly` **maxAgeInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L260)

##### name

> **name**: `string` = `'CertificateTimeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:257](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L257)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### timeDiffMsecs

> `readonly` **timeDiffMsecs**: `number`

Defined in: [packages/core/src/agent/errors.ts:263](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L263)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:270](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L270)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CertificateVerificationErrorCode

Defined in: [packages/core/src/agent/errors.ts:236](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L236)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateVerificationErrorCode**(`reason`, `error?`): [`CertificateVerificationErrorCode`](#certificateverificationerrorcode)

Defined in: [packages/core/src/agent/errors.ts:239](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L239)

###### Parameters

###### reason

`string`

###### error?

`unknown`

###### Returns

[`CertificateVerificationErrorCode`](#certificateverificationerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error?

> `readonly` `optional` **error?**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:241](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L241)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CertificateVerificationErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:237](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L237)

##### reason

> `readonly` **reason**: `string`

Defined in: [packages/core/src/agent/errors.ts:240](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L240)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:247](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L247)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CertifiedRejectErrorCode

Defined in: [packages/core/src/agent/errors.ts:523](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L523)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertifiedRejectErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`): [`CertifiedRejectErrorCode`](#certifiedrejecterrorcode)

Defined in: [packages/core/src/agent/errors.ts:526](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L526)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### rejectCode

[`ReplicaRejectCode`](#replicarejectcode)

###### rejectMessage

`string`

###### rejectErrorCode

`string` \| `undefined`

###### Returns

[`CertifiedRejectErrorCode`](#certifiedrejecterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CertifiedRejectErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:524](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L524)

##### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/errors.ts:528](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L528)

##### rejectErrorCode

> `readonly` **rejectErrorCode**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:530](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L530)

##### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:529](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L529)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:527](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L527)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:536](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L536)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### CreateHttpAgentErrorCode

Defined in: [packages/core/src/agent/errors.ts:683](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L683)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CreateHttpAgentErrorCode**(): [`CreateHttpAgentErrorCode`](#createhttpagenterrorcode)

Defined in: [packages/core/src/agent/errors.ts:686](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L686)

###### Returns

[`CreateHttpAgentErrorCode`](#createhttpagenterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'CreateHttpAgentErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:684](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L684)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:691](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L691)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### DerDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:407](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L407)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerDecodeErrorCode**(`error`): [`DerDecodeErrorCode`](#derdecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:410](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L410)

###### Parameters

###### error

`string`

###### Returns

[`DerDecodeErrorCode`](#derdecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:410](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L410)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'DerDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:408](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L408)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:415](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L415)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### DerDecodeLengthMismatchErrorCode

Defined in: [packages/core/src/agent/errors.ts:391](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L391)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerDecodeLengthMismatchErrorCode**(`expectedLength`, `actualLength`): [`DerDecodeLengthMismatchErrorCode`](#derdecodelengthmismatcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:394](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L394)

###### Parameters

###### expectedLength

`number`

###### actualLength

`number`

###### Returns

[`DerDecodeLengthMismatchErrorCode`](#derdecodelengthmismatcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### actualLength

> `readonly` **actualLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:396](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L396)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:395](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L395)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'DerDecodeLengthMismatchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:392](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L392)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:402](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L402)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### DerEncodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:420](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L420)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerEncodeErrorCode**(`error`): [`DerEncodeErrorCode`](#derencodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:423](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L423)

###### Parameters

###### error

`string`

###### Returns

[`DerEncodeErrorCode`](#derencodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:423](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L423)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'DerEncodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:421](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L421)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:428](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L428)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### DerKeyLengthMismatchErrorCode

Defined in: [packages/core/src/agent/errors.ts:359](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L359)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerKeyLengthMismatchErrorCode**(`expectedLength`, `actualLength`): [`DerKeyLengthMismatchErrorCode`](#derkeylengthmismatcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:362](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L362)

###### Parameters

###### expectedLength

`number`

###### actualLength

`number`

###### Returns

[`DerKeyLengthMismatchErrorCode`](#derkeylengthmismatcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### actualLength

> `readonly` **actualLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:364](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L364)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:363](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L363)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'DerKeyLengthMismatchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:360](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L360)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:370](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L370)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### DerPrefixMismatchErrorCode

Defined in: [packages/core/src/agent/errors.ts:375](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L375)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerPrefixMismatchErrorCode**(`expectedPrefix`, `actualPrefix`): [`DerPrefixMismatchErrorCode`](#derprefixmismatcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:378](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L378)

###### Parameters

###### expectedPrefix

`Uint8Array`

###### actualPrefix

`Uint8Array`

###### Returns

[`DerPrefixMismatchErrorCode`](#derprefixmismatcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### actualPrefix

> `readonly` **actualPrefix**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:380](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L380)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### expectedPrefix

> `readonly` **expectedPrefix**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:379](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L379)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'DerPrefixMismatchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:376](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L376)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:386](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L386)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### Ed25519PublicKey

Defined in: [packages/core/src/agent/public\_key.ts:5](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L5)

A Public Key implementation.

#### Implements

- [`PublicKey`](#publickey-1)

#### Accessors

##### derKey

###### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/public\_key.ts:43](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L43)

###### Returns

[`DerEncodedPublicKey`](#derencodedpublickey)

###### Implementation of

[`PublicKey`](#publickey-1).[`derKey`](#derkey-1)

##### rawKey

###### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/core/src/agent/public\_key.ts:37](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L37)

###### Returns

`Uint8Array`

###### Implementation of

[`PublicKey`](#publickey-1).[`rawKey`](#rawkey-1)

#### Methods

##### toDer()

> **toDer**(): [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/public\_key.ts:58](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L58)

###### Returns

[`DerEncodedPublicKey`](#derencodedpublickey)

###### Implementation of

[`PublicKey`](#publickey-1).[`toDer`](#toder-1)

##### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/agent/public\_key.ts:62](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L62)

###### Returns

`Uint8Array`

###### Implementation of

[`PublicKey`](#publickey-1).[`toRaw`](#toraw-1)

##### from()

> `static` **from**(`key`): [`Ed25519PublicKey`](#ed25519publickey)

Defined in: [packages/core/src/agent/public\_key.ts:6](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L6)

###### Parameters

###### key

[`PublicKey`](#publickey-1)

###### Returns

[`Ed25519PublicKey`](#ed25519publickey)

##### fromDer()

> `static` **fromDer**(`derKey`): [`Ed25519PublicKey`](#ed25519publickey)

Defined in: [packages/core/src/agent/public\_key.ts:14](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L14)

###### Parameters

###### derKey

[`DerEncodedPublicKey`](#derencodedpublickey)

###### Returns

[`Ed25519PublicKey`](#ed25519publickey)

##### fromRaw()

> `static` **fromRaw**(`rawKey`): [`Ed25519PublicKey`](#ed25519publickey)

Defined in: [packages/core/src/agent/public\_key.ts:10](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/public_key.ts#L10)

###### Parameters

###### rawKey

`Uint8Array`

###### Returns

[`Ed25519PublicKey`](#ed25519publickey)

***

### EmptyCookieErrorCode

Defined in: [packages/core/src/agent/errors.ts:933](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L933)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new EmptyCookieErrorCode**(`expectedCookieName`): [`EmptyCookieErrorCode`](#emptycookieerrorcode)

Defined in: [packages/core/src/agent/errors.ts:936](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L936)

###### Parameters

###### expectedCookieName

`string`

###### Returns

[`EmptyCookieErrorCode`](#emptycookieerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### expectedCookieName

> `readonly` **expectedCookieName**: `string`

Defined in: [packages/core/src/agent/errors.ts:936](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L936)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'EmptyCookieErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:934](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L934)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:941](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L941)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### `abstract` ErrorCode

Defined in: [packages/core/src/agent/errors.ts:74](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L74)

#### Extended by

- [`CertificateVerificationErrorCode`](#certificateverificationerrorcode)
- [`CertificateTimeErrorCode`](#certificatetimeerrorcode)
- [`CertificateHasTooManyDelegationsErrorCode`](#certificatehastoomanydelegationserrorcode)
- [`CertificateNotAuthorizedErrorCode`](#certificatenotauthorizederrorcode)
- [`CertificateNotAuthorizedForSubnetErrorCode`](#certificatenotauthorizedforsubneterrorcode)
- [`LookupErrorCode`](#lookuperrorcode)
- [`MalformedLookupFoundValueErrorCode`](#malformedlookupfoundvalueerrorcode)
- [`MissingLookupValueErrorCode`](#missinglookupvalueerrorcode)
- [`DerKeyLengthMismatchErrorCode`](#derkeylengthmismatcherrorcode)
- [`DerPrefixMismatchErrorCode`](#derprefixmismatcherrorcode)
- [`DerDecodeLengthMismatchErrorCode`](#derdecodelengthmismatcherrorcode)
- [`DerDecodeErrorCode`](#derdecodeerrorcode)
- [`DerEncodeErrorCode`](#derencodeerrorcode)
- [`CborDecodeErrorCode`](#cbordecodeerrorcode)
- [`CborEncodeErrorCode`](#cborencodeerrorcode)
- [`HexDecodeErrorCode`](#hexdecodeerrorcode)
- [`TimeoutWaitingForResponseErrorCode`](#timeoutwaitingforresponseerrorcode)
- [`CertificateOutdatedErrorCode`](#certificateoutdatederrorcode)
- [`CertifiedRejectErrorCode`](#certifiedrejecterrorcode)
- [`UncertifiedRejectErrorCode`](#uncertifiedrejecterrorcode)
- [`UncertifiedRejectUpdateErrorCode`](#uncertifiedrejectupdateerrorcode)
- [`RequestStatusDoneNoReplyErrorCode`](#requeststatusdonenoreplyerrorcode)
- [`MissingRootKeyErrorCode`](#missingrootkeyerrorcode)
- [`HashValueErrorCode`](#hashvalueerrorcode)
- [`IdentityInvalidErrorCode`](#identityinvaliderrorcode)
- [`IngressExpiryInvalidErrorCode`](#ingressexpiryinvaliderrorcode)
- [`MissingFetchErrorCode`](#missingfetcherrorcode)
- [`CreateHttpAgentErrorCode`](#createhttpagenterrorcode)
- [`ExcessiveSignaturesErrorCode`](#excessivesignatureserrorcode)
- [`MalformedSignatureErrorCode`](#malformedsignatureerrorcode)
- [`MissingSignatureErrorCode`](#missingsignatureerrorcode)
- [`MalformedPublicKeyErrorCode`](#malformedpublickeyerrorcode)
- [`QuerySignatureVerificationFailedErrorCode`](#querysignatureverificationfailederrorcode)
- [`UnexpectedErrorCode`](#unexpectederrorcode)
- [`UnexpectedV4StatusErrorCode`](#unexpectedv4statuserrorcode)
- [`HashTreeDecodeErrorCode`](#hashtreedecodeerrorcode)
- [`HttpErrorCode`](#httperrorcode)
- [`HttpV4ApiNotSupportedErrorCode`](#httpv4apinotsupportederrorcode)
- [`HttpFetchErrorCode`](#httpfetcherrorcode)
- [`MissingCanisterIdErrorCode`](#missingcanisteriderrorcode)
- [`InvalidReadStateRequestErrorCode`](#invalidreadstaterequesterrorcode)
- [`ExpiryJsonDeserializeErrorCode`](#expiryjsondeserializeerrorcode)
- [`InvalidRootKeyErrorCode`](#invalidrootkeyerrorcode)
- [`MissingCookieErrorCode`](#missingcookieerrorcode)
- [`EmptyCookieErrorCode`](#emptycookieerrorcode)

#### Constructors

##### Constructor

> **new ErrorCode**(`isCertified?`): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Parameters

###### isCertified?

`boolean` = `false`

###### Returns

[`ErrorCode`](#abstract-errorcode)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

#### Methods

##### toErrorMessage()

> `abstract` **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:82](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L82)

###### Returns

`string`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

***

### ExcessiveSignaturesErrorCode

Defined in: [packages/core/src/agent/errors.ts:696](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L696)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new ExcessiveSignaturesErrorCode**(`signatureCount`, `maxExpected`): [`ExcessiveSignaturesErrorCode`](#excessivesignatureserrorcode)

Defined in: [packages/core/src/agent/errors.ts:699](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L699)

###### Parameters

###### signatureCount

`number`

###### maxExpected

`number`

###### Returns

[`ExcessiveSignaturesErrorCode`](#excessivesignatureserrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### maxExpected

> `readonly` **maxExpected**: `number`

Defined in: [packages/core/src/agent/errors.ts:701](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L701)

##### name

> **name**: `string` = `'ExcessiveSignaturesErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:697](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L697)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### signatureCount

> `readonly` **signatureCount**: `number`

Defined in: [packages/core/src/agent/errors.ts:700](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L700)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:707](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L707)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### Expiry

Defined in: [packages/core/src/agent/agent/http/expiry.ts:24](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L24)

#### Properties

##### \_isExpiry

> `readonly` **\_isExpiry**: `true` = `true`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:25](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L25)

#### Methods

##### toBigInt()

> **toBigInt**(): `bigint`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:56](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L56)

###### Returns

`bigint`

##### toHash()

> **toHash**(): `Uint8Array`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:60](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L60)

###### Returns

`Uint8Array`

##### toJSON()

> **toJSON**(): [`JsonnableExpiry`](#jsonnableexpiry)

Defined in: [packages/core/src/agent/agent/http/expiry.ts:72](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L72)

Serializes to JSON

###### Returns

[`JsonnableExpiry`](#jsonnableexpiry)

a JSON object with a single key, [JSON\_KEY\_EXPIRY](#json_key_expiry), whose value is the expiry as a string

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:64](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L64)

###### Returns

`string`

##### fromDeltaInMilliseconds()

> `static` **fromDeltaInMilliseconds**(`deltaInMs`, `clockDriftInMs?`): [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/expiry.ts:39](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L39)

Creates an Expiry object from a delta in milliseconds.
The expiry is calculated as: current_time + delta + clock_drift
The resulting expiry is then rounded:
- If rounding down to the nearest minute still provides at least 60 seconds in the future, use minute precision
- Otherwise, use second precision

###### Parameters

###### deltaInMs

`number`

The milliseconds to add to the current time.

###### clockDriftInMs?

`number` = `0`

The milliseconds to add to the current time, typically the clock drift between IC network clock and the client's clock. Defaults to `0` if not provided.

###### Returns

[`Expiry`](#expiry)

The constructed Expiry object.

##### fromJSON()

> `static` **fromJSON**(`input`): [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/expiry.ts:81](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L81)

Deserializes a [JsonnableExpiry](#jsonnableexpiry) object from a JSON string.

###### Parameters

###### input

`string`

The JSON string to deserialize.

###### Returns

[`Expiry`](#expiry)

The deserialized Expiry object.

##### isExpiry()

> `static` **isExpiry**(`other`): `other is Expiry`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:96](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L96)

###### Parameters

###### other

`unknown`

###### Returns

`other is Expiry`

***

### ExpiryJsonDeserializeErrorCode

Defined in: [packages/core/src/agent/errors.ts:891](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L891)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new ExpiryJsonDeserializeErrorCode**(`error`): [`ExpiryJsonDeserializeErrorCode`](#expiryjsondeserializeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:894](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L894)

###### Parameters

###### error

`string`

###### Returns

[`ExpiryJsonDeserializeErrorCode`](#expiryjsondeserializeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:894](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L894)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'ExpiryJsonDeserializeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:892](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L892)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:899](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L899)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### ExternalError

Defined in: [packages/core/src/agent/errors.ts:200](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L200)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new ExternalError**(`code`): [`ExternalError`](#externalerror)

Defined in: [packages/core/src/agent/errors.ts:203](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L203)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`ExternalError`](#externalerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'ExternalError'`

Defined in: [packages/core/src/agent/errors.ts:201](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L201)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### HashTreeDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:801](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L801)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HashTreeDecodeErrorCode**(`error`): [`HashTreeDecodeErrorCode`](#hashtreedecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:804](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L804)

###### Parameters

###### error

`string`

###### Returns

[`HashTreeDecodeErrorCode`](#hashtreedecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:804](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L804)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'HashTreeDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:802](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L802)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:809](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L809)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### HashValueErrorCode

Defined in: [packages/core/src/agent/errors.ts:628](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L628)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HashValueErrorCode**(`value`): [`HashValueErrorCode`](#hashvalueerrorcode)

Defined in: [packages/core/src/agent/errors.ts:631](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L631)

###### Parameters

###### value

`unknown`

###### Returns

[`HashValueErrorCode`](#hashvalueerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'HashValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:629](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L629)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### value

> `readonly` **value**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:631](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L631)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:636](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L636)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### HexDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:465](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L465)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HexDecodeErrorCode**(`error`): [`HexDecodeErrorCode`](#hexdecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:468](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L468)

###### Parameters

###### error

`string`

###### Returns

[`HexDecodeErrorCode`](#hexdecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:468](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L468)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'HexDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:466](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L466)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:473](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L473)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### HttpAgent

Defined in: [packages/core/src/agent/agent/http/index.ts:269](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L269)

A HTTP agent allows users to interact with a client of the internet computer
using the available methods. It exposes an API that closely follows the
public view of the internet computer, and is not intended to be exposed
directly to the majority of users due to its low-level interface.
There is a pipeline to apply transformations to the request before sending
it to the client. This is to decouple signature, nonce generation and
other computations so that this class can stay as simple as possible while
allowing extensions.

#### Implements

- [`Agent`](#agent-1)

#### Constructors

##### Constructor

> **new HttpAgent**(`options?`): [`HttpAgent`](#httpagent)

Defined in: [packages/core/src/agent/agent/http/index.ts:311](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L311)

###### Parameters

###### options?

[`HttpAgentOptions`](#httpagentoptions) = `{}`

Options for the HttpAgent

###### Returns

[`HttpAgent`](#httpagent)

###### Deprecated

Use `HttpAgent.create` or `HttpAgent.createSync` instead

#### Properties

##### \_isAgent

> `readonly` **\_isAgent**: `true` = `true`

Defined in: [packages/core/src/agent/agent/http/index.ts:294](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L294)

##### config

> **config**: [`HttpAgentOptions`](#httpagentoptions) = `{}`

Defined in: [packages/core/src/agent/agent/http/index.ts:295](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L295)

##### host

> `readonly` **host**: `URL`

Defined in: [packages/core/src/agent/agent/http/index.ts:283](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L283)

##### log

> **log**: [`ObservableLog`](#observablelog)

Defined in: [packages/core/src/agent/agent/http/index.ts:297](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L297)

##### rootKey

> **rootKey**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/core/src/agent/agent/http/index.ts:270](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L270)

###### Implementation of

[`Agent`](#agent-1).[`rootKey`](#rootkey-2)

#### Methods

##### \_transform()

> `protected` **\_transform**(`request`): `Promise`\<[`HttpAgentRequest`](#httpagentrequest)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1668](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1668)

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

###### Returns

`Promise`\<[`HttpAgentRequest`](#httpagentrequest)\>

##### addTransform()

> **addTransform**(`type`, `fn`, `priority?`): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:444](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L444)

###### Parameters

###### type

`"query"` \| `"update"`

###### fn

[`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

###### priority?

`number` = `...`

###### Returns

`void`

##### call()

> **call**(`canisterId`, `options`, `identity?`): `Promise`\<[`SubmitResponse`](#submitresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:482](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L482)

Makes a call to a canister method.

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The ID of the canister to call. Can be a Principal or a string.

###### options

[`CallOptions`](#calloptions)

Options for the call.

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

(Optional) The identity to use for the call. If not provided, the agent's current identity will be used.

###### Returns

`Promise`\<[`SubmitResponse`](#submitresponse)\>

A promise that resolves to the response of the call, including the request ID and response details.

###### Implementation of

[`Agent`](#agent-1).[`call`](#call-3)

##### createReadStateRequest()

> **createReadStateRequest**(`fields`, `identity?`): `Promise`\<`any`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1203](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1203)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

###### Parameters

###### fields

[`ReadStateOptions`](#readstateoptions)

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

###### Returns

`Promise`\<`any`\>

###### Implementation of

[`Agent`](#agent-1).[`createReadStateRequest`](#createreadstaterequest-1)

##### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1537](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1537)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

###### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

###### Implementation of

[`Agent`](#agent-1).[`fetchRootKey`](#fetchrootkey-1)

##### fetchSubnetKeys()

> **fetchSubnetKeys**(`canisterId`): `Promise`\<`SubnetNodeKeys`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1587](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1587)

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

###### Returns

`Promise`\<`SubnetNodeKeys`\>

##### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../principal/api.md#principal)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:468](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L468)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

###### Returns

`Promise`\<[`Principal`](../../principal/api.md#principal)\>

###### Implementation of

[`Agent`](#agent-1).[`getPrincipal`](#getprincipal-3)

##### getSubnetIdFromCanister()

> **getSubnetIdFromCanister**(`canisterId`): `Promise`\<[`Principal`](../../principal/api.md#principal)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1651](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1651)

Returns the subnet ID for a given canister ID, by looking at the certificate delegation
returned by the canister's state obtained by requesting the `/time` path with [readState](#readstate-2).

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The canister ID to get the subnet ID for.

###### Returns

`Promise`\<[`Principal`](../../principal/api.md#principal)\>

The subnet ID for the given canister ID.

##### getTimeDiffMsecs()

> **getTimeDiffMsecs**(): `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:1689](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1689)

Returns the time difference in milliseconds between the IC network clock and the client's clock,
after the clock has been synced.

If the time has not been synced, returns `0`.

###### Returns

`number`

##### hasSyncedTime()

> **hasSyncedTime**(): `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:1696](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1696)

Returns `true` if the time has been synced at least once with the IC network, `false` otherwise.

###### Returns

`boolean`

##### invalidateIdentity()

> **invalidateIdentity**(): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:1579](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1579)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

###### Returns

`void`

###### Implementation of

[`Agent`](#agent-1).[`invalidateIdentity`](#invalidateidentity-1)

##### isLocal()

> **isLocal**(): `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:439](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L439)

###### Returns

`boolean`

##### parseTimeFromResponse()

> **parseTimeFromResponse**(`response`): `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:1358](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1358)

###### Parameters

###### response

###### certificate

`Uint8Array`

###### Returns

`number`

##### query()

> **query**(`canisterId`, `fields`, `identity?`): `Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1016](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1016)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

###### fields

[`QueryFields`](#queryfields)

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

Sender principal to use when sending the query.

###### Returns

`Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

###### Implementation of

[`Agent`](#agent-1).[`query`](#query-3)

##### readState()

> **readState**(`canisterId`, `fields`, `_identity?`, `request?`): `Promise`\<[`ReadStateResponse`](#readstateresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1239](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1239)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

###### fields

[`ReadStateOptions`](#readstateoptions)

###### \_identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

###### request?

`any`

The request to send in case it has already been created.

###### Returns

`Promise`\<[`ReadStateResponse`](#readstateresponse)\>

###### Implementation of

[`Agent`](#agent-1).[`readState`](#readstate-3)

##### readSubnetState()

> **readSubnetState**(`subnetId`, `options`): `Promise`\<[`ReadStateResponse`](#readstateresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1289](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1289)

Reads the state of a subnet from the `/api/v3/subnet/{subnetId}/read_state` endpoint.

###### Parameters

###### subnetId

`string` \| [`Principal`](../../principal/api.md#principal)

The ID of the subnet to read the state of. If you have a canister ID, you can use [getSubnetIdFromCanister](#getsubnetidfromcanister) to get the subnet ID.

###### options

[`ReadStateOptions`](#readstateoptions)

The options for the read state request.

###### Returns

`Promise`\<[`ReadStateResponse`](#readstateresponse)\>

The response from the read state request.

##### replaceIdentity()

> **replaceIdentity**(`identity`): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:1583](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1583)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@icp-sdk/auth/client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

###### Parameters

###### identity

[`Identity`](#identity-1)

###### Returns

`void`

###### Implementation of

[`Agent`](#agent-1).[`replaceIdentity`](#replaceidentity-1)

##### status()

> **status**(): `Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1518](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1518)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

###### Returns

`Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.

###### Implementation of

[`Agent`](#agent-1).[`status`](#status-4)

##### syncTime()

> **syncTime**(`canisterIdOverride?`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1398](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1398)

Allows agent to sync its time with the network. Can be called during initialization or mid-lifecycle if the device's clock has drifted away from the network time. This is necessary to set the Expiry for a request

###### Parameters

###### canisterIdOverride?

[`Principal`](../../principal/api.md#principal)

Pass a canister ID if you need to sync the time with a particular subnet. Uses the ICP ledger canister by default.

###### Returns

`Promise`\<`void`\>

##### syncTimeWithSubnet()

> **syncTimeWithSubnet**(`subnetId`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1461](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1461)

Allows agent to sync its time with the network.

###### Parameters

###### subnetId

[`Principal`](../../principal/api.md#principal)

Pass the subnet ID you need to sync the time with.

###### Returns

`Promise`\<`void`\>

##### update()

> **update**(`canisterId`, `fields`, `pollingOptions?`): `Promise`\<[`UpdateResult`](#updateresult)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:649](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L649)

Executes an update call to a canister and returns the certified result.

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The canister to call.

###### fields

[`UpdateOptions`](#updateoptions)

The call options (method name, arg, effective canister ID, optional nonce).

###### pollingOptions?

[`PollingOptions`](#pollingoptions-2) = `{}`

Optional polling configuration.

###### Returns

`Promise`\<[`UpdateResult`](#updateresult)\>

The certified result including the certificate, reply bytes, and raw certificate bytes.

###### Implementation of

[`Agent`](#agent-1).[`update`](#update-1)

##### create()

> `static` **create**(`options?`): `Promise`\<[`HttpAgent`](#httpagent)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:414](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L414)

###### Parameters

###### options?

[`HttpAgentOptions`](#httpagentoptions) = `{}`

###### Returns

`Promise`\<[`HttpAgent`](#httpagent)\>

##### createSync()

> `static` **createSync**(`options?`): [`HttpAgent`](#httpagent)

Defined in: [packages/core/src/agent/agent/http/index.ts:410](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L410)

###### Parameters

###### options?

[`HttpAgentOptions`](#httpagentoptions) = `{}`

###### Returns

[`HttpAgent`](#httpagent)

##### from()

> `static` **from**(`agent`): `Promise`\<[`HttpAgent`](#httpagent)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:420](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L420)

###### Parameters

###### agent

`V1HttpAgentInterface` \| `Pick`\<[`HttpAgent`](#httpagent), `"config"`\>

###### Returns

`Promise`\<[`HttpAgent`](#httpagent)\>

***

### HttpErrorCode

Defined in: [packages/core/src/agent/errors.ts:814](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L814)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HttpErrorCode**(`status`, `statusText`, `headers`, `bodyText?`): [`HttpErrorCode`](#httperrorcode)

Defined in: [packages/core/src/agent/errors.ts:817](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L817)

###### Parameters

###### status

`number`

###### statusText

`string`

###### headers

[`HttpHeaderField`](#httpheaderfield)[]

###### bodyText?

`string`

###### Returns

[`HttpErrorCode`](#httperrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### bodyText?

> `readonly` `optional` **bodyText?**: `string`

Defined in: [packages/core/src/agent/errors.ts:821](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L821)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### headers

> `readonly` **headers**: [`HttpHeaderField`](#httpheaderfield)[]

Defined in: [packages/core/src/agent/errors.ts:820](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L820)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'HttpErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:815](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L815)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### status

> `readonly` **status**: `number`

Defined in: [packages/core/src/agent/errors.ts:818](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L818)

##### statusText

> `readonly` **statusText**: `string`

Defined in: [packages/core/src/agent/errors.ts:819](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L819)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:827](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L827)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### HttpFetchErrorCode

Defined in: [packages/core/src/agent/errors.ts:852](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L852)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HttpFetchErrorCode**(`error`): [`HttpFetchErrorCode`](#httpfetcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:855](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L855)

###### Parameters

###### error

`unknown`

###### Returns

[`HttpFetchErrorCode`](#httpfetcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:855](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L855)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'HttpFetchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:853](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L853)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:860](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L860)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### HttpV4ApiNotSupportedErrorCode

Defined in: [packages/core/src/agent/errors.ts:839](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L839)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HttpV4ApiNotSupportedErrorCode**(): [`HttpV4ApiNotSupportedErrorCode`](#httpv4apinotsupportederrorcode)

Defined in: [packages/core/src/agent/errors.ts:842](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L842)

###### Returns

[`HttpV4ApiNotSupportedErrorCode`](#httpv4apinotsupportederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'HttpV4ApiNotSupportedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:840](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L840)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:847](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L847)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### IdentityInvalidErrorCode

Defined in: [packages/core/src/agent/errors.ts:641](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L641)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new IdentityInvalidErrorCode**(): [`IdentityInvalidErrorCode`](#identityinvaliderrorcode)

Defined in: [packages/core/src/agent/errors.ts:644](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L644)

###### Returns

[`IdentityInvalidErrorCode`](#identityinvaliderrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'IdentityInvalidErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:642](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L642)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:649](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L649)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### IngressExpiryInvalidErrorCode

Defined in: [packages/core/src/agent/errors.ts:654](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L654)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new IngressExpiryInvalidErrorCode**(`message`, `providedIngressExpiryInMinutes`): [`IngressExpiryInvalidErrorCode`](#ingressexpiryinvaliderrorcode)

Defined in: [packages/core/src/agent/errors.ts:657](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L657)

###### Parameters

###### message

`string`

###### providedIngressExpiryInMinutes

`number`

###### Returns

[`IngressExpiryInvalidErrorCode`](#ingressexpiryinvaliderrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:658](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L658)

##### name

> **name**: `string` = `'IngressExpiryInvalidErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:655](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L655)

##### providedIngressExpiryInMinutes

> `readonly` **providedIngressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:659](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L659)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:665](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L665)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### InputError

Defined in: [packages/core/src/agent/errors.ts:218](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L218)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new InputError**(`code`): [`InputError`](#inputerror)

Defined in: [packages/core/src/agent/errors.ts:221](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L221)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`InputError`](#inputerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'InputError'`

Defined in: [packages/core/src/agent/errors.ts:219](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L219)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### InvalidReadStateRequestErrorCode

Defined in: [packages/core/src/agent/errors.ts:878](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L878)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new InvalidReadStateRequestErrorCode**(`request`): [`InvalidReadStateRequestErrorCode`](#invalidreadstaterequesterrorcode)

Defined in: [packages/core/src/agent/errors.ts:881](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L881)

###### Parameters

###### request

`unknown`

###### Returns

[`InvalidReadStateRequestErrorCode`](#invalidreadstaterequesterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'InvalidReadStateRequestErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:879](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L879)

##### request

> `readonly` **request**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:881](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L881)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:886](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L886)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### InvalidRootKeyErrorCode

Defined in: [packages/core/src/agent/errors.ts:904](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L904)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new InvalidRootKeyErrorCode**(`rootKey`, `expectedLength`): [`InvalidRootKeyErrorCode`](#invalidrootkeyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:907](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L907)

###### Parameters

###### rootKey

`Uint8Array`

###### expectedLength

`number`

###### Returns

[`InvalidRootKeyErrorCode`](#invalidrootkeyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:909](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L909)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'InvalidRootKeyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:905](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L905)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### rootKey

> `readonly` **rootKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:908](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L908)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:915](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L915)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### LimitError

Defined in: [packages/core/src/agent/errors.ts:209](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L209)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new LimitError**(`code`): [`LimitError`](#limiterror)

Defined in: [packages/core/src/agent/errors.ts:212](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L212)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`LimitError`](#limiterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'LimitError'`

Defined in: [packages/core/src/agent/errors.ts:210](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L210)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### LookupErrorCode

Defined in: [packages/core/src/agent/errors.ts:317](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L317)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new LookupErrorCode**(`message`, `lookupStatus`): [`LookupErrorCode`](#lookuperrorcode)

Defined in: [packages/core/src/agent/errors.ts:320](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L320)

###### Parameters

###### message

`string`

###### lookupStatus

[`LookupSubtreeStatus`](#lookupsubtreestatus) \| [`LookupPathStatus`](#lookuppathstatus)

###### Returns

[`LookupErrorCode`](#lookuperrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### lookupStatus

> `readonly` **lookupStatus**: [`LookupSubtreeStatus`](#lookupsubtreestatus) \| [`LookupPathStatus`](#lookuppathstatus)

Defined in: [packages/core/src/agent/errors.ts:322](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L322)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:321](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L321)

##### name

> **name**: `string` = `'LookupErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:318](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L318)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:328](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L328)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MalformedLookupFoundValueErrorCode

Defined in: [packages/core/src/agent/errors.ts:333](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L333)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MalformedLookupFoundValueErrorCode**(`message`): [`MalformedLookupFoundValueErrorCode`](#malformedlookupfoundvalueerrorcode)

Defined in: [packages/core/src/agent/errors.ts:336](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L336)

###### Parameters

###### message

`string`

###### Returns

[`MalformedLookupFoundValueErrorCode`](#malformedlookupfoundvalueerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:336](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L336)

##### name

> **name**: `string` = `'MalformedLookupFoundValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:334](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L334)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:341](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L341)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MalformedPublicKeyErrorCode

Defined in: [packages/core/src/agent/errors.ts:738](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L738)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MalformedPublicKeyErrorCode**(): [`MalformedPublicKeyErrorCode`](#malformedpublickeyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:741](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L741)

###### Returns

[`MalformedPublicKeyErrorCode`](#malformedpublickeyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'MalformedPublicKeyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:739](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L739)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:746](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L746)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MalformedSignatureErrorCode

Defined in: [packages/core/src/agent/errors.ts:712](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L712)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MalformedSignatureErrorCode**(`error`): [`MalformedSignatureErrorCode`](#malformedsignatureerrorcode)

Defined in: [packages/core/src/agent/errors.ts:715](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L715)

###### Parameters

###### error

`string`

###### Returns

[`MalformedSignatureErrorCode`](#malformedsignatureerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:715](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L715)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'MalformedSignatureErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:713](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L713)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:720](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L720)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MissingCanisterIdErrorCode

Defined in: [packages/core/src/agent/errors.ts:865](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L865)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingCanisterIdErrorCode**(`receivedCanisterId`): [`MissingCanisterIdErrorCode`](#missingcanisteriderrorcode)

Defined in: [packages/core/src/agent/errors.ts:868](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L868)

###### Parameters

###### receivedCanisterId

`unknown`

###### Returns

[`MissingCanisterIdErrorCode`](#missingcanisteriderrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'MissingCanisterIdErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:866](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L866)

##### receivedCanisterId

> `readonly` **receivedCanisterId**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:868](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L868)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:873](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L873)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MissingCookieErrorCode

Defined in: [packages/core/src/agent/errors.ts:920](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L920)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingCookieErrorCode**(`expectedCookieName`): [`MissingCookieErrorCode`](#missingcookieerrorcode)

Defined in: [packages/core/src/agent/errors.ts:923](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L923)

###### Parameters

###### expectedCookieName

`string`

###### Returns

[`MissingCookieErrorCode`](#missingcookieerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### expectedCookieName

> `readonly` **expectedCookieName**: `string`

Defined in: [packages/core/src/agent/errors.ts:923](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L923)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'MissingCookieErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:921](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L921)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:928](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L928)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MissingFetchErrorCode

Defined in: [packages/core/src/agent/errors.ts:670](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L670)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingFetchErrorCode**(): [`MissingFetchErrorCode`](#missingfetcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:673](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L673)

###### Returns

[`MissingFetchErrorCode`](#missingfetcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'MissingFetchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:671](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L671)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:678](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L678)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MissingLookupValueErrorCode

Defined in: [packages/core/src/agent/errors.ts:346](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L346)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingLookupValueErrorCode**(`message`): [`MissingLookupValueErrorCode`](#missinglookupvalueerrorcode)

Defined in: [packages/core/src/agent/errors.ts:349](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L349)

###### Parameters

###### message

`string`

###### Returns

[`MissingLookupValueErrorCode`](#missinglookupvalueerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:349](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L349)

##### name

> **name**: `string` = `'MissingLookupValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:347](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L347)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:354](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L354)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MissingRootKeyErrorCode

Defined in: [packages/core/src/agent/errors.ts:612](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L612)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingRootKeyErrorCode**(`shouldFetchRootKey?`): [`MissingRootKeyErrorCode`](#missingrootkeyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:615](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L615)

###### Parameters

###### shouldFetchRootKey?

`boolean`

###### Returns

[`MissingRootKeyErrorCode`](#missingrootkeyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'MissingRootKeyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:613](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L613)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### shouldFetchRootKey?

> `readonly` `optional` **shouldFetchRootKey?**: `boolean`

Defined in: [packages/core/src/agent/errors.ts:615](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L615)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:620](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L620)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### MissingSignatureErrorCode

Defined in: [packages/core/src/agent/errors.ts:725](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L725)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingSignatureErrorCode**(): [`MissingSignatureErrorCode`](#missingsignatureerrorcode)

Defined in: [packages/core/src/agent/errors.ts:728](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L728)

###### Returns

[`MissingSignatureErrorCode`](#missingsignatureerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'MissingSignatureErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:726](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L726)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:733](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L733)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### Observable

Defined in: [packages/core/src/agent/observable.ts:5](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L5)

#### Extended by

- [`ObservableLog`](#observablelog)

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new Observable**\<`T`\>(): [`Observable`](#observable)\<`T`\>

Defined in: [packages/core/src/agent/observable.ts:8](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L8)

###### Returns

[`Observable`](#observable)\<`T`\>

#### Properties

##### observers

> **observers**: [`ObserveFunction`](#observefunction)\<`T`\>[]

Defined in: [packages/core/src/agent/observable.ts:6](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L6)

#### Methods

##### notify()

> **notify**(`data`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:20](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L20)

###### Parameters

###### data

`T`

###### rest

...`unknown`[]

###### Returns

`void`

##### subscribe()

> **subscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:12](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L12)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<`T`\>

###### Returns

`void`

##### unsubscribe()

> **unsubscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:16](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L16)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<`T`\>

###### Returns

`void`

***

### ObservableLog

Defined in: [packages/core/src/agent/observable.ts:36](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L36)

#### Extends

- [`Observable`](#observable)\<[`AgentLog`](#agentlog)\>

#### Constructors

##### Constructor

> **new ObservableLog**(): [`ObservableLog`](#observablelog)

Defined in: [packages/core/src/agent/observable.ts:37](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L37)

###### Returns

[`ObservableLog`](#observablelog)

###### Overrides

[`Observable`](#observable).[`constructor`](#constructor-46)

#### Properties

##### observers

> **observers**: [`ObserveFunction`](#observefunction)\<[`AgentLog`](#agentlog)\>[]

Defined in: [packages/core/src/agent/observable.ts:6](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L6)

###### Inherited from

[`Observable`](#observable).[`observers`](#observers)

#### Methods

##### error()

> **error**(`message`, `error`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:46](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L46)

###### Parameters

###### message

`string`

###### error

[`AgentError`](#agenterror)

###### rest

...`unknown`[]

###### Returns

`void`

##### notify()

> **notify**(`data`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:20](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L20)

###### Parameters

###### data

[`AgentLog`](#agentlog)

###### rest

...`unknown`[]

###### Returns

`void`

###### Inherited from

[`Observable`](#observable).[`notify`](#notify)

##### print()

> **print**(`message`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:40](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L40)

###### Parameters

###### message

`string`

###### rest

...`unknown`[]

###### Returns

`void`

##### subscribe()

> **subscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:12](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L12)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<[`AgentLog`](#agentlog)\>

###### Returns

`void`

###### Inherited from

[`Observable`](#observable).[`subscribe`](#subscribe)

##### unsubscribe()

> **unsubscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:16](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L16)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<[`AgentLog`](#agentlog)\>

###### Returns

`void`

###### Inherited from

[`Observable`](#observable).[`unsubscribe`](#unsubscribe)

##### warn()

> **warn**(`message`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:43](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L43)

###### Parameters

###### message

`string`

###### rest

...`unknown`[]

###### Returns

`void`

***

### ProtocolError

Defined in: [packages/core/src/agent/errors.ts:173](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L173)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new ProtocolError**(`code`): [`ProtocolError`](#protocolerror)

Defined in: [packages/core/src/agent/errors.ts:176](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L176)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`ProtocolError`](#protocolerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'ProtocolError'`

Defined in: [packages/core/src/agent/errors.ts:174](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L174)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### QuerySignatureVerificationFailedErrorCode

Defined in: [packages/core/src/agent/errors.ts:751](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L751)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new QuerySignatureVerificationFailedErrorCode**(`nodeId`): [`QuerySignatureVerificationFailedErrorCode`](#querysignatureverificationfailederrorcode)

Defined in: [packages/core/src/agent/errors.ts:754](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L754)

###### Parameters

###### nodeId

`string`

###### Returns

[`QuerySignatureVerificationFailedErrorCode`](#querysignatureverificationfailederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'QuerySignatureVerificationFailedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:752](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L752)

##### nodeId

> `readonly` **nodeId**: `string`

Defined in: [packages/core/src/agent/errors.ts:754](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L754)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:759](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L759)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### RejectError

Defined in: [packages/core/src/agent/errors.ts:182](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L182)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new RejectError**(`code`): [`RejectError`](#rejecterror)

Defined in: [packages/core/src/agent/errors.ts:185](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L185)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`RejectError`](#rejecterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'RejectError'`

Defined in: [packages/core/src/agent/errors.ts:183](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L183)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### RequestStatusDoneNoReplyErrorCode

Defined in: [packages/core/src/agent/errors.ts:596](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L596)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new RequestStatusDoneNoReplyErrorCode**(`requestId`): [`RequestStatusDoneNoReplyErrorCode`](#requeststatusdonenoreplyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:599](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L599)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### Returns

[`RequestStatusDoneNoReplyErrorCode`](#requeststatusdonenoreplyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'RequestStatusDoneNoReplyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:597](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L597)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:599](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L599)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:604](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L604)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### `abstract` SignIdentity

Defined in: [packages/core/src/agent/auth.ts:57](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L57)

An Identity that can sign blobs.

#### Extended by

- [`Ed25519KeyIdentity`](../../identity/api.md#ed25519keyidentity)
- [`ECDSAKeyIdentity`](../../identity/api.md#ecdsakeyidentity)
- [`DelegationIdentity`](../../identity/api.md#delegationidentity)
- [`Secp256k1KeyIdentity`](../../identity/secp256k1/api.md#secp256k1keyidentity)
- [`WebAuthnIdentity`](../../identity/api.md#webauthnidentity)

#### Implements

- [`Identity`](#identity-1)

#### Constructors

##### Constructor

> **new SignIdentity**(): [`SignIdentity`](#abstract-signidentity)

###### Returns

[`SignIdentity`](#abstract-signidentity)

#### Properties

##### \_principal

> `protected` **\_principal**: [`Principal`](../../principal/api.md#principal) \| `undefined`

Defined in: [packages/core/src/agent/auth.ts:58](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L58)

#### Methods

##### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/auth.ts:74](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L74)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

###### Returns

[`Principal`](../../principal/api.md#principal)

###### Implementation of

[`Identity`](#identity-1).[`getPrincipal`](#getprincipal-4)

##### getPublicKey()

> `abstract` **getPublicKey**(): [`PublicKey`](#publickey-1)

Defined in: [packages/core/src/agent/auth.ts:63](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L63)

Returns the public key that would match this identity's signature.

###### Returns

[`PublicKey`](#publickey-1)

##### sign()

> `abstract` **sign**(`blob`): `Promise`\<[`Signature`](#signature-2)\>

Defined in: [packages/core/src/agent/auth.ts:68](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L68)

Signs a blob of data, with this identity's private key.

###### Parameters

###### blob

`Uint8Array`

###### Returns

`Promise`\<[`Signature`](#signature-2)\>

##### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:87](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L87)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

internet computer request to transform

###### Returns

`Promise`\<`unknown`\>

###### Implementation of

[`Identity`](#identity-1).[`transformRequest`](#transformrequest-2)

***

### TimeoutWaitingForResponseErrorCode

Defined in: [packages/core/src/agent/errors.ts:478](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L478)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new TimeoutWaitingForResponseErrorCode**(`message`, `requestId?`, `status?`): [`TimeoutWaitingForResponseErrorCode`](#timeoutwaitingforresponseerrorcode)

Defined in: [packages/core/src/agent/errors.ts:481](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L481)

###### Parameters

###### message

`string`

###### requestId?

[`RequestId`](#requestid-9)

###### status?

[`RequestStatusResponseStatus`](#requeststatusresponsestatus)

###### Returns

[`TimeoutWaitingForResponseErrorCode`](#timeoutwaitingforresponseerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:482](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L482)

##### name

> **name**: `string` = `'TimeoutWaitingForResponseErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:479](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L479)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### requestId?

> `readonly` `optional` **requestId?**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:483](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L483)

##### status?

> `readonly` `optional` **status?**: [`RequestStatusResponseStatus`](#requeststatusresponsestatus)

Defined in: [packages/core/src/agent/errors.ts:484](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L484)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:490](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L490)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### `abstract` ToCborValue

Defined in: [packages/core/src/agent/cbor.ts:9](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/cbor.ts#L9)

Used to extend classes that need to provide a custom value for the CBOR encoding process.

#### Constructors

##### Constructor

> **new ToCborValue**(): [`ToCborValue`](#abstract-tocborvalue)

###### Returns

[`ToCborValue`](#abstract-tocborvalue)

#### Methods

##### toCborValue()

> `abstract` **toCborValue**(): `any`

Defined in: [packages/core/src/agent/cbor.ts:13](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/cbor.ts#L13)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](#encode) function.

###### Returns

`any`

***

### TransportError

Defined in: [packages/core/src/agent/errors.ts:191](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L191)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new TransportError**(`code`): [`TransportError`](#transporterror)

Defined in: [packages/core/src/agent/errors.ts:194](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L194)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`TransportError`](#transporterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'TransportError'`

Defined in: [packages/core/src/agent/errors.ts:192](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L192)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### TrustError

Defined in: [packages/core/src/agent/errors.ts:164](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L164)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new TrustError**(`code`): [`TrustError`](#trusterror)

Defined in: [packages/core/src/agent/errors.ts:167](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L167)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`TrustError`](#trusterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'TrustError'`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L165)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### UncertifiedRejectErrorCode

Defined in: [packages/core/src/agent/errors.ts:547](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L547)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UncertifiedRejectErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`, `signatures`): [`UncertifiedRejectErrorCode`](#uncertifiedrejecterrorcode)

Defined in: [packages/core/src/agent/errors.ts:550](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L550)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### rejectCode

[`ReplicaRejectCode`](#replicarejectcode)

###### rejectMessage

`string`

###### rejectErrorCode

`string` \| `undefined`

###### signatures

[`NodeSignature`](#nodesignature)[] \| `undefined`

###### Returns

[`UncertifiedRejectErrorCode`](#uncertifiedrejecterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'UncertifiedRejectErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:548](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L548)

##### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/errors.ts:552](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L552)

##### rejectErrorCode

> `readonly` **rejectErrorCode**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:554](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L554)

##### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:553](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L553)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:551](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L551)

##### signatures

> `readonly` **signatures**: [`NodeSignature`](#nodesignature)[] \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:555](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L555)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:561](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L561)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### UncertifiedRejectUpdateErrorCode

Defined in: [packages/core/src/agent/errors.ts:572](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L572)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UncertifiedRejectUpdateErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`): [`UncertifiedRejectUpdateErrorCode`](#uncertifiedrejectupdateerrorcode)

Defined in: [packages/core/src/agent/errors.ts:575](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L575)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### rejectCode

[`ReplicaRejectCode`](#replicarejectcode)

###### rejectMessage

`string`

###### rejectErrorCode

`string` \| `undefined`

###### Returns

[`UncertifiedRejectUpdateErrorCode`](#uncertifiedrejectupdateerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'UncertifiedRejectUpdateErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:573](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L573)

##### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/errors.ts:577](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L577)

##### rejectErrorCode

> `readonly` **rejectErrorCode**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:579](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L579)

##### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:578](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L578)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:576](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L576)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:585](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L585)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### UnexpectedErrorCode

Defined in: [packages/core/src/agent/errors.ts:764](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L764)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UnexpectedErrorCode**(`error`): [`UnexpectedErrorCode`](#unexpectederrorcode)

Defined in: [packages/core/src/agent/errors.ts:767](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L767)

###### Parameters

###### error

`unknown`

###### Returns

[`UnexpectedErrorCode`](#unexpectederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:767](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L767)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'UnexpectedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:765](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L765)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:772](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L772)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### UnexpectedV4StatusErrorCode

Defined in: [packages/core/src/agent/errors.ts:777](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L777)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UnexpectedV4StatusErrorCode**(`status`, `requestId`, `response`, `rawCertificate`): [`UnexpectedV4StatusErrorCode`](#unexpectedv4statuserrorcode)

Defined in: [packages/core/src/agent/errors.ts:780](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L780)

###### Parameters

###### status

`string` \| `undefined`

###### requestId

[`RequestId`](#requestid-9)

###### response

###### body

[`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

[`HttpHeaderField`](#httpheaderfield)[]

###### ok

`boolean`

###### status

`number`

###### statusText

`string`

###### rawCertificate

`Uint8Array`

###### Returns

[`UnexpectedV4StatusErrorCode`](#unexpectedv4statuserrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-19)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-46) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-16)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L80)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-17)

##### name

> **name**: `string` = `'UnexpectedV4StatusErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:778](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L778)

##### rawCertificate

> `readonly` **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:784](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L784)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-46)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L77)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-16)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:782](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L782)

##### response

> `readonly` **response**: `object`

Defined in: [packages/core/src/agent/errors.ts:783](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L783)

###### body

> **body**: [`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

###### ok

> **ok**: `boolean`

###### status

> **status**: `number`

###### statusText

> **statusText**: `string`

##### status

> `readonly` **status**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:781](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L781)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L75)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-16)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:790](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L790)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-16)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L84)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-17)

***

### UnknownError

Defined in: [packages/core/src/agent/errors.ts:227](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L227)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new UnknownError**(`code`): [`UnknownError`](#unknownerror)

Defined in: [packages/core/src/agent/errors.ts:230](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L230)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`UnknownError`](#unknownerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L116)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'UnknownError'`

Defined in: [packages/core/src/agent/errors.ts:228](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L228)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L118)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L121)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L136)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L125)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L128)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L146)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L150)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L156)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

## Interfaces

### ActorConfig

Defined in: [packages/core/src/agent/actor.ts:61](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L61)

Configuration that can be passed to customize the Actor behavior.

#### Extends

- `Pick`\<[`CallConfig`](#callconfig), `"agent"` \| `"effectiveCanisterId"`\>

#### Properties

##### agent?

> `optional` **agent?**: [`Agent`](#agent-1)

Defined in: [packages/core/src/agent/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

###### Inherited from

[`CallConfig`](#callconfig).[`agent`](#agent-2)

##### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/actor.ts:88](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L88)

Polyfill for BLS Certificate verification in case wasm is not supported

##### canisterId

> **canisterId**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:65](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L65)

The Canister ID of this Actor. This is required for an Actor.

##### effectiveCanisterId?

> `optional` **effectiveCanisterId?**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L50)

The effective canister ID.

###### Inherited from

[`CallConfig`](#callconfig).[`effectiveCanisterId`](#effectivecanisterid-1)

##### pollingOptions?

> `optional` **pollingOptions?**: [`PollingOptions`](#pollingoptions-2)

Defined in: [packages/core/src/agent/actor.ts:93](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L93)

Polling options to use when making update calls. This will override the default DEFAULT_POLLING_OPTIONS.

##### queryStrategy?

> `optional` **queryStrategy?**: [`QueryStrategy`](#querystrategy-1)

Defined in: [packages/core/src/agent/actor.ts:101](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L101)

Controls how query and composite_query methods are executed.
- `'query'` (default) — standard non-replicated query call.
- `'update'` — send query methods as update calls that go through consensus.

###### Default

```ts
'query'
```

#### Methods

##### callTransform()?

> `optional` **callTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](#callconfig)\>

Defined in: [packages/core/src/agent/actor.ts:70](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L70)

An override function for update calls' CallConfig. This will be called on every calls.

###### Parameters

###### methodName

`string`

###### args

`unknown`[]

###### callConfig

[`CallConfig`](#callconfig)

###### Returns

`void` \| `Partial`\<[`CallConfig`](#callconfig)\>

##### queryTransform()?

> `optional` **queryTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](#callconfig)\>

Defined in: [packages/core/src/agent/actor.ts:79](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L79)

An override function for query calls' CallConfig. This will be called on every query.

###### Parameters

###### methodName

`string`

###### args

`unknown`[]

###### callConfig

[`CallConfig`](#callconfig)

###### Returns

`void` \| `Partial`\<[`CallConfig`](#callconfig)\>

***

### ActorMethod()

Defined in: [packages/core/src/agent/actor.ts:113](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L113)

An actor method type, defined for each methods of the actor service.

#### Extended by

- [`ActorMethodWithHttpDetails`](#actormethodwithhttpdetails)
- [`ActorMethodExtended`](#actormethodextended)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:114](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L114)

An actor method type, defined for each methods of the actor service.

#### Parameters

##### args

...`Args`

#### Returns

`Promise`\<`Ret`\>

#### Methods

##### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L116)

###### Parameters

###### options

[`CallConfig`](#callconfig)

###### Returns

(...`args`) => `Promise`\<`Ret`\>

***

### ActorMethodExtended()

Defined in: [packages/core/src/agent/actor.ts:132](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L132)

An actor method type, defined for each methods of the actor service.

#### Extends

- [`ActorMethod`](#actormethod)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

#### Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<\{ `certificate?`: [`Certificate`](#certificate); `httpDetails?`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

Defined in: [packages/core/src/agent/actor.ts:136](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L136)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<\{ `certificate?`: [`Certificate`](#certificate); `httpDetails?`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

#### Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:132](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L132)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`unknown`[]

##### Returns

`Promise`\<`unknown`\>

#### Methods

##### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L116)

###### Parameters

###### options

[`CallConfig`](#callconfig)

###### Returns

(...`args`) => `Promise`\<`unknown`\>

###### Inherited from

[`ActorMethod`](#actormethod).[`withOptions`](#withoptions)

***

### ActorMethodWithHttpDetails()

Defined in: [packages/core/src/agent/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L122)

An actor method type, defined for each methods of the actor service.

#### Extends

- [`ActorMethod`](#actormethod)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

#### Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

Defined in: [packages/core/src/agent/actor.ts:126](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L126)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

#### Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L122)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`unknown`[]

##### Returns

`Promise`\<`unknown`\>

#### Methods

##### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L116)

###### Parameters

###### options

[`CallConfig`](#callconfig)

###### Returns

(...`args`) => `Promise`\<`unknown`\>

###### Inherited from

[`ActorMethod`](#actormethod).[`withOptions`](#withoptions)

***

### Agent

Defined in: [packages/core/src/agent/agent/api.ts:206](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L206)

An Agent able to make calls and queries to a Replica.

#### Properties

##### rootKey

> `readonly` **rootKey**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/core/src/agent/agent/api.ts:207](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L207)

#### Methods

##### call()

> **call**(`canisterId`, `fields`): `Promise`\<[`SubmitResponse`](#submitresponse)\>

Defined in: [packages/core/src/agent/agent/api.ts:238](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L238)

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

###### fields

[`CallOptions`](#calloptions)

###### Returns

`Promise`\<[`SubmitResponse`](#submitresponse)\>

##### createReadStateRequest()?

> `optional` **createReadStateRequest**(`options`, `identity?`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/agent/api.ts:220](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L220)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

###### Parameters

###### options

[`ReadStateOptions`](#readstateoptions)

###### identity?

[`Identity`](#identity-1)

###### Returns

`Promise`\<`unknown`\>

##### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/agent/api.ts:291](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L291)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

###### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

##### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../principal/api.md#principal)\>

Defined in: [packages/core/src/agent/agent/api.ts:213](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L213)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

###### Returns

`Promise`\<[`Principal`](../../principal/api.md#principal)\>

##### invalidateIdentity()?

> `optional` **invalidateIdentity**(): `void`

Defined in: [packages/core/src/agent/agent/api.ts:298](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L298)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

###### Returns

`void`

##### query()

> **query**(`canisterId`, `options`, `identity?`): `Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

Defined in: [packages/core/src/agent/agent/api.ts:273](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L273)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

###### options

[`QueryFields`](#queryfields)

Options to use to create and send the query.

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

Sender principal to use when sending the query.

###### Returns

`Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

##### readState()

> **readState**(`effectiveCanisterId`, `options`, `identity?`, `request?`): `Promise`\<[`ReadStateResponse`](#readstateresponse)\>

Defined in: [packages/core/src/agent/agent/api.ts:231](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L231)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

###### Parameters

###### effectiveCanisterId

`string` \| [`Principal`](../../principal/api.md#principal)

A Canister ID related to this call.

###### options

[`ReadStateOptions`](#readstateoptions)

The options for this call.

###### identity?

[`Identity`](#identity-1)

Identity for the call. If not specified, uses the instance identity.

###### request?

`unknown`

The request to send in case it has already been created.

###### Returns

`Promise`\<[`ReadStateResponse`](#readstateresponse)\>

##### replaceIdentity()?

> `optional` **replaceIdentity**(`identity`): `void`

Defined in: [packages/core/src/agent/agent/api.ts:309](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L309)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@icp-sdk/auth/client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

###### Parameters

###### identity

[`Identity`](#identity-1)

###### Returns

`void`

##### status()

> **status**(): `Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

Defined in: [packages/core/src/agent/agent/api.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L260)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

###### Returns

`Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.

##### update()

> **update**(`canisterId`, `fields`, `pollingOptions?`): `Promise`\<[`UpdateResult`](#updateresult)\>

Defined in: [packages/core/src/agent/agent/api.ts:247](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L247)

Executes an update call to a canister and returns the certified result.

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The canister to call.

###### fields

[`CallOptions`](#calloptions)

The call options (method name, arg, effective canister ID, optional nonce).

###### pollingOptions?

[`PollingOptions`](#pollingoptions-2)

Optional polling configuration.

###### Returns

`Promise`\<[`UpdateResult`](#updateresult)\>

The certified result including the certificate, reply bytes, and raw certificate bytes.

***

### AnonymousIdentityDescriptor

Defined in: [packages/core/src/agent/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L126)

#### Properties

##### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/core/src/agent/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L127)

***

### CallConfig

Defined in: [packages/core/src/agent/actor.ts:30](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L30)

Configuration to make calls to the Replica.

#### Properties

##### agent?

> `optional` **agent?**: [`Agent`](#agent-1)

Defined in: [packages/core/src/agent/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

##### canisterId?

> `optional` **canisterId?**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:45](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L45)

The canister ID of this Actor.

##### effectiveCanisterId?

> `optional` **effectiveCanisterId?**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L50)

The effective canister ID.

##### nonce?

> `optional` **nonce?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/actor.ts:55](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L55)

The nonce to use for this call. This is used to prevent replay attacks.

##### pollingOptions?

> `optional` **pollingOptions?**: [`PollingOptions`](#pollingoptions-2)

Defined in: [packages/core/src/agent/actor.ts:40](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L40)

Options for controlling polling behavior.

***

### CallContext

Defined in: [packages/core/src/agent/errors.ts:44](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L44)

Call context for errors that arise from a direct HTTP call response.

#### Extends

- [`PollingCallContext`](#pollingcallcontext)

#### Properties

##### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:37](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L37)

###### Inherited from

[`PollingCallContext`](#pollingcallcontext).[`canisterId`](#canisterid-5)

##### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](#httpdetailsresponse)

Defined in: [packages/core/src/agent/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L45)

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L38)

###### Inherited from

[`PollingCallContext`](#pollingcallcontext).[`methodName`](#methodname-2)

***

### CallOptions

Defined in: [packages/core/src/agent/agent/api.ts:103](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L103)

Options when doing a [Agent.call](#call-3) call.

#### Extended by

- [`UpdateOptions`](#updateoptions)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:112](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L112)

A binary encoded argument. This is already encoded and will be sent as is.

##### callSync?

> `optional` **callSync?**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:123](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L123)

Whether to use synchronous call mode. Defaults to true.

##### effectiveCanisterId

> **effectiveCanisterId**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/api.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L118)

An effective canister ID, used for routing. Usually the canister ID, except for management canister calls.

###### See

https://internetcomputer.org/docs/current/references/ic-interface-spec/#http-effective-canister-id

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:107](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L107)

The method name to call.

##### nonce?

> `optional` **nonce?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/api.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L128)

An optional nonce to use for the call, used to prevent replay attacks.

***

### CallRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:62](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L62)

#### Extends

- `Record`\<`string`, `any`\>

#### Indexable

> \[`key`: `string`\]: `any`

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/http/types.ts:66](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L66)

##### canister\_id

> **canister\_id**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:64](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L64)

##### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/types.ts:68](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L68)

##### method\_name

> **method\_name**: `string`

Defined in: [packages/core/src/agent/agent/http/types.ts:65](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L65)

##### nonce?

> `optional` **nonce?**: [`Nonce`](#nonce-5)

Defined in: [packages/core/src/agent/agent/http/types.ts:69](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L69)

##### request\_type

> **request\_type**: [`Call`](#call-1)

Defined in: [packages/core/src/agent/agent/http/types.ts:63](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L63)

##### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:67](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L67)

***

### Cert

Defined in: [packages/core/src/agent/certificate.ts:41](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L41)

#### Properties

##### delegation?

> `optional` **delegation?**: `Delegation`

Defined in: [packages/core/src/agent/certificate.ts:44](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L44)

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:43](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L43)

##### tree

> **tree**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:42](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L42)

***

### CheckCanisterRangesParams

Defined in: [packages/core/src/agent/certificate.ts:876](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L876)

#### Properties

##### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/certificate.ts:877](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L877)

##### subnetId

> **subnetId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/certificate.ts:878](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L878)

##### tree

> **tree**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:879](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L879)

***

### CreateActorClassOpts

Defined in: [packages/core/src/agent/actor.ts:174](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L174)

#### Properties

##### certificate?

> `optional` **certificate?**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:176](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L176)

##### httpDetails?

> `optional` **httpDetails?**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:175](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L175)

***

### CreateCertificateOptions

Defined in: [packages/core/src/agent/certificate.ts:170](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L170)

#### Properties

##### agent?

> `optional` **agent?**: [`Agent`](#agent-1)

Defined in: [packages/core/src/agent/certificate.ts:209](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L209)

The agent used to sync time with the IC network, if the certificate fails the freshness check.
If the agent does not implement the [HttpAgent.getTimeDiffMsecs](#gettimediffmsecs), [HttpAgent.hasSyncedTime](#hassyncedtime), [HttpAgent.syncTime](#synctime) and [HttpAgent.syncTimeWithSubnet](#synctimewithsubnet) methods,
time will not be synced in case of a freshness check failure.

###### Default

```ts
undefined
```

##### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/certificate.ts:187](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L187)

BLS Verification strategy. Default strategy uses bls12_381 from `@noble/curves`

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:174](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L174)

The bytes encoding the certificate to be verified

##### disableTimeVerification?

> `optional` **disableTimeVerification?**: `boolean`

Defined in: [packages/core/src/agent/certificate.ts:201](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L201)

Overrides the maxAgeInMinutes setting and skips comparing the client's time against the certificate. Used for scenarios where the machine's clock is known to be out of sync, or for inspecting expired certificates.

###### Default

```ts
false
```

##### maxAgeInMinutes?

> `optional` **maxAgeInMinutes?**: `number`

Defined in: [packages/core/src/agent/certificate.ts:195](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L195)

The maximum age of the certificate in minutes. Default is 5 minutes.
This is used to verify the time the certificate was signed, particularly for validating Delegation certificates, which can live for longer than the default window of +/- 5 minutes. If the certificate is
older than the specified age, it will fail verification.

###### Default

```ts
5
```

##### principal

> **principal**: [`CertificatePrincipal`](#certificateprincipal)

Defined in: [packages/core/src/agent/certificate.ts:183](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L183)

The principal for which the certificate is being verified.

##### rootKey

> **rootKey**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:179](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L179)

The root key against which to verify the certificate
(normally, the root key of the IC main network)

***

### ExpirableStore

Defined in: [packages/core/src/agent/utils/expirableStore.ts:6](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/expirableStore.ts#L6)

Generic interface for a key-value store with time-based expiration.
Keys are strings, values are of type V.
Implementations must handle expiration internally.

#### Type Parameters

##### V

`V`

#### Properties

##### expirationTime

> `readonly` **expirationTime**: `number`

Defined in: [packages/core/src/agent/utils/expirableStore.ts:10](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/expirableStore.ts#L10)

Time in milliseconds after which entries expire.

#### Methods

##### delete()

> **delete**(`key`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:27](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/expirableStore.ts#L27)

Delete the entry for a key.

###### Parameters

###### key

`string`

###### Returns

`Promise`\<`void`\>

##### get()

> **get**(`key`): `Promise`\<`V` \| `undefined`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:16](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/expirableStore.ts#L16)

Get the value for a key.
Returns undefined if the key is not present or has expired.

###### Parameters

###### key

`string`

###### Returns

`Promise`\<`V` \| `undefined`\>

##### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:22](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/expirableStore.ts#L22)

Store a value for a key.
Prunes expired entries before inserting.

###### Parameters

###### key

`string`

###### value

`V`

###### Returns

`Promise`\<`void`\>

***

### HttpAgentBaseRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:21](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L21)

#### Extended by

- [`HttpAgentSubmitRequest`](#httpagentsubmitrequest)
- [`HttpAgentQueryRequest`](#httpagentqueryrequest)
- [`HttpAgentReadStateRequest`](#httpagentreadstaterequest)

#### Properties

##### endpoint

> `readonly` **endpoint**: [`Endpoint`](#endpoint)

Defined in: [packages/core/src/agent/agent/http/types.ts:22](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L22)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L23)

***

### HttpAgentOptions

Defined in: [packages/core/src/agent/agent/http/index.ts:132](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L132)

#### Properties

##### backoffStrategy?

> `optional` **backoffStrategy?**: `BackoffStrategyFactory`

Defined in: [packages/core/src/agent/agent/http/index.ts:179](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L179)

The strategy to use for backoff when retrying requests

##### callOptions?

> `optional` **callOptions?**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:142](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L142)

##### credentials?

> `optional` **credentials?**: `object`

Defined in: [packages/core/src/agent/agent/http/index.ts:158](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L158)

###### name

> **name**: `string`

###### password?

> `optional` **password?**: `string`

##### fetch?

> `optional` **fetch?**: \{(`input`, `init?`): `Promise`\<`Response`\>; (`input`, `init?`): `Promise`\<`Response`\>; \}

Defined in: [packages/core/src/agent/agent/http/index.ts:134](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L134)

###### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

###### Parameters

###### input

`URL` \| `RequestInfo`

###### init?

`RequestInit`

###### Returns

`Promise`\<`Response`\>

###### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

###### Parameters

###### input

`string` \| `URL` \| `Request`

###### init?

`RequestInit`

###### Returns

`Promise`\<`Response`\>

##### fetchOptions?

> `optional` **fetchOptions?**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:139](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L139)

##### host?

> `optional` **host?**: `string`

Defined in: [packages/core/src/agent/agent/http/index.ts:146](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L146)

##### identity?

> `optional` **identity?**: [`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L150)

##### ingressExpiryInMinutes?

> `optional` **ingressExpiryInMinutes?**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:156](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L156)

The maximum time a request can be delayed before being rejected.

###### Default

```ts
5 minutes
```

##### logToConsole?

> `optional` **logToConsole?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:194](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L194)

Whether to log to the console. Defaults to false.

##### retryTimes?

> `optional` **retryTimes?**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:175](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L175)

Number of times to retry requests before throwing an error

###### Default

```ts
3
```

##### rootKey?

> `optional` **rootKey?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:199](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L199)

Alternate root key to use for verifying certificates. If not provided, the default IC root key will be used.

##### shouldFetchRootKey?

> `optional` **shouldFetchRootKey?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:204](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L204)

Whether or not the root key should be automatically fetched during construction. Defaults to false.

##### shouldSyncTime?

> `optional` **shouldSyncTime?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:209](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L209)

Whether or not to sync the time with the network during construction. Defaults to false.

##### subnetNodeKeyExpirableStore?

> `optional` **subnetNodeKeyExpirableStore?**: [`ExpirableStore`](#expirablestore)\<`SubnetNodeKeys`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:190](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L190)

Custom store for caching subnet node keys.
Allows sharing the cache across multiple HttpAgent instances.
Defaults to IndexedDB in browser environments, in-memory otherwise.

##### useQueryNonces?

> `optional` **useQueryNonces?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:170](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L170)

Adds a unique [Nonce](#nonce-5) with each query.
Enabling will prevent queries from being answered with a cached response.

###### Example

```ts
const agent = new HttpAgent({ useQueryNonces: true });
agent.addTransform(makeNonceTransform(makeNonce);
```

###### Default

```ts
false
```

##### verifyQuerySignatures?

> `optional` **verifyQuerySignatures?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:184](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L184)

Whether the agent should verify signatures signed by node keys on query responses. Increases security, but adds overhead and must make a separate request to cache the node keys for the canister's subnet.

###### Default

```ts
true
```

***

### HttpAgentQueryRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:33](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L33)

#### Extends

- [`HttpAgentBaseRequest`](#httpagentbaserequest)

#### Properties

##### body

> **body**: [`ReadRequest`](#readrequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:35](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L35)

##### endpoint

> `readonly` **endpoint**: [`Query`](#query)

Defined in: [packages/core/src/agent/agent/http/types.ts:34](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L34)

###### Overrides

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`endpoint`](#endpoint-1)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L23)

###### Inherited from

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`request`](#request-1)

***

### HttpAgentReadStateRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:38](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L38)

#### Extends

- [`HttpAgentBaseRequest`](#httpagentbaserequest)

#### Properties

##### body

> **body**: [`ReadRequest`](#readrequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:40](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L40)

##### endpoint

> `readonly` **endpoint**: [`ReadState`](#readstate)

Defined in: [packages/core/src/agent/agent/http/types.ts:39](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L39)

###### Overrides

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`endpoint`](#endpoint-1)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L23)

###### Inherited from

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`request`](#request-1)

***

### HttpAgentRequestTransformFn()

Defined in: [packages/core/src/agent/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`void` \| [`HttpAgentRequest`](#httpagentrequest) \| `undefined`\>

Defined in: [packages/core/src/agent/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L56)

#### Parameters

##### args

[`HttpAgentRequest`](#httpagentrequest)

#### Returns

`Promise`\<`void` \| [`HttpAgentRequest`](#httpagentrequest) \| `undefined`\>

#### Properties

##### priority?

> `optional` **priority?**: `number`

Defined in: [packages/core/src/agent/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L57)

***

### HttpAgentSubmitRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:28](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L28)

#### Extends

- [`HttpAgentBaseRequest`](#httpagentbaserequest)

#### Properties

##### body

> **body**: [`CallRequest`](#callrequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:30](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L30)

##### endpoint

> `readonly` **endpoint**: [`Call`](#call)

Defined in: [packages/core/src/agent/agent/http/types.ts:29](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L29)

###### Overrides

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`endpoint`](#endpoint-1)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L23)

###### Inherited from

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`request`](#request-1)

***

### HttpDetailsResponse

Defined in: [packages/core/src/agent/agent/api.ts:40](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L40)

#### Properties

##### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

Defined in: [packages/core/src/agent/agent/api.ts:44](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L44)

##### ok

> **ok**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:41](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L41)

##### status

> **status**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:42](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L42)

##### statusText

> **statusText**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:43](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L43)

***

### Identity

Defined in: [packages/core/src/agent/auth.ts:39](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L39)

A General Identity object. This does not have to be a private key (for example,
the Anonymous identity), but it must be able to transform request.

#### Methods

##### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/auth.ts:44](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L44)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

###### Returns

[`Principal`](../../principal/api.md#principal)

##### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:51](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L51)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

###### Returns

`Promise`\<`unknown`\>

***

### JsonnableExpiry

Defined in: [packages/core/src/agent/agent/http/expiry.ts:20](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L20)

#### Properties

##### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:21](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L21)

***

### KeyPair

Defined in: [packages/core/src/agent/auth.ts:9](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L9)

A Key Pair, containing a secret and public key.

#### Properties

##### publicKey

> **publicKey**: [`PublicKey`](#publickey-1)

Defined in: [packages/core/src/agent/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L11)

##### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/core/src/agent/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L10)

***

### LookupLabelResultAbsent

Defined in: [packages/core/src/agent/certificate.ts:579](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L579)

#### Properties

##### status

> **status**: [`Absent`](#absent)

Defined in: [packages/core/src/agent/certificate.ts:580](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L580)

***

### LookupLabelResultFound

Defined in: [packages/core/src/agent/certificate.ts:587](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L587)

#### Properties

##### status

> **status**: [`Found`](#found)

Defined in: [packages/core/src/agent/certificate.ts:588](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L588)

##### value

> **value**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:589](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L589)

***

### LookupLabelResultGreater

Defined in: [packages/core/src/agent/certificate.ts:592](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L592)

#### Properties

##### status

> **status**: [`Greater`](#greater)

Defined in: [packages/core/src/agent/certificate.ts:593](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L593)

***

### LookupLabelResultLess

Defined in: [packages/core/src/agent/certificate.ts:596](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L596)

#### Properties

##### status

> **status**: [`Less`](#less)

Defined in: [packages/core/src/agent/certificate.ts:597](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L597)

***

### LookupLabelResultUnknown

Defined in: [packages/core/src/agent/certificate.ts:583](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L583)

#### Properties

##### status

> **status**: [`Unknown`](#unknown-1)

Defined in: [packages/core/src/agent/certificate.ts:584](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L584)

***

### LookupPathResultAbsent

Defined in: [packages/core/src/agent/certificate.ts:524](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L524)

#### Properties

##### status

> **status**: [`Absent`](#absent-1)

Defined in: [packages/core/src/agent/certificate.ts:525](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L525)

***

### LookupPathResultError

Defined in: [packages/core/src/agent/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L537)

#### Properties

##### status

> **status**: [`Error`](#error)

Defined in: [packages/core/src/agent/certificate.ts:538](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L538)

***

### LookupPathResultFound

Defined in: [packages/core/src/agent/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L532)

#### Properties

##### status

> **status**: [`Found`](#found-1)

Defined in: [packages/core/src/agent/certificate.ts:533](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L533)

##### value

> **value**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:534](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L534)

***

### LookupPathResultUnknown

Defined in: [packages/core/src/agent/certificate.ts:528](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L528)

#### Properties

##### status

> **status**: [`Unknown`](#unknown-2)

Defined in: [packages/core/src/agent/certificate.ts:529](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L529)

***

### LookupSubtreeResultAbsent

Defined in: [packages/core/src/agent/certificate.ts:553](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L553)

#### Properties

##### status

> **status**: [`Absent`](#absent-2)

Defined in: [packages/core/src/agent/certificate.ts:554](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L554)

***

### LookupSubtreeResultFound

Defined in: [packages/core/src/agent/certificate.ts:561](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L561)

#### Properties

##### status

> **status**: [`Found`](#found-2)

Defined in: [packages/core/src/agent/certificate.ts:562](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L562)

##### value

> **value**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:563](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L563)

***

### LookupSubtreeResultUnknown

Defined in: [packages/core/src/agent/certificate.ts:557](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L557)

#### Properties

##### status

> **status**: [`Unknown`](#unknown-3)

Defined in: [packages/core/src/agent/certificate.ts:558](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L558)

***

### NodeSignature

Defined in: [packages/core/src/agent/agent/api.ts:57](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L57)

#### Properties

##### identity

> **identity**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:63](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L63)

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:61](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L61)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/core/src/agent/agent/api.ts:59](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L59)

***

### PollForResponseResult

Defined in: [packages/core/src/agent/polling/types.ts:21](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L21)

The result of polling for a response, including the certificate, reply bytes, and raw certificate bytes.

#### Extended by

- [`UpdateResult`](#updateresult)

#### Properties

##### certificate

> **certificate**: [`Certificate`](#certificate)

Defined in: [packages/core/src/agent/polling/types.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L23)

The certificate for the request, which can be used to verify the reply.

##### rawCertificate

> **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:27](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L27)

The raw certificate bytes for the request.

##### reply

> **reply**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:25](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L25)

The reply bytes for the request.

***

### PollingCallContext

Defined in: [packages/core/src/agent/errors.ts:36](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L36)

Call context for errors that arise during polling.

#### Extended by

- [`CallContext`](#callcontext-46)

#### Properties

##### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:37](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L37)

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L38)

***

### PollingOptions

Defined in: [packages/core/src/agent/polling/index.ts:39](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L39)

Options for controlling polling behavior

#### Properties

##### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/polling/index.ts:56](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L56)

Optional replacement function that verifies the BLS signature of a certificate.

##### preSignReadStateRequest?

> `optional` **preSignReadStateRequest?**: `boolean`

Defined in: [packages/core/src/agent/polling/index.ts:51](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L51)

Whether to reuse the same signed request for polling or create a new unsigned request each time.

###### Default

```ts
false
```

##### request?

> `optional` **request?**: [`ReadStateRequest`](#readstaterequest)

Defined in: [packages/core/src/agent/polling/index.ts:62](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L62)

The request to use for polling. If not provided, a new request will be created.
This is only used if `preSignReadStateRequest` is set to false.

##### strategy?

> `optional` **strategy?**: [`PollStrategy`](#pollstrategy)

Defined in: [packages/core/src/agent/polling/index.ts:45](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L45)

A polling strategy that dictates how much and often we should poll the
read_state endpoint to get the result of an update call.

###### Default

[defaultStrategy](namespaces/strategy.md#defaultstrategy)

***

### PublicKey

Defined in: [packages/core/src/agent/auth.ts:27](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L27)

A Public Key implementation.

#### Properties

##### derKey?

> `optional` **derKey?**: [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/auth.ts:32](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L32)

##### rawKey?

> `optional` **rawKey?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/auth.ts:31](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L31)

#### Methods

##### toDer()

> **toDer**(): [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/auth.ts:28](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L28)

###### Returns

[`DerEncodedPublicKey`](#derencodedpublickey)

##### toRaw()?

> `optional` **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/agent/auth.ts:30](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L30)

###### Returns

`Uint8Array`

***

### PublicKeyIdentityDescriptor

Defined in: [packages/core/src/agent/auth.ts:129](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L129)

#### Properties

##### publicKey

> **publicKey**: `string`

Defined in: [packages/core/src/agent/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L131)

##### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/core/src/agent/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L130)

***

### QueryFields

Defined in: [packages/core/src/agent/agent/api.ts:83](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L83)

Options when doing a [Agent.query](#query-3) call.

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:92](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L92)

A binary encoded argument. This is already encoded and will be sent as is.

##### effectiveCanisterId?

> `optional` **effectiveCanisterId?**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/api.ts:97](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L97)

Overrides canister id for path to fetch. This is used for management canister calls.

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:87](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L87)

The method name to call.

***

### QueryRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:85](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L85)

#### Extends

- `Record`\<`string`, `any`\>

#### Indexable

> \[`key`: `string`\]: `any`

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/http/types.ts:89](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L89)

##### canister\_id

> **canister\_id**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:87](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L87)

##### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/types.ts:91](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L91)

##### method\_name

> **method\_name**: `string`

Defined in: [packages/core/src/agent/agent/http/types.ts:88](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L88)

##### nonce?

> `optional` **nonce?**: [`Nonce`](#nonce-5)

Defined in: [packages/core/src/agent/agent/http/types.ts:92](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L92)

##### request\_type

> **request\_type**: [`Query`](#query-1)

Defined in: [packages/core/src/agent/agent/http/types.ts:86](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L86)

##### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:90](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L90)

***

### QueryResponseBase

Defined in: [packages/core/src/agent/agent/api.ts:52](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L52)

#### Extended by

- [`QueryResponseReplied`](#queryresponsereplied)
- [`QueryResponseRejected`](#queryresponserejected)

#### Properties

##### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](#queryrequest)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L54)

##### status

> **status**: [`QueryResponseStatus`](#queryresponsestatus)

Defined in: [packages/core/src/agent/agent/api.ts:53](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L53)

***

### QueryResponseRejected

Defined in: [packages/core/src/agent/agent/api.ts:72](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L72)

#### Extends

- [`QueryResponseBase`](#queryresponsebase)

#### Properties

##### error\_code

> **error\_code**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:76](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L76)

##### reject\_code

> **reject\_code**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/agent/api.ts:74](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L74)

##### reject\_message

> **reject\_message**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:75](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L75)

##### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](#queryrequest)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L54)

###### Inherited from

[`QueryResponseBase`](#queryresponsebase).[`requestDetails`](#requestdetails)

##### signatures?

> `optional` **signatures?**: [`NodeSignature`](#nodesignature)[]

Defined in: [packages/core/src/agent/agent/api.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L77)

##### status

> **status**: [`Rejected`](#rejected)

Defined in: [packages/core/src/agent/agent/api.ts:73](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L73)

###### Overrides

[`QueryResponseBase`](#queryresponsebase).[`status`](#status-18)

***

### QueryResponseReplied

Defined in: [packages/core/src/agent/agent/api.ts:66](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L66)

#### Extends

- [`QueryResponseBase`](#queryresponsebase)

#### Properties

##### reply

> **reply**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:68](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L68)

###### arg

> **arg**: `Uint8Array`

##### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](#queryrequest)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L54)

###### Inherited from

[`QueryResponseBase`](#queryresponsebase).[`requestDetails`](#requestdetails)

##### signatures?

> `optional` **signatures?**: [`NodeSignature`](#nodesignature)[]

Defined in: [packages/core/src/agent/agent/api.ts:69](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L69)

##### status

> **status**: [`Replied`](#replied)

Defined in: [packages/core/src/agent/agent/api.ts:67](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L67)

###### Overrides

[`QueryResponseBase`](#queryresponsebase).[`status`](#status-18)

***

### ReadStateOptions

Defined in: [packages/core/src/agent/agent/api.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L23)

Options when doing a [Agent.readState](#readstate-3) call.

#### Properties

##### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/core/src/agent/agent/api.ts:27](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L27)

A list of paths to read the state of.

***

### ReadStateRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:96](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L96)

#### Extends

- `Record`\<`string`, `any`\>

#### Indexable

> \[`key`: `string`\]: `any`

#### Properties

##### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/types.ts:99](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L99)

##### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/core/src/agent/agent/http/types.ts:98](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L98)

##### request\_type

> **request\_type**: [`ReadState`](#readstate-1)

Defined in: [packages/core/src/agent/agent/http/types.ts:97](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L97)

##### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:100](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L100)

***

### ReadStateResponse

Defined in: [packages/core/src/agent/agent/api.ts:144](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L144)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:145](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L145)

***

### RequestContext

Defined in: [packages/core/src/agent/errors.ts:26](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L26)

#### Properties

##### ingressExpiry

> **ingressExpiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/errors.ts:30](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L30)

##### requestId?

> `optional` **requestId?**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:27](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L27)

##### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:28](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L28)

##### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:29](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L29)

***

### Signed

Defined in: [packages/core/src/agent/agent/http/types.ts:43](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L43)

#### Type Parameters

##### T

`T`

#### Properties

##### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:44](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L44)

##### sender\_pubkey

> **sender\_pubkey**: `ArrayBuffer`

Defined in: [packages/core/src/agent/agent/http/types.ts:45](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L45)

##### sender\_sig

> **sender\_sig**: `ArrayBuffer`

Defined in: [packages/core/src/agent/agent/http/types.ts:46](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L46)

***

### SubmitResponse

Defined in: [packages/core/src/agent/agent/api.ts:180](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L180)

#### Properties

##### requestDetails?

> `optional` **requestDetails?**: [`CallRequest`](#callrequest)

Defined in: [packages/core/src/agent/agent/api.ts:189](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L189)

##### requestId

> **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/agent/api.ts:181](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L181)

##### response

> **response**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:182](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L182)

###### body

> **body**: [`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

###### ok

> **ok**: `boolean`

###### status

> **status**: `number`

###### statusText

> **statusText**: `string`

***

### UnSigned

Defined in: [packages/core/src/agent/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L49)

#### Type Parameters

##### T

`T`

#### Properties

##### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L50)

***

### UpdateOptions

Defined in: [packages/core/src/agent/agent/api.ts:131](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L131)

Options when doing a [Agent.call](#call-3) call.

#### Extends

- [`CallOptions`](#calloptions)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:112](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L112)

A binary encoded argument. This is already encoded and will be sent as is.

###### Inherited from

[`CallOptions`](#calloptions).[`arg`](#arg)

##### callSync?

> `optional` **callSync?**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:123](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L123)

Whether to use synchronous call mode. Defaults to true.

###### Inherited from

[`CallOptions`](#calloptions).[`callSync`](#callsync)

##### effectiveCanisterId

> **effectiveCanisterId**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/api.ts:118](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L118)

An effective canister ID, used for routing. Usually the canister ID, except for management canister calls.

###### See

https://internetcomputer.org/docs/current/references/ic-interface-spec/#http-effective-canister-id

###### Inherited from

[`CallOptions`](#calloptions).[`effectiveCanisterId`](#effectivecanisterid-2)

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:107](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L107)

The method name to call.

###### Inherited from

[`CallOptions`](#calloptions).[`methodName`](#methodname-1)

##### nonce?

> `optional` **nonce?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/api.ts:128](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L128)

An optional nonce to use for the call, used to prevent replay attacks.

###### Inherited from

[`CallOptions`](#calloptions).[`nonce`](#nonce-1)

##### onPollingStarted?

> `optional` **onPollingStarted?**: () => `void`

Defined in: [packages/core/src/agent/agent/api.ts:141](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L141)

An optional callback that will be invoked once the agent starts polling for the result of the
update call.

If `callSync` is set to false, polling will start, and the callback will be invoked, once the
request has been accepted by a single node. If `callSync` is set to true, the IC will first
try to process the request synchronously. But if the synchronous request timeout is exceeded,
the agent will start polling for the result, at which point the callback will be invoked.

###### Returns

`void`

***

### UpdateResult

Defined in: [packages/core/src/agent/agent/api.ts:196](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L196)

The result of [Agent.update](#update-1), extending [PollForResponseResult](#pollforresponseresult)
with the request details and raw HTTP response from the call.

#### Extends

- [`PollForResponseResult`](#pollforresponseresult)

#### Properties

##### callResponse

> **callResponse**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:200](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L200)

The raw HTTP response from the call endpoint.

###### body

> **body**: [`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

###### ok

> **ok**: `boolean`

###### status

> **status**: `number`

###### statusText

> **statusText**: `string`

##### certificate

> **certificate**: [`Certificate`](#certificate)

Defined in: [packages/core/src/agent/polling/types.ts:23](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L23)

The certificate for the request, which can be used to verify the reply.

###### Inherited from

[`PollForResponseResult`](#pollforresponseresult).[`certificate`](#certificate-3)

##### rawCertificate

> **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:27](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L27)

The raw certificate bytes for the request.

###### Inherited from

[`PollForResponseResult`](#pollforresponseresult).[`rawCertificate`](#rawcertificate-1)

##### reply

> **reply**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:25](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L25)

The reply bytes for the request.

###### Inherited from

[`PollForResponseResult`](#pollforresponseresult).[`reply`](#reply)

##### requestDetails?

> `optional` **requestDetails?**: [`CallRequest`](#callrequest)

Defined in: [packages/core/src/agent/agent/api.ts:198](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L198)

The request details from the call, if available.

***

### v2ResponseBody

Defined in: [packages/core/src/agent/agent/api.ts:148](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L148)

#### Properties

##### error\_code?

> `optional` **error\_code?**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:149](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L149)

##### reject\_code

> **reject\_code**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:150](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L150)

##### reject\_message

> **reject\_message**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:151](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L151)

***

### v4ResponseBody

Defined in: [packages/core/src/agent/agent/api.ts:165](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L165)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:166](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L166)

## Type Aliases

### ActorConstructor

> **ActorConstructor** = (`config`) => [`ActorSubclass`](#actorsubclass)

Defined in: [packages/core/src/agent/actor.ts:375](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L375)

#### Parameters

##### config

[`ActorConfig`](#actorconfig)

#### Returns

[`ActorSubclass`](#actorsubclass)

***

### ActorMethodMappedExtended

> **ActorMethodMappedExtended**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodExtended<Args, Ret> : never }`

Defined in: [packages/core/src/agent/actor.ts:155](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L155)

#### Type Parameters

##### T

`T`

***

### ActorMethodMappedWithHttpDetails

> **ActorMethodMappedWithHttpDetails**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodWithHttpDetails<Args, Ret> : never }`

Defined in: [packages/core/src/agent/actor.ts:148](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L148)

#### Type Parameters

##### T

`T`

***

### ActorSubclass

> **ActorSubclass**\<`T`\> = [`Actor`](#actor) & `T`

Defined in: [packages/core/src/agent/actor.ts:108](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L108)

A subclass of an actor. Actor class itself is meant to be a based class.

#### Type Parameters

##### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\>

***

### AgentLog

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](#agenterror); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/core/src/agent/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L25)

***

### ApiQueryResponse

> **ApiQueryResponse** = [`QueryResponse`](#queryresponse) & `object`

Defined in: [packages/core/src/agent/agent/api.ts:47](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L47)

#### Type Declaration

##### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](#httpdetailsresponse)

##### requestId

> **requestId**: [`RequestId`](#requestid-9)

***

### CanisterRanges

> **CanisterRanges** = \[[`Principal`](../../principal/api.md#principal), [`Principal`](../../principal/api.md#principal)\][]

Defined in: [packages/core/src/agent/certificate.ts:886](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L886)

Canister ranges in the form of an array of [start, end] principal tuples,
usually decoded from the certificate.

***

### CertificatePrincipal

> **CertificatePrincipal** = \{ `canisterId`: [`Principal`](../../principal/api.md#principal); \} \| \{ `subnetId`: [`Principal`](../../principal/api.md#principal); \}

Defined in: [packages/core/src/agent/certificate.ts:155](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L155)

#### Union Members

##### Type Literal

\{ `canisterId`: [`Principal`](../../principal/api.md#principal); \}

###### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

The effective canister ID of the request when verifying a response, or
the signing canister ID when verifying a certified variable.

***

##### Type Literal

\{ `subnetId`: [`Principal`](../../principal/api.md#principal); \}

###### subnetId

> **subnetId**: [`Principal`](../../principal/api.md#principal)

The subnet ID when verifying a certificate from a subnet.

***

### DerEncodedPublicKey

> **DerEncodedPublicKey** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/auth.ts:17](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L17)

A public key that is DER encoded. This is a branded Uint8Array.

#### Type Declaration

##### \_\_derEncodedPublicKey\_\_?

> `optional` **\_\_derEncodedPublicKey\_\_?**: `void`

***

### EmptyHashTree

> **EmptyHashTree** = \[[`Empty`](#empty)\]

Defined in: [packages/core/src/agent/certificate.ts:60](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L60)

***

### Envelope

> **Envelope**\<`T`\> = [`Signed`](#signed)\<`T`\> \| [`UnSigned`](#unsigned)\<`T`\>

Defined in: [packages/core/src/agent/agent/http/types.ts:53](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L53)

#### Type Parameters

##### T

`T`

***

### ForkHashTree

> **ForkHashTree** = \[[`Fork`](#fork), [`HashTree`](#hashtree), [`HashTree`](#hashtree)\]

Defined in: [packages/core/src/agent/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L61)

***

### FunctionWithArgsAndReturn

> **FunctionWithArgsAndReturn**\<`Args`, `Ret`\> = (...`args`) => `Ret`

Defined in: [packages/core/src/agent/actor.ts:143](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L143)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

#### Parameters

##### args

...`Args`

#### Returns

`Ret`

***

### HashTree

> **HashTree** = [`EmptyHashTree`](#emptyhashtree) \| [`ForkHashTree`](#forkhashtree) \| [`LabeledHashTree`](#labeledhashtree) \| [`LeafHashTree`](#leafhashtree) \| [`PrunedHashTree`](#prunedhashtree)

Defined in: [packages/core/src/agent/certificate.ts:66](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L66)

***

### HttpAgentRequest

> **HttpAgentRequest** = [`HttpAgentQueryRequest`](#httpagentqueryrequest) \| [`HttpAgentSubmitRequest`](#httpagentsubmitrequest) \| [`HttpAgentReadStateRequest`](#httpagentreadstaterequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:16](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L16)

***

### HttpHeaderField

> **HttpHeaderField** = \[`string`, `string`\]

Defined in: [packages/core/src/agent/agent/http/types.ts:26](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L26)

***

### IdentityDescriptor

> **IdentityDescriptor** = [`AnonymousIdentityDescriptor`](#anonymousidentitydescriptor) \| [`PublicKeyIdentityDescriptor`](#publickeyidentitydescriptor)

Defined in: [packages/core/src/agent/auth.ts:133](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L133)

***

### LabeledHashTree

> **LabeledHashTree** = \[[`Labeled`](#labeled), [`NodeLabel`](#nodelabel), [`HashTree`](#hashtree)\]

Defined in: [packages/core/src/agent/certificate.ts:62](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L62)

***

### LabelLookupResult

> **LabelLookupResult** = [`LookupLabelResultAbsent`](#lookuplabelresultabsent) \| [`LookupLabelResultUnknown`](#lookuplabelresultunknown) \| [`LookupLabelResultFound`](#lookuplabelresultfound) \| [`LookupLabelResultGreater`](#lookuplabelresultgreater) \| [`LookupLabelResultLess`](#lookuplabelresultless)

Defined in: [packages/core/src/agent/certificate.ts:600](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L600)

***

### LeafHashTree

> **LeafHashTree** = \[[`Leaf`](#leaf), [`NodeValue`](#nodevalue)\]

Defined in: [packages/core/src/agent/certificate.ts:63](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L63)

***

### LookupResult

> **LookupResult** = [`LookupPathResultAbsent`](#lookuppathresultabsent) \| [`LookupPathResultUnknown`](#lookuppathresultunknown) \| [`LookupPathResultFound`](#lookuppathresultfound) \| [`LookupPathResultError`](#lookuppathresulterror)

Defined in: [packages/core/src/agent/certificate.ts:541](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L541)

***

### NodeHash

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L58)

#### Type Declaration

##### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`

***

### NodeLabel

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L56)

#### Type Declaration

##### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`

***

### NodePath

> **NodePath** = (`Uint8Array` \| `string`)[]

Defined in: [packages/core/src/agent/certificate.ts:55](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L55)

***

### NodeValue

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:57](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L57)

#### Type Declaration

##### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`

***

### Nonce

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/agent/http/types.ts:125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L125)

#### Type Declaration

##### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`

***

### ObserveFunction

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/core/src/agent/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/observable.ts#L3)

#### Type Parameters

##### T

`T`

#### Parameters

##### data

`T`

##### rest

...`unknown`[]

#### Returns

`void`

***

### PollStrategy

> **PollStrategy** = (`canisterId`, `requestId`, `status`) => `Promise`\<`void`\>

Defined in: [packages/core/src/agent/polling/types.ts:6](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L6)

#### Parameters

##### canisterId

[`Principal`](../../principal/api.md#principal)

##### requestId

[`RequestId`](#requestid-9)

##### status

[`RequestStatusResponseStatus`](#requeststatusresponsestatus)

#### Returns

`Promise`\<`void`\>

***

### PrunedHashTree

> **PrunedHashTree** = \[[`Pruned`](#pruned), [`NodeHash`](#nodehash)\]

Defined in: [packages/core/src/agent/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L64)

***

### QueryResponse

> **QueryResponse** = [`QueryResponseReplied`](#queryresponsereplied) \| [`QueryResponseRejected`](#queryresponserejected)

Defined in: [packages/core/src/agent/agent/api.ts:33](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L33)

***

### QueryStrategy

> **QueryStrategy** = `"query"` \| `"update"`

Defined in: [packages/core/src/agent/actor.ts:25](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L25)

Controls how query and composite_query methods are executed.

- `'query'` — standard non-replicated query call (default).
- `'update'` — send query methods as update calls that go through consensus.

***

### ReadRequest

> **ReadRequest** = [`QueryRequest`](#queryrequest) \| [`ReadStateRequest`](#readstaterequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L103)

***

### RequestId

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/request_id.ts#L8)

#### Type Declaration

##### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`

***

### Signature

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L22)

A signature array buffer.

#### Type Declaration

##### \_\_signature\_\_

> **\_\_signature\_\_**: `void`

***

### SubtreeLookupResult

> **SubtreeLookupResult** = [`LookupSubtreeResultAbsent`](#lookupsubtreeresultabsent) \| [`LookupSubtreeResultUnknown`](#lookupsubtreeresultunknown) \| [`LookupSubtreeResultFound`](#lookupsubtreeresultfound)

Defined in: [packages/core/src/agent/certificate.ts:566](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L566)

## Variables

### ACTOR\_METHOD\_WITH\_CERTIFICATE

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/core/src/agent/actor.ts:378](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L378)

***

### ACTOR\_METHOD\_WITH\_HTTP\_DETAILS

> `const` **ACTOR\_METHOD\_WITH\_HTTP\_DETAILS**: `"http-details"` = `'http-details'`

Defined in: [packages/core/src/agent/actor.ts:377](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/actor.ts#L377)

***

### BLS12\_381\_G2\_OID

> `const` **BLS12\_381\_G2\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:116](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L116)

***

### Cbor

> `const` **Cbor**: `object`

Defined in: [packages/core/src/agent/cbor.ts:60](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/cbor.ts#L60)

#### Type Declaration

##### decode

> **decode**: \<`T`\>(`input`) => `T`

Decode a CBOR encoded value into a JavaScript value.

###### Type Parameters

###### T

`T`

###### Parameters

###### input

`Uint8Array`

The CBOR encoded value

###### Returns

`T`

##### encode

> **encode**: (`value`) => `Uint8Array`

Encode a JavaScript value into CBOR. If the value is an instance of [ToCborValue](#abstract-tocborvalue),
the [ToCborValue.toCborValue](#tocborvalue) method will be called to get the value to encode.

###### Parameters

###### value

`unknown`

The value to encode

###### Returns

`Uint8Array`

***

### DEFAULT\_POLLING\_OPTIONS

> `const` **DEFAULT\_POLLING\_OPTIONS**: [`PollingOptions`](#pollingoptions-2)

Defined in: [packages/core/src/agent/polling/index.ts:65](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L65)

***

### DER\_COSE\_OID

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:90](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L90)

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE

***

### ED25519\_OID

> `const` **ED25519\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:99](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L99)

A DER encoded `SEQUENCE(OID)` for the Ed25519 algorithm

***

### IC\_REQUEST\_AUTH\_DELEGATION\_DOMAIN\_SEPARATOR

> `const` **IC\_REQUEST\_AUTH\_DELEGATION\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:22](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/constants.ts#L22)

The `\x1Aic-request-auth-delegation` domain separator used in the signature of delegations.

***

### IC\_REQUEST\_DOMAIN\_SEPARATOR

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/constants.ts#L12)

The `\x0Aic-request` domain separator used in the signature of IC requests.

***

### IC\_RESPONSE\_DOMAIN\_SEPARATOR

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:17](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/constants.ts#L17)

The `\x0Bic-response` domain separator used in the signature of IC responses.

***

### IC\_ROOT\_KEY

> `const` **IC\_ROOT\_KEY**: `string`

Defined in: [packages/core/src/agent/agent/http/index.ts:109](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L109)

***

### IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR

> `const` **IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/constants.ts#L7)

The `\x0Dic-state-root` domain separator used in the root hash of IC certificates.

***

### JSON\_KEY\_EXPIRY

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:4](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/expiry.ts#L4)

***

### MANAGEMENT\_CANISTER\_ID

> `const` **MANAGEMENT\_CANISTER\_ID**: `"aaaaa-aa"` = `'aaaaa-aa'`

Defined in: [packages/core/src/agent/agent/http/index.ts:115](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L115)

***

### SECP256K1\_OID

> `const` **SECP256K1\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:108](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L108)

A DER encoded `SEQUENCE(OID)` for secp256k1 with the ECDSA algorithm

***

### UNREACHABLE\_ERROR

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/core/src/agent/errors.ts:962](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/errors.ts#L962)

Special error used to indicate that a code path is unreachable.

For internal use only.

***

### verify

> **verify**: (`pk`, `sig`, `msg`) => `boolean`

Defined in: [packages/core/src/agent/utils/bls.ts:4](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/bls.ts#L4)

#### Parameters

##### pk

`Uint8Array`

##### sig

`Uint8Array`

##### msg

`Uint8Array`

#### Returns

`boolean`

## Functions

### blsVerify()

> **blsVerify**(`pk`, `sig`, `msg`): `boolean`

Defined in: [packages/core/src/agent/utils/bls.ts:13](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/bls.ts#L13)

#### Parameters

##### pk

`Uint8Array`

primary key: Uint8Array

##### sig

`Uint8Array`

signature: Uint8Array

##### msg

`Uint8Array`

message: Uint8Array

#### Returns

`boolean`

boolean

***

### calculateIngressExpiry()

> **calculateIngressExpiry**(`maxIngressExpiryInMinutes`, `timeDiffMsecs`): [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/index.ts:1708](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/index.ts#L1708)

Calculates the ingress expiry time based on the maximum allowed expiry in minutes and the time difference in milliseconds.
The expiry is rounded down according to the [Expiry.fromDeltaInMilliseconds](#fromdeltainmilliseconds) method.

#### Parameters

##### maxIngressExpiryInMinutes

`number`

The maximum ingress expiry time in minutes.

##### timeDiffMsecs

`number`

The time difference in milliseconds to adjust the expiry.

#### Returns

[`Expiry`](#expiry)

The calculated ingress expiry as an Expiry object.

***

### check\_canister\_ranges()

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/core/src/agent/certificate.ts:896](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L896)

Check if a canister ID falls within the canister ranges of a given subnet

#### Parameters

##### params

[`CheckCanisterRangesParams`](#checkcanisterrangesparams)

the parameters with which to check the canister ranges

#### Returns

`boolean`

`true` if the canister is in the range, `false` otherwise

***

### constructRequest()

> **constructRequest**(`options`): `Promise`\<[`ReadStateRequest`](#readstaterequest)\>

Defined in: [packages/core/src/agent/polling/index.ts:219](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L219)

Constructs a read state request for the given paths.
If the request is already signed and has an expiry, it will be returned as is.
Otherwise, a new request will be created.

#### Parameters

##### options

The options to use for creating the request.

###### agent

[`Agent`](#agent-1)

The agent to use to create the request.

###### paths

`Uint8Array`\<`ArrayBufferLike`\>[][]

The paths to read from.

###### pollingOptions

[`PollingOptions`](#pollingoptions-2)

The options to use for creating the request.

#### Returns

`Promise`\<[`ReadStateRequest`](#readstaterequest)\>

The read state request.

***

### createIdentityDescriptor()

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](#identitydescriptor)

Defined in: [packages/core/src/agent/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/auth.ts#L139)

Create an IdentityDescriptor from an Identity

#### Parameters

##### identity

[`SignIdentity`](#abstract-signidentity) \| [`AnonymousIdentity`](#anonymousidentity)

identity describe in returned descriptor

#### Returns

[`IdentityDescriptor`](#identitydescriptor)

***

### decodeCanisterRanges()

> **decodeCanisterRanges**(`lookupValue`): [`CanisterRanges`](#canisterranges)

Defined in: [packages/core/src/agent/certificate.ts:973](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L973)

Decode canister ranges from CBOR-encoded buffer

#### Parameters

##### lookupValue

`Uint8Array`

the CBOR-encoded value read from the certificate

#### Returns

[`CanisterRanges`](#canisterranges)

an array of canister range tuples [start, end]

***

### decodeLen()

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:70](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L70)

#### Parameters

##### buf

`Uint8Array`

##### offset

`number`

#### Returns

`number`

***

### decodeLenBytes()

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:51](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L51)

#### Parameters

##### buf

`Uint8Array`

##### offset

`number`

#### Returns

`number`

***

### domain\_sep()

> **domain\_sep**(`s`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:507](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L507)

Creates a domain separator for hashing by encoding the input string
with its length as a prefix.

#### Parameters

##### s

`string`

The input string to encode.

#### Returns

`Uint8Array`

A Uint8Array containing the encoded domain separator.

***

### encodeLen()

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/core/src/agent/der.ts:25](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L25)

#### Parameters

##### buf

`Uint8Array`

##### offset

`number`

##### len

`number`

#### Returns

`number`

***

### encodeLenBytes()

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/core/src/agent/der.ts:9](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L9)

#### Parameters

##### len

`number`

#### Returns

`number`

***

### fetchCandid()

> **fetchCandid**(`canisterId`, `agent?`): `Promise`\<`string`\>

Defined in: [packages/core/src/agent/fetch\_candid.ts:13](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/fetch_candid.ts#L13)

Retrieves the Candid interface for the specified canister.

#### Parameters

##### canisterId

`string`

A string corresponding to the canister ID

##### agent?

[`HttpAgent`](#httpagent)

The agent to use for the request (usually an `HttpAgent`)

#### Returns

`Promise`\<`string`\>

Candid source code

***

### find\_label()

> **find\_label**(`label`, `tree`): [`LabelLookupResult`](#labellookupresult)

Defined in: [packages/core/src/agent/certificate.ts:750](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L750)

Find a label in a tree

#### Parameters

##### label

[`NodeLabel`](#nodelabel)

the label to find

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

[`LabelLookupResult`](#labellookupresult)

the result of the label lookup

***

### flatten\_forks()

> **flatten\_forks**(`t`): ([`LabeledHashTree`](#labeledhashtree) \| [`LeafHashTree`](#leafhashtree) \| [`PrunedHashTree`](#prunedhashtree))[]

Defined in: [packages/core/src/agent/certificate.ts:733](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L733)

If the tree is a fork, flatten it into an array of trees

#### Parameters

##### t

[`HashTree`](#hashtree)

the tree to flatten

#### Returns

([`LabeledHashTree`](#labeledhashtree) \| [`LeafHashTree`](#leafhashtree) \| [`PrunedHashTree`](#prunedhashtree))[]

the flattened tree

***

### getSubnetIdFromCertificate()

> **getSubnetIdFromCertificate**(`certificate`, `rootKey`): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/certificate.ts:1052](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L1052)

Get the subnet ID from a certificate
If the certificate has a delegation, it returns the subnet ID from the delegation.
If the certificate has no delegation, it returns the root subnet ID.

#### Parameters

##### certificate

[`Cert`](#cert-1)

the certificate to get the subnet ID from

##### rootKey

`Uint8Array`

the root key to use to get the subnet ID

#### Returns

[`Principal`](../../principal/api.md#principal)

the subnet ID

***

### hashOfMap()

> **hashOfMap**(`map`): `Uint8Array`

Defined in: [packages/core/src/agent/request\_id.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/request_id.ts#L80)

Hash a map into a Uint8Array using the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

#### Parameters

##### map

`Record`\<`string`, `unknown`\>

Any non-nested object

#### Returns

`Uint8Array`

Uint8Array

***

### hashTreeToString()

> **hashTreeToString**(`tree`): `string`

Defined in: [packages/core/src/agent/certificate.ts:77](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L77)

Make a human readable string out of a hash tree.

#### Parameters

##### tree

[`HashTree`](#hashtree)

The hash tree to convert to a string

#### Returns

`string`

***

### hashValue()

> **hashValue**(`value`): `Uint8Array`

Defined in: [packages/core/src/agent/request\_id.ts:19](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/request_id.ts#L19)

#### Parameters

##### value

`unknown`

unknown value

#### Returns

`Uint8Array`

Uint8Array

***

### httpHeadersTransform()

> **httpHeadersTransform**(`headers`): [`HttpHeaderField`](#httpheaderfield)[]

Defined in: [packages/core/src/agent/agent/http/transforms.ts:48](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/transforms.ts#L48)

Maps the default fetch headers field to the serializable HttpHeaderField.

#### Parameters

##### headers

`Headers`

Fetch definition of the headers type

#### Returns

[`HttpHeaderField`](#httpheaderfield)[]

array of header fields

***

### isV2ResponseBody()

> **isV2ResponseBody**(`body`): `body is v2ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:159](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L159)

Utility function to check if a body is a v2ResponseBody for type safety.

#### Parameters

##### body

[`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

The body to check

#### Returns

`body is v2ResponseBody`

boolean indicating if the body is a v2ResponseBody

***

### isV4ResponseBody()

> **isV4ResponseBody**(`body`): `body is v4ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:174](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/api.ts#L174)

Utility function to check if a body is a v4ResponseBody for type safety.

#### Parameters

##### body

[`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

The body to check

#### Returns

`body is v4ResponseBody`

boolean indicating if the body is a v4ResponseBody

***

### lookup\_path()

> **lookup\_path**(`path`, `tree`): [`LookupResult`](#lookupresult)

Defined in: [packages/core/src/agent/certificate.ts:613](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L613)

Lookup a path in a tree. If the path is a subtree, use [lookup\_subtree](#lookup_subtree-1) instead.

#### Parameters

##### path

[`NodePath`](#nodepath)

the path to look up

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

[`LookupResult`](#lookupresult)

the result of the lookup

***

### lookup\_subtree()

> **lookup\_subtree**(`path`, `tree`): [`SubtreeLookupResult`](#subtreelookupresult)

Defined in: [packages/core/src/agent/certificate.ts:692](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L692)

Lookup a subtree in a tree.

#### Parameters

##### path

[`NodePath`](#nodepath)

the path to look up

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

[`SubtreeLookupResult`](#subtreelookupresult)

the result of the lookup

***

### lookupCanisterRanges()

> **lookupCanisterRanges**(`params`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:919](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L919)

Lookup the canister ranges using the `/canister_ranges/<subnet_id>/<ranges>` path.
Certificates returned by `/api/v4/canister/<effective_canister_id>/call`
and `/api/v3/canister/<effective_canister_id>/read_state` use this path.

If the new lookup is not found, it tries the fallback lookup with [lookupCanisterRangesFallback](#lookupcanisterrangesfallback).

#### Parameters

##### params

[`CheckCanisterRangesParams`](#checkcanisterrangesparams)

the parameters with which to lookup the canister ranges

#### Returns

`Uint8Array`

the encoded canister ranges. Use [decodeCanisterRanges](#decodecanisterranges) to decode them.

#### See

 - https://internetcomputer.org/docs/references/ic-interface-spec#http-read-state
 - https://internetcomputer.org/docs/references/ic-interface-spec#state-tree-canister-ranges

***

### lookupCanisterRangesFallback()

> **lookupCanisterRangesFallback**(`subnetId`, `tree`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:955](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L955)

Lookup the canister ranges using the `/subnet/<subnet_id>/canister_ranges` path.
Certificates returned by `/api/v3/canister/<effective_canister_id>/call`
and `/api/v2/canister/<effective_canister_id>/read_state` use this path.

#### Parameters

##### subnetId

[`Principal`](../../principal/api.md#principal)

the subnet ID to lookup the canister ranges for

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

`Uint8Array`

the encoded canister ranges. Use [decodeCanisterRanges](#decodecanisterranges) to decode them.

#### See

https://internetcomputer.org/docs/references/ic-interface-spec#http-read-state

***

### lookupResultToBuffer()

> **lookupResultToBuffer**(`result`): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/agent/certificate.ts:463](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L463)

Utility function to constrain the type of a lookup result

#### Parameters

##### result

[`LookupResult`](#lookupresult)

the result of a lookup

#### Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

the value if the lookup was found, `undefined` otherwise

***

### makeExpiryTransform()

> **makeExpiryTransform**(`delayInMilliseconds`): [`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

Defined in: [packages/core/src/agent/agent/http/transforms.ts:37](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/transforms.ts#L37)

Create a transform that adds a delay (by default 5 minutes) to the expiry.

#### Parameters

##### delayInMilliseconds

`number`

The delay to add to the call time, in milliseconds.

#### Returns

[`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

***

### makeNonce()

> **makeNonce**(): [`Nonce`](#nonce-5)

Defined in: [packages/core/src/agent/agent/http/types.ts:130](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/types.ts#L130)

Create a random Nonce, based on random values

#### Returns

[`Nonce`](#nonce-5)

***

### makeNonceTransform()

> **makeNonceTransform**(`nonceFn?`): [`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

Defined in: [packages/core/src/agent/agent/http/transforms.ts:18](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/agent/http/transforms.ts#L18)

Create a Nonce transform, which takes a function that returns a Buffer, and adds it
as the nonce to every call requests.

#### Parameters

##### nonceFn?

() => [`Nonce`](#nonce-5)

A function that returns a buffer. By default uses a semi-random method.

#### Returns

[`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

***

### pollForResponse()

> **pollForResponse**(`agent`, `canisterId`, `requestId`, `options?`): `Promise`\<[`PollForResponseResult`](#pollforresponseresult)\>

Defined in: [packages/core/src/agent/polling/index.ts:126](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/index.ts#L126)

Polls the IC to check the status of the given request then
returns the response bytes once the request has been processed.

#### Parameters

##### agent

[`Agent`](#agent-1)

The agent to use to poll read_state.

##### canisterId

[`Principal`](../../principal/api.md#principal)

The effective canister ID.

##### requestId

[`RequestId`](#requestid-9)

The Request ID to poll status for.

##### options?

[`PollingOptions`](#pollingoptions-2) = `{}`

polling options to control behavior

#### Returns

`Promise`\<[`PollForResponseResult`](#pollforresponseresult)\>

The certificate, reply bytes, and raw certificate bytes for the request.

#### Throws

If the agent's root key is not available.

#### Throws

If the request was rejected by the canister.

#### Throws

If the request reached `done` status without a reply.

***

### randomNumber()

> **randomNumber**(): `number`

Defined in: [packages/core/src/agent/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff

#### Returns

`number`

a random number

***

### reconstruct()

> **reconstruct**(`t`): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/certificate.ts:478](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/certificate.ts#L478)

#### Parameters

##### t

[`HashTree`](#hashtree)

The hash tree to reconstruct

#### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

***

### requestIdOf()

> **requestIdOf**(`request`): [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/request\_id.ts:70](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/request_id.ts#L70)

Get the RequestId of the provided ic-ref request.
RequestId is the result of the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

#### Parameters

##### request

`Record`\<`string`, `unknown`\>

ic-ref request to hash into RequestId

#### Returns

[`RequestId`](#requestid-9)

***

### uint8Equals()

> **uint8Equals**(`a`, `b`): `boolean`

Defined in: [packages/core/src/agent/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/buffer.ts#L54)

Compares two Uint8Arrays for equality.

#### Parameters

##### a

`Uint8Array`

The first Uint8Array.

##### b

`Uint8Array`

The second Uint8Array.

#### Returns

`boolean`

True if the Uint8Arrays are equal, false otherwise.

***

### uint8FromBufLike()

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/agent/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.

#### Parameters

##### bufLike

`ArrayBufferLike` \| `Uint8Array`\<`ArrayBufferLike`\> \| `number`[] \| `DataView`\<`ArrayBufferLike`\> \| `ArrayBufferView`\<`ArrayBufferLike`\> \| \[`number`\] \| \{ `buffer`: `ArrayBuffer`; \}

a buffer-like object

#### Returns

`Uint8Array`

Uint8Array

***

### uint8ToBuf()

> **uint8ToBuf**(`arr`): `ArrayBuffer`

Defined in: [packages/core/src/agent/utils/buffer.ts:41](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/buffer.ts#L41)

Returns a true ArrayBuffer from a Uint8Array, as Uint8Array.buffer is unsafe.

#### Parameters

##### arr

`Uint8Array`

Uint8Array to convert

#### Returns

`ArrayBuffer`

ArrayBuffer

***

### unwrapDER()

> **unwrapDER**(`derEncoded`, `oid`): `Uint8Array`

Defined in: [packages/core/src/agent/der.ts:165](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L165)

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`

#### Parameters

##### derEncoded

`Uint8Array`

The DER encoded and tagged data

##### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

#### Returns

`Uint8Array`

The unwrapped payload

***

### wrapDER()

> **wrapDER**(`payload`, `oid`): `Uint8Array`

Defined in: [packages/core/src/agent/der.ts:132](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/der.ts#L132)

Wraps the given `payload` in a DER encoding tagged with the given encoded `oid` like so:
`SEQUENCE(oid, BITSTRING(payload))`

#### Parameters

##### payload

`Uint8Array`

The payload to encode as the bit string

##### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) OID to tag the payload with

#### Returns

`Uint8Array`

## References

### defaultStrategy

Re-exports [defaultStrategy](namespaces/strategy.md#defaultstrategy)
