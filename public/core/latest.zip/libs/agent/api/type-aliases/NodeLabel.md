---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:54](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L54)


### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
