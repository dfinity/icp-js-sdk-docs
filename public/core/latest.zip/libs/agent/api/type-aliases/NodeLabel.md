---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L56)

## Type declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
