---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L56)

## Type Declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
