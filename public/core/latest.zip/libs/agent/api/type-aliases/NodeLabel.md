---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:54](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L54)


### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
