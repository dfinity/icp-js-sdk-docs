---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:54](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L54)

## Type declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
