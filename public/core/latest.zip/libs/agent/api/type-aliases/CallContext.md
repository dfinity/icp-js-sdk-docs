---
title: CallContext
editUrl: false
next: true
prev: true
---

> **CallContext** = `object`

Defined in: [packages/agent/src/errors.ts:31](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/errors.ts#L31)


### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/errors.ts:32](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/errors.ts#L32)

***

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](../interfaces/HttpDetailsResponse.md)

Defined in: [packages/agent/src/errors.ts:34](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/errors.ts#L34)

***

### methodName

> **methodName**: `string`

Defined in: [packages/agent/src/errors.ts:33](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/errors.ts#L33)
