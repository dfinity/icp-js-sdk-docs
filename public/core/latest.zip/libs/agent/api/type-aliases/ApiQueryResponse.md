---
title: ApiQueryResponse
editUrl: false
next: true
prev: true
---

> **ApiQueryResponse** = [`QueryResponse`](QueryResponse.md) & `object`

Defined in: [packages/agent/src/agent/api.ts:46](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L46)

## Type declaration

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](../interfaces/HttpDetailsResponse.md)

### requestId

> **requestId**: [`RequestId`](RequestId.md)
