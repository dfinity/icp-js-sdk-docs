---
title: ApiQueryResponse
editUrl: false
next: true
prev: true
---

> **ApiQueryResponse** = [`QueryResponse`](QueryResponse.md) & `object`

Defined in: [packages/agent/src/agent/api.ts:46](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L46)

## Type declaration

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](../interfaces/HttpDetailsResponse.md)

### requestId

> **requestId**: [`RequestId`](RequestId.md)
