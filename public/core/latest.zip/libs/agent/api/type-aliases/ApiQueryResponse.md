---
title: ApiQueryResponse
editUrl: false
next: true
prev: true
---

> **ApiQueryResponse** = [`QueryResponse`](QueryResponse.md) & `object`

Defined in: [packages/core/src/agent/agent/api.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L46)

## Type declaration

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](../interfaces/HttpDetailsResponse.md)

### requestId

> **requestId**: [`RequestId`](RequestId.md)
