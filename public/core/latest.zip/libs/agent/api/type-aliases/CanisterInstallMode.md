---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

> **CanisterInstallMode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/agent/src/actor.ts:152](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/actor.ts#L152)

The mode used when installing a canister.
