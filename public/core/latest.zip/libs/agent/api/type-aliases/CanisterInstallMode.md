---
title: CanisterInstallMode
editUrl: false
next: true
prev: true
---

> **CanisterInstallMode** = \{ `reinstall`: `null`; \} \| \{ `upgrade`: \[\] \| \[\{ `skip_pre_upgrade`: \[\] \| \[`boolean`\]; \}\]; \} \| \{ `install`: `null`; \}

Defined in: [packages/agent/src/actor.ts:152](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/actor.ts#L152)

The mode used when installing a canister.
