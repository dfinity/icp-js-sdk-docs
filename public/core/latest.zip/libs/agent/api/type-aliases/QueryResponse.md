---
title: QueryResponse
editUrl: false
next: true
prev: true
---

> **QueryResponse** = [`QueryResponseReplied`](../interfaces/QueryResponseReplied.md) \| [`QueryResponseRejected`](../interfaces/QueryResponseRejected.md)

Defined in: [packages/agent/src/agent/api.ts:32](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L32)
