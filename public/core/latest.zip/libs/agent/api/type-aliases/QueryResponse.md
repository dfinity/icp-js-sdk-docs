---
title: QueryResponse
editUrl: false
next: true
prev: true
---

> **QueryResponse** = [`QueryResponseReplied`](../interfaces/QueryResponseReplied.md) \| [`QueryResponseRejected`](../interfaces/QueryResponseRejected.md)

Defined in: [packages/agent/src/agent/api.ts:32](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/agent/api.ts#L32)
