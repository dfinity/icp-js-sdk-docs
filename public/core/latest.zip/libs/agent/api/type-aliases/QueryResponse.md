---
title: QueryResponse
editUrl: false
next: true
prev: true
---

> **QueryResponse** = [`QueryResponseReplied`](../interfaces/QueryResponseReplied.md) \| [`QueryResponseRejected`](../interfaces/QueryResponseRejected.md)

Defined in: [packages/agent/src/agent/api.ts:32](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/api.ts#L32)
