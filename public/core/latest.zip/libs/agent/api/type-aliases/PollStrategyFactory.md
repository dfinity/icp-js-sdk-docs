---
title: PollStrategyFactory
editUrl: false
next: true
prev: true
---

> **PollStrategyFactory** = () => [`PollStrategy`](PollStrategy.md)

Defined in: [packages/agent/src/polling/index.ts:34](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/polling/index.ts#L34)


[`PollStrategy`](PollStrategy.md)
