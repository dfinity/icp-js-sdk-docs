---
title: ActorMethodMappedWithHttpDetails
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedWithHttpDetails**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodWithHttpDetails<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:136](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/actor.ts#L136)

## Type Parameters

### T

`T`
