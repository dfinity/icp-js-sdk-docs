---
title: ActorMethodMappedWithHttpDetails
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedWithHttpDetails**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodWithHttpDetails<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:136](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/actor.ts#L136)

## Type Parameters

### T

`T`
