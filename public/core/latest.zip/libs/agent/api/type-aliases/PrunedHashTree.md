---
title: PrunedHashTree
editUrl: false
next: true
prev: true
---

> **PrunedHashTree** = \[[`Pruned`](../enumerations/NodeType.md#pruned), [`NodeHash`](NodeHash.md)\]

Defined in: [packages/core/src/agent/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L64)
