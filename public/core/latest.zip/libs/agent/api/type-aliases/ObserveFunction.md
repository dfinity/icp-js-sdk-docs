---
title: ObserveFunction
editUrl: false
next: true
prev: true
---

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/core/src/agent/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/observable.ts#L3)

## Type Parameters

### T

`T`

## Parameters

### data

`T`

### rest

...`unknown`[]

## Returns

`void`
