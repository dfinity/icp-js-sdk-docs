---
title: HashTree
editUrl: false
next: true
prev: true
---

> **HashTree** = [`EmptyHashTree`](EmptyHashTree.md) \| [`ForkHashTree`](ForkHashTree.md) \| [`LabeledHashTree`](LabeledHashTree.md) \| [`LeafHashTree`](LeafHashTree.md) \| [`PrunedHashTree`](PrunedHashTree.md)

Defined in: [packages/agent/src/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L64)
