---
title: HashTree
editUrl: false
next: true
prev: true
---

> **HashTree** = [`EmptyHashTree`](EmptyHashTree.md) \| [`ForkHashTree`](ForkHashTree.md) \| [`LabeledHashTree`](LabeledHashTree.md) \| [`LeafHashTree`](LeafHashTree.md) \| [`PrunedHashTree`](PrunedHashTree.md)

Defined in: [packages/agent/src/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L64)
