---
title: ActorConstructor
editUrl: false
next: true
prev: true
---

> **ActorConstructor** = (`config`) => [`ActorSubclass`](ActorSubclass.md)

Defined in: [packages/agent/src/actor.ts:377](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/actor.ts#L377)


### config

[`ActorConfig`](../interfaces/ActorConfig.md)

## Returns

[`ActorSubclass`](ActorSubclass.md)
