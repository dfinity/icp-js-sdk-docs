---
title: ActorConstructor
editUrl: false
next: true
prev: true
---

> **ActorConstructor** = (`config`) => [`ActorSubclass`](ActorSubclass.md)

Defined in: [packages/agent/src/actor.ts:328](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/actor.ts#L328)


### config

[`ActorConfig`](../interfaces/ActorConfig.md)

## Returns

[`ActorSubclass`](ActorSubclass.md)
