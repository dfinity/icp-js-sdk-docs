---
title: ActorConstructor
editUrl: false
next: true
prev: true
---

> **ActorConstructor** = (`config`) => [`ActorSubclass`](ActorSubclass.md)

Defined in: [packages/agent/src/actor.ts:362](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/actor.ts#L362)

## Parameters

### config

[`ActorConfig`](../interfaces/ActorConfig.md)

## Returns

[`ActorSubclass`](ActorSubclass.md)
