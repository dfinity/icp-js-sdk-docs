---
title: ActorConstructor
editUrl: false
next: true
prev: true
---

> **ActorConstructor** = (`config`) => [`ActorSubclass`](ActorSubclass.md)

Defined in: [packages/core/src/agent/actor.ts:375](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/actor.ts#L375)

## Parameters

### config

[`ActorConfig`](../interfaces/ActorConfig.md)

## Returns

[`ActorSubclass`](ActorSubclass.md)
