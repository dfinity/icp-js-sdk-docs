---
title: ActorMethodMappedExtended
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedExtended**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodExtended<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:143](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L143)

## Type Parameters

### T

`T`
