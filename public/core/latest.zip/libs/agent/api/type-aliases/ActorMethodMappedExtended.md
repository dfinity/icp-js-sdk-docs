---
title: ActorMethodMappedExtended
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedExtended**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodExtended<Args, Ret> : never }`

Defined in: [packages/core/src/agent/actor.ts:155](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L155)

## Type Parameters

### T

`T`
