---
title: ActorMethodMappedExtended
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedExtended**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodExtended<Args, Ret> : never }`

Defined in: [packages/core/src/agent/actor.ts:155](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/actor.ts#L155)

## Type Parameters

### T

`T`
