---
title: AgentLog
editUrl: false
next: true
prev: true
---

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](../classes/AgentError.md); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/agent/src/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/observable.ts#L25)
