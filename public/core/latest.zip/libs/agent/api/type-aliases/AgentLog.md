---
title: AgentLog
editUrl: false
next: true
prev: true
---

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](../classes/AgentError.md); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/agent/src/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/observable.ts#L25)
