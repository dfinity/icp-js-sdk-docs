---
title: AgentLog
editUrl: false
next: true
prev: true
---

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](../classes/AgentError.md); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/agent/src/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/observable.ts#L25)
