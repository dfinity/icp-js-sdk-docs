---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

> **JsonnableExpiry** = `object`

Defined in: [packages/agent/src/agent/http/transforms.ts:27](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/transforms.ts#L27)

## Properties

### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/agent/src/agent/http/transforms.ts:28](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/transforms.ts#L28)
