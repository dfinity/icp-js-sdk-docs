---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

> **JsonnableExpiry** = `object`

Defined in: [packages/agent/src/agent/http/transforms.ts:28](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L28)

## Properties

### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/agent/src/agent/http/transforms.ts:29](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L29)
