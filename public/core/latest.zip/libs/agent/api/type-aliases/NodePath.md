---
title: NodePath
editUrl: false
next: true
prev: true
---

> **NodePath** = (`Uint8Array` \| `string`)[]

Defined in: [packages/agent/src/certificate.ts:53](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L53)
