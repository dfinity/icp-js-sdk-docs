---
title: NodePath
editUrl: false
next: true
prev: true
---

> **NodePath** = (`Uint8Array` \| `string`)[]

Defined in: [packages/agent/src/certificate.ts:53](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L53)
