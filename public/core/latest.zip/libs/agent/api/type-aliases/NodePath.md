---
title: NodePath
editUrl: false
next: true
prev: true
---

> **NodePath** = (`Uint8Array` \| `string`)[]

Defined in: [packages/agent/src/certificate.ts:53](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L53)
