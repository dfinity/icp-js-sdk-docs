---
title: NodeSignature
editUrl: false
next: true
prev: true
---

> **NodeSignature** = `object`

Defined in: [packages/agent/src/agent/api.ts:56](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L56)

## Properties

### identity

> **identity**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:62](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L62)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:60](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L60)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/agent/src/agent/api.ts:58](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L58)
