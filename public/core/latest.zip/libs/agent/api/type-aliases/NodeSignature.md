---
title: NodeSignature
editUrl: false
next: true
prev: true
---

> **NodeSignature** = `object`

Defined in: [packages/agent/src/agent/api.ts:56](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L56)

## Properties

### identity

> **identity**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:62](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L62)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:60](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L60)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/agent/src/agent/api.ts:58](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/api.ts#L58)
