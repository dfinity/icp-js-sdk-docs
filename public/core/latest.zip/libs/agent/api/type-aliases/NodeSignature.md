---
title: NodeSignature
editUrl: false
next: true
prev: true
---

> **NodeSignature** = `object`

Defined in: [packages/agent/src/agent/api.ts:56](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/api.ts#L56)


### identity

> **identity**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:62](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/api.ts#L62)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:60](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/api.ts#L60)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/agent/src/agent/api.ts:58](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/api.ts#L58)
