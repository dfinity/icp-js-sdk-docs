---
title: LabeledHashTree
editUrl: false
next: true
prev: true
---

> **LabeledHashTree** = \[[`Labeled`](../enumerations/NodeType.md#labeled), [`NodeLabel`](NodeLabel.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/core/src/agent/certificate.ts:62](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L62)
