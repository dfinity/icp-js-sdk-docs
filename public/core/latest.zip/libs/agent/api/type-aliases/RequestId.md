---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/request_id.ts#L8)

## Type Declaration

### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
