---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/request_id.ts#L8)

## Type Declaration

### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
