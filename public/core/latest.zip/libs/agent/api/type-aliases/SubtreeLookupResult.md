---
title: SubtreeLookupResult
editUrl: false
next: true
prev: true
---

> **SubtreeLookupResult** = [`LookupSubtreeResultAbsent`](../interfaces/LookupSubtreeResultAbsent.md) \| [`LookupSubtreeResultUnknown`](../interfaces/LookupSubtreeResultUnknown.md) \| [`LookupSubtreeResultFound`](../interfaces/LookupSubtreeResultFound.md)

Defined in: [packages/agent/src/certificate.ts:506](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L506)
