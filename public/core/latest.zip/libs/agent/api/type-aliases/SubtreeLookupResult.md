---
title: SubtreeLookupResult
editUrl: false
next: true
prev: true
---

> **SubtreeLookupResult** = [`LookupSubtreeResultAbsent`](../interfaces/LookupSubtreeResultAbsent.md) \| [`LookupSubtreeResultUnknown`](../interfaces/LookupSubtreeResultUnknown.md) \| [`LookupSubtreeResultFound`](../interfaces/LookupSubtreeResultFound.md)

Defined in: [packages/agent/src/certificate.ts:506](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L506)
