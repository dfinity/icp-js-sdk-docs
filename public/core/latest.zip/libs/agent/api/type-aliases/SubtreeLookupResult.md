---
title: SubtreeLookupResult
editUrl: false
next: true
prev: true
---

> **SubtreeLookupResult** = [`LookupSubtreeResultAbsent`](../interfaces/LookupSubtreeResultAbsent.md) \| [`LookupSubtreeResultUnknown`](../interfaces/LookupSubtreeResultUnknown.md) \| [`LookupSubtreeResultFound`](../interfaces/LookupSubtreeResultFound.md)

Defined in: [packages/agent/src/certificate.ts:506](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L506)
