---
title: HttpHeaderField
editUrl: false
next: true
prev: true
---

> **HttpHeaderField** = \[`string`, `string`\]

Defined in: [packages/agent/src/agent/http/types.ts:26](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L26)
