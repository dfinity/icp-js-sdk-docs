---
title: HttpHeaderField
editUrl: false
next: true
prev: true
---

> **HttpHeaderField** = \[`string`, `string`\]

Defined in: [packages/agent/src/agent/http/types.ts:26](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L26)
