---
title: HttpHeaderField
editUrl: false
next: true
prev: true
---

> **HttpHeaderField** = \[`string`, `string`\]

Defined in: [packages/core/src/agent/agent/http/types.ts:26](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L26)
