---
title: ForkHashTree
editUrl: false
next: true
prev: true
---

> **ForkHashTree** = \[[`Fork`](../enumerations/NodeType.md#fork), [`HashTree`](HashTree.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/agent/src/certificate.ts:59](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L59)
