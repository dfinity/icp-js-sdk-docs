---
title: ForkHashTree
editUrl: false
next: true
prev: true
---

> **ForkHashTree** = \[[`Fork`](../enumerations/NodeType.md#fork), [`HashTree`](HashTree.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/agent/src/certificate.ts:59](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L59)
