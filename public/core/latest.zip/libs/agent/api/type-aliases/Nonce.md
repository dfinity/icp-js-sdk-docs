---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/agent/http/types.ts:106](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/types.ts#L106)

## Type Declaration

### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
