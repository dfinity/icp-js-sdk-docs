---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/agent/src/agent/http/types.ts:106](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L106)


### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
