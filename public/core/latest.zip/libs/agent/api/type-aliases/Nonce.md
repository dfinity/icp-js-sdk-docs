---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/agent/src/agent/http/types.ts:106](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/types.ts#L106)

## Type declaration

### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
