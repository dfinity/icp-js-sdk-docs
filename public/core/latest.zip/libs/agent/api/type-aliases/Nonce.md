---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/agent/src/agent/http/types.ts:106](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L106)

## Type declaration

### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
