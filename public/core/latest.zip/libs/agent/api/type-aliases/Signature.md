---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L22)

A signature array buffer.

## Type declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
