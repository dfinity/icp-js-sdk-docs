---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/auth.ts#L22)

A signature array buffer.


### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
