---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/auth.ts#L22)

A signature array buffer.

## Type declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
