---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/auth.ts#L22)

A signature array buffer.


### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
