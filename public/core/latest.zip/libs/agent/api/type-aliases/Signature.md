---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/auth.ts#L22)

A signature array buffer.

## Type Declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
