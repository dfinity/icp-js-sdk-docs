---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/auth.ts#L22)

A signature array buffer.

## Type declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
