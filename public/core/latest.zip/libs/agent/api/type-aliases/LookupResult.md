---
title: LookupResult
editUrl: false
next: true
prev: true
---

> **LookupResult** = [`LookupPathResultAbsent`](../interfaces/LookupPathResultAbsent.md) \| [`LookupPathResultUnknown`](../interfaces/LookupPathResultUnknown.md) \| [`LookupPathResultFound`](../interfaces/LookupPathResultFound.md) \| [`LookupPathResultError`](../interfaces/LookupPathResultError.md)

Defined in: [packages/agent/src/certificate.ts:481](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L481)
