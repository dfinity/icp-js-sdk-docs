---
title: LookupResult
editUrl: false
next: true
prev: true
---

> **LookupResult** = [`LookupPathResultAbsent`](../interfaces/LookupPathResultAbsent.md) \| [`LookupPathResultUnknown`](../interfaces/LookupPathResultUnknown.md) \| [`LookupPathResultFound`](../interfaces/LookupPathResultFound.md) \| [`LookupPathResultError`](../interfaces/LookupPathResultError.md)

Defined in: [packages/agent/src/certificate.ts:481](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L481)
