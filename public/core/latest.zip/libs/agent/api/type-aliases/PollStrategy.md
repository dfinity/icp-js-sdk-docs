---
title: PollStrategy
editUrl: false
next: true
prev: true
---

> **PollStrategy** = (`canisterId`, `requestId`, `status`) => `Promise`\<`void`\>

Defined in: [packages/core/src/agent/polling/index.ts:28](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/polling/index.ts#L28)

## Parameters

### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](RequestId.md)

### status

[`RequestStatusResponseStatus`](../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`void`\>
