---
title: PollStrategy
editUrl: false
next: true
prev: true
---

> **PollStrategy** = (`canisterId`, `requestId`, `status`) => `Promise`\<`void`\>

Defined in: [packages/agent/src/polling/index.ts:28](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/polling/index.ts#L28)

## Parameters

### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](RequestId.md)

### status

[`RequestStatusResponseStatus`](../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`void`\>
