---
title: RequestContext
editUrl: false
next: true
prev: true
---

> **RequestContext** = `object`

Defined in: [packages/agent/src/errors.ts:24](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/errors.ts#L24)

## Properties

### ingressExpiry

> **ingressExpiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/agent/src/errors.ts:28](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/errors.ts#L28)

***

### requestId?

> `optional` **requestId**: [`RequestId`](RequestId.md)

Defined in: [packages/agent/src/errors.ts:25](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/errors.ts#L25)

***

### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/agent/src/errors.ts:26](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/errors.ts#L26)

***

### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/agent/src/errors.ts:27](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/errors.ts#L27)
