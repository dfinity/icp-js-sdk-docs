---
title: IdentityDescriptor
editUrl: false
next: true
prev: true
---

> **IdentityDescriptor** = [`AnonymousIdentityDescriptor`](../interfaces/AnonymousIdentityDescriptor.md) \| [`PublicKeyIdentityDescriptor`](../interfaces/PublicKeyIdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:133](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L133)
