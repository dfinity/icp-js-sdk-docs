---
title: IdentityDescriptor
editUrl: false
next: true
prev: true
---

> **IdentityDescriptor** = [`AnonymousIdentityDescriptor`](../interfaces/AnonymousIdentityDescriptor.md) \| [`PublicKeyIdentityDescriptor`](../interfaces/PublicKeyIdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:133](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/auth.ts#L133)
