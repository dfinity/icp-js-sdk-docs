---
title: IdentityDescriptor
editUrl: false
next: true
prev: true
---

> **IdentityDescriptor** = [`AnonymousIdentityDescriptor`](../interfaces/AnonymousIdentityDescriptor.md) \| [`PublicKeyIdentityDescriptor`](../interfaces/PublicKeyIdentityDescriptor.md)

Defined in: [packages/agent/src/auth.ts:133](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/auth.ts#L133)
