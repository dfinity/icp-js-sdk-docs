---
title: FunctionWithArgsAndReturn
editUrl: false
next: true
prev: true
---

> **FunctionWithArgsAndReturn**\<`Args`, `Ret`\> = (...`args`) => `Ret`

Defined in: [packages/agent/src/actor.ts:131](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/actor.ts#L131)


### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Parameters

### args

...`Args`

## Returns

`Ret`
