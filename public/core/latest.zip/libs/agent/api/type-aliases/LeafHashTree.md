---
title: LeafHashTree
editUrl: false
next: true
prev: true
---

> **LeafHashTree** = \[[`Leaf`](../enumerations/NodeType.md#leaf), [`NodeValue`](NodeValue.md)\]

Defined in: [packages/agent/src/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L61)
