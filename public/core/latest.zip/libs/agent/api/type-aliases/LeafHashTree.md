---
title: LeafHashTree
editUrl: false
next: true
prev: true
---

> **LeafHashTree** = \[[`Leaf`](../enumerations/NodeType.md#leaf), [`NodeValue`](NodeValue.md)\]

Defined in: [packages/agent/src/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L61)
