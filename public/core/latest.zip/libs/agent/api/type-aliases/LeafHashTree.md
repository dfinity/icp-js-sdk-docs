---
title: LeafHashTree
editUrl: false
next: true
prev: true
---

> **LeafHashTree** = \[[`Leaf`](../enumerations/NodeType.md#leaf), [`NodeValue`](NodeValue.md)\]

Defined in: [packages/agent/src/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/certificate.ts#L61)
