---
title: ActorSubclass
editUrl: false
next: true
prev: true
---

> **ActorSubclass**\<`T`\> = [`Actor`](../classes/Actor.md) & `T`

Defined in: [packages/core/src/agent/actor.ts:100](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L100)

A subclass of an actor. Actor class itself is meant to be a based class.

## Type Parameters

### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\>
