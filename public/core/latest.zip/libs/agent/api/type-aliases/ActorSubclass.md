---
title: ActorSubclass
editUrl: false
next: true
prev: true
---

> **ActorSubclass**\<`T`\> = [`Actor`](../classes/Actor.md) & `T`

Defined in: [packages/core/src/agent/actor.ts:108](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/actor.ts#L108)

A subclass of an actor. Actor class itself is meant to be a based class.

## Type Parameters

### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\>
