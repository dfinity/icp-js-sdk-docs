---
title: EmptyHashTree
editUrl: false
next: true
prev: true
---

> **EmptyHashTree** = \[[`Empty`](../enumerations/NodeType.md#empty)\]

Defined in: [packages/agent/src/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L58)
