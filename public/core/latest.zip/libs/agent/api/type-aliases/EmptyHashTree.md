---
title: EmptyHashTree
editUrl: false
next: true
prev: true
---

> **EmptyHashTree** = \[[`Empty`](../enumerations/NodeType.md#empty)\]

Defined in: [packages/agent/src/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L58)
