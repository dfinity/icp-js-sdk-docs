---
title: LabelLookupResult
editUrl: false
next: true
prev: true
---

> **LabelLookupResult** = [`LookupLabelResultAbsent`](../interfaces/LookupLabelResultAbsent.md) \| [`LookupLabelResultUnknown`](../interfaces/LookupLabelResultUnknown.md) \| [`LookupLabelResultFound`](../interfaces/LookupLabelResultFound.md) \| [`LookupLabelResultGreater`](../interfaces/LookupLabelResultGreater.md) \| [`LookupLabelResultLess`](../interfaces/LookupLabelResultLess.md)

Defined in: [packages/agent/src/certificate.ts:540](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L540)
