---
title: LabelLookupResult
editUrl: false
next: true
prev: true
---

> **LabelLookupResult** = [`LookupLabelResultAbsent`](../interfaces/LookupLabelResultAbsent.md) \| [`LookupLabelResultUnknown`](../interfaces/LookupLabelResultUnknown.md) \| [`LookupLabelResultFound`](../interfaces/LookupLabelResultFound.md) \| [`LookupLabelResultGreater`](../interfaces/LookupLabelResultGreater.md) \| [`LookupLabelResultLess`](../interfaces/LookupLabelResultLess.md)

Defined in: [packages/agent/src/certificate.ts:540](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L540)
