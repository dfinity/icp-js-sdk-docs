---
title: LabelLookupResult
editUrl: false
next: true
prev: true
---

> **LabelLookupResult** = [`LookupLabelResultAbsent`](../interfaces/LookupLabelResultAbsent.md) \| [`LookupLabelResultUnknown`](../interfaces/LookupLabelResultUnknown.md) \| [`LookupLabelResultFound`](../interfaces/LookupLabelResultFound.md) \| [`LookupLabelResultGreater`](../interfaces/LookupLabelResultGreater.md) \| [`LookupLabelResultLess`](../interfaces/LookupLabelResultLess.md)

Defined in: [packages/agent/src/certificate.ts:540](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L540)
