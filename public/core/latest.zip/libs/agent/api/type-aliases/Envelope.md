---
title: Envelope
editUrl: false
next: true
prev: true
---

> **Envelope**\<`T`\> = [`Signed`](../interfaces/Signed.md)\<`T`\> \| [`UnSigned`](../interfaces/UnSigned.md)\<`T`\>

Defined in: [packages/agent/src/agent/http/types.ts:53](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L53)


### T

`T`
