---
title: Envelope
editUrl: false
next: true
prev: true
---

> **Envelope**\<`T`\> = [`Signed`](../interfaces/Signed.md)\<`T`\> \| [`UnSigned`](../interfaces/UnSigned.md)\<`T`\>

Defined in: [packages/agent/src/agent/http/types.ts:53](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L53)

## Type Parameters

### T

`T`
