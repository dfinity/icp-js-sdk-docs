---
title: HttpAgentRequest
editUrl: false
next: true
prev: true
---

> **HttpAgentRequest** = [`HttpAgentQueryRequest`](../interfaces/HttpAgentQueryRequest.md) \| [`HttpAgentSubmitRequest`](../interfaces/HttpAgentSubmitRequest.md) \| [`HttpAgentReadStateRequest`](../interfaces/HttpAgentReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:16](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L16)
