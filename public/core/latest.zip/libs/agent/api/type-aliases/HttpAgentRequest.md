---
title: HttpAgentRequest
editUrl: false
next: true
prev: true
---

> **HttpAgentRequest** = [`HttpAgentQueryRequest`](../interfaces/HttpAgentQueryRequest.md) \| [`HttpAgentSubmitRequest`](../interfaces/HttpAgentSubmitRequest.md) \| [`HttpAgentReadStateRequest`](../interfaces/HttpAgentReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:16](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L16)
