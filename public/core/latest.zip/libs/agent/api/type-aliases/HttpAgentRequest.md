---
title: HttpAgentRequest
editUrl: false
next: true
prev: true
---

> **HttpAgentRequest** = [`HttpAgentQueryRequest`](../interfaces/HttpAgentQueryRequest.md) \| [`HttpAgentSubmitRequest`](../interfaces/HttpAgentSubmitRequest.md) \| [`HttpAgentReadStateRequest`](../interfaces/HttpAgentReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:16](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L16)
