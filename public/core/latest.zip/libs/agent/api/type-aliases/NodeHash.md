---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L56)


### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
