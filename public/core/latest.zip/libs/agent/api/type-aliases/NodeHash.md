---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/certificate.ts#L56)


### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
