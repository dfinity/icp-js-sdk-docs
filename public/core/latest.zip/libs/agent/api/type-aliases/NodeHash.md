---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L56)

## Type declaration

### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
