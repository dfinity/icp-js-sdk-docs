---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L56)

## Type declaration

### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
