---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L58)

## Type Declaration

### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
