---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L58)

## Type Declaration

### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
