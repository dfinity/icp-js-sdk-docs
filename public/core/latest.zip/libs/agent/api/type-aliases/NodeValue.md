---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:55](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L55)


### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
