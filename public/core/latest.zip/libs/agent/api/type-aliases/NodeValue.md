---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:57](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L57)

## Type Declaration

### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
