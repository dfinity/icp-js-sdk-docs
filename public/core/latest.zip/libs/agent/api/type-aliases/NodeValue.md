---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:55](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/certificate.ts#L55)


### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
