---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:57](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L57)

## Type Declaration

### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
