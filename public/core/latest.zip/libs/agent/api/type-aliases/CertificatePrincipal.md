---
title: CertificatePrincipal
editUrl: false
next: true
prev: true
---

> **CertificatePrincipal** = \{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \} \| \{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

Defined in: [packages/core/src/agent/certificate.ts:155](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L155)

## Union Members

### Type Literal

\{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

#### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

The effective canister ID of the request when verifying a response, or
the signing canister ID when verifying a certified variable.

***

### Type Literal

\{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

#### subnetId

> **subnetId**: [`Principal`](../../../principal/api/classes/Principal.md)

The subnet ID when verifying a certificate from a subnet.
