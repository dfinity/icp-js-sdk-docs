---
title: CertificatePrincipal
editUrl: false
next: true
prev: true
---

> **CertificatePrincipal** = \{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \} \| \{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

Defined in: [packages/core/src/agent/certificate.ts:155](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/certificate.ts#L155)

## Union Members

### Type Literal

\{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

#### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

The effective canister ID of the request when verifying a response, or
the signing canister ID when verifying a certified variable.

***

### Type Literal

\{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

#### subnetId

> **subnetId**: [`Principal`](../../../principal/api/classes/Principal.md)

The subnet ID when verifying a certificate from a subnet.
