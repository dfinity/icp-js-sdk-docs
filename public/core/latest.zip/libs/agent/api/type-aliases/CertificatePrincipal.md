---
title: CertificatePrincipal
editUrl: false
next: true
prev: true
---

> **CertificatePrincipal** = \{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \} \| \{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

Defined in: [packages/core/src/agent/certificate.ts:157](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L157)

## Type declaration

\{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

The effective canister ID of the request when verifying a response, or
the signing canister ID when verifying a certified variable.

\{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

### subnetId

> **subnetId**: [`Principal`](../../../principal/api/classes/Principal.md)

The subnet ID when verifying a certificate from a subnet.
