---
title: ReadRequest
editUrl: false
next: true
prev: true
---

> **ReadRequest** = [`QueryRequest`](../interfaces/QueryRequest.md) \| [`ReadStateRequest`](../interfaces/ReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/agent/http/types.ts#L103)
