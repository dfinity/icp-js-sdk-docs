---
title: ReadRequest
editUrl: false
next: true
prev: true
---

> **ReadRequest** = [`QueryRequest`](../interfaces/QueryRequest.md) \| [`ReadStateRequest`](../interfaces/ReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L103)
