---
title: ReadRequest
editUrl: false
next: true
prev: true
---

> **ReadRequest** = [`QueryRequest`](../interfaces/QueryRequest.md) \| [`ReadStateRequest`](../interfaces/ReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/http/types.ts#L103)
