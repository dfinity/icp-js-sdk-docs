---
title: DerEncodedPublicKey
editUrl: false
next: true
prev: true
---

> **DerEncodedPublicKey** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:17](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/auth.ts#L17)

A public key that is DER encoded. This is a branded Uint8Array.


### \_\_derEncodedPublicKey\_\_?

> `optional` **\_\_derEncodedPublicKey\_\_**: `void`
