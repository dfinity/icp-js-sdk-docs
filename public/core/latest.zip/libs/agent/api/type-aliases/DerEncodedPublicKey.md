---
title: DerEncodedPublicKey
editUrl: false
next: true
prev: true
---

> **DerEncodedPublicKey** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:17](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/auth.ts#L17)

A public key that is DER encoded. This is a branded Uint8Array.

## Type declaration

### \_\_derEncodedPublicKey\_\_?

> `optional` **\_\_derEncodedPublicKey\_\_**: `void`
