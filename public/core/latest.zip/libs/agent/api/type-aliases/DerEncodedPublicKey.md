---
title: DerEncodedPublicKey
editUrl: false
next: true
prev: true
---

> **DerEncodedPublicKey** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:17](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L17)

A public key that is DER encoded. This is a branded Uint8Array.

## Type declaration

### \_\_derEncodedPublicKey\_\_?

> `optional` **\_\_derEncodedPublicKey\_\_**: `void`
