---
title: DerEncodedPublicKey
editUrl: false
next: true
prev: true
---

> **DerEncodedPublicKey** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:17](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L17)

A public key that is DER encoded. This is a branded Uint8Array.

## Type declaration

### \_\_derEncodedPublicKey\_\_?

> `optional` **\_\_derEncodedPublicKey\_\_**: `void`
