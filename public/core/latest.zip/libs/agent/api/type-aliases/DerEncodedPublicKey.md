---
title: DerEncodedPublicKey
editUrl: false
next: true
prev: true
---

> **DerEncodedPublicKey** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:17](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/auth.ts#L17)

A public key that is DER encoded. This is a branded Uint8Array.

## Type declaration

### \_\_derEncodedPublicKey\_\_?

> `optional` **\_\_derEncodedPublicKey\_\_**: `void`
