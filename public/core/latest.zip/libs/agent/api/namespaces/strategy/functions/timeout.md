---
title: timeout
editUrl: false
next: true
prev: true
---

> **timeout**(`timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:92](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/polling/strategy.ts#L92)

Reject a call after a certain amount of time.

## Parameters

### timeInMsec

`number`

Time in milliseconds before the polling should be rejected.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
