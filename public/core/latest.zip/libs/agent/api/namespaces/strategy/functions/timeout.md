---
title: timeout
editUrl: false
next: true
prev: true
---

> **timeout**(`timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:89](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/polling/strategy.ts#L89)

Reject a call after a certain amount of time.


### timeInMsec

`number`

Time in milliseconds before the polling should be rejected.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
