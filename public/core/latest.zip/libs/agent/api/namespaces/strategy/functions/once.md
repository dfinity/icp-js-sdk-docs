---
title: once
editUrl: false
next: true
prev: true
---

> **once**(): [`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

Defined in: [packages/agent/src/polling/strategy.ts:26](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/polling/strategy.ts#L26)

Predicate that returns true once.


[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>
