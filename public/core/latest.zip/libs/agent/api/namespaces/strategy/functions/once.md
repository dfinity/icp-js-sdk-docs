---
title: once
editUrl: false
next: true
prev: true
---

> **once**(): [`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

Defined in: [packages/agent/src/polling/strategy.ts:29](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/polling/strategy.ts#L29)

Predicate that returns true once.


[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>
