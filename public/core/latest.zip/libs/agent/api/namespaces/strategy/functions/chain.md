---
title: chain
editUrl: false
next: true
prev: true
---

> **chain**(...`strategies`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:134](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/polling/strategy.ts#L134)

Chain multiple polling strategy. This _chains_ the strategies, so if you pass in,
say, two throttling strategy of 1 second, it will result in a throttle of 2 seconds.


### strategies

...[`PollStrategy`](../../../type-aliases/PollStrategy.md)[]

A strategy list to chain.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
