---
title: chain
editUrl: false
next: true
prev: true
---

> **chain**(...`strategies`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:131](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/polling/strategy.ts#L131)

Chain multiple polling strategy. This _chains_ the strategies, so if you pass in,
say, two throttling strategy of 1 second, it will result in a throttle of 2 seconds.


### strategies

...[`PollStrategy`](../../../type-aliases/PollStrategy.md)[]

A strategy list to chain.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
