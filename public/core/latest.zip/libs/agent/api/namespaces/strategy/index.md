---
title: strategy
editUrl: false
next: true
prev: true
---

## Type Aliases

- [Predicate](type-aliases/Predicate.md)

## Functions

- [backoff](functions/backoff.md)
- [chain](functions/chain.md)
- [conditionalDelay](functions/conditionalDelay.md)
- [defaultStrategy](functions/defaultStrategy.md)
- [maxAttempts](functions/maxAttempts.md)
- [once](functions/once.md)
- [throttle](functions/throttle.md)
- [timeout](functions/timeout.md)
