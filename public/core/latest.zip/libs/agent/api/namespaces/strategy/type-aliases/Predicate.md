---
title: Predicate
editUrl: false
next: true
prev: true
---

> **Predicate**\<`T`\> = (`canisterId`, `requestId`, `status`) => `Promise`\<`T`\>

Defined in: [packages/agent/src/polling/strategy.ts:7](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/polling/strategy.ts#L7)

## Type Parameters

### T

`T`

## Parameters

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](../../../type-aliases/RequestId.md)

### status

[`RequestStatusResponseStatus`](../../../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`T`\>
