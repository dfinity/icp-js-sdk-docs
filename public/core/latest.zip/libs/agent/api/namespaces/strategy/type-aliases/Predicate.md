---
title: Predicate
editUrl: false
next: true
prev: true
---

> **Predicate**\<`T`\> = (`canisterId`, `requestId`, `status`) => `Promise`\<`T`\>

Defined in: [packages/agent/src/polling/strategy.ts:7](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/polling/strategy.ts#L7)


### T

`T`

## Parameters

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](../../../type-aliases/RequestId.md)

### status

[`RequestStatusResponseStatus`](../../../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`T`\>
