---
title: conditionalDelay
editUrl: false
next: true
prev: true
---

> **conditionalDelay**(`condition`, `timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:42](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/polling/strategy.ts#L42)

Delay the polling once.


### condition

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

A predicate that indicates when to delay.

### timeInMsec

`number`

The amount of time to delay.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
