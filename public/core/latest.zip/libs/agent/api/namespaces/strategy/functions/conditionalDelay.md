---
title: conditionalDelay
editUrl: false
next: true
prev: true
---

> **conditionalDelay**(`condition`, `timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/strategy.ts:41](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/polling/strategy.ts#L41)

Delay the polling once.

## Parameters

### condition

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

A predicate that indicates when to delay.

### timeInMsec

`number`

The amount of time to delay.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
