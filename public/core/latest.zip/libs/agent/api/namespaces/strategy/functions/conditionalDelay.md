---
title: conditionalDelay
editUrl: false
next: true
prev: true
---

> **conditionalDelay**(`condition`, `timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:42](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/polling/strategy.ts#L42)

Delay the polling once.


### condition

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

A predicate that indicates when to delay.

### timeInMsec

`number`

The amount of time to delay.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
