---
title: defaultStrategy
editUrl: false
next: true
prev: true
---

> **defaultStrategy**(): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:22](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/polling/strategy.ts#L22)

A best practices polling strategy: wait 2 seconds before the first poll, then 1 second
with an exponential backoff factor of 1.2. Timeout after 5 minutes.

Note that calling this function will create the strategy chain described above and already start the 5 minutes timeout.
You should only call this function when you want to start the polling, and not before, to avoid exhausting the 5 minutes timeout in advance.


[`PollStrategy`](../../../type-aliases/PollStrategy.md)
