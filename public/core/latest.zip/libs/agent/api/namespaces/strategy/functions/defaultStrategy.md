---
title: defaultStrategy
editUrl: false
next: true
prev: true
---

> **defaultStrategy**(): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/strategy.ts:22](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/polling/strategy.ts#L22)

A best practices polling strategy: wait 2 seconds before the first poll, then 1 second
with an exponential backoff factor of 1.2. Timeout after 5 minutes.

Note that calling this function will create the strategy chain described above and already start the 5 minutes timeout.
You should only call this function when you want to start the polling, and not before, to avoid exhausting the 5 minutes timeout in advance.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
