---
title: maxAttempts
editUrl: false
next: true
prev: true
---

> **maxAttempts**(`count`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:58](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/polling/strategy.ts#L58)

Error out after a maximum number of polling has been done.


### count

`number`

The maximum attempts to poll.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
