---
title: maxAttempts
editUrl: false
next: true
prev: true
---

> **maxAttempts**(`count`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:61](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/strategy.ts#L61)

Error out after a maximum number of polling has been done.

## Parameters

### count

`number`

The maximum attempts to poll.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
