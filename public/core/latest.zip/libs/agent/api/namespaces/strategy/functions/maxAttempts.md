---
title: maxAttempts
editUrl: false
next: true
prev: true
---

> **maxAttempts**(`count`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/strategy.ts:57](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/polling/strategy.ts#L57)

Error out after a maximum number of polling has been done.

## Parameters

### count

`number`

The maximum attempts to poll.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
