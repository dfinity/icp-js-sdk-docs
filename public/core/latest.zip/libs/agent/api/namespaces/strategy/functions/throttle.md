---
title: throttle
editUrl: false
next: true
prev: true
---

> **throttle**(`throttleInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:84](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/polling/strategy.ts#L84)

Throttle polling.

## Parameters

### throttleInMsec

`number`

Amount in millisecond to wait between each polling.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
