---
title: throttle
editUrl: false
next: true
prev: true
---

> **throttle**(`throttleInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/strategy.ts:84](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/polling/strategy.ts#L84)

Throttle polling.

## Parameters

### throttleInMsec

`number`

Amount in millisecond to wait between each polling.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
