---
title: throttle
editUrl: false
next: true
prev: true
---

> **throttle**(`throttleInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:84](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/polling/strategy.ts#L84)

Throttle polling.

## Parameters

### throttleInMsec

`number`

Amount in millisecond to wait between each polling.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
