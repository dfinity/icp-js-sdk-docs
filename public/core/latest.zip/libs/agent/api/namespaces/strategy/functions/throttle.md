---
title: throttle
editUrl: false
next: true
prev: true
---

> **throttle**(`throttleInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:84](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/polling/strategy.ts#L84)

Throttle polling.


### throttleInMsec

`number`

Amount in millisecond to wait between each polling.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
