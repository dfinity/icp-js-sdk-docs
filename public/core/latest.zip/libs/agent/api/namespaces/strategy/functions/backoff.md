---
title: backoff
editUrl: false
next: true
prev: true
---

> **backoff**(`startingThrottleInMsec`, `backoffFactor`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:114](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/polling/strategy.ts#L114)

A strategy that throttle, but using an exponential backoff strategy.


### startingThrottleInMsec

`number`

The throttle in milliseconds to start with.

### backoffFactor

`number`

The factor to multiple the throttle time between every poll. For
  example if using 2, the throttle will double between every run.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
