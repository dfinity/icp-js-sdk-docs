---
title: backoff
editUrl: false
next: true
prev: true
---

> **backoff**(`startingThrottleInMsec`, `backoffFactor`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:117](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/polling/strategy.ts#L117)

A strategy that throttle, but using an exponential backoff strategy.


### startingThrottleInMsec

`number`

The throttle in milliseconds to start with.

### backoffFactor

`number`

The factor to multiple the throttle time between every poll. For
  example if using 2, the throttle will double between every run.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
