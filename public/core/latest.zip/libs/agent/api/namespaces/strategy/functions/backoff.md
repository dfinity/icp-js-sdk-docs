---
title: backoff
editUrl: false
next: true
prev: true
---

> **backoff**(`startingThrottleInMsec`, `backoffFactor`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:117](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/polling/strategy.ts#L117)

A strategy that throttle, but using an exponential backoff strategy.

## Parameters

### startingThrottleInMsec

`number`

The throttle in milliseconds to start with.

### backoffFactor

`number`

The factor to multiple the throttle time between every poll. For
  example if using 2, the throttle will double between every run.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
