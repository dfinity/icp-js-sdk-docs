---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

The CanisterStatus utility is used to request structured data directly from the IC public API. This data can be accessed using agent.readState, but CanisterStatus provides a helpful abstraction with some known paths.

You can request a canisters Controllers, ModuleHash, Candid interface, Subnet, or Time, or provide a custom path [CanisterStatus.CustomPath](#custompath) and pass arbitrary buffers for valid paths identified in https://internetcomputer.org/docs/current/references/ic-interface-spec.

The primary method for this namespace is [CanisterStatus.request](#request)

## Classes

### CustomPath

Defined in: [packages/core/src/agent/utils/readState.ts:67](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/readState.ts#L67)

Interface to define a custom path. Nested paths will be represented as individual buffers, and can be created from text using TextEncoder.

#### Param

the key to use to access the returned value in the status map

#### Param

the path to the desired value, represented as an array of buffers

#### Param

the strategy to use to decode the returned value

#### Implements

- [`CustomPath`](#custompath)

#### Constructors

##### Constructor

> **new CustomPath**(`key`, `path`, `decodeStrategy`): [`CustomPath`](#custompath)

Defined in: [packages/core/src/agent/utils/readState.ts:71](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/readState.ts#L71)

###### Parameters

###### key

`string`

###### path

`string` \| `Uint8Array`\<`ArrayBufferLike`\>[]

###### decodeStrategy

[`DecodeStrategy`](#decodestrategy-1)

###### Returns

[`CustomPath`](#custompath)

#### Properties

##### decodeStrategy

> **decodeStrategy**: [`DecodeStrategy`](#decodestrategy-1)

Defined in: [packages/core/src/agent/utils/readState.ts:70](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/readState.ts#L70)

###### Implementation of

`CustomPath.decodeStrategy`

##### key

> **key**: `string`

Defined in: [packages/core/src/agent/utils/readState.ts:68](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/readState.ts#L68)

###### Implementation of

`CustomPath.key`

##### path

> **path**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/core/src/agent/utils/readState.ts:69](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/readState.ts#L69)

###### Implementation of

`CustomPath.path`

## Interfaces

### CanisterStatusOptions

Defined in: [packages/core/src/agent/canisterStatus/index.ts:42](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L42)

#### Properties

##### agent

> **agent**: [`HttpAgent`](../index.md#httpagent)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:50](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L50)

The agent to use to make the canister request. Must be authenticated.

##### canisterId

> **canisterId**: [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:46](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L46)

The effective canister ID to use in the underlying [HttpAgent.readState](../index.md#readstate-2) call.

##### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification?**: `boolean`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:60](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L60)

Whether to disable the certificate freshness checks.

###### Default

```ts
false
```

##### paths?

> `optional` **paths?**: `Set`\<[`Path`](#path-1)\> \| [`Path`](#path-1)[]

Defined in: [packages/core/src/agent/canisterStatus/index.ts:55](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L55)

The paths to request.

###### Default

```ts
[]
```

## Type Aliases

### DecodeStrategy

> **DecodeStrategy** = `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/core/src/agent/utils/readState.ts:59](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/utils/readState.ts#L59)

Decode strategy for custom paths

***

### Path

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`CustomPath`](#custompath)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:38](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L38)

Pre-configured fields for canister status paths

***

### Status

> **Status** = `BaseStatus` \| [`SubnetStatus`](#subnetstatus)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:33](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L33)

***

### StatusMap

> **StatusMap** = `Map`\<[`Path`](#path-1) \| `string`, [`Status`](#status)\>

Defined in: [packages/core/src/agent/canisterStatus/index.ts:40](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L40)

***

### SubnetStatus

> **SubnetStatus** = `BaseSubnetStatus`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:32](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L32)

## Functions

### encodePath()

> **encodePath**(`path`, `canisterId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/core/src/agent/canisterStatus/index.ts:225](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L225)

#### Parameters

##### path

[`Path`](#path-1)

##### canisterId

[`Principal`](../../../principal/api.md#principal)

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>[]

***

### fetchNodeKeys()

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): `BaseSubnetStatus`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:196](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L196)

Lookup node keys from a certificate for a given canister.
The certificate is assumed to be already verified, including whether the canister is in range of the subnet.

#### Parameters

##### certificate

`Uint8Array`

the certificate to lookup node keys from

##### canisterId

[`Principal`](../../../principal/api.md#principal)

the canister ID to lookup node keys for

##### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

the root key to use to lookup node keys

#### Returns

`BaseSubnetStatus`

a map of node IDs to public keys

***

### request()

> **request**(`options`): `Promise`\<[`StatusMap`](#statusmap)\>

Defined in: [packages/core/src/agent/canisterStatus/index.ts:81](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/canisterStatus/index.ts#L81)

Requests information from a canister's `read_state` endpoint.
Can be used to request information about the canister's controllers, time, module hash, candid interface, and more.

> [!WARNING]
> Requesting the `subnet` path from the canister status might be deprecated in the future.
> Use [SubnetStatus.request](https://js.icp.build/core/latest/libs/agent/api/namespaces/subnetstatus/functions/request) to fetch subnet information instead.

#### Parameters

##### options

[`CanisterStatusOptions`](#canisterstatusoptions)

The configuration for the canister status request.

#### Returns

`Promise`\<[`StatusMap`](#statusmap)\>

A map populated with data from the requested paths. Each path is a key in the map, and the value is the data obtained from the certificate for that path.

#### See

[CanisterStatusOptions](#canisterstatusoptions) for detailed options.

#### Example

```ts
const status = await canisterStatus({
  paths: ['controllers', 'candid'],
  ...options
});

const controllers = status.get('controllers');
```
