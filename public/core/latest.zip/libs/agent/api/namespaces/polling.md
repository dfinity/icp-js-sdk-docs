---
title: polling
editUrl: false
next: true
prev: true
---

## References

### constructRequest

Re-exports [constructRequest](../index.md#constructrequest)

***

### DEFAULT\_POLLING\_OPTIONS

Re-exports [DEFAULT_POLLING_OPTIONS](../index.md#default_polling_options)

***

### defaultStrategy

Re-exports [defaultStrategy](strategy.md#defaultstrategy)

***

### pollForResponse

Re-exports [pollForResponse](../index.md#pollforresponse)

***

### PollForResponseResult

Re-exports [PollForResponseResult](../index.md#pollforresponseresult)

***

### PollingOptions

Re-exports [PollingOptions](../index.md#pollingoptions-2)

***

### PollStrategy

Re-exports [PollStrategy](../index.md#pollstrategy)

***

### strategy

Re-exports [strategy](strategy.md)
