---
title: strategy
editUrl: false
next: true
prev: true
---

## Type Aliases

### Predicate

> **Predicate**\<`T`\> = (`canisterId`, `requestId`, `status`) => `Promise`\<`T`\>

Defined in: [packages/core/src/agent/polling/types.ts:12](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/types.ts#L12)

#### Type Parameters

##### T

`T`

#### Parameters

##### canisterId

[`Principal`](../../../principal/api.md#principal)

##### requestId

[`RequestId`](../index.md#requestid-9)

##### status

[`RequestStatusResponseStatus`](../index.md#requeststatusresponsestatus)

#### Returns

`Promise`\<`T`\>

## Functions

### backoff()

> **backoff**(`startingThrottleInMsec`, `backoffFactor`): [`PollStrategy`](../index.md#pollstrategy)

Defined in: [packages/core/src/agent/polling/strategy.ts:113](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L113)

A strategy that throttle, but using an exponential backoff strategy.

#### Parameters

##### startingThrottleInMsec

`number`

The throttle in milliseconds to start with.

##### backoffFactor

`number`

The factor to multiple the throttle time between every poll. For
  example if using 2, the throttle will double between every run.

#### Returns

[`PollStrategy`](../index.md#pollstrategy)

***

### chain()

> **chain**(...`strategies`): [`PollStrategy`](../index.md#pollstrategy)

Defined in: [packages/core/src/agent/polling/strategy.ts:130](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L130)

Chain multiple polling strategy. This _chains_ the strategies, so if you pass in,
say, two throttling strategy of 1 second, it will result in a throttle of 2 seconds.

#### Parameters

##### strategies

...[`PollStrategy`](../index.md#pollstrategy)[]

A strategy list to chain.

#### Returns

[`PollStrategy`](../index.md#pollstrategy)

***

### conditionalDelay()

> **conditionalDelay**(`condition`, `timeInMsec`): [`PollStrategy`](../index.md#pollstrategy)

Defined in: [packages/core/src/agent/polling/strategy.ts:41](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L41)

Delay the polling once.

#### Parameters

##### condition

[`Predicate`](#predicate)\<`boolean`\>

A predicate that indicates when to delay.

##### timeInMsec

`number`

The amount of time to delay.

#### Returns

[`PollStrategy`](../index.md#pollstrategy)

***

### defaultStrategy()

> **defaultStrategy**(): [`PollStrategy`](../index.md#pollstrategy)

Defined in: [packages/core/src/agent/polling/strategy.ts:18](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L18)

A best practices polling strategy: wait 2 seconds before the first poll, then 1 second
with an exponential backoff factor of 1.2. Timeout after 5 minutes.

Note that calling this function will create the strategy chain described above and already start the 5 minutes timeout.
You should only call this function when you want to start the polling, and not before, to avoid exhausting the 5 minutes timeout in advance.

#### Returns

[`PollStrategy`](../index.md#pollstrategy)

***

### maxAttempts()

> **maxAttempts**(`count`): [`PollStrategy`](../index.md#pollstrategy)

Defined in: [packages/core/src/agent/polling/strategy.ts:57](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L57)

Error out after a maximum number of polling has been done.

#### Parameters

##### count

`number`

The maximum attempts to poll.

#### Returns

[`PollStrategy`](../index.md#pollstrategy)

***

### once()

> **once**(): [`Predicate`](#predicate)\<`boolean`\>

Defined in: [packages/core/src/agent/polling/strategy.ts:25](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L25)

Predicate that returns true once.

#### Returns

[`Predicate`](#predicate)\<`boolean`\>

***

### throttle()

> **throttle**(`throttleInMsec`): [`PollStrategy`](../index.md#pollstrategy)

Defined in: [packages/core/src/agent/polling/strategy.ts:80](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L80)

Throttle polling.

#### Parameters

##### throttleInMsec

`number`

Amount in millisecond to wait between each polling.

#### Returns

[`PollStrategy`](../index.md#pollstrategy)

***

### timeout()

> **timeout**(`timeInMsec`): [`PollStrategy`](../index.md#pollstrategy)

Defined in: [packages/core/src/agent/polling/strategy.ts:88](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/agent/polling/strategy.ts#L88)

Reject a call after a certain amount of time.

#### Parameters

##### timeInMsec

`number`

Time in milliseconds before the polling should be rejected.

#### Returns

[`PollStrategy`](../index.md#pollstrategy)

## References

### PollStrategy

Re-exports [PollStrategy](../index.md#pollstrategy)
