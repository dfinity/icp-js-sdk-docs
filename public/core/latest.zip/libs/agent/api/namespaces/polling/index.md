---
title: polling
editUrl: false
next: true
prev: true
---

## References

### constructRequest

Re-exports [constructRequest](../../functions/constructRequest.md)

***

### DEFAULT\_POLLING\_OPTIONS

Re-exports [DEFAULT_POLLING_OPTIONS](../../variables/DEFAULT_POLLING_OPTIONS.md)

***

### defaultStrategy

Re-exports [defaultStrategy](../strategy/functions/defaultStrategy.md)

***

### pollForResponse

Re-exports [pollForResponse](../../functions/pollForResponse.md)

***

### PollForResponseResult

Re-exports [PollForResponseResult](../../interfaces/PollForResponseResult.md)

***

### PollingOptions

Re-exports [PollingOptions](../../interfaces/PollingOptions.md)

***

### PollStrategy

Re-exports [PollStrategy](../../type-aliases/PollStrategy.md)

***

### strategy

Re-exports [strategy](../strategy/index.md)
