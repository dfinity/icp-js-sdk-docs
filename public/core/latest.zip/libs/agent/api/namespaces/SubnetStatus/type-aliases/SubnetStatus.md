---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

> **SubnetStatus** = `BaseSubnetStatus` & `object`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:40](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/subnetStatus/index.ts#L40)

## Type Declaration

### publicKey

> **publicKey**: `Uint8Array`

The public key of the subnet
