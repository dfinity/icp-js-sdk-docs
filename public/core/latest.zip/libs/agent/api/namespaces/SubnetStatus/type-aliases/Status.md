---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| `SubnetNodeKeys` \| [`CanisterRanges`](../../../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:47](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/subnetStatus/index.ts#L47)
