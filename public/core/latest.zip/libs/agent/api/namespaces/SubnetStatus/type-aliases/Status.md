---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| `SubnetNodeKeys` \| [`CanisterRanges`](../../../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:47](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/subnetStatus/index.ts#L47)
