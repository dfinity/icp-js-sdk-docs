---
title: lookupSubnetInfo
editUrl: false
next: true
prev: true
---

> **lookupSubnetInfo**(`certificate`, `subnetId`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:202](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/subnetStatus/index.ts#L202)

Fetch subnet info including node keys from a certificate

## Parameters

### certificate

`Uint8Array`

the certificate bytes

### subnetId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the subnet ID

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)

SubnetStatus with subnet ID and node keys
