---
title: request
editUrl: false
next: true
prev: true
---

> **request**(`options`): `Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

Defined in: [packages/core/src/agent/subnetStatus/index.ts:94](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L94)

Requests information from a subnet's `read_state` endpoint.
Can be used to request information about the subnet's time, canister ranges, public key, node keys, and metrics.

## Parameters

### options

[`SubnetStatusOptions`](../type-aliases/SubnetStatusOptions.md)

The configuration for the subnet status request.

## Returns

`Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

A map populated with data from the requested paths. Each path is a key in the map, and the value is the data obtained from the certificate for that path.

## See

[SubnetStatusOptions](../type-aliases/SubnetStatusOptions.md) for detailed options.

## Example

```ts
const status = await subnetStatus.request({
  subnetId: IC_ROOT_SUBNET_ID,
  paths: ['time', 'nodeKeys'],
  agent,
});

const time = status.get('time');
const nodeKeys = status.get('nodeKeys');
```
