---
title: IC_ROOT_SUBNET_ID
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_SUBNET\_ID**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/utils/readState.ts:26](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/utils/readState.ts#L26)

The root subnet ID for IC mainnet
