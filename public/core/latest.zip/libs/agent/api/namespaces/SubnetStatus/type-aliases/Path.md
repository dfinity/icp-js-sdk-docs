---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"canisterRanges"` \| `"publicKey"` \| `"nodeKeys"` \| [`CustomPath`](../../CanisterStatus/classes/CustomPath.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:52](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L52)

Pre-configured fields for subnet status paths
