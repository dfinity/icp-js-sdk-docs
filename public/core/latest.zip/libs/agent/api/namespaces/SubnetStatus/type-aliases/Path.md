---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"canisterRanges"` \| `"publicKey"` \| `"nodeKeys"` \| [`CustomPath`](../../CanisterStatus/classes/CustomPath.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:52](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/subnetStatus/index.ts#L52)

Pre-configured fields for subnet status paths
