---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"canisterRanges"` \| `"publicKey"` \| `"nodeKeys"` \| [`CustomPath`](../../CanisterStatus/classes/CustomPath.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:52](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/subnetStatus/index.ts#L52)

Pre-configured fields for subnet status paths
