---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

The SubnetStatus utility is used to request structured data directly from the IC public API. This data can be accessed using agent.readSubnetState, but SubnetStatus provides a helpful abstraction with some known paths.

The primary method for this namespace is [SubnetStatus.request](functions/request.md)

## Type Aliases

- [Path](type-aliases/Path.md)
- [Status](type-aliases/Status.md)
- [StatusMap](type-aliases/StatusMap.md)
- [SubnetStatus](type-aliases/SubnetStatus.md)
- [SubnetStatusOptions](type-aliases/SubnetStatusOptions.md)

## Variables

- [IC\_ROOT\_SUBNET\_ID](variables/IC_ROOT_SUBNET_ID.md)

## Functions

- [encodePath](functions/encodePath.md)
- [lookupSubnetInfo](functions/lookupSubnetInfo.md)
- [request](functions/request.md)

## References

### CustomPath

Re-exports [CustomPath](../CanisterStatus/classes/CustomPath.md)

***

### DecodeStrategy

Re-exports [DecodeStrategy](../CanisterStatus/type-aliases/DecodeStrategy.md)
