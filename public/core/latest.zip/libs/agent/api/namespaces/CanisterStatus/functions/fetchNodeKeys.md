---
title: fetchNodeKeys
editUrl: false
next: true
prev: true
---

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:285](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/canisterStatus/index.ts#L285)


### certificate

`Uint8Array`

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)
