---
title: DecodeStrategy
editUrl: false
next: true
prev: true
---

> **DecodeStrategy** = `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/core/src/agent/utils/readState.ts:59](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/utils/readState.ts#L59)

Decode strategy for custom paths
