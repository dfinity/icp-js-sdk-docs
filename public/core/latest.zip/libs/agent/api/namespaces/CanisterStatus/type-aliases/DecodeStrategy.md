---
title: DecodeStrategy
editUrl: false
next: true
prev: true
---

> **DecodeStrategy** = `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/core/src/agent/utils/readState.ts:59](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/readState.ts#L59)

Decode strategy for custom paths
