---
title: encodePath
editUrl: false
next: true
prev: true
---

> **encodePath**(`path`, `canisterId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/agent/src/canisterStatus/index.ts:364](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/canisterStatus/index.ts#L364)

## Parameters

### path

[`Path`](../type-aliases/Path.md)

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

## Returns

`Uint8Array`\<`ArrayBufferLike`\>[]
