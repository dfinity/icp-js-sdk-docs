---
title: encodePath
editUrl: false
next: true
prev: true
---

> **encodePath**(`path`, `canisterId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/agent/src/canisterStatus/index.ts:364](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/canisterStatus/index.ts#L364)


### path

[`Path`](../type-aliases/Path.md)

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

## Returns

`Uint8Array`\<`ArrayBufferLike`\>[]
