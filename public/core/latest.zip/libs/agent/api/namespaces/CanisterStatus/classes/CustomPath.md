---
title: CustomPath
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/canisterStatus/index.ts:76](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/canisterStatus/index.ts#L76)

Interface to define a custom path. Nested paths will be represented as individual buffers, and can be created from text using TextEncoder.

## Param

the key to use to access the returned value in the canisterStatus map

## Param

the path to the desired value, represented as an array of buffers

## Param

the strategy to use to decode the returned value

## Implements

- `CustomPath`

## Constructors

### Constructor

> **new CustomPath**(`key`, `path`, `decodeStrategy`): `CustomPath`

Defined in: [packages/agent/src/canisterStatus/index.ts:80](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/canisterStatus/index.ts#L80)

#### Parameters

##### key

`string`

##### path

`string` | `Uint8Array`\<`ArrayBufferLike`\>[]

##### decodeStrategy

`"cbor"` | `"hex"` | `"leb128"` | `"utf-8"` | `"raw"`

#### Returns

`CustomPath`

## Properties

### decodeStrategy

> **decodeStrategy**: `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/agent/src/canisterStatus/index.ts:79](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/canisterStatus/index.ts#L79)

#### Implementation of

`CustomPath.decodeStrategy`

***

### key

> **key**: `string`

Defined in: [packages/agent/src/canisterStatus/index.ts:77](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/canisterStatus/index.ts#L77)

#### Implementation of

`CustomPath.key`

***

### path

> **path**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/agent/src/canisterStatus/index.ts:78](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/canisterStatus/index.ts#L78)

#### Implementation of

`CustomPath.path`
