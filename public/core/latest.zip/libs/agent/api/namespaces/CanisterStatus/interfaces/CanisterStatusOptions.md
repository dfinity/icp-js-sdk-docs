---
title: CanisterStatusOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/canisterStatus/index.ts:42](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canisterStatus/index.ts#L42)

## Properties

### agent

> **agent**: [`HttpAgent`](../../../classes/HttpAgent.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:50](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canisterStatus/index.ts#L50)

The agent to use to make the canister request. Must be authenticated.

***

### canisterId

> **canisterId**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:46](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canisterStatus/index.ts#L46)

The effective canister ID to use in the underlying [HttpAgent.readState](../../../classes/HttpAgent.md#readstate) call.

***

### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification?**: `boolean`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:60](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canisterStatus/index.ts#L60)

Whether to disable the certificate freshness checks.

#### Default

```ts
false
```

***

### paths?

> `optional` **paths?**: `Set`\<[`Path`](../type-aliases/Path.md)\> \| [`Path`](../type-aliases/Path.md)[]

Defined in: [packages/core/src/agent/canisterStatus/index.ts:55](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canisterStatus/index.ts#L55)

The paths to request.

#### Default

```ts
[]
```
