---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`CustomPath`](../classes/CustomPath.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:38](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/canisterStatus/index.ts#L38)

Pre-configured fields for canister status paths
