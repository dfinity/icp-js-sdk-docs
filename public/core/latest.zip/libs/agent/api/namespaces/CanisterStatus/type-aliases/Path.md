---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`MetaData`](../interfaces/MetaData.md) \| [`CustomPath`](../classes/CustomPath.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:107](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/canisterStatus/index.ts#L107)

Pre-configured fields for canister status paths
