---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`MetaData`](../interfaces/MetaData.md) \| [`CustomPath`](../classes/CustomPath.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:107](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/canisterStatus/index.ts#L107)

Pre-configured fields for canister status paths
