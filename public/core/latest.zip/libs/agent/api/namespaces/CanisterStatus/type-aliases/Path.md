---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`CustomPath`](../classes/CustomPath.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:38](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canisterStatus/index.ts#L38)

Pre-configured fields for canister status paths
