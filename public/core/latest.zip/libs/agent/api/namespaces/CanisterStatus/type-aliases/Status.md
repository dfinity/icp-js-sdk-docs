---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| [`SubnetStatus`](SubnetStatus.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:33](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/canisterStatus/index.ts#L33)
