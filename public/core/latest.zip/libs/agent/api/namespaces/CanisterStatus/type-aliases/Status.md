---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `string` \| `Uint8Array` \| `Date` \| `Uint8Array`[] \| [`Principal`](../../../../../principal/api/classes/Principal.md)[] \| [`SubnetStatus`](SubnetStatus.md) \| `bigint` \| `null`

Defined in: [packages/agent/src/canisterStatus/index.ts:60](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/canisterStatus/index.ts#L60)

Types of an entry on the canisterStatus map.
An entry of null indicates that the request failed, due to lack of permissions or the result being missing.
