---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| [`SubnetStatus`](SubnetStatus.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:33](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canisterStatus/index.ts#L33)
