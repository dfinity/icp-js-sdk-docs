---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| [`SubnetStatus`](SubnetStatus.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:33](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/canisterStatus/index.ts#L33)
