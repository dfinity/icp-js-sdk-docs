---
title: StatusMap
editUrl: false
next: true
prev: true
---

> **StatusMap** = `Map`\<[`Path`](Path.md) \| `string`, [`Status`](Status.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:116](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/canisterStatus/index.ts#L116)
