---
title: StatusMap
editUrl: false
next: true
prev: true
---

> **StatusMap** = `Map`\<[`Path`](Path.md) \| `string`, [`Status`](Status.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:116](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/agent/src/canisterStatus/index.ts#L116)
