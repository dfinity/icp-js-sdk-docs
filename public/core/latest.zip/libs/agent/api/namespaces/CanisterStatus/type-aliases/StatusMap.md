---
title: StatusMap
editUrl: false
next: true
prev: true
---

> **StatusMap** = `Map`\<[`Path`](Path.md) \| `string`, [`Status`](Status.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:116](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/canisterStatus/index.ts#L116)
