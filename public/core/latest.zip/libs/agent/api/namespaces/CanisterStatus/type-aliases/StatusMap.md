---
title: StatusMap
editUrl: false
next: true
prev: true
---

> **StatusMap** = `Map`\<[`Path`](Path.md) \| `string`, [`Status`](Status.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:116](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/canisterStatus/index.ts#L116)
