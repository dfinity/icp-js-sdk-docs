---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

> **SubnetStatus** = `object`

Defined in: [packages/agent/src/canisterStatus/index.ts:41](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/canisterStatus/index.ts#L41)

Represents the useful information about a subnet

## Param

the principal id of the canister's subnet

## Param

the keys of the individual nodes in the subnet

## Properties

### metrics?

> `optional` **metrics**: `object`

Defined in: [packages/agent/src/canisterStatus/index.ts:45](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/canisterStatus/index.ts#L45)

#### canister\_state\_bytes

> **canister\_state\_bytes**: `bigint`

#### consumed\_cycles\_total

> **consumed\_cycles\_total**: `object`

##### consumed\_cycles\_total.current

> **current**: `bigint`

##### consumed\_cycles\_total.deleted

> **deleted**: `bigint`

#### num\_canisters

> **num\_canisters**: `bigint`

#### update\_transactions\_total

> **update\_transactions\_total**: `bigint`

***

### nodeKeys

> **nodeKeys**: `Map`\<`string`, [`DerEncodedPublicKey`](../../../type-aliases/DerEncodedPublicKey.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:44](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/canisterStatus/index.ts#L44)

***

### subnetId

> **subnetId**: `string`

Defined in: [packages/agent/src/canisterStatus/index.ts:43](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/canisterStatus/index.ts#L43)
