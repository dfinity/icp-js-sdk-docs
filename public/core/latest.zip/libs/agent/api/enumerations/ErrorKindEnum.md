---
title: ErrorKindEnum
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:14](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L14)

## Enumeration Members

### External

> **External**: `"External"`

Defined in: [packages/core/src/agent/errors.ts:19](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L19)

***

### Input

> **Input**: `"Input"`

Defined in: [packages/core/src/agent/errors.ts:21](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L21)

***

### Limit

> **Limit**: `"Limit"`

Defined in: [packages/core/src/agent/errors.ts:20](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L20)

***

### Protocol

> **Protocol**: `"Protocol"`

Defined in: [packages/core/src/agent/errors.ts:16](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L16)

***

### Reject

> **Reject**: `"Reject"`

Defined in: [packages/core/src/agent/errors.ts:17](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L17)

***

### Transport

> **Transport**: `"Transport"`

Defined in: [packages/core/src/agent/errors.ts:18](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L18)

***

### Trust

> **Trust**: `"Trust"`

Defined in: [packages/core/src/agent/errors.ts:15](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L15)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/errors.ts:22](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L22)
