---
title: ErrorKindEnum
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:15](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L15)

## Enumeration Members

### External

> **External**: `"External"`

Defined in: [packages/core/src/agent/errors.ts:20](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L20)

***

### Input

> **Input**: `"Input"`

Defined in: [packages/core/src/agent/errors.ts:22](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L22)

***

### Limit

> **Limit**: `"Limit"`

Defined in: [packages/core/src/agent/errors.ts:21](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L21)

***

### Protocol

> **Protocol**: `"Protocol"`

Defined in: [packages/core/src/agent/errors.ts:17](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L17)

***

### Reject

> **Reject**: `"Reject"`

Defined in: [packages/core/src/agent/errors.ts:18](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L18)

***

### Transport

> **Transport**: `"Transport"`

Defined in: [packages/core/src/agent/errors.ts:19](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L19)

***

### Trust

> **Trust**: `"Trust"`

Defined in: [packages/core/src/agent/errors.ts:16](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L16)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/errors.ts:23](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L23)
