---
title: ErrorKindEnum
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:13](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L13)


### External

> **External**: `"External"`

Defined in: [packages/agent/src/errors.ts:18](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L18)

***

### Input

> **Input**: `"Input"`

Defined in: [packages/agent/src/errors.ts:20](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L20)

***

### Limit

> **Limit**: `"Limit"`

Defined in: [packages/agent/src/errors.ts:19](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L19)

***

### Protocol

> **Protocol**: `"Protocol"`

Defined in: [packages/agent/src/errors.ts:15](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L15)

***

### Reject

> **Reject**: `"Reject"`

Defined in: [packages/agent/src/errors.ts:16](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L16)

***

### Transport

> **Transport**: `"Transport"`

Defined in: [packages/agent/src/errors.ts:17](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L17)

***

### Trust

> **Trust**: `"Trust"`

Defined in: [packages/agent/src/errors.ts:14](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L14)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/errors.ts:21](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/agent/src/errors.ts#L21)
