---
title: QueryResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:34](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/api.ts#L34)


### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/agent/src/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/api.ts#L36)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/agent/src/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/api.ts#L35)
