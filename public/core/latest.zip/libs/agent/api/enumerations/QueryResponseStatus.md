---
title: QueryResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:34](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L34)

## Enumeration Members

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/agent/src/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L36)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/agent/src/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/agent/api.ts#L35)
