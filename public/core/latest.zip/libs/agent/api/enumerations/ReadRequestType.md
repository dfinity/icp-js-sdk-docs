---
title: ReadRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L78)


### Query

> **Query**: `"query"`

Defined in: [packages/agent/src/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L79)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/agent/src/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L80)
