---
title: ReadRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L78)

## Enumeration Members

### Query

> **Query**: `"query"`

Defined in: [packages/core/src/agent/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L79)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/core/src/agent/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L80)
