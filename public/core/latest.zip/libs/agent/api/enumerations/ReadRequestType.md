---
title: ReadRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L78)

## Enumeration Members

### Query

> **Query**: `"query"`

Defined in: [packages/agent/src/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L79)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/agent/src/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L80)
