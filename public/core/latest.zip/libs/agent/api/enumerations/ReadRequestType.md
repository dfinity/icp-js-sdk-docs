---
title: ReadRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L78)


### Query

> **Query**: `"query"`

Defined in: [packages/agent/src/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L79)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/agent/src/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/agent/src/agent/http/types.ts#L80)
