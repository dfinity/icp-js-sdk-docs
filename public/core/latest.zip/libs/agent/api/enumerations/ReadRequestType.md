---
title: ReadRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L78)

## Enumeration Members

### Query

> **Query**: `"query"`

Defined in: [packages/agent/src/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L79)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/agent/src/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L80)
