---
title: LookupSubtreeStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:547](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L547)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:548](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L548)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:550](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L550)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:549](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/certificate.ts#L549)
