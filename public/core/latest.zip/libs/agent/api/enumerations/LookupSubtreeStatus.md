---
title: LookupSubtreeStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:549](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L549)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:550](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L550)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:552](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L552)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:551](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L551)
