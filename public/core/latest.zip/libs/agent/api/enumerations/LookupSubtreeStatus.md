---
title: LookupSubtreeStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:487](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L487)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:488](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L488)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:490](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L490)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:489](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/agent/src/certificate.ts#L489)
