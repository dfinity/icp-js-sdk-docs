---
title: LookupLabelStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:573](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L573)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:574](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L574)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:576](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L576)

***

### Greater

> **Greater**: `"Greater"`

Defined in: [packages/core/src/agent/certificate.ts:578](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L578)

***

### Less

> **Less**: `"Less"`

Defined in: [packages/core/src/agent/certificate.ts:577](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L577)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:575](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L575)
