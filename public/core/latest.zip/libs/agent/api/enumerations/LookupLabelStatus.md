---
title: LookupLabelStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:511](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L511)


### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:512](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L512)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:514](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L514)

***

### Greater

> **Greater**: `"Greater"`

Defined in: [packages/agent/src/certificate.ts:516](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L516)

***

### Less

> **Less**: `"Less"`

Defined in: [packages/agent/src/certificate.ts:515](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L515)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:513](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L513)
