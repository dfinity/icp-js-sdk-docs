---
title: ErrorVerbosity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:55](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L55)

Controls the level of detail included in error messages.
- `Normal` (default): includes error message, call context, and HTTP details, but omits large binary fields (arg, certificate, nonce).
- `Verbose`: same as Normal, but includes hex-encoded binary fields.

To enable verbose mode: `ErrorCode.verbosity = ErrorVerbosity.Verbose`

## Enumeration Members

### Normal

> **Normal**: `"normal"`

Defined in: [packages/core/src/agent/errors.ts:56](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L56)

***

### Verbose

> **Verbose**: `"verbose"`

Defined in: [packages/core/src/agent/errors.ts:57](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/agent/errors.ts#L57)
