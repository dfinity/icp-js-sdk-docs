---
title: ErrorVerbosity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:50](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L50)

Controls the level of detail included in error messages.
- `Normal` (default): includes error message, call context, and HTTP details, but omits large binary fields (arg, certificate, nonce).
- `Verbose`: same as Normal, but includes hex-encoded binary fields.

To enable verbose mode: `ErrorCode.verbosity = ErrorVerbosity.Verbose`

## Enumeration Members

### Normal

> **Normal**: `"normal"`

Defined in: [packages/core/src/agent/errors.ts:51](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L51)

***

### Verbose

> **Verbose**: `"verbose"`

Defined in: [packages/core/src/agent/errors.ts:52](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/errors.ts#L52)
