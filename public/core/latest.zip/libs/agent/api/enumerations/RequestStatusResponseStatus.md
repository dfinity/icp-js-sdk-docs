---
title: RequestStatusResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:85](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L85)

## Enumeration Members

### Done

> **Done**: `"done"`

Defined in: [packages/core/src/agent/agent/http/index.ts:91](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L91)

***

### Processing

> **Processing**: `"processing"`

Defined in: [packages/core/src/agent/agent/http/index.ts:87](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L87)

***

### Received

> **Received**: `"received"`

Defined in: [packages/core/src/agent/agent/http/index.ts:86](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L86)

***

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/http/index.ts:89](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L89)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/http/index.ts:88](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L88)

***

### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/core/src/agent/agent/http/index.ts:90](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L90)
