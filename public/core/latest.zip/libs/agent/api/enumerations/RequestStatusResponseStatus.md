---
title: RequestStatusResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:102](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/index.ts#L102)

Possible values for the request status in the IC state tree.

## See

https://internetcomputer.org/docs/references/ic-interface-spec#state-tree-request-status

## Enumeration Members

### Done

> **Done**: `"done"`

Defined in: [packages/core/src/agent/agent/http/index.ts:114](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/index.ts#L114)

The IC has pruned the response data but remembers the request to prevent replay attacks.

***

### Processing

> **Processing**: `"processing"`

Defined in: [packages/core/src/agent/agent/http/index.ts:106](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/index.ts#L106)

The initial effect of the call has happened or will happen.

***

### Received

> **Received**: `"received"`

Defined in: [packages/core/src/agent/agent/http/index.ts:104](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/index.ts#L104)

The call has made it past the endpoint into the IC's state.

***

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/http/index.ts:110](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/index.ts#L110)

The call failed; reject code and message are available at `/request_status/<id>/reject_code` and `/request_status/<id>/reject_message`.

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/http/index.ts:108](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/index.ts#L108)

The call completed successfully; the reply is available at `/request_status/<id>/reply`.

***

### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/core/src/agent/agent/http/index.ts:112](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/agent/http/index.ts#L112)

The request status path is absent from the state tree, the request is unknown to the IC (never received or pruned after expiry).
