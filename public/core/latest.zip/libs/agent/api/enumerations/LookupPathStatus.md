---
title: LookupPathStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:457](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L457)


### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:459](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L459)

***

### Error

> **Error**: `"Error"`

Defined in: [packages/agent/src/certificate.ts:461](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L461)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:460](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L460)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:458](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/agent/src/certificate.ts#L458)
