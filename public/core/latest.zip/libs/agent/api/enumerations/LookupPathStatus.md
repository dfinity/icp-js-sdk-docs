---
title: LookupPathStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:457](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L457)


### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:459](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L459)

***

### Error

> **Error**: `"Error"`

Defined in: [packages/agent/src/certificate.ts:461](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L461)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:460](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L460)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:458](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/agent/src/certificate.ts#L458)
