---
title: LookupPathStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:519](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L519)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:521](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L521)

***

### Error

> **Error**: `"Error"`

Defined in: [packages/core/src/agent/certificate.ts:523](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L523)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:522](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L522)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:520](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L520)
