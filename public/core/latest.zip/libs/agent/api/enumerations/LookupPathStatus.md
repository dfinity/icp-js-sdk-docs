---
title: LookupPathStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:457](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L457)


### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:459](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L459)

***

### Error

> **Error**: `"Error"`

Defined in: [packages/agent/src/certificate.ts:461](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L461)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:460](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L460)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:458](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/certificate.ts#L458)
