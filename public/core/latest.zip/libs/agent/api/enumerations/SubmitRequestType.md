---
title: SubmitRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:73](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L73)

## Enumeration Members

### Call

> **Call**: `"call"`

Defined in: [packages/agent/src/agent/http/types.ts:74](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L74)
