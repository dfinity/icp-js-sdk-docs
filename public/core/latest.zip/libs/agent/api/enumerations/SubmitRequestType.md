---
title: SubmitRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:73](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L73)


### Call

> **Call**: `"call"`

Defined in: [packages/agent/src/agent/http/types.ts:74](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/agent/src/agent/http/types.ts#L74)
