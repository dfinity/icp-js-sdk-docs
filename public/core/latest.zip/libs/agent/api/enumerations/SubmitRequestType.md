---
title: SubmitRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:73](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/types.ts#L73)

## Enumeration Members

### Call

> **Call**: `"call"`

Defined in: [packages/agent/src/agent/http/types.ts:74](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/types.ts#L74)
