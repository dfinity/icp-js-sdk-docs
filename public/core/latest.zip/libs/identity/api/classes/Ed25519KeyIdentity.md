---
title: Ed25519KeyIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/ed25519.ts:115](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L115)

Ed25519KeyIdentity is an implementation of SignIdentity that uses Ed25519 keys. This class is used to sign and verify messages for an agent.

## Extends

- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new Ed25519KeyIdentity**(`publicKey`, `privateKey`): `Ed25519KeyIdentity`

Defined in: [packages/core/src/identity/identity/ed25519.ts:175](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L175)

#### Parameters

##### publicKey

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

##### privateKey

`Uint8Array`

#### Returns

`Ed25519KeyIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_principal

> `protected` **\_principal**: [`Principal`](../../../principal/api/classes/Principal.md) \| `undefined`

Defined in: [packages/core/src/agent/auth.ts:58](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/auth.ts#L58)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

## Methods

### getKeyPair()

> **getKeyPair**(): [`KeyPair`](../../../agent/api/interfaces/KeyPair.md)

Defined in: [packages/core/src/identity/identity/ed25519.ts:191](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L191)

Return a copy of the key pair.

#### Returns

[`KeyPair`](../../../agent/api/interfaces/KeyPair.md)

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/auth.ts:74](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/auth.ts#L74)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): `Required`\<[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)\>

Defined in: [packages/core/src/identity/identity/ed25519.ts:201](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L201)

Return the public key.

#### Returns

`Required`\<[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`challenge`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [packages/core/src/identity/identity/ed25519.ts:209](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L209)

Signs a blob of data, with this identity's private key.

#### Parameters

##### challenge

`Uint8Array`

challenge to sign with this identity's secretKey, producing a signature

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### toJSON()

> **toJSON**(): [`JsonnableEd25519KeyIdentity`](../type-aliases/JsonnableEd25519KeyIdentity.md)

Defined in: [packages/core/src/identity/identity/ed25519.ts:184](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L184)

Serialize this key to JSON.

#### Returns

[`JsonnableEd25519KeyIdentity`](../type-aliases/JsonnableEd25519KeyIdentity.md)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:87](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/agent/auth.ts#L87)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### fromJSON()

> `static` **fromJSON**(`json`): `Ed25519KeyIdentity`

Defined in: [packages/core/src/identity/identity/ed25519.ts:151](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L151)

#### Parameters

##### json

`string`

#### Returns

`Ed25519KeyIdentity`

***

### fromKeyPair()

> `static` **fromKeyPair**(`publicKey`, `privateKey`): `Ed25519KeyIdentity`

Defined in: [packages/core/src/identity/identity/ed25519.ts:162](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L162)

#### Parameters

##### publicKey

`Uint8Array`

##### privateKey

`Uint8Array`

#### Returns

`Ed25519KeyIdentity`

***

### fromParsedJson()

> `static` **fromParsedJson**(`obj`): `Ed25519KeyIdentity`

Defined in: [packages/core/src/identity/identity/ed25519.ts:143](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L143)

#### Parameters

##### obj

[`JsonnableEd25519KeyIdentity`](../type-aliases/JsonnableEd25519KeyIdentity.md)

#### Returns

`Ed25519KeyIdentity`

***

### fromSecretKey()

> `static` **fromSecretKey**(`secretKey`): `Ed25519KeyIdentity`

Defined in: [packages/core/src/identity/identity/ed25519.ts:166](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L166)

#### Parameters

##### secretKey

`Uint8Array`

#### Returns

`Ed25519KeyIdentity`

***

### generate()

> `static` **generate**(`seed?`): `Ed25519KeyIdentity`

Defined in: [packages/core/src/identity/identity/ed25519.ts:121](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L121)

Generate a new Ed25519KeyIdentity.

#### Parameters

##### seed?

`Uint8Array`\<`ArrayBufferLike`\>

a 32-byte seed for the private key. If not provided, a random seed will be generated.

#### Returns

`Ed25519KeyIdentity`

Ed25519KeyIdentity

***

### verify()

> `static` **verify**(`sig`, `msg`, `pk`): `boolean`

Defined in: [packages/core/src/identity/identity/ed25519.ts:229](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/ed25519.ts#L229)

Verify

#### Parameters

##### sig

`string` \| `ArrayBuffer` \| `Uint8Array`\<`ArrayBufferLike`\>

signature to verify

##### msg

`string` \| `ArrayBuffer` \| `Uint8Array`\<`ArrayBufferLike`\>

message to verify

##### pk

`string` \| `ArrayBuffer` \| `Uint8Array`\<`ArrayBufferLike`\>

public key

#### Returns

`boolean`

- true if the signature is valid, false otherwise
