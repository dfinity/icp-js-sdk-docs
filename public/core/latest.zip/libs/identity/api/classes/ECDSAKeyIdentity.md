---
title: ECDSAKeyIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/ecdsa.ts:52](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L52)

An identity interface that wraps an ECDSA keypair using the P-256 named curve. Supports DER-encoding and decoding for agent calls

## Extends

- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new ECDSAKeyIdentity**(`keyPair`, `derKey`, `subtleCrypto`): `ECDSAKeyIdentity`

Defined in: [packages/identity/src/identity/ecdsa.ts:108](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L108)

#### Parameters

##### keyPair

`CryptoKeyPair`

##### derKey

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

##### subtleCrypto

`SubtleCrypto`

#### Returns

`ECDSAKeyIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_derKey

> `protected` **\_derKey**: [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ecdsa.ts:103](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L103)

***

### \_keyPair

> `protected` **\_keyPair**: `CryptoKeyPair`

Defined in: [packages/identity/src/identity/ecdsa.ts:104](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L104)

***

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:52

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

***

### \_subtleCrypto

> `protected` **\_subtleCrypto**: `SubtleCrypto`

Defined in: [packages/identity/src/identity/ecdsa.ts:105](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L105)

## Methods

### getKeyPair()

> **getKeyPair**(): `CryptoKeyPair`

Defined in: [packages/identity/src/identity/ecdsa.ts:123](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L123)

Return the internally-used key pair.

#### Returns

`CryptoKeyPair`

a CryptoKeyPair

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:65

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md) & [`DerCryptoKey`](../interfaces/DerCryptoKey.md)

Defined in: [packages/identity/src/identity/ecdsa.ts:131](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L131)

Return the public key.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md) & [`DerCryptoKey`](../interfaces/DerCryptoKey.md)

an [& DerCryptoKey](../../../agent/api/interfaces/PublicKey.md)

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`challenge`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [packages/identity/src/identity/ecdsa.ts:146](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L146)

Signs a blob of data, with this identity's private key.

#### Parameters

##### challenge

`Uint8Array`

challenge to sign with this identity's secretKey, producing a signature

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

signature

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: packages/agent/lib/esm/auth.d.ts:72

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### fromKeyPair()

> `static` **fromKeyPair**(`keyPair`, `subtleCrypto?`): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [packages/identity/src/identity/ecdsa.ts:89](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L89)

generates an identity from a public and private key. Please ensure that you are generating these keys securely and protect the user's private key

#### Parameters

##### keyPair

a CryptoKeyPair

`CryptoKeyPair` | \{ `privateKey`: `CryptoKey`; `publicKey`: `CryptoKey`; \}

##### subtleCrypto?

`SubtleCrypto`

a SubtleCrypto interface in case one is not available globally

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

an ECDSAKeyIdentity

***

### generate()

> `static` **generate**(`options?`): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [packages/identity/src/identity/ecdsa.ts:61](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity/src/identity/ecdsa.ts#L61)

Generates a randomly generated identity for use in calls to the Internet Computer.

#### Parameters

##### options?

[`CryptoKeyOptions`](../type-aliases/CryptoKeyOptions.md)

optional settings

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

a ECDSAKeyIdentity
