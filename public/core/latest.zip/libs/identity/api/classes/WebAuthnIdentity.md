---
title: WebAuthnIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/webauthn.ts:137](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L137)

A SignIdentity that uses `navigator.credentials`. See https://webauthn.guide/ for
more information about WebAuthentication.


- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> **new WebAuthnIdentity**(`rawId`, `cose`, `authenticatorAttachment`): `WebAuthnIdentity`

Defined in: [packages/identity/src/identity/webauthn.ts:184](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L184)

#### Parameters

##### rawId

`Uint8Array`

##### cose

`Uint8Array`

##### authenticatorAttachment

`undefined` | `AuthenticatorAttachment`

#### Returns

`WebAuthnIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:52

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

***

### \_publicKey

> `protected` **\_publicKey**: `CosePublicKey`

Defined in: [packages/identity/src/identity/webauthn.ts:182](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L182)

***

### authenticatorAttachment

> `protected` **authenticatorAttachment**: `undefined` \| `AuthenticatorAttachment`

Defined in: [packages/identity/src/identity/webauthn.ts:187](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L187)

***

### rawId

> `readonly` **rawId**: `Uint8Array`

Defined in: [packages/identity/src/identity/webauthn.ts:185](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L185)

## Methods

### getAuthenticatorAttachment()

> **getAuthenticatorAttachment**(): `undefined` \| `AuthenticatorAttachment`

Defined in: [packages/identity/src/identity/webauthn.ts:205](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L205)

WebAuthn level 3 spec introduces a new attribute on successful WebAuthn interactions,
see https://w3c.github.io/webauthn/#dom-publickeycredential-authenticatorattachment.
This attribute is already implemented for Chrome, Safari and Edge.

Given the attribute is only available after a successful interaction, the information is
provided opportunistically and might also be `undefined`.

#### Returns

`undefined` \| `AuthenticatorAttachment`

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:65

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

Defined in: [packages/identity/src/identity/webauthn.ts:193](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L193)

Returns the public key that would match this identity's signature.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`blob`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [packages/identity/src/identity/webauthn.ts:209](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L209)

Signs a blob of data, with this identity's private key.

#### Parameters

##### blob

`Uint8Array`

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### toJSON()

> **toJSON**(): `JsonnableWebAuthnIdentity`

Defined in: [packages/identity/src/identity/webauthn.ts:249](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L249)

Allow for JSON serialization of all information needed to reuse this identity.

#### Returns

`JsonnableWebAuthnIdentity`

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: packages/agent/lib/esm/auth.d.ts:72

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### create()

> `static` **create**(`credentialCreationOptions?`): `Promise`\<`WebAuthnIdentity`\>

Defined in: [packages/identity/src/identity/webauthn.ts:156](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L156)

Create an identity.

#### Parameters

##### credentialCreationOptions?

`CredentialCreationOptions`

an optional CredentialCreationOptions Challenge

#### Returns

`Promise`\<`WebAuthnIdentity`\>

***

### fromJSON()

> `static` **fromJSON**(`json`): `WebAuthnIdentity`

Defined in: [packages/identity/src/identity/webauthn.ts:142](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity/src/identity/webauthn.ts#L142)

Create an identity from a JSON serialization.

#### Parameters

##### json

`string`

json to parse

#### Returns

`WebAuthnIdentity`
