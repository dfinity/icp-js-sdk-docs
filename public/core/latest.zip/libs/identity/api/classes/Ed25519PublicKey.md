---
title: Ed25519PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/ed25519.ts:21](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L21)

A Public Key implementation.

## Implements

- [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ed25519.ts:84](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L84)

##### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`derKey`](../../../agent/api/interfaces/PublicKey.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/identity/src/identity/ed25519.ts:78](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L78)

##### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`rawKey`](../../../agent/api/interfaces/PublicKey.md#rawkey)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ed25519.ts:97](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L97)

#### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`toDer`](../../../agent/api/interfaces/PublicKey.md#toder)

***

### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/identity/src/identity/ed25519.ts:101](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L101)

#### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`toRaw`](../../../agent/api/interfaces/PublicKey.md#toraw)

***

### from()

> `static` **from**(`maybeKey`): `Ed25519PublicKey`

Defined in: [packages/identity/src/identity/ed25519.ts:27](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L27)

Construct Ed25519PublicKey from an existing PublicKey

#### Parameters

##### maybeKey

`unknown`

existing PublicKey, ArrayBuffer, DerEncodedPublicKey, or hex string

#### Returns

`Ed25519PublicKey`

Instance of Ed25519PublicKey

***

### fromDer()

> `static` **fromDer**(`derKey`): `Ed25519PublicKey`

Defined in: [packages/identity/src/identity/ed25519.ts:55](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L55)

#### Parameters

##### derKey

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Returns

`Ed25519PublicKey`

***

### fromRaw()

> `static` **fromRaw**(`rawKey`): `Ed25519PublicKey`

Defined in: [packages/identity/src/identity/ed25519.ts:51](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L51)

#### Parameters

##### rawKey

`Uint8Array`

#### Returns

`Ed25519PublicKey`
