---
title: Secp256k1KeyIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/index.ts:15](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/index.ts#L15)

## Deprecated

due to size of dependencies. Use `@dfinity/identity-secp256k1` instead.

## Constructors

### Constructor

> **new Secp256k1KeyIdentity**(): `Secp256k1KeyIdentity`

Defined in: [packages/identity/src/index.ts:16](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/index.ts#L16)

#### Returns

`Secp256k1KeyIdentity`
