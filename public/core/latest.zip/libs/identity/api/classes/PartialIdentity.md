---
title: PartialIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/partial.ts:7](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L7)

A partial delegated identity, representing a delegation chain and the public key that it targets

## Extended by

- [`PartialDelegationIdentity`](PartialDelegationIdentity.md)

## Implements

- [`Identity`](../../../agent/api/interfaces/Identity.md)

## Constructors

### Constructor

> **new PartialIdentity**(`inner`): `PartialIdentity`

Defined in: [packages/core/src/identity/identity/partial.ts:57](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L57)

#### Parameters

##### inner

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

#### Returns

`PartialIdentity`

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/identity/identity/partial.ts:20](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L20)

The DER-encoded public key of this identity.

##### Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/identity/identity/partial.ts:13](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L13)

The raw public key of this identity.

##### Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

## Methods

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/identity/identity/partial.ts:41](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L41)

The [Principal](../../../principal/api/classes/Principal.md) of this identity.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Implementation of

[`Identity`](../../../agent/api/interfaces/Identity.md).[`getPrincipal`](../../../agent/api/interfaces/Identity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

Defined in: [packages/core/src/identity/identity/partial.ts:34](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L34)

The inner [PublicKey](../../../agent/api/interfaces/PublicKey.md) used by this identity.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

***

### toDer()

> **toDer**(): `Uint8Array`

Defined in: [packages/core/src/identity/identity/partial.ts:27](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L27)

The DER-encoded public key of this identity.

#### Returns

`Uint8Array`

***

### transformRequest()

> **transformRequest**(): `Promise`\<`never`\>

Defined in: [packages/core/src/identity/identity/partial.ts:51](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/partial.ts#L51)

Required for the Identity interface, but cannot implemented for just a public key.

#### Returns

`Promise`\<`never`\>

#### Implementation of

[`Identity`](../../../agent/api/interfaces/Identity.md).[`transformRequest`](../../../agent/api/interfaces/Identity.md#transformrequest)
