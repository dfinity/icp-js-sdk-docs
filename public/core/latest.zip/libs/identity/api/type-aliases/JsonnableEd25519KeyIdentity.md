---
title: JsonnableEd25519KeyIdentity
editUrl: false
next: true
prev: true
---

> **JsonnableEd25519KeyIdentity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/identity/src/identity/ed25519.ts:239](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/identity/src/identity/ed25519.ts#L239)
