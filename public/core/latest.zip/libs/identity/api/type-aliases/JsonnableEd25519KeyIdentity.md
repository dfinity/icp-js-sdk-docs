---
title: JsonnableEd25519KeyIdentity
editUrl: false
next: true
prev: true
---

> **JsonnableEd25519KeyIdentity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/core/src/identity/identity/ed25519.ts:246](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/ed25519.ts#L246)
