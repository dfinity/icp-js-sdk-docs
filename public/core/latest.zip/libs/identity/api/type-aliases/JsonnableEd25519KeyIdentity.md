---
title: JsonnableEd25519KeyIdentity
editUrl: false
next: true
prev: true
---

> **JsonnableEd25519KeyIdentity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/identity/src/identity/ed25519.ts:239](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/ed25519.ts#L239)
