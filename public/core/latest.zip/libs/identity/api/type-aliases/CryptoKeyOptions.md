---
title: CryptoKeyOptions
editUrl: false
next: true
prev: true
---

> **CryptoKeyOptions** = `object`

Defined in: [packages/identity/src/identity/ecdsa.ts:12](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/ecdsa.ts#L12)

Options used in a [ECDSAKeyIdentity](../classes/ECDSAKeyIdentity.md)


### extractable?

> `optional` **extractable**: `boolean`

Defined in: [packages/identity/src/identity/ecdsa.ts:13](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/ecdsa.ts#L13)

***

### keyUsages?

> `optional` **keyUsages**: `KeyUsage`[]

Defined in: [packages/identity/src/identity/ecdsa.ts:14](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/ecdsa.ts#L14)

***

### subtleCrypto?

> `optional` **subtleCrypto**: `SubtleCrypto`

Defined in: [packages/identity/src/identity/ecdsa.ts:15](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/ecdsa.ts#L15)
