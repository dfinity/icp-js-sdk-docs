---
title: DelegationValidChecks
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/delegation.ts:357](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/delegation.ts#L357)

List of things to check for a delegation chain validity.

## Properties

### scope?

> `optional` **scope?**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md) \| (`string` \| [`Principal`](../../../principal/api/classes/Principal.md))[]

Defined in: [packages/core/src/identity/identity/delegation.ts:361](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/delegation.ts#L361)

Check that the scope is amongst the scopes that this delegation has access to.
