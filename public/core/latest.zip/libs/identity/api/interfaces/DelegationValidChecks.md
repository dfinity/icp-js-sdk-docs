---
title: DelegationValidChecks
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:345](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/delegation.ts#L345)

List of things to check for a delegation chain validity.


### scope?

> `optional` **scope**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md) \| (`string` \| [`Principal`](../../../principal/api/classes/Principal.md))[]

Defined in: [packages/identity/src/identity/delegation.ts:349](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity/src/identity/delegation.ts#L349)

Check that the scope is amongst the scopes that this delegation has access to.
