---
title: Signer
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/attributes.ts:15](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/attributes.ts#L15)

The canister that signed the attributes.

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/identity/identity/attributes.ts:16](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/attributes.ts#L16)
