---
title: DerCryptoKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/ecdsa.ts:20](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/identity/ecdsa.ts#L20)

## Extends

- `CryptoKey`

## Properties

### algorithm

> `readonly` **algorithm**: `KeyAlgorithm`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6462

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/algorithm)

#### Inherited from

`CryptoKey.algorithm`

***

### extractable

> `readonly` **extractable**: `boolean`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6464

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/extractable)

#### Inherited from

`CryptoKey.extractable`

***

### toDer()

> **toDer**: () => [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/identity/identity/ecdsa.ts:21](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/identity/ecdsa.ts#L21)

#### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

***

### type

> `readonly` **type**: `KeyType`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6466

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/type)

#### Inherited from

`CryptoKey.type`

***

### usages

> `readonly` **usages**: `KeyUsage`[]

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6468

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/usages)

#### Inherited from

`CryptoKey.usages`
