---
title: DerCryptoKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/ecdsa.ts:20](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/ecdsa.ts#L20)

## Extends

- `CryptoKey`

## Properties

### algorithm

> `readonly` **algorithm**: `KeyAlgorithm`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.dom.d.ts:8469

The read-only **`algorithm`** property of the CryptoKey interface returns an object describing the algorithm for which this key can be used, and any associated extra parameters.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/algorithm)

#### Inherited from

`CryptoKey.algorithm`

***

### extractable

> `readonly` **extractable**: `boolean`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.dom.d.ts:8475

The read-only **`extractable`** property of the CryptoKey interface indicates whether or not the key may be extracted using `SubtleCrypto.exportKey()` or `SubtleCrypto.wrapKey()`.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/extractable)

#### Inherited from

`CryptoKey.extractable`

***

### toDer

> **toDer**: () => [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/identity/identity/ecdsa.ts:21](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/identity/ecdsa.ts#L21)

#### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

***

### type

> `readonly` **type**: `KeyType`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.dom.d.ts:8481

The read-only **`type`** property of the CryptoKey interface indicates which kind of key is represented by the object.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/type)

#### Inherited from

`CryptoKey.type`

***

### usages

> `readonly` **usages**: `KeyUsage`[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.dom.d.ts:8487

The read-only **`usages`** property of the CryptoKey interface indicates what can be done with the key.

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/usages)

#### Inherited from

`CryptoKey.usages`
