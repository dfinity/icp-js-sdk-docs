---
title: DerCryptoKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/ecdsa.ts:25](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/ecdsa.ts#L25)

## Extends

- `CryptoKey`

## Properties

### algorithm

> `readonly` **algorithm**: `KeyAlgorithm`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6462

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/algorithm)

#### Inherited from

`CryptoKey.algorithm`

***

### extractable

> `readonly` **extractable**: `boolean`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6464

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/extractable)

#### Inherited from

`CryptoKey.extractable`

***

### toDer()

> **toDer**: () => [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/ecdsa.ts:26](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/ecdsa.ts#L26)

#### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

***

### type

> `readonly` **type**: `KeyType`

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6466

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/type)

#### Inherited from

`CryptoKey.type`

***

### usages

> `readonly` **usages**: `KeyUsage`[]

Defined in: node\_modules/.pnpm/typescript@5.8.3/node\_modules/typescript/lib/lib.dom.d.ts:6468

[MDN Reference](https://developer.mozilla.org/docs/Web/API/CryptoKey/usages)

#### Inherited from

`CryptoKey.usages`
