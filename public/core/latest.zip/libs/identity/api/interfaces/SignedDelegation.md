---
title: SignedDelegation
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:80](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/identity/src/identity/delegation.ts#L80)

A signed delegation, which lends its identity to the public key in the delegation
object. This is constructed by `DelegationChain.create()`.

DelegationChain


### delegation

> **delegation**: [`Delegation`](../classes/Delegation.md)

Defined in: [packages/identity/src/identity/delegation.ts:81](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/identity/src/identity/delegation.ts#L81)

***

### signature

> **signature**: [`Signature`](../../../agent/api/type-aliases/Signature.md)

Defined in: [packages/identity/src/identity/delegation.ts:82](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/identity/src/identity/delegation.ts#L82)
