---
title: SignedDelegation
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:92](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L92)

A signed delegation, which lends its identity to the public key in the delegation
object. This is constructed by `DelegationChain.create()`.

DelegationChain

## Properties

### delegation

> **delegation**: [`Delegation`](../classes/Delegation.md)

Defined in: [packages/identity/src/identity/delegation.ts:93](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L93)

***

### signature

> **signature**: [`Signature`](../../../agent/api/type-aliases/Signature.md)

Defined in: [packages/identity/src/identity/delegation.ts:94](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L94)
