---
title: JsonnableDelegationChain
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/delegation.ts:132](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/delegation.ts#L132)

## Properties

### delegations

> **delegations**: `object`[]

Defined in: [packages/core/src/identity/identity/delegation.ts:134](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/delegation.ts#L134)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `string`

##### delegation.pubkey

> **pubkey**: `string`

##### delegation.targets?

> `optional` **targets?**: `string`[]

#### signature

> **signature**: `string`

***

### publicKey

> **publicKey**: `string`

Defined in: [packages/core/src/identity/identity/delegation.ts:133](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/identity/identity/delegation.ts#L133)
