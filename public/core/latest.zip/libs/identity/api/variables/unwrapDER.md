---
title: unwrapDER
editUrl: false
next: true
prev: true
---

> `const` **unwrapDER**: (`derEncoded`, `oid`) => `Uint8Array`

Defined in: packages/agent/lib/esm/der.d.ts:33

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`


### derEncoded

`Uint8Array`

The DER encoded and tagged data

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

## Returns

`Uint8Array`

The unwrapped payload
