---
title: wrapDER
editUrl: false
next: true
prev: true
---

> **wrapDER**(`payload`, `oid`): `Uint8Array`

Defined in: packages/agent/lib/esm/der.d.ts:24

Wraps the given `payload` in a DER encoding tagged with the given encoded `oid` like so:
`SEQUENCE(oid, BITSTRING(payload))`


### payload

`Uint8Array`

The payload to encode as the bit string

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) OID to tag the payload with

## Returns

`Uint8Array`
