---
title: isDelegationValid
editUrl: false
next: true
prev: true
---

> **isDelegationValid**(`chain`, `checks?`): `boolean`

Defined in: [packages/identity/src/identity/delegation.ts:370](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/identity/src/identity/delegation.ts#L370)

Analyze a DelegationChain and validate that it's valid, ie. not expired and apply to the
scope.


### chain

[`DelegationChain`](../classes/DelegationChain.md)

The chain to validate.

### checks?

[`DelegationValidChecks`](../interfaces/DelegationValidChecks.md)

Various checks to validate on the chain.

## Returns

`boolean`
