---
title: isDelegationValid
editUrl: false
next: true
prev: true
---

> **isDelegationValid**(`chain`, `checks?`): `boolean`

Defined in: [packages/identity/src/identity/delegation.ts:358](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/identity/src/identity/delegation.ts#L358)

Analyze a DelegationChain and validate that it's valid, ie. not expired and apply to the
scope.


### chain

[`DelegationChain`](../classes/DelegationChain.md)

The chain to validate.

### checks?

[`DelegationValidChecks`](../interfaces/DelegationValidChecks.md)

Various checks to validate on the chain.

## Returns

`boolean`
