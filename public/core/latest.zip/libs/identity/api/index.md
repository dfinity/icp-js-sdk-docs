---
title: Overview
editUrl: false
next: true
prev: true
---

## Classes

- [CryptoError](classes/CryptoError.md)
- [Delegation](classes/Delegation.md)
- [DelegationChain](classes/DelegationChain.md)
- [DelegationIdentity](classes/DelegationIdentity.md)
- [ECDSAKeyIdentity](classes/ECDSAKeyIdentity.md)
- [Ed25519KeyIdentity](classes/Ed25519KeyIdentity.md)
- [Ed25519PublicKey](classes/Ed25519PublicKey.md)
- [PartialDelegationIdentity](classes/PartialDelegationIdentity.md)
- [PartialIdentity](classes/PartialIdentity.md)
- [WebAuthnIdentity](classes/WebAuthnIdentity.md)

## Interfaces

- [CryptoKeyOptions](interfaces/CryptoKeyOptions.md)
- [DelegationValidChecks](interfaces/DelegationValidChecks.md)
- [DerCryptoKey](interfaces/DerCryptoKey.md)
- [JsonnableDelegationChain](interfaces/JsonnableDelegationChain.md)
- [SignedDelegation](interfaces/SignedDelegation.md)

## Type Aliases

- [JsonnableEd25519KeyIdentity](type-aliases/JsonnableEd25519KeyIdentity.md)

## Functions

- [isDelegationValid](functions/isDelegationValid.md)

## References

### DER\_COSE\_OID

Re-exports [DER_COSE_OID](../../agent/api/variables/DER_COSE_OID.md)

***

### ED25519\_OID

Re-exports [ED25519_OID](../../agent/api/variables/ED25519_OID.md)

***

### unwrapDER

Re-exports [unwrapDER](../../agent/api/functions/unwrapDER.md)

***

### wrapDER

Re-exports [wrapDER](../../agent/api/functions/wrapDER.md)
