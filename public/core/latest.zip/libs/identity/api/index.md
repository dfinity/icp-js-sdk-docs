---
title: Overview
editUrl: false
next: true
prev: true
---


- [CryptoError](classes/CryptoError.md)
- [Delegation](classes/Delegation.md)
- [DelegationChain](classes/DelegationChain.md)
- [DelegationIdentity](classes/DelegationIdentity.md)
- [ECDSAKeyIdentity](classes/ECDSAKeyIdentity.md)
- [Ed25519KeyIdentity](classes/Ed25519KeyIdentity.md)
- [Ed25519PublicKey](classes/Ed25519PublicKey.md)
- [PartialDelegationIdentity](classes/PartialDelegationIdentity.md)
- [PartialIdentity](classes/PartialIdentity.md)
- [~~Secp256k1KeyIdentity~~](classes/Secp256k1KeyIdentity.md)
- [WebAuthnIdentity](classes/WebAuthnIdentity.md)

## Interfaces

- [DelegationValidChecks](interfaces/DelegationValidChecks.md)
- [DerCryptoKey](interfaces/DerCryptoKey.md)
- [JsonnableDelegationChain](interfaces/JsonnableDelegationChain.md)
- [SignedDelegation](interfaces/SignedDelegation.md)

## Type Aliases

- [CryptoKeyOptions](type-aliases/CryptoKeyOptions.md)
- [JsonnableEd25519KeyIdentity](type-aliases/JsonnableEd25519KeyIdentity.md)

## Variables

- [DER\_COSE\_OID](variables/DER_COSE_OID.md)
- [ED25519\_OID](variables/ED25519_OID.md)
- [unwrapDER](variables/unwrapDER.md)

## Functions

- [isDelegationValid](functions/isDelegationValid.md)
- [wrapDER](functions/wrapDER.md)
