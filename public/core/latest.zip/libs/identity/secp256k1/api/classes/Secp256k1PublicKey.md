---
title: Secp256k1PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:27](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L27)

A Public Key implementation.

## Implements

- [`PublicKey`](../../../../agent/api/interfaces/PublicKey.md)

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:89](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L89)

##### Returns

[`DerEncodedPublicKey`](../../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../../agent/api/interfaces/PublicKey.md).[`derKey`](../../../../agent/api/interfaces/PublicKey.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:83](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L83)

##### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../../agent/api/interfaces/PublicKey.md).[`rawKey`](../../../../agent/api/interfaces/PublicKey.md#rawkey)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:99](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L99)

#### Returns

[`DerEncodedPublicKey`](../../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../../agent/api/interfaces/PublicKey.md).[`toDer`](../../../../agent/api/interfaces/PublicKey.md#toder)

***

### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:103](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L103)

#### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../../agent/api/interfaces/PublicKey.md).[`toRaw`](../../../../agent/api/interfaces/PublicKey.md#toraw)

***

### from()

> `static` **from**(`maybeKey`): `Secp256k1PublicKey`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:41](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L41)

Construct Secp256k1PublicKey from an existing PublicKey

#### Parameters

##### maybeKey

`unknown`

existing PublicKey, ArrayBuffer, DerEncodedPublicKey, or hex string

#### Returns

`Secp256k1PublicKey`

Instance of Secp256k1PublicKey

***

### fromDer()

> `static` **fromDer**(`derKey`): `Secp256k1PublicKey`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:32](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L32)

#### Parameters

##### derKey

[`DerEncodedPublicKey`](../../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Returns

`Secp256k1PublicKey`

***

### fromRaw()

> `static` **fromRaw**(`rawKey`): `Secp256k1PublicKey`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:28](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/identity/secp256k1/secp256k1.ts#L28)

#### Parameters

##### rawKey

`Uint8Array`

#### Returns

`Secp256k1PublicKey`
