---
title: JsonValue
editUrl: false
next: true
prev: true
---

> **JsonValue** = `boolean` \| `string` \| `number` \| `bigint` \| [`JsonArray`](../interfaces/JsonArray.md) \| [`JsonObject`](../interfaces/JsonObject.md)

Defined in: [packages/candid/src/types.ts:7](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/types.ts#L7)
