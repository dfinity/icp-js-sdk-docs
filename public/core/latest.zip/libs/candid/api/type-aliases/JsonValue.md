---
title: JsonValue
editUrl: false
next: true
prev: true
---

> **JsonValue** = `boolean` \| `string` \| `number` \| `bigint` \| [`JsonArray`](../interfaces/JsonArray.md) \| [`JsonObject`](../interfaces/JsonObject.md)

Defined in: [packages/candid/src/types.ts:7](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/types.ts#L7)
