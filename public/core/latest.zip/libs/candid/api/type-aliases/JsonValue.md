---
title: JsonValue
editUrl: false
next: true
prev: true
---

> **JsonValue** = `boolean` \| `string` \| `number` \| `bigint` \| [`JsonArray`](../interfaces/JsonArray.md) \| [`JsonObject`](../interfaces/JsonObject.md)

Defined in: [packages/candid/src/types.ts:7](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/types.ts#L7)
