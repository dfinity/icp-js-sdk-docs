---
title: JsonValue
editUrl: false
next: true
prev: true
---

> **JsonValue** = `boolean` \| `string` \| `number` \| `bigint` \| [`JsonArray`](../interfaces/JsonArray.md) \| [`JsonObject`](../interfaces/JsonObject.md)

Defined in: [packages/candid/src/types.ts:7](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/types.ts#L7)
