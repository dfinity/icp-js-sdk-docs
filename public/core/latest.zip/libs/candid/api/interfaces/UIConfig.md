---
title: UIConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:10](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L10)


### form?

> `optional` **form**: [`InputForm`](../classes/InputForm.md)

Defined in: [packages/candid/src/candid-core.ts:12](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L12)

***

### input?

> `optional` **input**: `HTMLElement`

Defined in: [packages/candid/src/candid-core.ts:11](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L11)

## Methods

### parse()

> **parse**(`t`, `config`, `v`): `any`

Defined in: [packages/candid/src/candid-core.ts:13](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L13)

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)

##### config

[`ParseConfig`](ParseConfig.md)

##### v

`string`

#### Returns

`any`
