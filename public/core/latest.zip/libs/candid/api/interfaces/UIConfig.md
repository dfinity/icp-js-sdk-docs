---
title: UIConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:10](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/candid-core.ts#L10)

## Properties

### form?

> `optional` **form**: [`InputForm`](../classes/InputForm.md)

Defined in: [packages/candid/src/candid-core.ts:12](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/candid-core.ts#L12)

***

### input?

> `optional` **input**: `HTMLElement`

Defined in: [packages/candid/src/candid-core.ts:11](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/candid-core.ts#L11)

## Methods

### parse()

> **parse**(`t`, `config`, `v`): `any`

Defined in: [packages/candid/src/candid-core.ts:13](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/candid-core.ts#L13)

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)

##### config

[`ParseConfig`](ParseConfig.md)

##### v

`string`

#### Returns

`any`
