---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/types.ts:5](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/types.ts#L5)

## Extends

- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

\[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
