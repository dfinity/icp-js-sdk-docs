---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/types.ts:5](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/types.ts#L5)

## Extends

- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

\[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
