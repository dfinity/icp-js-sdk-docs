---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/types.ts:5](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/types.ts#L5)


- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

\[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
