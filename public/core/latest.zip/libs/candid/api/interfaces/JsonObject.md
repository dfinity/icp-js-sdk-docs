---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/types.ts:5](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/types.ts#L5)


- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

\[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
