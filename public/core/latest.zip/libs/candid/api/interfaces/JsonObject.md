---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/types.ts:5](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/types.ts#L5)

## Extends

- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

> \[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
