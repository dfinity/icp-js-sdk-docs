---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/types.ts:5](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/types.ts#L5)

## Extends

- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

> \[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
