---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/candid-core.ts#L6)


### random?

> `optional` **random**: `boolean`

Defined in: [packages/candid/src/candid-core.ts:7](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/candid-core.ts#L7)
