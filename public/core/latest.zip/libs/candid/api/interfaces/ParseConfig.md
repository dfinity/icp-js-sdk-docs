---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/candid-core.ts#L6)

## Properties

### random?

> `optional` **random**: `boolean`

Defined in: [packages/candid/src/candid-core.ts:7](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/candid-core.ts#L7)
