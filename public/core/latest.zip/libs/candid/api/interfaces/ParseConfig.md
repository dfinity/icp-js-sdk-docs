---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:5](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L5)

## Properties

### random?

> `optional` **random?**: `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L6)
