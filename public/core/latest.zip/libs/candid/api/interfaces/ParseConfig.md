---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:5](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L5)

## Properties

### random?

> `optional` **random?**: `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L6)
