---
title: FormConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:15](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L15)

## Properties

### container?

> `optional` **container?**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:19](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L19)

***

### event?

> `optional` **event?**: `string`

Defined in: [packages/core/src/candid/candid-core.ts:17](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L17)

***

### labelMap?

> `optional` **labelMap?**: `Record`\<`string`, `string`\>

Defined in: [packages/core/src/candid/candid-core.ts:18](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L18)

***

### open?

> `optional` **open?**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:16](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L16)

## Methods

### render()

> **render**(`t`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/core/src/candid/candid-core.ts:20](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L20)

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)

#### Returns

[`InputBox`](../classes/InputBox.md)
