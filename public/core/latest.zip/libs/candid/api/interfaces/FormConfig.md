---
title: FormConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:16](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L16)


### container?

> `optional` **container**: `HTMLElement`

Defined in: [packages/candid/src/candid-core.ts:20](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L20)

***

### event?

> `optional` **event**: `string`

Defined in: [packages/candid/src/candid-core.ts:18](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L18)

***

### labelMap?

> `optional` **labelMap**: `Record`\<`string`, `string`\>

Defined in: [packages/candid/src/candid-core.ts:19](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L19)

***

### open?

> `optional` **open**: `HTMLElement`

Defined in: [packages/candid/src/candid-core.ts:17](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L17)

## Methods

### render()

> **render**(`t`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-core.ts:21](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-core.ts#L21)

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)

#### Returns

[`InputBox`](../classes/InputBox.md)
