---
title: renderInput
editUrl: false
next: true
prev: true
---

> **renderInput**(`t`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:208](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-ui.ts#L208)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL type

## Returns

[`InputBox`](../classes/InputBox.md)

an input for that type
