---
title: readIntLE
editUrl: false
next: true
prev: true
---

> **readIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:224](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/utils/leb128.ts#L224)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
