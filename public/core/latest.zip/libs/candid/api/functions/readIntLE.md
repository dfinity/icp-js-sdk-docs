---
title: readIntLE
editUrl: false
next: true
prev: true
---

> **readIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:223](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/leb128.ts#L223)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
