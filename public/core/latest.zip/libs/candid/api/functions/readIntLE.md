---
title: readIntLE
editUrl: false
next: true
prev: true
---

> **readIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:224](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/leb128.ts#L224)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
