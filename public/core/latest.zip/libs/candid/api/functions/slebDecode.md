---
title: slebDecode
editUrl: false
next: true
prev: true
---

> **slebDecode**(`pipe`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:135](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/utils/leb128.ts#L135)

Decode a leb encoded buffer into a bigint. The number is decoded with support for negative
signed-leb encoding.

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the signed leb encoded bits.

## Returns

`bigint`
