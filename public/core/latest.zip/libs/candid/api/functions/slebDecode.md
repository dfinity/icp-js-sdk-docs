---
title: slebDecode
editUrl: false
next: true
prev: true
---

> **slebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:135](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/utils/leb128.ts#L135)

Decode a leb encoded buffer into a bigint. The number is decoded with support for negative
signed-leb encoding.

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the signed leb encoded bits.

## Returns

`bigint`
