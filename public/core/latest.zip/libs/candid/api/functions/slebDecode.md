---
title: slebDecode
editUrl: false
next: true
prev: true
---

> **slebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:135](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/leb128.ts#L135)

Decode a leb encoded buffer into a bigint. The number is decoded with support for negative
signed-leb encoding.


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the signed leb encoded bits.

## Returns

`bigint`
