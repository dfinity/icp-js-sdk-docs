---
title: slebDecode
editUrl: false
next: true
prev: true
---

> **slebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:135](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/utils/leb128.ts#L135)

Decode a leb encoded buffer into a bigint. The number is decoded with support for negative
signed-leb encoding.


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the signed leb encoded bits.

## Returns

`bigint`
