---
title: uint8ToDataView
editUrl: false
next: true
prev: true
---

> **uint8ToDataView**(`uint8`): `DataView`

Defined in: [packages/core/src/candid/utils/buffer.ts:216](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/utils/buffer.ts#L216)

Helpers to convert a Uint8Array to a DataView.

## Parameters

### uint8

`Uint8Array`

Uint8Array

## Returns

`DataView`

DataView
