---
title: uint8ToDataView
editUrl: false
next: true
prev: true
---

> **uint8ToDataView**(`uint8`): `DataView`

Defined in: [packages/candid/src/utils/buffer.ts:216](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/utils/buffer.ts#L216)

Helpers to convert a Uint8Array to a DataView.

## Parameters

### uint8

`Uint8Array`

Uint8Array

## Returns

`DataView`

DataView
