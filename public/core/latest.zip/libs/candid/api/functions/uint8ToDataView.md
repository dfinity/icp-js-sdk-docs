---
title: uint8ToDataView
editUrl: false
next: true
prev: true
---

> **uint8ToDataView**(`uint8`): `DataView`

Defined in: [packages/candid/src/utils/buffer.ts:216](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/utils/buffer.ts#L216)

Helpers to convert a Uint8Array to a DataView.

## Parameters

### uint8

`Uint8Array`

Uint8Array

## Returns

`DataView`

DataView
