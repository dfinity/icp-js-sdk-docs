---
title: concat
editUrl: false
next: true
prev: true
---

> **concat**(...`uint8Arrays`): `Uint8Array`

Defined in: [packages/candid/src/utils/buffer.ts:5](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/utils/buffer.ts#L5)

Concatenate multiple Uint8Arrays.


### uint8Arrays

...`Uint8Array`\<`ArrayBufferLike`\>[]

The Uint8Arrays to concatenate.

## Returns

`Uint8Array`
