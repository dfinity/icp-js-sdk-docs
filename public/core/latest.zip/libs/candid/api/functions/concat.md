---
title: concat
editUrl: false
next: true
prev: true
---

> **concat**(...`uint8Arrays`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:5](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/utils/buffer.ts#L5)

Concatenate multiple Uint8Arrays.

## Parameters

### uint8Arrays

...`Uint8Array`\<`ArrayBufferLike`\>[]

The Uint8Arrays to concatenate.

## Returns

`Uint8Array`
