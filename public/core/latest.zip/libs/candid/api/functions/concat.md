---
title: concat
editUrl: false
next: true
prev: true
---

> **concat**(...`uint8Arrays`): `Uint8Array`

Defined in: [packages/candid/src/utils/buffer.ts:5](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/utils/buffer.ts#L5)

Concatenate multiple Uint8Arrays.

## Parameters

### uint8Arrays

...`Uint8Array`\<`ArrayBufferLike`\>[]

The Uint8Arrays to concatenate.

## Returns

`Uint8Array`
