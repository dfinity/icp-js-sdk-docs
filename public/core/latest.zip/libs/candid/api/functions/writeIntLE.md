---
title: writeIntLE
editUrl: false
next: true
prev: true
---

> **writeIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:176](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/utils/leb128.ts#L176)


### value

bigint or number

`number` | `bigint`

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
