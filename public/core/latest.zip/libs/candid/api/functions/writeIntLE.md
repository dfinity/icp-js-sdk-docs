---
title: writeIntLE
editUrl: false
next: true
prev: true
---

> **writeIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:175](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/utils/leb128.ts#L175)

## Parameters

### value

`number` \| `bigint`

bigint or number

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
