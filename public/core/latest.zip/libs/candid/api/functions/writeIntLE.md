---
title: writeIntLE
editUrl: false
next: true
prev: true
---

> **writeIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:176](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/utils/leb128.ts#L176)

## Parameters

### value

bigint or number

`number` | `bigint`

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
