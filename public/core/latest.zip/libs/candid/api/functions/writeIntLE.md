---
title: writeIntLE
editUrl: false
next: true
prev: true
---

> **writeIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:176](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/leb128.ts#L176)


### value

bigint or number

`number` | `bigint`

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
