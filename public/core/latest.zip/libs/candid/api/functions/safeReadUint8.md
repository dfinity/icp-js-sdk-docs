---
title: safeReadUint8
editUrl: false
next: true
prev: true
---

> **safeReadUint8**(`pipe`): `number`

Defined in: [packages/core/src/candid/utils/leb128.ts:31](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/leb128.ts#L31)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

PipeArrayBuffer simulating buffer-pipe api

## Returns

`number`
