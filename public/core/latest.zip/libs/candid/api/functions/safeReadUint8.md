---
title: safeReadUint8
editUrl: false
next: true
prev: true
---

> **safeReadUint8**(`pipe`): `number`

Defined in: [packages/core/src/candid/utils/leb128.ts:31](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/utils/leb128.ts#L31)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

PipeArrayBuffer simulating buffer-pipe api

## Returns

`number`
