---
title: safeReadUint8
editUrl: false
next: true
prev: true
---

> **safeReadUint8**(`pipe`): `number`

Defined in: [packages/candid/src/utils/leb128.ts:31](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/utils/leb128.ts#L31)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

PipeArrayBuffer simulating buffer-pipe api

## Returns

`number`
