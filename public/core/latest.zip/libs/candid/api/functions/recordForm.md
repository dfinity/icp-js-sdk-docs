---
title: recordForm
editUrl: false
next: true
prev: true
---

> **recordForm**(`fields`, `config`): [`RecordForm`](../classes/RecordForm.md)

Defined in: [packages/candid/src/candid-ui.ts:15](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-ui.ts#L15)


### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`RecordForm`](../classes/RecordForm.md)
