---
title: optForm
editUrl: false
next: true
prev: true
---

> **optForm**(`ty`, `config`): [`OptionForm`](../classes/OptionForm.md)

Defined in: [packages/core/src/candid/candid-ui.ts:24](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/candid-ui.ts#L24)

## Parameters

### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`OptionForm`](../classes/OptionForm.md)
