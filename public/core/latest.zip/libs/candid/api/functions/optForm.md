---
title: optForm
editUrl: false
next: true
prev: true
---

> **optForm**(`ty`, `config`): [`OptionForm`](../classes/OptionForm.md)

Defined in: [packages/candid/src/candid-ui.ts:24](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/candid-ui.ts#L24)

## Parameters

### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`OptionForm`](../classes/OptionForm.md)
