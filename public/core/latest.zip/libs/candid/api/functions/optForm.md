---
title: optForm
editUrl: false
next: true
prev: true
---

> **optForm**(`ty`, `config`): [`OptionForm`](../classes/OptionForm.md)

Defined in: [packages/candid/src/candid-ui.ts:24](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/candid-ui.ts#L24)

## Parameters

### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`OptionForm`](../classes/OptionForm.md)
