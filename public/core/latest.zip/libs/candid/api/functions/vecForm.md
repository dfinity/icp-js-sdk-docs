---
title: vecForm
editUrl: false
next: true
prev: true
---

> **vecForm**(`ty`, `config`): [`VecForm`](../classes/VecForm.md)

Defined in: [packages/core/src/candid/candid-ui.ts:27](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-ui.ts#L27)

## Parameters

### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VecForm`](../classes/VecForm.md)
