---
title: vecForm
editUrl: false
next: true
prev: true
---

> **vecForm**(`ty`, `config`): [`VecForm`](../classes/VecForm.md)

Defined in: [packages/candid/src/candid-ui.ts:27](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/candid-ui.ts#L27)

## Parameters

### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VecForm`](../classes/VecForm.md)
