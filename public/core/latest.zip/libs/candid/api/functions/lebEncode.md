---
title: lebEncode
editUrl: false
next: true
prev: true
---

> **lebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:44](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/leb128.ts#L44)

Encode a positive number (or bigint) into a Buffer. The number will be floored to the
nearest integer.

## Parameters

### value

`number` \| `bigint`

The number to encode.

## Returns

`Uint8Array`
