---
title: lebEncode
editUrl: false
next: true
prev: true
---

> **lebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:44](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/utils/leb128.ts#L44)

Encode a positive number (or bigint) into a Buffer. The number will be floored to the
nearest integer.

## Parameters

### value

`number` \| `bigint`

The number to encode.

## Returns

`Uint8Array`
