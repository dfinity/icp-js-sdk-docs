---
title: writeUIntLE
editUrl: false
next: true
prev: true
---

> **writeUIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:163](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/utils/leb128.ts#L163)

## Parameters

### value

bigint or number

`number` | `bigint`

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
