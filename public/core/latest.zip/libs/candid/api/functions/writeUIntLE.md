---
title: writeUIntLE
editUrl: false
next: true
prev: true
---

> **writeUIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:162](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/utils/leb128.ts#L162)

## Parameters

### value

`number` \| `bigint`

bigint or number

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
