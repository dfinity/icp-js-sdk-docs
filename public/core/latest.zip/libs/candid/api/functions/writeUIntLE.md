---
title: writeUIntLE
editUrl: false
next: true
prev: true
---

> **writeUIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:162](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/leb128.ts#L162)

## Parameters

### value

`number` \| `bigint`

bigint or number

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
