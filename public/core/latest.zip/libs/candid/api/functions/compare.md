---
title: compare
editUrl: false
next: true
prev: true
---

> **compare**(`u1`, `u2`): `number`

Defined in: [packages/core/src/candid/utils/buffer.ts:189](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L189)

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`number`

number - negative if u1 < u2, positive if u1 > u2, 0 if u1 === u2
