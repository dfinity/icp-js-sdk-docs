---
title: compare
editUrl: false
next: true
prev: true
---

> **compare**(`u1`, `u2`): `number`

Defined in: [packages/candid/src/utils/buffer.ts:189](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/utils/buffer.ts#L189)

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`number`

number - negative if u1 < u2, positive if u1 > u2, 0 if u1 === u2
