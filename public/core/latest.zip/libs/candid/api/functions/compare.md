---
title: compare
editUrl: false
next: true
prev: true
---

> **compare**(`u1`, `u2`): `number`

Defined in: [packages/candid/src/utils/buffer.ts:189](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/buffer.ts#L189)


### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`number`

number - negative if u1 < u2, positive if u1 > u2, 0 if u1 === u2
