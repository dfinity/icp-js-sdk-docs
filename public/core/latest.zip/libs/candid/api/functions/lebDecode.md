---
title: lebDecode
editUrl: false
next: true
prev: true
---

> **lebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:74](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/utils/leb128.ts#L74)

Decode a leb encoded buffer into a bigint. The number will always be positive (does not
support signed leb encoding).

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the leb encoded bits.

## Returns

`bigint`
