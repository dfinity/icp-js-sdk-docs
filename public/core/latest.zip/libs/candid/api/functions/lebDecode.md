---
title: lebDecode
editUrl: false
next: true
prev: true
---

> **lebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:74](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/leb128.ts#L74)

Decode a leb encoded buffer into a bigint. The number will always be positive (does not
support signed leb encoding).


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the leb encoded bits.

## Returns

`bigint`
