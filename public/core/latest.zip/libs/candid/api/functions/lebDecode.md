---
title: lebDecode
editUrl: false
next: true
prev: true
---

> **lebDecode**(`pipe`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:74](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/utils/leb128.ts#L74)

Decode a leb encoded buffer into a bigint. The number will always be positive (does not
support signed leb encoding).


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the leb encoded bits.

## Returns

`bigint`
