---
title: slebEncode
editUrl: false
next: true
prev: true
---

> **slebEncode**(`value`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:93](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/utils/leb128.ts#L93)

Encode a number (or bigint) into a Buffer, with support for negative numbers. The number
will be floored to the nearest integer.

## Parameters

### value

The number to encode.

`number` | `bigint`

## Returns

`Uint8Array`
