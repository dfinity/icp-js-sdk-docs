---
title: slebEncode
editUrl: false
next: true
prev: true
---

> **slebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:93](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/utils/leb128.ts#L93)

Encode a number (or bigint) into a Buffer, with support for negative numbers. The number
will be floored to the nearest integer.

## Parameters

### value

The number to encode.

`number` | `bigint`

## Returns

`Uint8Array`
