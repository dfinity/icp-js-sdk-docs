---
title: variantForm
editUrl: false
next: true
prev: true
---

> **variantForm**(`fields`, `config`): [`VariantForm`](../classes/VariantForm.md)

Defined in: [packages/candid/src/candid-ui.ts:21](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-ui.ts#L21)


### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VariantForm`](../classes/VariantForm.md)
