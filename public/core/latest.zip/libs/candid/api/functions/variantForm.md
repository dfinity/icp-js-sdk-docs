---
title: variantForm
editUrl: false
next: true
prev: true
---

> **variantForm**(`fields`, `config`): [`VariantForm`](../classes/VariantForm.md)

Defined in: [packages/core/src/candid/candid-ui.ts:21](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-ui.ts#L21)

## Parameters

### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VariantForm`](../classes/VariantForm.md)
