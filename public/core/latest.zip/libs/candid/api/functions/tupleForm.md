---
title: tupleForm
editUrl: false
next: true
prev: true
---

> **tupleForm**(`components`, `config`): [`TupleForm`](../classes/TupleForm.md)

Defined in: [packages/candid/src/candid-ui.ts:18](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-ui.ts#L18)


### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`TupleForm`](../classes/TupleForm.md)
