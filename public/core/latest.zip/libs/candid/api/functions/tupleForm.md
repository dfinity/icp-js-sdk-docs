---
title: tupleForm
editUrl: false
next: true
prev: true
---

> **tupleForm**(`components`, `config`): [`TupleForm`](../classes/TupleForm.md)

Defined in: [packages/candid/src/candid-ui.ts:18](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/candid-ui.ts#L18)


### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`TupleForm`](../classes/TupleForm.md)
