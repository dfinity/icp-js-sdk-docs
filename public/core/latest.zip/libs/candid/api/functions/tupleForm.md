---
title: tupleForm
editUrl: false
next: true
prev: true
---

> **tupleForm**(`components`, `config`): [`TupleForm`](../classes/TupleForm.md)

Defined in: [packages/candid/src/candid-ui.ts:18](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-ui.ts#L18)


### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`TupleForm`](../classes/TupleForm.md)
