---
title: tupleForm
editUrl: false
next: true
prev: true
---

> **tupleForm**(`components`, `config`): [`TupleForm`](../classes/TupleForm.md)

Defined in: [packages/candid/src/candid-ui.ts:18](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L18)


### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`TupleForm`](../classes/TupleForm.md)
