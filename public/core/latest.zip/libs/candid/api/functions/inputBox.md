---
title: inputBox
editUrl: false
next: true
prev: true
---

> **inputBox**(`t`, `config`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:12](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/candid-ui.ts#L12)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`UIConfig`](../interfaces/UIConfig.md)\>

## Returns

[`InputBox`](../classes/InputBox.md)
