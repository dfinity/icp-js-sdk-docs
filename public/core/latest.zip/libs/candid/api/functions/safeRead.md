---
title: safeRead
editUrl: false
next: true
prev: true
---

> **safeRead**(`pipe`, `num`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:21](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/leb128.ts#L21)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### num

`number`

number

## Returns

`Uint8Array`

Uint8Array
