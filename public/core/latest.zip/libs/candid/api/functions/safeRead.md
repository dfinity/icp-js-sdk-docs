---
title: safeRead
editUrl: false
next: true
prev: true
---

> **safeRead**(`pipe`, `num`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:21](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/utils/leb128.ts#L21)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### num

`number`

number

## Returns

`Uint8Array`

Uint8Array
