---
title: safeRead
editUrl: false
next: true
prev: true
---

> **safeRead**(`pipe`, `num`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:21](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/utils/leb128.ts#L21)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### num

`number`

number

## Returns

`Uint8Array`

Uint8Array
