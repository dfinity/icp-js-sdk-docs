---
title: safeRead
editUrl: false
next: true
prev: true
---

> **safeRead**(`pipe`, `num`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:21](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/utils/leb128.ts#L21)


### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### num

`number`

number

## Returns

`Uint8Array`

Uint8Array
