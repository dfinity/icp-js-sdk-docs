---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`u1`, `u2`): `boolean`

Defined in: [packages/core/src/candid/utils/buffer.ts:207](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/utils/buffer.ts#L207)

Checks two uint8Arrays for equality.

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`boolean`

boolean
