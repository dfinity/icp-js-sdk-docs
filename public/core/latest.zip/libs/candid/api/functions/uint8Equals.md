---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`u1`, `u2`): `boolean`

Defined in: [packages/candid/src/utils/buffer.ts:207](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/buffer.ts#L207)

Checks two uint8Arrays for equality.


### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`boolean`

boolean
