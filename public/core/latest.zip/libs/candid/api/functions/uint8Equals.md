---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`u1`, `u2`): `boolean`

Defined in: [packages/candid/src/utils/buffer.ts:207](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/utils/buffer.ts#L207)

Checks two uint8Arrays for equality.

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`boolean`

boolean
