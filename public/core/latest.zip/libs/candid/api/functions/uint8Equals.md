---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`u1`, `u2`): `boolean`

Defined in: [packages/core/src/candid/utils/buffer.ts:207](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L207)

Checks two uint8Arrays for equality.

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`boolean`

boolean
