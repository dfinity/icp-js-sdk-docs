---
title: readUIntLE
editUrl: false
next: true
prev: true
---

> **readUIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/candid/src/utils/leb128.ts:203](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/utils/leb128.ts#L203)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
