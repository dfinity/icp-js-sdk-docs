---
title: idlLabelToId
editUrl: false
next: true
prev: true
---

> **idlLabelToId**(`label`): `number`

Defined in: [packages/candid/src/utils/hash.ts:23](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/utils/hash.ts#L23)


### label

`string`

string

## Returns

`number`

number representing hashed label
