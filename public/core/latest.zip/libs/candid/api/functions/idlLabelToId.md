---
title: idlLabelToId
editUrl: false
next: true
prev: true
---

> **idlLabelToId**(`label`): `number`

Defined in: [packages/candid/src/utils/hash.ts:23](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/utils/hash.ts#L23)

## Parameters

### label

`string`

string

## Returns

`number`

number representing hashed label
