---
title: idlLabelToId
editUrl: false
next: true
prev: true
---

> **idlLabelToId**(`label`): `number`

Defined in: [packages/candid/src/utils/hash.ts:23](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/utils/hash.ts#L23)


### label

`string`

string

## Returns

`number`

number representing hashed label
