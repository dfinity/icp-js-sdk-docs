---
title: idlLabelToId
editUrl: false
next: true
prev: true
---

> **idlLabelToId**(`label`): `number`

Defined in: [packages/candid/src/utils/hash.ts:23](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/utils/hash.ts#L23)


### label

`string`

string

## Returns

`number`

number representing hashed label
