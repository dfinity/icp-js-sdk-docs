---
title: renderValue
editUrl: false
next: true
prev: true
---

> **renderValue**(`t`, `input`, `value`): `void`

Defined in: [packages/candid/src/candid-ui.ts:224](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L224)

## Parameters

### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL Type

### input

[`InputBox`](../classes/InputBox.md)

an InputBox

### value

`any`

any

## Returns

`void`

rendering that value to the provided input
