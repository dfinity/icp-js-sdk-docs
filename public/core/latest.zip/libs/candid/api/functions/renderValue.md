---
title: renderValue
editUrl: false
next: true
prev: true
---

> **renderValue**(`t`, `input`, `value`): `void`

Defined in: [packages/core/src/candid/candid-ui.ts:224](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/candid-ui.ts#L224)

## Parameters

### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL Type

### input

[`InputBox`](../classes/InputBox.md)

an InputBox

### value

`any`

any

## Returns

`void`

rendering that value to the provided input
