---
title: renderValue
editUrl: false
next: true
prev: true
---

> **renderValue**(`t`, `input`, `value`): `void`

Defined in: [packages/candid/src/candid-ui.ts:224](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/candid-ui.ts#L224)


### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL Type

### input

[`InputBox`](../classes/InputBox.md)

an InputBox

### value

`any`

any

## Returns

`void`

rendering that value to the provided input
