---
title: OptionForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:223](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L223)

## Extends

- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new OptionForm**(`ty`, `ui`): `OptionForm`

Defined in: [packages/core/src/candid/candid-core.ts:224](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L224)

#### Parameters

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`OptionForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L100)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ty

> **ty**: [`Type`](../namespaces/IDL/classes/Type.md)

Defined in: [packages/core/src/candid/candid-core.ts:225](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L225)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/core/src/candid/candid-core.ts:226](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L226)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:230](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L230)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**\<`T`\>(`config`): \[\] \| \[`T`\] \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:238](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L238)

#### Type Parameters

##### T

`T`

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

\[\] \| \[`T`\] \| `undefined`

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L113)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/candid-core.ts#L105)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
