---
title: VecForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:252](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L252)


- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new VecForm**(`ty`, `ui`): `VecForm`

Defined in: [packages/candid/src/candid-core.ts:253](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L253)

#### Parameters

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`VecForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/candid/src/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L101)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ty

> **ty**: [`Type`](../namespaces/IDL/classes/Type.md)

Defined in: [packages/candid/src/candid-core.ts:254](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L254)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/candid/src/candid-core.ts:255](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L255)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/candid/src/candid-core.ts:259](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L259)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**\<`T`\>(`config`): `undefined` \| `T`[]

Defined in: [packages/candid/src/candid-core.ts:267](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L267)

#### Type Parameters

##### T

`T`

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`undefined` \| `T`[]

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:114](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L114)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:106](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/candid-core.ts#L106)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
