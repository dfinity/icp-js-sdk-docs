---
title: RecordForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:140](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L140)

## Extends

- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new RecordForm**(`fields`, `ui`): `RecordForm`

Defined in: [packages/candid/src/candid-core.ts:141](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L141)

#### Parameters

##### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`RecordForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### fields

> **fields**: \[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

Defined in: [packages/candid/src/candid-core.ts:142](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L142)

***

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/candid/src/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L101)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/candid/src/candid-core.ts:143](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L143)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/candid/src/candid-core.ts:147](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L147)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**(`config`): `undefined` \| `Record`\<`string`, `any`\>

Defined in: [packages/candid/src/candid-core.ts:159](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L159)

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`undefined` \| `Record`\<`string`, `any`\>

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:114](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L114)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:106](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-core.ts#L106)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
