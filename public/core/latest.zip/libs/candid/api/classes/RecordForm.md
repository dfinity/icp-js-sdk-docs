---
title: RecordForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:139](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L139)

## Extends

- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new RecordForm**(`fields`, `ui`): `RecordForm`

Defined in: [packages/core/src/candid/candid-core.ts:140](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L140)

#### Parameters

##### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`RecordForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### fields

> **fields**: \[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

Defined in: [packages/core/src/candid/candid-core.ts:141](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L141)

***

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L100)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/core/src/candid/candid-core.ts:142](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L142)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:146](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L146)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**(`config`): `Record`\<`string`, `any`\> \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:158](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L158)

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`Record`\<`string`, `any`\> \| `undefined`

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L113)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/candid-core.ts#L105)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
