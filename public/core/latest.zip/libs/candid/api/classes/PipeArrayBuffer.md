---
title: PipeArrayBuffer
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/utils/buffer.ts:18](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L18)

A class that abstracts a pipe-like Uint8Array.

## Constructors

### Constructor

> **new PipeArrayBuffer**(`buffer?`, `length?`): `PipeArrayBuffer`

Defined in: [packages/core/src/candid/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L54)

Creates a new instance of a pipe

#### Parameters

##### buffer?

`Uint8Array`\<`ArrayBufferLike`\>

an optional buffer to start with

##### length?

`number` = `...`

an optional amount of bytes to use for the length.

#### Returns

`PipeArrayBuffer`

## Accessors

### buffer

#### Get Signature

> **get** **buffer**(): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:72](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L72)

##### Returns

`Uint8Array`

***

### byteLength

#### Get Signature

> **get** **byteLength**(): `number`

Defined in: [packages/core/src/candid/utils/buffer.ts:77](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L77)

##### Returns

`number`

***

### end

#### Get Signature

> **get** **end**(): `boolean`

Defined in: [packages/core/src/candid/utils/buffer.ts:127](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L127)

Whether or not there is more data to read from the buffer

##### Returns

`boolean`

## Methods

### alloc()

> **alloc**(`amount`): `void`

Defined in: [packages/core/src/candid/utils/buffer.ts:135](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L135)

Allocate a fixed amount of memory in the buffer. This does not affect the view.

#### Parameters

##### amount

`number`

A number of bytes to add to the buffer.

#### Returns

`void`

***

### read()

> **read**(`num`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:85](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L85)

Read `num` number of bytes from the front of the pipe.

#### Parameters

##### num

`number`

The number of bytes to read.

#### Returns

`Uint8Array`

***

### readUint8()

> **readUint8**(): `number` \| `undefined`

Defined in: [packages/core/src/candid/utils/buffer.ts:91](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L91)

#### Returns

`number` \| `undefined`

***

### restore()

> **restore**(`checkPoint`): `void`

Defined in: [packages/core/src/candid/utils/buffer.ts:36](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L36)

Restore a checkpoint of the reading view (for backtracking)

#### Parameters

##### checkPoint

`Uint8Array`

a previously saved checkpoint

#### Returns

`void`

***

### save()

> **save**(): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:28](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L28)

Save a checkpoint of the reading view (for backtracking)

#### Returns

`Uint8Array`

***

### write()

> **write**(`buf`): `void`

Defined in: [packages/core/src/candid/utils/buffer.ts:104](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/utils/buffer.ts#L104)

Write a buffer to the end of the pipe.

#### Parameters

##### buf

`Uint8Array`

The bytes to write.

#### Returns

`void`
