---
title: InputBox
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-core.ts:24](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L24)

## Constructors

### Constructor

> **new InputBox**(`idl`, `ui`): `InputBox`

Defined in: [packages/candid/src/candid-core.ts:29](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L29)

#### Parameters

##### idl

[`Type`](../namespaces/IDL/classes/Type.md)

##### ui

[`UIConfig`](../interfaces/UIConfig.md)

#### Returns

`InputBox`

## Properties

### idl

> **idl**: [`Type`](../namespaces/IDL/classes/Type.md)

Defined in: [packages/candid/src/candid-core.ts:30](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L30)

***

### label

> **label**: `null` \| `string` = `null`

Defined in: [packages/candid/src/candid-core.ts:26](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L26)

***

### status

> **status**: `HTMLElement`

Defined in: [packages/candid/src/candid-core.ts:25](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L25)

***

### ui

> **ui**: [`UIConfig`](../interfaces/UIConfig.md)

Defined in: [packages/candid/src/candid-core.ts:31](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L31)

***

### value

> **value**: `any` = `undefined`

Defined in: [packages/candid/src/candid-core.ts:27](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L27)

## Methods

### isRejected()

> **isRejected**(): `boolean`

Defined in: [packages/candid/src/candid-core.ts:50](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L50)

#### Returns

`boolean`

***

### parse()

> **parse**(`config`): `any`

Defined in: [packages/candid/src/candid-core.ts:54](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L54)

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md) = `{}`

#### Returns

`any`

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/candid/src/candid-core.ts:81](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-core.ts#L81)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`
