---
title: Render
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-ui.ts:31](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L31)

## Extends

- [`Visitor`](../namespaces/IDL/classes/Visitor.md)\<`null`, `InputBox`\>

## Constructors

### Constructor

> **new Render**(): `Render`

#### Returns

`Render`

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`constructor`](../namespaces/IDL/classes/Visitor.md#constructor)

## Methods

### visitBool()

> **visitBool**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:140](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L140)

#### Parameters

##### t

[`BoolClass`](../namespaces/IDL/classes/BoolClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitBool`](../namespaces/IDL/classes/Visitor.md#visitbool)

***

### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:174](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L174)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`ConstructType`](../namespaces/IDL/classes/ConstructType.md)\<`T`\>

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitConstruct`](../namespaces/IDL/classes/Visitor.md#visitconstruct)

***

### visitEmpty()

> **visitEmpty**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:137](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L137)

#### Parameters

##### t

[`EmptyClass`](../namespaces/IDL/classes/EmptyClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitEmpty`](../namespaces/IDL/classes/Visitor.md#visitempty)

***

### visitFixedInt()

> **visitFixedInt**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:164](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L164)

#### Parameters

##### t

[`FixedIntClass`](../namespaces/IDL/classes/FixedIntClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFixedInt`](../namespaces/IDL/classes/Visitor.md#visitfixedint)

***

### visitFixedNat()

> **visitFixedNat**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:167](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L167)

#### Parameters

##### t

[`FixedNatClass`](../namespaces/IDL/classes/FixedNatClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFixedNat`](../namespaces/IDL/classes/Visitor.md#visitfixednat)

***

### visitFloat()

> **visitFloat**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:161](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L161)

#### Parameters

##### t

[`FloatClass`](../namespaces/IDL/classes/FloatClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFloat`](../namespaces/IDL/classes/Visitor.md#visitfloat)

***

### visitFunc()

> **visitFunc**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:196](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L196)

#### Parameters

##### t

[`FuncClass`](../namespaces/IDL/classes/FuncClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFunc`](../namespaces/IDL/classes/Visitor.md#visitfunc)

***

### visitInt()

> **visitInt**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:155](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L155)

#### Parameters

##### t

[`IntClass`](../namespaces/IDL/classes/IntClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitInt`](../namespaces/IDL/classes/Visitor.md#visitint)

***

### visitNat()

> **visitNat**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:158](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L158)

#### Parameters

##### t

[`NatClass`](../namespaces/IDL/classes/NatClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitNat`](../namespaces/IDL/classes/Visitor.md#visitnat)

***

### visitNull()

> **visitNull**(`t`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:38](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L38)

#### Parameters

##### t

[`NullClass`](../namespaces/IDL/classes/NullClass.md)

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitNull`](../namespaces/IDL/classes/Visitor.md#visitnull)

***

### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:152](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L152)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](../namespaces/IDL/classes/PrimitiveType.md)\<`T`\>

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitNumber`](../namespaces/IDL/classes/Visitor.md#visitnumber)

***

### visitOpt()

> **visitOpt**\<`T`\>(`t`, `ty`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:77](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L77)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`OptClass`](../namespaces/IDL/classes/OptClass.md)\<`T`\>

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitOpt`](../namespaces/IDL/classes/Visitor.md#visitopt)

***

### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:134](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L134)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](../namespaces/IDL/classes/PrimitiveType.md)\<`T`\>

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitPrimitive`](../namespaces/IDL/classes/Visitor.md#visitprimitive)

***

### visitPrincipal()

> **visitPrincipal**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:170](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L170)

#### Parameters

##### t

[`PrincipalClass`](../namespaces/IDL/classes/PrincipalClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitPrincipal`](../namespaces/IDL/classes/Visitor.md#visitprincipal)

***

### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:97](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L97)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`RecClass`](../namespaces/IDL/classes/RecClass.md)\<`T`\>

##### ty

[`ConstructType`](../namespaces/IDL/classes/ConstructType.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitRec`](../namespaces/IDL/classes/Visitor.md#visitrec)

***

### visitRecord()

> **visitRecord**(`t`, `fields`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:41](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L41)

#### Parameters

##### t

[`RecordClass`](../namespaces/IDL/classes/RecordClass.md)

##### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitRecord`](../namespaces/IDL/classes/Visitor.md#visitrecord)

***

### visitReserved()

> **visitReserved**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:146](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L146)

#### Parameters

##### t

[`ReservedClass`](../namespaces/IDL/classes/ReservedClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitReserved`](../namespaces/IDL/classes/Visitor.md#visitreserved)

***

### visitService()

> **visitService**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:199](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L199)

#### Parameters

##### t

[`ServiceClass`](../namespaces/IDL/classes/ServiceClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitService`](../namespaces/IDL/classes/Visitor.md#visitservice)

***

### visitText()

> **visitText**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:149](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L149)

#### Parameters

##### t

[`TextClass`](../namespaces/IDL/classes/TextClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitText`](../namespaces/IDL/classes/Visitor.md#visittext)

***

### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:51](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L51)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### t

[`TupleClass`](../namespaces/IDL/classes/TupleClass.md)\<`T`\>

##### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitTuple`](../namespaces/IDL/classes/Visitor.md#visittuple)

***

### visitType()

> **visitType**\<`T`\>(`t`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:32](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L32)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitType`](../namespaces/IDL/classes/Visitor.md#visittype)

***

### visitVariant()

> **visitVariant**(`t`, `fields`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:65](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L65)

#### Parameters

##### t

[`VariantClass`](../namespaces/IDL/classes/VariantClass.md)

##### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitVariant`](../namespaces/IDL/classes/Visitor.md#visitvariant)

***

### visitVec()

> **visitVec**\<`T`\>(`t`, `ty`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:84](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L84)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`VecClass`](../namespaces/IDL/classes/VecClass.md)\<`T`\>

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitVec`](../namespaces/IDL/classes/Visitor.md#visitvec)
