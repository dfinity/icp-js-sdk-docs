---
title: Render
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/candid-ui.ts:31](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L31)


- [`Visitor`](../namespaces/IDL/classes/Visitor.md)\<`null`, `InputBox`\>

## Constructors

### Constructor

> **new Render**(): `Render`

#### Returns

`Render`

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`constructor`](../namespaces/IDL/classes/Visitor.md#constructor)

## Methods

### visitBool()

> **visitBool**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:132](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L132)

#### Parameters

##### t

[`BoolClass`](../namespaces/IDL/classes/BoolClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitBool`](../namespaces/IDL/classes/Visitor.md#visitbool)

***

### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:166](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L166)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`ConstructType`](../namespaces/IDL/classes/ConstructType.md)\<`T`\>

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitConstruct`](../namespaces/IDL/classes/Visitor.md#visitconstruct)

***

### visitEmpty()

> **visitEmpty**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:129](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L129)

#### Parameters

##### t

[`EmptyClass`](../namespaces/IDL/classes/EmptyClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitEmpty`](../namespaces/IDL/classes/Visitor.md#visitempty)

***

### visitFixedInt()

> **visitFixedInt**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:156](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L156)

#### Parameters

##### t

[`FixedIntClass`](../namespaces/IDL/classes/FixedIntClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFixedInt`](../namespaces/IDL/classes/Visitor.md#visitfixedint)

***

### visitFixedNat()

> **visitFixedNat**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:159](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L159)

#### Parameters

##### t

[`FixedNatClass`](../namespaces/IDL/classes/FixedNatClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFixedNat`](../namespaces/IDL/classes/Visitor.md#visitfixednat)

***

### visitFloat()

> **visitFloat**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:153](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L153)

#### Parameters

##### t

[`FloatClass`](../namespaces/IDL/classes/FloatClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFloat`](../namespaces/IDL/classes/Visitor.md#visitfloat)

***

### visitFunc()

> **visitFunc**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:188](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L188)

#### Parameters

##### t

[`FuncClass`](../namespaces/IDL/classes/FuncClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitFunc`](../namespaces/IDL/classes/Visitor.md#visitfunc)

***

### visitInt()

> **visitInt**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:147](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L147)

#### Parameters

##### t

[`IntClass`](../namespaces/IDL/classes/IntClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitInt`](../namespaces/IDL/classes/Visitor.md#visitint)

***

### visitNat()

> **visitNat**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:150](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L150)

#### Parameters

##### t

[`NatClass`](../namespaces/IDL/classes/NatClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitNat`](../namespaces/IDL/classes/Visitor.md#visitnat)

***

### visitNull()

> **visitNull**(`t`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:38](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L38)

#### Parameters

##### t

[`NullClass`](../namespaces/IDL/classes/NullClass.md)

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitNull`](../namespaces/IDL/classes/Visitor.md#visitnull)

***

### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:144](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L144)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](../namespaces/IDL/classes/PrimitiveType.md)\<`T`\>

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitNumber`](../namespaces/IDL/classes/Visitor.md#visitnumber)

***

### visitOpt()

> **visitOpt**\<`T`\>(`t`, `ty`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:77](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L77)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`OptClass`](../namespaces/IDL/classes/OptClass.md)\<`T`\>

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitOpt`](../namespaces/IDL/classes/Visitor.md#visitopt)

***

### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:126](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L126)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](../namespaces/IDL/classes/PrimitiveType.md)\<`T`\>

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitPrimitive`](../namespaces/IDL/classes/Visitor.md#visitprimitive)

***

### visitPrincipal()

> **visitPrincipal**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:162](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L162)

#### Parameters

##### t

[`PrincipalClass`](../namespaces/IDL/classes/PrincipalClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitPrincipal`](../namespaces/IDL/classes/Visitor.md#visitprincipal)

***

### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:97](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L97)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`RecClass`](../namespaces/IDL/classes/RecClass.md)\<`T`\>

##### ty

[`ConstructType`](../namespaces/IDL/classes/ConstructType.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitRec`](../namespaces/IDL/classes/Visitor.md#visitrec)

***

### visitRecord()

> **visitRecord**(`t`, `fields`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:41](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L41)

#### Parameters

##### t

[`RecordClass`](../namespaces/IDL/classes/RecordClass.md)

##### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitRecord`](../namespaces/IDL/classes/Visitor.md#visitrecord)

***

### visitReserved()

> **visitReserved**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:138](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L138)

#### Parameters

##### t

[`ReservedClass`](../namespaces/IDL/classes/ReservedClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitReserved`](../namespaces/IDL/classes/Visitor.md#visitreserved)

***

### visitService()

> **visitService**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:191](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L191)

#### Parameters

##### t

[`ServiceClass`](../namespaces/IDL/classes/ServiceClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitService`](../namespaces/IDL/classes/Visitor.md#visitservice)

***

### visitText()

> **visitText**(`t`, `data`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/idl.ts:141](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L141)

#### Parameters

##### t

[`TextClass`](../namespaces/IDL/classes/TextClass.md)

##### data

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Inherited from

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitText`](../namespaces/IDL/classes/Visitor.md#visittext)

***

### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:51](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L51)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### t

[`TupleClass`](../namespaces/IDL/classes/TupleClass.md)\<`T`\>

##### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitTuple`](../namespaces/IDL/classes/Visitor.md#visittuple)

***

### visitType()

> **visitType**\<`T`\>(`t`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:32](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L32)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitType`](../namespaces/IDL/classes/Visitor.md#visittype)

***

### visitVariant()

> **visitVariant**(`t`, `fields`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:65](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L65)

#### Parameters

##### t

[`VariantClass`](../namespaces/IDL/classes/VariantClass.md)

##### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitVariant`](../namespaces/IDL/classes/Visitor.md#visitvariant)

***

### visitVec()

> **visitVec**\<`T`\>(`t`, `ty`, `_d`): [`InputBox`](InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:84](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/candid-ui.ts#L84)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`VecClass`](../namespaces/IDL/classes/VecClass.md)\<`T`\>

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)\<`T`\>

##### \_d

`null`

#### Returns

[`InputBox`](InputBox.md)

#### Overrides

[`Visitor`](../namespaces/IDL/classes/Visitor.md).[`visitVec`](../namespaces/IDL/classes/Visitor.md#visitvec)
