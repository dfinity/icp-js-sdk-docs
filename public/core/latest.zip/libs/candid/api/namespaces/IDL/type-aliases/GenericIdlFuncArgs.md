---
title: GenericIdlFuncArgs
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncArgs** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1772](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/idl.ts#L1772)

The generic type of the arguments of an [IDL Function](../functions/Func.md).
