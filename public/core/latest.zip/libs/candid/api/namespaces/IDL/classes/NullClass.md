---
title: NullClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:478](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L478)

Represents an IDL Null

## Extends

- [`PrimitiveType`](PrimitiveType.md)\<`null`\>

## Constructors

### Constructor

> **new NullClass**(): `NullClass`

#### Returns

`NullClass`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`constructor`](PrimitiveType.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:509](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L509)

##### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`name`](PrimitiveType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:479](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L479)

##### Returns

`IdlTypeName`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`typeName`](PrimitiveType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:286](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L286)

#### Parameters

##### \_typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`_buildTypeTableImpl`](PrimitiveType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:487](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L487)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`accept`](PrimitiveType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`buildTypeTable`](PrimitiveType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`Type`](Type.md)

Defined in: [packages/candid/src/idl.ts:279](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L279)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`checkType`](PrimitiveType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is null`

Defined in: [packages/candid/src/idl.ts:491](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L491)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is null`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`covariant`](PrimitiveType.md#covariant)

***

### decodeValue()

> **decodeValue**(`_b`, `t`): `null`

Defined in: [packages/candid/src/idl.ts:504](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L504)

#### Parameters

##### \_b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`null`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`decodeValue`](PrimitiveType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:237](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L237)

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`display`](PrimitiveType.md#display)

***

### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:500](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L500)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeType`](PrimitiveType.md#encodetype)

***

### encodeValue()

> **encodeValue**(): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:496](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L496)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeValue`](PrimitiveType.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:241](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L241)

#### Parameters

##### x

`null`

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`valueToString`](PrimitiveType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is NullClass`

Defined in: [packages/candid/src/idl.ts:483](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L483)

#### Parameters

##### instance

`any`

#### Returns

`instance is NullClass`
