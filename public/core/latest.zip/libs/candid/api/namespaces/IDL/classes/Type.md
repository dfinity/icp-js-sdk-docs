---
title: Type
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:231](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L231)

Represents an IDL type.


- [`PrimitiveType`](PrimitiveType.md)
- [`ConstructType`](ConstructType.md)
- [`UnknownClass`](UnknownClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new Type**\<`T`\>(): `Type`\<`T`\>

#### Returns

`Type`\<`T`\>

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/candid/src/idl.ts:233](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L233)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:232](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L232)

## Methods

### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:275](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L275)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:234](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L234)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### checkType()

> `abstract` **checkType**(`t`): `Type`

Defined in: [packages/candid/src/idl.ts:271](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L271)

#### Parameters

##### t

`Type`

#### Returns

`Type`

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:256](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L256)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:273](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L273)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

`Type`

#### Returns

`T`

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:237](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L237)

#### Returns

`string`

***

### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:269](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L269)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:263](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L263)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:241](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L241)

#### Parameters

##### x

`T`

#### Returns

`string`
