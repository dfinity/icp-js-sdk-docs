---
title: "Null"
editUrl: false
next: true
prev: true
---

> `const` **Null**: [`NullClass`](../classes/NullClass.md)

Defined in: [packages/candid/src/idl.ts:2284](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2284)
