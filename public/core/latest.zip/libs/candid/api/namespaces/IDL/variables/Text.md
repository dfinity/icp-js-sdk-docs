---
title: Text
editUrl: false
next: true
prev: true
---

> `const` **Text**: [`TextClass`](../classes/TextClass.md)

Defined in: [packages/candid/src/idl.ts:2293](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L2293)
