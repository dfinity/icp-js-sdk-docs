---
title: Unknown
editUrl: false
next: true
prev: true
---

> `const` **Unknown**: [`UnknownClass`](../classes/UnknownClass.md)

Defined in: [packages/candid/src/idl.ts:2290](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L2290)

Client-only type for deserializing unknown data. Not supported by Candid, and its use is discouraged.
