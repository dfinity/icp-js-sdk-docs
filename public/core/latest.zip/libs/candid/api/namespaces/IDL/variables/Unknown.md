---
title: Unknown
editUrl: false
next: true
prev: true
---

> `const` **Unknown**: [`UnknownClass`](../classes/UnknownClass.md)

Defined in: [packages/candid/src/idl.ts:2290](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/idl.ts#L2290)

Client-only type for deserializing unknown data. Not supported by Candid, and its use is discouraged.
