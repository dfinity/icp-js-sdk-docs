---
title: Nat64
editUrl: false
next: true
prev: true
---

> `const` **Nat64**: [`FixedNatClass`](../classes/FixedNatClass.md)

Defined in: [packages/candid/src/idl.ts:2300](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2300)
