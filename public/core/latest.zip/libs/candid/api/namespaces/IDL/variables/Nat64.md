---
title: Nat64
editUrl: false
next: true
prev: true
---

> `const` **Nat64**: [`FixedNatClass`](../classes/FixedNatClass.md)

Defined in: [packages/core/src/candid/idl.ts:2308](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L2308)
