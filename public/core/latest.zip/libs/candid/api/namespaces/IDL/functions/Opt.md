---
title: Opt
editUrl: false
next: true
prev: true
---

> **Opt**\<`T`\>(`t`): [`OptClass`](../classes/OptClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2333](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2333)

## Type Parameters

### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`OptClass`](../classes/OptClass.md)\<`T`\>

OptClass of Type
