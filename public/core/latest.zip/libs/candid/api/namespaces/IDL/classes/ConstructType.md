---
title: ConstructType
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:292](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L292)

Represents an IDL type.

## Extends

- [`Type`](Type.md)\<`T`\>

## Extended by

- [`VecClass`](VecClass.md)
- [`OptClass`](OptClass.md)
- [`RecordClass`](RecordClass.md)
- [`VariantClass`](VariantClass.md)
- [`RecClass`](RecClass.md)
- [`FuncClass`](FuncClass.md)
- [`ServiceClass`](ServiceClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new ConstructType**\<`T`\>(): `ConstructType`\<`T`\>

#### Returns

`ConstructType`\<`T`\>

#### Inherited from

[`Type`](Type.md).[`constructor`](Type.md#constructor)

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/candid/src/idl.ts:233](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L233)

#### Inherited from

[`Type`](Type.md).[`name`](Type.md#name)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:232](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L232)

#### Inherited from

[`Type`](Type.md).[`typeName`](Type.md#typename)

## Methods

### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:275](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L275)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`_buildTypeTableImpl`](Type.md#_buildtypetableimpl)

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:234](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L234)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Inherited from

[`Type`](Type.md).[`accept`](Type.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`buildTypeTable`](Type.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): `ConstructType`\<`T`\>

Defined in: [packages/candid/src/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L293)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

`ConstructType`\<`T`\>

#### Overrides

[`Type`](Type.md).[`checkType`](Type.md#checktype)

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:256](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L256)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Inherited from

[`Type`](Type.md).[`covariant`](Type.md#covariant)

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:273](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L273)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Inherited from

[`Type`](Type.md).[`decodeValue`](Type.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:237](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L237)

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`display`](Type.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/candid/src/idl.ts:303](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L303)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`Type`](Type.md).[`encodeType`](Type.md#encodetype)

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:263](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L263)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

#### Inherited from

[`Type`](Type.md).[`encodeValue`](Type.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:241](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L241)

#### Parameters

##### x

`T`

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`valueToString`](Type.md#valuetostring)
