---
title: Int
editUrl: false
next: true
prev: true
---

> `const` **Int**: [`IntClass`](../classes/IntClass.md)

Defined in: [packages/candid/src/idl.ts:2294](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L2294)
