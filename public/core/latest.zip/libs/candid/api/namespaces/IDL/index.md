---
title: IDL
editUrl: false
next: true
prev: true
---


- [BoolClass](classes/BoolClass.md)
- [ConstructType](classes/ConstructType.md)
- [EmptyClass](classes/EmptyClass.md)
- [FixedIntClass](classes/FixedIntClass.md)
- [FixedNatClass](classes/FixedNatClass.md)
- [FloatClass](classes/FloatClass.md)
- [FuncClass](classes/FuncClass.md)
- [IntClass](classes/IntClass.md)
- [NatClass](classes/NatClass.md)
- [NullClass](classes/NullClass.md)
- [OptClass](classes/OptClass.md)
- [PrimitiveType](classes/PrimitiveType.md)
- [PrincipalClass](classes/PrincipalClass.md)
- [RecClass](classes/RecClass.md)
- [RecordClass](classes/RecordClass.md)
- [ReservedClass](classes/ReservedClass.md)
- [ServiceClass](classes/ServiceClass.md)
- [TextClass](classes/TextClass.md)
- [TupleClass](classes/TupleClass.md)
- [Type](classes/Type.md)
- [UnknownClass](classes/UnknownClass.md)
- [VariantClass](classes/VariantClass.md)
- [VecClass](classes/VecClass.md)
- [Visitor](classes/Visitor.md)

## Type Aliases

- [GenericIdlFuncArgs](type-aliases/GenericIdlFuncArgs.md)
- [GenericIdlFuncRets](type-aliases/GenericIdlFuncRets.md)
- [GenericIdlServiceFields](type-aliases/GenericIdlServiceFields.md)
- [InterfaceFactory](type-aliases/InterfaceFactory.md)

## Variables

- [Bool](variables/Bool.md)
- [Empty](variables/Empty.md)
- [Float32](variables/Float32.md)
- [Float64](variables/Float64.md)
- [Int](variables/Int.md)
- [Int16](variables/Int16.md)
- [Int32](variables/Int32.md)
- [Int64](variables/Int64.md)
- [Int8](variables/Int8.md)
- [Nat](variables/Nat.md)
- [Nat16](variables/Nat16.md)
- [Nat32](variables/Nat32.md)
- [Nat64](variables/Nat64.md)
- [Nat8](variables/Nat8.md)
- [Null](variables/Null.md)
- [Principal](variables/Principal.md)
- [Reserved](variables/Reserved.md)
- [Text](variables/Text.md)
- [Unknown](variables/Unknown.md)

## Functions

- [decode](functions/decode.md)
- [encode](functions/encode.md)
- [Func](functions/Func.md)
- [Opt](functions/Opt.md)
- [Rec](functions/Rec.md)
- [Record](functions/Record.md)
- [resetSubtypeCache](functions/resetSubtypeCache.md)
- [Service](functions/Service.md)
- [subtype](functions/subtype.md)
- [Tuple](functions/Tuple.md)
- [Variant](functions/Variant.md)
- [Vec](functions/Vec.md)
