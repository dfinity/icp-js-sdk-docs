---
title: Empty
editUrl: false
next: true
prev: true
---

> `const` **Empty**: [`EmptyClass`](../classes/EmptyClass.md)

Defined in: [packages/candid/src/idl.ts:2285](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L2285)
