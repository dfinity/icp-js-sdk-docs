---
title: Int32
editUrl: false
next: true
prev: true
---

> `const` **Int32**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/candid/src/idl.ts:2294](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/candid/src/idl.ts#L2294)
