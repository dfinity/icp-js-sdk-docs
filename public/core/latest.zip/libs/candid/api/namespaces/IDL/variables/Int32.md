---
title: Int32
editUrl: false
next: true
prev: true
---

> `const` **Int32**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/candid/src/idl.ts:2294](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2294)
