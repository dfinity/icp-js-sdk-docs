---
title: Record
editUrl: false
next: true
prev: true
---

> **Record**(`t`): [`RecordClass`](../classes/RecordClass.md)

Defined in: [packages/candid/src/idl.ts:2341](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L2341)

## Parameters

### t

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`RecordClass`](../classes/RecordClass.md)

RecordClass of string and Type
