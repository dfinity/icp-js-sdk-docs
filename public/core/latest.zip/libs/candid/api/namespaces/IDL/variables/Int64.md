---
title: Int64
editUrl: false
next: true
prev: true
---

> `const` **Int64**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/candid/src/idl.ts:2295](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L2295)
