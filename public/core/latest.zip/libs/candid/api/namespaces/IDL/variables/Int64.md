---
title: Int64
editUrl: false
next: true
prev: true
---

> `const` **Int64**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/core/src/candid/idl.ts:2364](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/idl.ts#L2364)
