---
title: decode
editUrl: false
next: true
prev: true
---

> **decode**(`retTypes`, `bytes`): [`JsonValue`](../../../type-aliases/JsonValue.md)[]

Defined in: [packages/core/src/candid/idl.ts:2046](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/idl.ts#L2046)

Decode a binary value

## Parameters

### retTypes

[`Type`](../classes/Type.md)\<`any`\>[]

Types expected in the buffer.

### bytes

`Uint8Array`

hex-encoded string, or buffer.

## Returns

[`JsonValue`](../../../type-aliases/JsonValue.md)[]

Value deserialised to JS type
