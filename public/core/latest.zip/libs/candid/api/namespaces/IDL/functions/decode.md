---
title: decode
editUrl: false
next: true
prev: true
---

> **decode**(`retTypes`, `bytes`): [`JsonValue`](../../../type-aliases/JsonValue.md)[]

Defined in: [packages/core/src/candid/idl.ts:2046](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/idl.ts#L2046)

Decode a binary value

## Parameters

### retTypes

[`Type`](../classes/Type.md)\<`any`\>[]

Types expected in the buffer.

### bytes

`Uint8Array`

hex-encoded string, or buffer.

## Returns

[`JsonValue`](../../../type-aliases/JsonValue.md)[]

Value deserialised to JS type
