---
title: decode
editUrl: false
next: true
prev: true
---

> **decode**(`retTypes`, `bytes`): [`JsonValue`](../../../type-aliases/JsonValue.md)[]

Defined in: [packages/candid/src/idl.ts:1976](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L1976)

Decode a binary value


### retTypes

[`Type`](../classes/Type.md)\<`any`\>[]

Types expected in the buffer.

### bytes

`Uint8Array`

hex-encoded string, or buffer.

## Returns

[`JsonValue`](../../../type-aliases/JsonValue.md)[]

Value deserialised to JS type
