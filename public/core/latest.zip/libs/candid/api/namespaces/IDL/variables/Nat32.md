---
title: Nat32
editUrl: false
next: true
prev: true
---

> `const` **Nat32**: [`FixedNatClass`](../classes/FixedNatClass.md)

Defined in: [packages/candid/src/idl.ts:2307](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/idl.ts#L2307)
