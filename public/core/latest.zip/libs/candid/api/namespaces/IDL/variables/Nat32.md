---
title: Nat32
editUrl: false
next: true
prev: true
---

> `const` **Nat32**: [`FixedNatClass`](../classes/FixedNatClass.md)

Defined in: [packages/candid/src/idl.ts:2299](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2299)
