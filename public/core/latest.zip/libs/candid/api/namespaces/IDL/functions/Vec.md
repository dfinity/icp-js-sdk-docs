---
title: Vec
editUrl: false
next: true
prev: true
---

> **Vec**\<`T`\>(`t`): [`VecClass`](../classes/VecClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2317](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L2317)


### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`VecClass`](../classes/VecClass.md)\<`T`\>

VecClass from that type
