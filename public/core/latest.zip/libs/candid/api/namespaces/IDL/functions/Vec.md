---
title: Vec
editUrl: false
next: true
prev: true
---

> **Vec**\<`T`\>(`t`): [`VecClass`](../classes/VecClass.md)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2325](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L2325)

## Type Parameters

### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`VecClass`](../classes/VecClass.md)\<`T`\>

VecClass from that type
