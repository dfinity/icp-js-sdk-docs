---
title: GenericIdlFuncRets
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncRets** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/candid/src/idl.ts:1724](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L1724)

The generic type of the return values of an [IDL Function](../functions/Func.md).
