---
title: GenericIdlFuncRets
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncRets** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/candid/src/idl.ts:1716](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L1716)

The generic type of the return values of an [IDL Function](../functions/Func.md).
