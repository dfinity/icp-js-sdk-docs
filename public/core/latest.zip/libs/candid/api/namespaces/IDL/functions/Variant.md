---
title: Variant
editUrl: false
next: true
prev: true
---

> **Variant**(`fields`): [`VariantClass`](../classes/VariantClass.md)

Defined in: [packages/candid/src/idl.ts:2342](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L2342)


### fields

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`VariantClass`](../classes/VariantClass.md)

VariantClass
