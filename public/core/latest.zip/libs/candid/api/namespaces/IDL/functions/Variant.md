---
title: Variant
editUrl: false
next: true
prev: true
---

> **Variant**(`fields`): [`VariantClass`](../classes/VariantClass.md)

Defined in: [packages/candid/src/idl.ts:2350](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L2350)

## Parameters

### fields

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`VariantClass`](../classes/VariantClass.md)

VariantClass
