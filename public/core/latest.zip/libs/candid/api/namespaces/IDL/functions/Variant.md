---
title: Variant
editUrl: false
next: true
prev: true
---

> **Variant**(`fields`): [`VariantClass`](../classes/VariantClass.md)

Defined in: [packages/candid/src/idl.ts:2350](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/candid/src/idl.ts#L2350)


### fields

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`VariantClass`](../classes/VariantClass.md)

VariantClass
