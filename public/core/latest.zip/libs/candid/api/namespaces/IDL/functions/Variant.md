---
title: Variant
editUrl: false
next: true
prev: true
---

> **Variant**(`fields`): [`VariantClass`](../classes/VariantClass.md)

Defined in: [packages/candid/src/idl.ts:2350](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2350)

## Parameters

### fields

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`VariantClass`](../classes/VariantClass.md)

VariantClass
