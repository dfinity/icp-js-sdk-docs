---
title: subtype
editUrl: false
next: true
prev: true
---

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/candid/src/idl.ts:2464](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L2464)

Subtyping on Candid types t1 <: t2 (Exported for testing)


### t1

[`Type`](../classes/Type.md)

The potential subtype

### t2

[`Type`](../classes/Type.md)

The potential supertype

## Returns

`boolean`
