---
title: subtype
editUrl: false
next: true
prev: true
---

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/core/src/candid/idl.ts:2472](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L2472)

Subtyping on Candid types t1 <: t2 (Exported for testing)

## Parameters

### t1

[`Type`](../classes/Type.md)

The potential subtype

### t2

[`Type`](../classes/Type.md)

The potential supertype

## Returns

`boolean`
