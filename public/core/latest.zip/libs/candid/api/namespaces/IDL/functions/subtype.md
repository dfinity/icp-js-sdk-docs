---
title: subtype
editUrl: false
next: true
prev: true
---

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/candid/src/idl.ts:2472](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L2472)

Subtyping on Candid types t1 <: t2 (Exported for testing)


### t1

[`Type`](../classes/Type.md)

The potential subtype

### t2

[`Type`](../classes/Type.md)

The potential supertype

## Returns

`boolean`
