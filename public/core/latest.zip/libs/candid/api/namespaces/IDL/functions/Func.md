---
title: Func
editUrl: false
next: true
prev: true
---

> **Func**\<`Args`, `Ret`\>(`args`, `ret`, `annotations`): [`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

Defined in: [packages/candid/src/idl.ts:2368](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L2368)


### Args

`Args` *extends* [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md) = [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md)

### Ret

`Ret` *extends* [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md) = [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md)

## Parameters

### args

`Args`

array of IDL Types

### ret

`Ret`

array of IDL Types

### annotations

`string`[] = `[]`

array of strings, [] by default

## Returns

[`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

new FuncClass
