---
title: Func
editUrl: false
next: true
prev: true
---

> **Func**\<`Args`, `Ret`\>(`args`, `ret`, `annotations`): [`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

Defined in: [packages/candid/src/idl.ts:2360](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L2360)


### Args

`Args` *extends* [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md) = [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md)

### Ret

`Ret` *extends* [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md) = [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md)

## Parameters

### args

`Args`

array of IDL Types

### ret

`Ret`

array of IDL Types

### annotations

`string`[] = `[]`

array of strings, [] by default

## Returns

[`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

new FuncClass
