---
title: Func
editUrl: false
next: true
prev: true
---

> **Func**\<`Args`, `Ret`\>(`args`, `ret`, `annotations`): [`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

Defined in: [packages/candid/src/idl.ts:2360](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L2360)


### Args

`Args` *extends* [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md) = [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md)

### Ret

`Ret` *extends* [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md) = [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md)

## Parameters

### args

`Args`

array of IDL Types

### ret

`Ret`

array of IDL Types

### annotations

`string`[] = `[]`

array of strings, [] by default

## Returns

[`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

new FuncClass
