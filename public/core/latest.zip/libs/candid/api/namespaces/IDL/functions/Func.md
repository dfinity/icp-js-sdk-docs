---
title: Func
editUrl: false
next: true
prev: true
---

> **Func**\<`Args`, `Ret`\>(`args`, `ret`, `annotations?`): [`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

Defined in: [packages/core/src/candid/idl.ts:2429](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/idl.ts#L2429)

## Type Parameters

### Args

`Args` *extends* [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md) = [`GenericIdlFuncArgs`](../type-aliases/GenericIdlFuncArgs.md)

### Ret

`Ret` *extends* [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md) = [`GenericIdlFuncRets`](../type-aliases/GenericIdlFuncRets.md)

## Parameters

### args

`Args`

array of IDL Types

### ret

`Ret`

array of IDL Types

### annotations?

`string`[] = `[]`

array of strings, [] by default

## Returns

[`FuncClass`](../classes/FuncClass.md)\<`Args`, `Ret`\>

new FuncClass
