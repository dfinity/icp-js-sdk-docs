---
title: Service
editUrl: false
next: true
prev: true
---

> **Service**\<`K`, `Fields`\>(`t`): [`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

Defined in: [packages/candid/src/idl.ts:2380](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L2380)

## Type Parameters

### K

`K` *extends* `string` = `string`

### Fields

`Fields` *extends* [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md) = [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md)

## Parameters

### t

`Fields`

Record of string and FuncClass

## Returns

[`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

ServiceClass
