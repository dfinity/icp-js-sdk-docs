---
title: Service
editUrl: false
next: true
prev: true
---

> **Service**\<`K`, `Fields`\>(`t`): [`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

Defined in: [packages/candid/src/idl.ts:2372](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L2372)


### K

`K` *extends* `string` = `string`

### Fields

`Fields` *extends* [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md) = [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md)

## Parameters

### t

`Fields`

Record of string and FuncClass

## Returns

[`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

ServiceClass
