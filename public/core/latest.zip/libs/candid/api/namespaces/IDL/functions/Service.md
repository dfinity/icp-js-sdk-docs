---
title: Service
editUrl: false
next: true
prev: true
---

> **Service**\<`K`, `Fields`\>(`t`): [`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

Defined in: [packages/candid/src/idl.ts:2372](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L2372)


### K

`K` *extends* `string` = `string`

### Fields

`Fields` *extends* [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md) = [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md)

## Parameters

### t

`Fields`

Record of string and FuncClass

## Returns

[`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

ServiceClass
