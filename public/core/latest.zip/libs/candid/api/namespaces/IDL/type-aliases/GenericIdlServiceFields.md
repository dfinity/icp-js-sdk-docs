---
title: GenericIdlServiceFields
editUrl: false
next: true
prev: true
---

> **GenericIdlServiceFields** = `Record`\<`string`, [`FuncClass`](../classes/FuncClass.md)\>

Defined in: [packages/candid/src/idl.ts:1840](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L1840)

The generic type of the fields of an [IDL Service](../functions/Service.md).
