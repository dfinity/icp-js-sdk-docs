---
title: GenericIdlServiceFields
editUrl: false
next: true
prev: true
---

> **GenericIdlServiceFields** = `Record`\<`string`, [`FuncClass`](../classes/FuncClass.md)\>

Defined in: [packages/candid/src/idl.ts:1848](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L1848)

The generic type of the fields of an [IDL Service](../functions/Service.md).
