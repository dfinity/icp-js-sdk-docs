---
title: GenericIdlServiceFields
editUrl: false
next: true
prev: true
---

> **GenericIdlServiceFields** = `Record`\<`string`, [`FuncClass`](../classes/FuncClass.md)\>

Defined in: [packages/candid/src/idl.ts:1848](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L1848)

The generic type of the fields of an [IDL Service](../functions/Service.md).
