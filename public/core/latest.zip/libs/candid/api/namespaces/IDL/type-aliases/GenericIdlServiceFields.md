---
title: GenericIdlServiceFields
editUrl: false
next: true
prev: true
---

> **GenericIdlServiceFields** = `Record`\<`string`, [`FuncClass`](../classes/FuncClass.md)\>

Defined in: [packages/candid/src/idl.ts:1848](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L1848)

The generic type of the fields of an [IDL Service](../functions/Service.md).
