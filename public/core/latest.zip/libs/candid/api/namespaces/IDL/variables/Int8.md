---
title: Int8
editUrl: false
next: true
prev: true
---

> `const` **Int8**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/core/src/candid/idl.ts:2361](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/idl.ts#L2361)
