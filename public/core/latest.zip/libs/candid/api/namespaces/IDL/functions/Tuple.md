---
title: Tuple
editUrl: false
next: true
prev: true
---

> **Tuple**\<`T`\>(...`types`): [`TupleClass`](../classes/TupleClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2317](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2317)

## Type Parameters

### T

`T` *extends* `any`[]

## Parameters

### types

...`T`

array of any types

## Returns

[`TupleClass`](../classes/TupleClass.md)\<`T`\>

TupleClass from those types
