---
title: Tuple
editUrl: false
next: true
prev: true
---

> **Tuple**\<`T`\>(...`types`): [`TupleClass`](../classes/TupleClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2317](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/idl.ts#L2317)

## Type Parameters

### T

`T` *extends* `any`[]

## Parameters

### types

...`T`

array of any types

## Returns

[`TupleClass`](../classes/TupleClass.md)\<`T`\>

TupleClass from those types
