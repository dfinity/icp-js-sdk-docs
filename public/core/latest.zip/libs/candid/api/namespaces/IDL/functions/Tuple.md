---
title: Tuple
editUrl: false
next: true
prev: true
---

> **Tuple**\<`T`\>(...`types`): [`TupleClass`](../classes/TupleClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2309](https://github.com/dfinity/icp-js-core/blob/4d0b312cad2a09329b7f8cb8461214c7ded3268a/packages/candid/src/idl.ts#L2309)


### T

`T` *extends* `any`[]

## Parameters

### types

...`T`

array of any types

## Returns

[`TupleClass`](../classes/TupleClass.md)\<`T`\>

TupleClass from those types
