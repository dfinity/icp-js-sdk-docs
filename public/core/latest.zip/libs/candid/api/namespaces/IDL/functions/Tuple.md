---
title: Tuple
editUrl: false
next: true
prev: true
---

> **Tuple**\<`T`\>(...`types`): [`TupleClass`](../classes/TupleClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2309](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L2309)


### T

`T` *extends* `any`[]

## Parameters

### types

...`T`

array of any types

## Returns

[`TupleClass`](../classes/TupleClass.md)\<`T`\>

TupleClass from those types
