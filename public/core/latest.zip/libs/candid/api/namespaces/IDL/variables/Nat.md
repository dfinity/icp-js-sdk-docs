---
title: Nat
editUrl: false
next: true
prev: true
---

> `const` **Nat**: [`NatClass`](../classes/NatClass.md)

Defined in: [packages/candid/src/idl.ts:2295](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L2295)
