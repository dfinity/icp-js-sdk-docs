---
title: Nat
editUrl: false
next: true
prev: true
---

> `const` **Nat**: [`NatClass`](../classes/NatClass.md)

Defined in: [packages/candid/src/idl.ts:2295](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/candid/src/idl.ts#L2295)
