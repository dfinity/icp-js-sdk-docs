---
title: Nat
editUrl: false
next: true
prev: true
---

> `const` **Nat**: [`NatClass`](../classes/NatClass.md)

Defined in: [packages/core/src/candid/idl.ts:2356](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/idl.ts#L2356)
