---
title: Visitor
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:130](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L130)

## Extended by

- [`Render`](../../../classes/Render.md)

## Type Parameters

### D

`D`

### R

`R`

## Constructors

### Constructor

> **new Visitor**\<`D`, `R`\>(): `Visitor`\<`D`, `R`\>

#### Returns

`Visitor`\<`D`, `R`\>

## Methods

### visitBool()

> **visitBool**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:140](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L140)

#### Parameters

##### t

[`BoolClass`](BoolClass.md)

##### data

`D`

#### Returns

`R`

***

### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:174](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L174)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`ConstructType`](ConstructType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitEmpty()

> **visitEmpty**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:137](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L137)

#### Parameters

##### t

[`EmptyClass`](EmptyClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFixedInt()

> **visitFixedInt**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:164](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L164)

#### Parameters

##### t

[`FixedIntClass`](FixedIntClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFixedNat()

> **visitFixedNat**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:167](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L167)

#### Parameters

##### t

[`FixedNatClass`](FixedNatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFloat()

> **visitFloat**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:161](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L161)

#### Parameters

##### t

[`FloatClass`](FloatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFunc()

> **visitFunc**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:196](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L196)

#### Parameters

##### t

[`FuncClass`](FuncClass.md)

##### data

`D`

#### Returns

`R`

***

### visitInt()

> **visitInt**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:155](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L155)

#### Parameters

##### t

[`IntClass`](IntClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNat()

> **visitNat**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:158](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L158)

#### Parameters

##### t

[`NatClass`](NatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNull()

> **visitNull**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:143](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L143)

#### Parameters

##### t

[`NullClass`](NullClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:152](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L152)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](PrimitiveType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitOpt()

> **visitOpt**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:180](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L180)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`OptClass`](OptClass.md)\<`T`\>

##### \_ty

[`Type`](Type.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:134](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L134)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](PrimitiveType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitPrincipal()

> **visitPrincipal**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:170](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L170)

#### Parameters

##### t

[`PrincipalClass`](PrincipalClass.md)

##### data

`D`

#### Returns

`R`

***

### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:193](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L193)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`RecClass`](RecClass.md)\<`T`\>

##### ty

[`ConstructType`](ConstructType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitRecord()

> **visitRecord**(`t`, `_fields`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:183](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L183)

#### Parameters

##### t

[`RecordClass`](RecordClass.md)

##### \_fields

\[`string`, [`Type`](Type.md)\<`any`\>\][]

##### data

`D`

#### Returns

`R`

***

### visitReserved()

> **visitReserved**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:146](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L146)

#### Parameters

##### t

[`ReservedClass`](ReservedClass.md)

##### data

`D`

#### Returns

`R`

***

### visitService()

> **visitService**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:199](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L199)

#### Parameters

##### t

[`ServiceClass`](ServiceClass.md)

##### data

`D`

#### Returns

`R`

***

### visitText()

> **visitText**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:149](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L149)

#### Parameters

##### t

[`TextClass`](TextClass.md)

##### data

`D`

#### Returns

`R`

***

### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:186](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L186)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### t

[`TupleClass`](TupleClass.md)\<`T`\>

##### components

[`Type`](Type.md)\<`any`\>[]

##### data

`D`

#### Returns

`R`

***

### visitType()

> **visitType**\<`T`\>(`_t`, `_data`): `R`

Defined in: [packages/candid/src/idl.ts:131](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L131)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`Type`](Type.md)\<`T`\>

##### \_data

`D`

#### Returns

`R`

***

### visitVariant()

> **visitVariant**(`t`, `_fields`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:190](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L190)

#### Parameters

##### t

[`VariantClass`](VariantClass.md)

##### \_fields

\[`string`, [`Type`](Type.md)\<`any`\>\][]

##### data

`D`

#### Returns

`R`

***

### visitVec()

> **visitVec**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:177](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L177)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`VecClass`](VecClass.md)\<`T`\>

##### \_ty

[`Type`](Type.md)\<`T`\>

##### data

`D`

#### Returns

`R`
