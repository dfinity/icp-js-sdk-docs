---
title: Visitor
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:122](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L122)


- [`Render`](../../../classes/Render.md)

## Type Parameters

### D

`D`

### R

`R`

## Constructors

### Constructor

> **new Visitor**\<`D`, `R`\>(): `Visitor`\<`D`, `R`\>

#### Returns

`Visitor`\<`D`, `R`\>

## Methods

### visitBool()

> **visitBool**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:132](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L132)

#### Parameters

##### t

[`BoolClass`](BoolClass.md)

##### data

`D`

#### Returns

`R`

***

### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:166](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L166)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`ConstructType`](ConstructType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitEmpty()

> **visitEmpty**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:129](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L129)

#### Parameters

##### t

[`EmptyClass`](EmptyClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFixedInt()

> **visitFixedInt**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:156](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L156)

#### Parameters

##### t

[`FixedIntClass`](FixedIntClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFixedNat()

> **visitFixedNat**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:159](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L159)

#### Parameters

##### t

[`FixedNatClass`](FixedNatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFloat()

> **visitFloat**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:153](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L153)

#### Parameters

##### t

[`FloatClass`](FloatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFunc()

> **visitFunc**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:188](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L188)

#### Parameters

##### t

[`FuncClass`](FuncClass.md)

##### data

`D`

#### Returns

`R`

***

### visitInt()

> **visitInt**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:147](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L147)

#### Parameters

##### t

[`IntClass`](IntClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNat()

> **visitNat**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:150](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L150)

#### Parameters

##### t

[`NatClass`](NatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNull()

> **visitNull**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:135](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L135)

#### Parameters

##### t

[`NullClass`](NullClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:144](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L144)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](PrimitiveType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitOpt()

> **visitOpt**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:172](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L172)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`OptClass`](OptClass.md)\<`T`\>

##### \_ty

[`Type`](Type.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:126](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L126)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](PrimitiveType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitPrincipal()

> **visitPrincipal**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:162](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L162)

#### Parameters

##### t

[`PrincipalClass`](PrincipalClass.md)

##### data

`D`

#### Returns

`R`

***

### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:185](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L185)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`RecClass`](RecClass.md)\<`T`\>

##### ty

[`ConstructType`](ConstructType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitRecord()

> **visitRecord**(`t`, `_fields`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:175](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L175)

#### Parameters

##### t

[`RecordClass`](RecordClass.md)

##### \_fields

\[`string`, [`Type`](Type.md)\<`any`\>\][]

##### data

`D`

#### Returns

`R`

***

### visitReserved()

> **visitReserved**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:138](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L138)

#### Parameters

##### t

[`ReservedClass`](ReservedClass.md)

##### data

`D`

#### Returns

`R`

***

### visitService()

> **visitService**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:191](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L191)

#### Parameters

##### t

[`ServiceClass`](ServiceClass.md)

##### data

`D`

#### Returns

`R`

***

### visitText()

> **visitText**(`t`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:141](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L141)

#### Parameters

##### t

[`TextClass`](TextClass.md)

##### data

`D`

#### Returns

`R`

***

### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:178](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L178)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### t

[`TupleClass`](TupleClass.md)\<`T`\>

##### components

[`Type`](Type.md)\<`any`\>[]

##### data

`D`

#### Returns

`R`

***

### visitType()

> **visitType**\<`T`\>(`_t`, `_data`): `R`

Defined in: [packages/candid/src/idl.ts:123](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L123)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`Type`](Type.md)\<`T`\>

##### \_data

`D`

#### Returns

`R`

***

### visitVariant()

> **visitVariant**(`t`, `_fields`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:182](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L182)

#### Parameters

##### t

[`VariantClass`](VariantClass.md)

##### \_fields

\[`string`, [`Type`](Type.md)\<`any`\>\][]

##### data

`D`

#### Returns

`R`

***

### visitVec()

> **visitVec**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/candid/src/idl.ts:169](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/candid/src/idl.ts#L169)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`VecClass`](VecClass.md)\<`T`\>

##### \_ty

[`Type`](Type.md)\<`T`\>

##### data

`D`

#### Returns

`R`
