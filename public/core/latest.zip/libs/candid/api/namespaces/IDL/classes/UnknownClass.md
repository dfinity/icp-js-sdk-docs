---
title: UnknownClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:350](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L350)

Represents an IDL Unknown, a placeholder type for deserialization only.
When decoding a value as Unknown, all fields will be retained but the names are only available in
hashed form.
A deserialized unknown will offer it's actual type by calling the `type()` function.
Unknown cannot be serialized and attempting to do so will throw an error.


- [`Type`](Type.md)

## Constructors

### Constructor

> **new UnknownClass**(): `UnknownClass`

#### Returns

`UnknownClass`

#### Inherited from

[`Type`](Type.md).[`constructor`](Type.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:416](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L416)

##### Returns

`string`

#### Overrides

[`Type`](Type.md).[`name`](Type.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:351](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L351)

##### Returns

`IdlTypeName`

#### Overrides

[`Type`](Type.md).[`typeName`](Type.md#typename)

## Methods

### \_buildTypeTableImpl()

> `protected` **\_buildTypeTableImpl**(): `void`

Defined in: [packages/candid/src/idl.ts:412](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L412)

#### Returns

`void`

#### Overrides

[`Type`](Type.md).[`_buildTypeTableImpl`](Type.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:363](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L363)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`Type`](Type.md).[`accept`](Type.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L238)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`buildTypeTable`](Type.md#buildtypetable)

***

### checkType()

> **checkType**(`_t`): [`Type`](Type.md)

Defined in: [packages/candid/src/idl.ts:359](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L359)

#### Parameters

##### \_t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Overrides

[`Type`](Type.md).[`checkType`](Type.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is any`

Defined in: [packages/candid/src/idl.ts:367](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L367)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is any`

#### Overrides

[`Type`](Type.md).[`covariant`](Type.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `any`

Defined in: [packages/candid/src/idl.ts:383](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L383)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`any`

#### Overrides

[`Type`](Type.md).[`decodeValue`](Type.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:229](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L229)

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`display`](Type.md#display)

***

### encodeType()

> **encodeType**(): `never`

Defined in: [packages/candid/src/idl.ts:379](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L379)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Returns

`never`

#### Overrides

[`Type`](Type.md).[`encodeType`](Type.md#encodetype)

***

### encodeValue()

> **encodeValue**(): `never`

Defined in: [packages/candid/src/idl.ts:371](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L371)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Returns

`never`

#### Overrides

[`Type`](Type.md).[`encodeValue`](Type.md#encodevalue)

***

### valueToString()

> **valueToString**(): `never`

Defined in: [packages/candid/src/idl.ts:375](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L375)

#### Returns

`never`

#### Overrides

[`Type`](Type.md).[`valueToString`](Type.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is UnknownClass`

Defined in: [packages/candid/src/idl.ts:355](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/candid/src/idl.ts#L355)

#### Parameters

##### instance

`any`

#### Returns

`instance is UnknownClass`
