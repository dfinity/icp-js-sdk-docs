---
title: UnknownClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/idl.ts:359](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L359)

Represents an IDL Unknown, a placeholder type for deserialization only.
When decoding a value as Unknown, all fields will be retained but the names are only available in
hashed form.
A deserialized unknown will offer it's actual type by calling the `type()` function.
Unknown cannot be serialized and attempting to do so will throw an error.

## Extends

- [`Type`](Type.md)

## Constructors

### Constructor

> **new UnknownClass**(): `UnknownClass`

#### Returns

`UnknownClass`

#### Inherited from

[`Type`](Type.md).[`constructor`](Type.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:425](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L425)

##### Returns

`string`

#### Overrides

[`Type`](Type.md).[`name`](Type.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:360](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L360)

##### Returns

`IdlTypeName`

#### Overrides

[`Type`](Type.md).[`typeName`](Type.md#typename)

## Methods

### \_buildTypeTableImpl()

> `protected` **\_buildTypeTableImpl**(): `void`

Defined in: [packages/core/src/candid/idl.ts:421](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L421)

#### Returns

`void`

#### Overrides

[`Type`](Type.md).[`_buildTypeTableImpl`](Type.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:372](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L372)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`Type`](Type.md).[`accept`](Type.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L247)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`buildTypeTable`](Type.md#buildtypetable)

***

### checkType()

> **checkType**(`_t`): [`Type`](Type.md)

Defined in: [packages/core/src/candid/idl.ts:368](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L368)

#### Parameters

##### \_t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Overrides

[`Type`](Type.md).[`checkType`](Type.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is any`

Defined in: [packages/core/src/candid/idl.ts:376](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L376)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is any`

#### Overrides

[`Type`](Type.md).[`covariant`](Type.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `any`

Defined in: [packages/core/src/candid/idl.ts:392](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L392)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`any`

#### Overrides

[`Type`](Type.md).[`decodeValue`](Type.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L238)

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`display`](Type.md#display)

***

### encodeType()

> **encodeType**(): `never`

Defined in: [packages/core/src/candid/idl.ts:388](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L388)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Returns

`never`

#### Overrides

[`Type`](Type.md).[`encodeType`](Type.md#encodetype)

***

### encodeValue()

> **encodeValue**(): `never`

Defined in: [packages/core/src/candid/idl.ts:380](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L380)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Returns

`never`

#### Overrides

[`Type`](Type.md).[`encodeValue`](Type.md#encodevalue)

***

### valueToString()

> **valueToString**(): `never`

Defined in: [packages/core/src/candid/idl.ts:384](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L384)

#### Returns

`never`

#### Overrides

[`Type`](Type.md).[`valueToString`](Type.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is UnknownClass`

Defined in: [packages/core/src/candid/idl.ts:364](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L364)

#### Parameters

##### instance

`any`

#### Returns

`instance is UnknownClass`
