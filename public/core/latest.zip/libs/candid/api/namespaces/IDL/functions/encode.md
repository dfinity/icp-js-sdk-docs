---
title: encode
editUrl: false
next: true
prev: true
---

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:2013](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/idl.ts#L2013)

Encode a array of values

## Parameters

### argTypes

[`Type`](../classes/Type.md)\<`any`\>[]

array of Types

### args

`any`[]

array of values

## Returns

`Uint8Array`

serialised value
