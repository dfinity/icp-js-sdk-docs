---
title: encode
editUrl: false
next: true
prev: true
---

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1950](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/idl.ts#L1950)

Encode a array of values

## Parameters

### argTypes

[`Type`](../classes/Type.md)\<`any`\>[]

array of Types

### args

`any`[]

array of values

## Returns

`Uint8Array`

serialised value
