---
title: Principal
editUrl: false
next: true
prev: true
---

> `const` **Principal**: [`PrincipalClass`](../classes/PrincipalClass.md)

Defined in: [packages/candid/src/idl.ts:2310](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L2310)
