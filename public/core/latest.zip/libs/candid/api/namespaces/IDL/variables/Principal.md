---
title: Principal
editUrl: false
next: true
prev: true
---

> `const` **Principal**: [`PrincipalClass`](../classes/PrincipalClass.md)

Defined in: [packages/core/src/candid/idl.ts:2371](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/candid/idl.ts#L2371)
