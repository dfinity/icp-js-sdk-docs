---
title: Rec
editUrl: false
next: true
prev: true
---

> **Rec**(): [`RecClass`](../classes/RecClass.md)

Defined in: [packages/core/src/candid/idl.ts:2418](https://github.com/dfinity/icp-js-core/blob/dc09621aca787faf6bc63f7a782a4e3ae3c8603e/packages/core/src/candid/idl.ts#L2418)

## Returns

[`RecClass`](../classes/RecClass.md)

new RecClass
