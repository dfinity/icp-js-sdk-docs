---
title: Rec
editUrl: false
next: true
prev: true
---

> **Rec**(): [`RecClass`](../classes/RecClass.md)

Defined in: [packages/candid/src/idl.ts:2357](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/candid/src/idl.ts#L2357)


[`RecClass`](../classes/RecClass.md)

new RecClass
