---
title: TextClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/idl.ts:558](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L558)

Represents an IDL Text

## Extends

- [`PrimitiveType`](PrimitiveType.md)\<`string`\>

## Constructors

### Constructor

> **new TextClass**(): `TextClass`

#### Returns

`TextClass`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`constructor`](PrimitiveType.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:594](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L594)

##### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`name`](PrimitiveType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:559](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L559)

##### Returns

`IdlTypeName`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`typeName`](PrimitiveType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:287](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L287)

#### Parameters

##### \_typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`_buildTypeTableImpl`](PrimitiveType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:567](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L567)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`accept`](PrimitiveType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L247)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`buildTypeTable`](PrimitiveType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`Type`](Type.md)

Defined in: [packages/core/src/candid/idl.ts:280](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L280)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`checkType`](PrimitiveType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is string`

Defined in: [packages/core/src/candid/idl.ts:571](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L571)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`covariant`](PrimitiveType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `string`

Defined in: [packages/core/src/candid/idl.ts:586](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L586)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`decodeValue`](PrimitiveType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L238)

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`display`](PrimitiveType.md#display)

***

### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:582](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L582)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeType`](PrimitiveType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:576](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L576)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`string`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeValue`](PrimitiveType.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:598](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L598)

#### Parameters

##### x

`string`

#### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`valueToString`](PrimitiveType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is TextClass`

Defined in: [packages/core/src/candid/idl.ts:563](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L563)

#### Parameters

##### instance

`any`

#### Returns

`instance is TextClass`
