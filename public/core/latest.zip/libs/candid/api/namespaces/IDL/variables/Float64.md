---
title: Float64
editUrl: false
next: true
prev: true
---

> `const` **Float64**: [`FloatClass`](../classes/FloatClass.md)

Defined in: [packages/core/src/candid/idl.ts:2298](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L2298)
