---
title: IDL
editUrl: false
next: true
prev: true
---

## Classes

### BoolClass

Defined in: [packages/core/src/candid/idl.ts:445](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L445)

Represents an IDL Bool

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`boolean`\>

#### Constructors

##### Constructor

> **new BoolClass**(): [`BoolClass`](#boolclass)

###### Returns

[`BoolClass`](#boolclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:485](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L485)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:446](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L446)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:454](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L454)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is boolean`

Defined in: [packages/core/src/candid/idl.ts:458](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L458)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is boolean`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `boolean`

Defined in: [packages/core/src/candid/idl.ts:473](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L473)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`boolean`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:469](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L469)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:465](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L465)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`boolean`

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L255)

###### Parameters

###### x

`boolean`

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is BoolClass`

Defined in: [packages/core/src/candid/idl.ts:450](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L450)

###### Parameters

###### instance

`any`

###### Returns

`instance is BoolClass`

***

### CandidDecodeError

Defined in: [packages/core/src/candid/idl.ts:31](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L31)

Error thrown when candid decoding fails due to a type mismatch
between the expected and received types.

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new CandidDecodeError**(`message`): [`CandidDecodeError`](#candiddecodeerror)

Defined in: [packages/core/src/candid/idl.ts:34](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L34)

###### Parameters

###### message

`string`

###### Returns

[`CandidDecodeError`](#candiddecodeerror)

###### Overrides

`Error.constructor`

#### Properties

##### cause?

> `optional` **cause?**: `unknown`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.error.d.ts:26

###### Inherited from

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string` = `'CandidDecodeError'`

Defined in: [packages/core/src/candid/idl.ts:32](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L32)

###### Overrides

`Error.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Methods

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### `abstract` ConstructType

Defined in: [packages/core/src/candid/idl.ts:305](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L305)

Represents an IDL type.

#### Extends

- [`Type`](#abstract-type)\<`T`\>

#### Extended by

- [`VecClass`](#vecclass)
- [`OptClass`](#optclass)
- [`RecordClass`](#recordclass)
- [`VariantClass`](#variantclass)
- [`RecClass`](#recclass)
- [`FuncClass`](#funcclass)
- [`ServiceClass`](#serviceclass)

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new ConstructType**\<`T`\>(): [`ConstructType`](#abstract-constructtype)\<`T`\>

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Inherited from

[`Type`](#abstract-type).[`constructor`](#constructor-20)

#### Properties

##### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L247)

###### Inherited from

[`Type`](#abstract-type).[`name`](#name-20)

##### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L246)

###### Inherited from

[`Type`](#abstract-type).[`typeName`](#typename-20)

#### Methods

##### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:289](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L289)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`_buildTypeTableImpl`](#_buildtypetableimpl-19)

##### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:248](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L248)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Inherited from

[`Type`](#abstract-type).[`accept`](#accept-19)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`buildTypeTable`](#buildtypetable-19)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Overrides

[`Type`](#abstract-type).[`checkType`](#checktype-19)

##### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:270](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L270)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Inherited from

[`Type`](#abstract-type).[`covariant`](#covariant-19)

##### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:287](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L287)

###### Parameters

###### x

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Inherited from

[`Type`](#abstract-type).[`decodeValue`](#decodevalue-19)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`display`](#display-19)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`Type`](#abstract-type).[`encodeType`](#encodetype-19)

##### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:277](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L277)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`

###### Inherited from

[`Type`](#abstract-type).[`encodeValue`](#encodevalue-19)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L255)

###### Parameters

###### x

`T`

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`valueToString`](#valuetostring-19)

***

### EmptyClass

Defined in: [packages/core/src/candid/idl.ts:326](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L326)

Represents an IDL Empty, a type which has no inhabitants.
Since no values exist for this type, it cannot be serialised or deserialised.
Result types like `Result<Text, Empty>` should always succeed.

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`never`\>

#### Constructors

##### Constructor

> **new EmptyClass**(): [`EmptyClass`](#emptyclass)

###### Returns

[`EmptyClass`](#emptyclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:359](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L359)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:327](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L327)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:335](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L335)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is never`

Defined in: [packages/core/src/candid/idl.ts:339](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L339)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(): `never`

Defined in: [packages/core/src/candid/idl.ts:355](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L355)

###### Returns

`never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:351](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L351)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(): `never`

Defined in: [packages/core/src/candid/idl.ts:343](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L343)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(): `never`

Defined in: [packages/core/src/candid/idl.ts:347](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L347)

###### Returns

`never`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is EmptyClass`

Defined in: [packages/core/src/candid/idl.ts:331](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L331)

###### Parameters

###### instance

`any`

###### Returns

`instance is EmptyClass`

***

### FixedIntClass

Defined in: [packages/core/src/candid/idl.ts:782](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L782)

Represents an IDL fixed-width Int(n)

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint` \| `number`\>

#### Constructors

##### Constructor

> **new FixedIntClass**(`_bits`): [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:791](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L791)

###### Parameters

###### \_bits

`number`

###### Returns

[`FixedIntClass`](#fixedintclass)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Properties

##### \_bits

> `readonly` **\_bits**: `number`

Defined in: [packages/core/src/candid/idl.ts:791](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L791)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:833](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L833)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:783](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L783)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:795](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L795)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:799](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L799)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `number` \| `bigint`

Defined in: [packages/core/src/candid/idl.ts:824](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L824)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`number` \| `bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:819](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L819)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:815](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L815)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:837](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L837)

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FixedIntClass`

Defined in: [packages/core/src/candid/idl.ts:787](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L787)

###### Parameters

###### instance

`any`

###### Returns

`instance is FixedIntClass`

***

### FixedNatClass

Defined in: [packages/core/src/candid/idl.ts:845](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L845)

Represents an IDL fixed-width Nat(n)

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint` \| `number`\>

#### Constructors

##### Constructor

> **new FixedNatClass**(`_bits`): [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:854](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L854)

###### Parameters

###### \_bits

`number`

###### Returns

[`FixedNatClass`](#fixednatclass)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Properties

##### \_bits

> `readonly` **\_bits**: `number`

Defined in: [packages/core/src/candid/idl.ts:854](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L854)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:895](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L895)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:846](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L846)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:858](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L858)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:862](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L862)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `number` \| `bigint`

Defined in: [packages/core/src/candid/idl.ts:886](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L886)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`number` \| `bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:881](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L881)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:877](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L877)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:899](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L899)

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FixedNatClass`

Defined in: [packages/core/src/candid/idl.ts:850](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L850)

###### Parameters

###### instance

`any`

###### Returns

`instance is FixedNatClass`

***

### FloatClass

Defined in: [packages/core/src/candid/idl.ts:718](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L718)

Represents an IDL Float

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`number`\>

#### Constructors

##### Constructor

> **new FloatClass**(`_bits`): [`FloatClass`](#floatclass)

Defined in: [packages/core/src/candid/idl.ts:727](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L727)

###### Parameters

###### \_bits

`number`

###### Returns

[`FloatClass`](#floatclass)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Properties

##### \_bits

> `readonly` **\_bits**: `number`

Defined in: [packages/core/src/candid/idl.ts:727](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L727)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:770](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L770)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:719](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L719)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:733](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L733)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is number`

Defined in: [packages/core/src/candid/idl.ts:737](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L737)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is number`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `number`

Defined in: [packages/core/src/candid/idl.ts:760](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L760)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`number`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:755](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L755)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/candid/idl.ts:744](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L744)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number`

###### Returns

`Uint8Array`\<`ArrayBuffer`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:774](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L774)

###### Parameters

###### x

`number`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FloatClass`

Defined in: [packages/core/src/candid/idl.ts:723](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L723)

###### Parameters

###### instance

`any`

###### Returns

`instance is FloatClass`

***

### FuncClass

Defined in: [packages/core/src/candid/idl.ts:1785](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1785)

Represents an IDL function reference.

#### Param

Argument types.

#### Param

Return types.

#### Param

Function annotations.

#### Extends

- [`ConstructType`](#abstract-constructtype)\<\[[`Principal`](../../../principal/api.md#principal), `string`\]\>

#### Type Parameters

##### Args

`Args` *extends* [`GenericIdlFuncArgs`](#genericidlfuncargs) = [`GenericIdlFuncArgs`](#genericidlfuncargs)

##### Rets

`Rets` *extends* [`GenericIdlFuncRets`](#genericidlfuncrets) = [`GenericIdlFuncRets`](#genericidlfuncrets)

#### Constructors

##### Constructor

> **new FuncClass**\<`Args`, `Rets`\>(`argTypes`, `retTypes`, `annotations?`): [`FuncClass`](#funcclass)\<`Args`, `Rets`\>

Defined in: [packages/core/src/candid/idl.ts:1804](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1804)

###### Parameters

###### argTypes

`Args`

###### retTypes

`Rets`

###### annotations?

`string`[] = `[]`

###### Returns

[`FuncClass`](#funcclass)\<`Args`, `Rets`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### annotations

> **annotations**: `string`[] = `[]`

Defined in: [packages/core/src/candid/idl.ts:1807](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1807)

##### argTypes

> **argTypes**: `Args`

Defined in: [packages/core/src/candid/idl.ts:1805](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1805)

##### retTypes

> **retTypes**: `Rets`

Defined in: [packages/core/src/candid/idl.ts:1806](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1806)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1874](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1874)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1789](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1789)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1838](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1838)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1812](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1812)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<\[[`Principal`](../../../principal/api.md#principal), `string`\]\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<\[[`Principal`](../../../principal/api.md#principal), `string`\]\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is [Principal, string]`

Defined in: [packages/core/src/candid/idl.ts:1815](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1815)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is [Principal, string]`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): \[[`Principal`](../../../principal/api.md#principal), `string`\]

Defined in: [packages/core/src/candid/idl.ts:1853](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1853)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

\[[`Principal`](../../../principal/api.md#principal), `string`\]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1885](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1885)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`__namedParameters`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:1828](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1828)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### \_\_namedParameters

\[[`Principal`](../../../principal/api.md#principal), `string`\]

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`__namedParameters`): `string`

Defined in: [packages/core/src/candid/idl.ts:1881](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1881)

###### Parameters

###### \_\_namedParameters

\[[`Principal`](../../../principal/api.md#principal), `string`\]

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is FuncClass<GenericIdlFuncArgs, GenericIdlFuncRets>`

Defined in: [packages/core/src/candid/idl.ts:1793](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1793)

###### Parameters

###### instance

`any`

###### Returns

`instance is FuncClass<GenericIdlFuncArgs, GenericIdlFuncRets>`

##### argsToString()

> `static` **argsToString**(`types`, `v`): `string`

Defined in: [packages/core/src/candid/idl.ts:1797](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1797)

###### Parameters

###### types

[`Type`](#abstract-type)\<`any`\>[]

###### v

`any`[]

###### Returns

`string`

***

### IntClass

Defined in: [packages/core/src/candid/idl.ts:624](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L624)

Represents an IDL Int

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint`\>

#### Constructors

##### Constructor

> **new IntClass**(): [`IntClass`](#intclass)

###### Returns

[`IntClass`](#intclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:659](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L659)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:625](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L625)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:633](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L633)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:637](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L637)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `bigint`

Defined in: [packages/core/src/candid/idl.ts:654](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L654)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:650](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L650)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:646](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L646)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:663](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L663)

###### Parameters

###### x

`bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is IntClass`

Defined in: [packages/core/src/candid/idl.ts:629](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L629)

###### Parameters

###### instance

`any`

###### Returns

`instance is IntClass`

***

### NatClass

Defined in: [packages/core/src/candid/idl.ts:671](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L671)

Represents an IDL Nat

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`bigint`\>

#### Constructors

##### Constructor

> **new NatClass**(): [`NatClass`](#natclass)

###### Returns

[`NatClass`](#natclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:706](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L706)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:672](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L672)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:680](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L680)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is bigint`

Defined in: [packages/core/src/candid/idl.ts:684](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L684)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `bigint`

Defined in: [packages/core/src/candid/idl.ts:701](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L701)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`bigint`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:697](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L697)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:693](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L693)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`number` \| `bigint`

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:710](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L710)

###### Parameters

###### x

`bigint`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is NatClass`

Defined in: [packages/core/src/candid/idl.ts:676](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L676)

###### Parameters

###### instance

`any`

###### Returns

`instance is NatClass`

***

### NullClass

Defined in: [packages/core/src/candid/idl.ts:493](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L493)

Represents an IDL Null

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`null`\>

#### Constructors

##### Constructor

> **new NullClass**(): [`NullClass`](#nullclass)

###### Returns

[`NullClass`](#nullclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:526](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L526)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:494](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L494)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:502](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L502)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is null`

Defined in: [packages/core/src/candid/idl.ts:506](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L506)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is null`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`_b`, `t`): `null`

Defined in: [packages/core/src/candid/idl.ts:521](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L521)

###### Parameters

###### \_b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`null`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:517](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L517)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:513](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L513)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L255)

###### Parameters

###### x

`null`

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is NullClass`

Defined in: [packages/core/src/candid/idl.ts:498](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L498)

###### Parameters

###### instance

`any`

###### Returns

`instance is NullClass`

***

### OptClass

Defined in: [packages/core/src/candid/idl.ts:1120](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1120)

Represents an IDL Option

#### Param

#### Extends

- [`ConstructType`](#abstract-constructtype)\<\[`T`\] \| \[\]\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new OptClass**\<`T`\>(`_type`): [`OptClass`](#optclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1129](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1129)

###### Parameters

###### \_type

[`Type`](#abstract-type)\<`T`\>

###### Returns

[`OptClass`](#optclass)\<`T`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_type

> **\_type**: [`Type`](#abstract-type)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1129](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1129)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1237](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1237)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1121](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1121)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1158](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1158)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1133](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1133)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<\[\] \| \[`T`\]\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<\[\] \| \[`T`\]\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): x is \[\] \| \[T\]

Defined in: [packages/core/src/candid/idl.ts:1137](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1137)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

x is \[\] \| \[T\]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): \[\] \| \[`T`\]

Defined in: [packages/core/src/candid/idl.ts:1166](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1166)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

\[\] \| \[`T`\]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1241](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1241)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1151](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1151)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

\[\] \| \[`T`\]

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1245](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1245)

###### Parameters

###### x

\[\] \| \[`T`\]

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is OptClass<T>`

Defined in: [packages/core/src/candid/idl.ts:1125](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1125)

###### Type Parameters

###### T

`T`

###### Parameters

###### instance

`any`

###### Returns

`instance is OptClass<T>`

***

### `abstract` PrimitiveType

Defined in: [packages/core/src/candid/idl.ts:292](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L292)

Represents an IDL type.

#### Extends

- [`Type`](#abstract-type)\<`T`\>

#### Extended by

- [`EmptyClass`](#emptyclass)
- [`BoolClass`](#boolclass)
- [`NullClass`](#nullclass)
- [`ReservedClass`](#reservedclass)
- [`TextClass`](#textclass)
- [`IntClass`](#intclass)
- [`NatClass`](#natclass)
- [`FloatClass`](#floatclass)
- [`FixedIntClass`](#fixedintclass)
- [`FixedNatClass`](#fixednatclass)
- [`PrincipalClass`](#principalclass)

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new PrimitiveType**\<`T`\>(): [`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### Returns

[`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### Inherited from

[`Type`](#abstract-type).[`constructor`](#constructor-20)

#### Properties

##### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L247)

###### Inherited from

[`Type`](#abstract-type).[`name`](#name-20)

##### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L246)

###### Inherited from

[`Type`](#abstract-type).[`typeName`](#typename-20)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`Type`](#abstract-type).[`_buildTypeTableImpl`](#_buildtypetableimpl-19)

##### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:248](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L248)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Inherited from

[`Type`](#abstract-type).[`accept`](#accept-19)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`buildTypeTable`](#buildtypetable-19)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Overrides

[`Type`](#abstract-type).[`checkType`](#checktype-19)

##### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:270](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L270)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Inherited from

[`Type`](#abstract-type).[`covariant`](#covariant-19)

##### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:287](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L287)

###### Parameters

###### x

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Inherited from

[`Type`](#abstract-type).[`decodeValue`](#decodevalue-19)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`display`](#display-19)

##### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:283](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L283)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`

###### Inherited from

[`Type`](#abstract-type).[`encodeType`](#encodetype-19)

##### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:277](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L277)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`

###### Inherited from

[`Type`](#abstract-type).[`encodeValue`](#encodevalue-19)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L255)

###### Parameters

###### x

`T`

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`valueToString`](#valuetostring-19)

***

### PrincipalClass

Defined in: [packages/core/src/candid/idl.ts:1727](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1727)

Represents an IDL principal reference

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<[`Principal`](../../../principal/api.md#principal)\>

#### Constructors

##### Constructor

> **new PrincipalClass**(): [`PrincipalClass`](#principalclass)

###### Returns

[`PrincipalClass`](#principalclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1761](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1761)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1728](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1728)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1736](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1736)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is Principal`

Defined in: [packages/core/src/candid/idl.ts:1740](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1740)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Principal`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/candid/idl.ts:1756](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1756)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

[`Principal`](../../../principal/api.md#principal)

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1752](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1752)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1747](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1747)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1764](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1764)

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is PrincipalClass`

Defined in: [packages/core/src/candid/idl.ts:1732](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1732)

###### Parameters

###### instance

`any`

###### Returns

`instance is PrincipalClass`

***

### RecClass

Defined in: [packages/core/src/candid/idl.ts:1637](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1637)

Represents a reference to an IDL type, used for defining recursive data
types.

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`T`\>

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new RecClass**\<`T`\>(): [`RecClass`](#recclass)\<`T`\>

###### Returns

[`RecClass`](#recclass)\<`T`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1695](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1695)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1638](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1638)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1679](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1679)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1650](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1650)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:1665](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1665)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:1688](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1688)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1699](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1699)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:1672](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1672)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### fill()

> **fill**(`t`): `void`

Defined in: [packages/core/src/candid/idl.ts:1657](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1657)

###### Parameters

###### t

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### Returns

`void`

##### getType()

> **getType**(): [`ConstructType`](#abstract-constructtype)\<`T`\> \| `undefined`

Defined in: [packages/core/src/candid/idl.ts:1661](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1661)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`\> \| `undefined`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1706](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1706)

###### Parameters

###### x

`T`

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is RecClass<any>`

Defined in: [packages/core/src/candid/idl.ts:1646](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1646)

###### Parameters

###### instance

`any`

###### Returns

`instance is RecClass<any>`

***

### RecordClass

Defined in: [packages/core/src/candid/idl.ts:1257](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1257)

Represents an IDL Record

#### Param

mapping of function name to Type

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

#### Extended by

- [`TupleClass`](#tupleclass)

#### Constructors

##### Constructor

> **new RecordClass**(`fields?`): [`RecordClass`](#recordclass)

Defined in: [packages/core/src/candid/idl.ts:1271](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1271)

###### Parameters

###### fields?

`Record`\<`string`, [`Type`](#abstract-type)\> = `{}`

###### Returns

[`RecordClass`](#recordclass)

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/idl.ts:1269](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1269)

#### Accessors

##### fieldsAsObject

###### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](#abstract-type)\>

Defined in: [packages/core/src/candid/idl.ts:1394](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1394)

###### Returns

`Record`\<`number`, [`Type`](#abstract-type)\>

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1402](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1402)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1258](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1258)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1321](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1321)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1276](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1276)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is Record<string, any>`

Defined in: [packages/core/src/candid/idl.ts:1292](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1292)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Record<string, any>`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `Record`\<`string`, `any`\>

Defined in: [packages/core/src/candid/idl.ts:1332](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1332)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`Record`\<`string`, `any`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1407](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1407)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1315](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1315)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### tryAsTuple()

> **tryAsTuple**(): [`Type`](#abstract-type)\<`any`\>[] \| `null`

Defined in: [packages/core/src/candid/idl.ts:1280](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1280)

###### Returns

[`Type`](#abstract-type)\<`any`\>[] \| `null`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1412](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1412)

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is RecordClass`

Defined in: [packages/core/src/candid/idl.ts:1262](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1262)

###### Parameters

###### instance

`any`

###### Returns

`instance is RecordClass`

***

### ReservedClass

Defined in: [packages/core/src/candid/idl.ts:534](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L534)

Represents an IDL Reserved

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`any`\>

#### Constructors

##### Constructor

> **new ReservedClass**(): [`ReservedClass`](#reservedclass)

###### Returns

[`ReservedClass`](#reservedclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:566](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L566)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:535](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L535)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:543](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L543)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`_x`): `_x is any`

Defined in: [packages/core/src/candid/idl.ts:547](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L547)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### \_x

`any`

###### Returns

`_x is any`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `null`

Defined in: [packages/core/src/candid/idl.ts:559](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L559)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`null`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:555](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L555)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:551](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L551)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`Uint8Array`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L255)

###### Parameters

###### x

`any`

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is ReservedClass`

Defined in: [packages/core/src/candid/idl.ts:539](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L539)

###### Parameters

###### instance

`any`

###### Returns

`instance is ReservedClass`

***

### ServiceClass

Defined in: [packages/core/src/candid/idl.ts:1911](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1911)

Represents an IDL type.

#### Extends

- [`ConstructType`](#abstract-constructtype)\<[`Principal`](../../../principal/api.md#principal)\>

#### Type Parameters

##### K

`K` *extends* `string` = `string`

##### Fields

`Fields` *extends* [`GenericIdlServiceFields`](#genericidlservicefields) = [`GenericIdlServiceFields`](#genericidlservicefields)

#### Constructors

##### Constructor

> **new ServiceClass**\<`K`, `Fields`\>(`fields`): [`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

Defined in: [packages/core/src/candid/idl.ts:1924](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1924)

###### Parameters

###### fields

`Fields`

###### Returns

[`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_fields

> `readonly` **\_fields**: \[`K`, `Fields`\[`K`\]\][]

Defined in: [packages/core/src/candid/idl.ts:1923](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1923)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1974](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1974)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1915](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1915)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1952](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1952)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1936](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1936)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<[`Principal`](../../../principal/api.md#principal)\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<[`Principal`](../../../principal/api.md#principal)\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is Principal`

Defined in: [packages/core/src/candid/idl.ts:1939](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1939)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Principal`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/candid/idl.ts:1965](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1965)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

[`Principal`](../../../principal/api.md#principal)

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1946](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1946)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### fieldsAsObject()

> **fieldsAsObject**(): `Fields`

Defined in: [packages/core/src/candid/idl.ts:1983](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1983)

###### Returns

`Fields`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1979](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1979)

###### Parameters

###### x

[`Principal`](../../../principal/api.md#principal)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is ServiceClass<string, GenericIdlServiceFields>`

Defined in: [packages/core/src/candid/idl.ts:1919](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1919)

###### Parameters

###### instance

`any`

###### Returns

`instance is ServiceClass<string, GenericIdlServiceFields>`

***

### TextClass

Defined in: [packages/core/src/candid/idl.ts:574](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L574)

Represents an IDL Text

#### Extends

- [`PrimitiveType`](#abstract-primitivetype)\<`string`\>

#### Constructors

##### Constructor

> **new TextClass**(): [`TextClass`](#textclass)

###### Returns

[`TextClass`](#textclass)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`constructor`](#constructor-12)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:612](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L612)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`name`](#name-12)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:575](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L575)

###### Returns

`IdlTypeName`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`typeName`](#typename-11)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:300](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L300)

###### Parameters

###### \_typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`_buildTypeTableImpl`](#_buildtypetableimpl-11)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:583](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L583)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`accept`](#accept-11)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`buildTypeTable`](#buildtypetable-11)

##### checkType()

> **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L293)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`checkType`](#checktype-11)

##### covariant()

> **covariant**(`x`): `x is string`

Defined in: [packages/core/src/candid/idl.ts:587](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L587)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`covariant`](#covariant-11)

##### decodeValue()

> **decodeValue**(`b`, `t`): `string`

Defined in: [packages/core/src/candid/idl.ts:604](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L604)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`decodeValue`](#decodevalue-11)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`PrimitiveType`](#abstract-primitivetype).[`display`](#display-11)

##### encodeType()

> **encodeType**(): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:600](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L600)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeType`](#encodetype-11)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:594](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L594)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`string`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`encodeValue`](#encodevalue-11)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:616](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L616)

###### Parameters

###### x

`string`

###### Returns

`string`

###### Overrides

[`PrimitiveType`](#abstract-primitivetype).[`valueToString`](#valuetostring-11)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is TextClass`

Defined in: [packages/core/src/candid/idl.ts:579](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L579)

###### Parameters

###### instance

`any`

###### Returns

`instance is TextClass`

***

### TupleClass

Defined in: [packages/core/src/candid/idl.ts:1423](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1423)

Represents Tuple, a syntactic sugar for Record.

#### Param

#### Extends

- [`RecordClass`](#recordclass)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Constructors

##### Constructor

> **new TupleClass**\<`T`\>(`_components`): [`TupleClass`](#tupleclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1434](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1434)

###### Parameters

###### \_components

[`Type`](#abstract-type)\<`any`\>[]

###### Returns

[`TupleClass`](#tupleclass)\<`T`\>

###### Overrides

[`RecordClass`](#recordclass).[`constructor`](#constructor-15)

#### Properties

##### \_components

> `protected` `readonly` **\_components**: [`Type`](#abstract-type)\<`any`\>[]

Defined in: [packages/core/src/candid/idl.ts:1432](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1432)

##### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/idl.ts:1269](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1269)

###### Inherited from

[`RecordClass`](#recordclass).[`_fields`](#_fields)

#### Accessors

##### fieldsAsObject

###### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](#abstract-type)\>

Defined in: [packages/core/src/candid/idl.ts:1394](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1394)

###### Returns

`Record`\<`number`, [`Type`](#abstract-type)\>

###### Inherited from

[`RecordClass`](#recordclass).[`fieldsAsObject`](#fieldsasobject)

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1402](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1402)

###### Returns

`string`

###### Inherited from

[`RecordClass`](#recordclass).[`name`](#name-15)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1424](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1424)

###### Returns

`IdlTypeName`

###### Overrides

[`RecordClass`](#recordclass).[`typeName`](#typename-14)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1321](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1321)

###### Parameters

###### T

`TypeTable`

###### Returns

`void`

###### Inherited from

[`RecordClass`](#recordclass).[`_buildTypeTableImpl`](#_buildtypetableimpl-14)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1441](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1441)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`RecordClass`](#recordclass).[`accept`](#accept-14)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`RecordClass`](#recordclass).[`buildTypeTable`](#buildtypetable-14)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

###### Inherited from

[`RecordClass`](#recordclass).[`checkType`](#checktype-14)

##### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:1445](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1445)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

###### Overrides

[`RecordClass`](#recordclass).[`covariant`](#covariant-14)

##### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:1472](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1472)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

###### Overrides

[`RecordClass`](#recordclass).[`decodeValue`](#decodevalue-14)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1494](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1494)

###### Returns

`string`

###### Overrides

[`RecordClass`](#recordclass).[`display`](#display-14)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`RecordClass`](#recordclass).[`encodeType`](#encodetype-14)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1467](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1467)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`any`[]

###### Returns

`Uint8Array`

###### Overrides

[`RecordClass`](#recordclass).[`encodeValue`](#encodevalue-14)

##### tryAsTuple()

> **tryAsTuple**(): [`Type`](#abstract-type)\<`any`\>[] \| `null`

Defined in: [packages/core/src/candid/idl.ts:1280](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1280)

###### Returns

[`Type`](#abstract-type)\<`any`\>[] \| `null`

###### Inherited from

[`RecordClass`](#recordclass).[`tryAsTuple`](#tryastuple)

##### valueToString()

> **valueToString**(`values`): `string`

Defined in: [packages/core/src/candid/idl.ts:1499](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1499)

###### Parameters

###### values

`any`[]

###### Returns

`string`

###### Overrides

[`RecordClass`](#recordclass).[`valueToString`](#valuetostring-14)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is TupleClass<T>`

Defined in: [packages/core/src/candid/idl.ts:1428](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1428)

###### Type Parameters

###### T

`T` *extends* `any`[]

###### Parameters

###### instance

`any`

###### Returns

`instance is TupleClass<T>`

###### Overrides

[`RecordClass`](#recordclass).[`[hasInstance]`](#hasinstance-12)

***

### `abstract` Type

Defined in: [packages/core/src/candid/idl.ts:245](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L245)

Represents an IDL type.

#### Extended by

- [`PrimitiveType`](#abstract-primitivetype)
- [`ConstructType`](#abstract-constructtype)
- [`UnknownClass`](#unknownclass)

#### Type Parameters

##### T

`T` = `any`

#### Constructors

##### Constructor

> **new Type**\<`T`\>(): [`Type`](#abstract-type)\<`T`\>

###### Returns

[`Type`](#abstract-type)\<`T`\>

#### Properties

##### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L247)

##### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L246)

#### Methods

##### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:289](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L289)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

##### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:248](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L248)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

##### checkType()

> `abstract` **checkType**(`t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:285](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L285)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

##### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:270](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L270)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T`

##### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:287](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L287)

###### Parameters

###### x

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

##### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:283](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L283)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`

##### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:277](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L277)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`

###### Returns

`Uint8Array`

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L255)

###### Parameters

###### x

`T`

###### Returns

`string`

***

### UnknownClass

Defined in: [packages/core/src/candid/idl.ts:371](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L371)

Represents an IDL Unknown, a placeholder type for deserialization only.
When decoding a value as Unknown, all fields will be retained but the names are only available in
hashed form.
A deserialized unknown will offer it's actual type by calling the `type()` function.
Unknown cannot be serialized and attempting to do so will throw an error.

#### Extends

- [`Type`](#abstract-type)

#### Constructors

##### Constructor

> **new UnknownClass**(): [`UnknownClass`](#unknownclass)

###### Returns

[`UnknownClass`](#unknownclass)

###### Inherited from

[`Type`](#abstract-type).[`constructor`](#constructor-20)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:437](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L437)

###### Returns

`string`

###### Overrides

[`Type`](#abstract-type).[`name`](#name-20)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:372](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L372)

###### Returns

`IdlTypeName`

###### Overrides

[`Type`](#abstract-type).[`typeName`](#typename-20)

#### Methods

##### \_buildTypeTableImpl()

> `protected` **\_buildTypeTableImpl**(): `void`

Defined in: [packages/core/src/candid/idl.ts:433](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L433)

###### Returns

`void`

###### Overrides

[`Type`](#abstract-type).[`_buildTypeTableImpl`](#_buildtypetableimpl-19)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:384](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L384)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`Type`](#abstract-type).[`accept`](#accept-19)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`Type`](#abstract-type).[`buildTypeTable`](#buildtypetable-19)

##### checkType()

> **checkType**(`_t`): [`Type`](#abstract-type)

Defined in: [packages/core/src/candid/idl.ts:380](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L380)

###### Parameters

###### \_t

[`Type`](#abstract-type)

###### Returns

[`Type`](#abstract-type)

###### Overrides

[`Type`](#abstract-type).[`checkType`](#checktype-19)

##### covariant()

> **covariant**(`x`): `x is any`

Defined in: [packages/core/src/candid/idl.ts:388](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L388)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is any`

###### Overrides

[`Type`](#abstract-type).[`covariant`](#covariant-19)

##### decodeValue()

> **decodeValue**(`b`, `t`): `any`

Defined in: [packages/core/src/candid/idl.ts:404](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L404)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`any`

###### Overrides

[`Type`](#abstract-type).[`decodeValue`](#decodevalue-19)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L251)

###### Returns

`string`

###### Inherited from

[`Type`](#abstract-type).[`display`](#display-19)

##### encodeType()

> **encodeType**(): `never`

Defined in: [packages/core/src/candid/idl.ts:400](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L400)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Returns

`never`

###### Overrides

[`Type`](#abstract-type).[`encodeType`](#encodetype-19)

##### encodeValue()

> **encodeValue**(): `never`

Defined in: [packages/core/src/candid/idl.ts:392](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L392)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Returns

`never`

###### Overrides

[`Type`](#abstract-type).[`encodeValue`](#encodevalue-19)

##### valueToString()

> **valueToString**(): `never`

Defined in: [packages/core/src/candid/idl.ts:396](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L396)

###### Returns

`never`

###### Overrides

[`Type`](#abstract-type).[`valueToString`](#valuetostring-19)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is UnknownClass`

Defined in: [packages/core/src/candid/idl.ts:376](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L376)

###### Parameters

###### instance

`any`

###### Returns

`instance is UnknownClass`

***

### VariantClass

Defined in: [packages/core/src/candid/idl.ts:1509](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1509)

Represents an IDL Variant

#### Param

mapping of function name to Type

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

#### Constructors

##### Constructor

> **new VariantClass**(`fields?`): [`VariantClass`](#variantclass)

Defined in: [packages/core/src/candid/idl.ts:1520](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1520)

###### Parameters

###### fields?

`Record`\<`string`, [`Type`](#abstract-type)\> = `{}`

###### Returns

[`VariantClass`](#variantclass)

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/idl.ts:1518](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1518)

#### Accessors

##### alternativesAsObject

###### Get Signature

> **get** **alternativesAsObject**(): `Record`\<`number`, [`Type`](#abstract-type)\>

Defined in: [packages/core/src/candid/idl.ts:1624](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1624)

###### Returns

`Record`\<`number`, [`Type`](#abstract-type)\>

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1598](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1598)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1510](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1510)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1564](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1564)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1525](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1525)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`Record`\<`string`, `any`\>\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is Record<string, any>`

Defined in: [packages/core/src/candid/idl.ts:1529](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1529)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is Record<string, any>`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `object`

Defined in: [packages/core/src/candid/idl.ts:1576](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1576)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`object`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1603](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1603)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:1550](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1550)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1610](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1610)

###### Parameters

###### x

`Record`\<`string`, `any`\>

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is VariantClass`

Defined in: [packages/core/src/candid/idl.ts:1514](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1514)

###### Parameters

###### instance

`any`

###### Returns

`instance is VariantClass`

***

### VecClass

Defined in: [packages/core/src/candid/idl.ts:911](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L911)

Represents an IDL Array

Arrays of fixed-sized nat/int type (e.g. nat8), are encoded from and decoded to TypedArrays (e.g. Uint8Array).
Arrays of float or other non-primitive types are encoded/decoded as untyped array in Javascript.

#### Param

#### Extends

- [`ConstructType`](#abstract-constructtype)\<`T`[]\>

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new VecClass**\<`T`\>(`_type`): [`VecClass`](#vecclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:928](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L928)

###### Parameters

###### \_type

[`Type`](#abstract-type)\<`T`\>

###### Returns

[`VecClass`](#vecclass)\<`T`\>

###### Overrides

[`ConstructType`](#abstract-constructtype).[`constructor`](#constructor-2)

#### Properties

##### \_type

> **\_type**: [`Type`](#abstract-type)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:928](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L928)

#### Accessors

##### name

###### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1102](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1102)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`name`](#name-2)

##### typeName

###### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:912](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L912)

###### Returns

`IdlTypeName`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`typeName`](#typename-1)

#### Methods

##### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:1021](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1021)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`_buildTypeTableImpl`](#_buildtypetableimpl-1)

##### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:935](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L935)

###### Type Parameters

###### D

`D`

###### R

`R`

###### Parameters

###### v

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### d

`D`

###### Returns

`R`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`accept`](#accept-1)

##### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L260)

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`void`

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`buildTypeTable`](#buildtypetable-1)

##### checkType()

> **checkType**(`t`): [`ConstructType`](#abstract-constructtype)\<`T`[]\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L306)

###### Parameters

###### t

[`Type`](#abstract-type)

###### Returns

[`ConstructType`](#abstract-constructtype)\<`T`[]\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`checkType`](#checktype-1)

##### covariant()

> **covariant**(`x`): `x is T[]`

Defined in: [packages/core/src/candid/idl.ts:939](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L939)

Assert that JavaScript's `x` is the proper type represented by this
Type.

###### Parameters

###### x

`any`

###### Returns

`x is T[]`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`covariant`](#covariant-1)

##### decodeValue()

> **decodeValue**(`b`, `t`): `T`[]

Defined in: [packages/core/src/candid/idl.ts:1029](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1029)

###### Parameters

###### b

[`PipeArrayBuffer`](../index.md#pipearraybuffer)

###### t

[`Type`](#abstract-type)

###### Returns

`T`[]

###### Overrides

[`ConstructType`](#abstract-constructtype).[`decodeValue`](#decodevalue-1)

##### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1106](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1106)

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`display`](#display-1)

##### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

###### Parameters

###### typeTable

`TypeTable`

###### Returns

`Uint8Array`\<`ArrayBufferLike`\>

###### Inherited from

[`ConstructType`](#abstract-constructtype).[`encodeType`](#encodetype-1)

##### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:968](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L968)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

###### Parameters

###### x

`T`[]

###### Returns

`Uint8Array`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`encodeValue`](#encodevalue-1)

##### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:1110](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1110)

###### Parameters

###### x

`T`[]

###### Returns

`string`

###### Overrides

[`ConstructType`](#abstract-constructtype).[`valueToString`](#valuetostring-1)

##### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is VecClass<T>`

Defined in: [packages/core/src/candid/idl.ts:916](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L916)

###### Type Parameters

###### T

`T`

###### Parameters

###### instance

`any`

###### Returns

`instance is VecClass<T>`

***

### `abstract` Visitor

Defined in: [packages/core/src/candid/idl.ts:144](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L144)

#### Extended by

- [`Render`](../index.md#render-4)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Constructors

##### Constructor

> **new Visitor**\<`D`, `R`\>(): [`Visitor`](#abstract-visitor)\<`D`, `R`\>

###### Returns

[`Visitor`](#abstract-visitor)\<`D`, `R`\>

#### Methods

##### visitBool()

> **visitBool**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:154](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L154)

###### Parameters

###### t

[`BoolClass`](#boolclass)

###### data

`D`

###### Returns

`R`

##### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:188](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L188)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitEmpty()

> **visitEmpty**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:151](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L151)

###### Parameters

###### t

[`EmptyClass`](#emptyclass)

###### data

`D`

###### Returns

`R`

##### visitFixedInt()

> **visitFixedInt**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:178](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L178)

###### Parameters

###### t

[`FixedIntClass`](#fixedintclass)

###### data

`D`

###### Returns

`R`

##### visitFixedNat()

> **visitFixedNat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:181](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L181)

###### Parameters

###### t

[`FixedNatClass`](#fixednatclass)

###### data

`D`

###### Returns

`R`

##### visitFloat()

> **visitFloat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:175](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L175)

###### Parameters

###### t

[`FloatClass`](#floatclass)

###### data

`D`

###### Returns

`R`

##### visitFunc()

> **visitFunc**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:210](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L210)

###### Parameters

###### t

[`FuncClass`](#funcclass)

###### data

`D`

###### Returns

`R`

##### visitInt()

> **visitInt**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:169](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L169)

###### Parameters

###### t

[`IntClass`](#intclass)

###### data

`D`

###### Returns

`R`

##### visitNat()

> **visitNat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:172](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L172)

###### Parameters

###### t

[`NatClass`](#natclass)

###### data

`D`

###### Returns

`R`

##### visitNull()

> **visitNull**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:157](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L157)

###### Parameters

###### t

[`NullClass`](#nullclass)

###### data

`D`

###### Returns

`R`

##### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:166](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L166)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitOpt()

> **visitOpt**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:194](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L194)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`OptClass`](#optclass)\<`T`\>

###### \_ty

[`Type`](#abstract-type)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:148](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L148)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`PrimitiveType`](#abstract-primitivetype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitPrincipal()

> **visitPrincipal**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:184](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L184)

###### Parameters

###### t

[`PrincipalClass`](#principalclass)

###### data

`D`

###### Returns

`R`

##### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:207](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L207)

###### Type Parameters

###### T

`T`

###### Parameters

###### \_t

[`RecClass`](#recclass)\<`T`\>

###### ty

[`ConstructType`](#abstract-constructtype)\<`T`\>

###### data

`D`

###### Returns

`R`

##### visitRecord()

> **visitRecord**(`t`, `_fields`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:197](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L197)

###### Parameters

###### t

[`RecordClass`](#recordclass)

###### \_fields

\[`string`, [`Type`](#abstract-type)\<`any`\>\][]

###### data

`D`

###### Returns

`R`

##### visitReserved()

> **visitReserved**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:160](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L160)

###### Parameters

###### t

[`ReservedClass`](#reservedclass)

###### data

`D`

###### Returns

`R`

##### visitService()

> **visitService**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:213](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L213)

###### Parameters

###### t

[`ServiceClass`](#serviceclass)

###### data

`D`

###### Returns

`R`

##### visitText()

> **visitText**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:163](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L163)

###### Parameters

###### t

[`TextClass`](#textclass)

###### data

`D`

###### Returns

`R`

##### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:200](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L200)

###### Type Parameters

###### T

`T` *extends* `any`[]

###### Parameters

###### t

[`TupleClass`](#tupleclass)\<`T`\>

###### components

[`Type`](#abstract-type)\<`any`\>[]

###### data

`D`

###### Returns

`R`

##### visitType()

> **visitType**\<`T`\>(`_t`, `_data`): `R`

Defined in: [packages/core/src/candid/idl.ts:145](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L145)

###### Type Parameters

###### T

`T`

###### Parameters

###### \_t

[`Type`](#abstract-type)\<`T`\>

###### \_data

`D`

###### Returns

`R`

##### visitVariant()

> **visitVariant**(`t`, `_fields`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:204](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L204)

###### Parameters

###### t

[`VariantClass`](#variantclass)

###### \_fields

\[`string`, [`Type`](#abstract-type)\<`any`\>\][]

###### data

`D`

###### Returns

`R`

##### visitVec()

> **visitVec**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:191](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L191)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`VecClass`](#vecclass)\<`T`\>

###### \_ty

[`Type`](#abstract-type)\<`T`\>

###### data

`D`

###### Returns

`R`

## Type Aliases

### GenericIdlFuncArgs

> **GenericIdlFuncArgs** = \[[`Type`](#abstract-type), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1772](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1772)

The generic type of the arguments of an [IDL Function](#func).

***

### GenericIdlFuncRets

> **GenericIdlFuncRets** = \[[`Type`](#abstract-type), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1777](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1777)

The generic type of the return values of an [IDL Function](#func).

***

### GenericIdlServiceFields

> **GenericIdlServiceFields** = `Record`\<`string`, [`FuncClass`](#funcclass)\>

Defined in: [packages/core/src/candid/idl.ts:1909](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L1909)

The generic type of the fields of an [IDL Service](#service).

***

### InterfaceFactory

> **InterfaceFactory** = (`idl`) => [`ServiceClass`](#serviceclass)

Defined in: [packages/core/src/candid/idl.ts:2307](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2307)

An Interface Factory, normally provided by a Candid code generation.

#### Parameters

##### idl

###### IDL

\{ `Bool`: [`BoolClass`](#boolclass); `Empty`: [`EmptyClass`](#emptyclass); `Float32`: [`FloatClass`](#floatclass); `Float64`: [`FloatClass`](#floatclass); `Func`: *typeof* [`Func`](#func); `Int`: [`IntClass`](#intclass); `Int16`: [`FixedIntClass`](#fixedintclass); `Int32`: [`FixedIntClass`](#fixedintclass); `Int64`: [`FixedIntClass`](#fixedintclass); `Int8`: [`FixedIntClass`](#fixedintclass); `Nat`: [`NatClass`](#natclass); `Nat16`: [`FixedNatClass`](#fixednatclass); `Nat32`: [`FixedNatClass`](#fixednatclass); `Nat64`: [`FixedNatClass`](#fixednatclass); `Nat8`: [`FixedNatClass`](#fixednatclass); `Null`: [`NullClass`](#nullclass); `Opt`: *typeof* [`Opt`](#opt); `Principal`: [`PrincipalClass`](#principalclass); `Rec`: *typeof* [`Rec`](#rec); `Record`: *typeof* [`Record`](#record); `Reserved`: [`ReservedClass`](#reservedclass); `Text`: [`TextClass`](#textclass); `Tuple`: *typeof* [`Tuple`](#tuple); `Unknown`: [`UnknownClass`](#unknownclass); `Variant`: *typeof* [`Variant`](#variant); `Vec`: *typeof* [`Vec`](#vec); `Service`: [`ServiceClass`](#serviceclass); \}

###### IDL.Bool

[`BoolClass`](#boolclass)

###### IDL.Empty

[`EmptyClass`](#emptyclass)

###### IDL.Float32

[`FloatClass`](#floatclass)

###### IDL.Float64

[`FloatClass`](#floatclass)

###### IDL.Func

*typeof* [`Func`](#func)

###### IDL.Int

[`IntClass`](#intclass)

###### IDL.Int16

[`FixedIntClass`](#fixedintclass)

###### IDL.Int32

[`FixedIntClass`](#fixedintclass)

###### IDL.Int64

[`FixedIntClass`](#fixedintclass)

###### IDL.Int8

[`FixedIntClass`](#fixedintclass)

###### IDL.Nat

[`NatClass`](#natclass)

###### IDL.Nat16

[`FixedNatClass`](#fixednatclass)

###### IDL.Nat32

[`FixedNatClass`](#fixednatclass)

###### IDL.Nat64

[`FixedNatClass`](#fixednatclass)

###### IDL.Nat8

[`FixedNatClass`](#fixednatclass)

###### IDL.Null

[`NullClass`](#nullclass)

###### IDL.Opt

*typeof* [`Opt`](#opt)

###### IDL.Principal

[`PrincipalClass`](#principalclass)

###### IDL.Rec

*typeof* [`Rec`](#rec)

###### IDL.Record

*typeof* [`Record`](#record)

###### IDL.Reserved

[`ReservedClass`](#reservedclass)

###### IDL.Text

[`TextClass`](#textclass)

###### IDL.Tuple

*typeof* [`Tuple`](#tuple)

###### IDL.Unknown

[`UnknownClass`](#unknownclass)

###### IDL.Variant

*typeof* [`Variant`](#variant)

###### IDL.Vec

*typeof* [`Vec`](#vec)

###### IDL.Service

#### Returns

[`ServiceClass`](#serviceclass)

## Variables

### Bool

> `const` **Bool**: [`BoolClass`](#boolclass)

Defined in: [packages/core/src/candid/idl.ts:2352](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2352)

***

### Empty

> `const` **Empty**: [`EmptyClass`](#emptyclass)

Defined in: [packages/core/src/candid/idl.ts:2346](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2346)

***

### Float32

> `const` **Float32**: [`FloatClass`](#floatclass)

Defined in: [packages/core/src/candid/idl.ts:2358](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2358)

***

### Float64

> `const` **Float64**: [`FloatClass`](#floatclass)

Defined in: [packages/core/src/candid/idl.ts:2359](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2359)

***

### Int

> `const` **Int**: [`IntClass`](#intclass)

Defined in: [packages/core/src/candid/idl.ts:2355](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2355)

***

### Int16

> `const` **Int16**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2362](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2362)

***

### Int32

> `const` **Int32**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2363](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2363)

***

### Int64

> `const` **Int64**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2364](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2364)

***

### Int8

> `const` **Int8**: [`FixedIntClass`](#fixedintclass)

Defined in: [packages/core/src/candid/idl.ts:2361](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2361)

***

### Nat

> `const` **Nat**: [`NatClass`](#natclass)

Defined in: [packages/core/src/candid/idl.ts:2356](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2356)

***

### Nat16

> `const` **Nat16**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2367](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2367)

***

### Nat32

> `const` **Nat32**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2368](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2368)

***

### Nat64

> `const` **Nat64**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2369](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2369)

***

### Nat8

> `const` **Nat8**: [`FixedNatClass`](#fixednatclass)

Defined in: [packages/core/src/candid/idl.ts:2366](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2366)

***

### Null

> `const` **Null**: [`NullClass`](#nullclass)

Defined in: [packages/core/src/candid/idl.ts:2353](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2353)

***

### Principal

> `const` **Principal**: [`PrincipalClass`](#principalclass)

Defined in: [packages/core/src/candid/idl.ts:2371](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2371)

***

### Reserved

> `const` **Reserved**: [`ReservedClass`](#reservedclass)

Defined in: [packages/core/src/candid/idl.ts:2347](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2347)

***

### Text

> `const` **Text**: [`TextClass`](#textclass)

Defined in: [packages/core/src/candid/idl.ts:2354](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2354)

***

### Unknown

> `const` **Unknown**: [`UnknownClass`](#unknownclass)

Defined in: [packages/core/src/candid/idl.ts:2351](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2351)

Client-only type for deserializing unknown data. Not supported by Candid, and its use is discouraged.

## Functions

### decode()

> **decode**(`retTypes`, `bytes`): [`JsonValue`](../index.md#jsonvalue)[]

Defined in: [packages/core/src/candid/idl.ts:2046](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2046)

Decode a binary value

#### Parameters

##### retTypes

[`Type`](#abstract-type)\<`any`\>[]

Types expected in the buffer.

##### bytes

`Uint8Array`

hex-encoded string, or buffer.

#### Returns

[`JsonValue`](../index.md#jsonvalue)[]

Value deserialised to JS type

***

### encode()

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:2013](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2013)

Encode a array of values

#### Parameters

##### argTypes

[`Type`](#abstract-type)\<`any`\>[]

array of Types

##### args

`any`[]

array of values

#### Returns

`Uint8Array`

serialised value

***

### Func()

> **Func**\<`Args`, `Ret`\>(`args`, `ret`, `annotations?`): [`FuncClass`](#funcclass)\<`Args`, `Ret`\>

Defined in: [packages/core/src/candid/idl.ts:2429](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2429)

#### Type Parameters

##### Args

`Args` *extends* [`GenericIdlFuncArgs`](#genericidlfuncargs) = [`GenericIdlFuncArgs`](#genericidlfuncargs)

##### Ret

`Ret` *extends* [`GenericIdlFuncRets`](#genericidlfuncrets) = [`GenericIdlFuncRets`](#genericidlfuncrets)

#### Parameters

##### args

`Args`

array of IDL Types

##### ret

`Ret`

array of IDL Types

##### annotations?

`string`[] = `[]`

array of strings, [] by default

#### Returns

[`FuncClass`](#funcclass)\<`Args`, `Ret`\>

new FuncClass

***

### Opt()

> **Opt**\<`T`\>(`t`): [`OptClass`](#optclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2394](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2394)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`Type`](#abstract-type)\<`T`\>

IDL Type

#### Returns

[`OptClass`](#optclass)\<`T`\>

OptClass of Type

***

### Rec()

> **Rec**(): [`RecClass`](#recclass)

Defined in: [packages/core/src/candid/idl.ts:2418](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2418)

#### Returns

[`RecClass`](#recclass)

new RecClass

***

### Record()

> **Record**(`t`): [`RecordClass`](#recordclass)

Defined in: [packages/core/src/candid/idl.ts:2402](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2402)

#### Parameters

##### t

`Record`\<`string`, [`Type`](#abstract-type)\>

Record of string and IDL Type

#### Returns

[`RecordClass`](#recordclass)

RecordClass of string and Type

***

### resetSubtypeCache()

> **resetSubtypeCache**(): `void`

Defined in: [packages/core/src/candid/idl.ts:2508](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2508)

Resets the global subtyping cache

#### Returns

`void`

***

### Service()

> **Service**\<`K`, `Fields`\>(`t`): [`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

Defined in: [packages/core/src/candid/idl.ts:2441](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2441)

#### Type Parameters

##### K

`K` *extends* `string` = `string`

##### Fields

`Fields` *extends* [`GenericIdlServiceFields`](#genericidlservicefields) = [`GenericIdlServiceFields`](#genericidlservicefields)

#### Parameters

##### t

`Fields`

Record of string and FuncClass

#### Returns

[`ServiceClass`](#serviceclass)\<`K`, `Fields`\>

ServiceClass

***

### subtype()

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/core/src/candid/idl.ts:2535](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2535)

Subtyping on Candid types t1 <: t2 (Exported for testing)

#### Parameters

##### t1

[`Type`](#abstract-type)

The potential subtype

##### t2

[`Type`](#abstract-type)

The potential supertype

#### Returns

`boolean`

***

### Tuple()

> **Tuple**\<`T`\>(...`types`): [`TupleClass`](#tupleclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2378](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2378)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### types

...`T`

array of any types

#### Returns

[`TupleClass`](#tupleclass)\<`T`\>

TupleClass from those types

***

### Variant()

> **Variant**(`fields`): [`VariantClass`](#variantclass)

Defined in: [packages/core/src/candid/idl.ts:2411](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2411)

#### Parameters

##### fields

`Record`\<`string`, [`Type`](#abstract-type)\>

Record of string and IDL Type

#### Returns

[`VariantClass`](#variantclass)

VariantClass

***

### Vec()

> **Vec**\<`T`\>(`t`): [`VecClass`](#vecclass)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2386](https://github.com/dfinity/icp-js-core/blob/f5fe3d6a625cd1f9b8a8c8da10ba99bfbc362f19/packages/core/src/candid/idl.ts#L2386)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`Type`](#abstract-type)\<`T`\>

IDL Type

#### Returns

[`VecClass`](#vecclass)\<`T`\>

VecClass from that type
