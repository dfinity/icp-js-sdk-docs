---
title: Overview
editUrl: false
next: true
prev: true
---


- [Secp256k1KeyIdentity](classes/Secp256k1KeyIdentity.md)
- [Secp256k1PublicKey](classes/Secp256k1PublicKey.md)

## Type Aliases

- [JsonableSecp256k1Identity](type-aliases/JsonableSecp256k1Identity.md)
