---
title: JsonableSecp256k1Identity
editUrl: false
next: true
prev: true
---

> **JsonableSecp256k1Identity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [identity-secp256k1/src/secp256k1.ts:19](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/identity-secp256k1/src/secp256k1.ts#L19)
