---
title: JsonableSecp256k1Identity
editUrl: false
next: true
prev: true
---

> **JsonableSecp256k1Identity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [identity-secp256k1/src/secp256k1.ts:19](https://github.com/dfinity/icp-js-core/blob/93cea11942ffda7e33227525699a94da9145b627/packages/identity-secp256k1/src/secp256k1.ts#L19)
