---
title: Secp256k1PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [identity-secp256k1/src/secp256k1.ts:27](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L27)

A Public Key implementation.

## Implements

- [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [identity-secp256k1/src/secp256k1.ts:83](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L83)

##### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`derKey`](../../../agent/api/interfaces/PublicKey.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [identity-secp256k1/src/secp256k1.ts:77](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L77)

##### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`rawKey`](../../../agent/api/interfaces/PublicKey.md#rawkey)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [identity-secp256k1/src/secp256k1.ts:93](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L93)

#### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`toDer`](../../../agent/api/interfaces/PublicKey.md#toder)

***

### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [identity-secp256k1/src/secp256k1.ts:97](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L97)

#### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`toRaw`](../../../agent/api/interfaces/PublicKey.md#toraw)

***

### from()

> `static` **from**(`maybeKey`): `Secp256k1PublicKey`

Defined in: [identity-secp256k1/src/secp256k1.ts:41](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L41)

Construct Secp256k1PublicKey from an existing PublicKey

#### Parameters

##### maybeKey

`unknown`

existing PublicKey, ArrayBuffer, DerEncodedPublicKey, or hex string

#### Returns

`Secp256k1PublicKey`

Instance of Secp256k1PublicKey

***

### fromDer()

> `static` **fromDer**(`derKey`): `Secp256k1PublicKey`

Defined in: [identity-secp256k1/src/secp256k1.ts:32](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L32)

#### Parameters

##### derKey

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Returns

`Secp256k1PublicKey`

***

### fromRaw()

> `static` **fromRaw**(`rawKey`): `Secp256k1PublicKey`

Defined in: [identity-secp256k1/src/secp256k1.ts:28](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/identity-secp256k1/src/secp256k1.ts#L28)

#### Parameters

##### rawKey

`Uint8Array`

#### Returns

`Secp256k1PublicKey`
