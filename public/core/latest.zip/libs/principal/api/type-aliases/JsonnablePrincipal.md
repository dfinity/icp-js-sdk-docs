---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

> **JsonnablePrincipal** = `object`

Defined in: [principal.ts:12](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/principal/src/principal.ts#L12)


### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [principal.ts:13](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/principal/src/principal.ts#L13)
