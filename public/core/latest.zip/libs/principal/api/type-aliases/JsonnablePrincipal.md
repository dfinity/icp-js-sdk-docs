---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

> **JsonnablePrincipal** = `object`

Defined in: [principal.ts:12](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/principal/src/principal.ts#L12)


### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [principal.ts:13](https://github.com/dfinity/icp-js-core/blob/a6aa6e2eb58cf2cbae92156b957293e40f458323/packages/principal/src/principal.ts#L13)
