---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

> **JsonnablePrincipal** = `object`

Defined in: [packages/core/src/principal/principal.ts:12](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/principal/principal.ts#L12)

## Properties

### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [packages/core/src/principal/principal.ts:13](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/principal/principal.ts#L13)
