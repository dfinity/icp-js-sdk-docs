---
title: Overview
editUrl: false
next: true
prev: true
---


- [Principal](classes/Principal.md)

## Type Aliases

- [JsonnablePrincipal](type-aliases/JsonnablePrincipal.md)

## Variables

- [JSON\_KEY\_PRINCIPAL](variables/JSON_KEY_PRINCIPAL.md)

## Functions

- [getCrc32](functions/getCrc32.md)
