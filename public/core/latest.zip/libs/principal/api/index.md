---
title: Overview
editUrl: false
next: true
prev: true
---

## Classes

- [Principal](classes/Principal.md)

## Interfaces

- [JsonnablePrincipal](interfaces/JsonnablePrincipal.md)

## Variables

- [JSON\_KEY\_PRINCIPAL](variables/JSON_KEY_PRINCIPAL.md)

## Functions

- [base32Decode](functions/base32Decode.md)
- [base32Encode](functions/base32Encode.md)
- [getCrc32](functions/getCrc32.md)
