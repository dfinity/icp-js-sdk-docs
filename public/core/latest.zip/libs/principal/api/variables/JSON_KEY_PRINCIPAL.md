---
title: JSON_KEY_PRINCIPAL
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_PRINCIPAL**: `"__principal__"` = `'__principal__'`

Defined in: [principal.ts:6](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/principal/src/principal.ts#L6)
