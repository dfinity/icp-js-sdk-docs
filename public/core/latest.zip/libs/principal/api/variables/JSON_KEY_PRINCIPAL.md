---
title: JSON_KEY_PRINCIPAL
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_PRINCIPAL**: `"__principal__"` = `'__principal__'`

Defined in: [principal.ts:6](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/principal/src/principal.ts#L6)
