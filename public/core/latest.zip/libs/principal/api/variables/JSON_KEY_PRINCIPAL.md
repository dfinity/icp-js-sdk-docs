---
title: JSON_KEY_PRINCIPAL
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_PRINCIPAL**: `"__principal__"` = `'__principal__'`

Defined in: [principal.ts:6](https://github.com/dfinity/icp-js-core/blob/f273c08b2806a6cf707317b880d59b309c48e44e/packages/principal/src/principal.ts#L6)
