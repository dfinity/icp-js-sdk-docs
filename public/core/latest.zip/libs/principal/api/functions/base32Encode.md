---
title: base32Encode
editUrl: false
next: true
prev: true
---

> **base32Encode**(`input`): `string`

Defined in: [utils/base32.ts:17](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/principal/src/utils/base32.ts#L17)


### input

`Uint8Array`

The Uint8Array to encode.

## Returns

`string`

A Base32 string encoding the input.
