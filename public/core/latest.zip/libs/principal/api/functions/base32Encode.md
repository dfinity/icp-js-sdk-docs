---
title: base32Encode
editUrl: false
next: true
prev: true
---

> **base32Encode**(`input`): `string`

Defined in: [utils/base32.ts:17](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/principal/src/utils/base32.ts#L17)

## Parameters

### input

`Uint8Array`

The Uint8Array to encode.

## Returns

`string`

A Base32 string encoding the input.
