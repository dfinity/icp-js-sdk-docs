---
title: base32Encode
editUrl: false
next: true
prev: true
---

> **base32Encode**(`input`): `string`

Defined in: [utils/base32.ts:17](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/principal/src/utils/base32.ts#L17)

## Parameters

### input

`Uint8Array`

The Uint8Array to encode.

## Returns

`string`

A Base32 string encoding the input.
