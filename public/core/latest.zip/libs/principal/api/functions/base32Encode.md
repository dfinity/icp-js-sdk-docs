---
title: base32Encode
editUrl: false
next: true
prev: true
---

> **base32Encode**(`input`): `string`

Defined in: [packages/core/src/principal/utils/base32.ts:17](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/principal/utils/base32.ts#L17)

## Parameters

### input

`Uint8Array`

The Uint8Array to encode.

## Returns

`string`

A Base32 string encoding the input.
