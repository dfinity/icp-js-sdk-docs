---
title: base32Decode
editUrl: false
next: true
prev: true
---

> **base32Decode**(`input`): `Uint8Array`

Defined in: [utils/base32.ts:60](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/principal/src/utils/base32.ts#L60)

## Parameters

### input

`string`

The base32 encoded string to decode.

## Returns

`Uint8Array`
