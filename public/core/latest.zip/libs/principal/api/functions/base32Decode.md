---
title: base32Decode
editUrl: false
next: true
prev: true
---

> **base32Decode**(`input`): `Uint8Array`

Defined in: [utils/base32.ts:60](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/principal/src/utils/base32.ts#L60)

## Parameters

### input

`string`

The base32 encoded string to decode.

## Returns

`Uint8Array`
