---
title: base32Decode
editUrl: false
next: true
prev: true
---

> **base32Decode**(`input`): `Uint8Array`

Defined in: [utils/base32.ts:60](https://github.com/dfinity/icp-js-core/blob/59c689c4162461102c5a38fe2a68c42ba645258d/packages/principal/src/utils/base32.ts#L60)


### input

`string`

The base32 encoded string to decode.

## Returns

`Uint8Array`
