---
title: base32Decode
editUrl: false
next: true
prev: true
---

> **base32Decode**(`input`): `Uint8Array`

Defined in: [utils/base32.ts:60](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/principal/src/utils/base32.ts#L60)

## Parameters

### input

`string`

The base32 encoded string to decode.

## Returns

`Uint8Array`
