---
title: getCrc32
editUrl: false
next: true
prev: true
---

> **getCrc32**(`buf`): `number`

Defined in: [utils/getCrc.ts:42](https://github.com/dfinity/icp-js-core/blob/85fc3cda10237b9c288f0a65e61f18717d480207/packages/principal/src/utils/getCrc.ts#L42)

Calculate the CRC32 of a Uint8Array.


### buf

`Uint8Array`

The Uint8Array to calculate the CRC32 of.

## Returns

`number`
