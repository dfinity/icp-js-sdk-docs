---
title: getCrc32
editUrl: false
next: true
prev: true
---

> **getCrc32**(`buf`): `number`

Defined in: [utils/getCrc.ts:42](https://github.com/dfinity/icp-js-core/blob/8c33d49d9a0962f804b2d018b5b01a338b0c90ce/packages/principal/src/utils/getCrc.ts#L42)

Calculate the CRC32 of a Uint8Array.


### buf

`Uint8Array`

The Uint8Array to calculate the CRC32 of.

## Returns

`number`
