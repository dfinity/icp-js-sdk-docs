---
title: getCrc32
editUrl: false
next: true
prev: true
---

> **getCrc32**(`buf`): `number`

Defined in: [utils/getCrc.ts:42](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/principal/src/utils/getCrc.ts#L42)

Calculate the CRC32 of a Uint8Array.

## Parameters

### buf

`Uint8Array`

The Uint8Array to calculate the CRC32 of.

## Returns

`number`
