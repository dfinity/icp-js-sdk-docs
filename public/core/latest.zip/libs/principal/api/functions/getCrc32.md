---
title: getCrc32
editUrl: false
next: true
prev: true
---

> **getCrc32**(`buf`): `number`

Defined in: [packages/core/src/principal/utils/getCrc.ts:42](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/principal/utils/getCrc.ts#L42)

Calculate the CRC32 of a Uint8Array.

## Parameters

### buf

`Uint8Array`

The Uint8Array to calculate the CRC32 of.

## Returns

`number`
