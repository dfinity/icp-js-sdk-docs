---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/principal/principal.ts:12](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/principal/principal.ts#L12)

## Properties

### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [packages/core/src/principal/principal.ts:13](https://github.com/dfinity/icp-js-core/blob/5c6e122197fc1553cd7a40323ad61c2bb76f110a/packages/core/src/principal/principal.ts#L13)
