---
title: Principal
editUrl: false
next: true
prev: true
---

JavaScript and TypeScript module to work with Internet Computer Principals.

## Usage

```ts
import { Principal } from '@icp-sdk/core/principal';

const canisterId = Principal.fromText('uqqxf-5h777-77774-qaaaa-cai');
const anonymousPrincipal = Principal.anonymous();
```
