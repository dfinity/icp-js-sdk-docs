---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

The CanisterStatus utility is used to request structured data directly from the IC public API. This data can be accessed using agent.readState, but CanisterStatus provides a helpful abstraction with some known paths.

You can request a canisters Controllers, ModuleHash, Candid interface, Subnet, or Time, or provide a custom path [CanisterStatus.CustomPath](#custompath) and pass arbitrary buffers for valid paths identified in https://internetcomputer.org/docs/current/references/ic-interface-spec.

The primary method for this namespace is [CanisterStatus.request](#request)

## Classes

### ~~CustomPath~~

Defined in: [packages/core/src/agent/utils/readState.ts:102](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/utils/readState.ts#L102)

A `read_state` path defined by the user, with a string [DecodeStrategy](#decodestrategy-1). Consumed by the
status utilities (e.g. `CanisterStatus.request`), which translate it into a [KnownPath](../index.md#knownpath)
before calling `Agent.readState`.

#### Param

the key to use to access the returned value in the status map

#### Param

the path to the desired value

#### Param

the strategy used to decode the returned value

#### Deprecated

Use [KnownPath](../index.md#knownpath) with `Agent.readState` instead.

#### Constructors

##### Constructor

> **new CustomPath**(`key`, `path`, `decodeStrategy`): [`CustomPath`](#custompath)

Defined in: [packages/core/src/agent/utils/readState.ts:106](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/utils/readState.ts#L106)

###### Parameters

###### key

`string`

###### path

`string` \| `Uint8Array`\<`ArrayBufferLike`\> \| `Uint8Array`\<`ArrayBufferLike`\>[]

###### decodeStrategy

[`DecodeStrategy`](#decodestrategy-1)

###### Returns

[`CustomPath`](#custompath)

#### Properties

##### ~~decodeStrategy~~

> **decodeStrategy**: [`DecodeStrategy`](#decodestrategy-1)

Defined in: [packages/core/src/agent/utils/readState.ts:105](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/utils/readState.ts#L105)

##### ~~key~~

> **key**: `string`

Defined in: [packages/core/src/agent/utils/readState.ts:103](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/utils/readState.ts#L103)

##### ~~path~~

> **path**: `string` \| `Uint8Array`\<`ArrayBufferLike`\> \| `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/core/src/agent/utils/readState.ts:104](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/utils/readState.ts#L104)

## Interfaces

### CanisterStatusOptions

Defined in: [packages/core/src/agent/canisterStatus/index.ts:75](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L75)

#### Properties

##### agent

> **agent**: [`HttpAgent`](../index.md#httpagent)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:83](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L83)

The agent to use to make the canister request. Must be authenticated.

##### canisterId

> **canisterId**: [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:79](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L79)

The effective canister ID to use in the underlying [HttpAgent.readState](../index.md#readstate-2) call.

##### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification?**: `boolean`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:93](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L93)

Whether to disable the certificate freshness checks.

###### Default

```ts
false
```

##### paths?

> `optional` **paths?**: `Set`\<[`Path`](#path-1)\> \| [`Path`](#path-1)[]

Defined in: [packages/core/src/agent/canisterStatus/index.ts:88](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L88)

The paths to request.

###### Default

```ts
[]
```

## Type Aliases

### DecodeStrategy

> **DecodeStrategy** = `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/core/src/agent/utils/readState.ts:61](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/utils/readState.ts#L61)

Decode strategy for a [CustomPath](#custompath). `'raw'` returns the looked-up bytes unchanged.

***

### Path

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`CustomPath`](#custompath)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:35](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L35)

Pre-configured fields for canister status paths

***

### Status

> **Status** = `BaseStatus` \| [`SubnetStatus`](#subnetstatus)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:30](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L30)

***

### StatusMap

> **StatusMap** = `Map`\<[`Path`](#path-1) \| `string`, [`Status`](#status)\>

Defined in: [packages/core/src/agent/canisterStatus/index.ts:37](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L37)

***

### SubnetStatus

> **SubnetStatus** = `BaseSubnetStatus`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:29](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L29)

## Functions

### fetchNodeKeys()

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): `BaseSubnetStatus`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:183](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L183)

Lookup node keys from a certificate for a given canister.
The certificate is assumed to be already verified, including whether the canister is in range of the subnet.

#### Parameters

##### certificate

`Uint8Array`

the certificate to lookup node keys from

##### canisterId

[`Principal`](../../../principal/api.md#principal)

the canister ID to lookup node keys for

##### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

the root key to use to lookup node keys

#### Returns

`BaseSubnetStatus`

a map of node IDs to public keys

***

### ~~request()~~

> **request**(`options`): `Promise`\<[`StatusMap`](#statusmap)\>

Defined in: [packages/core/src/agent/canisterStatus/index.ts:115](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/canisterStatus/index.ts#L115)

Requests information from a canister's `read_state` endpoint.
Can be used to request information about the canister's controllers, time, module hash, candid interface, and more.

> [!WARNING]
> Requesting the `subnet` path from the canister status might be deprecated in the future.
> Use [SubnetStatus.request](https://js.icp.build/core/latest/libs/agent/api/namespaces/subnetstatus/functions/request) to fetch subnet information instead.

#### Parameters

##### options

[`CanisterStatusOptions`](#canisterstatusoptions)

The configuration for the canister status request.

#### Returns

`Promise`\<[`StatusMap`](#statusmap)\>

A map populated with data from the requested paths. Each path is a key in the map, and the value is the data obtained from the certificate for that path.

#### Deprecated

Use [HttpAgent.readState](../index.md#readstate-2) directly with [StatePaths](../index.md#statepaths) instead. This function will be removed in a future release.

#### See

[CanisterStatusOptions](#canisterstatusoptions) for detailed options.

#### Example

```ts
const status = await canisterStatus({
  paths: ['controllers', 'candid'],
  ...options
});

const controllers = status.get('controllers');
```
