---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

The SubnetStatus utility is used to request structured data directly from the IC public API. This data can be accessed using agent.readSubnetState, but SubnetStatus provides a helpful abstraction with some known paths.

The primary method for this namespace is [SubnetStatus.request](#request)

## Interfaces

### SubnetStatusOptions

Defined in: [packages/core/src/agent/subnetStatus/index.ts:82](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L82)

#### Properties

##### agent

> **agent**: [`HttpAgent`](../index.md#httpagent)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:91](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L91)

The agent to use to make the subnet request.

##### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification?**: `boolean`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:101](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L101)

Whether to disable the certificate freshness checks.

###### Default

```ts
false
```

##### paths?

> `optional` **paths?**: `Set`\<[`Path`](#path)\> \| [`Path`](#path)[]

Defined in: [packages/core/src/agent/subnetStatus/index.ts:96](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L96)

The paths to request.

###### Default

```ts
[]
```

##### subnetId

> **subnetId**: [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:87](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L87)

The subnet ID to query. Use [IC\_ROOT\_SUBNET\_ID](#ic_root_subnet_id) for the IC mainnet root subnet.
You can use [HttpAgent.getSubnetIdFromCanister](../index.md#getsubnetidfromcanister) to get a subnet ID from a canister.

## Type Aliases

### Path

> **Path** = `"time"` \| `"canisterRanges"` \| `"publicKey"` \| `"nodeKeys"` \| [`CustomPath`](CanisterStatus.md#custompath)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:44](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L44)

Pre-configured fields for subnet status paths

***

### Status

> **Status** = `BaseStatus` \| `SubnetNodeKeys` \| [`CanisterRanges`](../index.md#canisterranges)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:39](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L39)

***

### StatusMap

> **StatusMap** = `Map`\<[`Path`](#path) \| `string`, [`Status`](#status)\>

Defined in: [packages/core/src/agent/subnetStatus/index.ts:46](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L46)

***

### SubnetStatus

> **SubnetStatus** = `BaseSubnetStatus` & `object`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:32](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L32)

#### Type Declaration

##### publicKey

> **publicKey**: `Uint8Array`

The public key of the subnet

## Variables

### IC\_ROOT\_SUBNET\_ID

> `const` **IC\_ROOT\_SUBNET\_ID**: [`Principal`](../../../principal/api.md#principal)

Defined in: [packages/core/src/agent/utils/readState.ts:28](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/utils/readState.ts#L28)

The root subnet ID for IC mainnet

## Functions

### ~~encodePath()~~

> **encodePath**(`path`, `subnetId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/core/src/agent/subnetStatus/index.ts:214](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L214)

Encode a path for subnet state queries

#### Parameters

##### path

[`Path`](#path)

the path to encode

##### subnetId

[`Principal`](../../../principal/api.md#principal)

the subnet ID

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>[]

the encoded path as an array of Uint8Arrays

#### Deprecated

Use [HttpAgent.readState](../index.md#readstate-2) directly with [StatePaths](../index.md#statepaths) instead

***

### lookupSubnetInfo()

> **lookupSubnetInfo**(`certificate`, `subnetId`): [`SubnetStatus`](#subnetstatus)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:182](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L182)

Fetch subnet info including node keys from a certificate

#### Parameters

##### certificate

`Uint8Array`

the certificate bytes

##### subnetId

[`Principal`](../../../principal/api.md#principal)

the subnet ID

#### Returns

[`SubnetStatus`](#subnetstatus)

SubnetStatus with subnet ID and node keys

***

### ~~request()~~

> **request**(`options`): `Promise`\<[`StatusMap`](#statusmap)\>

Defined in: [packages/core/src/agent/subnetStatus/index.ts:121](https://github.com/dfinity/icp-js-core/blob/cb5e25e4cf9132e8e4d15eaee23675815a0c385b/packages/core/src/agent/subnetStatus/index.ts#L121)

Requests information from a subnet's `read_state` endpoint.
Can be used to request information about the subnet's time, canister ranges, public key, node keys, and metrics.

#### Parameters

##### options

[`SubnetStatusOptions`](#subnetstatusoptions)

The configuration for the subnet status request.

#### Returns

`Promise`\<[`StatusMap`](#statusmap)\>

A map populated with data from the requested paths. Each path is a key in the map, and the value is the data obtained from the certificate for that path.

#### See

[SubnetStatusOptions](#subnetstatusoptions) for detailed options.

#### Deprecated

Use [HttpAgent.readState](../index.md#readstate-2) directly with [StatePaths](../index.md#statepaths) instead. This function will be removed in a future release.

#### Example

```ts
const status = await subnetStatus.request({
  subnetId: IC_ROOT_SUBNET_ID,
  paths: ['time', 'nodeKeys'],
  agent,
});

const time = status.get('time');
const nodeKeys = status.get('nodeKeys');
```

## References

### CustomPath

Re-exports [CustomPath](CanisterStatus.md#custompath)

***

### DecodeStrategy

Re-exports [DecodeStrategy](CanisterStatus.md#decodestrategy-1)
