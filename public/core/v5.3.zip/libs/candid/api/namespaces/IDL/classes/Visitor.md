---
title: Visitor
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/idl.ts:144](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L144)

## Extended by

- [`Render`](../../../classes/Render.md)

## Type Parameters

### D

`D`

### R

`R`

## Constructors

### Constructor

> **new Visitor**\<`D`, `R`\>(): `Visitor`\<`D`, `R`\>

#### Returns

`Visitor`\<`D`, `R`\>

## Methods

### visitBool()

> **visitBool**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:154](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L154)

#### Parameters

##### t

[`BoolClass`](BoolClass.md)

##### data

`D`

#### Returns

`R`

***

### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:188](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L188)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`ConstructType`](ConstructType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitEmpty()

> **visitEmpty**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:151](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L151)

#### Parameters

##### t

[`EmptyClass`](EmptyClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFixedInt()

> **visitFixedInt**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:178](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L178)

#### Parameters

##### t

[`FixedIntClass`](FixedIntClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFixedNat()

> **visitFixedNat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:181](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L181)

#### Parameters

##### t

[`FixedNatClass`](FixedNatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFloat()

> **visitFloat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:175](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L175)

#### Parameters

##### t

[`FloatClass`](FloatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitFunc()

> **visitFunc**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:210](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L210)

#### Parameters

##### t

[`FuncClass`](FuncClass.md)

##### data

`D`

#### Returns

`R`

***

### visitInt()

> **visitInt**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:169](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L169)

#### Parameters

##### t

[`IntClass`](IntClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNat()

> **visitNat**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:172](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L172)

#### Parameters

##### t

[`NatClass`](NatClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNull()

> **visitNull**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:157](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L157)

#### Parameters

##### t

[`NullClass`](NullClass.md)

##### data

`D`

#### Returns

`R`

***

### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:166](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L166)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](PrimitiveType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitOpt()

> **visitOpt**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:194](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L194)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`OptClass`](OptClass.md)\<`T`\>

##### \_ty

[`Type`](Type.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:148](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L148)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`PrimitiveType`](PrimitiveType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitPrincipal()

> **visitPrincipal**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:184](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L184)

#### Parameters

##### t

[`PrincipalClass`](PrincipalClass.md)

##### data

`D`

#### Returns

`R`

***

### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:207](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L207)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`RecClass`](RecClass.md)\<`T`\>

##### ty

[`ConstructType`](ConstructType.md)\<`T`\>

##### data

`D`

#### Returns

`R`

***

### visitRecord()

> **visitRecord**(`t`, `_fields`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:197](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L197)

#### Parameters

##### t

[`RecordClass`](RecordClass.md)

##### \_fields

\[`string`, [`Type`](Type.md)\<`any`\>\][]

##### data

`D`

#### Returns

`R`

***

### visitReserved()

> **visitReserved**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:160](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L160)

#### Parameters

##### t

[`ReservedClass`](ReservedClass.md)

##### data

`D`

#### Returns

`R`

***

### visitService()

> **visitService**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:213](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L213)

#### Parameters

##### t

[`ServiceClass`](ServiceClass.md)

##### data

`D`

#### Returns

`R`

***

### visitText()

> **visitText**(`t`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:163](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L163)

#### Parameters

##### t

[`TextClass`](TextClass.md)

##### data

`D`

#### Returns

`R`

***

### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:200](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L200)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### t

[`TupleClass`](TupleClass.md)\<`T`\>

##### components

[`Type`](Type.md)\<`any`\>[]

##### data

`D`

#### Returns

`R`

***

### visitType()

> **visitType**\<`T`\>(`_t`, `_data`): `R`

Defined in: [packages/core/src/candid/idl.ts:145](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L145)

#### Type Parameters

##### T

`T`

#### Parameters

##### \_t

[`Type`](Type.md)\<`T`\>

##### \_data

`D`

#### Returns

`R`

***

### visitVariant()

> **visitVariant**(`t`, `_fields`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:204](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L204)

#### Parameters

##### t

[`VariantClass`](VariantClass.md)

##### \_fields

\[`string`, [`Type`](Type.md)\<`any`\>\][]

##### data

`D`

#### Returns

`R`

***

### visitVec()

> **visitVec**\<`T`\>(`t`, `_ty`, `data`): `R`

Defined in: [packages/core/src/candid/idl.ts:191](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L191)

#### Type Parameters

##### T

`T`

#### Parameters

##### t

[`VecClass`](VecClass.md)\<`T`\>

##### \_ty

[`Type`](Type.md)\<`T`\>

##### data

`D`

#### Returns

`R`
