---
title: encode
editUrl: false
next: true
prev: true
---

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:2013](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L2013)

Encode a array of values

## Parameters

### argTypes

[`Type`](../classes/Type.md)\<`any`\>[]

array of Types

### args

`any`[]

array of values

## Returns

`Uint8Array`

serialised value
