---
title: Nat32
editUrl: false
next: true
prev: true
---

> `const` **Nat32**: [`FixedNatClass`](../classes/FixedNatClass.md)

Defined in: [packages/core/src/candid/idl.ts:2368](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L2368)
