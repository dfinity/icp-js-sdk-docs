---
title: resetSubtypeCache
editUrl: false
next: true
prev: true
---

> **resetSubtypeCache**(): `void`

Defined in: [packages/core/src/candid/idl.ts:2508](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L2508)

Resets the global subtyping cache

## Returns

`void`
