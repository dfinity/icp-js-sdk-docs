---
title: Bool
editUrl: false
next: true
prev: true
---

> `const` **Bool**: [`BoolClass`](../classes/BoolClass.md)

Defined in: [packages/core/src/candid/idl.ts:2352](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/idl.ts#L2352)
