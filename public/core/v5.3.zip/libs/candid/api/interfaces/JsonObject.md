---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/types.ts:5](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/types.ts#L5)

## Extends

- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

> \[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
