---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:153](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/utils/buffer.ts#L153)

Returns a true Uint8Array from an ArrayBufferLike object.

## Parameters

### bufLike

`ArrayBufferLike` \| `Uint8Array`\<`ArrayBufferLike`\> \| `number`[] \| `DataView`\<`ArrayBufferLike`\> \| `ArrayBufferView`\<`ArrayBufferLike`\> \| \[`number`\] \| \{ `buffer`: `ArrayBuffer`; \}

a buffer-like object

## Returns

`Uint8Array`

Uint8Array
