---
title: vecForm
editUrl: false
next: true
prev: true
---

> **vecForm**(`ty`, `config`): [`VecForm`](../classes/VecForm.md)

Defined in: [packages/core/src/candid/candid-ui.ts:27](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/candid-ui.ts#L27)

## Parameters

### ty

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VecForm`](../classes/VecForm.md)
