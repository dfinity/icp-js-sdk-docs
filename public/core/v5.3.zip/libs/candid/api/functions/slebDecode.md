---
title: slebDecode
editUrl: false
next: true
prev: true
---

> **slebDecode**(`pipe`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:134](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/utils/leb128.ts#L134)

Decode a leb encoded buffer into a bigint. The number is decoded with support for negative
signed-leb encoding.

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

A Buffer containing the signed leb encoded bits.

## Returns

`bigint`
