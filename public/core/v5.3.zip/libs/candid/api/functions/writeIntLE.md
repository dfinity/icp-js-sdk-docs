---
title: writeIntLE
editUrl: false
next: true
prev: true
---

> **writeIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:175](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/utils/leb128.ts#L175)

## Parameters

### value

`number` \| `bigint`

bigint or number

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
