---
title: recordForm
editUrl: false
next: true
prev: true
---

> **recordForm**(`fields`, `config`): [`RecordForm`](../classes/RecordForm.md)

Defined in: [packages/core/src/candid/candid-ui.ts:15](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/candid-ui.ts#L15)

## Parameters

### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`RecordForm`](../classes/RecordForm.md)
