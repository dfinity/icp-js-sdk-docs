---
title: slebEncode
editUrl: false
next: true
prev: true
---

> **slebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:93](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/candid/utils/leb128.ts#L93)

Encode a number (or bigint) into a Buffer, with support for negative numbers. The number
will be floored to the nearest integer.

## Parameters

### value

`number` \| `bigint`

The number to encode.

## Returns

`Uint8Array`
