---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| `SubnetNodeKeys` \| [`CanisterRanges`](../../../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:47](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/subnetStatus/index.ts#L47)
