---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"canisterRanges"` \| `"publicKey"` \| `"nodeKeys"` \| [`CustomPath`](../../CanisterStatus/classes/CustomPath.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:52](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/subnetStatus/index.ts#L52)

Pre-configured fields for subnet status paths
