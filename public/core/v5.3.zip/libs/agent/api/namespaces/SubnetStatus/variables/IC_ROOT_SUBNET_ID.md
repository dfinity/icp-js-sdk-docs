---
title: IC_ROOT_SUBNET_ID
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_SUBNET\_ID**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/utils/readState.ts:26](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/utils/readState.ts#L26)

The root subnet ID for IC mainnet
