---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`CustomPath`](../classes/CustomPath.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:38](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/canisterStatus/index.ts#L38)

Pre-configured fields for canister status paths
