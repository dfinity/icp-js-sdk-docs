---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| [`SubnetStatus`](SubnetStatus.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:33](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/canisterStatus/index.ts#L33)
