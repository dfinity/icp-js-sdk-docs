---
title: DecodeStrategy
editUrl: false
next: true
prev: true
---

> **DecodeStrategy** = `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/core/src/agent/utils/readState.ts:59](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/utils/readState.ts#L59)

Decode strategy for custom paths
