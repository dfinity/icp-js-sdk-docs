---
title: IC_REQUEST_AUTH_DELEGATION_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_AUTH\_DELEGATION\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:22](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/constants.ts#L22)

The `\x1Aic-request-auth-delegation` domain separator used in the signature of delegations.
