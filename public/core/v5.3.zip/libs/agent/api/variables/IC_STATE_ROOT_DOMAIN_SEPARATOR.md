---
title: IC_STATE_ROOT_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/constants.ts#L7)

The `\x0Dic-state-root` domain separator used in the root hash of IC certificates.
