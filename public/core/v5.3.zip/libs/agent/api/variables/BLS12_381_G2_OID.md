---
title: BLS12_381_G2_OID
editUrl: false
next: true
prev: true
---

> `const` **BLS12\_381\_G2\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:116](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/der.ts#L116)
