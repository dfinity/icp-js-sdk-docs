---
title: CheckCanisterRangesParams
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:876](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L876)

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/certificate.ts:877](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L877)

***

### subnetId

> **subnetId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/certificate.ts:878](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L878)

***

### tree

> **tree**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/core/src/agent/certificate.ts:879](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L879)
