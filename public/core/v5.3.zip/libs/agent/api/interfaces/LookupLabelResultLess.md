---
title: LookupLabelResultLess
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:596](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L596)

## Properties

### status

> **status**: [`Less`](../enumerations/LookupLabelStatus.md#less)

Defined in: [packages/core/src/agent/certificate.ts:597](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L597)
