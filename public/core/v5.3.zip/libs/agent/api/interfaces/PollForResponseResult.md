---
title: PollForResponseResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/polling/types.ts:21](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/polling/types.ts#L21)

The result of polling for a response, including the certificate, reply bytes, and raw certificate bytes.

## Extended by

- [`UpdateResult`](UpdateResult.md)

## Properties

### certificate

> **certificate**: [`Certificate`](../classes/Certificate.md)

Defined in: [packages/core/src/agent/polling/types.ts:23](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/polling/types.ts#L23)

The certificate for the request, which can be used to verify the reply.

***

### rawCertificate

> **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:27](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/polling/types.ts#L27)

The raw certificate bytes for the request.

***

### reply

> **reply**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:25](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/polling/types.ts#L25)

The reply bytes for the request.
