---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/expiry.ts:20](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/expiry.ts#L20)

## Properties

### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:21](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/expiry.ts#L21)
