---
title: QueryResponseRejected
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:72](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L72)

## Extends

- [`QueryResponseBase`](QueryResponseBase.md)

## Properties

### error\_code

> **error\_code**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:76](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L76)

***

### reject\_code

> **reject\_code**: [`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

Defined in: [packages/core/src/agent/agent/api.ts:74](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L74)

***

### reject\_message

> **reject\_message**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:75](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L75)

***

### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](QueryRequest.md)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L54)

#### Inherited from

[`QueryResponseBase`](QueryResponseBase.md).[`requestDetails`](QueryResponseBase.md#requestdetails)

***

### signatures?

> `optional` **signatures?**: [`NodeSignature`](NodeSignature.md)[]

Defined in: [packages/core/src/agent/agent/api.ts:77](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L77)

***

### status

> **status**: [`Rejected`](../enumerations/QueryResponseStatus.md#rejected)

Defined in: [packages/core/src/agent/agent/api.ts:73](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L73)

#### Overrides

[`QueryResponseBase`](QueryResponseBase.md).[`status`](QueryResponseBase.md#status)
