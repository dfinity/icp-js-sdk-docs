---
title: LookupLabelResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:583](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L583)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupLabelStatus.md#unknown)

Defined in: [packages/core/src/agent/certificate.ts:584](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L584)
