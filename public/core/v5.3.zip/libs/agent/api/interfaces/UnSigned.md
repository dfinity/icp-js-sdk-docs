---
title: UnSigned
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L49)

## Type Parameters

### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L50)
