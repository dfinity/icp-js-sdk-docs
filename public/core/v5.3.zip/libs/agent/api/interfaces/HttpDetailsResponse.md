---
title: HttpDetailsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:40](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L40)

## Properties

### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/core/src/agent/agent/api.ts:44](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L44)

***

### ok

> **ok**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:41](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L41)

***

### status

> **status**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:42](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L42)

***

### statusText

> **statusText**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:43](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L43)
