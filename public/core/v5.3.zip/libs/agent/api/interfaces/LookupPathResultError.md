---
title: LookupPathResultError
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L537)

## Properties

### status

> **status**: [`Error`](../enumerations/LookupPathStatus.md#error)

Defined in: [packages/core/src/agent/certificate.ts:538](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L538)
