---
title: LookupLabelResultGreater
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:592](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L592)

## Properties

### status

> **status**: [`Greater`](../enumerations/LookupLabelStatus.md#greater)

Defined in: [packages/core/src/agent/certificate.ts:593](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L593)
