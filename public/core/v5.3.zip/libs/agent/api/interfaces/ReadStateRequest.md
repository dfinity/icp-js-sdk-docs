---
title: ReadStateRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:96](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L96)

## Extends

- `Record`\<`string`, `any`\>

## Indexable

> \[`key`: `string`\]: `any`

## Properties

### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:99](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L99)

***

### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/core/src/agent/agent/http/types.ts:98](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L98)

***

### request\_type

> **request\_type**: [`ReadState`](../enumerations/ReadRequestType.md#readstate)

Defined in: [packages/core/src/agent/agent/http/types.ts:97](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L97)

***

### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:100](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L100)
