---
title: ActorMethodWithHttpDetails
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L122)

An actor method type, defined for each methods of the actor service.

## Extends

- [`ActorMethod`](ActorMethod.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

Defined in: [packages/core/src/agent/actor.ts:126](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L126)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`Args`

### Returns

`Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

## Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L122)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`unknown`[]

### Returns

`Promise`\<`unknown`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L116)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

(...`args`) => `Promise`\<`unknown`\>

#### Inherited from

[`ActorMethod`](ActorMethod.md).[`withOptions`](ActorMethod.md#withoptions)
