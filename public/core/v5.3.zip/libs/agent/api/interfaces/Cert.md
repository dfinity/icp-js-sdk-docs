---
title: Cert
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:41](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L41)

## Properties

### delegation?

> `optional` **delegation?**: `Delegation`

Defined in: [packages/core/src/agent/certificate.ts:44](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L44)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:43](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L43)

***

### tree

> **tree**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/core/src/agent/certificate.ts:42](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L42)
