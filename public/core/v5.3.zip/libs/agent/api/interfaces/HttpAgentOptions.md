---
title: HttpAgentOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:131](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L131)

## Properties

### backoffStrategy?

> `optional` **backoffStrategy?**: `BackoffStrategyFactory`

Defined in: [packages/core/src/agent/agent/http/index.ts:178](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L178)

The strategy to use for backoff when retrying requests

***

### callOptions?

> `optional` **callOptions?**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:141](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L141)

***

### credentials?

> `optional` **credentials?**: `object`

Defined in: [packages/core/src/agent/agent/http/index.ts:157](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L157)

#### name

> **name**: `string`

#### password?

> `optional` **password?**: `string`

***

### fetch?

> `optional` **fetch?**: \{(`input`, `init?`): `Promise`\<`Response`\>; (`input`, `init?`): `Promise`\<`Response`\>; \}

Defined in: [packages/core/src/agent/agent/http/index.ts:133](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L133)

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`URL` \| `RequestInfo`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`string` \| `URL` \| `Request`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

***

### fetchOptions?

> `optional` **fetchOptions?**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:138](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L138)

***

### host?

> `optional` **host?**: `string`

Defined in: [packages/core/src/agent/agent/http/index.ts:145](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L145)

***

### identity?

> `optional` **identity?**: [`Identity`](Identity.md) \| `Promise`\<[`Identity`](Identity.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:149](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L149)

***

### ingressExpiryInMinutes?

> `optional` **ingressExpiryInMinutes?**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:155](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L155)

The maximum time a request can be delayed before being rejected.

#### Default

```ts
5 minutes
```

***

### logToConsole?

> `optional` **logToConsole?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:193](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L193)

Whether to log to the console. Defaults to false.

***

### retryTimes?

> `optional` **retryTimes?**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:174](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L174)

Number of times to retry requests before throwing an error

#### Default

```ts
3
```

***

### rootKey?

> `optional` **rootKey?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:198](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L198)

Alternate root key to use for verifying certificates. If not provided, the default IC root key will be used.

***

### shouldFetchRootKey?

> `optional` **shouldFetchRootKey?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:203](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L203)

Whether or not the root key should be automatically fetched during construction. Defaults to false.

***

### shouldSyncTime?

> `optional` **shouldSyncTime?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:208](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L208)

Whether or not to sync the time with the network during construction. Defaults to false.

***

### subnetNodeKeyExpirableStore?

> `optional` **subnetNodeKeyExpirableStore?**: [`ExpirableStore`](ExpirableStore.md)\<`SubnetNodeKeys`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:189](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L189)

Custom store for caching subnet node keys.
Allows sharing the cache across multiple HttpAgent instances.
Defaults to IndexedDB in browser environments, in-memory otherwise.

***

### useQueryNonces?

> `optional` **useQueryNonces?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:169](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L169)

Adds a unique [Nonce](../type-aliases/Nonce.md) with each query.
Enabling will prevent queries from being answered with a cached response.

#### Example

```ts
const agent = new HttpAgent({ useQueryNonces: true });
agent.addTransform(makeNonceTransform(makeNonce);
```

#### Default

```ts
false
```

***

### verifyQuerySignatures?

> `optional` **verifyQuerySignatures?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:183](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L183)

Whether the agent should verify signatures signed by node keys on query responses. Increases security, but adds overhead and must make a separate request to cache the node keys for the canister's subnet.

#### Default

```ts
true
```
