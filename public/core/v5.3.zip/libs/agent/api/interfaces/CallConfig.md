---
title: CallConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:30](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L30)

Configuration to make calls to the Replica.

## Properties

### agent?

> `optional` **agent?**: [`Agent`](Agent.md)

Defined in: [packages/core/src/agent/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

***

### canisterId?

> `optional` **canisterId?**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/actor.ts:45](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L45)

The canister ID of this Actor.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId?**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L50)

The effective canister ID.

***

### nonce?

> `optional` **nonce?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/actor.ts:55](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L55)

The nonce to use for this call. This is used to prevent replay attacks.

***

### pollingOptions?

> `optional` **pollingOptions?**: [`PollingOptions`](PollingOptions.md)

Defined in: [packages/core/src/agent/actor.ts:40](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L40)

Options for controlling polling behavior.
