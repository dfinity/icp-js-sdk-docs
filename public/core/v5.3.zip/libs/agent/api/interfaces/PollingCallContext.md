---
title: PollingCallContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:36](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L36)

Call context for errors that arise during polling.

## Extended by

- [`CallContext`](CallContext.md)

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/errors.ts:37](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L37)

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L38)
