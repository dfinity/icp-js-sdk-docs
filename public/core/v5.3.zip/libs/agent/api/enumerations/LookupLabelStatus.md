---
title: LookupLabelStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:571](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L571)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:572](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L572)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:574](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L574)

***

### Greater

> **Greater**: `"Greater"`

Defined in: [packages/core/src/agent/certificate.ts:576](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L576)

***

### Less

> **Less**: `"Less"`

Defined in: [packages/core/src/agent/certificate.ts:575](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L575)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:573](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L573)
