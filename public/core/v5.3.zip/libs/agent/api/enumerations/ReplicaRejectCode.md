---
title: ReplicaRejectCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:12](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L12)

Codes used by the replica for rejecting a message.
See [the interface spec](https://sdk.dfinity.org/docs/interface-spec/#reject-codes).

## Enumeration Members

### CanisterError

> **CanisterError**: `5`

Defined in: [packages/core/src/agent/agent/api.ts:17](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L17)

***

### CanisterReject

> **CanisterReject**: `4`

Defined in: [packages/core/src/agent/agent/api.ts:16](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L16)

***

### DestinationInvalid

> **DestinationInvalid**: `3`

Defined in: [packages/core/src/agent/agent/api.ts:15](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L15)

***

### SysFatal

> **SysFatal**: `1`

Defined in: [packages/core/src/agent/agent/api.ts:13](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L13)

***

### SysTransient

> **SysTransient**: `2`

Defined in: [packages/core/src/agent/agent/api.ts:14](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L14)
