---
title: RequestStatusResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:109](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L109)

Possible values for the request status in the IC state tree.

## See

https://internetcomputer.org/docs/references/ic-interface-spec#state-tree-request-status

## Enumeration Members

### Done

> **Done**: `"done"`

Defined in: [packages/core/src/agent/agent/http/types.ts:121](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L121)

The IC has pruned the response data but remembers the request to prevent replay attacks.

***

### Processing

> **Processing**: `"processing"`

Defined in: [packages/core/src/agent/agent/http/types.ts:113](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L113)

The initial effect of the call has happened or will happen.

***

### Received

> **Received**: `"received"`

Defined in: [packages/core/src/agent/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L111)

The call has made it past the endpoint into the IC's state.

***

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/http/types.ts:117](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L117)

The call failed; reject code and message are available at `/request_status/<id>/reject_code` and `/request_status/<id>/reject_message`.

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/http/types.ts:115](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L115)

The call completed successfully; the reply is available at `/request_status/<id>/reply`.

***

### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/core/src/agent/agent/http/types.ts:119](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L119)

The request status path is absent from the state tree, the request is unknown to the IC (never received or pruned after expiry).
