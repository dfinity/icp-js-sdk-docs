---
title: DerEncodeErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:420](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L420)

## Extends

- [`ErrorCode`](ErrorCode.md)

## Constructors

### Constructor

> **new DerEncodeErrorCode**(`error`): `DerEncodeErrorCode`

Defined in: [packages/core/src/agent/errors.ts:423](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L423)

#### Parameters

##### error

`string`

#### Returns

`DerEncodeErrorCode`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`constructor`](ErrorCode.md#constructor)

## Properties

### callContext?

> `optional` **callContext?**: [`CallContext`](../interfaces/CallContext.md) \| [`PollingCallContext`](../interfaces/PollingCallContext.md)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L78)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`callContext`](ErrorCode.md#callcontext)

***

### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:423](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L423)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L80)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`isCertified`](ErrorCode.md#iscertified)

***

### name

> **name**: `string` = `'DerEncodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:421](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L421)

***

### requestContext?

> `optional` **requestContext?**: [`RequestContext`](../interfaces/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L77)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`requestContext`](ErrorCode.md#requestcontext)

***

### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](../enumerations/ErrorVerbosity.md) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L75)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`verbosity`](ErrorCode.md#verbosity)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:428](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L428)

#### Returns

`string`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`toErrorMessage`](ErrorCode.md#toerrormessage)

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L84)

#### Returns

`string`

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`toString`](ErrorCode.md#tostring)
