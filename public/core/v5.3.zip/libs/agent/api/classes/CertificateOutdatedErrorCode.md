---
title: CertificateOutdatedErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:502](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L502)

## Extends

- [`ErrorCode`](ErrorCode.md)

## Constructors

### Constructor

> **new CertificateOutdatedErrorCode**(`maxIngressExpiryInMinutes`, `requestId`, `retryTimes?`): `CertificateOutdatedErrorCode`

Defined in: [packages/core/src/agent/errors.ts:505](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L505)

#### Parameters

##### maxIngressExpiryInMinutes

`number`

##### requestId

[`RequestId`](../type-aliases/RequestId.md)

##### retryTimes?

`number`

#### Returns

`CertificateOutdatedErrorCode`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`constructor`](ErrorCode.md#constructor)

## Properties

### callContext?

> `optional` **callContext?**: [`CallContext`](../interfaces/CallContext.md) \| [`PollingCallContext`](../interfaces/PollingCallContext.md)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L78)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`callContext`](ErrorCode.md#callcontext)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:80](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L80)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`isCertified`](ErrorCode.md#iscertified)

***

### maxIngressExpiryInMinutes

> `readonly` **maxIngressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:506](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L506)

***

### name

> **name**: `string` = `'CertificateOutdatedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:503](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L503)

***

### requestContext?

> `optional` **requestContext?**: [`RequestContext`](../interfaces/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:77](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L77)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`requestContext`](ErrorCode.md#requestcontext)

***

### requestId

> `readonly` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:507](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L507)

***

### retryTimes?

> `readonly` `optional` **retryTimes?**: `number`

Defined in: [packages/core/src/agent/errors.ts:508](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L508)

***

### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](../enumerations/ErrorVerbosity.md) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L75)

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`verbosity`](ErrorCode.md#verbosity)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:514](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L514)

#### Returns

`string`

#### Overrides

[`ErrorCode`](ErrorCode.md).[`toErrorMessage`](ErrorCode.md#toerrormessage)

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:84](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/errors.ts#L84)

#### Returns

`string`

#### Inherited from

[`ErrorCode`](ErrorCode.md).[`toString`](ErrorCode.md#tostring)
