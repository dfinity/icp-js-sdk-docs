---
title: isV4ResponseBody
editUrl: false
next: true
prev: true
---

> **isV4ResponseBody**(`body`): `body is v4ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:156](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/api.ts#L156)

Utility function to check if a body is a v4ResponseBody for type safety.

## Parameters

### body

[`v2ResponseBody`](../interfaces/v2ResponseBody.md) \| [`v4ResponseBody`](../interfaces/v4ResponseBody.md) \| `null`

The body to check

## Returns

`body is v4ResponseBody`

boolean indicating if the body is a v4ResponseBody
