---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:130](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L130)

Create a random Nonce, based on random values

## Returns

[`Nonce`](../type-aliases/Nonce.md)
