---
title: makeNonceTransform
editUrl: false
next: true
prev: true
---

> **makeNonceTransform**(`nonceFn?`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/core/src/agent/agent/http/transforms.ts:18](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/transforms.ts#L18)

Create a Nonce transform, which takes a function that returns a Buffer, and adds it
as the nonce to every call requests.

## Parameters

### nonceFn?

() => [`Nonce`](../type-aliases/Nonce.md)

A function that returns a buffer. By default uses a semi-random method.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
