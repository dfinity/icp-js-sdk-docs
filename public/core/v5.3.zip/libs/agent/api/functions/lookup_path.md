---
title: lookup_path
editUrl: false
next: true
prev: true
---

> **lookup\_path**(`path`, `tree`): [`LookupResult`](../type-aliases/LookupResult.md)

Defined in: [packages/core/src/agent/certificate.ts:613](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L613)

Lookup a path in a tree. If the path is a subtree, use [lookup\_subtree](lookup_subtree.md) instead.

## Parameters

### path

[`NodePath`](../type-aliases/NodePath.md)

the path to look up

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LookupResult`](../type-aliases/LookupResult.md)

the result of the lookup
