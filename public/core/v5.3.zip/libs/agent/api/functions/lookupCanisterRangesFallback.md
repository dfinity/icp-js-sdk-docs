---
title: lookupCanisterRangesFallback
editUrl: false
next: true
prev: true
---

> **lookupCanisterRangesFallback**(`subnetId`, `tree`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:955](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L955)

Lookup the canister ranges using the `/subnet/<subnet_id>/canister_ranges` path.
Certificates returned by `/api/v3/canister/<effective_canister_id>/call`
and `/api/v2/canister/<effective_canister_id>/read_state` use this path.

## Parameters

### subnetId

[`Principal`](../../../principal/api/classes/Principal.md)

the subnet ID to lookup the canister ranges for

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

`Uint8Array`

the encoded canister ranges. Use [decodeCanisterRanges](decodeCanisterRanges.md) to decode them.

## See

https://internetcomputer.org/docs/references/ic-interface-spec#http-read-state
