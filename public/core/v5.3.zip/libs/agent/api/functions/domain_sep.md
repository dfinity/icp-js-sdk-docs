---
title: domain_sep
editUrl: false
next: true
prev: true
---

> **domain\_sep**(`s`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:507](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L507)

Creates a domain separator for hashing by encoding the input string
with its length as a prefix.

## Parameters

### s

`string`

The input string to encode.

## Returns

`Uint8Array`

A Uint8Array containing the encoded domain separator.
