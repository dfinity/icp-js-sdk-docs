---
title: lookupResultToBuffer
editUrl: false
next: true
prev: true
---

> **lookupResultToBuffer**(`result`): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/agent/certificate.ts:463](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L463)

Utility function to constrain the type of a lookup result

## Parameters

### result

[`LookupResult`](../type-aliases/LookupResult.md)

the result of a lookup

## Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

the value if the lookup was found, `undefined` otherwise
