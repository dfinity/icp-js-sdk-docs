---
title: calculateIngressExpiry
editUrl: false
next: true
prev: true
---

> **calculateIngressExpiry**(`maxIngressExpiryInMinutes`, `timeDiffMsecs`): [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/agent/http/index.ts:1711](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/index.ts#L1711)

Calculates the ingress expiry time based on the maximum allowed expiry in minutes and the time difference in milliseconds.
The expiry is rounded down according to the [Expiry.fromDeltaInMilliseconds](../classes/Expiry.md#fromdeltainmilliseconds) method.

## Parameters

### maxIngressExpiryInMinutes

`number`

The maximum ingress expiry time in minutes.

### timeDiffMsecs

`number`

The time difference in milliseconds to adjust the expiry.

## Returns

[`Expiry`](../classes/Expiry.md)

The calculated ingress expiry as an Expiry object.
