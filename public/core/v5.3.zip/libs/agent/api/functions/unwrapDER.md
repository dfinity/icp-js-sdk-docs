---
title: unwrapDER
editUrl: false
next: true
prev: true
---

> **unwrapDER**(`derEncoded`, `oid`): `Uint8Array`

Defined in: [packages/core/src/agent/der.ts:165](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/der.ts#L165)

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`

## Parameters

### derEncoded

`Uint8Array`

The DER encoded and tagged data

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

## Returns

`Uint8Array`

The unwrapped payload
