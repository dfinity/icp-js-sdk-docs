---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/core/src/agent/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/auth.ts#L139)

Create an IdentityDescriptor from an Identity

## Parameters

### identity

[`SignIdentity`](../classes/SignIdentity.md) \| [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

identity describe in returned descriptor

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
