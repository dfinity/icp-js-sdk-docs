---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/core/src/agent/der.ts:25](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/der.ts#L25)

## Parameters

### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
