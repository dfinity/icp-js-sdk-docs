---
title: decodeLenBytes
editUrl: false
next: true
prev: true
---

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:51](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/der.ts#L51)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
