---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:57](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L57)

## Type Declaration

### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
