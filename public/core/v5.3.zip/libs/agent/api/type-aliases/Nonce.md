---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/agent/http/types.ts:125](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/agent/http/types.ts#L125)

## Type Declaration

### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
