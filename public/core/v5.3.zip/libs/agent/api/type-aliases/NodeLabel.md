---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L56)

## Type Declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
