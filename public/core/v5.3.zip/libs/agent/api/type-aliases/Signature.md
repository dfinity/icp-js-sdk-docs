---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/auth.ts#L22)

A signature array buffer.

## Type Declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
