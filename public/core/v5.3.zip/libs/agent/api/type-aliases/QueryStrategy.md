---
title: QueryStrategy
editUrl: false
next: true
prev: true
---

> **QueryStrategy** = `"query"` \| `"update"`

Defined in: [packages/core/src/agent/actor.ts:25](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/actor.ts#L25)

Controls how query and composite_query methods are executed.

- `'query'` — standard non-replicated query call (default).
- `'update'` — send query methods as update calls that go through consensus.
