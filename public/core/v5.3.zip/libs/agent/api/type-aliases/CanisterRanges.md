---
title: CanisterRanges
editUrl: false
next: true
prev: true
---

> **CanisterRanges** = \[[`Principal`](../../../principal/api/classes/Principal.md), [`Principal`](../../../principal/api/classes/Principal.md)\][]

Defined in: [packages/core/src/agent/certificate.ts:886](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/agent/certificate.ts#L886)

Canister ranges in the form of an array of [start, end] principal tuples,
usually decoded from the certificate.
