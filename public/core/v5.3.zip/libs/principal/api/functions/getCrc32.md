---
title: getCrc32
editUrl: false
next: true
prev: true
---

> **getCrc32**(`buf`): `number`

Defined in: [packages/core/src/principal/utils/getCrc.ts:42](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/utils/getCrc.ts#L42)

Calculate the CRC32 of a Uint8Array.

## Parameters

### buf

`Uint8Array`

The Uint8Array to calculate the CRC32 of.

## Returns

`number`
