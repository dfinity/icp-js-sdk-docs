---
title: Principal
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/principal/principal.ts:16](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L16)

## Constructors

### Constructor

> `protected` **new Principal**(`_arr`): `Principal`

Defined in: [packages/core/src/principal/principal.ts:95](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L95)

#### Parameters

##### \_arr

`Uint8Array`

#### Returns

`Principal`

## Properties

### \_isPrincipal

> `readonly` **\_isPrincipal**: `true` = `true`

Defined in: [packages/core/src/principal/principal.ts:93](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L93)

## Methods

### compareTo()

> **compareTo**(`other`): `"lt"` \| `"eq"` \| `"gt"`

Defined in: [packages/core/src/principal/principal.ts:143](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L143)

Utility method taking a Principal to compare against. Used for determining canister ranges in certificate verification

#### Parameters

##### other

`Principal`

a Principal to compare

#### Returns

`"lt"` \| `"eq"` \| `"gt"`

`'lt' | 'eq' | 'gt'` a string, representing less than, equal to, or greater than

***

### gtEq()

> **gtEq**(`other`): `boolean`

Defined in: [packages/core/src/principal/principal.ts:177](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L177)

Utility method checking whether a provided Principal is greater than or equal to the current one using the [Principal.compareTo](#compareto) method

#### Parameters

##### other

`Principal`

a Principal to compare

#### Returns

`boolean`

boolean

***

### isAnonymous()

> **isAnonymous**(): `boolean`

Defined in: [packages/core/src/principal/principal.ts:97](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L97)

#### Returns

`boolean`

***

### ltEq()

> **ltEq**(`other`): `boolean`

Defined in: [packages/core/src/principal/principal.ts:167](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L167)

Utility method checking whether a provided Principal is less than or equal to the current one using the [Principal.compareTo](#compareto) method

#### Parameters

##### other

`Principal`

a Principal to compare

#### Returns

`boolean`

boolean

***

### toHex()

> **toHex**(): `string`

Defined in: [packages/core/src/principal/principal.ts:105](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L105)

#### Returns

`string`

***

### toJSON()

> **toJSON**(): [`JsonnablePrincipal`](../interfaces/JsonnablePrincipal.md)

Defined in: [packages/core/src/principal/principal.ts:134](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L134)

Serializes to JSON

#### Returns

[`JsonnablePrincipal`](../interfaces/JsonnablePrincipal.md)

a JSON object with a single key, [JSON\_KEY\_PRINCIPAL](../variables/JSON_KEY_PRINCIPAL.md), whose value is the principal as a string

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/principal/principal.ts:126](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L126)

#### Returns

`string`

***

### toText()

> **toText**(): `string`

Defined in: [packages/core/src/principal/principal.ts:109](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L109)

#### Returns

`string`

***

### toUint8Array()

> **toUint8Array**(): `Uint8Array`

Defined in: [packages/core/src/principal/principal.ts:101](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L101)

#### Returns

`Uint8Array`

***

### anonymous()

> `static` **anonymous**(): `Principal`

Defined in: [packages/core/src/principal/principal.ts:17](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L17)

#### Returns

`Principal`

***

### from()

> `static` **from**(`other`): `Principal`

Defined in: [packages/core/src/principal/principal.ts:34](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L34)

#### Parameters

##### other

`unknown`

#### Returns

`Principal`

***

### fromHex()

> `static` **fromHex**(`hex`): `Principal`

Defined in: [packages/core/src/principal/principal.ts:48](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L48)

#### Parameters

##### hex

`string`

#### Returns

`Principal`

***

### fromText()

> `static` **fromText**(`text`): `Principal`

Defined in: [packages/core/src/principal/principal.ts:52](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L52)

#### Parameters

##### text

`string`

#### Returns

`Principal`

***

### fromUint8Array()

> `static` **fromUint8Array**(`arr`): `Principal`

Defined in: [packages/core/src/principal/principal.ts:77](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L77)

#### Parameters

##### arr

`Uint8Array`

#### Returns

`Principal`

***

### isPrincipal()

> `static` **isPrincipal**(`other`): `other is Principal`

Defined in: [packages/core/src/principal/principal.ts:81](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L81)

#### Parameters

##### other

`unknown`

#### Returns

`other is Principal`

***

### managementCanister()

> `static` **managementCanister**(): `Principal`

Defined in: [packages/core/src/principal/principal.ts:25](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L25)

Utility method, returning the principal representing the management canister, decoded from the hex string `'aaaaa-aa'`

#### Returns

`Principal`

principal of the management canister

***

### selfAuthenticating()

> `static` **selfAuthenticating**(`publicKey`): `Principal`

Defined in: [packages/core/src/principal/principal.ts:29](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/principal/principal.ts#L29)

#### Parameters

##### publicKey

`Uint8Array`

#### Returns

`Principal`
