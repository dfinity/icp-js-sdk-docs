---
title: JsonableSecp256k1Identity
editUrl: false
next: true
prev: true
---

> **JsonableSecp256k1Identity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:19](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/secp256k1/secp256k1.ts#L19)
