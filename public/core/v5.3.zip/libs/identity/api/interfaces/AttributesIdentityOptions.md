---
title: AttributesIdentityOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/attributes.ts:22](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L22)

Options for creating an [AttributesIdentity](../classes/AttributesIdentity.md).

## Properties

### attributes

> **attributes**: [`SignedAttributes`](SignedAttributes.md)

Defined in: [packages/core/src/identity/identity/attributes.ts:26](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L26)

The signed attributes to include in the request.

***

### inner

> **inner**: [`Identity`](../../../agent/api/interfaces/Identity.md)

Defined in: [packages/core/src/identity/identity/attributes.ts:24](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L24)

The inner identity to delegate signing to.

***

### signer

> **signer**: [`Signer`](Signer.md)

Defined in: [packages/core/src/identity/identity/attributes.ts:28](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L28)

The canister that signed the attributes.
