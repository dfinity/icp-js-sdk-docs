---
title: SignedAttributes
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/attributes.ts:7](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L7)

Signed attributes to be included as `sender_info` in the request content.

## Properties

### data

> **data**: `Uint8Array`

Defined in: [packages/core/src/identity/identity/attributes.ts:8](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L8)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/identity/identity/attributes.ts:9](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L9)
