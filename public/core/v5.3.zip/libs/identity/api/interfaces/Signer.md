---
title: Signer
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/attributes.ts:15](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L15)

The canister that signed the attributes.

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/identity/identity/attributes.ts:16](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L16)
