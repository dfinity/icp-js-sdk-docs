---
title: AttributesIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/attributes.ts:50](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L50)

An Identity decorator that injects `sender_info` into the request body
before delegating to an inner identity for signing.

Because `sender_info` is part of the request content, it is included in the
representation-independent hash (`requestIdOf`) and covered by the sender's
signature.

## Example

```ts
const inner = DelegationIdentity.fromDelegation(key, chain);
const identity = new AttributesIdentity({
  inner,
  attributes: { data: new Uint8Array([...]), signature: new Uint8Array([...]) },
  signer: { canisterId: Principal.fromText('aaaaa-aa') },
});
const agent = HttpAgent.create({ identity });
```

## Implements

- [`Identity`](../../../agent/api/interfaces/Identity.md)

## Constructors

### Constructor

> **new AttributesIdentity**(`options`): `AttributesIdentity`

Defined in: [packages/core/src/identity/identity/attributes.ts:61](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L61)

#### Parameters

##### options

[`AttributesIdentityOptions`](../interfaces/AttributesIdentityOptions.md)

Configuration for the identity.

#### Returns

`AttributesIdentity`

## Methods

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/identity/identity/attributes.ts:67](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L67)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Implementation of

[`Identity`](../../../agent/api/interfaces/Identity.md).[`getPrincipal`](../../../agent/api/interfaces/Identity.md#getprincipal)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/identity/identity/attributes.ts:71](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/attributes.ts#L71)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

#### Returns

`Promise`\<`unknown`\>

#### Implementation of

[`Identity`](../../../agent/api/interfaces/Identity.md).[`transformRequest`](../../../agent/api/interfaces/Identity.md#transformrequest)
