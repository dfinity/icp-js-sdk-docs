---
title: JsonnableEd25519KeyIdentity
editUrl: false
next: true
prev: true
---

> **JsonnableEd25519KeyIdentity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/core/src/identity/identity/ed25519.ts:246](https://github.com/dfinity/icp-js-core/blob/7a21eb73094ab9cec59acf6cba11886be95c9524/packages/core/src/identity/identity/ed25519.ts#L246)
