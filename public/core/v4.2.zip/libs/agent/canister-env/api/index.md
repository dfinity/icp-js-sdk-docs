---
title: Overview
editUrl: false
next: true
prev: true
---

**`Experimental`**

## Interfaces

- [CanisterEnv](interfaces/CanisterEnv.md)

## Type Aliases

- [GetCanisterEnvOptions](type-aliases/GetCanisterEnvOptions.md)

## Functions

- [getCanisterEnv](functions/getCanisterEnv.md)
- [safeGetCanisterEnv](functions/safeGetCanisterEnv.md)
