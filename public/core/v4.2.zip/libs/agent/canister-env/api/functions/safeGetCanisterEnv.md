---
title: safeGetCanisterEnv
editUrl: false
next: true
prev: true
---

> **safeGetCanisterEnv**\<`T`\>(`options`): `undefined` \| [`CanisterEnv`](../interfaces/CanisterEnv.md) & `T`

Defined in: [packages/agent/src/canister-env/index.ts:155](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/canister-env/index.ts#L155)

**`Experimental`**

Safe version of [getCanisterEnv](getCanisterEnv.md) that returns `undefined` instead of throwing errors.

## Type Parameters

### T

`T` = `Record`\<`string`, `never`\>

## Parameters

### options

[`GetCanisterEnvOptions`](../type-aliases/GetCanisterEnvOptions.md) = `{}`

The options for loading the asset canister environment variables

## Returns

`undefined` \| [`CanisterEnv`](../interfaces/CanisterEnv.md) & `T`

The environment variables for the asset canister, or `undefined` if any error occurs

## See

The [Canister Environment Guide](https://js.icp.build/core/latest/canister-environment/) for more details on how to use the canister environment in a frontend application

## Example

```ts
// in a browser environment with valid cookie
const env = safeGetCanisterEnv();
console.log(env); // { IC_ROOT_KEY: Uint8Array, ... }

// in a Node.js environment
const env = safeGetCanisterEnv();
console.log(env); // undefined

// in a browser without the environment cookie
const env = safeGetCanisterEnv();
console.log(env); // undefined
```
