---
title: GetCanisterEnvOptions
editUrl: false
next: true
prev: true
---

> **GetCanisterEnvOptions** = `object`

Defined in: [packages/agent/src/canister-env/index.ts:72](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/canister-env/index.ts#L72)

**`Experimental`**

Options for the [getCanisterEnv](../functions/getCanisterEnv.md) function

## Properties

### cookieName?

> `optional` **cookieName**: `string`

Defined in: [packages/agent/src/canister-env/index.ts:77](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/canister-env/index.ts#L77)

The name of the cookie to get the environment variables from.

#### Default

```ts
'ic_env'
```
