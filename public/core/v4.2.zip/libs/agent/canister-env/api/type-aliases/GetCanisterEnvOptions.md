---
title: GetCanisterEnvOptions
editUrl: false
next: true
prev: true
---

> **GetCanisterEnvOptions** = `object`

Defined in: [packages/agent/src/canister-env/index.ts:72](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/canister-env/index.ts#L72)

**`Experimental`**

Options for the [getCanisterEnv](../functions/getCanisterEnv.md) function

## Properties

### cookieName?

> `optional` **cookieName**: `string`

Defined in: [packages/agent/src/canister-env/index.ts:77](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/canister-env/index.ts#L77)

The name of the cookie to get the environment variables from.

#### Default

```ts
'ic_env'
```
