---
title: TimeoutWaitingForResponseErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:424](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L424)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new TimeoutWaitingForResponseErrorCode**(`message`, `requestId?`, `status?`): `TimeoutWaitingForResponseErrorCode`

Defined in: [packages/agent/src/errors.ts:427](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L427)

#### Parameters

##### message

`string`

##### requestId?

[`RequestId`](../type-aliases/RequestId.md)

##### status?

[`RequestStatusResponseStatus`](../enumerations/RequestStatusResponseStatus.md)

#### Returns

`TimeoutWaitingForResponseErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### message

> `readonly` **message**: `string`

Defined in: [packages/agent/src/errors.ts:428](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L428)

***

### name

> **name**: `string` = `'TimeoutWaitingForResponseErrorCode'`

Defined in: [packages/agent/src/errors.ts:425](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L425)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

***

### requestId?

> `readonly` `optional` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/errors.ts:429](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L429)

***

### status?

> `readonly` `optional` **status**: [`RequestStatusResponseStatus`](../enumerations/RequestStatusResponseStatus.md)

Defined in: [packages/agent/src/errors.ts:430](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L430)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:436](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L436)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
