---
title: Expiry
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/transforms.ts:32](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L32)

## Properties

### \_isExpiry

> `readonly` **\_isExpiry**: `true` = `true`

Defined in: [packages/agent/src/agent/http/transforms.ts:33](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L33)

## Methods

### toBigInt()

> **toBigInt**(): `bigint`

Defined in: [packages/agent/src/agent/http/transforms.ts:64](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L64)

#### Returns

`bigint`

***

### toHash()

> **toHash**(): `Uint8Array`

Defined in: [packages/agent/src/agent/http/transforms.ts:68](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L68)

#### Returns

`Uint8Array`

***

### toJSON()

> **toJSON**(): [`JsonnableExpiry`](../type-aliases/JsonnableExpiry.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:80](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L80)

Serializes to JSON

#### Returns

[`JsonnableExpiry`](../type-aliases/JsonnableExpiry.md)

a JSON object with a single key, [JSON\_KEY\_EXPIRY](../variables/JSON_KEY_EXPIRY.md), whose value is the expiry as a string

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/agent/http/transforms.ts:72](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L72)

#### Returns

`string`

***

### fromDeltaInMilliseconds()

> `static` **fromDeltaInMilliseconds**(`deltaInMs`, `clockDriftInMs`): `Expiry`

Defined in: [packages/agent/src/agent/http/transforms.ts:47](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L47)

Creates an Expiry object from a delta in milliseconds.
The expiry is calculated as: current_time + delta + clock_drift
The resulting expiry is then rounded:
- If rounding down to the nearest minute still provides at least 60 seconds in the future, use minute precision
- Otherwise, use second precision

#### Parameters

##### deltaInMs

`number`

The milliseconds to add to the current time.

##### clockDriftInMs

`number` = `0`

The milliseconds to add to the current time, typically the clock drift between IC network clock and the client's clock. Defaults to `0` if not provided.

#### Returns

`Expiry`

The constructed Expiry object.

***

### fromJSON()

> `static` **fromJSON**(`input`): `Expiry`

Defined in: [packages/agent/src/agent/http/transforms.ts:89](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L89)

Deserializes a [JsonnableExpiry](../type-aliases/JsonnableExpiry.md) object from a JSON string.

#### Parameters

##### input

`string`

The JSON string to deserialize.

#### Returns

`Expiry`

The deserialized Expiry object.

***

### isExpiry()

> `static` **isExpiry**(`other`): `other is Expiry`

Defined in: [packages/agent/src/agent/http/transforms.ts:104](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L104)

#### Parameters

##### other

`unknown`

#### Returns

`other is Expiry`
