---
title: HttpErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:720](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L720)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new HttpErrorCode**(`status`, `statusText`, `headers`, `bodyText?`): `HttpErrorCode`

Defined in: [packages/agent/src/errors.ts:723](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L723)

#### Parameters

##### status

`number`

##### statusText

`string`

##### headers

[`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

##### bodyText?

`string`

#### Returns

`HttpErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### bodyText?

> `readonly` `optional` **bodyText**: `string`

Defined in: [packages/agent/src/errors.ts:727](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L727)

***

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### headers

> `readonly` **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/errors.ts:726](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L726)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'HttpErrorCode'`

Defined in: [packages/agent/src/errors.ts:721](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L721)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

***

### status

> `readonly` **status**: `number`

Defined in: [packages/agent/src/errors.ts:724](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L724)

***

### statusText

> `readonly` **statusText**: `string`

Defined in: [packages/agent/src/errors.ts:725](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L725)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:733](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L733)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
