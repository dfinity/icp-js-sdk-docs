---
title: CreateHttpAgentErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/errors.ts:629](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L629)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new CreateHttpAgentErrorCode**(): `CreateHttpAgentErrorCode`

Defined in: [packages/agent/src/errors.ts:632](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L632)

#### Returns

`CreateHttpAgentErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/agent/src/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L39)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/agent/src/errors.ts:41](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L41)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'CreateHttpAgentErrorCode'`

Defined in: [packages/agent/src/errors.ts:630](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L630)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/agent/src/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L38)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/agent/src/errors.ts:637](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L637)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/agent/src/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L45)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
