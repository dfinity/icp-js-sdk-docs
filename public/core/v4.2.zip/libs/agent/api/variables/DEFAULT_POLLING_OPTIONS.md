---
title: DEFAULT_POLLING_OPTIONS
editUrl: false
next: true
prev: true
---

> `const` **DEFAULT\_POLLING\_OPTIONS**: [`PollingOptions`](../interfaces/PollingOptions.md)

Defined in: [packages/agent/src/polling/index.ts:69](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/polling/index.ts#L69)
