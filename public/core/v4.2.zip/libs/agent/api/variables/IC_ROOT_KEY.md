---
title: IC_ROOT_KEY
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_KEY**: `string`

Defined in: [packages/agent/src/agent/http/index.ts:91](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L91)
