---
title: MANAGEMENT_CANISTER_ID
editUrl: false
next: true
prev: true
---

> `const` **MANAGEMENT\_CANISTER\_ID**: `"aaaaa-aa"` = `'aaaaa-aa'`

Defined in: [packages/agent/src/agent/http/index.ts:97](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/index.ts#L97)
