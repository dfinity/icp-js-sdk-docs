---
title: IC_REQUEST_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/constants.ts#L7)

The `\x0Aic-request` domain separator used in the signature of IC requests.
