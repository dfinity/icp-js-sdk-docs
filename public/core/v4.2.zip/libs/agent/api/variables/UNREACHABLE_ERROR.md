---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/agent/src/errors.ts:868](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/errors.ts#L868)

Special error used to indicate that a code path is unreachable.

For internal use only.
