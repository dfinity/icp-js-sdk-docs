---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/agent/src/errors.ts:868](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/errors.ts#L868)

Special error used to indicate that a code path is unreachable.

For internal use only.
