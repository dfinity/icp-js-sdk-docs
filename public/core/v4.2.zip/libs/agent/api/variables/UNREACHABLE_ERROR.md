---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/agent/src/errors.ts:868](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/errors.ts#L868)

Special error used to indicate that a code path is unreachable.

For internal use only.
