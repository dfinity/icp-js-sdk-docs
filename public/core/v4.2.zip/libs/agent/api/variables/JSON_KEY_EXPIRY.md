---
title: JSON_KEY_EXPIRY
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/agent/src/agent/http/transforms.ts:12](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/transforms.ts#L12)
