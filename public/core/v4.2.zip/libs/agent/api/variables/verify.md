---
title: verify
editUrl: false
next: true
prev: true
---

> **verify**: (`pk`, `sig`, `msg`) => `boolean`

Defined in: [packages/agent/src/utils/bls.ts:4](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/utils/bls.ts#L4)

## Parameters

### pk

`Uint8Array`

### sig

`Uint8Array`

### msg

`Uint8Array`

## Returns

`boolean`
