---
title: DER_COSE_OID
editUrl: false
next: true
prev: true
---

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:69](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/der.ts#L69)

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE
