---
title: DER_COSE_OID
editUrl: false
next: true
prev: true
---

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/agent/src/der.ts:69](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/der.ts#L69)

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE
