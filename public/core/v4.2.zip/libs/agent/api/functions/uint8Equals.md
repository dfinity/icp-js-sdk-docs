---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`a`, `b`): `boolean`

Defined in: [packages/agent/src/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/utils/buffer.ts#L54)

Compares two Uint8Arrays for equality.

## Parameters

### a

`Uint8Array`

The first Uint8Array.

### b

`Uint8Array`

The second Uint8Array.

## Returns

`boolean`

True if the Uint8Arrays are equal, false otherwise.
