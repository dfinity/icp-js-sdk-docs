---
title: find_label
editUrl: false
next: true
prev: true
---

> **find\_label**(`label`, `tree`): [`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

Defined in: [packages/agent/src/certificate.ts:690](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L690)

Find a label in a tree

## Parameters

### label

[`NodeLabel`](../type-aliases/NodeLabel.md)

the label to find

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`LabelLookupResult`](../type-aliases/LabelLookupResult.md)

the result of the label lookup
