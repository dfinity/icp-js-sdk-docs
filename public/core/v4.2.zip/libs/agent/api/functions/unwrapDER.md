---
title: unwrapDER
editUrl: false
next: true
prev: true
---

> **unwrapDER**(`derEncoded`, `oid`): `Uint8Array`

Defined in: [packages/agent/src/der.ts:144](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/der.ts#L144)

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`

## Parameters

### derEncoded

`Uint8Array`

The DER encoded and tagged data

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

## Returns

`Uint8Array`

The unwrapped payload
