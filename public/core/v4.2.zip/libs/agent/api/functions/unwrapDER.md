---
title: unwrapDER
editUrl: false
next: true
prev: true
---

> **unwrapDER**(`derEncoded`, `oid`): `Uint8Array`

Defined in: [packages/agent/src/der.ts:144](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/der.ts#L144)

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`

## Parameters

### derEncoded

`Uint8Array`

The DER encoded and tagged data

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

## Returns

`Uint8Array`

The unwrapped payload
