---
title: httpHeadersTransform
editUrl: false
next: true
prev: true
---

> **httpHeadersTransform**(`headers`): [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/agent/http/transforms.ts:147](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/transforms.ts#L147)

Maps the default fetch headers field to the serializable HttpHeaderField.

## Parameters

### headers

`Headers`

Fetch definition of the headers type

## Returns

[`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

array of header fields
