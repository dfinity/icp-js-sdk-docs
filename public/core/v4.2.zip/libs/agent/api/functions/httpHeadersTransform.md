---
title: httpHeadersTransform
editUrl: false
next: true
prev: true
---

> **httpHeadersTransform**(`headers`): [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/agent/http/transforms.ts:152](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/transforms.ts#L152)

Maps the default fetch headers field to the serializable HttpHeaderField.

## Parameters

### headers

`Headers`

Fetch definition of the headers type

## Returns

[`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

array of header fields
