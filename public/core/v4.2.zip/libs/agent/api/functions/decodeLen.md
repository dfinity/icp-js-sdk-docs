---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:56](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/der.ts#L56)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
