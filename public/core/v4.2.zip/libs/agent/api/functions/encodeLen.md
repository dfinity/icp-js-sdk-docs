---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/agent/src/der.ts:23](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/der.ts#L23)

## Parameters

### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
