---
title: requestIdOf
editUrl: false
next: true
prev: true
---

> **requestIdOf**(`request`): [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/agent/src/request\_id.ts:63](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/request_id.ts#L63)

Get the RequestId of the provided ic-ref request.
RequestId is the result of the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

## Parameters

### request

`Record`\<`string`, `unknown`\>

ic-ref request to hash into RequestId

## Returns

[`RequestId`](../type-aliases/RequestId.md)
