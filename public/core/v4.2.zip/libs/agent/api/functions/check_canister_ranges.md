---
title: check_canister_ranges
editUrl: false
next: true
prev: true
---

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/agent/src/certificate.ts:795](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L795)

Check if a canister ID falls within the canister ranges of a given subnet

## Parameters

### params

the parameters with which to check the canister ranges

#### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

the canister ID to check

#### subnetId

[`Principal`](../../../principal/api/classes/Principal.md)

the subnet ID from which to check the canister ranges

#### tree

[`HashTree`](../type-aliases/HashTree.md)

the hash tree in which to lookup the subnet's canister ranges

## Returns

`boolean`

`true` if the canister is in the range, `false` otherwise
