---
title: makeNonceTransform
editUrl: false
next: true
prev: true
---

> **makeNonceTransform**(`nonceFn`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/agent/src/agent/http/transforms.ts:122](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/transforms.ts#L122)

Create a Nonce transform, which takes a function that returns a Buffer, and adds it
as the nonce to every call requests.

## Parameters

### nonceFn

() => [`Nonce`](../type-aliases/Nonce.md)

A function that returns a buffer. By default uses a semi-random method.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
