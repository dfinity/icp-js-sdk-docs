---
title: decodeLenBytes
editUrl: false
next: true
prev: true
---

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/agent/src/der.ts:47](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/der.ts#L47)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
