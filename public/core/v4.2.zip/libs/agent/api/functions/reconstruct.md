---
title: reconstruct
editUrl: false
next: true
prev: true
---

> **reconstruct**(`t`): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/agent/src/certificate.ts:418](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L418)

## Parameters

### t

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to reconstruct

## Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>
