---
title: uint8ToBuf
editUrl: false
next: true
prev: true
---

> **uint8ToBuf**(`arr`): `ArrayBuffer`

Defined in: [packages/agent/src/utils/buffer.ts:41](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/utils/buffer.ts#L41)

Returns a true ArrayBuffer from a Uint8Array, as Uint8Array.buffer is unsafe.

## Parameters

### arr

`Uint8Array`

Uint8Array to convert

## Returns

`ArrayBuffer`

ArrayBuffer
