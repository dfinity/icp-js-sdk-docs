---
title: uint8ToBuf
editUrl: false
next: true
prev: true
---

> **uint8ToBuf**(`arr`): `ArrayBuffer`

Defined in: [packages/agent/src/utils/buffer.ts:41](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/utils/buffer.ts#L41)

Returns a true ArrayBuffer from a Uint8Array, as Uint8Array.buffer is unsafe.

## Parameters

### arr

`Uint8Array`

Uint8Array to convert

## Returns

`ArrayBuffer`

ArrayBuffer
