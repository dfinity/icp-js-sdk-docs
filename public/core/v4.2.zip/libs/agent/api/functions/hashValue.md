---
title: hashValue
editUrl: false
next: true
prev: true
---

> **hashValue**(`value`): `Uint8Array`

Defined in: [packages/agent/src/request\_id.ts:19](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/request_id.ts#L19)

## Parameters

### value

`unknown`

unknown value

## Returns

`Uint8Array`

Uint8Array
