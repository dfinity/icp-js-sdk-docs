---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/agent/src/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L111)

Create a random Nonce, based on random values

## Returns

[`Nonce`](../type-aliases/Nonce.md)
