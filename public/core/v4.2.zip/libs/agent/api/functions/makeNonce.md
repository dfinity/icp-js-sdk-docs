---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/agent/src/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L111)

Create a random Nonce, based on random values

## Returns

[`Nonce`](../type-aliases/Nonce.md)
