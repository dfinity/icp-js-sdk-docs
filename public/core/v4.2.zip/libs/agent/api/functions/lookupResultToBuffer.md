---
title: lookupResultToBuffer
editUrl: false
next: true
prev: true
---

> **lookupResultToBuffer**(`result`): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/certificate.ts:403](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L403)

Utility function to constrain the type of a lookup result

## Parameters

### result

[`LookupResult`](../type-aliases/LookupResult.md)

the result of a lookup

## Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

the value if the lookup was found, `undefined` otherwise
