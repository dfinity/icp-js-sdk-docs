---
title: hashOfMap
editUrl: false
next: true
prev: true
---

> **hashOfMap**(`map`): `Uint8Array`

Defined in: [packages/agent/src/request\_id.ts:73](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/request_id.ts#L73)

Hash a map into a Uint8Array using the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

## Parameters

### map

`Record`\<`string`, `unknown`\>

Any non-nested object

## Returns

`Uint8Array`

Uint8Array
