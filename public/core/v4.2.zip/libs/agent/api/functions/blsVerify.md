---
title: blsVerify
editUrl: false
next: true
prev: true
---

> **blsVerify**(`pk`, `sig`, `msg`): `boolean`

Defined in: [packages/agent/src/utils/bls.ts:13](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/utils/bls.ts#L13)

## Parameters

### pk

`Uint8Array`

primary key: Uint8Array

### sig

`Uint8Array`

signature: Uint8Array

### msg

`Uint8Array`

message: Uint8Array

## Returns

`boolean`

boolean
