---
title: calculateIngressExpiry
editUrl: false
next: true
prev: true
---

> **calculateIngressExpiry**(`maxIngressExpiryInMinutes`, `timeDiffMsecs`): [`Expiry`](../classes/Expiry.md)

Defined in: [packages/agent/src/agent/http/index.ts:1409](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/index.ts#L1409)

Calculates the ingress expiry time based on the maximum allowed expiry in minutes and the time difference in milliseconds.
The expiry is rounded down according to the [Expiry.fromDeltaInMilliseconds](../classes/Expiry.md#fromdeltainmilliseconds) method.

## Parameters

### maxIngressExpiryInMinutes

`number`

The maximum ingress expiry time in minutes.

### timeDiffMsecs

`number`

The time difference in milliseconds to adjust the expiry.

## Returns

[`Expiry`](../classes/Expiry.md)

The calculated ingress expiry as an Expiry object.
