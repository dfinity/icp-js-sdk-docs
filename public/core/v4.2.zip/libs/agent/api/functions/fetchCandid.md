---
title: fetchCandid
editUrl: false
next: true
prev: true
---

> **fetchCandid**(`canisterId`, `agent?`): `Promise`\<`string`\>

Defined in: [packages/agent/src/fetch\_candid.ts:13](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/fetch_candid.ts#L13)

Retrieves the Candid interface for the specified canister.

## Parameters

### canisterId

`string`

A string corresponding to the canister ID

### agent?

[`HttpAgent`](../classes/HttpAgent.md)

The agent to use for the request (usually an `HttpAgent`)

## Returns

`Promise`\<`string`\>

Candid source code
