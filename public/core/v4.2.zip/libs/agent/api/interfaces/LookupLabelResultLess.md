---
title: LookupLabelResultLess
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:536](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L536)

## Properties

### status

> **status**: [`Less`](../enumerations/LookupLabelStatus.md#less)

Defined in: [packages/agent/src/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L537)
