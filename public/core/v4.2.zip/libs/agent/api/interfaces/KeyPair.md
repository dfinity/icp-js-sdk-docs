---
title: KeyPair
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:9](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/auth.ts#L9)

A Key Pair, containing a secret and public key.

## Properties

### publicKey

> **publicKey**: [`PublicKey`](PublicKey.md)

Defined in: [packages/agent/src/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/auth.ts#L11)

***

### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/agent/src/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/auth.ts#L10)
