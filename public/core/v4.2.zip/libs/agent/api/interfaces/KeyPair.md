---
title: KeyPair
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:9](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L9)

A Key Pair, containing a secret and public key.

## Properties

### publicKey

> **publicKey**: [`PublicKey`](PublicKey.md)

Defined in: [packages/agent/src/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L11)

***

### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/agent/src/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L10)
