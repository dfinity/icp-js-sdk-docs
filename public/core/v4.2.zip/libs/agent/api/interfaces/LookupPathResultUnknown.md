---
title: LookupPathResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:468](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L468)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupPathStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:469](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L469)
