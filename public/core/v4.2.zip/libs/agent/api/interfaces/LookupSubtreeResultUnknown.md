---
title: LookupSubtreeResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:497](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L497)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupSubtreeStatus.md#unknown)

Defined in: [packages/agent/src/certificate.ts:498](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L498)
