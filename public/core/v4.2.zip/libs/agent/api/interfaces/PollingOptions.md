---
title: PollingOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/polling/index.ts:43](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/index.ts#L43)

Options for controlling polling behavior

## Properties

### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: [packages/agent/src/polling/index.ts:60](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/index.ts#L60)

Optional replacement function that verifies the BLS signature of a certificate.

***

### preSignReadStateRequest?

> `optional` **preSignReadStateRequest**: `boolean`

Defined in: [packages/agent/src/polling/index.ts:55](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/index.ts#L55)

Whether to reuse the same signed request for polling or create a new unsigned request each time.

#### Default

```ts
false
```

***

### request?

> `optional` **request**: [`ReadStateRequest`](ReadStateRequest.md)

Defined in: [packages/agent/src/polling/index.ts:66](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/index.ts#L66)

The request to use for polling. If not provided, a new request will be created.
This is only used if `preSignReadStateRequest` is set to false.

***

### strategy?

> `optional` **strategy**: [`PollStrategy`](../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/index.ts:49](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/index.ts#L49)

A polling strategy that dictates how much and often we should poll the
read_state endpoint to get the result of an update call.

#### Default

[defaultStrategy](../namespaces/strategy/functions/defaultStrategy.md)
