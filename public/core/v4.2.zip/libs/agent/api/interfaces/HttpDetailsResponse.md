---
title: HttpDetailsResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:39](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L39)

## Properties

### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

Defined in: [packages/agent/src/agent/api.ts:43](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L43)

***

### ok

> **ok**: `boolean`

Defined in: [packages/agent/src/agent/api.ts:40](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L40)

***

### status

> **status**: `number`

Defined in: [packages/agent/src/agent/api.ts:41](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L41)

***

### statusText

> **statusText**: `string`

Defined in: [packages/agent/src/agent/api.ts:42](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/api.ts#L42)
