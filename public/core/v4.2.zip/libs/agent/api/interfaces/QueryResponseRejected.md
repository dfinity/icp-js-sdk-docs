---
title: QueryResponseRejected
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:71](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L71)

## Extends

- [`QueryResponseBase`](QueryResponseBase.md)

## Properties

### error\_code

> **error\_code**: `string`

Defined in: [packages/agent/src/agent/api.ts:75](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L75)

***

### reject\_code

> **reject\_code**: [`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

Defined in: [packages/agent/src/agent/api.ts:73](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L73)

***

### reject\_message

> **reject\_message**: `string`

Defined in: [packages/agent/src/agent/api.ts:74](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L74)

***

### requestDetails?

> `optional` **requestDetails**: [`QueryRequest`](QueryRequest.md)

Defined in: [packages/agent/src/agent/api.ts:53](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L53)

#### Inherited from

[`QueryResponseBase`](QueryResponseBase.md).[`requestDetails`](QueryResponseBase.md#requestdetails)

***

### signatures?

> `optional` **signatures**: [`NodeSignature`](../type-aliases/NodeSignature.md)[]

Defined in: [packages/agent/src/agent/api.ts:76](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L76)

***

### status

> **status**: [`Rejected`](../enumerations/QueryResponseStatus.md#rejected)

Defined in: [packages/agent/src/agent/api.ts:72](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L72)

#### Overrides

[`QueryResponseBase`](QueryResponseBase.md).[`status`](QueryResponseBase.md#status)
