---
title: HttpAgentRequestTransformFn
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

Defined in: [packages/agent/src/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L56)

## Parameters

### args

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

## Returns

`Promise`\<`undefined` \| `void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)\>

## Properties

### priority?

> `optional` **priority**: `number`

Defined in: [packages/agent/src/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L57)
