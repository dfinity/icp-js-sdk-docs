---
title: CallRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:62](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L62)

## Extends

- `Record`\<`string`, `any`\>

## Indexable

\[`key`: `string`\]: `any`

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/agent/src/agent/http/types.ts:66](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L66)

***

### canister\_id

> **canister\_id**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/agent/http/types.ts:64](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L64)

***

### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/agent/src/agent/http/types.ts:68](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L68)

***

### method\_name

> **method\_name**: `string`

Defined in: [packages/agent/src/agent/http/types.ts:65](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L65)

***

### nonce?

> `optional` **nonce**: [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/agent/src/agent/http/types.ts:69](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L69)

***

### request\_type

> **request\_type**: [`Call`](../enumerations/SubmitRequestType.md#call)

Defined in: [packages/agent/src/agent/http/types.ts:63](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L63)

***

### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/agent/http/types.ts:67](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L67)
