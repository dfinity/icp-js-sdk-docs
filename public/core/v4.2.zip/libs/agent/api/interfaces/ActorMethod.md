---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:105](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/actor.ts#L105)

An actor method type, defined for each methods of the actor service.

## Extended by

- [`ActorMethodWithHttpDetails`](ActorMethodWithHttpDetails.md)
- [`ActorMethodExtended`](ActorMethodExtended.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/agent/src/actor.ts:106](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/actor.ts#L106)

An actor method type, defined for each methods of the actor service.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`Ret`\>

Defined in: [packages/agent/src/actor.ts:108](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/actor.ts#L108)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

> (...`args`): `Promise`\<`Ret`\>

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<`Ret`\>
