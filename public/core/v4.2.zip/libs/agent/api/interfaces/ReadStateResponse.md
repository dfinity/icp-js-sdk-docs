---
title: ReadStateResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:120](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L120)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:121](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L121)
