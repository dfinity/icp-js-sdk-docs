---
title: LookupPathResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:472](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L472)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupPathStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:473](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L473)

***

### value

> **value**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:474](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L474)
