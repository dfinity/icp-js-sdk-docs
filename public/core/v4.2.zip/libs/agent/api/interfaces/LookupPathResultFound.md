---
title: LookupPathResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:472](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L472)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupPathStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:473](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L473)

***

### value

> **value**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:474](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L474)
