---
title: Cert
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:39](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L39)

## Properties

### delegation?

> `optional` **delegation**: `Delegation`

Defined in: [packages/agent/src/certificate.ts:42](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L42)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/agent/src/certificate.ts:41](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L41)

***

### tree

> **tree**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:40](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L40)
