---
title: AnonymousIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L126)

## Properties

### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/agent/src/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/auth.ts#L127)
