---
title: ActorConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/actor.ts:61](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L61)

Configuration that can be passed to customize the Actor behavior.

## Extends

- `Pick`\<[`CallConfig`](CallConfig.md), `"agent"` \| `"effectiveCanisterId"`\>

## Properties

### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/agent/src/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

#### Inherited from

[`CallConfig`](CallConfig.md).[`agent`](CallConfig.md#agent)

***

### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: [packages/agent/src/actor.ts:88](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L88)

Polyfill for BLS Certificate verification in case wasm is not supported

***

### canisterId

> **canisterId**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:65](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L65)

The Canister ID of this Actor. This is required for an Actor.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L50)

The effective canister ID.

#### Inherited from

[`CallConfig`](CallConfig.md).[`effectiveCanisterId`](CallConfig.md#effectivecanisterid)

***

### pollingOptions?

> `optional` **pollingOptions**: [`PollingOptions`](PollingOptions.md)

Defined in: [packages/agent/src/actor.ts:93](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L93)

Polling options to use when making update calls. This will override the default DEFAULT_POLLING_OPTIONS.

## Methods

### callTransform()?

> `optional` **callTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

Defined in: [packages/agent/src/actor.ts:70](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L70)

An override function for update calls' CallConfig. This will be called on every calls.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

***

### queryTransform()?

> `optional` **queryTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

Defined in: [packages/agent/src/actor.ts:79](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L79)

An override function for query calls' CallConfig. This will be called on every query.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>
