---
title: LookupPathResultError
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:477](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L477)

## Properties

### status

> **status**: [`Error`](../enumerations/LookupPathStatus.md#error)

Defined in: [packages/agent/src/certificate.ts:478](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L478)
