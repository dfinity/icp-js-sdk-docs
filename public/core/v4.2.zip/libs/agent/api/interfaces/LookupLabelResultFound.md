---
title: LookupLabelResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:527](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L527)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupLabelStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:528](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L528)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:529](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L529)
