---
title: HttpAgentSubmitRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:28](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L28)

## Extends

- [`HttpAgentBaseRequest`](HttpAgentBaseRequest.md)

## Properties

### body

> **body**: [`CallRequest`](CallRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:30](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L30)

***

### endpoint

> `readonly` **endpoint**: [`Call`](../enumerations/Endpoint.md#call)

Defined in: [packages/agent/src/agent/http/types.ts:29](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L29)

#### Overrides

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`endpoint`](HttpAgentBaseRequest.md#endpoint)

***

### request

> **request**: `RequestInit`

Defined in: [packages/agent/src/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/agent/http/types.ts#L23)

#### Inherited from

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`request`](HttpAgentBaseRequest.md#request)
