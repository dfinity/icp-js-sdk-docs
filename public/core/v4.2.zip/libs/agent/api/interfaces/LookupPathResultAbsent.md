---
title: LookupPathResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:464](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L464)

## Properties

### status

> **status**: [`Absent`](../enumerations/LookupPathStatus.md#absent)

Defined in: [packages/agent/src/certificate.ts:465](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L465)
