---
title: LookupSubtreeResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:501](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L501)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupSubtreeStatus.md#found)

Defined in: [packages/agent/src/certificate.ts:502](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L502)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/agent/src/certificate.ts:503](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L503)
