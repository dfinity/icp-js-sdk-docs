---
title: ReplicaRejectCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:11](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L11)

Codes used by the replica for rejecting a message.
See [the interface spec](https://sdk.dfinity.org/docs/interface-spec/#reject-codes).

## Enumeration Members

### CanisterError

> **CanisterError**: `5`

Defined in: [packages/agent/src/agent/api.ts:16](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L16)

***

### CanisterReject

> **CanisterReject**: `4`

Defined in: [packages/agent/src/agent/api.ts:15](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L15)

***

### DestinationInvalid

> **DestinationInvalid**: `3`

Defined in: [packages/agent/src/agent/api.ts:14](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L14)

***

### SysFatal

> **SysFatal**: `1`

Defined in: [packages/agent/src/agent/api.ts:12](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L12)

***

### SysTransient

> **SysTransient**: `2`

Defined in: [packages/agent/src/agent/api.ts:13](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L13)
