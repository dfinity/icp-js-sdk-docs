---
title: ReadRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L78)

## Enumeration Members

### Query

> **Query**: `"query"`

Defined in: [packages/agent/src/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L79)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/agent/src/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/types.ts#L80)
