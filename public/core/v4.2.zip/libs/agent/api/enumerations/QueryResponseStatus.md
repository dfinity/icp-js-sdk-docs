---
title: QueryResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/api.ts:34](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/api.ts#L34)

## Enumeration Members

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/agent/src/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/api.ts#L36)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/agent/src/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/api.ts#L35)
