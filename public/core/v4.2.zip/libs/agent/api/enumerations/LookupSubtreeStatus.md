---
title: LookupSubtreeStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:487](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L487)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:488](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L488)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:490](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L490)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:489](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L489)
