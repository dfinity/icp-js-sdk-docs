---
title: LookupSubtreeStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:487](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L487)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:488](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L488)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:490](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L490)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:489](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L489)
