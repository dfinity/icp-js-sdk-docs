---
title: LookupSubtreeStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:487](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L487)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:488](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L488)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:490](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L490)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:489](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L489)
