---
title: LookupPathStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:457](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L457)

## Enumeration Members

### Absent

> **Absent**: `"Absent"`

Defined in: [packages/agent/src/certificate.ts:459](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L459)

***

### Error

> **Error**: `"Error"`

Defined in: [packages/agent/src/certificate.ts:461](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L461)

***

### Found

> **Found**: `"Found"`

Defined in: [packages/agent/src/certificate.ts:460](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L460)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/agent/src/certificate.ts:458](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L458)
