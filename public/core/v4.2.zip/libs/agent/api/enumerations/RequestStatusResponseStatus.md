---
title: RequestStatusResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/agent/http/index.ts:76](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L76)

## Enumeration Members

### Done

> **Done**: `"done"`

Defined in: [packages/agent/src/agent/http/index.ts:82](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L82)

***

### Processing

> **Processing**: `"processing"`

Defined in: [packages/agent/src/agent/http/index.ts:78](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L78)

***

### Received

> **Received**: `"received"`

Defined in: [packages/agent/src/agent/http/index.ts:77](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L77)

***

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/agent/src/agent/http/index.ts:80](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L80)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/agent/src/agent/http/index.ts:79](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L79)

***

### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/agent/src/agent/http/index.ts:81](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/agent/http/index.ts#L81)
