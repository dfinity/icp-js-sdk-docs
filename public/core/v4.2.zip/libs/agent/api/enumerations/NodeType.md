---
title: NodeType
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/certificate.ts:45](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L45)

## Enumeration Members

### Empty

> **Empty**: `0`

Defined in: [packages/agent/src/certificate.ts:46](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L46)

***

### Fork

> **Fork**: `1`

Defined in: [packages/agent/src/certificate.ts:47](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L47)

***

### Labeled

> **Labeled**: `2`

Defined in: [packages/agent/src/certificate.ts:48](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L48)

***

### Leaf

> **Leaf**: `3`

Defined in: [packages/agent/src/certificate.ts:49](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L49)

***

### Pruned

> **Pruned**: `4`

Defined in: [packages/agent/src/certificate.ts:50](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L50)
