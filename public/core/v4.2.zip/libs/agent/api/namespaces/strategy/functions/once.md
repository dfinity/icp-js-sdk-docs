---
title: once
editUrl: false
next: true
prev: true
---

> **once**(): [`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

Defined in: [packages/agent/src/polling/strategy.ts:29](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/polling/strategy.ts#L29)

Predicate that returns true once.

## Returns

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>
