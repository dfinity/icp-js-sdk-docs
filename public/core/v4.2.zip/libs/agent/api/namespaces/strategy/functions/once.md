---
title: once
editUrl: false
next: true
prev: true
---

> **once**(): [`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

Defined in: [packages/agent/src/polling/strategy.ts:29](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/polling/strategy.ts#L29)

Predicate that returns true once.

## Returns

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>
