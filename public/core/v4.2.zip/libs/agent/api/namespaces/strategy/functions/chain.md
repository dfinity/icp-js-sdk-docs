---
title: chain
editUrl: false
next: true
prev: true
---

> **chain**(...`strategies`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:134](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/polling/strategy.ts#L134)

Chain multiple polling strategy. This _chains_ the strategies, so if you pass in,
say, two throttling strategy of 1 second, it will result in a throttle of 2 seconds.

## Parameters

### strategies

...[`PollStrategy`](../../../type-aliases/PollStrategy.md)[]

A strategy list to chain.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
