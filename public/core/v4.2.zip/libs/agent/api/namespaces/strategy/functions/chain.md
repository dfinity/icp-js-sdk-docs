---
title: chain
editUrl: false
next: true
prev: true
---

> **chain**(...`strategies`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/agent/src/polling/strategy.ts:134](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/polling/strategy.ts#L134)

Chain multiple polling strategy. This _chains_ the strategies, so if you pass in,
say, two throttling strategy of 1 second, it will result in a throttle of 2 seconds.

## Parameters

### strategies

...[`PollStrategy`](../../../type-aliases/PollStrategy.md)[]

A strategy list to chain.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
