---
title: request
editUrl: false
next: true
prev: true
---

> **request**(`options`): `Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:153](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/canisterStatus/index.ts#L153)

Requests information from a canister's `read_state` endpoint.
Can be used to request information about the canister's controllers, time, module hash, candid interface, and more.

## Parameters

### options

[`CanisterStatusOptions`](../type-aliases/CanisterStatusOptions.md)

The configuration for the canister status request.

## Returns

`Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

A map populated with data from the requested paths. Each path is a key in the map, and the value is the data obtained from the certificate for that path.

## See

[CanisterStatusOptions](../type-aliases/CanisterStatusOptions.md) for detailed options.

## Example

```ts
const status = await canisterStatus({
  paths: ['controllers', 'candid'],
  ...options
});

const controllers = status.get('controllers');
```
