---
title: MetaData
editUrl: false
next: true
prev: true
---

Defined in: [packages/agent/src/canisterStatus/index.ts:97](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L97)

## Deprecated

Use [CustomPath](../classes/CustomPath.md) instead

## Param

the key to use to access the returned value in the canisterStatus map

## Param

the path to the desired value, represented as a string

## Param

the strategy to use to decode the returned value

## Properties

### ~~decodeStrategy~~

> **decodeStrategy**: `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/agent/src/canisterStatus/index.ts:101](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L101)

***

### ~~key~~

> **key**: `string`

Defined in: [packages/agent/src/canisterStatus/index.ts:99](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L99)

***

### ~~kind~~

> **kind**: `"metadata"`

Defined in: [packages/agent/src/canisterStatus/index.ts:98](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L98)

***

### ~~path~~

> **path**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/agent/src/canisterStatus/index.ts:100](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L100)
