---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

## Classes

- [CustomPath](classes/CustomPath.md)

## Interfaces

- [~~MetaData~~](interfaces/MetaData.md)

## Type Aliases

- [CanisterStatusOptions](type-aliases/CanisterStatusOptions.md)
- [Path](type-aliases/Path.md)
- [Status](type-aliases/Status.md)
- [StatusMap](type-aliases/StatusMap.md)
- [SubnetStatus](type-aliases/SubnetStatus.md)

## Functions

- [encodePath](functions/encodePath.md)
- [fetchNodeKeys](functions/fetchNodeKeys.md)
- [request](functions/request.md)
