---
title: fetchNodeKeys
editUrl: false
next: true
prev: true
---

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:285](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/canisterStatus/index.ts#L285)

## Parameters

### certificate

`Uint8Array`

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)
