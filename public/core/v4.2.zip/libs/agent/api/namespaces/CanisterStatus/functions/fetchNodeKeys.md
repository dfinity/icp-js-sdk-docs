---
title: fetchNodeKeys
editUrl: false
next: true
prev: true
---

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:285](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/canisterStatus/index.ts#L285)

## Parameters

### certificate

`Uint8Array`

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)
