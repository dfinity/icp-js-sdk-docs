---
title: encodePath
editUrl: false
next: true
prev: true
---

> **encodePath**(`path`, `canisterId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/agent/src/canisterStatus/index.ts:364](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/canisterStatus/index.ts#L364)

## Parameters

### path

[`Path`](../type-aliases/Path.md)

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

## Returns

`Uint8Array`\<`ArrayBufferLike`\>[]
