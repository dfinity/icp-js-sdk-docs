---
title: CanisterStatusOptions
editUrl: false
next: true
prev: true
---

> **CanisterStatusOptions** = `object`

Defined in: [packages/agent/src/canisterStatus/index.ts:118](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L118)

## Properties

### agent

> **agent**: [`HttpAgent`](../../../classes/HttpAgent.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:126](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L126)

The agent to use to make the canister request. Must be authenticated.

***

### canisterId

> **canisterId**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/agent/src/canisterStatus/index.ts:122](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L122)

The effective canister ID to use in the underlying [HttpAgent.readState](../../../classes/HttpAgent.md#readstate) call.

***

### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification**: `boolean`

Defined in: [packages/agent/src/canisterStatus/index.ts:136](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L136)

Whether to disable the certificate freshness checks.

#### Default

```ts
false
```

***

### paths?

> `optional` **paths**: [`Path`](Path.md)[] \| `Set`\<[`Path`](Path.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:131](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/canisterStatus/index.ts#L131)

The paths to request.

#### Default

```ts
[]
```
