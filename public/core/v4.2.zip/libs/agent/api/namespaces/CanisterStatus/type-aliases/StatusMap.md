---
title: StatusMap
editUrl: false
next: true
prev: true
---

> **StatusMap** = `Map`\<[`Path`](Path.md) \| `string`, [`Status`](Status.md)\>

Defined in: [packages/agent/src/canisterStatus/index.ts:116](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/canisterStatus/index.ts#L116)
