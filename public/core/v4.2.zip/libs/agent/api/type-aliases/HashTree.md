---
title: HashTree
editUrl: false
next: true
prev: true
---

> **HashTree** = [`EmptyHashTree`](EmptyHashTree.md) \| [`ForkHashTree`](ForkHashTree.md) \| [`LabeledHashTree`](LabeledHashTree.md) \| [`LeafHashTree`](LeafHashTree.md) \| [`PrunedHashTree`](PrunedHashTree.md)

Defined in: [packages/agent/src/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L64)
