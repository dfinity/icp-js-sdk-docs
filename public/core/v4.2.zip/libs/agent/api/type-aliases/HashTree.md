---
title: HashTree
editUrl: false
next: true
prev: true
---

> **HashTree** = [`EmptyHashTree`](EmptyHashTree.md) \| [`ForkHashTree`](ForkHashTree.md) \| [`LabeledHashTree`](LabeledHashTree.md) \| [`LeafHashTree`](LeafHashTree.md) \| [`PrunedHashTree`](PrunedHashTree.md)

Defined in: [packages/agent/src/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L64)
