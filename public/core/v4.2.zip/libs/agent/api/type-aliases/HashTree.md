---
title: HashTree
editUrl: false
next: true
prev: true
---

> **HashTree** = [`EmptyHashTree`](EmptyHashTree.md) \| [`ForkHashTree`](ForkHashTree.md) \| [`LabeledHashTree`](LabeledHashTree.md) \| [`LeafHashTree`](LeafHashTree.md) \| [`PrunedHashTree`](PrunedHashTree.md)

Defined in: [packages/agent/src/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L64)
