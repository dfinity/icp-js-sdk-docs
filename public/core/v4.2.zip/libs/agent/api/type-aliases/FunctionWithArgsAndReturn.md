---
title: FunctionWithArgsAndReturn
editUrl: false
next: true
prev: true
---

> **FunctionWithArgsAndReturn**\<`Args`, `Ret`\> = (...`args`) => `Ret`

Defined in: [packages/agent/src/actor.ts:131](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/actor.ts#L131)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Parameters

### args

...`Args`

## Returns

`Ret`
