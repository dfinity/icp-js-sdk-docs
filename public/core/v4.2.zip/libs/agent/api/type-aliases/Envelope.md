---
title: Envelope
editUrl: false
next: true
prev: true
---

> **Envelope**\<`T`\> = [`Signed`](../interfaces/Signed.md)\<`T`\> \| [`UnSigned`](../interfaces/UnSigned.md)\<`T`\>

Defined in: [packages/agent/src/agent/http/types.ts:53](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L53)

## Type Parameters

### T

`T`
