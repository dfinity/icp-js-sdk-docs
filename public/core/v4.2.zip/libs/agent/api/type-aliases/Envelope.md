---
title: Envelope
editUrl: false
next: true
prev: true
---

> **Envelope**\<`T`\> = [`Signed`](../interfaces/Signed.md)\<`T`\> \| [`UnSigned`](../interfaces/UnSigned.md)\<`T`\>

Defined in: [packages/agent/src/agent/http/types.ts:53](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/types.ts#L53)

## Type Parameters

### T

`T`
