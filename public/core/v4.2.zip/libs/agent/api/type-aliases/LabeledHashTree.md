---
title: LabeledHashTree
editUrl: false
next: true
prev: true
---

> **LabeledHashTree** = \[[`Labeled`](../enumerations/NodeType.md#labeled), [`NodeLabel`](NodeLabel.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/agent/src/certificate.ts:60](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L60)
