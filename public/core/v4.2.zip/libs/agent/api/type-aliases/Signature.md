---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/agent/src/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/auth.ts#L22)

A signature array buffer.

## Type declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
