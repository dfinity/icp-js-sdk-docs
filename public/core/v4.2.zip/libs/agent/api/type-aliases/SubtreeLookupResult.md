---
title: SubtreeLookupResult
editUrl: false
next: true
prev: true
---

> **SubtreeLookupResult** = [`LookupSubtreeResultAbsent`](../interfaces/LookupSubtreeResultAbsent.md) \| [`LookupSubtreeResultUnknown`](../interfaces/LookupSubtreeResultUnknown.md) \| [`LookupSubtreeResultFound`](../interfaces/LookupSubtreeResultFound.md)

Defined in: [packages/agent/src/certificate.ts:506](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L506)
