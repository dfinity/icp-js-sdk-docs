---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:55](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/certificate.ts#L55)

## Type declaration

### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
