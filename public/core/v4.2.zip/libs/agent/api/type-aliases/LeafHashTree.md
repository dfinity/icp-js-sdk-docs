---
title: LeafHashTree
editUrl: false
next: true
prev: true
---

> **LeafHashTree** = \[[`Leaf`](../enumerations/NodeType.md#leaf), [`NodeValue`](NodeValue.md)\]

Defined in: [packages/agent/src/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L61)
