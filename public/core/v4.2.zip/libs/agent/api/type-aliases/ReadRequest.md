---
title: ReadRequest
editUrl: false
next: true
prev: true
---

> **ReadRequest** = [`QueryRequest`](../interfaces/QueryRequest.md) \| [`ReadStateRequest`](../interfaces/ReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/agent/http/types.ts#L103)
