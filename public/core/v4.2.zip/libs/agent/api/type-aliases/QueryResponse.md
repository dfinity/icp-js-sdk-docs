---
title: QueryResponse
editUrl: false
next: true
prev: true
---

> **QueryResponse** = [`QueryResponseReplied`](../interfaces/QueryResponseReplied.md) \| [`QueryResponseRejected`](../interfaces/QueryResponseRejected.md)

Defined in: [packages/agent/src/agent/api.ts:32](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L32)
