---
title: PollStrategy
editUrl: false
next: true
prev: true
---

> **PollStrategy** = (`canisterId`, `requestId`, `status`) => `Promise`\<`void`\>

Defined in: [packages/agent/src/polling/index.ts:28](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/polling/index.ts#L28)

## Parameters

### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](RequestId.md)

### status

[`RequestStatusResponseStatus`](../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`void`\>
