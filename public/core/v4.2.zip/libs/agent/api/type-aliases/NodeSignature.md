---
title: NodeSignature
editUrl: false
next: true
prev: true
---

> **NodeSignature** = `object`

Defined in: [packages/agent/src/agent/api.ts:56](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L56)

## Properties

### identity

> **identity**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:62](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L62)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/agent/src/agent/api.ts:60](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L60)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/agent/src/agent/api.ts:58](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/api.ts#L58)
