---
title: PrunedHashTree
editUrl: false
next: true
prev: true
---

> **PrunedHashTree** = \[[`Pruned`](../enumerations/NodeType.md#pruned), [`NodeHash`](NodeHash.md)\]

Defined in: [packages/agent/src/certificate.ts:62](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L62)
