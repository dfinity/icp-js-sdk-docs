---
title: PrunedHashTree
editUrl: false
next: true
prev: true
---

> **PrunedHashTree** = \[[`Pruned`](../enumerations/NodeType.md#pruned), [`NodeHash`](NodeHash.md)\]

Defined in: [packages/agent/src/certificate.ts:62](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/certificate.ts#L62)
