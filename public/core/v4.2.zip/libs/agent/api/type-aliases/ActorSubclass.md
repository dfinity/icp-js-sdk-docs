---
title: ActorSubclass
editUrl: false
next: true
prev: true
---

> **ActorSubclass**\<`T`\> = [`Actor`](../classes/Actor.md) & `T`

Defined in: [packages/agent/src/actor.ts:100](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/actor.ts#L100)

A subclass of an actor. Actor class itself is meant to be a based class.

## Type Parameters

### T

`T` = `Record`\<`string`, [`ActorMethod`](../interfaces/ActorMethod.md)\>
