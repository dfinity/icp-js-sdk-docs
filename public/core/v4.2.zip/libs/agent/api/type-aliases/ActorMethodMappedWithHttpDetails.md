---
title: ActorMethodMappedWithHttpDetails
editUrl: false
next: true
prev: true
---

> **ActorMethodMappedWithHttpDetails**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodWithHttpDetails<Args, Ret> : never }`

Defined in: [packages/agent/src/actor.ts:136](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/agent/src/actor.ts#L136)

## Type Parameters

### T

`T`
