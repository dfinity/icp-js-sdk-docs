---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/agent/src/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/request_id.ts#L8)

## Type declaration

### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
