---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/agent/src/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/request_id.ts#L8)

## Type declaration

### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
