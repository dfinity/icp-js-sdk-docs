---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:54](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/agent/src/certificate.ts#L54)

## Type declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
