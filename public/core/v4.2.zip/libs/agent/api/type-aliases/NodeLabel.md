---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/agent/src/certificate.ts:54](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/agent/src/certificate.ts#L54)

## Type declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
