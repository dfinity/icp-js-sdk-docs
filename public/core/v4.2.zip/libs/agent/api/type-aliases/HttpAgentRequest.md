---
title: HttpAgentRequest
editUrl: false
next: true
prev: true
---

> **HttpAgentRequest** = [`HttpAgentQueryRequest`](../interfaces/HttpAgentQueryRequest.md) \| [`HttpAgentSubmitRequest`](../interfaces/HttpAgentSubmitRequest.md) \| [`HttpAgentReadStateRequest`](../interfaces/HttpAgentReadStateRequest.md)

Defined in: [packages/agent/src/agent/http/types.ts:16](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/agent/src/agent/http/types.ts#L16)
