---
title: DelegationValidChecks
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:357](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L357)

List of things to check for a delegation chain validity.

## Properties

### scope?

> `optional` **scope**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md) \| (`string` \| [`Principal`](../../../principal/api/classes/Principal.md))[]

Defined in: [packages/identity/src/identity/delegation.ts:361](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L361)

Check that the scope is amongst the scopes that this delegation has access to.
