---
title: JsonnableDelegationChain
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:132](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/identity/src/identity/delegation.ts#L132)

## Properties

### delegations

> **delegations**: `object`[]

Defined in: [packages/identity/src/identity/delegation.ts:134](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/identity/src/identity/delegation.ts#L134)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `string`

##### delegation.pubkey

> **pubkey**: `string`

##### delegation.targets?

> `optional` **targets**: `string`[]

#### signature

> **signature**: `string`

***

### publicKey

> **publicKey**: `string`

Defined in: [packages/identity/src/identity/delegation.ts:133](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/identity/src/identity/delegation.ts#L133)
