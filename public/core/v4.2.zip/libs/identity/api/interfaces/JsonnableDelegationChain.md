---
title: JsonnableDelegationChain
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:132](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/delegation.ts#L132)

## Properties

### delegations

> **delegations**: `object`[]

Defined in: [packages/identity/src/identity/delegation.ts:134](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/delegation.ts#L134)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `string`

##### delegation.pubkey

> **pubkey**: `string`

##### delegation.targets?

> `optional` **targets**: `string`[]

#### signature

> **signature**: `string`

***

### publicKey

> **publicKey**: `string`

Defined in: [packages/identity/src/identity/delegation.ts:133](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/delegation.ts#L133)
