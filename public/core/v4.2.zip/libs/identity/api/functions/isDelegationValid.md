---
title: isDelegationValid
editUrl: false
next: true
prev: true
---

> **isDelegationValid**(`chain`, `checks?`): `boolean`

Defined in: [packages/identity/src/identity/delegation.ts:370](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/delegation.ts#L370)

Analyze a DelegationChain and validate that it's valid, ie. not expired and apply to the
scope.

## Parameters

### chain

[`DelegationChain`](../classes/DelegationChain.md)

The chain to validate.

### checks?

[`DelegationValidChecks`](../interfaces/DelegationValidChecks.md)

Various checks to validate on the chain.

## Returns

`boolean`
