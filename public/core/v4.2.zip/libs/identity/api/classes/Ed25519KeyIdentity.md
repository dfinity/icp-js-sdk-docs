---
title: Ed25519KeyIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/ed25519.ts:109](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L109)

Ed25519KeyIdentity is an implementation of SignIdentity that uses Ed25519 keys. This class is used to sign and verify messages for an agent.

## Extends

- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new Ed25519KeyIdentity**(`publicKey`, `privateKey`): `Ed25519KeyIdentity`

Defined in: [packages/identity/src/identity/ed25519.ts:168](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L168)

#### Parameters

##### publicKey

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

##### privateKey

`Uint8Array`

#### Returns

`Ed25519KeyIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:52

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

## Methods

### getKeyPair()

> **getKeyPair**(): [`KeyPair`](../../../agent/api/interfaces/KeyPair.md)

Defined in: [packages/identity/src/identity/ed25519.ts:184](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L184)

Return a copy of the key pair.

#### Returns

[`KeyPair`](../../../agent/api/interfaces/KeyPair.md)

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: packages/agent/lib/esm/auth.d.ts:65

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): `Required`\<[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)\>

Defined in: [packages/identity/src/identity/ed25519.ts:194](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L194)

Return the public key.

#### Returns

`Required`\<[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`challenge`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [packages/identity/src/identity/ed25519.ts:202](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L202)

Signs a blob of data, with this identity's private key.

#### Parameters

##### challenge

`Uint8Array`

challenge to sign with this identity's secretKey, producing a signature

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### toJSON()

> **toJSON**(): [`JsonnableEd25519KeyIdentity`](../type-aliases/JsonnableEd25519KeyIdentity.md)

Defined in: [packages/identity/src/identity/ed25519.ts:177](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L177)

Serialize this key to JSON.

#### Returns

[`JsonnableEd25519KeyIdentity`](../type-aliases/JsonnableEd25519KeyIdentity.md)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: packages/agent/lib/esm/auth.d.ts:72

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### fromJSON()

> `static` **fromJSON**(`json`): `Ed25519KeyIdentity`

Defined in: [packages/identity/src/identity/ed25519.ts:143](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L143)

#### Parameters

##### json

`string`

#### Returns

`Ed25519KeyIdentity`

***

### fromKeyPair()

> `static` **fromKeyPair**(`publicKey`, `privateKey`): `Ed25519KeyIdentity`

Defined in: [packages/identity/src/identity/ed25519.ts:155](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L155)

#### Parameters

##### publicKey

`Uint8Array`

##### privateKey

`Uint8Array`

#### Returns

`Ed25519KeyIdentity`

***

### fromParsedJson()

> `static` **fromParsedJson**(`obj`): `Ed25519KeyIdentity`

Defined in: [packages/identity/src/identity/ed25519.ts:135](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L135)

#### Parameters

##### obj

[`JsonnableEd25519KeyIdentity`](../type-aliases/JsonnableEd25519KeyIdentity.md)

#### Returns

`Ed25519KeyIdentity`

***

### fromSecretKey()

> `static` **fromSecretKey**(`secretKey`): `Ed25519KeyIdentity`

Defined in: [packages/identity/src/identity/ed25519.ts:159](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L159)

#### Parameters

##### secretKey

`Uint8Array`

#### Returns

`Ed25519KeyIdentity`

***

### generate()

> `static` **generate**(`seed?`): `Ed25519KeyIdentity`

Defined in: [packages/identity/src/identity/ed25519.ts:115](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L115)

Generate a new Ed25519KeyIdentity.

#### Parameters

##### seed?

`Uint8Array`\<`ArrayBufferLike`\>

a 32-byte seed for the private key. If not provided, a random seed will be generated.

#### Returns

`Ed25519KeyIdentity`

Ed25519KeyIdentity

***

### verify()

> `static` **verify**(`sig`, `msg`, `pk`): `boolean`

Defined in: [packages/identity/src/identity/ed25519.ts:222](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/identity/src/identity/ed25519.ts#L222)

Verify

#### Parameters

##### sig

signature to verify

`string` | `ArrayBuffer` | `Uint8Array`\<`ArrayBufferLike`\>

##### msg

message to verify

`string` | `ArrayBuffer` | `Uint8Array`\<`ArrayBufferLike`\>

##### pk

public key

`string` | `ArrayBuffer` | `Uint8Array`\<`ArrayBufferLike`\>

#### Returns

`boolean`

- true if the signature is valid, false otherwise
