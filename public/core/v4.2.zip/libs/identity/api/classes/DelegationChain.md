---
title: DelegationChain
editUrl: false
next: true
prev: true
---

Defined in: [packages/identity/src/identity/delegation.ts:149](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L149)

A chain of delegations. This is JSON Serializable.
This is the object to serialize and pass to a DelegationIdentity. It does not keep any
private keys.

## Constructors

### Constructor

> `protected` **new DelegationChain**(`delegations`, `publicKey`): `DelegationChain`

Defined in: [packages/identity/src/identity/delegation.ts:243](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L243)

#### Parameters

##### delegations

[`SignedDelegation`](../interfaces/SignedDelegation.md)[]

##### publicKey

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Returns

`DelegationChain`

## Properties

### delegations

> `readonly` **delegations**: [`SignedDelegation`](../interfaces/SignedDelegation.md)[]

Defined in: [packages/identity/src/identity/delegation.ts:244](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L244)

***

### publicKey

> `readonly` **publicKey**: [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/identity/src/identity/delegation.ts:245](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L245)

## Methods

### toJSON()

> **toJSON**(): [`JsonnableDelegationChain`](../interfaces/JsonnableDelegationChain.md)

Defined in: [packages/identity/src/identity/delegation.ts:248](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L248)

#### Returns

[`JsonnableDelegationChain`](../interfaces/JsonnableDelegationChain.md)

***

### create()

> `static` **create**(`from`, `to`, `expiration`, `options`): `Promise`\<`DelegationChain`\>

Defined in: [packages/identity/src/identity/delegation.ts:179](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L179)

Create a delegation chain between two (or more) keys. By default, the expiration time
will be very short (15 minutes).

To build a chain of more than 2 identities, this function needs to be called multiple times,
passing the previous delegation chain into the options argument. For example:

#### Parameters

##### from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

The identity that will delegate.

##### to

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

The identity that gets delegated. It can now sign messages as if it was the
          identity above.

##### expiration

`Date` = `...`

The length the delegation is valid. By default, 15 minutes from calling
                  this function.

##### options

A set of options for this delegation. expiration and previous

###### previous?

`DelegationChain`

Another DelegationChain that this chain should start with.

###### targets?

[`Principal`](../../../principal/api/classes/Principal.md)[]

targets that scope the delegation (e.g. Canister Principals)

#### Returns

`Promise`\<`DelegationChain`\>

#### Example

```ts
const rootKey = createKey();
const middleKey = createKey();
const bottomeKey = createKey();

const rootToMiddle = await DelegationChain.create(
  root, middle.getPublicKey(), Date.parse('2100-01-01'),
);
const middleToBottom = await DelegationChain.create(
  middle, bottom.getPublicKey(), Date.parse('2100-01-01'), { previous: rootToMiddle },
);

// We can now use a delegation identity that uses the delegation above:
const identity = DelegationIdentity.fromDelegation(bottomKey, middleToBottom);
```

***

### fromDelegations()

> `static` **fromDelegations**(`delegations`, `publicKey`): `DelegationChain`

Defined in: [packages/identity/src/identity/delegation.ts:236](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L236)

Creates a DelegationChain object from a list of delegations and a DER-encoded public key.

#### Parameters

##### delegations

[`SignedDelegation`](../interfaces/SignedDelegation.md)[]

The list of delegations.

##### publicKey

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

The DER-encoded public key of the key-pair signing the first delegation.

#### Returns

`DelegationChain`

***

### fromJSON()

> `static` **fromJSON**(`json`): `DelegationChain`

Defined in: [packages/identity/src/identity/delegation.ts:199](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/delegation.ts#L199)

Creates a DelegationChain object from a JSON string.

#### Parameters

##### json

The JSON string to parse.

`string` | [`JsonnableDelegationChain`](../interfaces/JsonnableDelegationChain.md)

#### Returns

`DelegationChain`
