---
title: CryptoKeyOptions
editUrl: false
next: true
prev: true
---

> **CryptoKeyOptions** = `object`

Defined in: [packages/identity/src/identity/ecdsa.ts:12](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/ecdsa.ts#L12)

Options used in a [ECDSAKeyIdentity](../classes/ECDSAKeyIdentity.md)

## Properties

### extractable?

> `optional` **extractable**: `boolean`

Defined in: [packages/identity/src/identity/ecdsa.ts:13](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/ecdsa.ts#L13)

***

### keyUsages?

> `optional` **keyUsages**: `KeyUsage`[]

Defined in: [packages/identity/src/identity/ecdsa.ts:14](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/ecdsa.ts#L14)

***

### subtleCrypto?

> `optional` **subtleCrypto**: `SubtleCrypto`

Defined in: [packages/identity/src/identity/ecdsa.ts:15](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/identity/src/identity/ecdsa.ts#L15)
