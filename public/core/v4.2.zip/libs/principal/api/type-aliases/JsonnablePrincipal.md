---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

> **JsonnablePrincipal** = `object`

Defined in: [principal.ts:12](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/principal/src/principal.ts#L12)

## Properties

### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [principal.ts:13](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/principal/src/principal.ts#L13)
