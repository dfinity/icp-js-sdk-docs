---
title: base32Encode
editUrl: false
next: true
prev: true
---

> **base32Encode**(`input`): `string`

Defined in: [utils/base32.ts:17](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/principal/src/utils/base32.ts#L17)

## Parameters

### input

`Uint8Array`

The Uint8Array to encode.

## Returns

`string`

A Base32 string encoding the input.
