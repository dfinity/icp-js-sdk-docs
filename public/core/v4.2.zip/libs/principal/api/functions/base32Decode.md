---
title: base32Decode
editUrl: false
next: true
prev: true
---

> **base32Decode**(`input`): `Uint8Array`

Defined in: [utils/base32.ts:60](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/principal/src/utils/base32.ts#L60)

## Parameters

### input

`string`

The base32 encoded string to decode.

## Returns

`Uint8Array`
