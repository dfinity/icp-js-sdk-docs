---
title: JSON_KEY_PRINCIPAL
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_PRINCIPAL**: `"__principal__"` = `'__principal__'`

Defined in: [principal.ts:6](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/principal/src/principal.ts#L6)
