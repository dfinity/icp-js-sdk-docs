---
title: JsonValue
editUrl: false
next: true
prev: true
---

> **JsonValue** = `boolean` \| `string` \| `number` \| `bigint` \| [`JsonArray`](../interfaces/JsonArray.md) \| [`JsonObject`](../interfaces/JsonObject.md)

Defined in: [packages/candid/src/types.ts:7](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/types.ts#L7)
