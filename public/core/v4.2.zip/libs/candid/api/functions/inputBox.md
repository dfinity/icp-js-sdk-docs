---
title: inputBox
editUrl: false
next: true
prev: true
---

> **inputBox**(`t`, `config`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:12](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/candid-ui.ts#L12)

## Parameters

### t

[`Type`](../namespaces/IDL/classes/Type.md)

### config

`Partial`\<[`UIConfig`](../interfaces/UIConfig.md)\>

## Returns

[`InputBox`](../classes/InputBox.md)
