---
title: lebEncode
editUrl: false
next: true
prev: true
---

> **lebEncode**(`value`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:44](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/utils/leb128.ts#L44)

Encode a positive number (or bigint) into a Buffer. The number will be floored to the
nearest integer.

## Parameters

### value

The number to encode.

`number` | `bigint`

## Returns

`Uint8Array`
