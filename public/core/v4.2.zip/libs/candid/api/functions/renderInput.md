---
title: renderInput
editUrl: false
next: true
prev: true
---

> **renderInput**(`t`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/candid/src/candid-ui.ts:208](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/candid-ui.ts#L208)

## Parameters

### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL type

## Returns

[`InputBox`](../classes/InputBox.md)

an input for that type
