---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/candid/src/utils/buffer.ts:153](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/utils/buffer.ts#L153)

Returns a true Uint8Array from an ArrayBufferLike object.

## Parameters

### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `DataView`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | \[`number`\] | `number`[] | \{ `buffer`: `ArrayBuffer`; \}

## Returns

`Uint8Array`

Uint8Array
