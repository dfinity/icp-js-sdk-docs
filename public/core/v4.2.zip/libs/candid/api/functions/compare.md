---
title: compare
editUrl: false
next: true
prev: true
---

> **compare**(`u1`, `u2`): `number`

Defined in: [packages/candid/src/utils/buffer.ts:189](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/utils/buffer.ts#L189)

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`number`

number - negative if u1 < u2, positive if u1 > u2, 0 if u1 === u2
