---
title: variantForm
editUrl: false
next: true
prev: true
---

> **variantForm**(`fields`, `config`): [`VariantForm`](../classes/VariantForm.md)

Defined in: [packages/candid/src/candid-ui.ts:21](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/candid-ui.ts#L21)

## Parameters

### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VariantForm`](../classes/VariantForm.md)
