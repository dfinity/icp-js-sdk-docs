---
title: variantForm
editUrl: false
next: true
prev: true
---

> **variantForm**(`fields`, `config`): [`VariantForm`](../classes/VariantForm.md)

Defined in: [packages/candid/src/candid-ui.ts:21](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/candid-ui.ts#L21)

## Parameters

### fields

\[`string`, [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>\][]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`VariantForm`](../classes/VariantForm.md)
