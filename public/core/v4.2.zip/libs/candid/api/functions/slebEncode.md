---
title: slebEncode
editUrl: false
next: true
prev: true
---

> **slebEncode**(`value`): `Uint8Array`

Defined in: [packages/candid/src/utils/leb128.ts:93](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/utils/leb128.ts#L93)

Encode a number (or bigint) into a Buffer, with support for negative numbers. The number
will be floored to the nearest integer.

## Parameters

### value

The number to encode.

`number` | `bigint`

## Returns

`Uint8Array`
