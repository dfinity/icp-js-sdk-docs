---
title: subtype
editUrl: false
next: true
prev: true
---

> **subtype**(`t1`, `t2`): `boolean`

Defined in: [packages/candid/src/idl.ts:2472](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2472)

Subtyping on Candid types t1 <: t2 (Exported for testing)

## Parameters

### t1

[`Type`](../classes/Type.md)

The potential subtype

### t2

[`Type`](../classes/Type.md)

The potential supertype

## Returns

`boolean`
