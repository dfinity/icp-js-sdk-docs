---
title: Opt
editUrl: false
next: true
prev: true
---

> **Opt**\<`T`\>(`t`): [`OptClass`](../classes/OptClass.md)\<`T`\>

Defined in: [packages/candid/src/idl.ts:2333](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/idl.ts#L2333)

## Type Parameters

### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`OptClass`](../classes/OptClass.md)\<`T`\>

OptClass of Type
