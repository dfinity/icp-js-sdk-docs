---
title: Rec
editUrl: false
next: true
prev: true
---

> **Rec**(): [`RecClass`](../classes/RecClass.md)

Defined in: [packages/candid/src/idl.ts:2357](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2357)

## Returns

[`RecClass`](../classes/RecClass.md)

new RecClass
