---
title: Record
editUrl: false
next: true
prev: true
---

> **Record**(`t`): [`RecordClass`](../classes/RecordClass.md)

Defined in: [packages/candid/src/idl.ts:2341](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L2341)

## Parameters

### t

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`RecordClass`](../classes/RecordClass.md)

RecordClass of string and Type
