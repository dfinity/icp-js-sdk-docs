---
title: decode
editUrl: false
next: true
prev: true
---

> **decode**(`retTypes`, `bytes`): [`JsonValue`](../../../type-aliases/JsonValue.md)[]

Defined in: [packages/candid/src/idl.ts:1984](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/idl.ts#L1984)

Decode a binary value

## Parameters

### retTypes

[`Type`](../classes/Type.md)\<`any`\>[]

Types expected in the buffer.

### bytes

`Uint8Array`

hex-encoded string, or buffer.

## Returns

[`JsonValue`](../../../type-aliases/JsonValue.md)[]

Value deserialised to JS type
