---
title: Float64
editUrl: false
next: true
prev: true
---

> `const` **Float64**: [`FloatClass`](../classes/FloatClass.md)

Defined in: [packages/candid/src/idl.ts:2298](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2298)
