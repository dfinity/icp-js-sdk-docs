---
title: PrincipalClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:1676](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1676)

Represents an IDL principal reference

## Extends

- [`PrimitiveType`](PrimitiveType.md)\<[`Principal`](../../../../../principal/api/classes/Principal.md)\>

## Constructors

### Constructor

> **new PrincipalClass**(): `PrincipalClass`

#### Returns

`PrincipalClass`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`constructor`](PrimitiveType.md#constructor)

## Accessors

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/candid/src/idl.ts:1708](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1708)

##### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`name`](PrimitiveType.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:1677](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1677)

##### Returns

`IdlTypeName`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`typeName`](PrimitiveType.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:286](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L286)

#### Parameters

##### \_typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`_buildTypeTableImpl`](PrimitiveType.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:1685](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1685)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`accept`](PrimitiveType.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`buildTypeTable`](PrimitiveType.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`Type`](Type.md)

Defined in: [packages/candid/src/idl.ts:279](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L279)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`checkType`](PrimitiveType.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is Principal`

Defined in: [packages/candid/src/idl.ts:1689](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1689)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is Principal`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`covariant`](PrimitiveType.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/candid/src/idl.ts:1703](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1703)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

[`Principal`](../../../../../principal/api/classes/Principal.md)

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`decodeValue`](PrimitiveType.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:237](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L237)

#### Returns

`string`

#### Inherited from

[`PrimitiveType`](PrimitiveType.md).[`display`](PrimitiveType.md#display)

***

### encodeType()

> **encodeType**(): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1699](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1699)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeType`](PrimitiveType.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1694](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1694)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

[`Principal`](../../../../../principal/api/classes/Principal.md)

#### Returns

`Uint8Array`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`encodeValue`](PrimitiveType.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:1711](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1711)

#### Parameters

##### x

[`Principal`](../../../../../principal/api/classes/Principal.md)

#### Returns

`string`

#### Overrides

[`PrimitiveType`](PrimitiveType.md).[`valueToString`](PrimitiveType.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**(`instance`): `instance is PrincipalClass`

Defined in: [packages/candid/src/idl.ts:1681](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1681)

#### Parameters

##### instance

`any`

#### Returns

`instance is PrincipalClass`
