---
title: Service
editUrl: false
next: true
prev: true
---

> **Service**\<`K`, `Fields`\>(`t`): [`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

Defined in: [packages/candid/src/idl.ts:2380](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2380)

## Type Parameters

### K

`K` *extends* `string` = `string`

### Fields

`Fields` *extends* [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md) = [`GenericIdlServiceFields`](../type-aliases/GenericIdlServiceFields.md)

## Parameters

### t

`Fields`

Record of string and FuncClass

## Returns

[`ServiceClass`](../classes/ServiceClass.md)\<`K`, `Fields`\>

ServiceClass
