---
title: PrimitiveType
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/idl.ts:278](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L278)

Represents an IDL type.

## Extends

- [`Type`](Type.md)\<`T`\>

## Extended by

- [`EmptyClass`](EmptyClass.md)
- [`BoolClass`](BoolClass.md)
- [`NullClass`](NullClass.md)
- [`ReservedClass`](ReservedClass.md)
- [`TextClass`](TextClass.md)
- [`IntClass`](IntClass.md)
- [`NatClass`](NatClass.md)
- [`FloatClass`](FloatClass.md)
- [`FixedIntClass`](FixedIntClass.md)
- [`FixedNatClass`](FixedNatClass.md)
- [`PrincipalClass`](PrincipalClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new PrimitiveType**\<`T`\>(): `PrimitiveType`\<`T`\>

#### Returns

`PrimitiveType`\<`T`\>

#### Inherited from

[`Type`](Type.md).[`constructor`](Type.md#constructor)

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/candid/src/idl.ts:233](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L233)

#### Inherited from

[`Type`](Type.md).[`name`](Type.md#name)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/candid/src/idl.ts:232](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L232)

#### Inherited from

[`Type`](Type.md).[`typeName`](Type.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`_typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:286](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L286)

#### Parameters

##### \_typeTable

`TypeTable`

#### Returns

`void`

#### Overrides

[`Type`](Type.md).[`_buildTypeTableImpl`](Type.md#_buildtypetableimpl)

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/candid/src/idl.ts:234](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L234)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Inherited from

[`Type`](Type.md).[`accept`](Type.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/candid/src/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L246)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`buildTypeTable`](Type.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`Type`](Type.md)

Defined in: [packages/candid/src/idl.ts:279](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L279)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`Type`](Type.md)

#### Overrides

[`Type`](Type.md).[`checkType`](Type.md#checktype)

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/candid/src/idl.ts:256](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L256)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Inherited from

[`Type`](Type.md).[`covariant`](Type.md#covariant)

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/candid/src/idl.ts:273](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L273)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Inherited from

[`Type`](Type.md).[`decodeValue`](Type.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/candid/src/idl.ts:237](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L237)

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`display`](Type.md#display)

***

### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:269](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L269)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`

#### Inherited from

[`Type`](Type.md).[`encodeType`](Type.md#encodetype)

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:263](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L263)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

#### Inherited from

[`Type`](Type.md).[`encodeValue`](Type.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/candid/src/idl.ts:241](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L241)

#### Parameters

##### x

`T`

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`valueToString`](Type.md#valuetostring)
