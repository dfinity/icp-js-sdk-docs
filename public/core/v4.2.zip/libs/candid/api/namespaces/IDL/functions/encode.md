---
title: encode
editUrl: false
next: true
prev: true
---

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1950](https://github.com/dfinity/icp-js-core/blob/21dcf8590333ed6762ba6aa87335c9637abd26c8/packages/candid/src/idl.ts#L1950)

Encode a array of values

## Parameters

### argTypes

[`Type`](../classes/Type.md)\<`any`\>[]

array of Types

### args

`any`[]

array of values

## Returns

`Uint8Array`

serialised value
