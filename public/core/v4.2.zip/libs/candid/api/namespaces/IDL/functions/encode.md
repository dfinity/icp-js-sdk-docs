---
title: encode
editUrl: false
next: true
prev: true
---

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/candid/src/idl.ts:1950](https://github.com/dfinity/icp-js-core/blob/354704a87c15672a2bd40ad51d046e20af055163/packages/candid/src/idl.ts#L1950)

Encode a array of values

## Parameters

### argTypes

[`Type`](../classes/Type.md)\<`any`\>[]

array of Types

### args

`any`[]

array of values

## Returns

`Uint8Array`

serialised value
