---
title: GenericIdlFuncArgs
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncArgs** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/candid/src/idl.ts:1719](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L1719)

The generic type of the arguments of an [IDL Function](../functions/Func.md).
