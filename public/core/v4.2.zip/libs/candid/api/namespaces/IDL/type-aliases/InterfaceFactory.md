---
title: InterfaceFactory
editUrl: false
next: true
prev: true
---

> **InterfaceFactory** = (`idl`) => [`ServiceClass`](../classes/ServiceClass.md)

Defined in: [packages/candid/src/idl.ts:2246](https://github.com/dfinity/icp-js-core/blob/7122f003c6931eb0b590d149b1605a5c4f543f0d/packages/candid/src/idl.ts#L2246)

An Interface Factory, normally provided by a Candid code generation.

## Parameters

### idl

#### IDL

\{ `Bool`: [`BoolClass`](../classes/BoolClass.md); `Empty`: [`EmptyClass`](../classes/EmptyClass.md); `Float32`: [`FloatClass`](../classes/FloatClass.md); `Float64`: [`FloatClass`](../classes/FloatClass.md); `Func`: *typeof* [`Func`](../functions/Func.md); `Int`: [`IntClass`](../classes/IntClass.md); `Int16`: [`FixedIntClass`](../classes/FixedIntClass.md); `Int32`: [`FixedIntClass`](../classes/FixedIntClass.md); `Int64`: [`FixedIntClass`](../classes/FixedIntClass.md); `Int8`: [`FixedIntClass`](../classes/FixedIntClass.md); `Nat`: [`NatClass`](../classes/NatClass.md); `Nat16`: [`FixedNatClass`](../classes/FixedNatClass.md); `Nat32`: [`FixedNatClass`](../classes/FixedNatClass.md); `Nat64`: [`FixedNatClass`](../classes/FixedNatClass.md); `Nat8`: [`FixedNatClass`](../classes/FixedNatClass.md); `Null`: [`NullClass`](../classes/NullClass.md); `Opt`: *typeof* [`Opt`](../functions/Opt.md); `Principal`: [`PrincipalClass`](../classes/PrincipalClass.md); `Rec`: *typeof* [`Rec`](../functions/Rec.md); `Record`: *typeof* [`Record`](../functions/Record.md); `Reserved`: [`ReservedClass`](../classes/ReservedClass.md); `Text`: [`TextClass`](../classes/TextClass.md); `Tuple`: *typeof* [`Tuple`](../functions/Tuple.md); `Unknown`: [`UnknownClass`](../classes/UnknownClass.md); `Variant`: *typeof* [`Variant`](../functions/Variant.md); `Vec`: *typeof* [`Vec`](../functions/Vec.md); `Service`: [`ServiceClass`](../classes/ServiceClass.md); \}

#### IDL.Bool

[`BoolClass`](../classes/BoolClass.md)

#### IDL.Empty

[`EmptyClass`](../classes/EmptyClass.md)

#### IDL.Float32

[`FloatClass`](../classes/FloatClass.md)

#### IDL.Float64

[`FloatClass`](../classes/FloatClass.md)

#### IDL.Func

*typeof* [`Func`](../functions/Func.md)

#### IDL.Int

[`IntClass`](../classes/IntClass.md)

#### IDL.Int16

[`FixedIntClass`](../classes/FixedIntClass.md)

#### IDL.Int32

[`FixedIntClass`](../classes/FixedIntClass.md)

#### IDL.Int64

[`FixedIntClass`](../classes/FixedIntClass.md)

#### IDL.Int8

[`FixedIntClass`](../classes/FixedIntClass.md)

#### IDL.Nat

[`NatClass`](../classes/NatClass.md)

#### IDL.Nat16

[`FixedNatClass`](../classes/FixedNatClass.md)

#### IDL.Nat32

[`FixedNatClass`](../classes/FixedNatClass.md)

#### IDL.Nat64

[`FixedNatClass`](../classes/FixedNatClass.md)

#### IDL.Nat8

[`FixedNatClass`](../classes/FixedNatClass.md)

#### IDL.Null

[`NullClass`](../classes/NullClass.md)

#### IDL.Opt

*typeof* [`Opt`](../functions/Opt.md)

#### IDL.Principal

[`PrincipalClass`](../classes/PrincipalClass.md)

#### IDL.Rec

*typeof* [`Rec`](../functions/Rec.md)

#### IDL.Record

*typeof* [`Record`](../functions/Record.md)

#### IDL.Reserved

[`ReservedClass`](../classes/ReservedClass.md)

#### IDL.Text

[`TextClass`](../classes/TextClass.md)

#### IDL.Tuple

*typeof* [`Tuple`](../functions/Tuple.md)

#### IDL.Unknown

[`UnknownClass`](../classes/UnknownClass.md)

#### IDL.Variant

*typeof* [`Variant`](../functions/Variant.md)

#### IDL.Vec

*typeof* [`Vec`](../functions/Vec.md)

#### IDL.Service

## Returns

[`ServiceClass`](../classes/ServiceClass.md)
