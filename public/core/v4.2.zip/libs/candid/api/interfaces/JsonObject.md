---
title: JsonObject
editUrl: false
next: true
prev: true
---

Defined in: [packages/candid/src/types.ts:5](https://github.com/dfinity/icp-js-core/blob/f80905d4f24c158a3a287fb9cc53dd754c1527a4/packages/candid/src/types.ts#L5)

## Extends

- `Record`\<`string`, [`JsonValue`](../type-aliases/JsonValue.md)\>

## Indexable

\[`key`: `string`\]: [`JsonValue`](../type-aliases/JsonValue.md)
