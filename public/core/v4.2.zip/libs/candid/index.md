---
title: Candid
editUrl: false
next: true
prev: true
---


JavaScript and TypeScript module to work with Candid interfaces

## Usage

```ts
import { IDL } from '@icp-sdk/core/candid';
```

## API Reference

Additional API Documentation can be found [here](https://js.icp.build/core/latest/libs/candid/api).

## Modules

- [api](api/index.md)
