---
title: base32Decode
editUrl: false
next: true
prev: true
---

> **base32Decode**(`input`): `Uint8Array`

Defined in: [packages/core/src/principal/utils/base32.ts:60](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/principal/utils/base32.ts#L60)

## Parameters

### input

`string`

The base32 encoded string to decode.

## Returns

`Uint8Array`
