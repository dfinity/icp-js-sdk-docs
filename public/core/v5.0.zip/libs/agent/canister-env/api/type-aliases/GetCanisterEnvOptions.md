---
title: GetCanisterEnvOptions
editUrl: false
next: true
prev: true
---

> **GetCanisterEnvOptions** = `object`

Defined in: [packages/core/src/agent/canister-env/index.ts:73](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canister-env/index.ts#L73)

**`Experimental`**

Options for the [getCanisterEnv](../functions/getCanisterEnv.md) function

## Properties

### cookieName?

> `optional` **cookieName**: `string`

Defined in: [packages/core/src/agent/canister-env/index.ts:78](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canister-env/index.ts#L78)

The name of the cookie to get the environment variables from.

#### Default

```ts
'ic_env'
```
