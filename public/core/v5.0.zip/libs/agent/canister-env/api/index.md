---
title: Overview
editUrl: false
next: true
prev: true
---

**`Experimental`**

## See

https://js.icp.build/core/latest/canister-environment

## Interfaces

- [CanisterEnv](interfaces/CanisterEnv.md)

## Type Aliases

- [GetCanisterEnvOptions](type-aliases/GetCanisterEnvOptions.md)

## Functions

- [getCanisterEnv](functions/getCanisterEnv.md)
- [safeGetCanisterEnv](functions/safeGetCanisterEnv.md)
