---
title: ACTOR_METHOD_WITH_CERTIFICATE
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/core/src/agent/actor.ts:365](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L365)
