---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/core/src/agent/errors.ts:882](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L882)

Special error used to indicate that a code path is unreachable.

For internal use only.
