---
title: IC_RESPONSE_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/constants.ts:17](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/constants.ts#L17)

The `\x0Bic-response` domain separator used in the signature of IC responses.
