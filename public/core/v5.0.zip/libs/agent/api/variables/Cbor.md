---
title: Cbor
editUrl: false
next: true
prev: true
---

> `const` **Cbor**: `object`

Defined in: [packages/core/src/agent/cbor.ts:60](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/cbor.ts#L60)

## Type declaration

### decode()

> **decode**: \<`T`\>(`input`) => `T`

Decode a CBOR encoded value into a JavaScript value.

#### Type Parameters

##### T

`T`

#### Parameters

##### input

`Uint8Array`

The CBOR encoded value

#### Returns

`T`

### encode()

> **encode**: (`value`) => `Uint8Array`

Encode a JavaScript value into CBOR. If the value is an instance of [ToCborValue](../classes/ToCborValue.md),
the [ToCborValue.toCborValue](../classes/ToCborValue.md#tocborvalue) method will be called to get the value to encode.

#### Parameters

##### value

`unknown`

The value to encode

#### Returns

`Uint8Array`
