---
title: ACTOR_METHOD_WITH_HTTP_DETAILS
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_HTTP\_DETAILS**: `"http-details"` = `'http-details'`

Defined in: [packages/core/src/agent/actor.ts:364](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/actor.ts#L364)
