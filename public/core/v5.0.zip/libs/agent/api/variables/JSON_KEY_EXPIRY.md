---
title: JSON_KEY_EXPIRY
editUrl: false
next: true
prev: true
---

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/core/src/agent/agent/http/transforms.ts:12](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/transforms.ts#L12)
