---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/core/src/agent/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L139)

Create an IdentityDescriptor from an Identity

## Parameters

### identity

identity describe in returned descriptor

[`SignIdentity`](../classes/SignIdentity.md) | [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
