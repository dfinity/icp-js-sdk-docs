---
title: lookupResultToBuffer
editUrl: false
next: true
prev: true
---

> **lookupResultToBuffer**(`result`): `undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/certificate.ts:465](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L465)

Utility function to constrain the type of a lookup result

## Parameters

### result

[`LookupResult`](../type-aliases/LookupResult.md)

the result of a lookup

## Returns

`undefined` \| `Uint8Array`\<`ArrayBufferLike`\>

the value if the lookup was found, `undefined` otherwise
