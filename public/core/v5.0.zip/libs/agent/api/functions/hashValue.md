---
title: hashValue
editUrl: false
next: true
prev: true
---

> **hashValue**(`value`): `Uint8Array`

Defined in: [packages/core/src/agent/request\_id.ts:19](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/request_id.ts#L19)

## Parameters

### value

`unknown`

unknown value

## Returns

`Uint8Array`

Uint8Array
