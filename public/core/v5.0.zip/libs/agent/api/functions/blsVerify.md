---
title: blsVerify
editUrl: false
next: true
prev: true
---

> **blsVerify**(`pk`, `sig`, `msg`): `boolean`

Defined in: [packages/core/src/agent/utils/bls.ts:13](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/bls.ts#L13)

## Parameters

### pk

`Uint8Array`

primary key: Uint8Array

### sig

`Uint8Array`

signature: Uint8Array

### msg

`Uint8Array`

message: Uint8Array

## Returns

`boolean`

boolean
