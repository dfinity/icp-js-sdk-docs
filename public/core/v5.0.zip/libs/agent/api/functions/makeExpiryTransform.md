---
title: makeExpiryTransform
editUrl: false
next: true
prev: true
---

> **makeExpiryTransform**(`delayInMilliseconds`): [`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)

Defined in: [packages/core/src/agent/agent/http/transforms.ts:141](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/transforms.ts#L141)

Create a transform that adds a delay (by default 5 minutes) to the expiry.

## Parameters

### delayInMilliseconds

`number`

The delay to add to the call time, in milliseconds.

## Returns

[`HttpAgentRequestTransformFn`](../interfaces/HttpAgentRequestTransformFn.md)
