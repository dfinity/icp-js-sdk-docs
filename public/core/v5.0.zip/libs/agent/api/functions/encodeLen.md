---
title: encodeLen
editUrl: false
next: true
prev: true
---

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/core/src/agent/der.ts:23](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/der.ts#L23)

## Parameters

### buf

`Uint8Array`

### offset

`number`

### len

`number`

## Returns

`number`
