---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:56](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/der.ts#L56)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
