---
title: pollForResponse
editUrl: false
next: true
prev: true
---

> **pollForResponse**(`agent`, `canisterId`, `requestId`, `options`): `Promise`\<\{ `certificate`: [`Certificate`](../classes/Certificate.md); `reply`: `Uint8Array`; \}\>

Defined in: [packages/core/src/agent/polling/index.ts:126](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/polling/index.ts#L126)

Polls the IC to check the status of the given request then
returns the response bytes once the request has been processed.

## Parameters

### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to poll read_state.

### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

The effective canister ID.

### requestId

[`RequestId`](../type-aliases/RequestId.md)

The Request ID to poll status for.

### options

[`PollingOptions`](../interfaces/PollingOptions.md) = `{}`

polling options to control behavior

## Returns

`Promise`\<\{ `certificate`: [`Certificate`](../classes/Certificate.md); `reply`: `Uint8Array`; \}\>
