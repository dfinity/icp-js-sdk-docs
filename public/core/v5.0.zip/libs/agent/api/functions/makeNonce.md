---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L111)

Create a random Nonce, based on random values

## Returns

[`Nonce`](../type-aliases/Nonce.md)
