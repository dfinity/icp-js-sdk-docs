---
title: randomNumber
editUrl: false
next: true
prev: true
---

> **randomNumber**(): `number`

Defined in: [packages/core/src/agent/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff

## Returns

`number`

a random number
