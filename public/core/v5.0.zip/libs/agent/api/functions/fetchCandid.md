---
title: fetchCandid
editUrl: false
next: true
prev: true
---

> **fetchCandid**(`canisterId`, `agent?`): `Promise`\<`string`\>

Defined in: [packages/core/src/agent/fetch\_candid.ts:13](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/fetch_candid.ts#L13)

Retrieves the Candid interface for the specified canister.

## Parameters

### canisterId

`string`

A string corresponding to the canister ID

### agent?

[`HttpAgent`](../classes/HttpAgent.md)

The agent to use for the request (usually an `HttpAgent`)

## Returns

`Promise`\<`string`\>

Candid source code
