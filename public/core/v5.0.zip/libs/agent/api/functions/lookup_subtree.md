---
title: lookup_subtree
editUrl: false
next: true
prev: true
---

> **lookup\_subtree**(`path`, `tree`): [`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

Defined in: [packages/core/src/agent/certificate.ts:694](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L694)

Lookup a subtree in a tree.

## Parameters

### path

[`NodePath`](../type-aliases/NodePath.md)

the path to look up

### tree

[`HashTree`](../type-aliases/HashTree.md)

the tree to search

## Returns

[`SubtreeLookupResult`](../type-aliases/SubtreeLookupResult.md)

the result of the lookup
