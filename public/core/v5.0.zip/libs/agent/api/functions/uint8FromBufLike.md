---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/agent/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.

## Parameters

### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `number`[] | `DataView`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | \[`number`\] | \{ `buffer`: `ArrayBuffer`; \}

## Returns

`Uint8Array`

Uint8Array
