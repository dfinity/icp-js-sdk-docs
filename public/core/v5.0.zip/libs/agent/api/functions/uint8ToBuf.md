---
title: uint8ToBuf
editUrl: false
next: true
prev: true
---

> **uint8ToBuf**(`arr`): `ArrayBuffer`

Defined in: [packages/core/src/agent/utils/buffer.ts:41](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/buffer.ts#L41)

Returns a true ArrayBuffer from a Uint8Array, as Uint8Array.buffer is unsafe.

## Parameters

### arr

`Uint8Array`

Uint8Array to convert

## Returns

`ArrayBuffer`

ArrayBuffer
