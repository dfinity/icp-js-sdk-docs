---
title: hashOfMap
editUrl: false
next: true
prev: true
---

> **hashOfMap**(`map`): `Uint8Array`

Defined in: [packages/core/src/agent/request\_id.ts:73](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/request_id.ts#L73)

Hash a map into a Uint8Array using the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

## Parameters

### map

`Record`\<`string`, `unknown`\>

Any non-nested object

## Returns

`Uint8Array`

Uint8Array
