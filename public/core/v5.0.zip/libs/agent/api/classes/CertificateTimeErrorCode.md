---
title: CertificateTimeErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:216](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L216)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new CertificateTimeErrorCode**(`maxAgeInMinutes`, `certificateTime`, `currentTime`, `timeDiffMsecs`, `ageType`): `CertificateTimeErrorCode`

Defined in: [packages/core/src/agent/errors.ts:219](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L219)

#### Parameters

##### maxAgeInMinutes

`number`

##### certificateTime

`Date`

##### currentTime

`Date`

##### timeDiffMsecs

`number`

##### ageType

`"past"` | `"future"`

#### Returns

`CertificateTimeErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### ageType

> `readonly` **ageType**: `"past"` \| `"future"`

Defined in: [packages/core/src/agent/errors.ts:224](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L224)

***

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/core/src/agent/errors.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L40)

#### Inherited from

`ErrorCode.callContext`

***

### certificateTime

> `readonly` **certificateTime**: `Date`

Defined in: [packages/core/src/agent/errors.ts:221](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L221)

***

### currentTime

> `readonly` **currentTime**: `Date`

Defined in: [packages/core/src/agent/errors.ts:222](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L222)

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L42)

#### Inherited from

`ErrorCode.isCertified`

***

### maxAgeInMinutes

> `readonly` **maxAgeInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:220](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L220)

***

### name

> **name**: `string` = `'CertificateTimeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:217](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L217)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L39)

#### Inherited from

`ErrorCode.requestContext`

***

### timeDiffMsecs

> `readonly` **timeDiffMsecs**: `number`

Defined in: [packages/core/src/agent/errors.ts:223](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L223)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:230](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L230)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L46)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
