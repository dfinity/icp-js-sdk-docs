---
title: UncertifiedRejectErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:507](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L507)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new UncertifiedRejectErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`, `signatures`): `UncertifiedRejectErrorCode`

Defined in: [packages/core/src/agent/errors.ts:510](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L510)

#### Parameters

##### requestId

[`RequestId`](../type-aliases/RequestId.md)

##### rejectCode

[`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

##### rejectMessage

`string`

##### rejectErrorCode

`undefined` | `string`

##### signatures

`undefined` | [`NodeSignature`](../type-aliases/NodeSignature.md)[]

#### Returns

`UncertifiedRejectErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/core/src/agent/errors.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L40)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L42)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'UncertifiedRejectErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:508](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L508)

***

### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](../enumerations/ReplicaRejectCode.md)

Defined in: [packages/core/src/agent/errors.ts:512](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L512)

***

### rejectErrorCode

> `readonly` **rejectErrorCode**: `undefined` \| `string`

Defined in: [packages/core/src/agent/errors.ts:514](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L514)

***

### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:513](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L513)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L39)

#### Inherited from

`ErrorCode.requestContext`

***

### requestId

> `readonly` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:511](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L511)

***

### signatures

> `readonly` **signatures**: `undefined` \| [`NodeSignature`](../type-aliases/NodeSignature.md)[]

Defined in: [packages/core/src/agent/errors.ts:515](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L515)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:521](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L521)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L46)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
