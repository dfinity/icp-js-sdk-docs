---
title: SignIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/auth.ts:57](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L57)

An Identity that can sign blobs.

## Extended by

- [`Ed25519KeyIdentity`](../../../identity/api/classes/Ed25519KeyIdentity.md)
- [`ECDSAKeyIdentity`](../../../identity/api/classes/ECDSAKeyIdentity.md)
- [`DelegationIdentity`](../../../identity/api/classes/DelegationIdentity.md)
- [`Secp256k1KeyIdentity`](../../../identity/secp256k1/api/classes/Secp256k1KeyIdentity.md)
- [`WebAuthnIdentity`](../../../identity/api/classes/WebAuthnIdentity.md)

## Implements

- [`Identity`](../interfaces/Identity.md)

## Constructors

### Constructor

> **new SignIdentity**(): `SignIdentity`

#### Returns

`SignIdentity`

## Properties

### \_principal

> `protected` **\_principal**: `undefined` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/auth.ts:58](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L58)

## Methods

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/auth.ts:74](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L74)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Implementation of

[`Identity`](../interfaces/Identity.md).[`getPrincipal`](../interfaces/Identity.md#getprincipal)

***

### getPublicKey()

> `abstract` **getPublicKey**(): [`PublicKey`](../interfaces/PublicKey.md)

Defined in: [packages/core/src/agent/auth.ts:63](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L63)

Returns the public key that would match this identity's signature.

#### Returns

[`PublicKey`](../interfaces/PublicKey.md)

***

### sign()

> `abstract` **sign**(`blob`): `Promise`\<[`Signature`](../type-aliases/Signature.md)\>

Defined in: [packages/core/src/agent/auth.ts:68](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L68)

Signs a blob of data, with this identity's private key.

#### Parameters

##### blob

`Uint8Array`

#### Returns

`Promise`\<[`Signature`](../type-aliases/Signature.md)\>

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:87](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L87)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Implementation of

[`Identity`](../interfaces/Identity.md).[`transformRequest`](../interfaces/Identity.md#transformrequest)
