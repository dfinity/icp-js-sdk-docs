---
title: InvalidReadStateRequestErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:798](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L798)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new InvalidReadStateRequestErrorCode**(`request`): `InvalidReadStateRequestErrorCode`

Defined in: [packages/core/src/agent/errors.ts:801](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L801)

#### Parameters

##### request

`unknown`

#### Returns

`InvalidReadStateRequestErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/core/src/agent/errors.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L40)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L42)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'InvalidReadStateRequestErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:799](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L799)

***

### request

> `readonly` **request**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:801](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L801)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L39)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:806](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L806)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L46)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
