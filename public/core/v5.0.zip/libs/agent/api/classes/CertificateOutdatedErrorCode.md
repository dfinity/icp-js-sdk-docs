---
title: CertificateOutdatedErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:462](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L462)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new CertificateOutdatedErrorCode**(`maxIngressExpiryInMinutes`, `requestId`, `retryTimes?`): `CertificateOutdatedErrorCode`

Defined in: [packages/core/src/agent/errors.ts:465](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L465)

#### Parameters

##### maxIngressExpiryInMinutes

`number`

##### requestId

[`RequestId`](../type-aliases/RequestId.md)

##### retryTimes?

`number`

#### Returns

`CertificateOutdatedErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../type-aliases/CallContext.md)

Defined in: [packages/core/src/agent/errors.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L40)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L42)

#### Inherited from

`ErrorCode.isCertified`

***

### maxIngressExpiryInMinutes

> `readonly` **maxIngressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:466](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L466)

***

### name

> **name**: `string` = `'CertificateOutdatedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:463](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L463)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../type-aliases/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L39)

#### Inherited from

`ErrorCode.requestContext`

***

### requestId

> `readonly` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:467](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L467)

***

### retryTimes?

> `readonly` `optional` **retryTimes**: `number`

Defined in: [packages/core/src/agent/errors.ts:468](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L468)

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:474](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L474)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L46)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
