---
title: Observable
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/observable.ts:5](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/observable.ts#L5)

## Extended by

- [`ObservableLog`](ObservableLog.md)

## Type Parameters

### T

`T`

## Constructors

### Constructor

> **new Observable**\<`T`\>(): `Observable`\<`T`\>

Defined in: [packages/core/src/agent/observable.ts:8](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/observable.ts#L8)

#### Returns

`Observable`\<`T`\>

## Properties

### observers

> **observers**: [`ObserveFunction`](../type-aliases/ObserveFunction.md)\<`T`\>[]

Defined in: [packages/core/src/agent/observable.ts:6](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/observable.ts#L6)

## Methods

### notify()

> **notify**(`data`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:20](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/observable.ts#L20)

#### Parameters

##### data

`T`

##### rest

...`unknown`[]

#### Returns

`void`

***

### subscribe()

> **subscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:12](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/observable.ts#L12)

#### Parameters

##### func

[`ObserveFunction`](../type-aliases/ObserveFunction.md)\<`T`\>

#### Returns

`void`

***

### unsubscribe()

> **unsubscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:16](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/observable.ts#L16)

#### Parameters

##### func

[`ObserveFunction`](../type-aliases/ObserveFunction.md)\<`T`\>

#### Returns

`void`
