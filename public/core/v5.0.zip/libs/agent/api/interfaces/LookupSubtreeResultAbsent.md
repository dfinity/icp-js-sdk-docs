---
title: LookupSubtreeResultAbsent
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:555](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L555)

## Properties

### status

> **status**: [`Absent`](../enumerations/LookupSubtreeStatus.md#absent)

Defined in: [packages/core/src/agent/certificate.ts:556](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L556)
