---
title: SubmitResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:156](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L156)

## Properties

### requestDetails?

> `optional` **requestDetails**: [`CallRequest`](CallRequest.md)

Defined in: [packages/core/src/agent/agent/api.ts:165](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L165)

***

### requestId

> **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/agent/api.ts:157](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L157)

***

### response

> **response**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:158](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/api.ts#L158)

#### body

> **body**: `null` \| [`v2ResponseBody`](v2ResponseBody.md) \| [`v4ResponseBody`](v4ResponseBody.md)

#### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

#### ok

> **ok**: `boolean`

#### status

> **status**: `number`

#### statusText

> **statusText**: `string`
