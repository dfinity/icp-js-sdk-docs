---
title: HttpAgentOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:123](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L123)

## Properties

### backoffStrategy?

> `optional` **backoffStrategy**: `BackoffStrategyFactory`

Defined in: [packages/core/src/agent/agent/http/index.ts:170](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L170)

The strategy to use for backoff when retrying requests

***

### callOptions?

> `optional` **callOptions**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:133](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L133)

***

### credentials?

> `optional` **credentials**: `object`

Defined in: [packages/core/src/agent/agent/http/index.ts:149](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L149)

#### name

> **name**: `string`

#### password?

> `optional` **password**: `string`

***

### fetch()?

> `optional` **fetch**: \{(`input`, `init?`): `Promise`\<`Response`\>; (`input`, `init?`): `Promise`\<`Response`\>; \}

Defined in: [packages/core/src/agent/agent/http/index.ts:125](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L125)

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`RequestInfo` | `URL`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`string` | `Request` | `URL`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

***

### fetchOptions?

> `optional` **fetchOptions**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:130](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L130)

***

### host?

> `optional` **host**: `string`

Defined in: [packages/core/src/agent/agent/http/index.ts:137](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L137)

***

### identity?

> `optional` **identity**: [`Identity`](Identity.md) \| `Promise`\<[`Identity`](Identity.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:141](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L141)

***

### ingressExpiryInMinutes?

> `optional` **ingressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:147](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L147)

The maximum time a request can be delayed before being rejected.

#### Default

```ts
5 minutes
```

***

### logToConsole?

> `optional` **logToConsole**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:179](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L179)

Whether to log to the console. Defaults to false.

***

### retryTimes?

> `optional` **retryTimes**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:166](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L166)

Number of times to retry requests before throwing an error

#### Default

```ts
3
```

***

### rootKey?

> `optional` **rootKey**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:184](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L184)

Alternate root key to use for verifying certificates. If not provided, the default IC root key will be used.

***

### shouldFetchRootKey?

> `optional` **shouldFetchRootKey**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:189](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L189)

Whether or not the root key should be automatically fetched during construction. Defaults to false.

***

### shouldSyncTime?

> `optional` **shouldSyncTime**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:194](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L194)

Whether or not to sync the time with the network during construction. Defaults to false.

***

### useQueryNonces?

> `optional` **useQueryNonces**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:161](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L161)

Adds a unique [Nonce](../type-aliases/Nonce.md) with each query.
Enabling will prevent queries from being answered with a cached response.

#### Example

```ts
const agent = new HttpAgent({ useQueryNonces: true });
agent.addTransform(makeNonceTransform(makeNonce);
```

#### Default

```ts
false
```

***

### verifyQuerySignatures?

> `optional` **verifyQuerySignatures**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:175](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/index.ts#L175)

Whether the agent should verify signatures signed by node keys on query responses. Increases security, but adds overhead and must make a separate request to cache the node keys for the canister's subnet.

#### Default

```ts
true
```
