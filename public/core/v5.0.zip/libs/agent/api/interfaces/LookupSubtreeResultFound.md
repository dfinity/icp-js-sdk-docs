---
title: LookupSubtreeResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:563](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L563)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupSubtreeStatus.md#found)

Defined in: [packages/core/src/agent/certificate.ts:564](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L564)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/core/src/agent/certificate.ts:565](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L565)
