---
title: LookupLabelResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:589](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L589)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupLabelStatus.md#found)

Defined in: [packages/core/src/agent/certificate.ts:590](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L590)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/core/src/agent/certificate.ts:591](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L591)
