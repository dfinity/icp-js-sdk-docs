---
title: UnSigned
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L49)

## Type Parameters

### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L50)
