---
title: HttpAgentQueryRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:33](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L33)

## Extends

- [`HttpAgentBaseRequest`](HttpAgentBaseRequest.md)

## Properties

### body

> **body**: [`ReadRequest`](../type-aliases/ReadRequest.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:35](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L35)

***

### endpoint

> `readonly` **endpoint**: [`Query`](../enumerations/Endpoint.md#query)

Defined in: [packages/core/src/agent/agent/http/types.ts:34](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L34)

#### Overrides

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`endpoint`](HttpAgentBaseRequest.md#endpoint)

***

### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L23)

#### Inherited from

[`HttpAgentBaseRequest`](HttpAgentBaseRequest.md).[`request`](HttpAgentBaseRequest.md#request)
