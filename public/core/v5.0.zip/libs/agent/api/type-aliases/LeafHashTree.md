---
title: LeafHashTree
editUrl: false
next: true
prev: true
---

> **LeafHashTree** = \[[`Leaf`](../enumerations/NodeType.md#leaf), [`NodeValue`](NodeValue.md)\]

Defined in: [packages/core/src/agent/certificate.ts:63](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/certificate.ts#L63)
