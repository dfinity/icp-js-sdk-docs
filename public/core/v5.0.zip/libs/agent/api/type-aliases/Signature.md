---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/auth.ts#L22)

A signature array buffer.

## Type declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
