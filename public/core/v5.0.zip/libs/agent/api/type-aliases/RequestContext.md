---
title: RequestContext
editUrl: false
next: true
prev: true
---

> **RequestContext** = `object`

Defined in: [packages/core/src/agent/errors.ts:25](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L25)

## Properties

### ingressExpiry

> **ingressExpiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/errors.ts:29](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L29)

***

### requestId?

> `optional` **requestId**: [`RequestId`](RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:26](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L26)

***

### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:27](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L27)

***

### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:28](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/errors.ts#L28)
