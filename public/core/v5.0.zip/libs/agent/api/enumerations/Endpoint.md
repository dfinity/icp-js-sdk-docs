---
title: Endpoint
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:8](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L8)

**`Internal`**

## Enumeration Members

### Call

> **Call**: `"call"`

Defined in: [packages/core/src/agent/agent/http/types.ts:11](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L11)

***

### Query

> **Query**: `"read"`

Defined in: [packages/core/src/agent/agent/http/types.ts:9](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L9)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/core/src/agent/agent/http/types.ts:10](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/agent/http/types.ts#L10)
