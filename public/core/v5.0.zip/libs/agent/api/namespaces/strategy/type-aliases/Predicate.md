---
title: Predicate
editUrl: false
next: true
prev: true
---

> **Predicate**\<`T`\> = (`canisterId`, `requestId`, `status`) => `Promise`\<`T`\>

Defined in: [packages/core/src/agent/polling/strategy.ts:7](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/polling/strategy.ts#L7)

## Type Parameters

### T

`T`

## Parameters

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

### requestId

[`RequestId`](../../../type-aliases/RequestId.md)

### status

[`RequestStatusResponseStatus`](../../../enumerations/RequestStatusResponseStatus.md)

## Returns

`Promise`\<`T`\>
