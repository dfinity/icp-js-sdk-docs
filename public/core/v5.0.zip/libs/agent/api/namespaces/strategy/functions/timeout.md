---
title: timeout
editUrl: false
next: true
prev: true
---

> **timeout**(`timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/strategy.ts:92](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/polling/strategy.ts#L92)

Reject a call after a certain amount of time.

## Parameters

### timeInMsec

`number`

Time in milliseconds before the polling should be rejected.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
