---
title: once
editUrl: false
next: true
prev: true
---

> **once**(): [`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

Defined in: [packages/core/src/agent/polling/strategy.ts:29](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/polling/strategy.ts#L29)

Predicate that returns true once.

## Returns

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>
