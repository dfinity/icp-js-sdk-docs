---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

> **SubnetStatus** = `BaseSubnetStatus` & `object`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:40](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L40)

## Type declaration

### publicKey

> **publicKey**: `Uint8Array`

The public key of the subnet
