---
title: SubnetStatusOptions
editUrl: false
next: true
prev: true
---

> **SubnetStatusOptions** = `object`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:56](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L56)

## Properties

### agent

> **agent**: [`HttpAgent`](../../../classes/HttpAgent.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:65](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L65)

The agent to use to make the subnet request.

***

### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification**: `boolean`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:75](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L75)

Whether to disable the certificate freshness checks.

#### Default

```ts
false
```

***

### paths?

> `optional` **paths**: [`Path`](Path.md)[] \| `Set`\<[`Path`](Path.md)\>

Defined in: [packages/core/src/agent/subnetStatus/index.ts:70](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L70)

The paths to request.

#### Default

```ts
[]
```

***

### subnetId

> **subnetId**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:61](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L61)

The subnet ID to query. Use [IC\_ROOT\_SUBNET\_ID](../variables/IC_ROOT_SUBNET_ID.md) for the IC mainnet root subnet.
You can use [HttpAgent.getSubnetIdFromCanister](../../../classes/HttpAgent.md#getsubnetidfromcanister) to get a subnet ID from a canister.
