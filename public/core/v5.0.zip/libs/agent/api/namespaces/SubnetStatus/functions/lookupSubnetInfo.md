---
title: lookupSubnetInfo
editUrl: false
next: true
prev: true
---

> **lookupSubnetInfo**(`certificate`, `subnetId`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:203](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/subnetStatus/index.ts#L203)

Fetch subnet info including node keys from a certificate

## Parameters

### certificate

`Uint8Array`

the certificate bytes

### subnetId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the subnet ID

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)

SubnetStatus with subnet ID and node keys
