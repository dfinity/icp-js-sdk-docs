---
title: CustomPath
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/utils/readState.ts:67](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/readState.ts#L67)

Interface to define a custom path. Nested paths will be represented as individual buffers, and can be created from text using TextEncoder.

## Param

the key to use to access the returned value in the status map

## Param

the path to the desired value, represented as an array of buffers

## Param

the strategy to use to decode the returned value

## Implements

- `CustomPath`

## Constructors

### Constructor

> **new CustomPath**(`key`, `path`, `decodeStrategy`): `CustomPath`

Defined in: [packages/core/src/agent/utils/readState.ts:71](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/readState.ts#L71)

#### Parameters

##### key

`string`

##### path

`string` | `Uint8Array`\<`ArrayBufferLike`\>[]

##### decodeStrategy

[`DecodeStrategy`](../type-aliases/DecodeStrategy.md)

#### Returns

`CustomPath`

## Properties

### decodeStrategy

> **decodeStrategy**: [`DecodeStrategy`](../type-aliases/DecodeStrategy.md)

Defined in: [packages/core/src/agent/utils/readState.ts:70](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/readState.ts#L70)

#### Implementation of

`CustomPath.decodeStrategy`

***

### key

> **key**: `string`

Defined in: [packages/core/src/agent/utils/readState.ts:68](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/readState.ts#L68)

#### Implementation of

`CustomPath.key`

***

### path

> **path**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/core/src/agent/utils/readState.ts:69](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/utils/readState.ts#L69)

#### Implementation of

`CustomPath.path`
