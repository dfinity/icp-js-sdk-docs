---
title: CanisterStatusOptions
editUrl: false
next: true
prev: true
---

> **CanisterStatusOptions** = `object`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:42](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canisterStatus/index.ts#L42)

## Properties

### agent

> **agent**: [`HttpAgent`](../../../classes/HttpAgent.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:50](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canisterStatus/index.ts#L50)

The agent to use to make the canister request. Must be authenticated.

***

### canisterId

> **canisterId**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:46](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canisterStatus/index.ts#L46)

The effective canister ID to use in the underlying [HttpAgent.readState](../../../classes/HttpAgent.md#readstate) call.

***

### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification**: `boolean`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:60](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canisterStatus/index.ts#L60)

Whether to disable the certificate freshness checks.

#### Default

```ts
false
```

***

### paths?

> `optional` **paths**: [`Path`](Path.md)[] \| `Set`\<[`Path`](Path.md)\>

Defined in: [packages/core/src/agent/canisterStatus/index.ts:55](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canisterStatus/index.ts#L55)

The paths to request.

#### Default

```ts
[]
```
