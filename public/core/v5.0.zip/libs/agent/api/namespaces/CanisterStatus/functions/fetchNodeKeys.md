---
title: fetchNodeKeys
editUrl: false
next: true
prev: true
---

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): `BaseSubnetStatus`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:197](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/agent/canisterStatus/index.ts#L197)

Lookup node keys from a certificate for a given canister.
The certificate is assumed to be already verified, including whether the canister is in range of the subnet.

## Parameters

### certificate

`Uint8Array`

the certificate to lookup node keys from

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the canister ID to lookup node keys for

### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

the root key to use to lookup node keys

## Returns

`BaseSubnetStatus`

a map of node IDs to public keys
