---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

The CanisterStatus utility is used to request structured data directly from the IC public API. This data can be accessed using agent.readState, but CanisterStatus provides a helpful abstraction with some known paths.

You can request a canisters Controllers, ModuleHash, Candid interface, Subnet, or Time, or provide a custom path [CanisterStatus.CustomPath](classes/CustomPath.md) and pass arbitrary buffers for valid paths identified in https://internetcomputer.org/docs/current/references/ic-interface-spec.

The primary method for this namespace is [CanisterStatus.request](functions/request.md)

## Classes

- [CustomPath](classes/CustomPath.md)

## Type Aliases

- [CanisterStatusOptions](type-aliases/CanisterStatusOptions.md)
- [DecodeStrategy](type-aliases/DecodeStrategy.md)
- [Path](type-aliases/Path.md)
- [Status](type-aliases/Status.md)
- [StatusMap](type-aliases/StatusMap.md)
- [SubnetStatus](type-aliases/SubnetStatus.md)

## Functions

- [encodePath](functions/encodePath.md)
- [fetchNodeKeys](functions/fetchNodeKeys.md)
- [request](functions/request.md)
