---
title: JsonableSecp256k1Identity
editUrl: false
next: true
prev: true
---

> **JsonableSecp256k1Identity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:19](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/secp256k1/secp256k1.ts#L19)
