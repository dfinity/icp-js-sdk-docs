---
title: CryptoKeyOptions
editUrl: false
next: true
prev: true
---

> **CryptoKeyOptions** = `object`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:7](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/identity/ecdsa.ts#L7)

Options used in a [ECDSAKeyIdentity](../classes/ECDSAKeyIdentity.md)

## Properties

### extractable?

> `optional` **extractable**: `boolean`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:8](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/identity/ecdsa.ts#L8)

***

### keyUsages?

> `optional` **keyUsages**: `KeyUsage`[]

Defined in: [packages/core/src/identity/identity/ecdsa.ts:9](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/identity/ecdsa.ts#L9)

***

### subtleCrypto?

> `optional` **subtleCrypto**: `SubtleCrypto`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:10](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/identity/ecdsa.ts#L10)
