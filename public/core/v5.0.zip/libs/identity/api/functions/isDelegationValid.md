---
title: isDelegationValid
editUrl: false
next: true
prev: true
---

> **isDelegationValid**(`chain`, `checks?`): `boolean`

Defined in: [packages/core/src/identity/identity/delegation.ts:370](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/identity/identity/delegation.ts#L370)

Analyze a DelegationChain and validate that it's valid, ie. not expired and apply to the
scope.

## Parameters

### chain

[`DelegationChain`](../classes/DelegationChain.md)

The chain to validate.

### checks?

[`DelegationValidChecks`](../interfaces/DelegationValidChecks.md)

Various checks to validate on the chain.

## Returns

`boolean`
