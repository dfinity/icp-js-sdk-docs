---
title: GenericIdlFuncRets
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncRets** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1725](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L1725)

The generic type of the return values of an [IDL Function](../functions/Func.md).
