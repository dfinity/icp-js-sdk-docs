---
title: encode
editUrl: false
next: true
prev: true
---

> **encode**(`argTypes`, `args`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1951](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L1951)

Encode a array of values

## Parameters

### argTypes

[`Type`](../classes/Type.md)\<`any`\>[]

array of Types

### args

`any`[]

array of values

## Returns

`Uint8Array`

serialised value
