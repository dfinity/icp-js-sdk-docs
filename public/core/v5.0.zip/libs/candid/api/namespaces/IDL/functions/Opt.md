---
title: Opt
editUrl: false
next: true
prev: true
---

> **Opt**\<`T`\>(`t`): [`OptClass`](../classes/OptClass.md)\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:2333](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L2333)

## Type Parameters

### T

`T`

## Parameters

### t

[`Type`](../classes/Type.md)\<`T`\>

IDL Type

## Returns

[`OptClass`](../classes/OptClass.md)\<`T`\>

OptClass of Type
