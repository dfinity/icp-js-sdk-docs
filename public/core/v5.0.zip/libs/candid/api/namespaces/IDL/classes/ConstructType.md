---
title: ConstructType
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/idl.ts:293](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L293)

Represents an IDL type.

## Extends

- [`Type`](Type.md)\<`T`\>

## Extended by

- [`VecClass`](VecClass.md)
- [`OptClass`](OptClass.md)
- [`RecordClass`](RecordClass.md)
- [`VariantClass`](VariantClass.md)
- [`RecClass`](RecClass.md)
- [`FuncClass`](FuncClass.md)
- [`ServiceClass`](ServiceClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new ConstructType**\<`T`\>(): `ConstructType`\<`T`\>

#### Returns

`ConstructType`\<`T`\>

#### Inherited from

[`Type`](Type.md).[`constructor`](Type.md#constructor)

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:234](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L234)

#### Inherited from

[`Type`](Type.md).[`name`](Type.md#name)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:233](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L233)

#### Inherited from

[`Type`](Type.md).[`typeName`](Type.md#typename)

## Methods

### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:276](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L276)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`_buildTypeTableImpl`](Type.md#_buildtypetableimpl)

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:235](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L235)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Inherited from

[`Type`](Type.md).[`accept`](Type.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L247)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`Type`](Type.md).[`buildTypeTable`](Type.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): `ConstructType`\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:294](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L294)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

`ConstructType`\<`T`\>

#### Overrides

[`Type`](Type.md).[`checkType`](Type.md#checktype)

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:257](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L257)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Inherited from

[`Type`](Type.md).[`covariant`](Type.md#covariant)

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:274](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L274)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Inherited from

[`Type`](Type.md).[`decodeValue`](Type.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:238](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L238)

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`display`](Type.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:304](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L304)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Overrides

[`Type`](Type.md).[`encodeType`](Type.md#encodetype)

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:264](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L264)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

#### Inherited from

[`Type`](Type.md).[`encodeValue`](Type.md#encodevalue)

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:242](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L242)

#### Parameters

##### x

`T`

#### Returns

`string`

#### Inherited from

[`Type`](Type.md).[`valueToString`](Type.md#valuetostring)
