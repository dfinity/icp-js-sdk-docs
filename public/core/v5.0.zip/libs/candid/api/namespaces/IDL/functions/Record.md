---
title: Record
editUrl: false
next: true
prev: true
---

> **Record**(`t`): [`RecordClass`](../classes/RecordClass.md)

Defined in: [packages/core/src/candid/idl.ts:2341](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/idl.ts#L2341)

## Parameters

### t

`Record`\<`string`, [`Type`](../classes/Type.md)\>

Record of string and IDL Type

## Returns

[`RecordClass`](../classes/RecordClass.md)

RecordClass of string and Type
