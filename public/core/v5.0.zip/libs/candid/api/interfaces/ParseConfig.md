---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/candid-core.ts#L6)

## Properties

### random?

> `optional` **random**: `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:7](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/candid-core.ts#L7)
