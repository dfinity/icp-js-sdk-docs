---
title: safeRead
editUrl: false
next: true
prev: true
---

> **safeRead**(`pipe`, `num`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:21](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/utils/leb128.ts#L21)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### num

`number`

number

## Returns

`Uint8Array`

Uint8Array
