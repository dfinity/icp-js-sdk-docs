---
title: tupleForm
editUrl: false
next: true
prev: true
---

> **tupleForm**(`components`, `config`): [`TupleForm`](../classes/TupleForm.md)

Defined in: [packages/core/src/candid/candid-ui.ts:18](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/candid-ui.ts#L18)

## Parameters

### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

### config

`Partial`\<[`FormConfig`](../interfaces/FormConfig.md)\>

## Returns

[`TupleForm`](../classes/TupleForm.md)
