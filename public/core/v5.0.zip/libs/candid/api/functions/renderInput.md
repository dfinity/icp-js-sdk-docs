---
title: renderInput
editUrl: false
next: true
prev: true
---

> **renderInput**(`t`): [`InputBox`](../classes/InputBox.md)

Defined in: [packages/core/src/candid/candid-ui.ts:208](https://github.com/dfinity/icp-js-core/blob/5e11ae098e9048ecdd243ddc080ca1cb908117b8/packages/core/src/candid/candid-ui.ts#L208)

## Parameters

### t

[`Type`](../namespaces/IDL/classes/Type.md)

an IDL type

## Returns

[`InputBox`](../classes/InputBox.md)

an input for that type
