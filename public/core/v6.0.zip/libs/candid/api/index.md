---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [IDL](namespaces/IDL.md)

## Classes

### InputBox

Defined in: [packages/core/src/candid/candid-core.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L23)

#### Constructors

##### Constructor

> **new InputBox**(`idl`, `ui`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-core.ts:28](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L28)

###### Parameters

###### idl

[`Type`](namespaces/IDL.md#abstract-type)

###### ui

[`UIConfig`](#uiconfig)

###### Returns

[`InputBox`](#inputbox)

#### Properties

##### idl

> **idl**: [`Type`](namespaces/IDL.md#abstract-type)

Defined in: [packages/core/src/candid/candid-core.ts:29](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L29)

##### label

> **label**: `string` \| `null` = `null`

Defined in: [packages/core/src/candid/candid-core.ts:25](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L25)

##### status

> **status**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:24](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L24)

##### ui

> **ui**: [`UIConfig`](#uiconfig)

Defined in: [packages/core/src/candid/candid-core.ts:30](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L30)

##### value

> **value**: `any` = `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:26](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L26)

#### Methods

##### isRejected()

> **isRejected**(): `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:49](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L49)

###### Returns

`boolean`

##### parse()

> **parse**(`config?`): `any`

Defined in: [packages/core/src/candid/candid-core.ts:53](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L53)

###### Parameters

###### config?

[`ParseConfig`](#parseconfig) = `{}`

###### Returns

`any`

##### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:80](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L80)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

***

### `abstract` InputForm

Defined in: [packages/core/src/candid/candid-core.ts:99](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L99)

#### Extended by

- [`RecordForm`](#recordform)
- [`TupleForm`](#tupleform)
- [`VariantForm`](#variantform)
- [`OptionForm`](#optionform)
- [`VecForm`](#vecform)

#### Constructors

##### Constructor

> **new InputForm**(`ui`): [`InputForm`](#abstract-inputform)

Defined in: [packages/core/src/candid/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L101)

###### Parameters

###### ui

[`FormConfig`](#formconfig)

###### Returns

[`InputForm`](#abstract-inputform)

#### Properties

##### form

> **form**: [`InputBox`](#inputbox)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L100)

##### ui

> **ui**: [`FormConfig`](#formconfig)

Defined in: [packages/core/src/candid/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L101)

#### Methods

##### generateForm()

> `abstract` **generateForm**(): `any`

Defined in: [packages/core/src/candid/candid-core.ts:104](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L104)

###### Returns

`any`

##### parse()

> `abstract` **parse**(`config`): `any`

Defined in: [packages/core/src/candid/candid-core.ts:103](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L103)

###### Parameters

###### config

[`ParseConfig`](#parseconfig)

###### Returns

`any`

##### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L113)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

##### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L105)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

***

### OptionForm

Defined in: [packages/core/src/candid/candid-core.ts:223](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L223)

#### Extends

- [`InputForm`](#abstract-inputform)

#### Constructors

##### Constructor

> **new OptionForm**(`ty`, `ui`): [`OptionForm`](#optionform)

Defined in: [packages/core/src/candid/candid-core.ts:224](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L224)

###### Parameters

###### ty

[`Type`](namespaces/IDL.md#abstract-type)

###### ui

[`FormConfig`](#formconfig)

###### Returns

[`OptionForm`](#optionform)

###### Overrides

[`InputForm`](#abstract-inputform).[`constructor`](#constructor-1)

#### Properties

##### form

> **form**: [`InputBox`](#inputbox)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L100)

###### Inherited from

[`InputForm`](#abstract-inputform).[`form`](#form)

##### ty

> **ty**: [`Type`](namespaces/IDL.md#abstract-type)

Defined in: [packages/core/src/candid/candid-core.ts:225](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L225)

##### ui

> **ui**: [`FormConfig`](#formconfig)

Defined in: [packages/core/src/candid/candid-core.ts:226](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L226)

###### Inherited from

[`InputForm`](#abstract-inputform).[`ui`](#ui-1)

#### Methods

##### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:230](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L230)

###### Returns

`void`

###### Overrides

[`InputForm`](#abstract-inputform).[`generateForm`](#generateform)

##### parse()

> **parse**\<`T`\>(`config`): \[\] \| \[`T`\] \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:238](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L238)

###### Type Parameters

###### T

`T`

###### Parameters

###### config

[`ParseConfig`](#parseconfig)

###### Returns

\[\] \| \[`T`\] \| `undefined`

###### Overrides

[`InputForm`](#abstract-inputform).[`parse`](#parse-1)

##### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L113)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`render`](#render-1)

##### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L105)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`renderForm`](#renderform)

***

### PipeArrayBuffer

Defined in: [packages/core/src/candid/utils/buffer.ts:18](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L18)

A class that abstracts a pipe-like Uint8Array.

#### Constructors

##### Constructor

> **new PipeArrayBuffer**(`buffer?`, `length?`): [`PipeArrayBuffer`](#pipearraybuffer)

Defined in: [packages/core/src/candid/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L54)

Creates a new instance of a pipe

###### Parameters

###### buffer?

`Uint8Array`\<`ArrayBufferLike`\>

an optional buffer to start with

###### length?

`number` = `...`

an optional amount of bytes to use for the length.

###### Returns

[`PipeArrayBuffer`](#pipearraybuffer)

#### Accessors

##### buffer

###### Get Signature

> **get** **buffer**(): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:72](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L72)

###### Returns

`Uint8Array`

##### byteLength

###### Get Signature

> **get** **byteLength**(): `number`

Defined in: [packages/core/src/candid/utils/buffer.ts:77](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L77)

###### Returns

`number`

##### end

###### Get Signature

> **get** **end**(): `boolean`

Defined in: [packages/core/src/candid/utils/buffer.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L127)

Whether or not there is more data to read from the buffer

###### Returns

`boolean`

#### Methods

##### alloc()

> **alloc**(`amount`): `void`

Defined in: [packages/core/src/candid/utils/buffer.ts:135](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L135)

Allocate a fixed amount of memory in the buffer. This does not affect the view.

###### Parameters

###### amount

`number`

A number of bytes to add to the buffer.

###### Returns

`void`

##### read()

> **read**(`num`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L85)

Read `num` number of bytes from the front of the pipe.

###### Parameters

###### num

`number`

The number of bytes to read.

###### Returns

`Uint8Array`

##### readUint8()

> **readUint8**(): `number` \| `undefined`

Defined in: [packages/core/src/candid/utils/buffer.ts:91](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L91)

###### Returns

`number` \| `undefined`

##### restore()

> **restore**(`checkPoint`): `void`

Defined in: [packages/core/src/candid/utils/buffer.ts:36](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L36)

Restore a checkpoint of the reading view (for backtracking)

###### Parameters

###### checkPoint

`Uint8Array`

a previously saved checkpoint

###### Returns

`void`

##### save()

> **save**(): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:28](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L28)

Save a checkpoint of the reading view (for backtracking)

###### Returns

`Uint8Array`

##### write()

> **write**(`buf`): `void`

Defined in: [packages/core/src/candid/utils/buffer.ts:104](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L104)

Write a buffer to the end of the pipe.

###### Parameters

###### buf

`Uint8Array`

The bytes to write.

###### Returns

`void`

***

### RecordForm

Defined in: [packages/core/src/candid/candid-core.ts:139](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L139)

#### Extends

- [`InputForm`](#abstract-inputform)

#### Constructors

##### Constructor

> **new RecordForm**(`fields`, `ui`): [`RecordForm`](#recordform)

Defined in: [packages/core/src/candid/candid-core.ts:140](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L140)

###### Parameters

###### fields

\[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

###### ui

[`FormConfig`](#formconfig)

###### Returns

[`RecordForm`](#recordform)

###### Overrides

[`InputForm`](#abstract-inputform).[`constructor`](#constructor-1)

#### Properties

##### fields

> **fields**: \[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/candid-core.ts:141](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L141)

##### form

> **form**: [`InputBox`](#inputbox)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L100)

###### Inherited from

[`InputForm`](#abstract-inputform).[`form`](#form)

##### ui

> **ui**: [`FormConfig`](#formconfig)

Defined in: [packages/core/src/candid/candid-core.ts:142](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L142)

###### Inherited from

[`InputForm`](#abstract-inputform).[`ui`](#ui-1)

#### Methods

##### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:146](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L146)

###### Returns

`void`

###### Overrides

[`InputForm`](#abstract-inputform).[`generateForm`](#generateform)

##### parse()

> **parse**(`config`): `Record`\<`string`, `any`\> \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:158](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L158)

###### Parameters

###### config

[`ParseConfig`](#parseconfig)

###### Returns

`Record`\<`string`, `any`\> \| `undefined`

###### Overrides

[`InputForm`](#abstract-inputform).[`parse`](#parse-1)

##### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L113)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`render`](#render-1)

##### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L105)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`renderForm`](#renderform)

***

### Render

Defined in: [packages/core/src/candid/candid-ui.ts:31](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L31)

#### Extends

- [`Visitor`](namespaces/IDL.md#abstract-visitor)\<`null`, `InputBox`\>

#### Constructors

##### Constructor

> **new Render**(): [`Render`](#render-4)

###### Returns

[`Render`](#render-4)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`constructor`](namespaces/IDL.md#constructor-24)

#### Methods

##### visitBool()

> **visitBool**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:154](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L154)

###### Parameters

###### t

[`BoolClass`](namespaces/IDL.md#boolclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitBool`](namespaces/IDL.md#visitbool)

##### visitConstruct()

> **visitConstruct**\<`T`\>(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:188](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L188)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`ConstructType`](namespaces/IDL.md#abstract-constructtype)\<`T`\>

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitConstruct`](namespaces/IDL.md#visitconstruct)

##### visitEmpty()

> **visitEmpty**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:151](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L151)

###### Parameters

###### t

[`EmptyClass`](namespaces/IDL.md#emptyclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitEmpty`](namespaces/IDL.md#visitempty)

##### visitFixedInt()

> **visitFixedInt**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:178](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L178)

###### Parameters

###### t

[`FixedIntClass`](namespaces/IDL.md#fixedintclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitFixedInt`](namespaces/IDL.md#visitfixedint)

##### visitFixedNat()

> **visitFixedNat**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:181](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L181)

###### Parameters

###### t

[`FixedNatClass`](namespaces/IDL.md#fixednatclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitFixedNat`](namespaces/IDL.md#visitfixednat)

##### visitFloat()

> **visitFloat**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:175](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L175)

###### Parameters

###### t

[`FloatClass`](namespaces/IDL.md#floatclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitFloat`](namespaces/IDL.md#visitfloat)

##### visitFunc()

> **visitFunc**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:210](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L210)

###### Parameters

###### t

[`FuncClass`](namespaces/IDL.md#funcclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitFunc`](namespaces/IDL.md#visitfunc)

##### visitInt()

> **visitInt**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:169](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L169)

###### Parameters

###### t

[`IntClass`](namespaces/IDL.md#intclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitInt`](namespaces/IDL.md#visitint)

##### visitNat()

> **visitNat**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:172](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L172)

###### Parameters

###### t

[`NatClass`](namespaces/IDL.md#natclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitNat`](namespaces/IDL.md#visitnat)

##### visitNull()

> **visitNull**(`t`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:38](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L38)

###### Parameters

###### t

[`NullClass`](namespaces/IDL.md#nullclass)

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitNull`](namespaces/IDL.md#visitnull)

##### visitNumber()

> **visitNumber**\<`T`\>(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:166](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L166)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`PrimitiveType`](namespaces/IDL.md#abstract-primitivetype)\<`T`\>

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitNumber`](namespaces/IDL.md#visitnumber)

##### visitOpt()

> **visitOpt**\<`T`\>(`t`, `ty`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:77](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L77)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`OptClass`](namespaces/IDL.md#optclass)\<`T`\>

###### ty

[`Type`](namespaces/IDL.md#abstract-type)\<`T`\>

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitOpt`](namespaces/IDL.md#visitopt)

##### visitPrimitive()

> **visitPrimitive**\<`T`\>(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:148](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L148)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`PrimitiveType`](namespaces/IDL.md#abstract-primitivetype)\<`T`\>

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitPrimitive`](namespaces/IDL.md#visitprimitive)

##### visitPrincipal()

> **visitPrincipal**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:184](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L184)

###### Parameters

###### t

[`PrincipalClass`](namespaces/IDL.md#principalclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitPrincipal`](namespaces/IDL.md#visitprincipal)

##### visitRec()

> **visitRec**\<`T`\>(`_t`, `ty`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:97](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L97)

###### Type Parameters

###### T

`T`

###### Parameters

###### \_t

[`RecClass`](namespaces/IDL.md#recclass)\<`T`\>

###### ty

[`ConstructType`](namespaces/IDL.md#abstract-constructtype)\<`T`\>

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitRec`](namespaces/IDL.md#visitrec)

##### visitRecord()

> **visitRecord**(`t`, `fields`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:41](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L41)

###### Parameters

###### t

[`RecordClass`](namespaces/IDL.md#recordclass)

###### fields

\[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitRecord`](namespaces/IDL.md#visitrecord)

##### visitReserved()

> **visitReserved**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:160](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L160)

###### Parameters

###### t

[`ReservedClass`](namespaces/IDL.md#reservedclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitReserved`](namespaces/IDL.md#visitreserved)

##### visitService()

> **visitService**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:213](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L213)

###### Parameters

###### t

[`ServiceClass`](namespaces/IDL.md#serviceclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitService`](namespaces/IDL.md#visitservice)

##### visitText()

> **visitText**(`t`, `data`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/idl.ts:163](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/idl.ts#L163)

###### Parameters

###### t

[`TextClass`](namespaces/IDL.md#textclass)

###### data

`null`

###### Returns

[`InputBox`](#inputbox)

###### Inherited from

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitText`](namespaces/IDL.md#visittext)

##### visitTuple()

> **visitTuple**\<`T`\>(`t`, `components`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:51](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L51)

###### Type Parameters

###### T

`T` *extends* `any`[]

###### Parameters

###### t

[`TupleClass`](namespaces/IDL.md#tupleclass)\<`T`\>

###### components

[`Type`](namespaces/IDL.md#abstract-type)\<`any`\>[]

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitTuple`](namespaces/IDL.md#visittuple)

##### visitType()

> **visitType**\<`T`\>(`t`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:32](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L32)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`Type`](namespaces/IDL.md#abstract-type)\<`T`\>

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitType`](namespaces/IDL.md#visittype)

##### visitVariant()

> **visitVariant**(`t`, `fields`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:65](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L65)

###### Parameters

###### t

[`VariantClass`](namespaces/IDL.md#variantclass)

###### fields

\[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitVariant`](namespaces/IDL.md#visitvariant)

##### visitVec()

> **visitVec**\<`T`\>(`t`, `ty`, `_d`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:84](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L84)

###### Type Parameters

###### T

`T`

###### Parameters

###### t

[`VecClass`](namespaces/IDL.md#vecclass)\<`T`\>

###### ty

[`Type`](namespaces/IDL.md#abstract-type)\<`T`\>

###### \_d

`null`

###### Returns

[`InputBox`](#inputbox)

###### Overrides

[`Visitor`](namespaces/IDL.md#abstract-visitor).[`visitVec`](namespaces/IDL.md#visitvec)

***

### TupleForm

Defined in: [packages/core/src/candid/candid-core.ts:171](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L171)

#### Extends

- [`InputForm`](#abstract-inputform)

#### Constructors

##### Constructor

> **new TupleForm**(`components`, `ui`): [`TupleForm`](#tupleform)

Defined in: [packages/core/src/candid/candid-core.ts:172](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L172)

###### Parameters

###### components

[`Type`](namespaces/IDL.md#abstract-type)\<`any`\>[]

###### ui

[`FormConfig`](#formconfig)

###### Returns

[`TupleForm`](#tupleform)

###### Overrides

[`InputForm`](#abstract-inputform).[`constructor`](#constructor-1)

#### Properties

##### components

> **components**: [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>[]

Defined in: [packages/core/src/candid/candid-core.ts:173](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L173)

##### form

> **form**: [`InputBox`](#inputbox)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L100)

###### Inherited from

[`InputForm`](#abstract-inputform).[`form`](#form)

##### ui

> **ui**: [`FormConfig`](#formconfig)

Defined in: [packages/core/src/candid/candid-core.ts:174](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L174)

###### Inherited from

[`InputForm`](#abstract-inputform).[`ui`](#ui-1)

#### Methods

##### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:178](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L178)

###### Returns

`void`

###### Overrides

[`InputForm`](#abstract-inputform).[`generateForm`](#generateform)

##### parse()

> **parse**(`config`): `any`[] \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:184](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L184)

###### Parameters

###### config

[`ParseConfig`](#parseconfig)

###### Returns

`any`[] \| `undefined`

###### Overrides

[`InputForm`](#abstract-inputform).[`parse`](#parse-1)

##### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L113)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`render`](#render-1)

##### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L105)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`renderForm`](#renderform)

***

### VariantForm

Defined in: [packages/core/src/candid/candid-core.ts:197](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L197)

#### Extends

- [`InputForm`](#abstract-inputform)

#### Constructors

##### Constructor

> **new VariantForm**(`fields`, `ui`): [`VariantForm`](#variantform)

Defined in: [packages/core/src/candid/candid-core.ts:198](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L198)

###### Parameters

###### fields

\[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

###### ui

[`FormConfig`](#formconfig)

###### Returns

[`VariantForm`](#variantform)

###### Overrides

[`InputForm`](#abstract-inputform).[`constructor`](#constructor-1)

#### Properties

##### fields

> **fields**: \[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

Defined in: [packages/core/src/candid/candid-core.ts:199](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L199)

##### form

> **form**: [`InputBox`](#inputbox)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L100)

###### Inherited from

[`InputForm`](#abstract-inputform).[`form`](#form)

##### ui

> **ui**: [`FormConfig`](#formconfig)

Defined in: [packages/core/src/candid/candid-core.ts:200](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L200)

###### Inherited from

[`InputForm`](#abstract-inputform).[`ui`](#ui-1)

#### Methods

##### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:204](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L204)

###### Returns

`void`

###### Overrides

[`InputForm`](#abstract-inputform).[`generateForm`](#generateform)

##### parse()

> **parse**(`config`): `Record`\<`string`, `any`\> \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:210](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L210)

###### Parameters

###### config

[`ParseConfig`](#parseconfig)

###### Returns

`Record`\<`string`, `any`\> \| `undefined`

###### Overrides

[`InputForm`](#abstract-inputform).[`parse`](#parse-1)

##### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L113)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`render`](#render-1)

##### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L105)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`renderForm`](#renderform)

***

### VecForm

Defined in: [packages/core/src/candid/candid-core.ts:250](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L250)

#### Extends

- [`InputForm`](#abstract-inputform)

#### Constructors

##### Constructor

> **new VecForm**(`ty`, `ui`): [`VecForm`](#vecform)

Defined in: [packages/core/src/candid/candid-core.ts:251](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L251)

###### Parameters

###### ty

[`Type`](namespaces/IDL.md#abstract-type)

###### ui

[`FormConfig`](#formconfig)

###### Returns

[`VecForm`](#vecform)

###### Overrides

[`InputForm`](#abstract-inputform).[`constructor`](#constructor-1)

#### Properties

##### form

> **form**: [`InputBox`](#inputbox)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L100)

###### Inherited from

[`InputForm`](#abstract-inputform).[`form`](#form)

##### ty

> **ty**: [`Type`](namespaces/IDL.md#abstract-type)

Defined in: [packages/core/src/candid/candid-core.ts:252](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L252)

##### ui

> **ui**: [`FormConfig`](#formconfig)

Defined in: [packages/core/src/candid/candid-core.ts:253](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L253)

###### Inherited from

[`InputForm`](#abstract-inputform).[`ui`](#ui-1)

#### Methods

##### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:257](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L257)

###### Returns

`void`

###### Overrides

[`InputForm`](#abstract-inputform).[`generateForm`](#generateform)

##### parse()

> **parse**\<`T`\>(`config`): `T`[] \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:265](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L265)

###### Type Parameters

###### T

`T`

###### Parameters

###### config

[`ParseConfig`](#parseconfig)

###### Returns

`T`[] \| `undefined`

###### Overrides

[`InputForm`](#abstract-inputform).[`parse`](#parse-1)

##### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L113)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`render`](#render-1)

##### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L105)

###### Parameters

###### dom

`HTMLElement`

###### Returns

`void`

###### Inherited from

[`InputForm`](#abstract-inputform).[`renderForm`](#renderform)

## Interfaces

### FormConfig

Defined in: [packages/core/src/candid/candid-core.ts:15](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L15)

#### Properties

##### container?

> `optional` **container?**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:19](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L19)

##### event?

> `optional` **event?**: `string`

Defined in: [packages/core/src/candid/candid-core.ts:17](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L17)

##### labelMap?

> `optional` **labelMap?**: `Record`\<`string`, `string`\>

Defined in: [packages/core/src/candid/candid-core.ts:18](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L18)

##### open?

> `optional` **open?**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:16](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L16)

#### Methods

##### render()

> **render**(`t`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-core.ts:20](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L20)

###### Parameters

###### t

[`Type`](namespaces/IDL.md#abstract-type)

###### Returns

[`InputBox`](#inputbox)

***

### JsonArray

Defined in: [packages/core/src/candid/types.ts:3](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/types.ts#L3)

#### Extends

- `Array`\<[`JsonValue`](#jsonvalue)\>

#### Indexable

> \[`n`: `number`\]: [`JsonValue`](#jsonvalue)

#### Properties

##### \[unscopables\]

> `readonly` **\[unscopables\]**: `object`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts:97

Is an object whose properties have the value 'true'
when they will be absent when used in a 'with' statement.

###### Index Signature

\[`key`: `number`\]: `boolean` \| `undefined`

###### \[iterator\]?

> `optional` **\[iterator\]?**: `boolean`

###### \[unscopables\]?

> `readonly` `optional` **\[unscopables\]?**: `boolean`

Is an object whose properties have the value 'true'
when they will be absent when used in a 'with' statement.

###### at?

> `optional` **at?**: `boolean`

###### concat?

> `optional` **concat?**: `boolean`

###### copyWithin?

> `optional` **copyWithin?**: `boolean`

###### entries?

> `optional` **entries?**: `boolean`

###### every?

> `optional` **every?**: `boolean`

###### fill?

> `optional` **fill?**: `boolean`

###### filter?

> `optional` **filter?**: `boolean`

###### find?

> `optional` **find?**: `boolean`

###### findIndex?

> `optional` **findIndex?**: `boolean`

###### flat?

> `optional` **flat?**: `boolean`

###### flatMap?

> `optional` **flatMap?**: `boolean`

###### forEach?

> `optional` **forEach?**: `boolean`

###### includes?

> `optional` **includes?**: `boolean`

###### indexOf?

> `optional` **indexOf?**: `boolean`

###### join?

> `optional` **join?**: `boolean`

###### keys?

> `optional` **keys?**: `boolean`

###### lastIndexOf?

> `optional` **lastIndexOf?**: `boolean`

###### length?

> `optional` **length?**: `boolean`

Gets or sets the length of the array. This is a number one higher than the highest index in the array.

###### map?

> `optional` **map?**: `boolean`

###### pop?

> `optional` **pop?**: `boolean`

###### push?

> `optional` **push?**: `boolean`

###### reduce?

> `optional` **reduce?**: `boolean`

###### reduceRight?

> `optional` **reduceRight?**: `boolean`

###### reverse?

> `optional` **reverse?**: `boolean`

###### shift?

> `optional` **shift?**: `boolean`

###### slice?

> `optional` **slice?**: `boolean`

###### some?

> `optional` **some?**: `boolean`

###### sort?

> `optional` **sort?**: `boolean`

###### splice?

> `optional` **splice?**: `boolean`

###### toLocaleString?

> `optional` **toLocaleString?**: `boolean`

###### toString?

> `optional` **toString?**: `boolean`

###### unshift?

> `optional` **unshift?**: `boolean`

###### values?

> `optional` **values?**: `boolean`

###### Inherited from

`Array.[unscopables]`

##### length

> **length**: `number`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1329

Gets or sets the length of the array. This is a number one higher than the highest index in the array.

###### Inherited from

`Array.length`

#### Methods

##### \[iterator\]()

> **\[iterator\]**(): `ArrayIterator`\<[`JsonValue`](#jsonvalue)\>

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.iterable.d.ts:78

Iterator

###### Returns

`ArrayIterator`\<[`JsonValue`](#jsonvalue)\>

###### Inherited from

`Array.[iterator]`

##### at()

> **at**(`index`): [`JsonValue`](#jsonvalue) \| `undefined`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2022.array.d.ts:24

Returns the item located at the specified index.

###### Parameters

###### index

`number`

The zero-based index of the desired code unit. A negative index will count back from the last item.

###### Returns

[`JsonValue`](#jsonvalue) \| `undefined`

###### Inherited from

`Array.at`

##### concat()

###### Call Signature

> **concat**(...`items`): [`JsonValue`](#jsonvalue)[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1353

Combines two or more arrays.
This method returns a new array without modifying any existing arrays.

###### Parameters

###### items

...`ConcatArray`\<[`JsonValue`](#jsonvalue)\>[]

Additional arrays and/or items to add to the end of the array.

###### Returns

[`JsonValue`](#jsonvalue)[]

###### Inherited from

`Array.concat`

###### Call Signature

> **concat**(...`items`): [`JsonValue`](#jsonvalue)[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1359

Combines two or more arrays.
This method returns a new array without modifying any existing arrays.

###### Parameters

###### items

...([`JsonValue`](#jsonvalue) \| `ConcatArray`\<[`JsonValue`](#jsonvalue)\>)[]

Additional arrays and/or items to add to the end of the array.

###### Returns

[`JsonValue`](#jsonvalue)[]

###### Inherited from

`Array.concat`

##### copyWithin()

> **copyWithin**(`target`, `start`, `end?`): `this`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.core.d.ts:62

Returns the this object after copying a section of the array identified by start and end
to the same array starting at position target

###### Parameters

###### target

`number`

If target is negative, it is treated as length+target where length is the
length of the array.

###### start

`number`

If start is negative, it is treated as length+start. If end is negative, it
is treated as length+end.

###### end?

`number`

If not specified, length of the this object is used as its default value.

###### Returns

`this`

###### Inherited from

`Array.copyWithin`

##### entries()

> **entries**(): `ArrayIterator`\<\[`number`, [`JsonValue`](#jsonvalue)\]\>

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.iterable.d.ts:83

Returns an iterable of key, value pairs for every entry in the array

###### Returns

`ArrayIterator`\<\[`number`, [`JsonValue`](#jsonvalue)\]\>

###### Inherited from

`Array.entries`

##### every()

###### Call Signature

> **every**\<`S`\>(`predicate`, `thisArg?`): `this is S[]`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1440

Determines whether all the members of an array satisfy the specified test.

###### Type Parameters

###### S

`S` *extends* [`JsonValue`](#jsonvalue)

###### Parameters

###### predicate

(`value`, `index`, `array`) => `value is S`

A function that accepts up to three arguments. The every method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value false, or until the end of the array.

###### thisArg?

`any`

An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.

###### Returns

`this is S[]`

###### Inherited from

`Array.every`

###### Call Signature

> **every**(`predicate`, `thisArg?`): `boolean`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1449

Determines whether all the members of an array satisfy the specified test.

###### Parameters

###### predicate

(`value`, `index`, `array`) => `unknown`

A function that accepts up to three arguments. The every method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value false, or until the end of the array.

###### thisArg?

`any`

An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.

###### Returns

`boolean`

###### Inherited from

`Array.every`

##### fill()

> **fill**(`value`, `start?`, `end?`): `this`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.core.d.ts:51

Changes all array elements from `start` to `end` index to a static `value` and returns the modified array

###### Parameters

###### value

[`JsonValue`](#jsonvalue)

value to fill array section with

###### start?

`number`

index to start filling the array at. If start is negative, it is treated as
length+start where length is the length of the array.

###### end?

`number`

index to stop filling the array at. If end is negative, it is treated as
length+end.

###### Returns

`this`

###### Inherited from

`Array.fill`

##### filter()

###### Call Signature

> **filter**\<`S`\>(`predicate`, `thisArg?`): `S`[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1476

Returns the elements of an array that meet the condition specified in a callback function.

###### Type Parameters

###### S

`S` *extends* [`JsonValue`](#jsonvalue)

###### Parameters

###### predicate

(`value`, `index`, `array`) => `value is S`

A function that accepts up to three arguments. The filter method calls the predicate function one time for each element in the array.

###### thisArg?

`any`

An object to which the this keyword can refer in the predicate function. If thisArg is omitted, undefined is used as the this value.

###### Returns

`S`[]

###### Inherited from

`Array.filter`

###### Call Signature

> **filter**(`predicate`, `thisArg?`): [`JsonValue`](#jsonvalue)[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1482

Returns the elements of an array that meet the condition specified in a callback function.

###### Parameters

###### predicate

(`value`, `index`, `array`) => `unknown`

A function that accepts up to three arguments. The filter method calls the predicate function one time for each element in the array.

###### thisArg?

`any`

An object to which the this keyword can refer in the predicate function. If thisArg is omitted, undefined is used as the this value.

###### Returns

[`JsonValue`](#jsonvalue)[]

###### Inherited from

`Array.filter`

##### find()

###### Call Signature

> **find**\<`S`\>(`predicate`, `thisArg?`): `S` \| `undefined`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.core.d.ts:29

Returns the value of the first element in the array where predicate is true, and undefined
otherwise.

###### Type Parameters

###### S

`S` *extends* [`JsonValue`](#jsonvalue)

###### Parameters

###### predicate

(`value`, `index`, `obj`) => `value is S`

find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found, find
immediately returns that element value. Otherwise, find returns undefined.

###### thisArg?

`any`

If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.

###### Returns

`S` \| `undefined`

###### Inherited from

`Array.find`

###### Call Signature

> **find**(`predicate`, `thisArg?`): [`JsonValue`](#jsonvalue) \| `undefined`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.core.d.ts:30

###### Parameters

###### predicate

(`value`, `index`, `obj`) => `unknown`

###### thisArg?

`any`

###### Returns

[`JsonValue`](#jsonvalue) \| `undefined`

###### Inherited from

`Array.find`

##### findIndex()

> **findIndex**(`predicate`, `thisArg?`): `number`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.core.d.ts:41

Returns the index of the first element in the array where predicate is true, and -1
otherwise.

###### Parameters

###### predicate

(`value`, `index`, `obj`) => `unknown`

find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found,
findIndex immediately returns that element index. Otherwise, findIndex returns -1.

###### thisArg?

`any`

If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.

###### Returns

`number`

###### Inherited from

`Array.findIndex`

##### flat()

> **flat**\<`A`, `D`\>(`this`, `depth?`): `FlatArray`\<`A`, `D`\>[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2019.array.d.ts:75

Returns a new array with all sub-array elements concatenated into it recursively up to the
specified depth.

###### Type Parameters

###### A

`A`

###### D

`D` *extends* `number` = `1`

###### Parameters

###### this

`A`

###### depth?

`D`

The maximum recursion depth

###### Returns

`FlatArray`\<`A`, `D`\>[]

###### Inherited from

`Array.flat`

##### flatMap()

> **flatMap**\<`U`, `This`\>(`callback`, `thisArg?`): `U`[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2019.array.d.ts:64

Calls a defined callback function on each element of an array. Then, flattens the result into
a new array.
This is identical to a map followed by flat with depth 1.

###### Type Parameters

###### U

`U`

###### This

`This` = `undefined`

###### Parameters

###### callback

(`this`, `value`, `index`, `array`) => `U` \| readonly `U`[]

A function that accepts up to three arguments. The flatMap method calls the
callback function one time for each element in the array.

###### thisArg?

`This`

An object to which the this keyword can refer in the callback function. If
thisArg is omitted, undefined is used as the this value.

###### Returns

`U`[]

###### Inherited from

`Array.flatMap`

##### forEach()

> **forEach**(`callbackfn`, `thisArg?`): `void`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1464

Performs the specified action for each element in an array.

###### Parameters

###### callbackfn

(`value`, `index`, `array`) => `void`

A function that accepts up to three arguments. forEach calls the callbackfn function one time for each element in the array.

###### thisArg?

`any`

An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.

###### Returns

`void`

###### Inherited from

`Array.forEach`

##### includes()

> **includes**(`searchElement`, `fromIndex?`): `boolean`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2016.array.include.d.ts:25

Determines whether an array includes a certain element, returning true or false as appropriate.

###### Parameters

###### searchElement

[`JsonValue`](#jsonvalue)

The element to search for.

###### fromIndex?

`number`

The position in this array at which to begin searching for searchElement.

###### Returns

`boolean`

###### Inherited from

`Array.includes`

##### indexOf()

> **indexOf**(`searchElement`, `fromIndex?`): `number`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1425

Returns the index of the first occurrence of a value in an array, or -1 if it is not present.

###### Parameters

###### searchElement

[`JsonValue`](#jsonvalue)

The value to locate in the array.

###### fromIndex?

`number`

The array index at which to begin the search. If fromIndex is omitted, the search starts at index 0.

###### Returns

`number`

###### Inherited from

`Array.indexOf`

##### join()

> **join**(`separator?`): `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1364

Adds all the elements of an array into a string, separated by the specified separator string.

###### Parameters

###### separator?

`string`

A string used to separate one element of the array from the next in the resulting string. If omitted, the array elements are separated with a comma.

###### Returns

`string`

###### Inherited from

`Array.join`

##### keys()

> **keys**(): `ArrayIterator`\<`number`\>

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.iterable.d.ts:88

Returns an iterable of keys in the array

###### Returns

`ArrayIterator`\<`number`\>

###### Inherited from

`Array.keys`

##### lastIndexOf()

> **lastIndexOf**(`searchElement`, `fromIndex?`): `number`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1431

Returns the index of the last occurrence of a specified value in an array, or -1 if it is not present.

###### Parameters

###### searchElement

[`JsonValue`](#jsonvalue)

The value to locate in the array.

###### fromIndex?

`number`

The array index at which to begin searching backward. If fromIndex is omitted, the search starts at the last index in the array.

###### Returns

`number`

###### Inherited from

`Array.lastIndexOf`

##### map()

> **map**\<`U`\>(`callbackfn`, `thisArg?`): `U`[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1470

Calls a defined callback function on each element of an array, and returns an array that contains the results.

###### Type Parameters

###### U

`U`

###### Parameters

###### callbackfn

(`value`, `index`, `array`) => `U`

A function that accepts up to three arguments. The map method calls the callbackfn function one time for each element in the array.

###### thisArg?

`any`

An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.

###### Returns

`U`[]

###### Inherited from

`Array.map`

##### pop()

> **pop**(): [`JsonValue`](#jsonvalue) \| `undefined`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1342

Removes the last element from an array and returns it.
If the array is empty, undefined is returned and the array is not modified.

###### Returns

[`JsonValue`](#jsonvalue) \| `undefined`

###### Inherited from

`Array.pop`

##### push()

> **push**(...`items`): `number`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1347

Appends new elements to the end of an array, and returns the new length of the array.

###### Parameters

###### items

...[`JsonValue`](#jsonvalue)[]

New elements to add to the array.

###### Returns

`number`

###### Inherited from

`Array.push`

##### reduce()

###### Call Signature

> **reduce**(`callbackfn`): [`JsonValue`](#jsonvalue)

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1488

Calls the specified callback function for all the elements in an array. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

###### Parameters

###### callbackfn

(`previousValue`, `currentValue`, `currentIndex`, `array`) => [`JsonValue`](#jsonvalue)

A function that accepts up to four arguments. The reduce method calls the callbackfn function one time for each element in the array.

###### Returns

[`JsonValue`](#jsonvalue)

###### Inherited from

`Array.reduce`

###### Call Signature

> **reduce**(`callbackfn`, `initialValue`): [`JsonValue`](#jsonvalue)

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1489

###### Parameters

###### callbackfn

(`previousValue`, `currentValue`, `currentIndex`, `array`) => [`JsonValue`](#jsonvalue)

###### initialValue

[`JsonValue`](#jsonvalue)

###### Returns

[`JsonValue`](#jsonvalue)

###### Inherited from

`Array.reduce`

###### Call Signature

> **reduce**\<`U`\>(`callbackfn`, `initialValue`): `U`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1495

Calls the specified callback function for all the elements in an array. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

###### Type Parameters

###### U

`U`

###### Parameters

###### callbackfn

(`previousValue`, `currentValue`, `currentIndex`, `array`) => `U`

A function that accepts up to four arguments. The reduce method calls the callbackfn function one time for each element in the array.

###### initialValue

`U`

If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.

###### Returns

`U`

###### Inherited from

`Array.reduce`

##### reduceRight()

###### Call Signature

> **reduceRight**(`callbackfn`): [`JsonValue`](#jsonvalue)

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1501

Calls the specified callback function for all the elements in an array, in descending order. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

###### Parameters

###### callbackfn

(`previousValue`, `currentValue`, `currentIndex`, `array`) => [`JsonValue`](#jsonvalue)

A function that accepts up to four arguments. The reduceRight method calls the callbackfn function one time for each element in the array.

###### Returns

[`JsonValue`](#jsonvalue)

###### Inherited from

`Array.reduceRight`

###### Call Signature

> **reduceRight**(`callbackfn`, `initialValue`): [`JsonValue`](#jsonvalue)

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1502

###### Parameters

###### callbackfn

(`previousValue`, `currentValue`, `currentIndex`, `array`) => [`JsonValue`](#jsonvalue)

###### initialValue

[`JsonValue`](#jsonvalue)

###### Returns

[`JsonValue`](#jsonvalue)

###### Inherited from

`Array.reduceRight`

###### Call Signature

> **reduceRight**\<`U`\>(`callbackfn`, `initialValue`): `U`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1508

Calls the specified callback function for all the elements in an array, in descending order. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

###### Type Parameters

###### U

`U`

###### Parameters

###### callbackfn

(`previousValue`, `currentValue`, `currentIndex`, `array`) => `U`

A function that accepts up to four arguments. The reduceRight method calls the callbackfn function one time for each element in the array.

###### initialValue

`U`

If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.

###### Returns

`U`

###### Inherited from

`Array.reduceRight`

##### reverse()

> **reverse**(): [`JsonValue`](#jsonvalue)[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1369

Reverses the elements in an array in place.
This method mutates the array and returns a reference to the same array.

###### Returns

[`JsonValue`](#jsonvalue)[]

###### Inherited from

`Array.reverse`

##### shift()

> **shift**(): [`JsonValue`](#jsonvalue) \| `undefined`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1374

Removes the first element from an array and returns it.
If the array is empty, undefined is returned and the array is not modified.

###### Returns

[`JsonValue`](#jsonvalue) \| `undefined`

###### Inherited from

`Array.shift`

##### slice()

> **slice**(`start?`, `end?`): [`JsonValue`](#jsonvalue)[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1384

Returns a copy of a section of an array.
For both start and end, a negative index can be used to indicate an offset from the end of the array.
For example, -2 refers to the second to last element of the array.

###### Parameters

###### start?

`number`

The beginning index of the specified portion of the array.
If start is undefined, then the slice begins at index 0.

###### end?

`number`

The end index of the specified portion of the array. This is exclusive of the element at the index 'end'.
If end is undefined, then the slice extends to the end of the array.

###### Returns

[`JsonValue`](#jsonvalue)[]

###### Inherited from

`Array.slice`

##### some()

> **some**(`predicate`, `thisArg?`): `boolean`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1458

Determines whether the specified callback function returns true for any element of an array.

###### Parameters

###### predicate

(`value`, `index`, `array`) => `unknown`

A function that accepts up to three arguments. The some method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value true, or until the end of the array.

###### thisArg?

`any`

An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.

###### Returns

`boolean`

###### Inherited from

`Array.some`

##### sort()

> **sort**(`compareFn?`): `this`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1395

Sorts an array in place.
This method mutates the array and returns a reference to the same array.

###### Parameters

###### compareFn?

(`a`, `b`) => `number`

Function used to determine the order of the elements. It is expected to return
a negative value if the first argument is less than the second argument, zero if they're equal, and a positive
value otherwise. If omitted, the elements are sorted in ascending, UTF-16 code unit order.
```ts
[11,2,22,1].sort((a, b) => a - b)
```

###### Returns

`this`

###### Inherited from

`Array.sort`

##### splice()

###### Call Signature

> **splice**(`start`, `deleteCount?`): [`JsonValue`](#jsonvalue)[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1404

Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted elements.

###### Parameters

###### start

`number`

The zero-based location in the array from which to start removing elements.

###### deleteCount?

`number`

The number of elements to remove. Omitting this argument will remove all elements from the start
paramater location to end of the array. If value of this argument is either a negative number, zero, undefined, or a type
that cannot be converted to an integer, the function will evaluate the argument as zero and not remove any elements.

###### Returns

[`JsonValue`](#jsonvalue)[]

An array containing the elements that were deleted.

###### Inherited from

`Array.splice`

###### Call Signature

> **splice**(`start`, `deleteCount`, ...`items`): [`JsonValue`](#jsonvalue)[]

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1414

Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted elements.

###### Parameters

###### start

`number`

The zero-based location in the array from which to start removing elements.

###### deleteCount

`number`

The number of elements to remove. If value of this argument is either a negative number, zero,
undefined, or a type that cannot be converted to an integer, the function will evaluate the argument as zero and
not remove any elements.

###### items

...[`JsonValue`](#jsonvalue)[]

Elements to insert into the array in place of the deleted elements.

###### Returns

[`JsonValue`](#jsonvalue)[]

An array containing the elements that were deleted.

###### Inherited from

`Array.splice`

##### toLocaleString()

###### Call Signature

> **toLocaleString**(): `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1337

Returns a string representation of an array. The elements are converted to string using their toLocaleString methods.

###### Returns

`string`

###### Inherited from

`Array.toLocaleString`

###### Call Signature

> **toLocaleString**(`locales`, `options?`): `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.core.d.ts:64

###### Parameters

###### locales

`string` \| `string`[]

###### options?

`NumberFormatOptions` & `DateTimeFormatOptions`

###### Returns

`string`

###### Inherited from

`Array.toLocaleString`

##### toString()

> **toString**(): `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1333

Returns a string representation of an array.

###### Returns

`string`

###### Inherited from

`Array.toString`

##### unshift()

> **unshift**(...`items`): `number`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1419

Inserts new elements at the start of an array, and returns the new length of the array.

###### Parameters

###### items

...[`JsonValue`](#jsonvalue)[]

Elements to insert at the start of the array.

###### Returns

`number`

###### Inherited from

`Array.unshift`

##### values()

> **values**(): `ArrayIterator`\<[`JsonValue`](#jsonvalue)\>

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es2015.iterable.d.ts:93

Returns an iterable of values in the array

###### Returns

`ArrayIterator`\<[`JsonValue`](#jsonvalue)\>

###### Inherited from

`Array.values`

***

### JsonObject

Defined in: [packages/core/src/candid/types.ts:5](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/types.ts#L5)

#### Extends

- `Record`\<`string`, [`JsonValue`](#jsonvalue)\>

#### Indexable

> \[`key`: `string`\]: [`JsonValue`](#jsonvalue)

***

### ParseConfig

Defined in: [packages/core/src/candid/candid-core.ts:5](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L5)

#### Properties

##### random?

> `optional` **random?**: `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L6)

***

### UIConfig

Defined in: [packages/core/src/candid/candid-core.ts:9](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L9)

#### Properties

##### form?

> `optional` **form?**: [`InputForm`](#abstract-inputform)

Defined in: [packages/core/src/candid/candid-core.ts:11](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L11)

##### input?

> `optional` **input?**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:10](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L10)

#### Methods

##### parse()

> **parse**(`t`, `config`, `v`): `any`

Defined in: [packages/core/src/candid/candid-core.ts:12](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-core.ts#L12)

###### Parameters

###### t

[`Type`](namespaces/IDL.md#abstract-type)

###### config

[`ParseConfig`](#parseconfig)

###### v

`string`

###### Returns

`any`

## Type Aliases

### JsonValue

> **JsonValue** = `boolean` \| `string` \| `number` \| `bigint` \| [`JsonArray`](#jsonarray) \| [`JsonObject`](#jsonobject)

Defined in: [packages/core/src/candid/types.ts:7](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/types.ts#L7)

***

### Uint8ArrayBuffer

> **Uint8ArrayBuffer** = `ReturnType`\<*typeof* `Uint8Array.of`\>

Defined in: [packages/core/src/candid/utils/buffer.ts:185](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L185)

## Functions

### compare()

> **compare**(`u1`, `u2`): `number`

Defined in: [packages/core/src/candid/utils/buffer.ts:193](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L193)

#### Parameters

##### u1

`Uint8Array`

uint8Array 1

##### u2

`Uint8Array`

uint8Array 2

#### Returns

`number`

number - negative if u1 < u2, positive if u1 > u2, 0 if u1 === u2

***

### concat()

> **concat**(...`uint8Arrays`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:5](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L5)

Concatenate multiple Uint8Arrays.

#### Parameters

##### uint8Arrays

...`Uint8Array`\<`ArrayBufferLike`\>[]

The Uint8Arrays to concatenate.

#### Returns

`Uint8Array`

***

### idlLabelToId()

> **idlLabelToId**(`label`): `number`

Defined in: [packages/core/src/candid/utils/hash.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/hash.ts#L23)

#### Parameters

##### label

`string`

string

#### Returns

`number`

number representing hashed label

***

### inputBox()

> **inputBox**(`t`, `config`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:12](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L12)

#### Parameters

##### t

[`Type`](namespaces/IDL.md#abstract-type)

##### config

`Partial`\<[`UIConfig`](#uiconfig)\>

#### Returns

[`InputBox`](#inputbox)

***

### lebDecode()

> **lebDecode**(`pipe`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:74](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L74)

Decode a leb encoded buffer into a bigint. The number will always be positive (does not
support signed leb encoding).

#### Parameters

##### pipe

[`PipeArrayBuffer`](#pipearraybuffer)

A Buffer containing the leb encoded bits.

#### Returns

`bigint`

***

### lebEncode()

> **lebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:44](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L44)

Encode a positive number (or bigint) into a Buffer. The number will be floored to the
nearest integer.

#### Parameters

##### value

`number` \| `bigint`

The number to encode.

#### Returns

`Uint8Array`

***

### optForm()

> **optForm**(`ty`, `config`): [`OptionForm`](#optionform)

Defined in: [packages/core/src/candid/candid-ui.ts:24](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L24)

#### Parameters

##### ty

[`Type`](namespaces/IDL.md#abstract-type)

##### config

`Partial`\<[`FormConfig`](#formconfig)\>

#### Returns

[`OptionForm`](#optionform)

***

### readIntLE()

> **readIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:223](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L223)

#### Parameters

##### pipe

[`PipeArrayBuffer`](#pipearraybuffer)

Pipe from buffer-pipe

##### byteLength

`number`

number

#### Returns

`bigint`

bigint

***

### readUIntLE()

> **readUIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:202](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L202)

#### Parameters

##### pipe

[`PipeArrayBuffer`](#pipearraybuffer)

Pipe from buffer-pipe

##### byteLength

`number`

number

#### Returns

`bigint`

bigint

***

### recordForm()

> **recordForm**(`fields`, `config`): [`RecordForm`](#recordform)

Defined in: [packages/core/src/candid/candid-ui.ts:15](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L15)

#### Parameters

##### fields

\[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

##### config

`Partial`\<[`FormConfig`](#formconfig)\>

#### Returns

[`RecordForm`](#recordform)

***

### renderInput()

> **renderInput**(`t`): [`InputBox`](#inputbox)

Defined in: [packages/core/src/candid/candid-ui.ts:202](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L202)

#### Parameters

##### t

[`Type`](namespaces/IDL.md#abstract-type)

an IDL type

#### Returns

[`InputBox`](#inputbox)

an input for that type

***

### renderValue()

> **renderValue**(`t`, `input`, `value`): `void`

Defined in: [packages/core/src/candid/candid-ui.ts:218](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L218)

#### Parameters

##### t

[`Type`](namespaces/IDL.md#abstract-type)

an IDL Type

##### input

[`InputBox`](#inputbox)

an InputBox

##### value

`any`

any

#### Returns

`void`

rendering that value to the provided input

***

### safeRead()

> **safeRead**(`pipe`, `num`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:21](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L21)

#### Parameters

##### pipe

[`PipeArrayBuffer`](#pipearraybuffer)

Pipe from buffer-pipe

##### num

`number`

number

#### Returns

`Uint8Array`

Uint8Array

***

### safeReadUint8()

> **safeReadUint8**(`pipe`): `number`

Defined in: [packages/core/src/candid/utils/leb128.ts:31](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L31)

#### Parameters

##### pipe

[`PipeArrayBuffer`](#pipearraybuffer)

PipeArrayBuffer simulating buffer-pipe api

#### Returns

`number`

***

### slebDecode()

> **slebDecode**(`pipe`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L134)

Decode a leb encoded buffer into a bigint. The number is decoded with support for negative
signed-leb encoding.

#### Parameters

##### pipe

[`PipeArrayBuffer`](#pipearraybuffer)

A Buffer containing the signed leb encoded bits.

#### Returns

`bigint`

***

### slebEncode()

> **slebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:93](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L93)

Encode a number (or bigint) into a Buffer, with support for negative numbers. The number
will be floored to the nearest integer.

#### Parameters

##### value

`number` \| `bigint`

The number to encode.

#### Returns

`Uint8Array`

***

### tupleForm()

> **tupleForm**(`components`, `config`): [`TupleForm`](#tupleform)

Defined in: [packages/core/src/candid/candid-ui.ts:18](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L18)

#### Parameters

##### components

[`Type`](namespaces/IDL.md#abstract-type)\<`any`\>[]

##### config

`Partial`\<[`FormConfig`](#formconfig)\>

#### Returns

[`TupleForm`](#tupleform)

***

### uint8Equals()

> **uint8Equals**(`u1`, `u2`): `boolean`

Defined in: [packages/core/src/candid/utils/buffer.ts:211](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L211)

Checks two uint8Arrays for equality.

#### Parameters

##### u1

`Uint8Array`

uint8Array 1

##### u2

`Uint8Array`

uint8Array 2

#### Returns

`boolean`

boolean

***

### uint8FromBufLike()

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:153](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L153)

Returns a true Uint8Array from an ArrayBufferLike object.

#### Parameters

##### bufLike

`ArrayBufferLike` \| `Uint8Array`\<`ArrayBufferLike`\> \| `number`[] \| `DataView`\<`ArrayBufferLike`\> \| `ArrayBufferView`\<`ArrayBufferLike`\> \| \[`number`\] \| \{ `buffer`: `ArrayBuffer`; \}

a buffer-like object

#### Returns

`Uint8Array`

Uint8Array

***

### uint8ToDataView()

> **uint8ToDataView**(`uint8`): `DataView`

Defined in: [packages/core/src/candid/utils/buffer.ts:220](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/buffer.ts#L220)

Helpers to convert a Uint8Array to a DataView.

#### Parameters

##### uint8

`Uint8Array`

Uint8Array

#### Returns

`DataView`

DataView

***

### variantForm()

> **variantForm**(`fields`, `config`): [`VariantForm`](#variantform)

Defined in: [packages/core/src/candid/candid-ui.ts:21](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L21)

#### Parameters

##### fields

\[`string`, [`Type`](namespaces/IDL.md#abstract-type)\<`any`\>\][]

##### config

`Partial`\<[`FormConfig`](#formconfig)\>

#### Returns

[`VariantForm`](#variantform)

***

### vecForm()

> **vecForm**(`ty`, `config`): [`VecForm`](#vecform)

Defined in: [packages/core/src/candid/candid-ui.ts:27](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/candid-ui.ts#L27)

#### Parameters

##### ty

[`Type`](namespaces/IDL.md#abstract-type)

##### config

`Partial`\<[`FormConfig`](#formconfig)\>

#### Returns

[`VecForm`](#vecform)

***

### writeIntLE()

> **writeIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:175](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L175)

#### Parameters

##### value

`number` \| `bigint`

bigint or number

##### byteLength

`number`

number

#### Returns

`Uint8Array`

Uint8Array

***

### writeUIntLE()

> **writeUIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:162](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/candid/utils/leb128.ts#L162)

#### Parameters

##### value

`number` \| `bigint`

bigint or number

##### byteLength

`number`

number

#### Returns

`Uint8Array`

Uint8Array

## References

### GenericIdlFuncArgs

Re-exports [GenericIdlFuncArgs](namespaces/IDL.md#genericidlfuncargs)

***

### GenericIdlFuncRets

Re-exports [GenericIdlFuncRets](namespaces/IDL.md#genericidlfuncrets)

***

### GenericIdlServiceFields

Re-exports [GenericIdlServiceFields](namespaces/IDL.md#genericidlservicefields)
