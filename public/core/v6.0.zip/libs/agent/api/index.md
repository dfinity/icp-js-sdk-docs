---
title: Overview
editUrl: false
next: true
prev: true
---

## Namespaces

- [CanisterStatus](namespaces/CanisterStatus.md)
- [polling](namespaces/polling.md)
- [strategy](namespaces/strategy.md)
- [SubnetStatus](namespaces/SubnetStatus-1.md)

## Enumerations

### Endpoint

Defined in: [packages/core/src/agent/agent/http/types.ts:8](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L8)

**`Internal`**

#### Enumeration Members

##### Call

> **Call**: `"call"`

Defined in: [packages/core/src/agent/agent/http/types.ts:11](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L11)

##### Query

> **Query**: `"read"`

Defined in: [packages/core/src/agent/agent/http/types.ts:9](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L9)

##### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/core/src/agent/agent/http/types.ts:10](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L10)

***

### ErrorKindEnum

Defined in: [packages/core/src/agent/errors.ts:15](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L15)

#### Enumeration Members

##### External

> **External**: `"External"`

Defined in: [packages/core/src/agent/errors.ts:20](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L20)

##### Input

> **Input**: `"Input"`

Defined in: [packages/core/src/agent/errors.ts:22](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L22)

##### Limit

> **Limit**: `"Limit"`

Defined in: [packages/core/src/agent/errors.ts:21](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L21)

##### Protocol

> **Protocol**: `"Protocol"`

Defined in: [packages/core/src/agent/errors.ts:17](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L17)

##### Reject

> **Reject**: `"Reject"`

Defined in: [packages/core/src/agent/errors.ts:18](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L18)

##### Transport

> **Transport**: `"Transport"`

Defined in: [packages/core/src/agent/errors.ts:19](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L19)

##### Trust

> **Trust**: `"Trust"`

Defined in: [packages/core/src/agent/errors.ts:16](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L16)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/errors.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L23)

***

### ErrorVerbosity

Defined in: [packages/core/src/agent/errors.ts:56](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L56)

Controls the level of detail included in error messages.
- `Normal` (default): includes error message, call context, and HTTP details, but omits large binary fields (arg, certificate, nonce).
- `Verbose`: same as Normal, but includes hex-encoded binary fields.

To enable verbose mode: `ErrorCode.verbosity = ErrorVerbosity.Verbose`

#### Enumeration Members

##### Normal

> **Normal**: `"normal"`

Defined in: [packages/core/src/agent/errors.ts:57](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L57)

##### Verbose

> **Verbose**: `"verbose"`

Defined in: [packages/core/src/agent/errors.ts:58](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L58)

***

### LookupLabelStatus

Defined in: [packages/core/src/agent/certificate.ts:562](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L562)

#### Enumeration Members

##### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:563](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L563)

##### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:565](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L565)

##### Greater

> **Greater**: `"Greater"`

Defined in: [packages/core/src/agent/certificate.ts:567](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L567)

##### Less

> **Less**: `"Less"`

Defined in: [packages/core/src/agent/certificate.ts:566](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L566)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:564](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L564)

***

### LookupPathStatus

Defined in: [packages/core/src/agent/certificate.ts:508](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L508)

#### Enumeration Members

##### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:510](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L510)

##### Error

> **Error**: `"Error"`

Defined in: [packages/core/src/agent/certificate.ts:512](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L512)

##### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:511](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L511)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:509](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L509)

***

### LookupSubtreeStatus

Defined in: [packages/core/src/agent/certificate.ts:538](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L538)

#### Enumeration Members

##### Absent

> **Absent**: `"Absent"`

Defined in: [packages/core/src/agent/certificate.ts:539](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L539)

##### Found

> **Found**: `"Found"`

Defined in: [packages/core/src/agent/certificate.ts:541](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L541)

##### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/certificate.ts:540](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L540)

***

### NodeType

Defined in: [packages/core/src/agent/certificate.ts:47](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L47)

#### Enumeration Members

##### Empty

> **Empty**: `0`

Defined in: [packages/core/src/agent/certificate.ts:48](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L48)

##### Fork

> **Fork**: `1`

Defined in: [packages/core/src/agent/certificate.ts:49](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L49)

##### Labeled

> **Labeled**: `2`

Defined in: [packages/core/src/agent/certificate.ts:50](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L50)

##### Leaf

> **Leaf**: `3`

Defined in: [packages/core/src/agent/certificate.ts:51](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L51)

##### Pruned

> **Pruned**: `4`

Defined in: [packages/core/src/agent/certificate.ts:52](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L52)

***

### QueryResponseStatus

Defined in: [packages/core/src/agent/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L35)

#### Enumeration Members

##### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/api.ts:37](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L37)

##### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L36)

***

### ReadRequestType

Defined in: [packages/core/src/agent/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L78)

#### Enumeration Members

##### Query

> **Query**: `"query"`

Defined in: [packages/core/src/agent/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L79)

##### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/core/src/agent/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L80)

***

### ReplicaRejectCode

Defined in: [packages/core/src/agent/agent/api.ts:12](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L12)

Codes used by the replica for rejecting a message.
See [the interface spec](https://sdk.dfinity.org/docs/interface-spec/#reject-codes).

#### Enumeration Members

##### CanisterError

> **CanisterError**: `5`

Defined in: [packages/core/src/agent/agent/api.ts:17](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L17)

##### CanisterReject

> **CanisterReject**: `4`

Defined in: [packages/core/src/agent/agent/api.ts:16](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L16)

##### DestinationInvalid

> **DestinationInvalid**: `3`

Defined in: [packages/core/src/agent/agent/api.ts:15](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L15)

##### SysFatal

> **SysFatal**: `1`

Defined in: [packages/core/src/agent/agent/api.ts:13](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L13)

##### SysTransient

> **SysTransient**: `2`

Defined in: [packages/core/src/agent/agent/api.ts:14](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L14)

***

### RequestStatusResponseStatus

Defined in: [packages/core/src/agent/agent/http/types.ts:109](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L109)

Possible values for the request status in the IC state tree.

#### See

https://internetcomputer.org/docs/references/ic-interface-spec#state-tree-request-status

#### Enumeration Members

##### Done

> **Done**: `"done"`

Defined in: [packages/core/src/agent/agent/http/types.ts:121](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L121)

The IC has pruned the response data but remembers the request to prevent replay attacks.

##### Processing

> **Processing**: `"processing"`

Defined in: [packages/core/src/agent/agent/http/types.ts:113](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L113)

The initial effect of the call has happened or will happen.

##### Received

> **Received**: `"received"`

Defined in: [packages/core/src/agent/agent/http/types.ts:111](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L111)

The call has made it past the endpoint into the IC's state.

##### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/http/types.ts:117](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L117)

The call failed; reject code and message are available at `/request_status/<id>/reject_code` and `/request_status/<id>/reject_message`.

##### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/http/types.ts:115](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L115)

The call completed successfully; the reply is available at `/request_status/<id>/reply`.

##### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/core/src/agent/agent/http/types.ts:119](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L119)

The request status path is absent from the state tree, the request is unknown to the IC (never received or pruned after expiry).

***

### SubmitRequestType

Defined in: [packages/core/src/agent/agent/http/types.ts:73](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L73)

#### Enumeration Members

##### Call

> **Call**: `"call"`

Defined in: [packages/core/src/agent/agent/http/types.ts:74](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L74)

## Classes

### Actor

Defined in: [packages/core/src/agent/actor.ts:191](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L191)

An actor base class. An actor is an object containing only functions that will
return a promise. These functions are derived from the IDL definition.

#### Constructors

##### Constructor

> `protected` **new Actor**(`metadata`): [`Actor`](#actor)

Defined in: [packages/core/src/agent/actor.ts:358](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L358)

###### Parameters

###### metadata

`ActorMetadata`

###### Returns

[`Actor`](#actor)

#### Methods

##### agentOf()

> `static` **agentOf**(`actor`): [`Agent`](#agent-1) \| `undefined`

Defined in: [packages/core/src/agent/actor.ts:197](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L197)

Get the Agent class this Actor would call, or undefined if the Actor would use
the default agent (global.ic.agent).

###### Parameters

###### actor

[`Actor`](#actor)

The actor to get the agent of.

###### Returns

[`Agent`](#agent-1) \| `undefined`

##### canisterIdOf()

> `static` **canisterIdOf**(`actor`): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:209](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L209)

###### Parameters

###### actor

[`Actor`](#actor)

###### Returns

[`Principal`](../../principal/api.md#principal)

##### createActor()

> `static` **createActor**\<`T`\>(`interfaceFactory`, `configuration`): [`ActorSubclass`](#actorsubclass)\<`T`\>

Defined in: [packages/core/src/agent/actor.ts:310](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L310)

Creates an actor with the given interface factory and configuration.

The [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package can be used to generate the interface factory for your canister.

###### Type Parameters

###### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\<`unknown`[], `unknown`\>\>

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

the interface factory for the actor, typically generated by the [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package

###### configuration

[`ActorConfig`](#actorconfig)

the configuration for the actor

###### Returns

[`ActorSubclass`](#actorsubclass)\<`T`\>

an actor with the given interface factory and configuration

###### See

The [Canister Environment Guide](https://js.icp.build/core/latest/canister-environment/) for more details on how to configure an actor using the canister environment.

###### Examples

Using the interface factory generated by the [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package:
```ts
import { Actor, HttpAgent } from '@icp-sdk/core/agent';
import { Principal } from '@icp-sdk/core/principal';
import { idlFactory } from './api/declarations/hello-world.did';

// For a convenient way to get the canister ID,
// see the https://js.icp.build/core/latest/canister-environment/ guide.
const canisterId = Principal.fromText('rrkah-fqaaa-aaaaa-aaaaq-cai');

const agent = await HttpAgent.create({
  host: 'https://icp-api.io',
});

const actor = Actor.createActor(idlFactory, {
  agent,
  canisterId,
});

const response = await actor.greet('world');
console.log(response);
```

Using the `createActor` wrapper function generated by the [`@icp-sdk/bindgen`](https://js.icp.build/bindgen/) package:
```ts
import { HttpAgent } from '@icp-sdk/core/agent';
import { Principal } from '@icp-sdk/core/principal';
import { createActor } from './api/hello-world';

// For a convenient way to get the canister ID,
// see the https://js.icp.build/core/latest/canister-environment/ guide.
const canisterId = Principal.fromText('rrkah-fqaaa-aaaaa-aaaaq-cai');

const agent = await HttpAgent.create({
  host: 'https://icp-api.io',
});

const actor = createActor(canisterId, {
  agent,
});

const response = await actor.greet('world');
console.log(response);
```

##### createActorClass()

> `static` **createActorClass**(`interfaceFactory`, `options?`): [`ActorConstructor`](#actorconstructor-1)

Defined in: [packages/core/src/agent/actor.ts:213](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L213)

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

###### options?

[`CreateActorClassOpts`](#createactorclassopts)

###### Returns

[`ActorConstructor`](#actorconstructor-1)

##### createActorWithExtendedDetails()

> `static` **createActorWithExtendedDetails**\<`T`\>(`interfaceFactory`, `configuration`, `actorClassOptions?`): [`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedExtended`](#actormethodmappedextended)\<`T`\>\>

Defined in: [packages/core/src/agent/actor.ts:343](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L343)

Returns an actor with methods that return the http response details along with the result

###### Type Parameters

###### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\<`unknown`[], `unknown`\>\>

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

the interface factory for the actor

###### configuration

[`ActorConfig`](#actorconfig)

the configuration for the actor

###### actorClassOptions?

[`CreateActorClassOpts`](#createactorclassopts) = `...`

options for the actor class extended details to return with the result

###### Returns

[`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedExtended`](#actormethodmappedextended)\<`T`\>\>

##### ~~createActorWithHttpDetails()~~

> `static` **createActorWithHttpDetails**\<`T`\>(`interfaceFactory`, `configuration`): [`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedWithHttpDetails`](#actormethodmappedwithhttpdetails)\<`T`\>\>

Defined in: [packages/core/src/agent/actor.ts:328](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L328)

Returns an actor with methods that return the http response details along with the result

###### Type Parameters

###### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\<`unknown`[], `unknown`\>\>

###### Parameters

###### interfaceFactory

[`InterfaceFactory`](../../candid/api/namespaces/IDL.md#interfacefactory)

the interface factory for the actor

###### configuration

[`ActorConfig`](#actorconfig)

the configuration for the actor

###### Returns

[`ActorSubclass`](#actorsubclass)\<[`ActorMethodMappedWithHttpDetails`](#actormethodmappedwithhttpdetails)\<`T`\>\>

###### Deprecated

- use createActor with actorClassOptions instead

##### interfaceOf()

> `static` **interfaceOf**(`actor`): [`ServiceClass`](../../candid/api/namespaces/IDL.md#serviceclass)

Defined in: [packages/core/src/agent/actor.ts:205](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L205)

Get the interface of an actor, in the form of an instance of a Service.

###### Parameters

###### actor

[`Actor`](#actor)

The actor to get the interface of.

###### Returns

[`ServiceClass`](../../candid/api/namespaces/IDL.md#serviceclass)

***

### AgentError

Defined in: [packages/core/src/agent/errors.ts:122](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L122)

An error that happens in the Agent. This is the root of all errors and should be used
everywhere in the Agent code (this package).

To know if the error is certified, use the `isCertified` getter.

#### Extends

- `Error`

#### Constructors

##### Constructor

> **new AgentError**(`code`, `kind`): [`AgentError`](#agenterror)

Defined in: [packages/core/src/agent/errors.ts:149](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L149)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

[`AgentError`](#agenterror)

###### Overrides

`Error.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Overrides

`Error.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`Error.message`

##### name

> **name**: `string` = `'AgentError'`

Defined in: [packages/core/src/agent/errors.ts:123](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L123)

###### Overrides

`Error.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`Error.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`Error.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`Error.captureStackTrace`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`Error.prepareStackTrace`

***

### AnonymousIdentity

Defined in: [packages/core/src/agent/auth.ts:102](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L102)

A General Identity object. This does not have to be a private key (for example,
the Anonymous identity), but it must be able to transform request.

#### Implements

- [`Identity`](#identity-1)

#### Constructors

##### Constructor

> **new AnonymousIdentity**(): [`AnonymousIdentity`](#anonymousidentity)

###### Returns

[`AnonymousIdentity`](#anonymousidentity)

#### Methods

##### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/auth.ts:103](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L103)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

###### Returns

[`Principal`](../../principal/api.md#principal)

###### Implementation of

[`Identity`](#identity-1).[`getPrincipal`](#getprincipal-4)

##### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:107](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L107)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

###### Returns

`Promise`\<`unknown`\>

###### Implementation of

[`Identity`](#identity-1).[`transformRequest`](#transformrequest-2)

***

### CborDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:442](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L442)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CborDecodeErrorCode**(`error`, `input`): [`CborDecodeErrorCode`](#cbordecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:445](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L445)

###### Parameters

###### error

`unknown`

###### input

`Uint8Array`

###### Returns

[`CborDecodeErrorCode`](#cbordecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:446](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L446)

##### input

> `readonly` **input**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:447](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L447)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CborDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:443](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L443)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:453](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L453)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CborEncodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:458](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L458)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CborEncodeErrorCode**(`error`, `value`): [`CborEncodeErrorCode`](#cborencodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:461](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L461)

###### Parameters

###### error

`unknown`

###### value

`unknown`

###### Returns

[`CborEncodeErrorCode`](#cborencodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:462](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L462)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CborEncodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:459](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L459)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### value

> `readonly` **value**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:463](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L463)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:469](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L469)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### Certificate

Defined in: [packages/core/src/agent/certificate.ts:213](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L213)

#### Properties

##### cert

> **cert**: [`Cert`](#cert-1)

Defined in: [packages/core/src/agent/certificate.ts:214](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L214)

#### Methods

##### lookup\_path()

> **lookup\_path**(`path`): [`LookupResult`](#lookupresult)

Defined in: [packages/core/src/agent/certificate.ts:265](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L265)

Lookup a path in the certificate tree, using [lookup\_path](#lookup_path-1).

###### Parameters

###### path

[`NodePath`](#nodepath)

The path to lookup.

###### Returns

[`LookupResult`](#lookupresult)

The result of the lookup.

##### lookup\_subtree()

> **lookup\_subtree**(`path`): [`SubtreeLookupResult`](#subtreelookupresult)

Defined in: [packages/core/src/agent/certificate.ts:274](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L274)

Lookup a subtree in the certificate tree, using [lookup\_subtree](#lookup_subtree-1).

###### Parameters

###### path

[`NodePath`](#nodepath)

The path to lookup.

###### Returns

[`SubtreeLookupResult`](#subtreelookupresult)

The result of the lookup.

##### create()

> `static` **create**(`options`): `Promise`\<[`Certificate`](#certificate)\>

Defined in: [packages/core/src/agent/certificate.ts:224](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L224)

Create a new instance of a certificate, automatically verifying it.

###### Parameters

###### options

[`CreateCertificateOptions`](#createcertificateoptions)

[CreateCertificateOptions](#createcertificateoptions)

###### Returns

`Promise`\<[`Certificate`](#certificate)\>

###### Throws

if the verification of the certificate fails

***

### CertificateHasTooManyDelegationsErrorCode

Defined in: [packages/core/src/agent/errors.ts:284](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L284)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateHasTooManyDelegationsErrorCode**(): [`CertificateHasTooManyDelegationsErrorCode`](#certificatehastoomanydelegationserrorcode)

Defined in: [packages/core/src/agent/errors.ts:287](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L287)

###### Returns

[`CertificateHasTooManyDelegationsErrorCode`](#certificatehastoomanydelegationserrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CertificateHasTooManyDelegationsErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:285](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L285)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:292](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L292)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CertificateNotAuthorizedErrorCode

Defined in: [packages/core/src/agent/errors.ts:297](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L297)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateNotAuthorizedErrorCode**(`canisterId`, `subnetId`): [`CertificateNotAuthorizedErrorCode`](#certificatenotauthorizederrorcode)

Defined in: [packages/core/src/agent/errors.ts:300](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L300)

###### Parameters

###### canisterId

[`Principal`](../../principal/api.md#principal)

###### subnetId

[`Principal`](../../principal/api.md#principal)

###### Returns

[`CertificateNotAuthorizedErrorCode`](#certificatenotauthorizederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### canisterId

> `readonly` **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:301](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L301)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CertificateNotAuthorizedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:298](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L298)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### subnetId

> `readonly` **subnetId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:302](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L302)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:308](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L308)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CertificateNotAuthorizedForSubnetErrorCode

Defined in: [packages/core/src/agent/errors.ts:313](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L313)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateNotAuthorizedForSubnetErrorCode**(`subnetId`): [`CertificateNotAuthorizedForSubnetErrorCode`](#certificatenotauthorizedforsubneterrorcode)

Defined in: [packages/core/src/agent/errors.ts:316](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L316)

###### Parameters

###### subnetId

[`Principal`](../../principal/api.md#principal)

###### Returns

[`CertificateNotAuthorizedForSubnetErrorCode`](#certificatenotauthorizedforsubneterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CertificateNotAuthorizedForSubnetErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:314](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L314)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### subnetId

> `readonly` **subnetId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:316](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L316)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:321](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L321)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CertificateOutdatedErrorCode

Defined in: [packages/core/src/agent/errors.ts:511](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L511)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateOutdatedErrorCode**(`maxIngressExpiryInMinutes`, `requestId`, `retryTimes?`): [`CertificateOutdatedErrorCode`](#certificateoutdatederrorcode)

Defined in: [packages/core/src/agent/errors.ts:514](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L514)

###### Parameters

###### maxIngressExpiryInMinutes

`number`

###### requestId

[`RequestId`](#requestid-9)

###### retryTimes?

`number`

###### Returns

[`CertificateOutdatedErrorCode`](#certificateoutdatederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### maxIngressExpiryInMinutes

> `readonly` **maxIngressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:515](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L515)

##### name

> **name**: `string` = `'CertificateOutdatedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:512](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L512)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:516](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L516)

##### retryTimes?

> `readonly` `optional` **retryTimes?**: `number`

Defined in: [packages/core/src/agent/errors.ts:517](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L517)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:523](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L523)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CertificateTimeErrorCode

Defined in: [packages/core/src/agent/errors.ts:265](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L265)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateTimeErrorCode**(`maxAgeInMinutes`, `certificateTime`, `currentTime`, `timeDiffMsecs`, `ageType`): [`CertificateTimeErrorCode`](#certificatetimeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:268](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L268)

###### Parameters

###### maxAgeInMinutes

`number`

###### certificateTime

`Date`

###### currentTime

`Date`

###### timeDiffMsecs

`number`

###### ageType

`"past"` \| `"future"`

###### Returns

[`CertificateTimeErrorCode`](#certificatetimeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### ageType

> `readonly` **ageType**: `"past"` \| `"future"`

Defined in: [packages/core/src/agent/errors.ts:273](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L273)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### certificateTime

> `readonly` **certificateTime**: `Date`

Defined in: [packages/core/src/agent/errors.ts:270](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L270)

##### currentTime

> `readonly` **currentTime**: `Date`

Defined in: [packages/core/src/agent/errors.ts:271](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L271)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### maxAgeInMinutes

> `readonly` **maxAgeInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:269](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L269)

##### name

> **name**: `string` = `'CertificateTimeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:266](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L266)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### timeDiffMsecs

> `readonly` **timeDiffMsecs**: `number`

Defined in: [packages/core/src/agent/errors.ts:272](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L272)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:279](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L279)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CertificateVerificationErrorCode

Defined in: [packages/core/src/agent/errors.ts:245](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L245)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertificateVerificationErrorCode**(`reason`, `error?`): [`CertificateVerificationErrorCode`](#certificateverificationerrorcode)

Defined in: [packages/core/src/agent/errors.ts:248](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L248)

###### Parameters

###### reason

`string`

###### error?

`unknown`

###### Returns

[`CertificateVerificationErrorCode`](#certificateverificationerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error?

> `readonly` `optional` **error?**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:250](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L250)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CertificateVerificationErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:246](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L246)

##### reason

> `readonly` **reason**: `string`

Defined in: [packages/core/src/agent/errors.ts:249](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L249)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:256](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L256)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CertifiedRejectErrorCode

Defined in: [packages/core/src/agent/errors.ts:532](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L532)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CertifiedRejectErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`): [`CertifiedRejectErrorCode`](#certifiedrejecterrorcode)

Defined in: [packages/core/src/agent/errors.ts:535](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L535)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### rejectCode

[`ReplicaRejectCode`](#replicarejectcode)

###### rejectMessage

`string`

###### rejectErrorCode

`string` \| `undefined`

###### Returns

[`CertifiedRejectErrorCode`](#certifiedrejecterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CertifiedRejectErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:533](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L533)

##### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/errors.ts:537](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L537)

##### rejectErrorCode

> `readonly` **rejectErrorCode**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:539](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L539)

##### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:538](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L538)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:536](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L536)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:545](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L545)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### CreateHttpAgentErrorCode

Defined in: [packages/core/src/agent/errors.ts:692](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L692)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new CreateHttpAgentErrorCode**(): [`CreateHttpAgentErrorCode`](#createhttpagenterrorcode)

Defined in: [packages/core/src/agent/errors.ts:695](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L695)

###### Returns

[`CreateHttpAgentErrorCode`](#createhttpagenterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'CreateHttpAgentErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:693](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L693)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:700](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L700)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### DerDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:416](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L416)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerDecodeErrorCode**(`error`): [`DerDecodeErrorCode`](#derdecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:419](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L419)

###### Parameters

###### error

`string`

###### Returns

[`DerDecodeErrorCode`](#derdecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:419](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L419)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'DerDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:417](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L417)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:424](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L424)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### DerDecodeLengthMismatchErrorCode

Defined in: [packages/core/src/agent/errors.ts:400](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L400)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerDecodeLengthMismatchErrorCode**(`expectedLength`, `actualLength`): [`DerDecodeLengthMismatchErrorCode`](#derdecodelengthmismatcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:403](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L403)

###### Parameters

###### expectedLength

`number`

###### actualLength

`number`

###### Returns

[`DerDecodeLengthMismatchErrorCode`](#derdecodelengthmismatcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### actualLength

> `readonly` **actualLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:405](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L405)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:404](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L404)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'DerDecodeLengthMismatchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:401](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L401)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:411](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L411)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### DerEncodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:429](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L429)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerEncodeErrorCode**(`error`): [`DerEncodeErrorCode`](#derencodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:432](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L432)

###### Parameters

###### error

`string`

###### Returns

[`DerEncodeErrorCode`](#derencodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:432](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L432)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'DerEncodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:430](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L430)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:437](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L437)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### DerKeyLengthMismatchErrorCode

Defined in: [packages/core/src/agent/errors.ts:368](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L368)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerKeyLengthMismatchErrorCode**(`expectedLength`, `actualLength`): [`DerKeyLengthMismatchErrorCode`](#derkeylengthmismatcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:371](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L371)

###### Parameters

###### expectedLength

`number`

###### actualLength

`number`

###### Returns

[`DerKeyLengthMismatchErrorCode`](#derkeylengthmismatcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### actualLength

> `readonly` **actualLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:373](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L373)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:372](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L372)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'DerKeyLengthMismatchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:369](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L369)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:379](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L379)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### DerPrefixMismatchErrorCode

Defined in: [packages/core/src/agent/errors.ts:384](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L384)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new DerPrefixMismatchErrorCode**(`expectedPrefix`, `actualPrefix`): [`DerPrefixMismatchErrorCode`](#derprefixmismatcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:387](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L387)

###### Parameters

###### expectedPrefix

`Uint8Array`

###### actualPrefix

`Uint8Array`

###### Returns

[`DerPrefixMismatchErrorCode`](#derprefixmismatcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### actualPrefix

> `readonly` **actualPrefix**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:389](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L389)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### expectedPrefix

> `readonly` **expectedPrefix**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:388](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L388)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'DerPrefixMismatchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:385](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L385)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:395](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L395)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### Ed25519PublicKey

Defined in: [packages/core/src/agent/public\_key.ts:6](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L6)

A Public Key implementation.

#### Implements

- [`PublicKey`](#publickey-1)

#### Accessors

##### derKey

###### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/public\_key.ts:44](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L44)

###### Returns

[`DerEncodedPublicKey`](#derencodedpublickey)

###### Implementation of

[`PublicKey`](#publickey-1).[`derKey`](#derkey-1)

##### rawKey

###### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/core/src/agent/public\_key.ts:38](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L38)

###### Returns

`Uint8Array`

###### Implementation of

[`PublicKey`](#publickey-1).[`rawKey`](#rawkey-1)

#### Methods

##### toDer()

> **toDer**(): [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/public\_key.ts:59](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L59)

###### Returns

[`DerEncodedPublicKey`](#derencodedpublickey)

###### Implementation of

[`PublicKey`](#publickey-1).[`toDer`](#toder-1)

##### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/agent/public\_key.ts:63](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L63)

###### Returns

`Uint8Array`

###### Implementation of

[`PublicKey`](#publickey-1).[`toRaw`](#toraw-1)

##### from()

> `static` **from**(`key`): [`Ed25519PublicKey`](#ed25519publickey)

Defined in: [packages/core/src/agent/public\_key.ts:7](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L7)

###### Parameters

###### key

[`PublicKey`](#publickey-1)

###### Returns

[`Ed25519PublicKey`](#ed25519publickey)

##### fromDer()

> `static` **fromDer**(`derKey`): [`Ed25519PublicKey`](#ed25519publickey)

Defined in: [packages/core/src/agent/public\_key.ts:15](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L15)

###### Parameters

###### derKey

[`DerEncodedPublicKey`](#derencodedpublickey)

###### Returns

[`Ed25519PublicKey`](#ed25519publickey)

##### fromRaw()

> `static` **fromRaw**(`rawKey`): [`Ed25519PublicKey`](#ed25519publickey)

Defined in: [packages/core/src/agent/public\_key.ts:11](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/public_key.ts#L11)

###### Parameters

###### rawKey

`Uint8Array`

###### Returns

[`Ed25519PublicKey`](#ed25519publickey)

***

### EffectiveSubnetIdAsyncErrorCode

Defined in: [packages/core/src/agent/errors.ts:955](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L955)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new EffectiveSubnetIdAsyncErrorCode**(): [`EffectiveSubnetIdAsyncErrorCode`](#effectivesubnetidasyncerrorcode)

Defined in: [packages/core/src/agent/errors.ts:958](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L958)

###### Returns

[`EffectiveSubnetIdAsyncErrorCode`](#effectivesubnetidasyncerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'EffectiveSubnetIdAsyncErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:956](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L956)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:963](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L963)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### EmptyCookieErrorCode

Defined in: [packages/core/src/agent/errors.ts:942](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L942)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new EmptyCookieErrorCode**(`expectedCookieName`): [`EmptyCookieErrorCode`](#emptycookieerrorcode)

Defined in: [packages/core/src/agent/errors.ts:945](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L945)

###### Parameters

###### expectedCookieName

`string`

###### Returns

[`EmptyCookieErrorCode`](#emptycookieerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### expectedCookieName

> `readonly` **expectedCookieName**: `string`

Defined in: [packages/core/src/agent/errors.ts:945](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L945)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'EmptyCookieErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:943](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L943)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:950](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L950)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### `abstract` ErrorCode

Defined in: [packages/core/src/agent/errors.ts:75](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L75)

#### Extended by

- [`CertificateVerificationErrorCode`](#certificateverificationerrorcode)
- [`CertificateTimeErrorCode`](#certificatetimeerrorcode)
- [`CertificateHasTooManyDelegationsErrorCode`](#certificatehastoomanydelegationserrorcode)
- [`CertificateNotAuthorizedErrorCode`](#certificatenotauthorizederrorcode)
- [`CertificateNotAuthorizedForSubnetErrorCode`](#certificatenotauthorizedforsubneterrorcode)
- [`LookupErrorCode`](#lookuperrorcode)
- [`MalformedLookupFoundValueErrorCode`](#malformedlookupfoundvalueerrorcode)
- [`MissingLookupValueErrorCode`](#missinglookupvalueerrorcode)
- [`DerKeyLengthMismatchErrorCode`](#derkeylengthmismatcherrorcode)
- [`DerPrefixMismatchErrorCode`](#derprefixmismatcherrorcode)
- [`DerDecodeLengthMismatchErrorCode`](#derdecodelengthmismatcherrorcode)
- [`DerDecodeErrorCode`](#derdecodeerrorcode)
- [`DerEncodeErrorCode`](#derencodeerrorcode)
- [`CborDecodeErrorCode`](#cbordecodeerrorcode)
- [`CborEncodeErrorCode`](#cborencodeerrorcode)
- [`HexDecodeErrorCode`](#hexdecodeerrorcode)
- [`TimeoutWaitingForResponseErrorCode`](#timeoutwaitingforresponseerrorcode)
- [`CertificateOutdatedErrorCode`](#certificateoutdatederrorcode)
- [`CertifiedRejectErrorCode`](#certifiedrejecterrorcode)
- [`UncertifiedRejectErrorCode`](#uncertifiedrejecterrorcode)
- [`UncertifiedRejectUpdateErrorCode`](#uncertifiedrejectupdateerrorcode)
- [`RequestStatusDoneNoReplyErrorCode`](#requeststatusdonenoreplyerrorcode)
- [`MissingRootKeyErrorCode`](#missingrootkeyerrorcode)
- [`HashValueErrorCode`](#hashvalueerrorcode)
- [`IdentityInvalidErrorCode`](#identityinvaliderrorcode)
- [`IngressExpiryInvalidErrorCode`](#ingressexpiryinvaliderrorcode)
- [`MissingFetchErrorCode`](#missingfetcherrorcode)
- [`CreateHttpAgentErrorCode`](#createhttpagenterrorcode)
- [`ExcessiveSignaturesErrorCode`](#excessivesignatureserrorcode)
- [`MalformedSignatureErrorCode`](#malformedsignatureerrorcode)
- [`MissingSignatureErrorCode`](#missingsignatureerrorcode)
- [`MalformedPublicKeyErrorCode`](#malformedpublickeyerrorcode)
- [`QuerySignatureVerificationFailedErrorCode`](#querysignatureverificationfailederrorcode)
- [`UnexpectedErrorCode`](#unexpectederrorcode)
- [`UnexpectedV4StatusErrorCode`](#unexpectedv4statuserrorcode)
- [`HashTreeDecodeErrorCode`](#hashtreedecodeerrorcode)
- [`HttpErrorCode`](#httperrorcode)
- [`HttpV4ApiNotSupportedErrorCode`](#httpv4apinotsupportederrorcode)
- [`HttpFetchErrorCode`](#httpfetcherrorcode)
- [`MissingCanisterIdErrorCode`](#missingcanisteriderrorcode)
- [`InvalidReadStateRequestErrorCode`](#invalidreadstaterequesterrorcode)
- [`ExpiryJsonDeserializeErrorCode`](#expiryjsondeserializeerrorcode)
- [`InvalidRootKeyErrorCode`](#invalidrootkeyerrorcode)
- [`MissingCookieErrorCode`](#missingcookieerrorcode)
- [`EmptyCookieErrorCode`](#emptycookieerrorcode)
- [`EffectiveSubnetIdAsyncErrorCode`](#effectivesubnetidasyncerrorcode)

#### Constructors

##### Constructor

> **new ErrorCode**(`isCertified?`): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Parameters

###### isCertified?

`boolean` = `false`

###### Returns

[`ErrorCode`](#abstract-errorcode)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

#### Methods

##### toErrorMessage()

> `abstract` **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:83](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L83)

###### Returns

`string`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

***

### ExcessiveSignaturesErrorCode

Defined in: [packages/core/src/agent/errors.ts:705](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L705)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new ExcessiveSignaturesErrorCode**(`signatureCount`, `maxExpected`): [`ExcessiveSignaturesErrorCode`](#excessivesignatureserrorcode)

Defined in: [packages/core/src/agent/errors.ts:708](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L708)

###### Parameters

###### signatureCount

`number`

###### maxExpected

`number`

###### Returns

[`ExcessiveSignaturesErrorCode`](#excessivesignatureserrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### maxExpected

> `readonly` **maxExpected**: `number`

Defined in: [packages/core/src/agent/errors.ts:710](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L710)

##### name

> **name**: `string` = `'ExcessiveSignaturesErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:706](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L706)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### signatureCount

> `readonly` **signatureCount**: `number`

Defined in: [packages/core/src/agent/errors.ts:709](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L709)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:716](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L716)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### Expiry

Defined in: [packages/core/src/agent/agent/http/expiry.ts:24](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L24)

#### Properties

##### \_isExpiry

> `readonly` **\_isExpiry**: `true` = `true`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:25](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L25)

#### Methods

##### toBigInt()

> **toBigInt**(): `bigint`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:56](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L56)

###### Returns

`bigint`

##### toHash()

> **toHash**(): `Uint8Array`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:60](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L60)

###### Returns

`Uint8Array`

##### toJSON()

> **toJSON**(): [`JsonnableExpiry`](#jsonnableexpiry)

Defined in: [packages/core/src/agent/agent/http/expiry.ts:72](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L72)

Serializes to JSON

###### Returns

[`JsonnableExpiry`](#jsonnableexpiry)

a JSON object with a single key, [JSON\_KEY\_EXPIRY](#json_key_expiry), whose value is the expiry as a string

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:64](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L64)

###### Returns

`string`

##### fromDeltaInMilliseconds()

> `static` **fromDeltaInMilliseconds**(`deltaInMs`, `clockDriftInMs?`): [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/expiry.ts:39](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L39)

Creates an Expiry object from a delta in milliseconds.
The expiry is calculated as: current_time + delta + clock_drift
The resulting expiry is then rounded:
- If rounding down to the nearest minute still provides at least 60 seconds in the future, use minute precision
- Otherwise, use second precision

###### Parameters

###### deltaInMs

`number`

The milliseconds to add to the current time.

###### clockDriftInMs?

`number` = `0`

The milliseconds to add to the current time, typically the clock drift between IC network clock and the client's clock. Defaults to `0` if not provided.

###### Returns

[`Expiry`](#expiry)

The constructed Expiry object.

##### fromJSON()

> `static` **fromJSON**(`input`): [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/expiry.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L81)

Deserializes a [JsonnableExpiry](#jsonnableexpiry) object from a JSON string.

###### Parameters

###### input

`string`

The JSON string to deserialize.

###### Returns

[`Expiry`](#expiry)

The deserialized Expiry object.

##### isExpiry()

> `static` **isExpiry**(`other`): `other is Expiry`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:96](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L96)

###### Parameters

###### other

`unknown`

###### Returns

`other is Expiry`

***

### ExpiryJsonDeserializeErrorCode

Defined in: [packages/core/src/agent/errors.ts:900](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L900)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new ExpiryJsonDeserializeErrorCode**(`error`): [`ExpiryJsonDeserializeErrorCode`](#expiryjsondeserializeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:903](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L903)

###### Parameters

###### error

`string`

###### Returns

[`ExpiryJsonDeserializeErrorCode`](#expiryjsondeserializeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:903](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L903)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'ExpiryJsonDeserializeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:901](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L901)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:908](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L908)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### ExternalError

Defined in: [packages/core/src/agent/errors.ts:209](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L209)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new ExternalError**(`code`): [`ExternalError`](#externalerror)

Defined in: [packages/core/src/agent/errors.ts:212](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L212)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`ExternalError`](#externalerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'ExternalError'`

Defined in: [packages/core/src/agent/errors.ts:210](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L210)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### HashTreeDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:810](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L810)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HashTreeDecodeErrorCode**(`error`): [`HashTreeDecodeErrorCode`](#hashtreedecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:813](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L813)

###### Parameters

###### error

`string`

###### Returns

[`HashTreeDecodeErrorCode`](#hashtreedecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:813](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L813)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'HashTreeDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:811](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L811)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:818](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L818)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### HashValueErrorCode

Defined in: [packages/core/src/agent/errors.ts:637](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L637)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HashValueErrorCode**(`value`): [`HashValueErrorCode`](#hashvalueerrorcode)

Defined in: [packages/core/src/agent/errors.ts:640](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L640)

###### Parameters

###### value

`unknown`

###### Returns

[`HashValueErrorCode`](#hashvalueerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'HashValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:638](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L638)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### value

> `readonly` **value**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:640](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L640)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:645](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L645)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### HexDecodeErrorCode

Defined in: [packages/core/src/agent/errors.ts:474](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L474)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HexDecodeErrorCode**(`error`): [`HexDecodeErrorCode`](#hexdecodeerrorcode)

Defined in: [packages/core/src/agent/errors.ts:477](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L477)

###### Parameters

###### error

`string`

###### Returns

[`HexDecodeErrorCode`](#hexdecodeerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:477](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L477)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'HexDecodeErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:475](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L475)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:482](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L482)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### HttpAgent

Defined in: [packages/core/src/agent/agent/http/index.ts:272](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L272)

A HTTP agent allows users to interact with a client of the internet computer
using the available methods. It exposes an API that closely follows the
public view of the internet computer, and is not intended to be exposed
directly to the majority of users due to its low-level interface.
There is a pipeline to apply transformations to the request before sending
it to the client. This is to decouple signature, nonce generation and
other computations so that this class can stay as simple as possible while
allowing extensions.

#### Implements

- [`Agent`](#agent-1)

#### Constructors

##### Constructor

> **new HttpAgent**(`options?`): [`HttpAgent`](#httpagent)

Defined in: [packages/core/src/agent/agent/http/index.ts:314](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L314)

###### Parameters

###### options?

[`HttpAgentOptions`](#httpagentoptions) = `{}`

Options for the HttpAgent

###### Returns

[`HttpAgent`](#httpagent)

###### Deprecated

Use `HttpAgent.create` or `HttpAgent.createSync` instead

#### Properties

##### \_isAgent

> `readonly` **\_isAgent**: `true` = `true`

Defined in: [packages/core/src/agent/agent/http/index.ts:297](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L297)

##### config

> **config**: [`HttpAgentOptions`](#httpagentoptions) = `{}`

Defined in: [packages/core/src/agent/agent/http/index.ts:298](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L298)

##### host

> `readonly` **host**: `URL`

Defined in: [packages/core/src/agent/agent/http/index.ts:286](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L286)

##### log

> **log**: [`ObservableLog`](#observablelog)

Defined in: [packages/core/src/agent/agent/http/index.ts:300](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L300)

##### rootKey

> **rootKey**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/core/src/agent/agent/http/index.ts:273](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L273)

###### Implementation of

[`Agent`](#agent-1).[`rootKey`](#rootkey-2)

#### Methods

##### \_transform()

> `protected` **\_transform**(`request`): `Promise`\<[`HttpAgentRequest`](#httpagentrequest)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1683](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1683)

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

###### Returns

`Promise`\<[`HttpAgentRequest`](#httpagentrequest)\>

##### addTransform()

> **addTransform**(`type`, `fn`, `priority?`): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:451](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L451)

###### Parameters

###### type

`"query"` \| `"update"`

###### fn

[`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

###### priority?

`number` = `...`

###### Returns

`void`

##### call()

> **call**(`canisterId`, `options`, `identity?`): `Promise`\<[`SubmitResponse`](#submitresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:489](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L489)

Makes a call to a canister method.

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The ID of the canister to call. Can be a Principal or a string.

###### options

[`CallOptions`](#calloptions)

Options for the call.

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

(Optional) The identity to use for the call. If not provided, the agent's current identity will be used.

###### Returns

`Promise`\<[`SubmitResponse`](#submitresponse)\>

A promise that resolves to the response of the call, including the request ID and response details.

###### Implementation of

[`Agent`](#agent-1).[`call`](#call-3)

##### createReadStateRequest()

> **createReadStateRequest**(`fields`, `identity?`): `Promise`\<`any`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1240](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1240)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

###### Parameters

###### fields

[`ReadStateOptions`](#readstateoptions)

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

###### Returns

`Promise`\<`any`\>

###### Implementation of

[`Agent`](#agent-1).[`createReadStateRequest`](#createreadstaterequest-1)

##### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1543](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1543)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

###### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

###### Implementation of

[`Agent`](#agent-1).[`fetchRootKey`](#fetchrootkey-1)

##### fetchSubnetKeys()

> **fetchSubnetKeys**(`effectiveTarget`): `Promise`\<`SubnetNodeKeys`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1593](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1593)

###### Parameters

###### effectiveTarget

[`InputTargetPrincipal`](#inputtargetprincipal)

###### Returns

`Promise`\<`SubnetNodeKeys`\>

##### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../principal/api.md#principal)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:475](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L475)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

###### Returns

`Promise`\<[`Principal`](../../principal/api.md#principal)\>

###### Implementation of

[`Agent`](#agent-1).[`getPrincipal`](#getprincipal-3)

##### getSubnetIdFromCanister()

> **getSubnetIdFromCanister**(`canisterId`): `Promise`\<[`Principal`](../../principal/api.md#principal)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1663](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1663)

Returns the subnet ID for a given canister ID, by looking at the certificate delegation
returned by the canister's state obtained by requesting the `/time` path with [readState](#readstate-2).

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The canister ID to get the subnet ID for.

###### Returns

`Promise`\<[`Principal`](../../principal/api.md#principal)\>

The subnet ID for the given canister ID.

##### getTimeDiffMsecs()

> **getTimeDiffMsecs**(): `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:1704](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1704)

Returns the time difference in milliseconds between the IC network clock and the client's clock,
after the clock has been synced.

If the time has not been synced, returns `0`.

###### Returns

`number`

##### hasSyncedTime()

> **hasSyncedTime**(): `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:1711](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1711)

Returns `true` if the time has been synced at least once with the IC network, `false` otherwise.

###### Returns

`boolean`

##### invalidateIdentity()

> **invalidateIdentity**(): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:1585](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1585)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

###### Returns

`void`

###### Implementation of

[`Agent`](#agent-1).[`invalidateIdentity`](#invalidateidentity-1)

##### isLocal()

> **isLocal**(): `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:446](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L446)

###### Returns

`boolean`

##### parseTimeFromResponse()

> **parseTimeFromResponse**(`response`): `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:1385](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1385)

###### Parameters

###### response

###### certificate

`Uint8Array`

###### Returns

`number`

##### query()

> **query**(`canisterId`, `fields`, `identity?`): `Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1046](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1046)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

###### fields

[`QueryFields`](#queryfields)

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

Sender principal to use when sending the query.

###### Returns

`Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

###### Implementation of

[`Agent`](#agent-1).[`query`](#query-3)

##### readState()

> **readState**(`effectiveTarget`, `fields`, `_identity?`, `request?`): `Promise`\<[`ReadStateResponse`](#readstateresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1286](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1286)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

###### Parameters

###### effectiveTarget

[`InputTargetPrincipal`](#inputtargetprincipal)

A Canister ID or Subnet ID related to this call.

###### fields

[`ReadStateOptions`](#readstateoptions)

###### \_identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

###### request?

`any`

The request to send in case it has already been created.

###### Returns

`Promise`\<[`ReadStateResponse`](#readstateresponse)\>

###### Implementation of

[`Agent`](#agent-1).[`readState`](#readstate-3)

##### ~~readSubnetState()~~

> **readSubnetState**(`subnetId`, `options`): `Promise`\<[`ReadStateResponse`](#readstateresponse)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1331](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1331)

###### Parameters

###### subnetId

`string` \| [`Principal`](../../principal/api.md#principal)

###### options

[`ReadStateOptions`](#readstateoptions)

###### Returns

`Promise`\<[`ReadStateResponse`](#readstateresponse)\>

###### Deprecated

Use `readState`

##### replaceIdentity()

> **replaceIdentity**(`identity`): `void`

Defined in: [packages/core/src/agent/agent/http/index.ts:1589](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1589)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@icp-sdk/auth/client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

###### Parameters

###### identity

[`Identity`](#identity-1)

###### Returns

`void`

###### Implementation of

[`Agent`](#agent-1).[`replaceIdentity`](#replaceidentity-1)

##### status()

> **status**(): `Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1524](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1524)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

###### Returns

`Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.

###### Implementation of

[`Agent`](#agent-1).[`status`](#status-4)

##### syncTime()

> **syncTime**(`targetOverride?`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1425](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1425)

Allows agent to sync its time with the network. Can be called during initialization or mid-lifecycle if the device's clock has drifted away from the network time. This is necessary to set the Expiry for a request

###### Parameters

###### targetOverride?

[`TargetPrincipal`](#targetprincipal)

Pass a canister or subnet ID if you need to sync the time with a particular subnet. Uses the ICP ledger canister by default.

###### Returns

`Promise`\<`void`\>

##### ~~syncTimeWithSubnet()~~

> **syncTimeWithSubnet**(`subnetId`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:1505](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1505)

###### Parameters

###### subnetId

[`Principal`](../../principal/api.md#principal)

###### Returns

`Promise`\<`void`\>

###### Deprecated

Use [syncTime](#synctime)

##### update()

> **update**(`canisterId`, `fields`, `pollingOptions?`): `Promise`\<[`UpdateResult`](#updateresult)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:674](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L674)

Executes an update call to a canister and returns the certified result.

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The canister to call.

###### fields

[`UpdateOptions`](#updateoptions)

The call options (method name, arg, effective canister ID, optional nonce).

###### pollingOptions?

[`PollingOptions`](#pollingoptions-2) = `{}`

Optional polling configuration.

###### Returns

`Promise`\<[`UpdateResult`](#updateresult)\>

The certified result including the certificate, reply bytes, and raw certificate bytes.

###### Implementation of

[`Agent`](#agent-1).[`update`](#update-1)

##### create()

> `static` **create**(`options?`): `Promise`\<[`HttpAgent`](#httpagent)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:421](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L421)

###### Parameters

###### options?

[`HttpAgentOptions`](#httpagentoptions) = `{}`

###### Returns

`Promise`\<[`HttpAgent`](#httpagent)\>

##### createSync()

> `static` **createSync**(`options?`): [`HttpAgent`](#httpagent)

Defined in: [packages/core/src/agent/agent/http/index.ts:417](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L417)

###### Parameters

###### options?

[`HttpAgentOptions`](#httpagentoptions) = `{}`

###### Returns

[`HttpAgent`](#httpagent)

##### from()

> `static` **from**(`agent`): `Promise`\<[`HttpAgent`](#httpagent)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:427](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L427)

###### Parameters

###### agent

`V1HttpAgentInterface` \| `Pick`\<[`HttpAgent`](#httpagent), `"config"`\>

###### Returns

`Promise`\<[`HttpAgent`](#httpagent)\>

***

### HttpErrorCode

Defined in: [packages/core/src/agent/errors.ts:823](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L823)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HttpErrorCode**(`status`, `statusText`, `headers`, `bodyText?`): [`HttpErrorCode`](#httperrorcode)

Defined in: [packages/core/src/agent/errors.ts:826](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L826)

###### Parameters

###### status

`number`

###### statusText

`string`

###### headers

[`HttpHeaderField`](#httpheaderfield)[]

###### bodyText?

`string`

###### Returns

[`HttpErrorCode`](#httperrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### bodyText?

> `readonly` `optional` **bodyText?**: `string`

Defined in: [packages/core/src/agent/errors.ts:830](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L830)

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### headers

> `readonly` **headers**: [`HttpHeaderField`](#httpheaderfield)[]

Defined in: [packages/core/src/agent/errors.ts:829](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L829)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'HttpErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:824](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L824)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### status

> `readonly` **status**: `number`

Defined in: [packages/core/src/agent/errors.ts:827](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L827)

##### statusText

> `readonly` **statusText**: `string`

Defined in: [packages/core/src/agent/errors.ts:828](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L828)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:836](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L836)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### HttpFetchErrorCode

Defined in: [packages/core/src/agent/errors.ts:861](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L861)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HttpFetchErrorCode**(`error`): [`HttpFetchErrorCode`](#httpfetcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:864](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L864)

###### Parameters

###### error

`unknown`

###### Returns

[`HttpFetchErrorCode`](#httpfetcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:864](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L864)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'HttpFetchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:862](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L862)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:869](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L869)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### HttpV4ApiNotSupportedErrorCode

Defined in: [packages/core/src/agent/errors.ts:848](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L848)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new HttpV4ApiNotSupportedErrorCode**(): [`HttpV4ApiNotSupportedErrorCode`](#httpv4apinotsupportederrorcode)

Defined in: [packages/core/src/agent/errors.ts:851](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L851)

###### Returns

[`HttpV4ApiNotSupportedErrorCode`](#httpv4apinotsupportederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'HttpV4ApiNotSupportedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:849](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L849)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:856](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L856)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### IdentityInvalidErrorCode

Defined in: [packages/core/src/agent/errors.ts:650](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L650)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new IdentityInvalidErrorCode**(): [`IdentityInvalidErrorCode`](#identityinvaliderrorcode)

Defined in: [packages/core/src/agent/errors.ts:653](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L653)

###### Returns

[`IdentityInvalidErrorCode`](#identityinvaliderrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'IdentityInvalidErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:651](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L651)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:658](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L658)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### IngressExpiryInvalidErrorCode

Defined in: [packages/core/src/agent/errors.ts:663](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L663)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new IngressExpiryInvalidErrorCode**(`message`, `providedIngressExpiryInMinutes`): [`IngressExpiryInvalidErrorCode`](#ingressexpiryinvaliderrorcode)

Defined in: [packages/core/src/agent/errors.ts:666](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L666)

###### Parameters

###### message

`string`

###### providedIngressExpiryInMinutes

`number`

###### Returns

[`IngressExpiryInvalidErrorCode`](#ingressexpiryinvaliderrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:667](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L667)

##### name

> **name**: `string` = `'IngressExpiryInvalidErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:664](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L664)

##### providedIngressExpiryInMinutes

> `readonly` **providedIngressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/errors.ts:668](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L668)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:674](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L674)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### InputError

Defined in: [packages/core/src/agent/errors.ts:227](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L227)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new InputError**(`code`): [`InputError`](#inputerror)

Defined in: [packages/core/src/agent/errors.ts:230](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L230)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`InputError`](#inputerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'InputError'`

Defined in: [packages/core/src/agent/errors.ts:228](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L228)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### InvalidReadStateRequestErrorCode

Defined in: [packages/core/src/agent/errors.ts:887](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L887)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new InvalidReadStateRequestErrorCode**(`request`): [`InvalidReadStateRequestErrorCode`](#invalidreadstaterequesterrorcode)

Defined in: [packages/core/src/agent/errors.ts:890](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L890)

###### Parameters

###### request

`unknown`

###### Returns

[`InvalidReadStateRequestErrorCode`](#invalidreadstaterequesterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'InvalidReadStateRequestErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:888](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L888)

##### request

> `readonly` **request**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:890](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L890)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:895](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L895)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### InvalidRootKeyErrorCode

Defined in: [packages/core/src/agent/errors.ts:913](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L913)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new InvalidRootKeyErrorCode**(`rootKey`, `expectedLength`): [`InvalidRootKeyErrorCode`](#invalidrootkeyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:916](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L916)

###### Parameters

###### rootKey

`Uint8Array`

###### expectedLength

`number`

###### Returns

[`InvalidRootKeyErrorCode`](#invalidrootkeyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### expectedLength

> `readonly` **expectedLength**: `number`

Defined in: [packages/core/src/agent/errors.ts:918](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L918)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'InvalidRootKeyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:914](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L914)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### rootKey

> `readonly` **rootKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:917](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L917)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:924](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L924)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### LimitError

Defined in: [packages/core/src/agent/errors.ts:218](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L218)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new LimitError**(`code`): [`LimitError`](#limiterror)

Defined in: [packages/core/src/agent/errors.ts:221](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L221)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`LimitError`](#limiterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'LimitError'`

Defined in: [packages/core/src/agent/errors.ts:219](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L219)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### LookupErrorCode

Defined in: [packages/core/src/agent/errors.ts:326](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L326)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new LookupErrorCode**(`message`, `lookupStatus`): [`LookupErrorCode`](#lookuperrorcode)

Defined in: [packages/core/src/agent/errors.ts:329](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L329)

###### Parameters

###### message

`string`

###### lookupStatus

[`LookupSubtreeStatus`](#lookupsubtreestatus) \| [`LookupPathStatus`](#lookuppathstatus)

###### Returns

[`LookupErrorCode`](#lookuperrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### lookupStatus

> `readonly` **lookupStatus**: [`LookupSubtreeStatus`](#lookupsubtreestatus) \| [`LookupPathStatus`](#lookuppathstatus)

Defined in: [packages/core/src/agent/errors.ts:331](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L331)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:330](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L330)

##### name

> **name**: `string` = `'LookupErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:327](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L327)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:337](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L337)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MalformedLookupFoundValueErrorCode

Defined in: [packages/core/src/agent/errors.ts:342](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L342)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MalformedLookupFoundValueErrorCode**(`message`): [`MalformedLookupFoundValueErrorCode`](#malformedlookupfoundvalueerrorcode)

Defined in: [packages/core/src/agent/errors.ts:345](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L345)

###### Parameters

###### message

`string`

###### Returns

[`MalformedLookupFoundValueErrorCode`](#malformedlookupfoundvalueerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:345](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L345)

##### name

> **name**: `string` = `'MalformedLookupFoundValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:343](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L343)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:350](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L350)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MalformedPublicKeyErrorCode

Defined in: [packages/core/src/agent/errors.ts:747](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L747)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MalformedPublicKeyErrorCode**(): [`MalformedPublicKeyErrorCode`](#malformedpublickeyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:750](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L750)

###### Returns

[`MalformedPublicKeyErrorCode`](#malformedpublickeyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'MalformedPublicKeyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:748](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L748)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:755](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L755)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MalformedSignatureErrorCode

Defined in: [packages/core/src/agent/errors.ts:721](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L721)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MalformedSignatureErrorCode**(`error`): [`MalformedSignatureErrorCode`](#malformedsignatureerrorcode)

Defined in: [packages/core/src/agent/errors.ts:724](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L724)

###### Parameters

###### error

`string`

###### Returns

[`MalformedSignatureErrorCode`](#malformedsignatureerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `string`

Defined in: [packages/core/src/agent/errors.ts:724](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L724)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'MalformedSignatureErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:722](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L722)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:729](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L729)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MissingCanisterIdErrorCode

Defined in: [packages/core/src/agent/errors.ts:874](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L874)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingCanisterIdErrorCode**(`receivedCanisterId`): [`MissingCanisterIdErrorCode`](#missingcanisteriderrorcode)

Defined in: [packages/core/src/agent/errors.ts:877](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L877)

###### Parameters

###### receivedCanisterId

`unknown`

###### Returns

[`MissingCanisterIdErrorCode`](#missingcanisteriderrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'MissingCanisterIdErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:875](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L875)

##### receivedCanisterId

> `readonly` **receivedCanisterId**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:877](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L877)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:882](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L882)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MissingCookieErrorCode

Defined in: [packages/core/src/agent/errors.ts:929](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L929)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingCookieErrorCode**(`expectedCookieName`): [`MissingCookieErrorCode`](#missingcookieerrorcode)

Defined in: [packages/core/src/agent/errors.ts:932](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L932)

###### Parameters

###### expectedCookieName

`string`

###### Returns

[`MissingCookieErrorCode`](#missingcookieerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### expectedCookieName

> `readonly` **expectedCookieName**: `string`

Defined in: [packages/core/src/agent/errors.ts:932](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L932)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'MissingCookieErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:930](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L930)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:937](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L937)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MissingFetchErrorCode

Defined in: [packages/core/src/agent/errors.ts:679](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L679)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingFetchErrorCode**(): [`MissingFetchErrorCode`](#missingfetcherrorcode)

Defined in: [packages/core/src/agent/errors.ts:682](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L682)

###### Returns

[`MissingFetchErrorCode`](#missingfetcherrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'MissingFetchErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:680](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L680)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:687](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L687)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MissingLookupValueErrorCode

Defined in: [packages/core/src/agent/errors.ts:355](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L355)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingLookupValueErrorCode**(`message`): [`MissingLookupValueErrorCode`](#missinglookupvalueerrorcode)

Defined in: [packages/core/src/agent/errors.ts:358](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L358)

###### Parameters

###### message

`string`

###### Returns

[`MissingLookupValueErrorCode`](#missinglookupvalueerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:358](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L358)

##### name

> **name**: `string` = `'MissingLookupValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:356](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L356)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:363](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L363)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MissingRootKeyErrorCode

Defined in: [packages/core/src/agent/errors.ts:621](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L621)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingRootKeyErrorCode**(`shouldFetchRootKey?`): [`MissingRootKeyErrorCode`](#missingrootkeyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:624](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L624)

###### Parameters

###### shouldFetchRootKey?

`boolean`

###### Returns

[`MissingRootKeyErrorCode`](#missingrootkeyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'MissingRootKeyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:622](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L622)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### shouldFetchRootKey?

> `readonly` `optional` **shouldFetchRootKey?**: `boolean`

Defined in: [packages/core/src/agent/errors.ts:624](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L624)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:629](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L629)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### MissingSignatureErrorCode

Defined in: [packages/core/src/agent/errors.ts:734](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L734)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new MissingSignatureErrorCode**(): [`MissingSignatureErrorCode`](#missingsignatureerrorcode)

Defined in: [packages/core/src/agent/errors.ts:737](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L737)

###### Returns

[`MissingSignatureErrorCode`](#missingsignatureerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'MissingSignatureErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:735](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L735)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:742](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L742)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### Observable

Defined in: [packages/core/src/agent/observable.ts:5](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L5)

#### Extended by

- [`ObservableLog`](#observablelog)

#### Type Parameters

##### T

`T`

#### Constructors

##### Constructor

> **new Observable**\<`T`\>(): [`Observable`](#observable)\<`T`\>

Defined in: [packages/core/src/agent/observable.ts:8](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L8)

###### Returns

[`Observable`](#observable)\<`T`\>

#### Properties

##### observers

> **observers**: [`ObserveFunction`](#observefunction)\<`T`\>[]

Defined in: [packages/core/src/agent/observable.ts:6](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L6)

#### Methods

##### notify()

> **notify**(`data`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:20](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L20)

###### Parameters

###### data

`T`

###### rest

...`unknown`[]

###### Returns

`void`

##### subscribe()

> **subscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:12](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L12)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<`T`\>

###### Returns

`void`

##### unsubscribe()

> **unsubscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:16](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L16)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<`T`\>

###### Returns

`void`

***

### ObservableLog

Defined in: [packages/core/src/agent/observable.ts:36](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L36)

#### Extends

- [`Observable`](#observable)\<[`AgentLog`](#agentlog)\>

#### Constructors

##### Constructor

> **new ObservableLog**(): [`ObservableLog`](#observablelog)

Defined in: [packages/core/src/agent/observable.ts:37](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L37)

###### Returns

[`ObservableLog`](#observablelog)

###### Overrides

[`Observable`](#observable).[`constructor`](#constructor-47)

#### Properties

##### observers

> **observers**: [`ObserveFunction`](#observefunction)\<[`AgentLog`](#agentlog)\>[]

Defined in: [packages/core/src/agent/observable.ts:6](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L6)

###### Inherited from

[`Observable`](#observable).[`observers`](#observers)

#### Methods

##### error()

> **error**(`message`, `error`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:46](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L46)

###### Parameters

###### message

`string`

###### error

[`AgentError`](#agenterror)

###### rest

...`unknown`[]

###### Returns

`void`

##### notify()

> **notify**(`data`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:20](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L20)

###### Parameters

###### data

[`AgentLog`](#agentlog)

###### rest

...`unknown`[]

###### Returns

`void`

###### Inherited from

[`Observable`](#observable).[`notify`](#notify)

##### print()

> **print**(`message`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:40](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L40)

###### Parameters

###### message

`string`

###### rest

...`unknown`[]

###### Returns

`void`

##### subscribe()

> **subscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:12](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L12)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<[`AgentLog`](#agentlog)\>

###### Returns

`void`

###### Inherited from

[`Observable`](#observable).[`subscribe`](#subscribe)

##### unsubscribe()

> **unsubscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:16](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L16)

###### Parameters

###### func

[`ObserveFunction`](#observefunction)\<[`AgentLog`](#agentlog)\>

###### Returns

`void`

###### Inherited from

[`Observable`](#observable).[`unsubscribe`](#unsubscribe)

##### warn()

> **warn**(`message`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:43](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L43)

###### Parameters

###### message

`string`

###### rest

...`unknown`[]

###### Returns

`void`

***

### ProtocolError

Defined in: [packages/core/src/agent/errors.ts:182](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L182)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new ProtocolError**(`code`): [`ProtocolError`](#protocolerror)

Defined in: [packages/core/src/agent/errors.ts:185](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L185)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`ProtocolError`](#protocolerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'ProtocolError'`

Defined in: [packages/core/src/agent/errors.ts:183](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L183)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### QuerySignatureVerificationFailedErrorCode

Defined in: [packages/core/src/agent/errors.ts:760](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L760)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new QuerySignatureVerificationFailedErrorCode**(`nodeId`): [`QuerySignatureVerificationFailedErrorCode`](#querysignatureverificationfailederrorcode)

Defined in: [packages/core/src/agent/errors.ts:763](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L763)

###### Parameters

###### nodeId

`string`

###### Returns

[`QuerySignatureVerificationFailedErrorCode`](#querysignatureverificationfailederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'QuerySignatureVerificationFailedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:761](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L761)

##### nodeId

> `readonly` **nodeId**: `string`

Defined in: [packages/core/src/agent/errors.ts:763](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L763)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:768](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L768)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### RejectError

Defined in: [packages/core/src/agent/errors.ts:191](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L191)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new RejectError**(`code`): [`RejectError`](#rejecterror)

Defined in: [packages/core/src/agent/errors.ts:194](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L194)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`RejectError`](#rejecterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'RejectError'`

Defined in: [packages/core/src/agent/errors.ts:192](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L192)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### RequestStatusDoneNoReplyErrorCode

Defined in: [packages/core/src/agent/errors.ts:605](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L605)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new RequestStatusDoneNoReplyErrorCode**(`requestId`): [`RequestStatusDoneNoReplyErrorCode`](#requeststatusdonenoreplyerrorcode)

Defined in: [packages/core/src/agent/errors.ts:608](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L608)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### Returns

[`RequestStatusDoneNoReplyErrorCode`](#requeststatusdonenoreplyerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'RequestStatusDoneNoReplyErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:606](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L606)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:608](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L608)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:613](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L613)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### `abstract` SignIdentity

Defined in: [packages/core/src/agent/auth.ts:58](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L58)

An Identity that can sign blobs.

#### Extended by

- [`Ed25519KeyIdentity`](../../identity/api.md#ed25519keyidentity)
- [`ECDSAKeyIdentity`](../../identity/api.md#ecdsakeyidentity)
- [`DelegationIdentity`](../../identity/api.md#delegationidentity)
- [`Secp256k1KeyIdentity`](../../identity/secp256k1/api.md#secp256k1keyidentity)
- [`WebAuthnIdentity`](../../identity/api.md#webauthnidentity)

#### Implements

- [`Identity`](#identity-1)

#### Constructors

##### Constructor

> **new SignIdentity**(): [`SignIdentity`](#abstract-signidentity)

###### Returns

[`SignIdentity`](#abstract-signidentity)

#### Properties

##### \_principal

> `protected` **\_principal**: [`Principal`](../../principal/api.md#principal) \| `undefined`

Defined in: [packages/core/src/agent/auth.ts:59](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L59)

#### Methods

##### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/auth.ts:75](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L75)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

###### Returns

[`Principal`](../../principal/api.md#principal)

###### Implementation of

[`Identity`](#identity-1).[`getPrincipal`](#getprincipal-4)

##### getPublicKey()

> `abstract` **getPublicKey**(): [`PublicKey`](#publickey-1)

Defined in: [packages/core/src/agent/auth.ts:64](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L64)

Returns the public key that would match this identity's signature.

###### Returns

[`PublicKey`](#publickey-1)

##### sign()

> `abstract` **sign**(`blob`): `Promise`\<[`Signature`](#signature-2)\>

Defined in: [packages/core/src/agent/auth.ts:69](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L69)

Signs a blob of data, with this identity's private key.

###### Parameters

###### blob

`Uint8Array`

###### Returns

`Promise`\<[`Signature`](#signature-2)\>

##### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:88](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L88)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

internet computer request to transform

###### Returns

`Promise`\<`unknown`\>

###### Implementation of

[`Identity`](#identity-1).[`transformRequest`](#transformrequest-2)

***

### TimeoutWaitingForResponseErrorCode

Defined in: [packages/core/src/agent/errors.ts:487](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L487)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new TimeoutWaitingForResponseErrorCode**(`message`, `requestId?`, `status?`): [`TimeoutWaitingForResponseErrorCode`](#timeoutwaitingforresponseerrorcode)

Defined in: [packages/core/src/agent/errors.ts:490](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L490)

###### Parameters

###### message

`string`

###### requestId?

[`RequestId`](#requestid-9)

###### status?

[`RequestStatusResponseStatus`](#requeststatusresponsestatus)

###### Returns

[`TimeoutWaitingForResponseErrorCode`](#timeoutwaitingforresponseerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:491](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L491)

##### name

> **name**: `string` = `'TimeoutWaitingForResponseErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:488](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L488)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### requestId?

> `readonly` `optional` **requestId?**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:492](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L492)

##### status?

> `readonly` `optional` **status?**: [`RequestStatusResponseStatus`](#requeststatusresponsestatus)

Defined in: [packages/core/src/agent/errors.ts:493](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L493)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:499](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L499)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### `abstract` ToCborValue

Defined in: [packages/core/src/agent/cbor.ts:10](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/cbor.ts#L10)

Used to extend classes that need to provide a custom value for the CBOR encoding process.

#### Constructors

##### Constructor

> **new ToCborValue**(): [`ToCborValue`](#abstract-tocborvalue)

###### Returns

[`ToCborValue`](#abstract-tocborvalue)

#### Methods

##### toCborValue()

> `abstract` **toCborValue**(): `any`

Defined in: [packages/core/src/agent/cbor.ts:14](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/cbor.ts#L14)

Returns a value that can be encoded with CBOR. Typically called in the replacer function of the [encode](#encode) function.

###### Returns

`any`

***

### TransportError

Defined in: [packages/core/src/agent/errors.ts:200](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L200)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new TransportError**(`code`): [`TransportError`](#transporterror)

Defined in: [packages/core/src/agent/errors.ts:203](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L203)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`TransportError`](#transporterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'TransportError'`

Defined in: [packages/core/src/agent/errors.ts:201](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L201)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### TrustError

Defined in: [packages/core/src/agent/errors.ts:173](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L173)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new TrustError**(`code`): [`TrustError`](#trusterror)

Defined in: [packages/core/src/agent/errors.ts:176](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L176)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`TrustError`](#trusterror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'TrustError'`

Defined in: [packages/core/src/agent/errors.ts:174](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L174)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

***

### UncertifiedRejectErrorCode

Defined in: [packages/core/src/agent/errors.ts:556](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L556)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UncertifiedRejectErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`, `signatures`): [`UncertifiedRejectErrorCode`](#uncertifiedrejecterrorcode)

Defined in: [packages/core/src/agent/errors.ts:559](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L559)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### rejectCode

[`ReplicaRejectCode`](#replicarejectcode)

###### rejectMessage

`string`

###### rejectErrorCode

`string` \| `undefined`

###### signatures

[`NodeSignature`](#nodesignature)[] \| `undefined`

###### Returns

[`UncertifiedRejectErrorCode`](#uncertifiedrejecterrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'UncertifiedRejectErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:557](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L557)

##### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/errors.ts:561](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L561)

##### rejectErrorCode

> `readonly` **rejectErrorCode**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:563](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L563)

##### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:562](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L562)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:560](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L560)

##### signatures

> `readonly` **signatures**: [`NodeSignature`](#nodesignature)[] \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:564](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L564)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:570](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L570)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### UncertifiedRejectUpdateErrorCode

Defined in: [packages/core/src/agent/errors.ts:581](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L581)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UncertifiedRejectUpdateErrorCode**(`requestId`, `rejectCode`, `rejectMessage`, `rejectErrorCode`): [`UncertifiedRejectUpdateErrorCode`](#uncertifiedrejectupdateerrorcode)

Defined in: [packages/core/src/agent/errors.ts:584](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L584)

###### Parameters

###### requestId

[`RequestId`](#requestid-9)

###### rejectCode

[`ReplicaRejectCode`](#replicarejectcode)

###### rejectMessage

`string`

###### rejectErrorCode

`string` \| `undefined`

###### Returns

[`UncertifiedRejectUpdateErrorCode`](#uncertifiedrejectupdateerrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'UncertifiedRejectUpdateErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:582](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L582)

##### rejectCode

> `readonly` **rejectCode**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/errors.ts:586](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L586)

##### rejectErrorCode

> `readonly` **rejectErrorCode**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:588](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L588)

##### rejectMessage

> `readonly` **rejectMessage**: `string`

Defined in: [packages/core/src/agent/errors.ts:587](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L587)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:585](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L585)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:594](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L594)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### UnexpectedErrorCode

Defined in: [packages/core/src/agent/errors.ts:773](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L773)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UnexpectedErrorCode**(`error`): [`UnexpectedErrorCode`](#unexpectederrorcode)

Defined in: [packages/core/src/agent/errors.ts:776](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L776)

###### Parameters

###### error

`unknown`

###### Returns

[`UnexpectedErrorCode`](#unexpectederrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### error

> `readonly` **error**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:776](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L776)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'UnexpectedErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:774](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L774)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:781](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L781)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### UnexpectedV4StatusErrorCode

Defined in: [packages/core/src/agent/errors.ts:786](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L786)

#### Extends

- [`ErrorCode`](#abstract-errorcode)

#### Constructors

##### Constructor

> **new UnexpectedV4StatusErrorCode**(`status`, `requestId`, `response`, `rawCertificate`): [`UnexpectedV4StatusErrorCode`](#unexpectedv4statuserrorcode)

Defined in: [packages/core/src/agent/errors.ts:789](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L789)

###### Parameters

###### status

`string` \| `undefined`

###### requestId

[`RequestId`](#requestid-9)

###### response

###### body

[`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

[`HttpHeaderField`](#httpheaderfield)[]

###### ok

`boolean`

###### status

`number`

###### statusText

`string`

###### rawCertificate

`Uint8Array`

###### Returns

[`UnexpectedV4StatusErrorCode`](#unexpectedv4statuserrorcode)

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`constructor`](#constructor-20)

#### Properties

##### callContext?

> `optional` **callContext?**: [`CallContext`](#callcontext-47) \| [`PollingCallContext`](#pollingcallcontext)

Defined in: [packages/core/src/agent/errors.ts:79](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L79)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`callContext`](#callcontext-17)

##### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:81](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L81)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`isCertified`](#iscertified-18)

##### name

> **name**: `string` = `'UnexpectedV4StatusErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:787](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L787)

##### rawCertificate

> `readonly` **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:793](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L793)

##### requestContext?

> `optional` **requestContext?**: [`RequestContext`](#requestcontext-47)

Defined in: [packages/core/src/agent/errors.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L78)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`requestContext`](#requestcontext-17)

##### requestId

> `readonly` **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:791](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L791)

##### response

> `readonly` **response**: `object`

Defined in: [packages/core/src/agent/errors.ts:792](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L792)

###### body

> **body**: [`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

###### ok

> **ok**: `boolean`

###### status

> **status**: `number`

###### statusText

> **statusText**: `string`

##### status

> `readonly` **status**: `string` \| `undefined`

Defined in: [packages/core/src/agent/errors.ts:790](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L790)

##### verbosity

> `static` **verbosity**: [`ErrorVerbosity`](#errorverbosity) = `ErrorVerbosity.Normal`

Defined in: [packages/core/src/agent/errors.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L76)

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`verbosity`](#verbosity-17)

#### Methods

##### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:799](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L799)

###### Returns

`string`

###### Overrides

[`ErrorCode`](#abstract-errorcode).[`toErrorMessage`](#toerrormessage-17)

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L85)

###### Returns

`string`

###### Inherited from

[`ErrorCode`](#abstract-errorcode).[`toString`](#tostring-18)

***

### UnknownError

Defined in: [packages/core/src/agent/errors.ts:236](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L236)

#### Extends

- `ErrorKind`

#### Constructors

##### Constructor

> **new UnknownError**(`code`): [`UnknownError`](#unknownerror)

Defined in: [packages/core/src/agent/errors.ts:239](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L239)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

[`UnknownError`](#unknownerror)

###### Overrides

`ErrorKind.constructor`

#### Properties

##### cause

> `readonly` **cause**: `object`

Defined in: [packages/core/src/agent/errors.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L125)

###### code

> **code**: [`ErrorCode`](#abstract-errorcode)

###### kind

> **kind**: [`ErrorKindEnum`](#errorkindenum)

###### Inherited from

`ErrorKind.cause`

##### message

> **message**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1077

###### Inherited from

`ErrorKind.message`

##### name

> **name**: `string` = `'UnknownError'`

Defined in: [packages/core/src/agent/errors.ts:237](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L237)

###### Overrides

`ErrorKind.name`

##### stack?

> `optional` **stack?**: `string`

Defined in: node\_modules/.pnpm/typescript@5.9.3/node\_modules/typescript/lib/lib.es5.d.ts:1078

###### Inherited from

`ErrorKind.stack`

##### stackTraceLimit

> `static` **stackTraceLimit**: `number`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:67

The `Error.stackTraceLimit` property specifies the number of stack frames
collected by a stack trace (whether generated by `new Error().stack` or
`Error.captureStackTrace(obj)`).

The default value is `10` but may be set to any valid JavaScript number. Changes
will affect any stack trace captured _after_ the value has been changed.

If set to a non-number value, or set to a negative number, stack traces will
not capture any frames.

###### Inherited from

`ErrorKind.stackTraceLimit`

#### Accessors

##### code

###### Get Signature

> **get** **code**(): [`ErrorCode`](#abstract-errorcode)

Defined in: [packages/core/src/agent/errors.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L127)

###### Returns

[`ErrorCode`](#abstract-errorcode)

###### Set Signature

> **set** **code**(`code`): `void`

Defined in: [packages/core/src/agent/errors.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L130)

###### Parameters

###### code

[`ErrorCode`](#abstract-errorcode)

###### Returns

`void`

###### Inherited from

`ErrorKind.code`

##### isCertified

###### Get Signature

> **get** **isCertified**(): `boolean`

Defined in: [packages/core/src/agent/errors.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L145)

Reads the `isCertified` property of the underlying error code.

###### Returns

`boolean`

`true` if the error is certified, `false` otherwise.

###### Inherited from

`ErrorKind.isCertified`

##### kind

###### Get Signature

> **get** **kind**(): [`ErrorKindEnum`](#errorkindenum)

Defined in: [packages/core/src/agent/errors.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L134)

###### Returns

[`ErrorKindEnum`](#errorkindenum)

###### Set Signature

> **set** **kind**(`kind`): `void`

Defined in: [packages/core/src/agent/errors.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L137)

###### Parameters

###### kind

[`ErrorKindEnum`](#errorkindenum)

###### Returns

`void`

###### Inherited from

`ErrorKind.kind`

#### Methods

##### hasCode()

> **hasCode**\<`C`\>(`code`): `boolean`

Defined in: [packages/core/src/agent/errors.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L155)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### Parameters

###### code

(...`args`) => `C`

###### Returns

`boolean`

###### Inherited from

`ErrorKind.hasCode`

##### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L159)

Returns a string representation of an object.

###### Returns

`string`

###### Inherited from

`ErrorKind.toString`

##### captureStackTrace()

> `static` **captureStackTrace**(`targetObject`, `constructorOpt?`): `void`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:51

Creates a `.stack` property on `targetObject`, which when accessed returns
a string representing the location in the code at which
`Error.captureStackTrace()` was called.

```js
const myObject = {};
Error.captureStackTrace(myObject);
myObject.stack;  // Similar to `new Error().stack`
```

The first line of the trace will be prefixed with
`${myObject.name}: ${myObject.message}`.

The optional `constructorOpt` argument accepts a function. If given, all frames
above `constructorOpt`, including `constructorOpt`, will be omitted from the
generated stack trace.

The `constructorOpt` argument is useful for hiding implementation
details of error generation from the user. For instance:

```js
function a() {
  b();
}

function b() {
  c();
}

function c() {
  // Create an error without stack trace to avoid calculating the stack trace twice.
  const { stackTraceLimit } = Error;
  Error.stackTraceLimit = 0;
  const error = new Error();
  Error.stackTraceLimit = stackTraceLimit;

  // Capture the stack trace above function b
  Error.captureStackTrace(error, b); // Neither function c, nor b is included in the stack trace
  throw error;
}

a();
```

###### Parameters

###### targetObject

`object`

###### constructorOpt?

`Function`

###### Returns

`void`

###### Inherited from

`ErrorKind.captureStackTrace`

##### fromCode()

> `static` **fromCode**\<`C`, `E`\>(`this`, `code`): `E`

Defined in: [packages/core/src/agent/errors.ts:165](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L165)

###### Type Parameters

###### C

`C` *extends* [`ErrorCode`](#abstract-errorcode)

###### E

`E` *extends* `ErrorKind`

###### Parameters

###### this

(`code`) => `E`

###### code

`C`

###### Returns

`E`

###### Inherited from

`ErrorKind.fromCode`

##### prepareStackTrace()

> `static` **prepareStackTrace**(`err`, `stackTraces`): `any`

Defined in: node\_modules/.pnpm/@types+node@25.5.0/node\_modules/@types/node/globals.d.ts:55

###### Parameters

###### err

`Error`

###### stackTraces

`CallSite`[]

###### Returns

`any`

###### See

https://v8.dev/docs/stack-trace-api#customizing-stack-traces

###### Inherited from

`ErrorKind.prepareStackTrace`

## Interfaces

### ActorConfig

Defined in: [packages/core/src/agent/actor.ts:66](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L66)

Configuration that can be passed to customize the Actor behavior.

#### Extends

- `Pick`\<[`CallConfig`](#callconfig), `"agent"` \| `"effectiveTarget"` \| `"effectiveCanisterId"`\>

#### Properties

##### agent?

> `optional` **agent?**: [`Agent`](#agent-1)

Defined in: [packages/core/src/agent/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

###### Inherited from

[`CallConfig`](#callconfig).[`agent`](#agent-2)

##### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/actor.ts:96](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L96)

Polyfill for BLS Certificate verification in case wasm is not supported

##### canisterId

> **canisterId**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:73](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L73)

The Canister ID of this Actor. This is required for an Actor.

##### ~~effectiveCanisterId?~~

> `optional` **effectiveCanisterId?**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:55](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L55)

###### Deprecated

Use [CallConfig.effectiveTarget](#effectivetarget-1) instead.

###### Inherited from

[`CallConfig`](#callconfig).[`effectiveCanisterId`](#effectivecanisterid-1)

##### effectiveTarget?

> `optional` **effectiveTarget?**: [`TargetPrincipal`](#targetprincipal)

Defined in: [packages/core/src/agent/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L50)

The effective canister or subnet ID.

###### Inherited from

[`CallConfig`](#callconfig).[`effectiveTarget`](#effectivetarget-1)

##### pollingOptions?

> `optional` **pollingOptions?**: [`PollingOptions`](#pollingoptions-2)

Defined in: [packages/core/src/agent/actor.ts:101](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L101)

Polling options to use when making update calls. This will override the default DEFAULT_POLLING_OPTIONS.

##### queryStrategy?

> `optional` **queryStrategy?**: [`QueryStrategy`](#querystrategy-1)

Defined in: [packages/core/src/agent/actor.ts:109](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L109)

Controls how query and composite_query methods are executed.
- `'query'` (default) — standard non-replicated query call.
- `'update'` — send query methods as update calls that go through consensus.

###### Default

```ts
'query'
```

#### Methods

##### callTransform()?

> `optional` **callTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](#callconfig)\>

Defined in: [packages/core/src/agent/actor.ts:78](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L78)

An override function for update calls' CallConfig. This will be called on every calls.

###### Parameters

###### methodName

`string`

###### args

`unknown`[]

###### callConfig

[`CallConfig`](#callconfig)

###### Returns

`void` \| `Partial`\<[`CallConfig`](#callconfig)\>

##### queryTransform()?

> `optional` **queryTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](#callconfig)\>

Defined in: [packages/core/src/agent/actor.ts:87](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L87)

An override function for query calls' CallConfig. This will be called on every query.

###### Parameters

###### methodName

`string`

###### args

`unknown`[]

###### callConfig

[`CallConfig`](#callconfig)

###### Returns

`void` \| `Partial`\<[`CallConfig`](#callconfig)\>

***

### ActorMethod()

Defined in: [packages/core/src/agent/actor.ts:121](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L121)

An actor method type, defined for each methods of the actor service.

#### Extended by

- [`ActorMethodWithHttpDetails`](#actormethodwithhttpdetails)
- [`ActorMethodExtended`](#actormethodextended)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L122)

An actor method type, defined for each methods of the actor service.

#### Parameters

##### args

...`Args`

#### Returns

`Promise`\<`Ret`\>

#### Methods

##### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:124](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L124)

###### Parameters

###### options

[`CallConfig`](#callconfig)

###### Returns

(...`args`) => `Promise`\<`Ret`\>

***

### ActorMethodExtended()

Defined in: [packages/core/src/agent/actor.ts:140](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L140)

An actor method type, defined for each methods of the actor service.

#### Extends

- [`ActorMethod`](#actormethod)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

#### Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<\{ `certificate?`: [`Certificate`](#certificate); `httpDetails?`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

Defined in: [packages/core/src/agent/actor.ts:144](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L144)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<\{ `certificate?`: [`Certificate`](#certificate); `httpDetails?`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

#### Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:140](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L140)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`unknown`[]

##### Returns

`Promise`\<`unknown`\>

#### Methods

##### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:124](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L124)

###### Parameters

###### options

[`CallConfig`](#callconfig)

###### Returns

(...`args`) => `Promise`\<`unknown`\>

###### Inherited from

[`ActorMethod`](#actormethod).[`withOptions`](#withoptions)

***

### ActorMethodWithHttpDetails()

Defined in: [packages/core/src/agent/actor.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L130)

An actor method type, defined for each methods of the actor service.

#### Extends

- [`ActorMethod`](#actormethod)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

#### Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

Defined in: [packages/core/src/agent/actor.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L134)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<\{ `httpDetails`: [`HttpDetailsResponse`](#httpdetailsresponse); `result`: `Ret`; \}\>

#### Call Signature

> **ActorMethodWithHttpDetails**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L130)

An actor method type, defined for each methods of the actor service.

##### Parameters

###### args

...`unknown`[]

##### Returns

`Promise`\<`unknown`\>

#### Methods

##### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:124](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L124)

###### Parameters

###### options

[`CallConfig`](#callconfig)

###### Returns

(...`args`) => `Promise`\<`unknown`\>

###### Inherited from

[`ActorMethod`](#actormethod).[`withOptions`](#withoptions)

***

### Agent

Defined in: [packages/core/src/agent/agent/api.ts:220](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L220)

An Agent able to make calls and queries to a Replica.

#### Properties

##### rootKey

> `readonly` **rootKey**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/core/src/agent/agent/api.ts:221](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L221)

#### Methods

##### call()

> **call**(`canisterId`, `fields`): `Promise`\<[`SubmitResponse`](#submitresponse)\>

Defined in: [packages/core/src/agent/agent/api.ts:252](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L252)

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

###### fields

[`CallOptions`](#calloptions)

###### Returns

`Promise`\<[`SubmitResponse`](#submitresponse)\>

##### createReadStateRequest()?

> `optional` **createReadStateRequest**(`options`, `identity?`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/agent/api.ts:234](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L234)

Create the request for the read state call.
`readState` uses this internally.
Useful to avoid signing the same request multiple times.

###### Parameters

###### options

[`ReadStateOptions`](#readstateoptions)

###### identity?

[`Identity`](#identity-1)

###### Returns

`Promise`\<`unknown`\>

##### fetchRootKey()

> **fetchRootKey**(): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/agent/api.ts:305](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L305)

By default, the agent is configured to talk to the main Internet Computer,
and verifies responses using a hard-coded public key.

This function will instruct the agent to ask the endpoint for its public
key, and use that instead. This is required when talking to a local test
instance, for example.

Only use this when you are  _not_ talking to the main Internet Computer,
otherwise you are prone to man-in-the-middle attacks! Do not call this
function by default.

###### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

##### getPrincipal()

> **getPrincipal**(): `Promise`\<[`Principal`](../../principal/api.md#principal)\>

Defined in: [packages/core/src/agent/agent/api.ts:227](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L227)

Returns the principal ID associated with this agent (by default). It only shows
the principal of the default identity in the agent, which is the principal used
when calls don't specify it.

###### Returns

`Promise`\<[`Principal`](../../principal/api.md#principal)\>

##### invalidateIdentity()?

> `optional` **invalidateIdentity**(): `void`

Defined in: [packages/core/src/agent/agent/api.ts:312](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L312)

If an application needs to invalidate an identity under certain conditions, an `Agent` may expose an `invalidateIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to `null`.

A use case for this would be - after a certain period of inactivity, a secure application chooses to invalidate the identity of any `HttpAgent` instances. An invalid identity can be replaced by `Agent.replaceIdentity`

###### Returns

`void`

##### query()

> **query**(`canisterId`, `options`, `identity?`): `Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

Defined in: [packages/core/src/agent/agent/api.ts:287](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L287)

Send a query call to a canister. See
[the interface spec](https://sdk.dfinity.org/docs/interface-spec/#http-query).

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The Principal of the Canister to send the query to. Sending a query to
    the management canister is not supported (as it has no meaning from an agent).

###### options

[`QueryFields`](#queryfields)

Options to use to create and send the query.

###### identity?

[`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

Sender principal to use when sending the query.

###### Returns

`Promise`\<[`ApiQueryResponse`](#apiqueryresponse)\>

The response from the replica. The Promise will only reject when the communication
    failed. If the query itself failed but no protocol errors happened, the response will
    be of type QueryResponseRejected.

##### readState()

> **readState**(`effectiveTarget`, `options`, `identity?`, `request?`): `Promise`\<[`ReadStateResponse`](#readstateresponse)\>

Defined in: [packages/core/src/agent/agent/api.ts:245](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L245)

Send a read state query to the replica. This includes a list of paths to return,
and will return a Certificate. This will only reject on communication errors,
but the certificate might contain less information than requested.

###### Parameters

###### effectiveTarget

[`InputTargetPrincipal`](#inputtargetprincipal)

A Canister ID or Subnet ID related to this call.

###### options

[`ReadStateOptions`](#readstateoptions)

The options for this call.

###### identity?

[`Identity`](#identity-1)

Identity for the call. If not specified, uses the instance identity.

###### request?

`unknown`

The request to send in case it has already been created.

###### Returns

`Promise`\<[`ReadStateResponse`](#readstateresponse)\>

##### replaceIdentity()?

> `optional` **replaceIdentity**(`identity`): `void`

Defined in: [packages/core/src/agent/agent/api.ts:323](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L323)

If an application needs to replace an identity under certain conditions, an `Agent` may expose a `replaceIdentity` method.
Invoking this method will set the inner identity used by the `Agent` to a newly provided identity.

A use case for this would be - after authenticating using `@icp-sdk/auth/client`, you can replace the `AnonymousIdentity` of your `Actor` with a `DelegationIdentity`.

```ts
Actor.agentOf(defaultActor).replaceIdentity(await authClient.getIdentity());
```

###### Parameters

###### identity

[`Identity`](#identity-1)

###### Returns

`void`

##### status()

> **status**(): `Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

Defined in: [packages/core/src/agent/agent/api.ts:274](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L274)

Query the status endpoint of the replica. This normally has a few fields that
corresponds to the version of the replica, its root public key, and any other
information made public.

###### Returns

`Promise`\<[`JsonObject`](../../candid/api/index.md#jsonobject)\>

A JsonObject that is essentially a record of fields from the status
    endpoint.

##### update()

> **update**(`canisterId`, `fields`, `pollingOptions?`): `Promise`\<[`UpdateResult`](#updateresult)\>

Defined in: [packages/core/src/agent/agent/api.ts:261](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L261)

Executes an update call to a canister and returns the certified result.

###### Parameters

###### canisterId

`string` \| [`Principal`](../../principal/api.md#principal)

The canister to call.

###### fields

[`CallOptions`](#calloptions)

The call options (method name, arg, effective canister ID, optional nonce).

###### pollingOptions?

[`PollingOptions`](#pollingoptions-2)

Optional polling configuration.

###### Returns

`Promise`\<[`UpdateResult`](#updateresult)\>

The certified result including the certificate, reply bytes, and raw certificate bytes.

***

### AnonymousIdentityDescriptor

Defined in: [packages/core/src/agent/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L127)

#### Properties

##### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/core/src/agent/auth.ts:128](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L128)

***

### CallConfig

Defined in: [packages/core/src/agent/actor.ts:30](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L30)

Configuration to make calls to the Replica.

#### Properties

##### agent?

> `optional` **agent?**: [`Agent`](#agent-1)

Defined in: [packages/core/src/agent/actor.ts:35](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L35)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

##### canisterId?

> `optional` **canisterId?**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:45](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L45)

The canister ID of this Actor.

##### ~~effectiveCanisterId?~~

> `optional` **effectiveCanisterId?**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/actor.ts:55](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L55)

###### Deprecated

Use [CallConfig.effectiveTarget](#effectivetarget-1) instead.

##### effectiveTarget?

> `optional` **effectiveTarget?**: [`TargetPrincipal`](#targetprincipal)

Defined in: [packages/core/src/agent/actor.ts:50](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L50)

The effective canister or subnet ID.

##### nonce?

> `optional` **nonce?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/actor.ts:60](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L60)

The nonce to use for this call. This is used to prevent replay attacks.

##### pollingOptions?

> `optional` **pollingOptions?**: [`PollingOptions`](#pollingoptions-2)

Defined in: [packages/core/src/agent/actor.ts:40](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L40)

Options for controlling polling behavior.

***

### CallContext

Defined in: [packages/core/src/agent/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L45)

Call context for errors that arise from a direct HTTP call response.

#### Extends

- [`PollingCallContext`](#pollingcallcontext)

#### Properties

##### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:37](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L37)

###### Inherited from

[`PollingCallContext`](#pollingcallcontext).[`canisterId`](#canisterid-5)

##### effectiveTarget

> **effectiveTarget**: [`TargetPrincipal`](#targetprincipal)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L39)

###### Inherited from

[`PollingCallContext`](#pollingcallcontext).[`effectiveTarget`](#effectivetarget-4)

##### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](#httpdetailsresponse)

Defined in: [packages/core/src/agent/errors.ts:46](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L46)

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L38)

###### Inherited from

[`PollingCallContext`](#pollingcallcontext).[`methodName`](#methodname-2)

***

### CallOptions

Defined in: [packages/core/src/agent/agent/api.ts:108](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L108)

Options when doing a [Agent.call](#call-3) call.

#### Extended by

- [`UpdateOptions`](#updateoptions)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:117](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L117)

A binary encoded argument. This is already encoded and will be sent as is.

##### callSync?

> `optional` **callSync?**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:133](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L133)

Whether to use synchronous call mode. Defaults to true.

##### ~~effectiveCanisterId?~~

> `optional` **effectiveCanisterId?**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/api.ts:128](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L128)

###### Deprecated

Use [CallOptions.effectiveTarget](#effectivetarget-3) instead.

##### effectiveTarget?

> `optional` **effectiveTarget?**: [`InputTargetPrincipal`](#inputtargetprincipal)

Defined in: [packages/core/src/agent/agent/api.ts:123](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L123)

An effective canister or subnet ID, used for routing. Usually the canister ID, except for management canister calls.

###### See

https://internetcomputer.org/docs/current/references/ic-interface-spec/#http-effective-canister-id

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:112](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L112)

The method name to call.

##### nonce?

> `optional` **nonce?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/api.ts:138](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L138)

An optional nonce to use for the call, used to prevent replay attacks.

***

### CallRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:62](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L62)

#### Extends

- `Record`\<`string`, `any`\>

#### Indexable

> \[`key`: `string`\]: `any`

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/http/types.ts:66](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L66)

##### canister\_id

> **canister\_id**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:64](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L64)

##### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/types.ts:68](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L68)

##### method\_name

> **method\_name**: `string`

Defined in: [packages/core/src/agent/agent/http/types.ts:65](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L65)

##### nonce?

> `optional` **nonce?**: [`Nonce`](#nonce-5)

Defined in: [packages/core/src/agent/agent/http/types.ts:69](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L69)

##### request\_type

> **request\_type**: [`Call`](#call-1)

Defined in: [packages/core/src/agent/agent/http/types.ts:63](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L63)

##### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:67](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L67)

***

### Cert

Defined in: [packages/core/src/agent/certificate.ts:41](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L41)

#### Properties

##### delegation?

> `optional` **delegation?**: `Delegation`

Defined in: [packages/core/src/agent/certificate.ts:44](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L44)

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:43](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L43)

##### tree

> **tree**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:42](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L42)

***

### CheckCanisterRangesParams

Defined in: [packages/core/src/agent/certificate.ts:867](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L867)

#### Properties

##### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/certificate.ts:868](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L868)

##### subnetId

> **subnetId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/certificate.ts:869](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L869)

##### tree

> **tree**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:870](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L870)

***

### CreateActorClassOpts

Defined in: [packages/core/src/agent/actor.ts:182](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L182)

#### Properties

##### certificate?

> `optional` **certificate?**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:184](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L184)

##### httpDetails?

> `optional` **httpDetails?**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:183](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L183)

***

### CreateCertificateOptions

Defined in: [packages/core/src/agent/certificate.ts:171](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L171)

#### Properties

##### agent?

> `optional` **agent?**: [`Agent`](#agent-1)

Defined in: [packages/core/src/agent/certificate.ts:210](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L210)

The agent used to sync time with the IC network, if the certificate fails the freshness check.
If the agent does not implement the [HttpAgent.getTimeDiffMsecs](#gettimediffmsecs), [HttpAgent.hasSyncedTime](#hassyncedtime), and [HttpAgent.syncTime](#synctime) methods,
time will not be synced in case of a freshness check failure.

###### Default

```ts
undefined
```

##### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/certificate.ts:188](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L188)

BLS Verification strategy. Default strategy uses bls12_381 from `@noble/curves`

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:175](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L175)

The bytes encoding the certificate to be verified

##### disableTimeVerification?

> `optional` **disableTimeVerification?**: `boolean`

Defined in: [packages/core/src/agent/certificate.ts:202](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L202)

Overrides the maxAgeInMinutes setting and skips comparing the client's time against the certificate. Used for scenarios where the machine's clock is known to be out of sync, or for inspecting expired certificates.

###### Default

```ts
false
```

##### maxAgeInMinutes?

> `optional` **maxAgeInMinutes?**: `number`

Defined in: [packages/core/src/agent/certificate.ts:196](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L196)

The maximum age of the certificate in minutes. Default is 5 minutes.
This is used to verify the time the certificate was signed, particularly for validating Delegation certificates, which can live for longer than the default window of +/- 5 minutes. If the certificate is
older than the specified age, it will fail verification.

###### Default

```ts
5
```

##### principal

> **principal**: [`TargetPrincipal`](#targetprincipal)

Defined in: [packages/core/src/agent/certificate.ts:184](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L184)

The principal for which the certificate is being verified.

##### rootKey

> **rootKey**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:180](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L180)

The root key against which to verify the certificate
(normally, the root key of the IC main network)

***

### ExpirableStore

Defined in: [packages/core/src/agent/utils/expirableStore.ts:6](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/expirableStore.ts#L6)

Generic interface for a key-value store with time-based expiration.
Keys are strings, values are of type V.
Implementations must handle expiration internally.

#### Type Parameters

##### V

`V`

#### Properties

##### expirationTime

> `readonly` **expirationTime**: `number`

Defined in: [packages/core/src/agent/utils/expirableStore.ts:10](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/expirableStore.ts#L10)

Time in milliseconds after which entries expire.

#### Methods

##### delete()

> **delete**(`key`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:27](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/expirableStore.ts#L27)

Delete the entry for a key.

###### Parameters

###### key

`string`

###### Returns

`Promise`\<`void`\>

##### get()

> **get**(`key`): `Promise`\<`V` \| `undefined`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:16](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/expirableStore.ts#L16)

Get the value for a key.
Returns undefined if the key is not present or has expired.

###### Parameters

###### key

`string`

###### Returns

`Promise`\<`V` \| `undefined`\>

##### set()

> **set**(`key`, `value`): `Promise`\<`void`\>

Defined in: [packages/core/src/agent/utils/expirableStore.ts:22](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/expirableStore.ts#L22)

Store a value for a key.
Prunes expired entries before inserting.

###### Parameters

###### key

`string`

###### value

`V`

###### Returns

`Promise`\<`void`\>

***

### HttpAgentBaseRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:21](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L21)

#### Extended by

- [`HttpAgentSubmitRequest`](#httpagentsubmitrequest)
- [`HttpAgentQueryRequest`](#httpagentqueryrequest)
- [`HttpAgentReadStateRequest`](#httpagentreadstaterequest)

#### Properties

##### endpoint

> `readonly` **endpoint**: [`Endpoint`](#endpoint)

Defined in: [packages/core/src/agent/agent/http/types.ts:22](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L22)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L23)

***

### HttpAgentOptions

Defined in: [packages/core/src/agent/agent/http/index.ts:135](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L135)

#### Properties

##### backoffStrategy?

> `optional` **backoffStrategy?**: `BackoffStrategyFactory`

Defined in: [packages/core/src/agent/agent/http/index.ts:182](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L182)

The strategy to use for backoff when retrying requests

##### callOptions?

> `optional` **callOptions?**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:145](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L145)

##### credentials?

> `optional` **credentials?**: `object`

Defined in: [packages/core/src/agent/agent/http/index.ts:161](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L161)

###### name

> **name**: `string`

###### password?

> `optional` **password?**: `string`

##### fetch?

> `optional` **fetch?**: \{(`input`, `init?`): `Promise`\<`Response`\>; (`input`, `init?`): `Promise`\<`Response`\>; \}

Defined in: [packages/core/src/agent/agent/http/index.ts:137](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L137)

###### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

###### Parameters

###### input

`URL` \| `RequestInfo`

###### init?

`RequestInit`

###### Returns

`Promise`\<`Response`\>

###### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

###### Parameters

###### input

`string` \| `URL` \| `Request`

###### init?

`RequestInit`

###### Returns

`Promise`\<`Response`\>

##### fetchOptions?

> `optional` **fetchOptions?**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:142](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L142)

##### host?

> `optional` **host?**: `string`

Defined in: [packages/core/src/agent/agent/http/index.ts:149](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L149)

##### identity?

> `optional` **identity?**: [`Identity`](#identity-1) \| `Promise`\<[`Identity`](#identity-1)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:153](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L153)

##### ingressExpiryInMinutes?

> `optional` **ingressExpiryInMinutes?**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L159)

The maximum time a request can be delayed before being rejected.

###### Default

```ts
5 minutes
```

##### logToConsole?

> `optional` **logToConsole?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:197](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L197)

Whether to log to the console. Defaults to false.

##### retryTimes?

> `optional` **retryTimes?**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:178](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L178)

Number of times to retry requests before throwing an error

###### Default

```ts
3
```

##### rootKey?

> `optional` **rootKey?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:202](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L202)

Alternate root key to use for verifying certificates. If not provided, the default IC root key will be used.

##### shouldFetchRootKey?

> `optional` **shouldFetchRootKey?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:207](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L207)

Whether or not the root key should be automatically fetched during construction. Defaults to false.

##### shouldSyncTime?

> `optional` **shouldSyncTime?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:212](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L212)

Whether or not to sync the time with the network during construction. Defaults to false.

##### subnetNodeKeyExpirableStore?

> `optional` **subnetNodeKeyExpirableStore?**: [`ExpirableStore`](#expirablestore)\<`SubnetNodeKeys`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:193](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L193)

Custom store for caching subnet node keys.
Allows sharing the cache across multiple HttpAgent instances.
Defaults to IndexedDB in browser environments, in-memory otherwise.

##### useQueryNonces?

> `optional` **useQueryNonces?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:173](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L173)

Adds a unique [Nonce](#nonce-5) with each query.
Enabling will prevent queries from being answered with a cached response.

###### Example

```ts
const agent = new HttpAgent({ useQueryNonces: true });
agent.addTransform(makeNonceTransform(makeNonce);
```

###### Default

```ts
false
```

##### verifyQuerySignatures?

> `optional` **verifyQuerySignatures?**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:187](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L187)

Whether the agent should verify signatures signed by node keys on query responses. Increases security, but adds overhead and must make a separate request to cache the node keys for the canister's subnet.

###### Default

```ts
true
```

***

### HttpAgentQueryRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:33](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L33)

#### Extends

- [`HttpAgentBaseRequest`](#httpagentbaserequest)

#### Properties

##### body

> **body**: [`ReadRequest`](#readrequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:35](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L35)

##### endpoint

> `readonly` **endpoint**: [`Query`](#query)

Defined in: [packages/core/src/agent/agent/http/types.ts:34](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L34)

###### Overrides

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`endpoint`](#endpoint-1)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L23)

###### Inherited from

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`request`](#request-1)

***

### HttpAgentReadStateRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:38](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L38)

#### Extends

- [`HttpAgentBaseRequest`](#httpagentbaserequest)

#### Properties

##### body

> **body**: [`ReadRequest`](#readrequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:40](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L40)

##### endpoint

> `readonly` **endpoint**: [`ReadState`](#readstate)

Defined in: [packages/core/src/agent/agent/http/types.ts:39](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L39)

###### Overrides

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`endpoint`](#endpoint-1)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L23)

###### Inherited from

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`request`](#request-1)

***

### HttpAgentRequestTransformFn()

Defined in: [packages/core/src/agent/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`void` \| [`HttpAgentRequest`](#httpagentrequest) \| `undefined`\>

Defined in: [packages/core/src/agent/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L56)

#### Parameters

##### args

[`HttpAgentRequest`](#httpagentrequest)

#### Returns

`Promise`\<`void` \| [`HttpAgentRequest`](#httpagentrequest) \| `undefined`\>

#### Properties

##### priority?

> `optional` **priority?**: `number`

Defined in: [packages/core/src/agent/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L57)

***

### HttpAgentSubmitRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:28](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L28)

#### Extends

- [`HttpAgentBaseRequest`](#httpagentbaserequest)

#### Properties

##### body

> **body**: [`CallRequest`](#callrequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:30](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L30)

##### endpoint

> `readonly` **endpoint**: [`Call`](#call)

Defined in: [packages/core/src/agent/agent/http/types.ts:29](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L29)

###### Overrides

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`endpoint`](#endpoint-1)

##### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L23)

###### Inherited from

[`HttpAgentBaseRequest`](#httpagentbaserequest).[`request`](#request-1)

***

### HttpDetailsResponse

Defined in: [packages/core/src/agent/agent/api.ts:40](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L40)

#### Properties

##### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

Defined in: [packages/core/src/agent/agent/api.ts:44](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L44)

##### ok

> **ok**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:41](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L41)

##### status

> **status**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:42](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L42)

##### statusText

> **statusText**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:43](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L43)

***

### Identity

Defined in: [packages/core/src/agent/auth.ts:40](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L40)

A General Identity object. This does not have to be a private key (for example,
the Anonymous identity), but it must be able to transform request.

#### Methods

##### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/auth.ts:45](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L45)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

###### Returns

[`Principal`](../../principal/api.md#principal)

##### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:52](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L52)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

###### Parameters

###### request

[`HttpAgentRequest`](#httpagentrequest)

###### Returns

`Promise`\<`unknown`\>

***

### JsonnableExpiry

Defined in: [packages/core/src/agent/agent/http/expiry.ts:20](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L20)

#### Properties

##### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:21](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L21)

***

### KeyPair

Defined in: [packages/core/src/agent/auth.ts:10](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L10)

A Key Pair, containing a secret and public key.

#### Properties

##### publicKey

> **publicKey**: [`PublicKey`](#publickey-1)

Defined in: [packages/core/src/agent/auth.ts:12](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L12)

##### secretKey

> **secretKey**: `Uint8Array`

Defined in: [packages/core/src/agent/auth.ts:11](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L11)

***

### LookupLabelResultAbsent

Defined in: [packages/core/src/agent/certificate.ts:570](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L570)

#### Properties

##### status

> **status**: [`Absent`](#absent)

Defined in: [packages/core/src/agent/certificate.ts:571](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L571)

***

### LookupLabelResultFound

Defined in: [packages/core/src/agent/certificate.ts:578](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L578)

#### Properties

##### status

> **status**: [`Found`](#found)

Defined in: [packages/core/src/agent/certificate.ts:579](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L579)

##### value

> **value**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:580](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L580)

***

### LookupLabelResultGreater

Defined in: [packages/core/src/agent/certificate.ts:583](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L583)

#### Properties

##### status

> **status**: [`Greater`](#greater)

Defined in: [packages/core/src/agent/certificate.ts:584](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L584)

***

### LookupLabelResultLess

Defined in: [packages/core/src/agent/certificate.ts:587](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L587)

#### Properties

##### status

> **status**: [`Less`](#less)

Defined in: [packages/core/src/agent/certificate.ts:588](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L588)

***

### LookupLabelResultUnknown

Defined in: [packages/core/src/agent/certificate.ts:574](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L574)

#### Properties

##### status

> **status**: [`Unknown`](#unknown-1)

Defined in: [packages/core/src/agent/certificate.ts:575](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L575)

***

### LookupPathResultAbsent

Defined in: [packages/core/src/agent/certificate.ts:515](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L515)

#### Properties

##### status

> **status**: [`Absent`](#absent-1)

Defined in: [packages/core/src/agent/certificate.ts:516](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L516)

***

### LookupPathResultError

Defined in: [packages/core/src/agent/certificate.ts:528](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L528)

#### Properties

##### status

> **status**: [`Error`](#error)

Defined in: [packages/core/src/agent/certificate.ts:529](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L529)

***

### LookupPathResultFound

Defined in: [packages/core/src/agent/certificate.ts:523](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L523)

#### Properties

##### status

> **status**: [`Found`](#found-1)

Defined in: [packages/core/src/agent/certificate.ts:524](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L524)

##### value

> **value**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:525](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L525)

***

### LookupPathResultUnknown

Defined in: [packages/core/src/agent/certificate.ts:519](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L519)

#### Properties

##### status

> **status**: [`Unknown`](#unknown-2)

Defined in: [packages/core/src/agent/certificate.ts:520](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L520)

***

### LookupSubtreeResultAbsent

Defined in: [packages/core/src/agent/certificate.ts:544](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L544)

#### Properties

##### status

> **status**: [`Absent`](#absent-2)

Defined in: [packages/core/src/agent/certificate.ts:545](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L545)

***

### LookupSubtreeResultFound

Defined in: [packages/core/src/agent/certificate.ts:552](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L552)

#### Properties

##### status

> **status**: [`Found`](#found-2)

Defined in: [packages/core/src/agent/certificate.ts:553](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L553)

##### value

> **value**: [`HashTree`](#hashtree)

Defined in: [packages/core/src/agent/certificate.ts:554](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L554)

***

### LookupSubtreeResultUnknown

Defined in: [packages/core/src/agent/certificate.ts:548](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L548)

#### Properties

##### status

> **status**: [`Unknown`](#unknown-3)

Defined in: [packages/core/src/agent/certificate.ts:549](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L549)

***

### NodeSignature

Defined in: [packages/core/src/agent/agent/api.ts:57](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L57)

#### Properties

##### identity

> **identity**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:63](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L63)

##### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:61](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L61)

##### timestamp

> **timestamp**: `bigint`

Defined in: [packages/core/src/agent/agent/api.ts:59](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L59)

***

### PollForResponseResult

Defined in: [packages/core/src/agent/polling/types.ts:20](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L20)

The result of polling for a response, including the certificate, reply bytes, and raw certificate bytes.

#### Extended by

- [`UpdateResult`](#updateresult)

#### Properties

##### certificate

> **certificate**: [`Certificate`](#certificate)

Defined in: [packages/core/src/agent/polling/types.ts:22](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L22)

The certificate for the request, which can be used to verify the reply.

##### rawCertificate

> **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:26](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L26)

The raw certificate bytes for the request.

##### reply

> **reply**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:24](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L24)

The reply bytes for the request.

***

### PollingCallContext

Defined in: [packages/core/src/agent/errors.ts:36](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L36)

Call context for errors that arise during polling.

#### Extended by

- [`CallContext`](#callcontext-47)

#### Properties

##### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/errors.ts:37](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L37)

##### effectiveTarget

> **effectiveTarget**: [`TargetPrincipal`](#targetprincipal)

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L39)

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L38)

***

### PollingOptions

Defined in: [packages/core/src/agent/polling/index.ts:40](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L40)

Options for controlling polling behavior

#### Properties

##### blsVerify?

> `optional` **blsVerify?**: `VerifyFunc`

Defined in: [packages/core/src/agent/polling/index.ts:57](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L57)

Optional replacement function that verifies the BLS signature of a certificate.

##### preSignReadStateRequest?

> `optional` **preSignReadStateRequest?**: `boolean`

Defined in: [packages/core/src/agent/polling/index.ts:52](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L52)

Whether to reuse the same signed request for polling or create a new unsigned request each time.

###### Default

```ts
false
```

##### request?

> `optional` **request?**: [`ReadStateRequest`](#readstaterequest)

Defined in: [packages/core/src/agent/polling/index.ts:63](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L63)

The request to use for polling. If not provided, a new request will be created.
This is only used if `preSignReadStateRequest` is set to false.

##### strategy?

> `optional` **strategy?**: [`PollStrategy`](#pollstrategy)

Defined in: [packages/core/src/agent/polling/index.ts:46](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L46)

A polling strategy that dictates how much and often we should poll the
read_state endpoint to get the result of an update call.

###### Default

[defaultStrategy](namespaces/strategy.md#defaultstrategy)

***

### PublicKey

Defined in: [packages/core/src/agent/auth.ts:28](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L28)

A Public Key implementation.

#### Properties

##### derKey?

> `optional` **derKey?**: [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/auth.ts:33](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L33)

##### rawKey?

> `optional` **rawKey?**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/auth.ts:32](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L32)

#### Methods

##### toDer()

> **toDer**(): [`DerEncodedPublicKey`](#derencodedpublickey)

Defined in: [packages/core/src/agent/auth.ts:29](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L29)

###### Returns

[`DerEncodedPublicKey`](#derencodedpublickey)

##### toRaw()?

> `optional` **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/agent/auth.ts:31](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L31)

###### Returns

`Uint8Array`

***

### PublicKeyIdentityDescriptor

Defined in: [packages/core/src/agent/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L130)

#### Properties

##### publicKey

> **publicKey**: `string`

Defined in: [packages/core/src/agent/auth.ts:132](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L132)

##### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/core/src/agent/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L131)

***

### QueryFields

Defined in: [packages/core/src/agent/agent/api.ts:83](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L83)

Options when doing a [Agent.query](#query-3) call.

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:92](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L92)

A binary encoded argument. This is already encoded and will be sent as is.

##### ~~effectiveCanisterId?~~

> `optional` **effectiveCanisterId?**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/api.ts:102](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L102)

###### Deprecated

Use [QueryFields.effectiveTarget](#effectivetarget-5)

##### effectiveTarget?

> `optional` **effectiveTarget?**: [`InputTargetPrincipal`](#inputtargetprincipal)

Defined in: [packages/core/src/agent/agent/api.ts:97](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L97)

Overrides canister or subnet id for path to fetch. This is used for management canister calls.

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:87](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L87)

The method name to call.

***

### QueryRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:85](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L85)

#### Extends

- `Record`\<`string`, `any`\>

#### Indexable

> \[`key`: `string`\]: `any`

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/http/types.ts:89](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L89)

##### canister\_id

> **canister\_id**: [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:87](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L87)

##### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/types.ts:91](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L91)

##### method\_name

> **method\_name**: `string`

Defined in: [packages/core/src/agent/agent/http/types.ts:88](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L88)

##### nonce?

> `optional` **nonce?**: [`Nonce`](#nonce-5)

Defined in: [packages/core/src/agent/agent/http/types.ts:92](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L92)

##### request\_type

> **request\_type**: [`Query`](#query-1)

Defined in: [packages/core/src/agent/agent/http/types.ts:86](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L86)

##### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:90](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L90)

***

### QueryResponseBase

Defined in: [packages/core/src/agent/agent/api.ts:52](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L52)

#### Extended by

- [`QueryResponseReplied`](#queryresponsereplied)
- [`QueryResponseRejected`](#queryresponserejected)

#### Properties

##### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](#queryrequest)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L54)

##### status

> **status**: [`QueryResponseStatus`](#queryresponsestatus)

Defined in: [packages/core/src/agent/agent/api.ts:53](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L53)

***

### QueryResponseRejected

Defined in: [packages/core/src/agent/agent/api.ts:72](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L72)

#### Extends

- [`QueryResponseBase`](#queryresponsebase)

#### Properties

##### error\_code

> **error\_code**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:76](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L76)

##### reject\_code

> **reject\_code**: [`ReplicaRejectCode`](#replicarejectcode)

Defined in: [packages/core/src/agent/agent/api.ts:74](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L74)

##### reject\_message

> **reject\_message**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:75](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L75)

##### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](#queryrequest)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L54)

###### Inherited from

[`QueryResponseBase`](#queryresponsebase).[`requestDetails`](#requestdetails)

##### signatures?

> `optional` **signatures?**: [`NodeSignature`](#nodesignature)[]

Defined in: [packages/core/src/agent/agent/api.ts:77](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L77)

##### status

> **status**: [`Rejected`](#rejected)

Defined in: [packages/core/src/agent/agent/api.ts:73](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L73)

###### Overrides

[`QueryResponseBase`](#queryresponsebase).[`status`](#status-18)

***

### QueryResponseReplied

Defined in: [packages/core/src/agent/agent/api.ts:66](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L66)

#### Extends

- [`QueryResponseBase`](#queryresponsebase)

#### Properties

##### reply

> **reply**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:68](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L68)

###### arg

> **arg**: `Uint8Array`

##### requestDetails?

> `optional` **requestDetails?**: [`QueryRequest`](#queryrequest)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L54)

###### Inherited from

[`QueryResponseBase`](#queryresponsebase).[`requestDetails`](#requestdetails)

##### signatures?

> `optional` **signatures?**: [`NodeSignature`](#nodesignature)[]

Defined in: [packages/core/src/agent/agent/api.ts:69](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L69)

##### status

> **status**: [`Replied`](#replied)

Defined in: [packages/core/src/agent/agent/api.ts:67](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L67)

###### Overrides

[`QueryResponseBase`](#queryresponsebase).[`status`](#status-18)

***

### ReadStateOptions

Defined in: [packages/core/src/agent/agent/api.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L23)

Options when doing a [Agent.readState](#readstate-3) call.

#### Properties

##### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/core/src/agent/agent/api.ts:27](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L27)

A list of paths to read the state of.

***

### ReadStateRequest

Defined in: [packages/core/src/agent/agent/http/types.ts:96](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L96)

#### Extends

- `Record`\<`string`, `any`\>

#### Indexable

> \[`key`: `string`\]: `any`

#### Properties

##### ingress\_expiry

> **ingress\_expiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/types.ts:99](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L99)

##### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/core/src/agent/agent/http/types.ts:98](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L98)

##### request\_type

> **request\_type**: [`ReadState`](#readstate-1)

Defined in: [packages/core/src/agent/agent/http/types.ts:97](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L97)

##### sender

> **sender**: `Uint8Array`\<`ArrayBufferLike`\> \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/http/types.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L100)

***

### ReadStateResponse

Defined in: [packages/core/src/agent/agent/api.ts:154](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L154)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L155)

***

### RequestContext

Defined in: [packages/core/src/agent/errors.ts:26](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L26)

#### Properties

##### ingressExpiry

> **ingressExpiry**: [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/errors.ts:30](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L30)

##### requestId?

> `optional` **requestId?**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/errors.ts:27](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L27)

##### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:28](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L28)

##### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:29](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L29)

***

### Signed

Defined in: [packages/core/src/agent/agent/http/types.ts:43](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L43)

#### Type Parameters

##### T

`T`

#### Properties

##### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:44](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L44)

##### sender\_pubkey

> **sender\_pubkey**: `ArrayBuffer`

Defined in: [packages/core/src/agent/agent/http/types.ts:45](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L45)

##### sender\_sig

> **sender\_sig**: `ArrayBuffer`

Defined in: [packages/core/src/agent/agent/http/types.ts:46](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L46)

***

### SubmitResponse

Defined in: [packages/core/src/agent/agent/api.ts:190](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L190)

#### Properties

##### requestDetails?

> `optional` **requestDetails?**: [`CallRequest`](#callrequest)

Defined in: [packages/core/src/agent/agent/api.ts:199](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L199)

##### requestId

> **requestId**: [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/agent/api.ts:191](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L191)

##### response

> **response**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:192](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L192)

###### body

> **body**: [`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

###### ok

> **ok**: `boolean`

###### status

> **status**: `number`

###### statusText

> **statusText**: `string`

***

### UnSigned

Defined in: [packages/core/src/agent/agent/http/types.ts:49](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L49)

#### Type Parameters

##### T

`T`

#### Properties

##### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:50](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L50)

***

### UpdateOptions

Defined in: [packages/core/src/agent/agent/api.ts:141](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L141)

Options when doing a [Agent.call](#call-3) call.

#### Extends

- [`CallOptions`](#calloptions)

#### Properties

##### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:117](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L117)

A binary encoded argument. This is already encoded and will be sent as is.

###### Inherited from

[`CallOptions`](#calloptions).[`arg`](#arg)

##### callSync?

> `optional` **callSync?**: `boolean`

Defined in: [packages/core/src/agent/agent/api.ts:133](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L133)

Whether to use synchronous call mode. Defaults to true.

###### Inherited from

[`CallOptions`](#calloptions).[`callSync`](#callsync)

##### ~~effectiveCanisterId?~~

> `optional` **effectiveCanisterId?**: `string` \| [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/agent/api.ts:128](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L128)

###### Deprecated

Use [CallOptions.effectiveTarget](#effectivetarget-3) instead.

###### Inherited from

[`CallOptions`](#calloptions).[`effectiveCanisterId`](#effectivecanisterid-2)

##### effectiveTarget?

> `optional` **effectiveTarget?**: [`InputTargetPrincipal`](#inputtargetprincipal)

Defined in: [packages/core/src/agent/agent/api.ts:123](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L123)

An effective canister or subnet ID, used for routing. Usually the canister ID, except for management canister calls.

###### See

https://internetcomputer.org/docs/current/references/ic-interface-spec/#http-effective-canister-id

###### Inherited from

[`CallOptions`](#calloptions).[`effectiveTarget`](#effectivetarget-3)

##### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:112](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L112)

The method name to call.

###### Inherited from

[`CallOptions`](#calloptions).[`methodName`](#methodname-1)

##### nonce?

> `optional` **nonce?**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/api.ts:138](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L138)

An optional nonce to use for the call, used to prevent replay attacks.

###### Inherited from

[`CallOptions`](#calloptions).[`nonce`](#nonce-1)

##### onPollingStarted?

> `optional` **onPollingStarted?**: () => `void`

Defined in: [packages/core/src/agent/agent/api.ts:151](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L151)

An optional callback that will be invoked once the agent starts polling for the result of the
update call.

If `callSync` is set to false, polling will start, and the callback will be invoked, once the
request has been accepted by a single node. If `callSync` is set to true, the IC will first
try to process the request synchronously. But if the synchronous request timeout is exceeded,
the agent will start polling for the result, at which point the callback will be invoked.

###### Returns

`void`

***

### UpdateResult

Defined in: [packages/core/src/agent/agent/api.ts:206](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L206)

The result of [Agent.update](#update-1), extending [PollForResponseResult](#pollforresponseresult)
with the request details and raw HTTP response from the call.

#### Extends

- [`PollForResponseResult`](#pollforresponseresult)

#### Properties

##### callResponse

> **callResponse**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:210](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L210)

The raw HTTP response from the call endpoint.

###### body

> **body**: [`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

###### headers

> **headers**: [`HttpHeaderField`](#httpheaderfield)[]

###### ok

> **ok**: `boolean`

###### status

> **status**: `number`

###### statusText

> **statusText**: `string`

##### certificate

> **certificate**: [`Certificate`](#certificate)

Defined in: [packages/core/src/agent/polling/types.ts:22](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L22)

The certificate for the request, which can be used to verify the reply.

###### Inherited from

[`PollForResponseResult`](#pollforresponseresult).[`certificate`](#certificate-3)

##### rawCertificate

> **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:26](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L26)

The raw certificate bytes for the request.

###### Inherited from

[`PollForResponseResult`](#pollforresponseresult).[`rawCertificate`](#rawcertificate-1)

##### reply

> **reply**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:24](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L24)

The reply bytes for the request.

###### Inherited from

[`PollForResponseResult`](#pollforresponseresult).[`reply`](#reply)

##### requestDetails?

> `optional` **requestDetails?**: [`CallRequest`](#callrequest)

Defined in: [packages/core/src/agent/agent/api.ts:208](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L208)

The request details from the call, if available.

***

### v2ResponseBody

Defined in: [packages/core/src/agent/agent/api.ts:158](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L158)

#### Properties

##### error\_code?

> `optional` **error\_code?**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:159](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L159)

##### reject\_code

> **reject\_code**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:160](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L160)

##### reject\_message

> **reject\_message**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:161](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L161)

***

### v4ResponseBody

Defined in: [packages/core/src/agent/agent/api.ts:175](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L175)

#### Properties

##### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:176](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L176)

## Type Aliases

### ActorConstructor

> **ActorConstructor** = (`config`) => [`ActorSubclass`](#actorsubclass)

Defined in: [packages/core/src/agent/actor.ts:383](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L383)

#### Parameters

##### config

[`ActorConfig`](#actorconfig)

#### Returns

[`ActorSubclass`](#actorsubclass)

***

### ActorMethodMappedExtended

> **ActorMethodMappedExtended**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodExtended<Args, Ret> : never }`

Defined in: [packages/core/src/agent/actor.ts:163](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L163)

#### Type Parameters

##### T

`T`

***

### ActorMethodMappedWithHttpDetails

> **ActorMethodMappedWithHttpDetails**\<`T`\> = `{ [K in keyof T]: T[K] extends FunctionWithArgsAndReturn<infer Args, infer Ret> ? ActorMethodWithHttpDetails<Args, Ret> : never }`

Defined in: [packages/core/src/agent/actor.ts:156](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L156)

#### Type Parameters

##### T

`T`

***

### ActorSubclass

> **ActorSubclass**\<`T`\> = [`Actor`](#actor) & `T`

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L116)

A subclass of an actor. Actor class itself is meant to be a based class.

#### Type Parameters

##### T

`T` = `Record`\<`string`, [`ActorMethod`](#actormethod)\>

***

### AgentLog

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](#agenterror); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/core/src/agent/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L25)

***

### ApiQueryResponse

> **ApiQueryResponse** = [`QueryResponse`](#queryresponse) & `object`

Defined in: [packages/core/src/agent/agent/api.ts:47](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L47)

#### Type Declaration

##### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](#httpdetailsresponse)

##### requestId

> **requestId**: [`RequestId`](#requestid-9)

***

### CanisterRanges

> **CanisterRanges** = \[[`Principal`](../../principal/api.md#principal), [`Principal`](../../principal/api.md#principal)\][]

Defined in: [packages/core/src/agent/certificate.ts:877](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L877)

Canister ranges in the form of an array of [start, end] principal tuples,
usually decoded from the certificate.

***

### DerEncodedPublicKey

> **DerEncodedPublicKey** = [`Uint8ArrayBuffer`](../../candid/api/index.md#uint8arraybuffer) & `object`

Defined in: [packages/core/src/agent/auth.ts:18](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L18)

A public key that is DER encoded. This is a branded Uint8Array.

#### Type Declaration

##### \_\_derEncodedPublicKey\_\_?

> `optional` **\_\_derEncodedPublicKey\_\_?**: `void`

***

### EmptyHashTree

> **EmptyHashTree** = \[[`Empty`](#empty)\]

Defined in: [packages/core/src/agent/certificate.ts:60](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L60)

***

### Envelope

> **Envelope**\<`T`\> = [`Signed`](#signed)\<`T`\> \| [`UnSigned`](#unsigned)\<`T`\>

Defined in: [packages/core/src/agent/agent/http/types.ts:53](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L53)

#### Type Parameters

##### T

`T`

***

### ForkHashTree

> **ForkHashTree** = \[[`Fork`](#fork), [`HashTree`](#hashtree), [`HashTree`](#hashtree)\]

Defined in: [packages/core/src/agent/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L61)

***

### FunctionWithArgsAndReturn

> **FunctionWithArgsAndReturn**\<`Args`, `Ret`\> = (...`args`) => `Ret`

Defined in: [packages/core/src/agent/actor.ts:151](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L151)

#### Type Parameters

##### Args

`Args` *extends* `unknown`[] = `unknown`[]

##### Ret

`Ret` = `unknown`

#### Parameters

##### args

...`Args`

#### Returns

`Ret`

***

### HashTree

> **HashTree** = [`EmptyHashTree`](#emptyhashtree) \| [`ForkHashTree`](#forkhashtree) \| [`LabeledHashTree`](#labeledhashtree) \| [`LeafHashTree`](#leafhashtree) \| [`PrunedHashTree`](#prunedhashtree)

Defined in: [packages/core/src/agent/certificate.ts:66](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L66)

***

### HttpAgentRequest

> **HttpAgentRequest** = [`HttpAgentQueryRequest`](#httpagentqueryrequest) \| [`HttpAgentSubmitRequest`](#httpagentsubmitrequest) \| [`HttpAgentReadStateRequest`](#httpagentreadstaterequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:16](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L16)

***

### HttpHeaderField

> **HttpHeaderField** = \[`string`, `string`\]

Defined in: [packages/core/src/agent/agent/http/types.ts:26](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L26)

***

### IdentityDescriptor

> **IdentityDescriptor** = [`AnonymousIdentityDescriptor`](#anonymousidentitydescriptor) \| [`PublicKeyIdentityDescriptor`](#publickeyidentitydescriptor)

Defined in: [packages/core/src/agent/auth.ts:134](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L134)

***

### InputTargetPrincipal

> **InputTargetPrincipal** = \{ `canisterId`: [`Principal`](../../principal/api.md#principal) \| `string`; \} \| \{ `subnetId`: [`Principal`](../../principal/api.md#principal) \| `string`; \}

Defined in: [packages/core/src/agent/agent/api.ts:213](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L213)

***

### LabeledHashTree

> **LabeledHashTree** = \[[`Labeled`](#labeled), [`NodeLabel`](#nodelabel), [`HashTree`](#hashtree)\]

Defined in: [packages/core/src/agent/certificate.ts:62](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L62)

***

### LabelLookupResult

> **LabelLookupResult** = [`LookupLabelResultAbsent`](#lookuplabelresultabsent) \| [`LookupLabelResultUnknown`](#lookuplabelresultunknown) \| [`LookupLabelResultFound`](#lookuplabelresultfound) \| [`LookupLabelResultGreater`](#lookuplabelresultgreater) \| [`LookupLabelResultLess`](#lookuplabelresultless)

Defined in: [packages/core/src/agent/certificate.ts:591](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L591)

***

### LeafHashTree

> **LeafHashTree** = \[[`Leaf`](#leaf), [`NodeValue`](#nodevalue)\]

Defined in: [packages/core/src/agent/certificate.ts:63](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L63)

***

### LookupResult

> **LookupResult** = [`LookupPathResultAbsent`](#lookuppathresultabsent) \| [`LookupPathResultUnknown`](#lookuppathresultunknown) \| [`LookupPathResultFound`](#lookuppathresultfound) \| [`LookupPathResultError`](#lookuppathresulterror)

Defined in: [packages/core/src/agent/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L532)

***

### NodeHash

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L58)

#### Type Declaration

##### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`

***

### NodeLabel

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L56)

#### Type Declaration

##### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`

***

### NodePath

> **NodePath** = (`Uint8Array` \| `string`)[]

Defined in: [packages/core/src/agent/certificate.ts:55](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L55)

***

### NodeValue

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:57](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L57)

#### Type Declaration

##### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`

***

### Nonce

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/agent/http/types.ts:125](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L125)

#### Type Declaration

##### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`

***

### ObserveFunction

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/core/src/agent/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/observable.ts#L3)

#### Type Parameters

##### T

`T`

#### Parameters

##### data

`T`

##### rest

...`unknown`[]

#### Returns

`void`

***

### PollStrategy

> **PollStrategy** = (`effectiveTarget`, `requestId`, `status`) => `Promise`\<`void`\>

Defined in: [packages/core/src/agent/polling/types.ts:5](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/types.ts#L5)

#### Parameters

##### effectiveTarget

[`TargetPrincipal`](#targetprincipal)

##### requestId

[`RequestId`](#requestid-9)

##### status

[`RequestStatusResponseStatus`](#requeststatusresponsestatus)

#### Returns

`Promise`\<`void`\>

***

### PrunedHashTree

> **PrunedHashTree** = \[[`Pruned`](#pruned), [`NodeHash`](#nodehash)\]

Defined in: [packages/core/src/agent/certificate.ts:64](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L64)

***

### QueryResponse

> **QueryResponse** = [`QueryResponseReplied`](#queryresponsereplied) \| [`QueryResponseRejected`](#queryresponserejected)

Defined in: [packages/core/src/agent/agent/api.ts:33](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L33)

***

### QueryStrategy

> **QueryStrategy** = `"query"` \| `"update"`

Defined in: [packages/core/src/agent/actor.ts:25](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L25)

Controls how query and composite_query methods are executed.

- `'query'` — standard non-replicated query call (default).
- `'update'` — send query methods as update calls that go through consensus.

***

### ReadRequest

> **ReadRequest** = [`QueryRequest`](#queryrequest) \| [`ReadStateRequest`](#readstaterequest)

Defined in: [packages/core/src/agent/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L103)

***

### RequestId

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/request_id.ts#L8)

#### Type Declaration

##### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`

***

### Signature

> **Signature** = [`Uint8ArrayBuffer`](../../candid/api/index.md#uint8arraybuffer) & `object`

Defined in: [packages/core/src/agent/auth.ts:23](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L23)

A signature array buffer.

#### Type Declaration

##### \_\_signature\_\_

> **\_\_signature\_\_**: `void`

***

### SubtreeLookupResult

> **SubtreeLookupResult** = [`LookupSubtreeResultAbsent`](#lookupsubtreeresultabsent) \| [`LookupSubtreeResultUnknown`](#lookupsubtreeresultunknown) \| [`LookupSubtreeResultFound`](#lookupsubtreeresultfound)

Defined in: [packages/core/src/agent/certificate.ts:557](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L557)

***

### TargetPrincipal

> **TargetPrincipal** = \{ `canisterId`: [`Principal`](../../principal/api.md#principal); \} \| \{ `subnetId`: [`Principal`](../../principal/api.md#principal); \}

Defined in: [packages/core/src/agent/certificate.ts:155](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L155)

#### Union Members

##### Type Literal

\{ `canisterId`: [`Principal`](../../principal/api.md#principal); \}

###### canisterId

> **canisterId**: [`Principal`](../../principal/api.md#principal)

The effective canister ID of the request when verifying a response, or
the signing canister ID when verifying a certified variable.

***

##### Type Literal

\{ `subnetId`: [`Principal`](../../principal/api.md#principal); \}

###### subnetId

> **subnetId**: [`Principal`](../../principal/api.md#principal)

The effective subnet ID of the request when verifying a response, or
the subnet ID when verifying a certificate from a subnet.

## Variables

### ACTOR\_METHOD\_WITH\_CERTIFICATE

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/core/src/agent/actor.ts:386](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L386)

***

### ACTOR\_METHOD\_WITH\_HTTP\_DETAILS

> `const` **ACTOR\_METHOD\_WITH\_HTTP\_DETAILS**: `"http-details"` = `'http-details'`

Defined in: [packages/core/src/agent/actor.ts:385](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/actor.ts#L385)

***

### BLS12\_381\_G2\_OID

> `const` **BLS12\_381\_G2\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:117](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L117)

***

### Cbor

> `const` **Cbor**: `object`

Defined in: [packages/core/src/agent/cbor.ts:64](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/cbor.ts#L64)

#### Type Declaration

##### decode

> **decode**: \<`T`\>(`input`) => `T`

Decode a CBOR encoded value into a JavaScript value.

###### Type Parameters

###### T

`T`

###### Parameters

###### input

`Uint8Array`

The CBOR encoded value

###### Returns

`T`

##### encode

> **encode**: (`value`) => `Uint8Array`

Encode a JavaScript value into CBOR. If the value is an instance of [ToCborValue](#abstract-tocborvalue),
the [ToCborValue.toCborValue](#tocborvalue) method will be called to get the value to encode.

###### Parameters

###### value

`unknown`

The value to encode

###### Returns

`Uint8Array`

***

### DEFAULT\_POLLING\_OPTIONS

> `const` **DEFAULT\_POLLING\_OPTIONS**: [`PollingOptions`](#pollingoptions-2)

Defined in: [packages/core/src/agent/polling/index.ts:66](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L66)

***

### DER\_COSE\_OID

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:91](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L91)

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE

***

### ED25519\_OID

> `const` **ED25519\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:100](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L100)

A DER encoded `SEQUENCE(OID)` for the Ed25519 algorithm

***

### IC\_REQUEST\_AUTH\_DELEGATION\_DOMAIN\_SEPARATOR

> `const` **IC\_REQUEST\_AUTH\_DELEGATION\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:22](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/constants.ts#L22)

The `\x1Aic-request-auth-delegation` domain separator used in the signature of delegations.

***

### IC\_REQUEST\_DOMAIN\_SEPARATOR

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/constants.ts#L12)

The `\x0Aic-request` domain separator used in the signature of IC requests.

***

### IC\_RESPONSE\_DOMAIN\_SEPARATOR

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:17](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/constants.ts#L17)

The `\x0Bic-response` domain separator used in the signature of IC responses.

***

### IC\_ROOT\_KEY

> `const` **IC\_ROOT\_KEY**: `string`

Defined in: [packages/core/src/agent/agent/http/index.ts:112](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L112)

***

### IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR

> `const` **IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/constants.ts#L7)

The `\x0Dic-state-root` domain separator used in the root hash of IC certificates.

***

### JSON\_KEY\_EXPIRY

> `const` **JSON\_KEY\_EXPIRY**: `"__expiry__"` = `'__expiry__'`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:4](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/expiry.ts#L4)

***

### MANAGEMENT\_CANISTER\_ID

> `const` **MANAGEMENT\_CANISTER\_ID**: `"aaaaa-aa"` = `'aaaaa-aa'`

Defined in: [packages/core/src/agent/agent/http/index.ts:118](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L118)

***

### SECP256K1\_OID

> `const` **SECP256K1\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:109](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L109)

A DER encoded `SEQUENCE(OID)` for secp256k1 with the ECDSA algorithm

***

### UNREACHABLE\_ERROR

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/core/src/agent/errors.ts:984](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/errors.ts#L984)

Special error used to indicate that a code path is unreachable.

For internal use only.

***

### verify

> **verify**: (`pk`, `sig`, `msg`) => `boolean`

Defined in: [packages/core/src/agent/utils/bls.ts:4](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/bls.ts#L4)

#### Parameters

##### pk

`Uint8Array`

##### sig

`Uint8Array`

##### msg

`Uint8Array`

#### Returns

`boolean`

## Functions

### blsVerify()

> **blsVerify**(`pk`, `sig`, `msg`): `boolean`

Defined in: [packages/core/src/agent/utils/bls.ts:13](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/bls.ts#L13)

#### Parameters

##### pk

`Uint8Array`

primary key: Uint8Array

##### sig

`Uint8Array`

signature: Uint8Array

##### msg

`Uint8Array`

message: Uint8Array

#### Returns

`boolean`

boolean

***

### calculateIngressExpiry()

> **calculateIngressExpiry**(`maxIngressExpiryInMinutes`, `timeDiffMsecs`): [`Expiry`](#expiry)

Defined in: [packages/core/src/agent/agent/http/index.ts:1723](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/index.ts#L1723)

Calculates the ingress expiry time based on the maximum allowed expiry in minutes and the time difference in milliseconds.
The expiry is rounded down according to the [Expiry.fromDeltaInMilliseconds](#fromdeltainmilliseconds) method.

#### Parameters

##### maxIngressExpiryInMinutes

`number`

The maximum ingress expiry time in minutes.

##### timeDiffMsecs

`number`

The time difference in milliseconds to adjust the expiry.

#### Returns

[`Expiry`](#expiry)

The calculated ingress expiry as an Expiry object.

***

### check\_canister\_ranges()

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/core/src/agent/certificate.ts:887](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L887)

Check if a canister ID falls within the canister ranges of a given subnet

#### Parameters

##### params

[`CheckCanisterRangesParams`](#checkcanisterrangesparams)

the parameters with which to check the canister ranges

#### Returns

`boolean`

`true` if the canister is in the range, `false` otherwise

***

### constructRequest()

> **constructRequest**(`options`): `Promise`\<[`ReadStateRequest`](#readstaterequest)\>

Defined in: [packages/core/src/agent/polling/index.ts:225](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L225)

Constructs a read state request for the given paths.
If the request is already signed and has an expiry, it will be returned as is.
Otherwise, a new request will be created.

#### Parameters

##### options

The options to use for creating the request.

###### agent

[`Agent`](#agent-1)

The agent to use to create the request.

###### paths

`Uint8Array`\<`ArrayBufferLike`\>[][]

The paths to read from.

###### pollingOptions

[`PollingOptions`](#pollingoptions-2)

The options to use for creating the request.

#### Returns

`Promise`\<[`ReadStateRequest`](#readstaterequest)\>

The read state request.

***

### createIdentityDescriptor()

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](#identitydescriptor)

Defined in: [packages/core/src/agent/auth.ts:140](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L140)

Create an IdentityDescriptor from an Identity

#### Parameters

##### identity

[`SignIdentity`](#abstract-signidentity) \| [`AnonymousIdentity`](#anonymousidentity)

identity describe in returned descriptor

#### Returns

[`IdentityDescriptor`](#identitydescriptor)

***

### decodeCanisterRanges()

> **decodeCanisterRanges**(`lookupValue`): [`CanisterRanges`](#canisterranges)

Defined in: [packages/core/src/agent/certificate.ts:964](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L964)

Decode canister ranges from CBOR-encoded buffer

#### Parameters

##### lookupValue

`Uint8Array`

the CBOR-encoded value read from the certificate

#### Returns

[`CanisterRanges`](#canisterranges)

an array of canister range tuples [start, end]

***

### decodeLen()

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:71](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L71)

#### Parameters

##### buf

`Uint8Array`

##### offset

`number`

#### Returns

`number`

***

### decodeLenBytes()

> **decodeLenBytes**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:52](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L52)

#### Parameters

##### buf

`Uint8Array`

##### offset

`number`

#### Returns

`number`

***

### domain\_sep()

> **domain\_sep**(`s`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:498](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L498)

Creates a domain separator for hashing by encoding the input string
with its length as a prefix.

#### Parameters

##### s

`string`

The input string to encode.

#### Returns

`Uint8Array`

A Uint8Array containing the encoded domain separator.

***

### encodeLen()

> **encodeLen**(`buf`, `offset`, `len`): `number`

Defined in: [packages/core/src/agent/der.ts:26](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L26)

#### Parameters

##### buf

`Uint8Array`

##### offset

`number`

##### len

`number`

#### Returns

`number`

***

### encodeLenBytes()

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/core/src/agent/der.ts:10](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L10)

#### Parameters

##### len

`number`

#### Returns

`number`

***

### fetchCandid()

> **fetchCandid**(`canisterId`, `agent?`): `Promise`\<`string`\>

Defined in: [packages/core/src/agent/fetch\_candid.ts:13](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/fetch_candid.ts#L13)

Retrieves the Candid interface for the specified canister.

#### Parameters

##### canisterId

`string`

A string corresponding to the canister ID

##### agent?

[`HttpAgent`](#httpagent)

The agent to use for the request (usually an `HttpAgent`)

#### Returns

`Promise`\<`string`\>

Candid source code

***

### find\_label()

> **find\_label**(`label`, `tree`): [`LabelLookupResult`](#labellookupresult)

Defined in: [packages/core/src/agent/certificate.ts:741](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L741)

Find a label in a tree

#### Parameters

##### label

[`NodeLabel`](#nodelabel)

the label to find

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

[`LabelLookupResult`](#labellookupresult)

the result of the label lookup

***

### flatten\_forks()

> **flatten\_forks**(`t`): ([`LabeledHashTree`](#labeledhashtree) \| [`LeafHashTree`](#leafhashtree) \| [`PrunedHashTree`](#prunedhashtree))[]

Defined in: [packages/core/src/agent/certificate.ts:724](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L724)

If the tree is a fork, flatten it into an array of trees

#### Parameters

##### t

[`HashTree`](#hashtree)

the tree to flatten

#### Returns

([`LabeledHashTree`](#labeledhashtree) \| [`LeafHashTree`](#leafhashtree) \| [`PrunedHashTree`](#prunedhashtree))[]

the flattened tree

***

### getSubnetIdFromCertificate()

> **getSubnetIdFromCertificate**(`certificate`, `rootKey`): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/certificate.ts:1043](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L1043)

Get the subnet ID from a certificate
If the certificate has a delegation, it returns the subnet ID from the delegation.
If the certificate has no delegation, it returns the root subnet ID.

#### Parameters

##### certificate

[`Cert`](#cert-1)

the certificate to get the subnet ID from

##### rootKey

`Uint8Array`

the root key to use to get the subnet ID

#### Returns

[`Principal`](../../principal/api.md#principal)

the subnet ID

***

### hashOfMap()

> **hashOfMap**(`map`): `Uint8Array`

Defined in: [packages/core/src/agent/request\_id.ts:80](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/request_id.ts#L80)

Hash a map into a Uint8Array using the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

#### Parameters

##### map

`Record`\<`string`, `unknown`\>

Any non-nested object

#### Returns

`Uint8Array`

Uint8Array

***

### hashTreeToString()

> **hashTreeToString**(`tree`): `string`

Defined in: [packages/core/src/agent/certificate.ts:77](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L77)

Make a human readable string out of a hash tree.

#### Parameters

##### tree

[`HashTree`](#hashtree)

The hash tree to convert to a string

#### Returns

`string`

***

### hashValue()

> **hashValue**(`value`): `Uint8Array`

Defined in: [packages/core/src/agent/request\_id.ts:19](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/request_id.ts#L19)

#### Parameters

##### value

`unknown`

unknown value

#### Returns

`Uint8Array`

Uint8Array

***

### httpHeadersTransform()

> **httpHeadersTransform**(`headers`): [`HttpHeaderField`](#httpheaderfield)[]

Defined in: [packages/core/src/agent/agent/http/transforms.ts:48](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/transforms.ts#L48)

Maps the default fetch headers field to the serializable HttpHeaderField.

#### Parameters

##### headers

`Headers`

Fetch definition of the headers type

#### Returns

[`HttpHeaderField`](#httpheaderfield)[]

array of header fields

***

### isV2ResponseBody()

> **isV2ResponseBody**(`body`): `body is v2ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:169](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L169)

Utility function to check if a body is a v2ResponseBody for type safety.

#### Parameters

##### body

[`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

The body to check

#### Returns

`body is v2ResponseBody`

boolean indicating if the body is a v2ResponseBody

***

### isV4ResponseBody()

> **isV4ResponseBody**(`body`): `body is v4ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:184](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/api.ts#L184)

Utility function to check if a body is a v4ResponseBody for type safety.

#### Parameters

##### body

[`v2ResponseBody`](#v2responsebody) \| [`v4ResponseBody`](#v4responsebody) \| `null`

The body to check

#### Returns

`body is v4ResponseBody`

boolean indicating if the body is a v4ResponseBody

***

### lookup\_path()

> **lookup\_path**(`path`, `tree`): [`LookupResult`](#lookupresult)

Defined in: [packages/core/src/agent/certificate.ts:604](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L604)

Lookup a path in a tree. If the path is a subtree, use [lookup\_subtree](#lookup_subtree-1) instead.

#### Parameters

##### path

[`NodePath`](#nodepath)

the path to look up

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

[`LookupResult`](#lookupresult)

the result of the lookup

***

### lookup\_subtree()

> **lookup\_subtree**(`path`, `tree`): [`SubtreeLookupResult`](#subtreelookupresult)

Defined in: [packages/core/src/agent/certificate.ts:683](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L683)

Lookup a subtree in a tree.

#### Parameters

##### path

[`NodePath`](#nodepath)

the path to look up

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

[`SubtreeLookupResult`](#subtreelookupresult)

the result of the lookup

***

### lookupCanisterRanges()

> **lookupCanisterRanges**(`params`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:910](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L910)

Lookup the canister ranges using the `/canister_ranges/<subnet_id>/<ranges>` path.
Certificates returned by `/api/v4/canister/<effective_canister_id>/call`
and `/api/v3/canister/<effective_canister_id>/read_state` use this path.

If the new lookup is not found, it tries the fallback lookup with [lookupCanisterRangesFallback](#lookupcanisterrangesfallback).

#### Parameters

##### params

[`CheckCanisterRangesParams`](#checkcanisterrangesparams)

the parameters with which to lookup the canister ranges

#### Returns

`Uint8Array`

the encoded canister ranges. Use [decodeCanisterRanges](#decodecanisterranges) to decode them.

#### See

 - https://internetcomputer.org/docs/references/ic-interface-spec#http-read-state
 - https://internetcomputer.org/docs/references/ic-interface-spec#state-tree-canister-ranges

***

### lookupCanisterRangesFallback()

> **lookupCanisterRangesFallback**(`subnetId`, `tree`): `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:946](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L946)

Lookup the canister ranges using the `/subnet/<subnet_id>/canister_ranges` path.
Certificates returned by `/api/v3/canister/<effective_canister_id>/call`
and `/api/v2/canister/<effective_canister_id>/read_state` use this path.

#### Parameters

##### subnetId

[`Principal`](../../principal/api.md#principal)

the subnet ID to lookup the canister ranges for

##### tree

[`HashTree`](#hashtree)

the tree to search

#### Returns

`Uint8Array`

the encoded canister ranges. Use [decodeCanisterRanges](#decodecanisterranges) to decode them.

#### See

https://internetcomputer.org/docs/references/ic-interface-spec#http-read-state

***

### lookupResultToBuffer()

> **lookupResultToBuffer**(`result`): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/agent/certificate.ts:454](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L454)

Utility function to constrain the type of a lookup result

#### Parameters

##### result

[`LookupResult`](#lookupresult)

the result of a lookup

#### Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

the value if the lookup was found, `undefined` otherwise

***

### makeExpiryTransform()

> **makeExpiryTransform**(`delayInMilliseconds`): [`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

Defined in: [packages/core/src/agent/agent/http/transforms.ts:37](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/transforms.ts#L37)

Create a transform that adds a delay (by default 5 minutes) to the expiry.

#### Parameters

##### delayInMilliseconds

`number`

The delay to add to the call time, in milliseconds.

#### Returns

[`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

***

### makeNonce()

> **makeNonce**(): [`Nonce`](#nonce-5)

Defined in: [packages/core/src/agent/agent/http/types.ts:130](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/types.ts#L130)

Create a random Nonce, based on random values

#### Returns

[`Nonce`](#nonce-5)

***

### makeNonceTransform()

> **makeNonceTransform**(`nonceFn?`): [`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

Defined in: [packages/core/src/agent/agent/http/transforms.ts:18](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/agent/http/transforms.ts#L18)

Create a Nonce transform, which takes a function that returns a Buffer, and adds it
as the nonce to every call requests.

#### Parameters

##### nonceFn?

() => [`Nonce`](#nonce-5)

A function that returns a buffer. By default uses a semi-random method.

#### Returns

[`HttpAgentRequestTransformFn`](#httpagentrequesttransformfn)

***

### pollForResponse()

> **pollForResponse**(`agent`, `effectiveTarget`, `requestId`, `options?`): `Promise`\<[`PollForResponseResult`](#pollforresponseresult)\>

Defined in: [packages/core/src/agent/polling/index.ts:127](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/polling/index.ts#L127)

Polls the IC to check the status of the given request then
returns the response bytes once the request has been processed.

#### Parameters

##### agent

[`Agent`](#agent-1)

The agent to use to poll read_state.

##### effectiveTarget

[`InputTargetPrincipal`](#inputtargetprincipal)

The effective canister or subnet ID.

##### requestId

[`RequestId`](#requestid-9)

The Request ID to poll status for.

##### options?

[`PollingOptions`](#pollingoptions-2) = `{}`

polling options to control behavior

#### Returns

`Promise`\<[`PollForResponseResult`](#pollforresponseresult)\>

The certificate, reply bytes, and raw certificate bytes for the request.

#### Throws

If the agent's root key is not available.

#### Throws

If the request was rejected by the canister.

#### Throws

If the request reached `done` status without a reply.

***

### randomNumber()

> **randomNumber**(): `number`

Defined in: [packages/core/src/agent/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff

#### Returns

`number`

a random number

***

### reconstruct()

> **reconstruct**(`t`): `Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

Defined in: [packages/core/src/agent/certificate.ts:469](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/certificate.ts#L469)

#### Parameters

##### t

[`HashTree`](#hashtree)

The hash tree to reconstruct

#### Returns

`Promise`\<`Uint8Array`\<`ArrayBufferLike`\>\>

***

### requestIdOf()

> **requestIdOf**(`request`): [`RequestId`](#requestid-9)

Defined in: [packages/core/src/agent/request\_id.ts:70](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/request_id.ts#L70)

Get the RequestId of the provided ic-ref request.
RequestId is the result of the representation-independent-hash function.
https://sdk.dfinity.org/docs/interface-spec/index.html#hash-of-map

#### Parameters

##### request

`Record`\<`string`, `unknown`\>

ic-ref request to hash into RequestId

#### Returns

[`RequestId`](#requestid-9)

***

### uint8Equals()

> **uint8Equals**(`a`, `b`): `boolean`

Defined in: [packages/core/src/agent/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/buffer.ts#L54)

Compares two Uint8Arrays for equality.

#### Parameters

##### a

`Uint8Array`

The first Uint8Array.

##### b

`Uint8Array`

The second Uint8Array.

#### Returns

`boolean`

True if the Uint8Arrays are equal, false otherwise.

***

### uint8FromBufLike()

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/agent/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.

#### Parameters

##### bufLike

`ArrayBufferLike` \| `Uint8Array`\<`ArrayBufferLike`\> \| `number`[] \| `DataView`\<`ArrayBufferLike`\> \| `ArrayBufferView`\<`ArrayBufferLike`\> \| \[`number`\] \| \{ `buffer`: `ArrayBuffer`; \}

a buffer-like object

#### Returns

`Uint8Array`

Uint8Array

***

### uint8ToBuf()

> **uint8ToBuf**(`arr`): `ArrayBuffer`

Defined in: [packages/core/src/agent/utils/buffer.ts:41](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/utils/buffer.ts#L41)

Returns a true ArrayBuffer from a Uint8Array, as Uint8Array.buffer is unsafe.

#### Parameters

##### arr

`Uint8Array`

Uint8Array to convert

#### Returns

`ArrayBuffer`

ArrayBuffer

***

### unwrapDER()

> **unwrapDER**(`derEncoded`, `oid`): `Uint8Array`

Defined in: [packages/core/src/agent/der.ts:166](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L166)

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`

#### Parameters

##### derEncoded

`Uint8Array`

The DER encoded and tagged data

##### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

#### Returns

`Uint8Array`

The unwrapped payload

***

### wrapDER()

> **wrapDER**(`payload`, `oid`): `Uint8Array`

Defined in: [packages/core/src/agent/der.ts:133](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/der.ts#L133)

Wraps the given `payload` in a DER encoding tagged with the given encoded `oid` like so:
`SEQUENCE(oid, BITSTRING(payload))`

#### Parameters

##### payload

`Uint8Array`

The payload to encode as the bit string

##### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) OID to tag the payload with

#### Returns

`Uint8Array`

## References

### defaultStrategy

Re-exports [defaultStrategy](namespaces/strategy.md#defaultstrategy)
