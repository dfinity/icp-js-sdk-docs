---
title: Overview
editUrl: false
next: true
prev: true
---

The `@icp-sdk/core/identity/secp256k1` module provides an implementation of the [`SignIdentity`](https://js.icp.build/core/latest/libs/agent/api/classes/signidentity/) interface for the secp256k1 elliptic curve. It allows you to create and manage key pairs for signing and verification of messages.

## Usage

Here's an example of how to use the `Secp256k1KeyIdentity` class to generate a new key pair and sign and verify a message:

```ts
import { Secp256k1KeyIdentity } from '@icp-sdk/core/identity/secp256k1';

// Generate a new key pair
const identity = Secp256k1KeyIdentity.generate();

// Sign a message
const message = 'Hello, world!';
const signature = identity.sign(message);

// Verify the signature
const isValid = identity.verify(message, signature);

console.log(`Signature is ${isValid ? 'valid' : 'invalid'}`);
```

You can also use a seed to generate deterministic key pairs:

```ts
import { Secp256k1KeyIdentity } from '@icp-sdk/core/identity/secp256k1';

const seed = Buffer.from('my-secret-seed', 'utf8');
const identity = Secp256k1KeyIdentity.generate(seed);
```

The Secp256k1KeyIdentity class also provides methods for converting the key pair to and from JSON-serializable objects:

```ts
import { Secp256k1KeyIdentity } from '@icp-sdk/core/identity/secp256k1';

// Generate a new key pair
const identity = Secp256k1KeyIdentity.generate();

// Convert the key pair to a JSON-serializable object
const json = identity.toJson();

// Convert the JSON-serializable object back to a key pair
const restoredIdentity = Secp256k1KeyIdentity.fromJson(json);
```

<!-- split here -->

## Classes

### Secp256k1KeyIdentity

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:107](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L107)

An Identity that can sign blobs.

#### Extends

- [`SignIdentity`](../../agent/api/index.md#abstract-signidentity)

#### Constructors

##### Constructor

> `protected` **new Secp256k1KeyIdentity**(`publicKey`, `privateKey`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:229](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L229)

###### Parameters

###### publicKey

[`Secp256k1PublicKey`](#secp256k1publickey)

###### privateKey

`Uint8Array`

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

###### Overrides

[`SignIdentity`](../../agent/api/index.md#abstract-signidentity).[`constructor`](../../agent/api/index.md#constructor-53)

#### Properties

##### \_principal

> `protected` **\_principal**: [`Principal`](../../principal/api.md#principal) \| `undefined`

Defined in: [packages/core/src/agent/auth.ts:59](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L59)

###### Inherited from

[`SignIdentity`](../../agent/api/index.md#abstract-signidentity).[`_principal`](../../agent/api/index.md#_principal)

##### \_privateKey

> **\_privateKey**: `Uint8Array`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:227](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L227)

##### \_publicKey

> **\_publicKey**: [`Secp256k1PublicKey`](#secp256k1publickey)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:226](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L226)

#### Methods

##### getKeyPair()

> **getKeyPair**(): [`KeyPair`](../../agent/api/index.md#keypair)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:247](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L247)

Return a copy of the key pair.

###### Returns

[`KeyPair`](../../agent/api/index.md#keypair)

KeyPair

##### getPrincipal()

> **getPrincipal**(): [`Principal`](../../principal/api.md#principal)

Defined in: [packages/core/src/agent/auth.ts:75](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L75)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

###### Returns

[`Principal`](../../principal/api.md#principal)

###### Inherited from

[`SignIdentity`](../../agent/api/index.md#abstract-signidentity).[`getPrincipal`](../../agent/api/index.md#getprincipal-2)

##### getPublicKey()

> **getPublicKey**(): `Required`\<[`PublicKey`](../../agent/api/index.md#publickey-1)\>

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:258](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L258)

Return the public key.

###### Returns

`Required`\<[`PublicKey`](../../agent/api/index.md#publickey-1)\>

Required<PublicKey>

###### Overrides

[`SignIdentity`](../../agent/api/index.md#abstract-signidentity).[`getPublicKey`](../../agent/api/index.md#getpublickey)

##### sign()

> **sign**(`data`): `Promise`\<[`Signature`](../../agent/api/index.md#signature-2)\>

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:267](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L267)

Signs a blob of data, with this identity's private key.

###### Parameters

###### data

`Uint8Array`

bytes to hash and sign with this identity's secretKey, producing a signature

###### Returns

`Promise`\<[`Signature`](../../agent/api/index.md#signature-2)\>

signature

###### Overrides

[`SignIdentity`](../../agent/api/index.md#abstract-signidentity).[`sign`](../../agent/api/index.md#sign)

##### toJSON()

> **toJSON**(): [`JsonableSecp256k1Identity`](#jsonablesecp256k1identity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:239](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L239)

Serialize this key to JSON-serializable object.

###### Returns

[`JsonableSecp256k1Identity`](#jsonablesecp256k1identity)

JsonableSecp256k1Identity

##### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:88](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/agent/auth.ts#L88)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

###### Parameters

###### request

[`HttpAgentRequest`](../../agent/api/index.md#httpagentrequest)

internet computer request to transform

###### Returns

`Promise`\<`unknown`\>

###### Inherited from

[`SignIdentity`](../../agent/api/index.md#abstract-signidentity).[`transformRequest`](../../agent/api/index.md#transformrequest-1)

##### fromJSON()

> `static` **fromJSON**(`json`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:150](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L150)

###### Parameters

###### json

`string`

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

##### fromKeyPair()

> `static` **fromKeyPair**(`publicKey`, `privateKey`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:167](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L167)

generates an identity from a public and private key. Please ensure that you are generating these keys securely and protect the user's private key

###### Parameters

###### publicKey

`Uint8Array`

Uint8Array

###### privateKey

`Uint8Array`

Uint8Array

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Secp256k1KeyIdentity

##### fromParsedJson()

> `static` **fromParsedJson**(`obj`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:142](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L142)

###### Parameters

###### obj

[`JsonableSecp256k1Identity`](#jsonablesecp256k1identity)

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

##### fromPem()

> `static` **fromPem**(`pemKey`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:221](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L221)

Utility method to create a Secp256k1KeyIdentity from a PEM-encoded key.

###### Parameters

###### pemKey

`string`

PEM-encoded key as a string

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

- Secp256k1KeyIdentity

##### fromSecretKey()

> `static` **fromSecretKey**(`secretKey`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:176](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L176)

generates an identity from an existing secret key, and is the correct method to generate an identity from a seed phrase. Please ensure you protect the user's private key.

###### Parameters

###### secretKey

`Uint8Array`

Uint8Array

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

- Secp256k1KeyIdentity

##### fromSeedPhrase()

> `static` **fromSeedPhrase**(`seedPhrase`, `password?`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:188](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L188)

Generates an identity from a seed phrase. Use carefully - seed phrases should only be used in secure contexts, and you should avoid having users copying and pasting seed phrases as much as possible.

###### Parameters

###### seedPhrase

`string` \| `string`[]

either an array of words or a string of words separated by spaces.

###### password?

`string`

optional password to be used by bip39

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Secp256k1KeyIdentity

##### generate()

> `static` **generate**(`seed?`): [`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:116](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L116)

Generates an identity. If a seed is provided, the keys are generated from the
seed according to BIP 0032. Otherwise, the key pair is randomly generated.
This method throws an error in case the seed is not 32 bytes long or invalid
for use as a private key.

###### Parameters

###### seed?

`Uint8Array`\<`ArrayBufferLike`\>

the optional seed

###### Returns

[`Secp256k1KeyIdentity`](#secp256k1keyidentity)

Secp256k1KeyIdentity

***

### Secp256k1PublicKey

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:26](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L26)

A Public Key implementation.

#### Implements

- [`PublicKey`](../../agent/api/index.md#publickey-1)

#### Accessors

##### derKey

###### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../../agent/api/index.md#derencodedpublickey)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:88](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L88)

###### Returns

[`DerEncodedPublicKey`](../../agent/api/index.md#derencodedpublickey)

###### Implementation of

[`PublicKey`](../../agent/api/index.md#publickey-1).[`derKey`](../../agent/api/index.md#derkey-1)

##### rawKey

###### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:82](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L82)

###### Returns

`Uint8Array`

###### Implementation of

[`PublicKey`](../../agent/api/index.md#publickey-1).[`rawKey`](../../agent/api/index.md#rawkey-1)

#### Methods

##### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../../agent/api/index.md#derencodedpublickey)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:98](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L98)

###### Returns

[`DerEncodedPublicKey`](../../agent/api/index.md#derencodedpublickey)

###### Implementation of

[`PublicKey`](../../agent/api/index.md#publickey-1).[`toDer`](../../agent/api/index.md#toder-1)

##### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:102](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L102)

###### Returns

`Uint8Array`

###### Implementation of

[`PublicKey`](../../agent/api/index.md#publickey-1).[`toRaw`](../../agent/api/index.md#toraw-1)

##### from()

> `static` **from**(`maybeKey`): [`Secp256k1PublicKey`](#secp256k1publickey)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:40](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L40)

Construct Secp256k1PublicKey from an existing PublicKey

###### Parameters

###### maybeKey

`unknown`

existing PublicKey, ArrayBuffer, DerEncodedPublicKey, or hex string

###### Returns

[`Secp256k1PublicKey`](#secp256k1publickey)

Instance of Secp256k1PublicKey

##### fromDer()

> `static` **fromDer**(`derKey`): [`Secp256k1PublicKey`](#secp256k1publickey)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:31](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L31)

###### Parameters

###### derKey

[`DerEncodedPublicKey`](../../agent/api/index.md#derencodedpublickey)

###### Returns

[`Secp256k1PublicKey`](#secp256k1publickey)

##### fromRaw()

> `static` **fromRaw**(`rawKey`): [`Secp256k1PublicKey`](#secp256k1publickey)

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:27](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L27)

###### Parameters

###### rawKey

`Uint8Array`

###### Returns

[`Secp256k1PublicKey`](#secp256k1publickey)

## Type Aliases

### JsonableSecp256k1Identity

> **JsonableSecp256k1Identity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:18](https://github.com/dfinity/icp-js-core/blob/eac56b8c6132a07059ae168dd5b6acb759fd15e8/packages/core/src/identity/secp256k1/secp256k1.ts#L18)
