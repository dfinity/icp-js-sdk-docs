---
title: GenericIdlFuncArgs
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncArgs** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1772](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/idl.ts#L1772)

The generic type of the arguments of an [IDL Function](../functions/Func.md).
