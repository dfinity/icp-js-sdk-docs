---
title: GenericIdlFuncArgs
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncArgs** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1772](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/idl.ts#L1772)

The generic type of the arguments of an [IDL Function](../functions/Func.md).
