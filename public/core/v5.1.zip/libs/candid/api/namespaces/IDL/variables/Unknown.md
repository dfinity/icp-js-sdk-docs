---
title: Unknown
editUrl: false
next: true
prev: true
---

> `const` **Unknown**: [`UnknownClass`](../classes/UnknownClass.md)

Defined in: [packages/core/src/candid/idl.ts:2351](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/idl.ts#L2351)

Client-only type for deserializing unknown data. Not supported by Candid, and its use is discouraged.
