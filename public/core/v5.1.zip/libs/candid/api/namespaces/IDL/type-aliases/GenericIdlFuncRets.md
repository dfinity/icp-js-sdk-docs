---
title: GenericIdlFuncRets
editUrl: false
next: true
prev: true
---

> **GenericIdlFuncRets** = \[[`Type`](../classes/Type.md), `...Type[]`\] \| \[\]

Defined in: [packages/core/src/candid/idl.ts:1777](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/idl.ts#L1777)

The generic type of the return values of an [IDL Function](../functions/Func.md).
