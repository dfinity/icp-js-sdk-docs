---
title: Int32
editUrl: false
next: true
prev: true
---

> `const` **Int32**: [`FixedIntClass`](../classes/FixedIntClass.md)

Defined in: [packages/core/src/candid/idl.ts:2363](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/idl.ts#L2363)
