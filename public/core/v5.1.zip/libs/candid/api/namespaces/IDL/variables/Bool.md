---
title: Bool
editUrl: false
next: true
prev: true
---

> `const` **Bool**: [`BoolClass`](../classes/BoolClass.md)

Defined in: [packages/core/src/candid/idl.ts:2352](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/idl.ts#L2352)
