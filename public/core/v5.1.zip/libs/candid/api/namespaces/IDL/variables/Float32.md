---
title: Float32
editUrl: false
next: true
prev: true
---

> `const` **Float32**: [`FloatClass`](../classes/FloatClass.md)

Defined in: [packages/core/src/candid/idl.ts:2358](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/idl.ts#L2358)
