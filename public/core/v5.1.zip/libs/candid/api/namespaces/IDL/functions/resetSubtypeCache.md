---
title: resetSubtypeCache
editUrl: false
next: true
prev: true
---

> **resetSubtypeCache**(): `void`

Defined in: [packages/core/src/candid/idl.ts:2508](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/idl.ts#L2508)

Resets the global subtyping cache

## Returns

`void`
