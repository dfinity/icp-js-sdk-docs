---
title: resetSubtypeCache
editUrl: false
next: true
prev: true
---

> **resetSubtypeCache**(): `void`

Defined in: [packages/core/src/candid/idl.ts:2508](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/idl.ts#L2508)

Resets the global subtyping cache

## Returns

`void`
