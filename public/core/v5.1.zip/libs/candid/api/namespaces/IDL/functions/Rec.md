---
title: Rec
editUrl: false
next: true
prev: true
---

> **Rec**(): [`RecClass`](../classes/RecClass.md)

Defined in: [packages/core/src/candid/idl.ts:2418](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/idl.ts#L2418)

## Returns

[`RecClass`](../classes/RecClass.md)

new RecClass
