---
title: lebEncode
editUrl: false
next: true
prev: true
---

> **lebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:44](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/utils/leb128.ts#L44)

Encode a positive number (or bigint) into a Buffer. The number will be floored to the
nearest integer.

## Parameters

### value

The number to encode.

`number` | `bigint`

## Returns

`Uint8Array`
