---
title: idlLabelToId
editUrl: false
next: true
prev: true
---

> **idlLabelToId**(`label`): `number`

Defined in: [packages/core/src/candid/utils/hash.ts:23](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/utils/hash.ts#L23)

## Parameters

### label

`string`

string

## Returns

`number`

number representing hashed label
