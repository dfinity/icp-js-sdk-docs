---
title: compare
editUrl: false
next: true
prev: true
---

> **compare**(`u1`, `u2`): `number`

Defined in: [packages/core/src/candid/utils/buffer.ts:189](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/utils/buffer.ts#L189)

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`number`

number - negative if u1 < u2, positive if u1 > u2, 0 if u1 === u2
