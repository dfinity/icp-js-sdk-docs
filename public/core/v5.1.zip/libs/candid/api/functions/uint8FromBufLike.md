---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/buffer.ts:153](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/utils/buffer.ts#L153)

Returns a true Uint8Array from an ArrayBufferLike object.

## Parameters

### bufLike

a buffer-like object

`ArrayBufferLike` | `Uint8Array`\<`ArrayBufferLike`\> | `number`[] | `DataView`\<`ArrayBufferLike`\> | `ArrayBufferView`\<`ArrayBufferLike`\> | \[`number`\] | \{ `buffer`: `ArrayBuffer`; \}

## Returns

`Uint8Array`

Uint8Array
