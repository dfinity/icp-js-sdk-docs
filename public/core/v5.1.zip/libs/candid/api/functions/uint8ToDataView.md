---
title: uint8ToDataView
editUrl: false
next: true
prev: true
---

> **uint8ToDataView**(`uint8`): `DataView`

Defined in: [packages/core/src/candid/utils/buffer.ts:216](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/utils/buffer.ts#L216)

Helpers to convert a Uint8Array to a DataView.

## Parameters

### uint8

`Uint8Array`

Uint8Array

## Returns

`DataView`

DataView
