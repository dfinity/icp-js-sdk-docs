---
title: readIntLE
editUrl: false
next: true
prev: true
---

> **readIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:223](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/utils/leb128.ts#L223)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
