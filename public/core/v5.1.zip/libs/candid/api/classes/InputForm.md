---
title: InputForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:99](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L99)

## Extended by

- [`RecordForm`](RecordForm.md)
- [`TupleForm`](TupleForm.md)
- [`VariantForm`](VariantForm.md)
- [`OptionForm`](OptionForm.md)
- [`VecForm`](VecForm.md)

## Constructors

### Constructor

> **new InputForm**(`ui`): `InputForm`

Defined in: [packages/core/src/candid/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L101)

#### Parameters

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`InputForm`

## Properties

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L100)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/core/src/candid/candid-core.ts:101](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L101)

## Methods

### generateForm()

> `abstract` **generateForm**(): `any`

Defined in: [packages/core/src/candid/candid-core.ts:104](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L104)

#### Returns

`any`

***

### parse()

> `abstract` **parse**(`config`): `any`

Defined in: [packages/core/src/candid/candid-core.ts:103](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L103)

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`any`

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L113)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L105)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`
