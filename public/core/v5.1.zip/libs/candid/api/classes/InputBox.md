---
title: InputBox
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:23](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L23)

## Constructors

### Constructor

> **new InputBox**(`idl`, `ui`): `InputBox`

Defined in: [packages/core/src/candid/candid-core.ts:28](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L28)

#### Parameters

##### idl

[`Type`](../namespaces/IDL/classes/Type.md)

##### ui

[`UIConfig`](../interfaces/UIConfig.md)

#### Returns

`InputBox`

## Properties

### idl

> **idl**: [`Type`](../namespaces/IDL/classes/Type.md)

Defined in: [packages/core/src/candid/candid-core.ts:29](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L29)

***

### label

> **label**: `string` \| `null` = `null`

Defined in: [packages/core/src/candid/candid-core.ts:25](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L25)

***

### status

> **status**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:24](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L24)

***

### ui

> **ui**: [`UIConfig`](../interfaces/UIConfig.md)

Defined in: [packages/core/src/candid/candid-core.ts:30](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L30)

***

### value

> **value**: `any` = `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:26](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L26)

## Methods

### isRejected()

> **isRejected**(): `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:49](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L49)

#### Returns

`boolean`

***

### parse()

> **parse**(`config?`): `any`

Defined in: [packages/core/src/candid/candid-core.ts:53](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L53)

#### Parameters

##### config?

[`ParseConfig`](../interfaces/ParseConfig.md) = `{}`

#### Returns

`any`

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:80](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/candid/candid-core.ts#L80)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`
