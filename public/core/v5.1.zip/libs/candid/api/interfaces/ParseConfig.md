---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:5](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L5)

## Properties

### random?

> `optional` **random**: `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/candid/candid-core.ts#L6)
