---
title: getCanisterEnv
editUrl: false
next: true
prev: true
---

> **getCanisterEnv**\<`T`\>(`options?`): [`CanisterEnv`](../interfaces/CanisterEnv.md) & `T`

Defined in: [packages/core/src/agent/canister-env/index.ts:111](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/canister-env/index.ts#L111)

**`Experimental`**

Get the environment variables served by the asset canister via the cookie.

The returned object always includes `IC_ROOT_KEY` property.
You can extend the global `CanisterEnv` interface to add your own environment variables
and have strong typing for them.

In Node.js environment (or any other environment where `globalThis.document` is not available), this function will throw an error.
Use [safeGetCanisterEnv](safeGetCanisterEnv.md) if you need a function that returns `undefined` instead of throwing errors.

## Type Parameters

### T

`T` = `Record`\<`string`, `never`\>

## Parameters

### options?

[`GetCanisterEnvOptions`](../interfaces/GetCanisterEnvOptions.md) = `{}`

The options for loading the canister environment variables

## Returns

[`CanisterEnv`](../interfaces/CanisterEnv.md) & `T`

The environment variables for the asset canister, always including `IC_ROOT_KEY`

## Throws

When `globalThis.document` is not available

## Throws

When the cookie is not found

## Throws

When the `IC_ROOT_KEY` is missing or has an invalid length

## See

The [Canister Environment Guide](https://js.icp.build/core/latest/canister-environment/) for more details on how to use the canister environment in a frontend application

## Example

```ts
type MyCanisterEnv = {
  readonly ['PUBLIC_CANISTER_ID:backend']: string;
};

const env = getCanisterEnv<MyCanisterEnv>();

console.log(env.IC_ROOT_KEY); // always available (Uint8Array)
console.log(env['PUBLIC_CANISTER_ID:backend']); // ✅ from generic parameter, TS passes
console.log(env['PUBLIC_CANISTER_ID:frontend']); // ❌ TS will show an error
```
Have a look at [CanisterEnv](../interfaces/CanisterEnv.md) for more details on how to extend the interface
