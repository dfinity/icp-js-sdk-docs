---
title: safeGetCanisterEnv
editUrl: false
next: true
prev: true
---

> **safeGetCanisterEnv**\<`T`\>(`options?`): [`CanisterEnv`](../interfaces/CanisterEnv.md) & `T` \| `undefined`

Defined in: [packages/core/src/agent/canister-env/index.ts:156](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/canister-env/index.ts#L156)

**`Experimental`**

Safe version of [getCanisterEnv](getCanisterEnv.md) that returns `undefined` instead of throwing errors.

## Type Parameters

### T

`T` = `Record`\<`string`, `never`\>

## Parameters

### options?

[`GetCanisterEnvOptions`](../interfaces/GetCanisterEnvOptions.md) = `{}`

The options for loading the asset canister environment variables

## Returns

[`CanisterEnv`](../interfaces/CanisterEnv.md) & `T` \| `undefined`

The environment variables for the asset canister, or `undefined` if any error occurs

## See

The [Canister Environment Guide](https://js.icp.build/core/latest/canister-environment/) for more details on how to use the canister environment in a frontend application

## Example

```ts
// in a browser environment with valid cookie
const env = safeGetCanisterEnv();
console.log(env); // { IC_ROOT_KEY: Uint8Array, ... }

// in a Node.js environment
const env = safeGetCanisterEnv();
console.log(env); // undefined

// in a browser without the environment cookie
const env = safeGetCanisterEnv();
console.log(env); // undefined
```
