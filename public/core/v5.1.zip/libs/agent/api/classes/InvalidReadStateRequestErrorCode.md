---
title: InvalidReadStateRequestErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:808](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L808)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new InvalidReadStateRequestErrorCode**(`request`): `InvalidReadStateRequestErrorCode`

Defined in: [packages/core/src/agent/errors.ts:811](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L811)

#### Parameters

##### request

`unknown`

#### Returns

`InvalidReadStateRequestErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../interfaces/CallContext.md) \| [`PollingCallContext`](../interfaces/PollingCallContext.md)

Defined in: [packages/core/src/agent/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L45)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:47](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L47)

#### Inherited from

`ErrorCode.isCertified`

***

### name

> **name**: `string` = `'InvalidReadStateRequestErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:809](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L809)

***

### request

> `readonly` **request**: `unknown`

Defined in: [packages/core/src/agent/errors.ts:811](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L811)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../interfaces/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:44](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L44)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:816](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L816)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:51](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L51)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
