---
title: MissingLookupValueErrorCode
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:313](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L313)

## Extends

- `ErrorCode`

## Constructors

### Constructor

> **new MissingLookupValueErrorCode**(`message`): `MissingLookupValueErrorCode`

Defined in: [packages/core/src/agent/errors.ts:316](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L316)

#### Parameters

##### message

`string`

#### Returns

`MissingLookupValueErrorCode`

#### Overrides

`ErrorCode.constructor`

## Properties

### callContext?

> `optional` **callContext**: [`CallContext`](../interfaces/CallContext.md) \| [`PollingCallContext`](../interfaces/PollingCallContext.md)

Defined in: [packages/core/src/agent/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L45)

#### Inherited from

`ErrorCode.callContext`

***

### isCertified

> `readonly` **isCertified**: `boolean` = `false`

Defined in: [packages/core/src/agent/errors.ts:47](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L47)

#### Inherited from

`ErrorCode.isCertified`

***

### message

> `readonly` **message**: `string`

Defined in: [packages/core/src/agent/errors.ts:316](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L316)

***

### name

> **name**: `string` = `'MissingLookupValueErrorCode'`

Defined in: [packages/core/src/agent/errors.ts:314](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L314)

***

### requestContext?

> `optional` **requestContext**: [`RequestContext`](../interfaces/RequestContext.md)

Defined in: [packages/core/src/agent/errors.ts:44](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L44)

#### Inherited from

`ErrorCode.requestContext`

## Methods

### toErrorMessage()

> **toErrorMessage**(): `string`

Defined in: [packages/core/src/agent/errors.ts:321](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L321)

#### Returns

`string`

#### Overrides

`ErrorCode.toErrorMessage`

***

### toString()

> **toString**(): `string`

Defined in: [packages/core/src/agent/errors.ts:51](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L51)

#### Returns

`string`

#### Inherited from

`ErrorCode.toString`
