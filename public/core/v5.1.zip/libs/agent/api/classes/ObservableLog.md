---
title: ObservableLog
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/observable.ts:36](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L36)

## Extends

- [`Observable`](Observable.md)\<[`AgentLog`](../type-aliases/AgentLog.md)\>

## Constructors

### Constructor

> **new ObservableLog**(): `ObservableLog`

Defined in: [packages/core/src/agent/observable.ts:37](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L37)

#### Returns

`ObservableLog`

#### Overrides

[`Observable`](Observable.md).[`constructor`](Observable.md#constructor)

## Properties

### observers

> **observers**: [`ObserveFunction`](../type-aliases/ObserveFunction.md)\<[`AgentLog`](../type-aliases/AgentLog.md)\>[]

Defined in: [packages/core/src/agent/observable.ts:6](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L6)

#### Inherited from

[`Observable`](Observable.md).[`observers`](Observable.md#observers)

## Methods

### error()

> **error**(`message`, `error`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:46](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L46)

#### Parameters

##### message

`string`

##### error

[`AgentError`](AgentError.md)

##### rest

...`unknown`[]

#### Returns

`void`

***

### notify()

> **notify**(`data`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:20](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L20)

#### Parameters

##### data

[`AgentLog`](../type-aliases/AgentLog.md)

##### rest

...`unknown`[]

#### Returns

`void`

#### Inherited from

[`Observable`](Observable.md).[`notify`](Observable.md#notify)

***

### print()

> **print**(`message`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:40](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L40)

#### Parameters

##### message

`string`

##### rest

...`unknown`[]

#### Returns

`void`

***

### subscribe()

> **subscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:12](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L12)

#### Parameters

##### func

[`ObserveFunction`](../type-aliases/ObserveFunction.md)\<[`AgentLog`](../type-aliases/AgentLog.md)\>

#### Returns

`void`

#### Inherited from

[`Observable`](Observable.md).[`subscribe`](Observable.md#subscribe)

***

### unsubscribe()

> **unsubscribe**(`func`): `void`

Defined in: [packages/core/src/agent/observable.ts:16](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L16)

#### Parameters

##### func

[`ObserveFunction`](../type-aliases/ObserveFunction.md)\<[`AgentLog`](../type-aliases/AgentLog.md)\>

#### Returns

`void`

#### Inherited from

[`Observable`](Observable.md).[`unsubscribe`](Observable.md#unsubscribe)

***

### warn()

> **warn**(`message`, ...`rest`): `void`

Defined in: [packages/core/src/agent/observable.ts:43](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L43)

#### Parameters

##### message

`string`

##### rest

...`unknown`[]

#### Returns

`void`
