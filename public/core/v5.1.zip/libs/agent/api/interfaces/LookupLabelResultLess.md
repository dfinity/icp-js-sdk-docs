---
title: LookupLabelResultLess
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:596](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L596)

## Properties

### status

> **status**: [`Less`](../enumerations/LookupLabelStatus.md#less)

Defined in: [packages/core/src/agent/certificate.ts:597](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L597)
