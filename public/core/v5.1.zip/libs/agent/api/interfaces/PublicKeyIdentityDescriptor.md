---
title: PublicKeyIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/auth.ts:129](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/auth.ts#L129)

## Properties

### publicKey

> **publicKey**: `string`

Defined in: [packages/core/src/agent/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/auth.ts#L131)

***

### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/core/src/agent/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/auth.ts#L130)
