---
title: HttpAgentBaseRequest
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:21](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/types.ts#L21)

## Extended by

- [`HttpAgentSubmitRequest`](HttpAgentSubmitRequest.md)
- [`HttpAgentQueryRequest`](HttpAgentQueryRequest.md)
- [`HttpAgentReadStateRequest`](HttpAgentReadStateRequest.md)

## Properties

### endpoint

> `readonly` **endpoint**: [`Endpoint`](../enumerations/Endpoint.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:22](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/types.ts#L22)

***

### request

> **request**: `RequestInit`

Defined in: [packages/core/src/agent/agent/http/types.ts:23](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/types.ts#L23)
