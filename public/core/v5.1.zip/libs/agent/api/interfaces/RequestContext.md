---
title: RequestContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:21](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L21)

## Properties

### ingressExpiry

> **ingressExpiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/errors.ts:25](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L25)

***

### requestId?

> `optional` **requestId**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:22](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L22)

***

### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:23](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L23)

***

### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:24](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L24)
