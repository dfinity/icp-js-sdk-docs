---
title: AnonymousIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/auth.ts:126](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/auth.ts#L126)

## Properties

### type

> **type**: `"AnonymousIdentity"`

Defined in: [packages/core/src/agent/auth.ts:127](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/auth.ts#L127)
