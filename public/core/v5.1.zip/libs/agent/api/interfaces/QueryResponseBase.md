---
title: QueryResponseBase
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:52](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L52)

## Extended by

- [`QueryResponseReplied`](QueryResponseReplied.md)
- [`QueryResponseRejected`](QueryResponseRejected.md)

## Properties

### requestDetails?

> `optional` **requestDetails**: [`QueryRequest`](QueryRequest.md)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L54)

***

### status

> **status**: [`QueryResponseStatus`](../enumerations/QueryResponseStatus.md)

Defined in: [packages/core/src/agent/agent/api.ts:53](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L53)
