---
title: Cert
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:41](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L41)

## Properties

### delegation?

> `optional` **delegation**: `Delegation`

Defined in: [packages/core/src/agent/certificate.ts:44](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L44)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:43](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L43)

***

### tree

> **tree**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/core/src/agent/certificate.ts:42](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L42)
