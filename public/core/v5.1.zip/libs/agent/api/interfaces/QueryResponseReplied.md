---
title: QueryResponseReplied
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:66](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L66)

## Extends

- [`QueryResponseBase`](QueryResponseBase.md)

## Properties

### reply

> **reply**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:68](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L68)

#### arg

> **arg**: `Uint8Array`

***

### requestDetails?

> `optional` **requestDetails**: [`QueryRequest`](QueryRequest.md)

Defined in: [packages/core/src/agent/agent/api.ts:54](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L54)

#### Inherited from

[`QueryResponseBase`](QueryResponseBase.md).[`requestDetails`](QueryResponseBase.md#requestdetails)

***

### signatures?

> `optional` **signatures**: [`NodeSignature`](NodeSignature.md)[]

Defined in: [packages/core/src/agent/agent/api.ts:69](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L69)

***

### status

> **status**: [`Replied`](../enumerations/QueryResponseStatus.md#replied)

Defined in: [packages/core/src/agent/agent/api.ts:67](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L67)

#### Overrides

[`QueryResponseBase`](QueryResponseBase.md).[`status`](QueryResponseBase.md#status)
