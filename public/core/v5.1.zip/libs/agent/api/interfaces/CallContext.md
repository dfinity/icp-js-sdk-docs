---
title: CallContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:39](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L39)

Call context for errors that arise from a direct HTTP call response.

## Extends

- [`PollingCallContext`](PollingCallContext.md)

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/errors.ts:32](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L32)

#### Inherited from

[`PollingCallContext`](PollingCallContext.md).[`canisterId`](PollingCallContext.md#canisterid)

***

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](HttpDetailsResponse.md)

Defined in: [packages/core/src/agent/errors.ts:40](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L40)

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:33](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L33)

#### Inherited from

[`PollingCallContext`](PollingCallContext.md).[`methodName`](PollingCallContext.md#methodname)
