---
title: HttpAgentRequestTransformFn
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:55](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/types.ts#L55)

> **HttpAgentRequestTransformFn**(`args`): `Promise`\<`void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md) \| `undefined`\>

Defined in: [packages/core/src/agent/agent/http/types.ts:56](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/types.ts#L56)

## Parameters

### args

[`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md)

## Returns

`Promise`\<`void` \| [`HttpAgentRequest`](../type-aliases/HttpAgentRequest.md) \| `undefined`\>

## Properties

### priority?

> `optional` **priority**: `number`

Defined in: [packages/core/src/agent/agent/http/types.ts:57](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/types.ts#L57)
