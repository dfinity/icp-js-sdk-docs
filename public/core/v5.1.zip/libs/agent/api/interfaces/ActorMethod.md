---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:121](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L121)

An actor method type, defined for each methods of the actor service.

## Extended by

- [`ActorMethodWithHttpDetails`](ActorMethodWithHttpDetails.md)
- [`ActorMethodExtended`](ActorMethodExtended.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:122](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L122)

An actor method type, defined for each methods of the actor service.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:124](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L124)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

> (...`args`): `Promise`\<`Ret`\>

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<`Ret`\>
