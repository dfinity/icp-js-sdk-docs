---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:113](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L113)

An actor method type, defined for each methods of the actor service.

## Extended by

- [`ActorMethodWithHttpDetails`](ActorMethodWithHttpDetails.md)
- [`ActorMethodExtended`](ActorMethodExtended.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:114](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L114)

An actor method type, defined for each methods of the actor service.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`Ret`\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L116)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

> (...`args`): `Promise`\<`Ret`\>

##### Parameters

###### args

...`Args`

##### Returns

`Promise`\<`Ret`\>
