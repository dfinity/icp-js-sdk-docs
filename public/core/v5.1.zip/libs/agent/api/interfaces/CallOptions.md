---
title: CallOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:103](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L103)

Options when doing a [Agent.call](Agent.md#call) call.

## Properties

### arg

> **arg**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:112](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L112)

A binary encoded argument. This is already encoded and will be sent as is.

***

### effectiveCanisterId

> **effectiveCanisterId**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/agent/api.ts:118](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L118)

An effective canister ID, used for routing. Usually the canister ID, except for management canister calls.

#### See

https://internetcomputer.org/docs/current/references/ic-interface-spec/#http-effective-canister-id

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:107](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L107)

The method name to call.

***

### nonce?

> `optional` **nonce**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/api.ts:123](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L123)

An optional nonce to use for the call, used to prevent replay attacks.
