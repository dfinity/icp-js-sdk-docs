---
title: v4ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:147](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L147)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:148](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L148)
