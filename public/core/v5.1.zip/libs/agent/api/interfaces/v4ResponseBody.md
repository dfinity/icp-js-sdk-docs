---
title: v4ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:147](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L147)

## Properties

### certificate

> **certificate**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:148](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L148)
