---
title: CallConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:38](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L38)

Configuration to make calls to the Replica.

## Properties

### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/core/src/agent/actor.ts:43](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L43)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

***

### canisterId?

> `optional` **canisterId**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/actor.ts:53](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L53)

The canister ID of this Actor.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/actor.ts:58](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L58)

The effective canister ID.

***

### nonce?

> `optional` **nonce**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/actor.ts:63](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L63)

The nonce to use for this call. This is used to prevent replay attacks.

***

### pollingOptions?

> `optional` **pollingOptions**: [`PollingOptions`](PollingOptions.md)

Defined in: [packages/core/src/agent/actor.ts:48](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L48)

Options for controlling polling behavior.
