---
title: LookupLabelResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:583](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L583)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupLabelStatus.md#unknown)

Defined in: [packages/core/src/agent/certificate.ts:584](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L584)
