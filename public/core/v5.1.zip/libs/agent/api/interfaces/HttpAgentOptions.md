---
title: HttpAgentOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:134](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L134)

## Properties

### backoffStrategy?

> `optional` **backoffStrategy**: `BackoffStrategyFactory`

Defined in: [packages/core/src/agent/agent/http/index.ts:181](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L181)

The strategy to use for backoff when retrying requests

***

### callOptions?

> `optional` **callOptions**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:144](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L144)

***

### credentials?

> `optional` **credentials**: `object`

Defined in: [packages/core/src/agent/agent/http/index.ts:160](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L160)

#### name

> **name**: `string`

#### password?

> `optional` **password**: `string`

***

### fetch()?

> `optional` **fetch**: \{(`input`, `init?`): `Promise`\<`Response`\>; (`input`, `init?`): `Promise`\<`Response`\>; \}

Defined in: [packages/core/src/agent/agent/http/index.ts:136](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L136)

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`URL` | `RequestInfo`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

#### Call Signature

> (`input`, `init?`): `Promise`\<`Response`\>

[MDN Reference](https://developer.mozilla.org/docs/Web/API/Window/fetch)

##### Parameters

###### input

`string` | `URL` | `Request`

###### init?

`RequestInit`

##### Returns

`Promise`\<`Response`\>

***

### fetchOptions?

> `optional` **fetchOptions**: `Record`\<`string`, `unknown`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:141](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L141)

***

### host?

> `optional` **host**: `string`

Defined in: [packages/core/src/agent/agent/http/index.ts:148](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L148)

***

### identity?

> `optional` **identity**: [`Identity`](Identity.md) \| `Promise`\<[`Identity`](Identity.md)\>

Defined in: [packages/core/src/agent/agent/http/index.ts:152](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L152)

***

### ingressExpiryInMinutes?

> `optional` **ingressExpiryInMinutes**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:158](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L158)

The maximum time a request can be delayed before being rejected.

#### Default

```ts
5 minutes
```

***

### logToConsole?

> `optional` **logToConsole**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:190](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L190)

Whether to log to the console. Defaults to false.

***

### retryTimes?

> `optional` **retryTimes**: `number`

Defined in: [packages/core/src/agent/agent/http/index.ts:177](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L177)

Number of times to retry requests before throwing an error

#### Default

```ts
3
```

***

### rootKey?

> `optional` **rootKey**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/agent/agent/http/index.ts:195](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L195)

Alternate root key to use for verifying certificates. If not provided, the default IC root key will be used.

***

### shouldFetchRootKey?

> `optional` **shouldFetchRootKey**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:200](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L200)

Whether or not the root key should be automatically fetched during construction. Defaults to false.

***

### shouldSyncTime?

> `optional` **shouldSyncTime**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:205](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L205)

Whether or not to sync the time with the network during construction. Defaults to false.

***

### useQueryNonces?

> `optional` **useQueryNonces**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:172](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L172)

Adds a unique [Nonce](../type-aliases/Nonce.md) with each query.
Enabling will prevent queries from being answered with a cached response.

#### Example

```ts
const agent = new HttpAgent({ useQueryNonces: true });
agent.addTransform(makeNonceTransform(makeNonce);
```

#### Default

```ts
false
```

***

### verifyQuerySignatures?

> `optional` **verifyQuerySignatures**: `boolean`

Defined in: [packages/core/src/agent/agent/http/index.ts:186](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L186)

Whether the agent should verify signatures signed by node keys on query responses. Increases security, but adds overhead and must make a separate request to cache the node keys for the canister's subnet.

#### Default

```ts
true
```
