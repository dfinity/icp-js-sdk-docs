---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:174](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L174)

## Properties

### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:176](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L176)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:175](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L175)
