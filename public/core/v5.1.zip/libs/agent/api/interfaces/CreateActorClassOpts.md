---
title: CreateActorClassOpts
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:182](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L182)

## Properties

### certificate?

> `optional` **certificate**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:184](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L184)

***

### httpDetails?

> `optional` **httpDetails**: `boolean`

Defined in: [packages/core/src/agent/actor.ts:183](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L183)
