---
title: LookupPathResultError
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:537](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L537)

## Properties

### status

> **status**: [`Error`](../enumerations/LookupPathStatus.md#error)

Defined in: [packages/core/src/agent/certificate.ts:538](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L538)
