---
title: PollingCallContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:31](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L31)

Call context for errors that arise during polling.

## Extended by

- [`CallContext`](CallContext.md)

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/errors.ts:32](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L32)

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:33](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/errors.ts#L33)
