---
title: ActorConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:69](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L69)

Configuration that can be passed to customize the Actor behavior.

## Extends

- `Pick`\<[`CallConfig`](CallConfig.md), `"agent"` \| `"effectiveCanisterId"`\>

## Properties

### agent?

> `optional` **agent**: [`Agent`](Agent.md)

Defined in: [packages/core/src/agent/actor.ts:43](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L43)

An agent to use in this call, otherwise the actor or call will try to discover the
agent to use.

#### Inherited from

[`CallConfig`](CallConfig.md).[`agent`](CallConfig.md#agent)

***

### blsVerify?

> `optional` **blsVerify**: `VerifyFunc`

Defined in: [packages/core/src/agent/actor.ts:96](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L96)

Polyfill for BLS Certificate verification in case wasm is not supported

***

### canisterId

> **canisterId**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/actor.ts:73](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L73)

The Canister ID of this Actor. This is required for an Actor.

***

### effectiveCanisterId?

> `optional` **effectiveCanisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/actor.ts:58](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L58)

The effective canister ID.

#### Inherited from

[`CallConfig`](CallConfig.md).[`effectiveCanisterId`](CallConfig.md#effectivecanisterid)

***

### pollingOptions?

> `optional` **pollingOptions**: [`PollingOptions`](PollingOptions.md)

Defined in: [packages/core/src/agent/actor.ts:101](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L101)

Polling options to use when making update calls. This will override the default DEFAULT_POLLING_OPTIONS.

***

### queryStrategy?

> `optional` **queryStrategy**: [`QueryStrategy`](../type-aliases/QueryStrategy.md)

Defined in: [packages/core/src/agent/actor.ts:109](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L109)

Controls how query and composite_query methods are executed.
- `'query'` (default) — standard non-replicated query call.
- `'update'` — send query methods as update calls that go through consensus.

#### Default

```ts
'query'
```

## Methods

### callTransform()?

> `optional` **callTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

Defined in: [packages/core/src/agent/actor.ts:78](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L78)

An override function for update calls' CallConfig. This will be called on every calls.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

***

### queryTransform()?

> `optional` **queryTransform**(`methodName`, `args`, `callConfig`): `void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>

Defined in: [packages/core/src/agent/actor.ts:87](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L87)

An override function for query calls' CallConfig. This will be called on every query.

#### Parameters

##### methodName

`string`

##### args

`unknown`[]

##### callConfig

[`CallConfig`](CallConfig.md)

#### Returns

`void` \| `Partial`\<[`CallConfig`](CallConfig.md)\>
