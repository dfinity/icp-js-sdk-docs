---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/expiry.ts:20](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/expiry.ts#L20)

## Properties

### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:21](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/expiry.ts#L21)
