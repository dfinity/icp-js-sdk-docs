---
title: JsonnableExpiry
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/expiry.ts:20](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/expiry.ts#L20)

## Properties

### \_\_expiry\_\_

> **\_\_expiry\_\_**: `string`

Defined in: [packages/core/src/agent/agent/http/expiry.ts:21](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/expiry.ts#L21)
