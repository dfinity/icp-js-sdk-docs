---
title: ActorMethodExtended
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/actor.ts:132](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L132)

An actor method type, defined for each methods of the actor service.

## Extends

- [`ActorMethod`](ActorMethod.md)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

## Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<\{ `certificate?`: [`Certificate`](../classes/Certificate.md); `httpDetails?`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

Defined in: [packages/core/src/agent/actor.ts:136](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L136)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`Args`

### Returns

`Promise`\<\{ `certificate?`: [`Certificate`](../classes/Certificate.md); `httpDetails?`: [`HttpDetailsResponse`](HttpDetailsResponse.md); `result`: `Ret`; \}\>

## Call Signature

> **ActorMethodExtended**(...`args`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:132](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L132)

An actor method type, defined for each methods of the actor service.

### Parameters

#### args

...`unknown`[]

### Returns

`Promise`\<`unknown`\>

## Methods

### withOptions()

> **withOptions**(`options`): (...`args`) => `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/actor.ts:116](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/actor.ts#L116)

#### Parameters

##### options

[`CallConfig`](CallConfig.md)

#### Returns

> (...`args`): `Promise`\<`unknown`\>

##### Parameters

###### args

...`unknown`[]

##### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`ActorMethod`](ActorMethod.md).[`withOptions`](ActorMethod.md#withoptions)
