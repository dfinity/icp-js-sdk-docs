---
title: SECP256K1_OID
editUrl: false
next: true
prev: true
---

> `const` **SECP256K1\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:108](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/der.ts#L108)

A DER encoded `SEQUENCE(OID)` for secp256k1 with the ECDSA algorithm
