---
title: SECP256K1_OID
editUrl: false
next: true
prev: true
---

> `const` **SECP256K1\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:108](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/der.ts#L108)

A DER encoded `SEQUENCE(OID)` for secp256k1 with the ECDSA algorithm
