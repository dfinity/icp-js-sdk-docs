---
title: DER_COSE_OID
editUrl: false
next: true
prev: true
---

> `const` **DER\_COSE\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:90](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/der.ts#L90)

A DER encoded `SEQUENCE(OID)` for DER-encoded-COSE
