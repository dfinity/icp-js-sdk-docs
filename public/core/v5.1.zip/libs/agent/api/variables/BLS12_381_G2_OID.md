---
title: BLS12_381_G2_OID
editUrl: false
next: true
prev: true
---

> `const` **BLS12\_381\_G2\_OID**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/der.ts:116](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/der.ts#L116)
