---
title: Cbor
editUrl: false
next: true
prev: true
---

> `const` **Cbor**: `object`

Defined in: [packages/core/src/agent/cbor.ts:60](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/cbor.ts#L60)

## Type Declaration

### decode()

> **decode**: \<`T`\>(`input`) => `T`

Decode a CBOR encoded value into a JavaScript value.

#### Type Parameters

##### T

`T`

#### Parameters

##### input

`Uint8Array`

The CBOR encoded value

#### Returns

`T`

### encode()

> **encode**: (`value`) => `Uint8Array`

Encode a JavaScript value into CBOR. If the value is an instance of [ToCborValue](../classes/ToCborValue.md),
the [ToCborValue.toCborValue](../classes/ToCborValue.md#tocborvalue) method will be called to get the value to encode.

#### Parameters

##### value

`unknown`

The value to encode

#### Returns

`Uint8Array`
