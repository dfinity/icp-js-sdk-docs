---
title: IC_REQUEST_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_REQUEST\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:12](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/constants.ts#L12)

The `\x0Aic-request` domain separator used in the signature of IC requests.
