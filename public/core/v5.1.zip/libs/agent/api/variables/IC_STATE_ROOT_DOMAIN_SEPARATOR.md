---
title: IC_STATE_ROOT_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/constants.ts#L7)

The `\x0Dic-state-root` domain separator used in the root hash of IC certificates.
