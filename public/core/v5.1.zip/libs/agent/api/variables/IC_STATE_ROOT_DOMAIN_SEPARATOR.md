---
title: IC_STATE_ROOT_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_STATE\_ROOT\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:7](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/constants.ts#L7)

The `\x0Dic-state-root` domain separator used in the root hash of IC certificates.
