---
title: ReadRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:78](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/types.ts#L78)

## Enumeration Members

### Query

> **Query**: `"query"`

Defined in: [packages/core/src/agent/agent/http/types.ts:79](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/types.ts#L79)

***

### ReadState

> **ReadState**: `"read_state"`

Defined in: [packages/core/src/agent/agent/http/types.ts:80](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/types.ts#L80)
