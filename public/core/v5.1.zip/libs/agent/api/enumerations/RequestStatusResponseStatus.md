---
title: RequestStatusResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:96](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L96)

## Enumeration Members

### Done

> **Done**: `"done"`

Defined in: [packages/core/src/agent/agent/http/index.ts:102](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L102)

***

### Processing

> **Processing**: `"processing"`

Defined in: [packages/core/src/agent/agent/http/index.ts:98](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L98)

***

### Received

> **Received**: `"received"`

Defined in: [packages/core/src/agent/agent/http/index.ts:97](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L97)

***

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/http/index.ts:100](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L100)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/http/index.ts:99](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L99)

***

### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/core/src/agent/agent/http/index.ts:101](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L101)
