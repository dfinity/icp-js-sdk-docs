---
title: RequestStatusResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/index.ts:93](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/index.ts#L93)

## Enumeration Members

### Done

> **Done**: `"done"`

Defined in: [packages/core/src/agent/agent/http/index.ts:99](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/index.ts#L99)

***

### Processing

> **Processing**: `"processing"`

Defined in: [packages/core/src/agent/agent/http/index.ts:95](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/index.ts#L95)

***

### Received

> **Received**: `"received"`

Defined in: [packages/core/src/agent/agent/http/index.ts:94](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/index.ts#L94)

***

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/http/index.ts:97](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/index.ts#L97)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/http/index.ts:96](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/index.ts#L96)

***

### Unknown

> **Unknown**: `"unknown"`

Defined in: [packages/core/src/agent/agent/http/index.ts:98](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/index.ts#L98)
