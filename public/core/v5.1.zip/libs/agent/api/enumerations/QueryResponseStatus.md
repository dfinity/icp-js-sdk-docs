---
title: QueryResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L35)

## Enumeration Members

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/api.ts:37](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L37)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/api.ts#L36)
