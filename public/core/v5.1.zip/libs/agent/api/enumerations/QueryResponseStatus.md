---
title: QueryResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L35)

## Enumeration Members

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/api.ts:37](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L37)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L36)
