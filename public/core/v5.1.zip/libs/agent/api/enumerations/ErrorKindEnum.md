---
title: ErrorKindEnum
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:10](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L10)

## Enumeration Members

### External

> **External**: `"External"`

Defined in: [packages/core/src/agent/errors.ts:15](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L15)

***

### Input

> **Input**: `"Input"`

Defined in: [packages/core/src/agent/errors.ts:17](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L17)

***

### Limit

> **Limit**: `"Limit"`

Defined in: [packages/core/src/agent/errors.ts:16](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L16)

***

### Protocol

> **Protocol**: `"Protocol"`

Defined in: [packages/core/src/agent/errors.ts:12](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L12)

***

### Reject

> **Reject**: `"Reject"`

Defined in: [packages/core/src/agent/errors.ts:13](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L13)

***

### Transport

> **Transport**: `"Transport"`

Defined in: [packages/core/src/agent/errors.ts:14](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L14)

***

### Trust

> **Trust**: `"Trust"`

Defined in: [packages/core/src/agent/errors.ts:11](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L11)

***

### Unknown

> **Unknown**: `"Unknown"`

Defined in: [packages/core/src/agent/errors.ts:18](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/errors.ts#L18)
