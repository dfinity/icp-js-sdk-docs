---
title: encodePath
editUrl: false
next: true
prev: true
---

> **encodePath**(`path`, `subnetId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/core/src/agent/subnetStatus/index.ts:233](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/subnetStatus/index.ts#L233)

Encode a path for subnet state queries

## Parameters

### path

[`Path`](../type-aliases/Path.md)

the path to encode

### subnetId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the subnet ID

## Returns

`Uint8Array`\<`ArrayBufferLike`\>[]

the encoded path as an array of Uint8Arrays
