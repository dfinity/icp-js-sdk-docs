---
title: SubnetStatusOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/subnetStatus/index.ts:56](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/subnetStatus/index.ts#L56)

## Properties

### agent

> **agent**: [`HttpAgent`](../../../classes/HttpAgent.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:65](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/subnetStatus/index.ts#L65)

The agent to use to make the subnet request.

***

### disableCertificateTimeVerification?

> `optional` **disableCertificateTimeVerification**: `boolean`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:75](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/subnetStatus/index.ts#L75)

Whether to disable the certificate freshness checks.

#### Default

```ts
false
```

***

### paths?

> `optional` **paths**: `Set`\<[`Path`](../type-aliases/Path.md)\> \| [`Path`](../type-aliases/Path.md)[]

Defined in: [packages/core/src/agent/subnetStatus/index.ts:70](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/subnetStatus/index.ts#L70)

The paths to request.

#### Default

```ts
[]
```

***

### subnetId

> **subnetId**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:61](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/subnetStatus/index.ts#L61)

The subnet ID to query. Use [IC\_ROOT\_SUBNET\_ID](../variables/IC_ROOT_SUBNET_ID.md) for the IC mainnet root subnet.
You can use [HttpAgent.getSubnetIdFromCanister](../../../classes/HttpAgent.md#getsubnetidfromcanister) to get a subnet ID from a canister.
