---
title: lookupSubnetInfo
editUrl: false
next: true
prev: true
---

> **lookupSubnetInfo**(`certificate`, `subnetId`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:202](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/subnetStatus/index.ts#L202)

Fetch subnet info including node keys from a certificate

## Parameters

### certificate

`Uint8Array`

the certificate bytes

### subnetId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the subnet ID

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)

SubnetStatus with subnet ID and node keys
