---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| `SubnetNodeKeys` \| [`CanisterRanges`](../../../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:47](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/subnetStatus/index.ts#L47)
