---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

> **SubnetStatus** = `BaseSubnetStatus` & `object`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:40](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/subnetStatus/index.ts#L40)

## Type Declaration

### publicKey

> **publicKey**: `Uint8Array`

The public key of the subnet
