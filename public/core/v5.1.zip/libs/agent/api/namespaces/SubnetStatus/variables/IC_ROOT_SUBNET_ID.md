---
title: IC_ROOT_SUBNET_ID
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_SUBNET\_ID**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/utils/readState.ts:26](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/utils/readState.ts#L26)

The root subnet ID for IC mainnet
