---
title: IC_ROOT_SUBNET_ID
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_SUBNET\_ID**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/utils/readState.ts:26](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/utils/readState.ts#L26)

The root subnet ID for IC mainnet
