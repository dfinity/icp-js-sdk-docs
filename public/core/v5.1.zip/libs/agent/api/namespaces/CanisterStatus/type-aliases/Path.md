---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`CustomPath`](../classes/CustomPath.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:38](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/canisterStatus/index.ts#L38)

Pre-configured fields for canister status paths
