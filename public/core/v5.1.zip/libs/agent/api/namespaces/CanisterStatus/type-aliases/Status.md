---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| [`SubnetStatus`](SubnetStatus.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:33](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/canisterStatus/index.ts#L33)
