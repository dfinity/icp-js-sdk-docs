---
title: fetchNodeKeys
editUrl: false
next: true
prev: true
---

> **fetchNodeKeys**(`certificate`, `canisterId`, `root_key?`): `BaseSubnetStatus`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:196](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/canisterStatus/index.ts#L196)

Lookup node keys from a certificate for a given canister.
The certificate is assumed to be already verified, including whether the canister is in range of the subnet.

## Parameters

### certificate

`Uint8Array`

the certificate to lookup node keys from

### canisterId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the canister ID to lookup node keys for

### root\_key?

`Uint8Array`\<`ArrayBufferLike`\>

the root key to use to lookup node keys

## Returns

`BaseSubnetStatus`

a map of node IDs to public keys
