---
title: request
editUrl: false
next: true
prev: true
---

> **request**(`options`): `Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

Defined in: [packages/core/src/agent/canisterStatus/index.ts:81](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/canisterStatus/index.ts#L81)

Requests information from a canister's `read_state` endpoint.
Can be used to request information about the canister's controllers, time, module hash, candid interface, and more.

> [!WARNING]
> Requesting the `subnet` path from the canister status might be deprecated in the future.
> Use [SubnetStatus.request](https://js.icp.build/core/latest/libs/agent/api/namespaces/subnetstatus/functions/request) to fetch subnet information instead.

## Parameters

### options

[`CanisterStatusOptions`](../interfaces/CanisterStatusOptions.md)

The configuration for the canister status request.

## Returns

`Promise`\<[`StatusMap`](../type-aliases/StatusMap.md)\>

A map populated with data from the requested paths. Each path is a key in the map, and the value is the data obtained from the certificate for that path.

## See

[CanisterStatusOptions](../interfaces/CanisterStatusOptions.md) for detailed options.

## Example

```ts
const status = await canisterStatus({
  paths: ['controllers', 'candid'],
  ...options
});

const controllers = status.get('controllers');
```
