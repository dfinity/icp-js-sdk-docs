---
title: DecodeStrategy
editUrl: false
next: true
prev: true
---

> **DecodeStrategy** = `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/core/src/agent/utils/readState.ts:59](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/utils/readState.ts#L59)

Decode strategy for custom paths
