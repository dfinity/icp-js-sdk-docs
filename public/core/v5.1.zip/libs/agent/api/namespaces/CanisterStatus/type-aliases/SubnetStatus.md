---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

> **SubnetStatus** = `BaseSubnetStatus`

Defined in: [packages/core/src/agent/canisterStatus/index.ts:32](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/canisterStatus/index.ts#L32)
