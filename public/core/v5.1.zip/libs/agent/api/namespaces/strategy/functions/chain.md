---
title: chain
editUrl: false
next: true
prev: true
---

> **chain**(...`strategies`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/strategy.ts:130](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/polling/strategy.ts#L130)

Chain multiple polling strategy. This _chains_ the strategies, so if you pass in,
say, two throttling strategy of 1 second, it will result in a throttle of 2 seconds.

## Parameters

### strategies

...[`PollStrategy`](../../../type-aliases/PollStrategy.md)[]

A strategy list to chain.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
