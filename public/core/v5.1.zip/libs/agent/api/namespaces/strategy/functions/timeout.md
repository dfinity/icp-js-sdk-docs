---
title: timeout
editUrl: false
next: true
prev: true
---

> **timeout**(`timeInMsec`): [`PollStrategy`](../../../type-aliases/PollStrategy.md)

Defined in: [packages/core/src/agent/polling/strategy.ts:88](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/polling/strategy.ts#L88)

Reject a call after a certain amount of time.

## Parameters

### timeInMsec

`number`

Time in milliseconds before the polling should be rejected.

## Returns

[`PollStrategy`](../../../type-aliases/PollStrategy.md)
