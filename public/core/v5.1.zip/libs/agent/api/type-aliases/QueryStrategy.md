---
title: QueryStrategy
editUrl: false
next: true
prev: true
---

> **QueryStrategy** = `"query"` \| `"update"`

Defined in: [packages/core/src/agent/actor.ts:33](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/actor.ts#L33)

Controls how query and composite_query methods are executed.

- `'query'` — standard non-replicated query call (default).
- `'update'` — send query methods as update calls that go through consensus.
