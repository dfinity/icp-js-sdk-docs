---
title: ForkHashTree
editUrl: false
next: true
prev: true
---

> **ForkHashTree** = \[[`Fork`](../enumerations/NodeType.md#fork), [`HashTree`](HashTree.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/core/src/agent/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L61)
