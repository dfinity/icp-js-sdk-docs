---
title: ForkHashTree
editUrl: false
next: true
prev: true
---

> **ForkHashTree** = \[[`Fork`](../enumerations/NodeType.md#fork), [`HashTree`](HashTree.md), [`HashTree`](HashTree.md)\]

Defined in: [packages/core/src/agent/certificate.ts:61](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L61)
