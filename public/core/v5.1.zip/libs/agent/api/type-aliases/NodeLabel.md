---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L56)

## Type Declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
