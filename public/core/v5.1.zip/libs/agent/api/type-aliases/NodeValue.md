---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:57](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L57)

## Type Declaration

### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
