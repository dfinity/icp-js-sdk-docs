---
title: NodeValue
editUrl: false
next: true
prev: true
---

> **NodeValue** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:57](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L57)

## Type Declaration

### \_\_nodeValue\_\_

> **\_\_nodeValue\_\_**: `void`
