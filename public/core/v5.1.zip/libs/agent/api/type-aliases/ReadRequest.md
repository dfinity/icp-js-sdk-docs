---
title: ReadRequest
editUrl: false
next: true
prev: true
---

> **ReadRequest** = [`QueryRequest`](../interfaces/QueryRequest.md) \| [`ReadStateRequest`](../interfaces/ReadStateRequest.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:103](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/http/types.ts#L103)
