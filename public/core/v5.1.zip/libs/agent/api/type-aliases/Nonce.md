---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/agent/http/types.ts:106](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/types.ts#L106)

## Type Declaration

### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
