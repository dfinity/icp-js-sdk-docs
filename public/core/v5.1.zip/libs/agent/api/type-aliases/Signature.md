---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/auth.ts#L22)

A signature array buffer.

## Type Declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
