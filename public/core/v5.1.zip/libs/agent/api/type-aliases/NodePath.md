---
title: NodePath
editUrl: false
next: true
prev: true
---

> **NodePath** = (`Uint8Array` \| `string`)[]

Defined in: [packages/core/src/agent/certificate.ts:55](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L55)
