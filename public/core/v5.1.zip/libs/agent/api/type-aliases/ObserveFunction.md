---
title: ObserveFunction
editUrl: false
next: true
prev: true
---

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/core/src/agent/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/observable.ts#L3)

## Type Parameters

### T

`T`

## Parameters

### data

`T`

### rest

...`unknown`[]

## Returns

`void`
