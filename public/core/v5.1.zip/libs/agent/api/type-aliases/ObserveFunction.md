---
title: ObserveFunction
editUrl: false
next: true
prev: true
---

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/core/src/agent/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/observable.ts#L3)

## Type Parameters

### T

`T`

## Parameters

### data

`T`

### rest

...`unknown`[]

## Returns

`void`
