---
title: CertificatePrincipal
editUrl: false
next: true
prev: true
---

> **CertificatePrincipal** = \{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \} \| \{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

Defined in: [packages/core/src/agent/certificate.ts:155](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L155)

## Type Declaration

\{ `canisterId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

The effective canister ID of the request when verifying a response, or
the signing canister ID when verifying a certified variable.

\{ `subnetId`: [`Principal`](../../../principal/api/classes/Principal.md); \}

### subnetId

> **subnetId**: [`Principal`](../../../principal/api/classes/Principal.md)

The subnet ID when verifying a certificate from a subnet.
