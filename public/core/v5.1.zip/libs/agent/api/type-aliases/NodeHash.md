---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L58)

## Type Declaration

### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
