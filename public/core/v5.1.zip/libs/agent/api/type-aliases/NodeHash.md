---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L58)

## Type Declaration

### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
