---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/request_id.ts#L8)

## Type Declaration

### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
