---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/request_id.ts#L8)

## Type Declaration

### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
