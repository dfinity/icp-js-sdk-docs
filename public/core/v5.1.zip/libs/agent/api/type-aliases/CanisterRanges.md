---
title: CanisterRanges
editUrl: false
next: true
prev: true
---

> **CanisterRanges** = \[[`Principal`](../../../principal/api/classes/Principal.md), [`Principal`](../../../principal/api/classes/Principal.md)\][]

Defined in: [packages/core/src/agent/certificate.ts:886](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L886)

Canister ranges in the form of an array of [start, end] principal tuples,
usually decoded from the certificate.
