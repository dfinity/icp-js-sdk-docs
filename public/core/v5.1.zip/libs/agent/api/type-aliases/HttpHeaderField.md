---
title: HttpHeaderField
editUrl: false
next: true
prev: true
---

> **HttpHeaderField** = \[`string`, `string`\]

Defined in: [packages/core/src/agent/agent/http/types.ts:26](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/types.ts#L26)
