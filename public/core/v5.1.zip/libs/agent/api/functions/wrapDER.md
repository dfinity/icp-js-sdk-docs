---
title: wrapDER
editUrl: false
next: true
prev: true
---

> **wrapDER**(`payload`, `oid`): `Uint8Array`

Defined in: [packages/core/src/agent/der.ts:132](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/der.ts#L132)

Wraps the given `payload` in a DER encoding tagged with the given encoded `oid` like so:
`SEQUENCE(oid, BITSTRING(payload))`

## Parameters

### payload

`Uint8Array`

The payload to encode as the bit string

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) OID to tag the payload with

## Returns

`Uint8Array`
