---
title: decodeLen
editUrl: false
next: true
prev: true
---

> **decodeLen**(`buf`, `offset`): `number`

Defined in: [packages/core/src/agent/der.ts:70](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/der.ts#L70)

## Parameters

### buf

`Uint8Array`

### offset

`number`

## Returns

`number`
