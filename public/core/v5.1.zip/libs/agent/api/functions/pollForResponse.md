---
title: pollForResponse
editUrl: false
next: true
prev: true
---

> **pollForResponse**(`agent`, `canisterId`, `requestId`, `options?`): `Promise`\<[`PollForResponseResult`](../interfaces/PollForResponseResult.md)\>

Defined in: [packages/core/src/agent/polling/index.ts:126](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/polling/index.ts#L126)

Polls the IC to check the status of the given request then
returns the response bytes once the request has been processed.

## Parameters

### agent

[`Agent`](../interfaces/Agent.md)

The agent to use to poll read_state.

### canisterId

[`Principal`](../../../principal/api/classes/Principal.md)

The effective canister ID.

### requestId

[`RequestId`](../type-aliases/RequestId.md)

The Request ID to poll status for.

### options?

[`PollingOptions`](../interfaces/PollingOptions.md) = `{}`

polling options to control behavior

## Returns

`Promise`\<[`PollForResponseResult`](../interfaces/PollForResponseResult.md)\>

The certificate, reply bytes, and raw certificate bytes for the request.

## Throws

If the agent's root key is not available.

## Throws

If the request was rejected by the canister.

## Throws

If the request reached `done` status without a reply.
