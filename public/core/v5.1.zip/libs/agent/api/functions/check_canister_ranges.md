---
title: check_canister_ranges
editUrl: false
next: true
prev: true
---

> **check\_canister\_ranges**(`params`): `boolean`

Defined in: [packages/core/src/agent/certificate.ts:896](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L896)

Check if a canister ID falls within the canister ranges of a given subnet

## Parameters

### params

[`CheckCanisterRangesParams`](../interfaces/CheckCanisterRangesParams.md)

the parameters with which to check the canister ranges

## Returns

`boolean`

`true` if the canister is in the range, `false` otherwise
