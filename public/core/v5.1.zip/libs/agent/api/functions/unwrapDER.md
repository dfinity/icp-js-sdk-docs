---
title: unwrapDER
editUrl: false
next: true
prev: true
---

> **unwrapDER**(`derEncoded`, `oid`): `Uint8Array`

Defined in: [packages/core/src/agent/der.ts:165](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/der.ts#L165)

Extracts a payload from the given `derEncoded` data, and checks that it was tagged with the given `oid`.

`derEncoded = SEQUENCE(oid, BITSTRING(payload))`

## Parameters

### derEncoded

`Uint8Array`

The DER encoded and tagged data

### oid

`Uint8Array`

The DER encoded (and SEQUENCE wrapped!) expected OID

## Returns

`Uint8Array`

The unwrapped payload
