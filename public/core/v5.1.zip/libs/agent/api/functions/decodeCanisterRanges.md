---
title: decodeCanisterRanges
editUrl: false
next: true
prev: true
---

> **decodeCanisterRanges**(`lookupValue`): [`CanisterRanges`](../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/certificate.ts:973](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/certificate.ts#L973)

Decode canister ranges from CBOR-encoded buffer

## Parameters

### lookupValue

`Uint8Array`

the CBOR-encoded value read from the certificate

## Returns

[`CanisterRanges`](../type-aliases/CanisterRanges.md)

an array of canister range tuples [start, end]
