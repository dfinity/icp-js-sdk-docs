---
title: decodeCanisterRanges
editUrl: false
next: true
prev: true
---

> **decodeCanisterRanges**(`lookupValue`): [`CanisterRanges`](../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/certificate.ts:973](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L973)

Decode canister ranges from CBOR-encoded buffer

## Parameters

### lookupValue

`Uint8Array`

the CBOR-encoded value read from the certificate

## Returns

[`CanisterRanges`](../type-aliases/CanisterRanges.md)

an array of canister range tuples [start, end]
