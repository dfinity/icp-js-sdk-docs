---
title: calculateIngressExpiry
editUrl: false
next: true
prev: true
---

> **calculateIngressExpiry**(`maxIngressExpiryInMinutes`, `timeDiffMsecs`): [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/agent/http/index.ts:1678](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/agent/http/index.ts#L1678)

Calculates the ingress expiry time based on the maximum allowed expiry in minutes and the time difference in milliseconds.
The expiry is rounded down according to the [Expiry.fromDeltaInMilliseconds](../classes/Expiry.md#fromdeltainmilliseconds) method.

## Parameters

### maxIngressExpiryInMinutes

`number`

The maximum ingress expiry time in minutes.

### timeDiffMsecs

`number`

The time difference in milliseconds to adjust the expiry.

## Returns

[`Expiry`](../classes/Expiry.md)

The calculated ingress expiry as an Expiry object.
