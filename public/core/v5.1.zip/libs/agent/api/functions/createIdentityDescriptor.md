---
title: createIdentityDescriptor
editUrl: false
next: true
prev: true
---

> **createIdentityDescriptor**(`identity`): [`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)

Defined in: [packages/core/src/agent/auth.ts:139](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/auth.ts#L139)

Create an IdentityDescriptor from an Identity

## Parameters

### identity

identity describe in returned descriptor

[`SignIdentity`](../classes/SignIdentity.md) | [`AnonymousIdentity`](../classes/AnonymousIdentity.md)

## Returns

[`IdentityDescriptor`](../type-aliases/IdentityDescriptor.md)
