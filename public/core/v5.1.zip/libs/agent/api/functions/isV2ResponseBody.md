---
title: isV2ResponseBody
editUrl: false
next: true
prev: true
---

> **isV2ResponseBody**(`body`): `body is v2ResponseBody`

Defined in: [packages/core/src/agent/agent/api.ts:141](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/agent/api.ts#L141)

Utility function to check if a body is a v2ResponseBody for type safety.

## Parameters

### body

The body to check

[`v2ResponseBody`](../interfaces/v2ResponseBody.md) | [`v4ResponseBody`](../interfaces/v4ResponseBody.md) | `null`

## Returns

`body is v2ResponseBody`

boolean indicating if the body is a v2ResponseBody
