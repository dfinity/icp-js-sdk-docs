---
title: hashTreeToString
editUrl: false
next: true
prev: true
---

> **hashTreeToString**(`tree`): `string`

Defined in: [packages/core/src/agent/certificate.ts:77](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/agent/certificate.ts#L77)

Make a human readable string out of a hash tree.

## Parameters

### tree

[`HashTree`](../type-aliases/HashTree.md)

The hash tree to convert to a string

## Returns

`string`
