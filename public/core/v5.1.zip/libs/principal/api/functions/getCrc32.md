---
title: getCrc32
editUrl: false
next: true
prev: true
---

> **getCrc32**(`buf`): `number`

Defined in: [packages/core/src/principal/utils/getCrc.ts:42](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/principal/utils/getCrc.ts#L42)

Calculate the CRC32 of a Uint8Array.

## Parameters

### buf

`Uint8Array`

The Uint8Array to calculate the CRC32 of.

## Returns

`number`
