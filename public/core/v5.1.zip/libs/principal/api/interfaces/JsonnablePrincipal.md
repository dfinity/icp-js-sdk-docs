---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/principal/principal.ts:12](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/principal/principal.ts#L12)

## Properties

### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [packages/core/src/principal/principal.ts:13](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/principal/principal.ts#L13)
