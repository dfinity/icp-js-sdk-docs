---
title: CryptoKeyOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/ecdsa.ts:7](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L7)

Options used in a [ECDSAKeyIdentity](../classes/ECDSAKeyIdentity.md)

## Properties

### extractable?

> `optional` **extractable**: `boolean`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:8](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L8)

***

### keyUsages?

> `optional` **keyUsages**: `KeyUsage`[]

Defined in: [packages/core/src/identity/identity/ecdsa.ts:9](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L9)

***

### subtleCrypto?

> `optional` **subtleCrypto**: `SubtleCrypto`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:10](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L10)
