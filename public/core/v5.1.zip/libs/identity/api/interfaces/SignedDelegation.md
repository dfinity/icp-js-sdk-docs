---
title: SignedDelegation
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/delegation.ts:92](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/delegation.ts#L92)

A signed delegation, which lends its identity to the public key in the delegation
object. This is constructed by `DelegationChain.create()`.

[DelegationChain](../classes/DelegationChain.md)

## Properties

### delegation

> **delegation**: [`Delegation`](../classes/Delegation.md)

Defined in: [packages/core/src/identity/identity/delegation.ts:93](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/delegation.ts#L93)

***

### signature

> **signature**: [`Signature`](../../../agent/api/type-aliases/Signature.md)

Defined in: [packages/core/src/identity/identity/delegation.ts:94](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/delegation.ts#L94)
