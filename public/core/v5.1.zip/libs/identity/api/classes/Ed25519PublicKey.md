---
title: Ed25519PublicKey
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/ed25519.ts:21](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L21)

A Public Key implementation.

## Implements

- [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

## Accessors

### derKey

#### Get Signature

> **get** **derKey**(): [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/identity/identity/ed25519.ts:90](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L90)

##### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`derKey`](../../../agent/api/interfaces/PublicKey.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`

Defined in: [packages/core/src/identity/identity/ed25519.ts:84](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L84)

##### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`rawKey`](../../../agent/api/interfaces/PublicKey.md#rawkey)

## Methods

### toDer()

> **toDer**(): [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/identity/identity/ed25519.ts:103](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L103)

#### Returns

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`toDer`](../../../agent/api/interfaces/PublicKey.md#toder)

***

### toRaw()

> **toRaw**(): `Uint8Array`

Defined in: [packages/core/src/identity/identity/ed25519.ts:107](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L107)

#### Returns

`Uint8Array`

#### Implementation of

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md).[`toRaw`](../../../agent/api/interfaces/PublicKey.md#toraw)

***

### from()

> `static` **from**(`maybeKey`): `Ed25519PublicKey`

Defined in: [packages/core/src/identity/identity/ed25519.ts:27](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L27)

Construct Ed25519PublicKey from an existing PublicKey

#### Parameters

##### maybeKey

`unknown`

existing PublicKey, ArrayBuffer, DerEncodedPublicKey, or hex string

#### Returns

`Ed25519PublicKey`

Instance of Ed25519PublicKey

***

### fromDer()

> `static` **fromDer**(`derKey`): `Ed25519PublicKey`

Defined in: [packages/core/src/identity/identity/ed25519.ts:61](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L61)

#### Parameters

##### derKey

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

#### Returns

`Ed25519PublicKey`

***

### fromRaw()

> `static` **fromRaw**(`rawKey`): `Ed25519PublicKey`

Defined in: [packages/core/src/identity/identity/ed25519.ts:57](https://github.com/dfinity/icp-js-core/blob/52eda2f363dd5fb23ae1e98e2817eb808567a560/packages/core/src/identity/identity/ed25519.ts#L57)

#### Parameters

##### rawKey

`Uint8Array`

#### Returns

`Ed25519PublicKey`
