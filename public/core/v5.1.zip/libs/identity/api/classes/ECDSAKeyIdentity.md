---
title: ECDSAKeyIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/ecdsa.ts:47](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L47)

An identity interface that wraps an ECDSA keypair using the P-256 named curve. Supports DER-encoding and decoding for agent calls

## Extends

- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new ECDSAKeyIdentity**(`keyPair`, `derKey`, `subtleCrypto`): `ECDSAKeyIdentity`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:103](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L103)

#### Parameters

##### keyPair

`CryptoKeyPair`

##### derKey

[`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

##### subtleCrypto

`SubtleCrypto`

#### Returns

`ECDSAKeyIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_derKey

> `protected` **\_derKey**: [`DerEncodedPublicKey`](../../../agent/api/type-aliases/DerEncodedPublicKey.md)

Defined in: [packages/core/src/identity/identity/ecdsa.ts:98](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L98)

***

### \_keyPair

> `protected` **\_keyPair**: `CryptoKeyPair`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:99](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L99)

***

### \_principal

> `protected` **\_principal**: [`Principal`](../../../principal/api/classes/Principal.md) \| `undefined`

Defined in: [packages/core/src/agent/auth.ts:58](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/auth.ts#L58)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

***

### \_subtleCrypto

> `protected` **\_subtleCrypto**: `SubtleCrypto`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:100](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L100)

## Methods

### getKeyPair()

> **getKeyPair**(): `CryptoKeyPair`

Defined in: [packages/core/src/identity/identity/ecdsa.ts:118](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L118)

Return the internally-used key pair.

#### Returns

`CryptoKeyPair`

a CryptoKeyPair

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/auth.ts:74](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/auth.ts#L74)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md) & [`DerCryptoKey`](../interfaces/DerCryptoKey.md)

Defined in: [packages/core/src/identity/identity/ecdsa.ts:126](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L126)

Return the public key.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md) & [`DerCryptoKey`](../interfaces/DerCryptoKey.md)

an [& DerCryptoKey](../../../agent/api/interfaces/PublicKey.md)

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`challenge`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [packages/core/src/identity/identity/ecdsa.ts:141](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L141)

Signs a blob of data, with this identity's private key.

#### Parameters

##### challenge

`Uint8Array`

challenge to sign with this identity's secretKey, producing a signature

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

signature

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/agent/auth.ts:87](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/agent/auth.ts#L87)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### fromKeyPair()

> `static` **fromKeyPair**(`keyPair`, `subtleCrypto?`): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [packages/core/src/identity/identity/ecdsa.ts:84](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L84)

generates an identity from a public and private key. Please ensure that you are generating these keys securely and protect the user's private key

#### Parameters

##### keyPair

a CryptoKeyPair

`CryptoKeyPair` | \{ `privateKey`: `CryptoKey`; `publicKey`: `CryptoKey`; \}

##### subtleCrypto?

`SubtleCrypto`

a SubtleCrypto interface in case one is not available globally

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

an ECDSAKeyIdentity

***

### generate()

> `static` **generate**(`options?`): `Promise`\<`ECDSAKeyIdentity`\>

Defined in: [packages/core/src/identity/identity/ecdsa.ts:56](https://github.com/dfinity/icp-js-core/blob/c7fe96aaa3bb4c731428083883ae18cc4a43066c/packages/core/src/identity/identity/ecdsa.ts#L56)

Generates a randomly generated identity for use in calls to the Internet Computer.

#### Parameters

##### options?

[`CryptoKeyOptions`](../interfaces/CryptoKeyOptions.md)

optional settings

#### Returns

`Promise`\<`ECDSAKeyIdentity`\>

a ECDSAKeyIdentity
