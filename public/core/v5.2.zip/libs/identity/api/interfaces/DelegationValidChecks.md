---
title: DelegationValidChecks
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/delegation.ts:357](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L357)

List of things to check for a delegation chain validity.

## Properties

### scope?

> `optional` **scope?**: `string` \| [`Principal`](../../../principal/api/classes/Principal.md) \| (`string` \| [`Principal`](../../../principal/api/classes/Principal.md))[]

Defined in: [packages/core/src/identity/identity/delegation.ts:361](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L361)

Check that the scope is amongst the scopes that this delegation has access to.
