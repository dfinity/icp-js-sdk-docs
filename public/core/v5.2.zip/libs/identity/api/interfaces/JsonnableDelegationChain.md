---
title: JsonnableDelegationChain
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/delegation.ts:132](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L132)

## Properties

### delegations

> **delegations**: `object`[]

Defined in: [packages/core/src/identity/identity/delegation.ts:134](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L134)

#### delegation

> **delegation**: `object`

##### delegation.expiration

> **expiration**: `string`

##### delegation.pubkey

> **pubkey**: `string`

##### delegation.targets?

> `optional` **targets?**: `string`[]

#### signature

> **signature**: `string`

***

### publicKey

> **publicKey**: `string`

Defined in: [packages/core/src/identity/identity/delegation.ts:133](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L133)
