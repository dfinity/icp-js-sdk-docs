---
title: DelegationIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/delegation.ts:275](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L275)

An Identity that adds delegation to a request. Everywhere in this class, the name
innerKey refers to the SignIdentity that is being used to sign the requests, while
originalKey is the identity that is being borrowed. More identities can be used
in the middle to delegate.

## Extends

- [`SignIdentity`](../../../agent/api/classes/SignIdentity.md)

## Constructors

### Constructor

> `protected` **new DelegationIdentity**(`_inner`, `_delegation`): `DelegationIdentity`

Defined in: [packages/core/src/identity/identity/delegation.ts:288](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L288)

#### Parameters

##### \_inner

`Pick`\<[`SignIdentity`](../../../agent/api/classes/SignIdentity.md), `"sign"`\>

##### \_delegation

[`DelegationChain`](DelegationChain.md)

#### Returns

`DelegationIdentity`

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`constructor`](../../../agent/api/classes/SignIdentity.md#constructor)

## Properties

### \_principal

> `protected` **\_principal**: [`Principal`](../../../principal/api/classes/Principal.md) \| `undefined`

Defined in: [packages/core/src/agent/auth.ts:58](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/auth.ts#L58)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`_principal`](../../../agent/api/classes/SignIdentity.md#_principal)

## Methods

### getDelegation()

> **getDelegation**(): [`DelegationChain`](DelegationChain.md)

Defined in: [packages/core/src/identity/identity/delegation.ts:295](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L295)

#### Returns

[`DelegationChain`](DelegationChain.md)

***

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/auth.ts:74](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/auth.ts#L74)

Get the principal represented by this identity. Normally should be a
`Principal.selfAuthenticating()`.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPrincipal`](../../../agent/api/classes/SignIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

Defined in: [packages/core/src/identity/identity/delegation.ts:299](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L299)

Returns the public key that would match this identity's signature.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`getPublicKey`](../../../agent/api/classes/SignIdentity.md#getpublickey)

***

### sign()

> **sign**(`blob`): `Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

Defined in: [packages/core/src/identity/identity/delegation.ts:305](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L305)

Signs a blob of data, with this identity's private key.

#### Parameters

##### blob

`Uint8Array`

#### Returns

`Promise`\<[`Signature`](../../../agent/api/type-aliases/Signature.md)\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`sign`](../../../agent/api/classes/SignIdentity.md#sign)

***

### transformRequest()

> **transformRequest**(`request`): `Promise`\<`unknown`\>

Defined in: [packages/core/src/identity/identity/delegation.ts:309](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L309)

Transform a request into a signed version of the request. This is done last
after the transforms on the body of a request. The returned object can be
anything, but must be serializable to CBOR.

#### Parameters

##### request

[`HttpAgentRequest`](../../../agent/api/type-aliases/HttpAgentRequest.md)

internet computer request to transform

#### Returns

`Promise`\<`unknown`\>

#### Overrides

[`SignIdentity`](../../../agent/api/classes/SignIdentity.md).[`transformRequest`](../../../agent/api/classes/SignIdentity.md#transformrequest)

***

### fromDelegation()

> `static` **fromDelegation**(`key`, `delegation`): `DelegationIdentity`

Defined in: [packages/core/src/identity/identity/delegation.ts:281](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L281)

Create a delegation without having access to delegateKey.

#### Parameters

##### key

`Pick`\<[`SignIdentity`](../../../agent/api/classes/SignIdentity.md), `"sign"`\>

The key used to sign the requests.

##### delegation

[`DelegationChain`](DelegationChain.md)

A delegation object created using `createDelegation`.

#### Returns

`DelegationIdentity`
