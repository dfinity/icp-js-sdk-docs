---
title: PartialDelegationIdentity
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/identity/identity/delegation.ts:329](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L329)

A partial delegated identity, representing a delegation chain and the public key that it targets

## Extends

- [`PartialIdentity`](PartialIdentity.md)

## Accessors

### delegation

#### Get Signature

> **get** **delegation**(): [`DelegationChain`](DelegationChain.md)

Defined in: [packages/core/src/identity/identity/delegation.ts:335](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L335)

The Delegation Chain of this identity.

##### Returns

[`DelegationChain`](DelegationChain.md)

***

### derKey

#### Get Signature

> **get** **derKey**(): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/identity/identity/partial.ts:20](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/partial.ts#L20)

The DER-encoded public key of this identity.

##### Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`derKey`](PartialIdentity.md#derkey)

***

### rawKey

#### Get Signature

> **get** **rawKey**(): `Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

Defined in: [packages/core/src/identity/identity/partial.ts:13](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/partial.ts#L13)

The raw public key of this identity.

##### Returns

`Uint8Array`\<`ArrayBufferLike`\> \| `undefined`

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`rawKey`](PartialIdentity.md#rawkey)

## Methods

### getPrincipal()

> **getPrincipal**(): [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/identity/identity/partial.ts:41](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/partial.ts#L41)

The [Principal](../../../principal/api/classes/Principal.md) of this identity.

#### Returns

[`Principal`](../../../principal/api/classes/Principal.md)

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`getPrincipal`](PartialIdentity.md#getprincipal)

***

### getPublicKey()

> **getPublicKey**(): [`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

Defined in: [packages/core/src/identity/identity/partial.ts:34](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/partial.ts#L34)

The inner [PublicKey](../../../agent/api/interfaces/PublicKey.md) used by this identity.

#### Returns

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`getPublicKey`](PartialIdentity.md#getpublickey)

***

### toDer()

> **toDer**(): `Uint8Array`

Defined in: [packages/core/src/identity/identity/partial.ts:27](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/partial.ts#L27)

The DER-encoded public key of this identity.

#### Returns

`Uint8Array`

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`toDer`](PartialIdentity.md#toder)

***

### transformRequest()

> **transformRequest**(): `Promise`\<`never`\>

Defined in: [packages/core/src/identity/identity/partial.ts:51](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/partial.ts#L51)

Required for the Identity interface, but cannot implemented for just a public key.

#### Returns

`Promise`\<`never`\>

#### Inherited from

[`PartialIdentity`](PartialIdentity.md).[`transformRequest`](PartialIdentity.md#transformrequest)

***

### fromDelegation()

> `static` **fromDelegation**(`key`, `delegation`): `PartialDelegationIdentity`

Defined in: [packages/core/src/identity/identity/delegation.ts:349](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/identity/delegation.ts#L349)

Create a PartialDelegationIdentity from a [PublicKey](../../../agent/api/interfaces/PublicKey.md) and a [DelegationChain](DelegationChain.md).

#### Parameters

##### key

[`PublicKey`](../../../agent/api/interfaces/PublicKey.md)

The [PublicKey](../../../agent/api/interfaces/PublicKey.md) to delegate to.

##### delegation

[`DelegationChain`](DelegationChain.md)

a [DelegationChain](DelegationChain.md) targeting the inner key.

#### Returns

`PartialDelegationIdentity`
