---
title: JsonableSecp256k1Identity
editUrl: false
next: true
prev: true
---

> **JsonableSecp256k1Identity** = \[`PublicKeyHex`, `SecretKeyHex`\]

Defined in: [packages/core/src/identity/secp256k1/secp256k1.ts:19](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/identity/secp256k1/secp256k1.ts#L19)
