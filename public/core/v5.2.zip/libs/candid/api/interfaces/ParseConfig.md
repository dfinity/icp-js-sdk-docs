---
title: ParseConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:5](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L5)

## Properties

### random?

> `optional` **random?**: `boolean`

Defined in: [packages/core/src/candid/candid-core.ts:6](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L6)
