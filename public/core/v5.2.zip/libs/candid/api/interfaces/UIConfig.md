---
title: UIConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:9](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L9)

## Properties

### form?

> `optional` **form?**: [`InputForm`](../classes/InputForm.md)

Defined in: [packages/core/src/candid/candid-core.ts:11](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L11)

***

### input?

> `optional` **input?**: `HTMLElement`

Defined in: [packages/core/src/candid/candid-core.ts:10](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L10)

## Methods

### parse()

> **parse**(`t`, `config`, `v`): `any`

Defined in: [packages/core/src/candid/candid-core.ts:12](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L12)

#### Parameters

##### t

[`Type`](../namespaces/IDL/classes/Type.md)

##### config

[`ParseConfig`](ParseConfig.md)

##### v

`string`

#### Returns

`any`
