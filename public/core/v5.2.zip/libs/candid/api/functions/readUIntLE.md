---
title: readUIntLE
editUrl: false
next: true
prev: true
---

> **readUIntLE**(`pipe`, `byteLength`): `bigint`

Defined in: [packages/core/src/candid/utils/leb128.ts:202](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/utils/leb128.ts#L202)

## Parameters

### pipe

[`PipeArrayBuffer`](../classes/PipeArrayBuffer.md)

Pipe from buffer-pipe

### byteLength

`number`

number

## Returns

`bigint`

bigint
