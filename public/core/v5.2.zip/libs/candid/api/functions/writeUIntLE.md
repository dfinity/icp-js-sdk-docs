---
title: writeUIntLE
editUrl: false
next: true
prev: true
---

> **writeUIntLE**(`value`, `byteLength`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:162](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/utils/leb128.ts#L162)

## Parameters

### value

`number` \| `bigint`

bigint or number

### byteLength

`number`

number

## Returns

`Uint8Array`

Uint8Array
