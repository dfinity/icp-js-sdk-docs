---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`u1`, `u2`): `boolean`

Defined in: [packages/core/src/candid/utils/buffer.ts:207](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/utils/buffer.ts#L207)

Checks two uint8Arrays for equality.

## Parameters

### u1

`Uint8Array`

uint8Array 1

### u2

`Uint8Array`

uint8Array 2

## Returns

`boolean`

boolean
