---
title: lebEncode
editUrl: false
next: true
prev: true
---

> **lebEncode**(`value`): `Uint8Array`

Defined in: [packages/core/src/candid/utils/leb128.ts:44](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/utils/leb128.ts#L44)

Encode a positive number (or bigint) into a Buffer. The number will be floored to the
nearest integer.

## Parameters

### value

`number` \| `bigint`

The number to encode.

## Returns

`Uint8Array`
