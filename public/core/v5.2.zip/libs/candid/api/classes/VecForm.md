---
title: VecForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:250](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L250)

## Extends

- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new VecForm**(`ty`, `ui`): `VecForm`

Defined in: [packages/core/src/candid/candid-core.ts:251](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L251)

#### Parameters

##### ty

[`Type`](../namespaces/IDL/classes/Type.md)

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`VecForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L100)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ty

> **ty**: [`Type`](../namespaces/IDL/classes/Type.md)

Defined in: [packages/core/src/candid/candid-core.ts:252](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L252)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/core/src/candid/candid-core.ts:253](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L253)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:257](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L257)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**\<`T`\>(`config`): `T`[] \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:265](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L265)

#### Type Parameters

##### T

`T`

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`T`[] \| `undefined`

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L113)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L105)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
