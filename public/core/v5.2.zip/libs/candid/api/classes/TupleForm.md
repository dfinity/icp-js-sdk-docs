---
title: TupleForm
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/candid-core.ts:171](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L171)

## Extends

- [`InputForm`](InputForm.md)

## Constructors

### Constructor

> **new TupleForm**(`components`, `ui`): `TupleForm`

Defined in: [packages/core/src/candid/candid-core.ts:172](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L172)

#### Parameters

##### components

[`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

##### ui

[`FormConfig`](../interfaces/FormConfig.md)

#### Returns

`TupleForm`

#### Overrides

[`InputForm`](InputForm.md).[`constructor`](InputForm.md#constructor)

## Properties

### components

> **components**: [`Type`](../namespaces/IDL/classes/Type.md)\<`any`\>[]

Defined in: [packages/core/src/candid/candid-core.ts:173](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L173)

***

### form

> **form**: [`InputBox`](InputBox.md)[] = `[]`

Defined in: [packages/core/src/candid/candid-core.ts:100](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L100)

#### Inherited from

[`InputForm`](InputForm.md).[`form`](InputForm.md#form)

***

### ui

> **ui**: [`FormConfig`](../interfaces/FormConfig.md)

Defined in: [packages/core/src/candid/candid-core.ts:174](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L174)

#### Inherited from

[`InputForm`](InputForm.md).[`ui`](InputForm.md#ui)

## Methods

### generateForm()

> **generateForm**(): `void`

Defined in: [packages/core/src/candid/candid-core.ts:178](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L178)

#### Returns

`void`

#### Overrides

[`InputForm`](InputForm.md).[`generateForm`](InputForm.md#generateform)

***

### parse()

> **parse**(`config`): `any`[] \| `undefined`

Defined in: [packages/core/src/candid/candid-core.ts:184](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L184)

#### Parameters

##### config

[`ParseConfig`](../interfaces/ParseConfig.md)

#### Returns

`any`[] \| `undefined`

#### Overrides

[`InputForm`](InputForm.md).[`parse`](InputForm.md#parse)

***

### render()

> **render**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:113](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L113)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`render`](InputForm.md#render)

***

### renderForm()

> **renderForm**(`dom`): `void`

Defined in: [packages/core/src/candid/candid-core.ts:105](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/candid-core.ts#L105)

#### Parameters

##### dom

`HTMLElement`

#### Returns

`void`

#### Inherited from

[`InputForm`](InputForm.md).[`renderForm`](InputForm.md#renderform)
