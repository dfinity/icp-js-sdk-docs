---
title: TupleClass
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/idl.ts:1423](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1423)

Represents Tuple, a syntactic sugar for Record.

## Param

## Extends

- [`RecordClass`](RecordClass.md)

## Type Parameters

### T

`T` *extends* `any`[]

## Constructors

### Constructor

> **new TupleClass**\<`T`\>(`_components`): `TupleClass`\<`T`\>

Defined in: [packages/core/src/candid/idl.ts:1434](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1434)

#### Parameters

##### \_components

[`Type`](Type.md)\<`any`\>[]

#### Returns

`TupleClass`\<`T`\>

#### Overrides

[`RecordClass`](RecordClass.md).[`constructor`](RecordClass.md#constructor)

## Properties

### \_components

> `protected` `readonly` **\_components**: [`Type`](Type.md)\<`any`\>[]

Defined in: [packages/core/src/candid/idl.ts:1432](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1432)

***

### \_fields

> `readonly` **\_fields**: \[`string`, [`Type`](Type.md)\<`any`\>\][]

Defined in: [packages/core/src/candid/idl.ts:1269](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1269)

#### Inherited from

[`RecordClass`](RecordClass.md).[`_fields`](RecordClass.md#_fields)

## Accessors

### fieldsAsObject

#### Get Signature

> **get** **fieldsAsObject**(): `Record`\<`number`, [`Type`](Type.md)\>

Defined in: [packages/core/src/candid/idl.ts:1394](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1394)

##### Returns

`Record`\<`number`, [`Type`](Type.md)\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`fieldsAsObject`](RecordClass.md#fieldsasobject)

***

### name

#### Get Signature

> **get** **name**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1402](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1402)

##### Returns

`string`

#### Inherited from

[`RecordClass`](RecordClass.md).[`name`](RecordClass.md#name)

***

### typeName

#### Get Signature

> **get** **typeName**(): `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:1424](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1424)

##### Returns

`IdlTypeName`

#### Overrides

[`RecordClass`](RecordClass.md).[`typeName`](RecordClass.md#typename)

## Methods

### \_buildTypeTableImpl()

> **\_buildTypeTableImpl**(`T`): `void`

Defined in: [packages/core/src/candid/idl.ts:1321](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1321)

#### Parameters

##### T

`TypeTable`

#### Returns

`void`

#### Inherited from

[`RecordClass`](RecordClass.md).[`_buildTypeTableImpl`](RecordClass.md#_buildtypetableimpl)

***

### accept()

> **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:1441](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1441)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

#### Overrides

[`RecordClass`](RecordClass.md).[`accept`](RecordClass.md#accept)

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L260)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

#### Inherited from

[`RecordClass`](RecordClass.md).[`buildTypeTable`](RecordClass.md#buildtypetable)

***

### checkType()

> **checkType**(`t`): [`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

Defined in: [packages/core/src/candid/idl.ts:306](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L306)

#### Parameters

##### t

[`Type`](Type.md)

#### Returns

[`ConstructType`](ConstructType.md)\<`Record`\<`string`, `any`\>\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`checkType`](RecordClass.md#checktype)

***

### covariant()

> **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:1445](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1445)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

#### Overrides

[`RecordClass`](RecordClass.md).[`covariant`](RecordClass.md#covariant)

***

### decodeValue()

> **decodeValue**(`b`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:1472](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1472)

#### Parameters

##### b

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

[`Type`](Type.md)

#### Returns

`T`

#### Overrides

[`RecordClass`](RecordClass.md).[`decodeValue`](RecordClass.md#decodevalue)

***

### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:1494](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1494)

#### Returns

`string`

#### Overrides

[`RecordClass`](RecordClass.md).[`display`](RecordClass.md#display)

***

### encodeType()

> **encodeType**(`typeTable`): `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/core/src/candid/idl.ts:316](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L316)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`\<`ArrayBufferLike`\>

#### Inherited from

[`RecordClass`](RecordClass.md).[`encodeType`](RecordClass.md#encodetype)

***

### encodeValue()

> **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:1467](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1467)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`any`[]

#### Returns

`Uint8Array`

#### Overrides

[`RecordClass`](RecordClass.md).[`encodeValue`](RecordClass.md#encodevalue)

***

### tryAsTuple()

> **tryAsTuple**(): [`Type`](Type.md)\<`any`\>[] \| `null`

Defined in: [packages/core/src/candid/idl.ts:1280](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1280)

#### Returns

[`Type`](Type.md)\<`any`\>[] \| `null`

#### Inherited from

[`RecordClass`](RecordClass.md).[`tryAsTuple`](RecordClass.md#tryastuple)

***

### valueToString()

> **valueToString**(`values`): `string`

Defined in: [packages/core/src/candid/idl.ts:1499](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1499)

#### Parameters

##### values

`any`[]

#### Returns

`string`

#### Overrides

[`RecordClass`](RecordClass.md).[`valueToString`](RecordClass.md#valuetostring)

***

### \[hasInstance\]()

> `static` **\[hasInstance\]**\<`T`\>(`instance`): `instance is TupleClass<T>`

Defined in: [packages/core/src/candid/idl.ts:1428](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L1428)

#### Type Parameters

##### T

`T` *extends* `any`[]

#### Parameters

##### instance

`any`

#### Returns

`instance is TupleClass<T>`

#### Overrides

[`RecordClass`](RecordClass.md).[`[hasInstance]`](RecordClass.md#hasinstance)
