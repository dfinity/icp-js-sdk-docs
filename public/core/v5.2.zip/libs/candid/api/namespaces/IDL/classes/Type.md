---
title: Type
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/candid/idl.ts:245](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L245)

Represents an IDL type.

## Extended by

- [`PrimitiveType`](PrimitiveType.md)
- [`ConstructType`](ConstructType.md)
- [`UnknownClass`](UnknownClass.md)

## Type Parameters

### T

`T` = `any`

## Constructors

### Constructor

> **new Type**\<`T`\>(): `Type`\<`T`\>

#### Returns

`Type`\<`T`\>

## Properties

### name

> `abstract` `readonly` **name**: `string`

Defined in: [packages/core/src/candid/idl.ts:247](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L247)

***

### typeName

> `abstract` `readonly` **typeName**: `IdlTypeName`

Defined in: [packages/core/src/candid/idl.ts:246](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L246)

## Methods

### \_buildTypeTableImpl()

> `abstract` `protected` **\_buildTypeTableImpl**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:289](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L289)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### accept()

> `abstract` **accept**\<`D`, `R`\>(`v`, `d`): `R`

Defined in: [packages/core/src/candid/idl.ts:248](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L248)

#### Type Parameters

##### D

`D`

##### R

`R`

#### Parameters

##### v

[`Visitor`](Visitor.md)\<`D`, `R`\>

##### d

`D`

#### Returns

`R`

***

### buildTypeTable()

> **buildTypeTable**(`typeTable`): `void`

Defined in: [packages/core/src/candid/idl.ts:260](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L260)

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`void`

***

### checkType()

> `abstract` **checkType**(`t`): `Type`

Defined in: [packages/core/src/candid/idl.ts:285](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L285)

#### Parameters

##### t

`Type`

#### Returns

`Type`

***

### covariant()

> `abstract` **covariant**(`x`): `x is T`

Defined in: [packages/core/src/candid/idl.ts:270](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L270)

Assert that JavaScript's `x` is the proper type represented by this
Type.

#### Parameters

##### x

`any`

#### Returns

`x is T`

***

### decodeValue()

> `abstract` **decodeValue**(`x`, `t`): `T`

Defined in: [packages/core/src/candid/idl.ts:287](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L287)

#### Parameters

##### x

[`PipeArrayBuffer`](../../../classes/PipeArrayBuffer.md)

##### t

`Type`

#### Returns

`T`

***

### display()

> **display**(): `string`

Defined in: [packages/core/src/candid/idl.ts:251](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L251)

#### Returns

`string`

***

### encodeType()

> `abstract` **encodeType**(`typeTable`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:283](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L283)

Implement `I` in the IDL spec.
Encode this type for the type table.

#### Parameters

##### typeTable

`TypeTable`

#### Returns

`Uint8Array`

***

### encodeValue()

> `abstract` **encodeValue**(`x`): `Uint8Array`

Defined in: [packages/core/src/candid/idl.ts:277](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L277)

**`Internal`**

Encode the value. This needs to be public because it is used by
encodeValue() from different types.

#### Parameters

##### x

`T`

#### Returns

`Uint8Array`

***

### valueToString()

> **valueToString**(`x`): `string`

Defined in: [packages/core/src/candid/idl.ts:255](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L255)

#### Parameters

##### x

`T`

#### Returns

`string`
