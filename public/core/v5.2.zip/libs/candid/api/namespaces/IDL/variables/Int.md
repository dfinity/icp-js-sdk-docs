---
title: Int
editUrl: false
next: true
prev: true
---

> `const` **Int**: [`IntClass`](../classes/IntClass.md)

Defined in: [packages/core/src/candid/idl.ts:2355](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/candid/idl.ts#L2355)
