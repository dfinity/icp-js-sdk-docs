---
title: GetCanisterEnvOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/canister-env/index.ts:73](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/canister-env/index.ts#L73)

**`Experimental`**

Options for the [getCanisterEnv](../functions/getCanisterEnv.md) function

## Properties

### cookieName?

> `optional` **cookieName?**: `string`

Defined in: [packages/core/src/agent/canister-env/index.ts:78](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/canister-env/index.ts#L78)

**`Experimental`**

The name of the cookie to get the environment variables from.

#### Default

```ts
'ic_env'
```
