---
title: LookupSubtreeResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:557](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L557)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupSubtreeStatus.md#unknown)

Defined in: [packages/core/src/agent/certificate.ts:558](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L558)
