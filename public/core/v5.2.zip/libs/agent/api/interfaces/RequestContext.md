---
title: RequestContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:26](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L26)

## Properties

### ingressExpiry

> **ingressExpiry**: [`Expiry`](../classes/Expiry.md)

Defined in: [packages/core/src/agent/errors.ts:30](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L30)

***

### requestId?

> `optional` **requestId?**: [`RequestId`](../type-aliases/RequestId.md)

Defined in: [packages/core/src/agent/errors.ts:27](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L27)

***

### senderPubKey

> **senderPubKey**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:28](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L28)

***

### senderSignature

> **senderSignature**: `Uint8Array`

Defined in: [packages/core/src/agent/errors.ts:29](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L29)
