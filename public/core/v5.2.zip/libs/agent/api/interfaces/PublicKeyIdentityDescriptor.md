---
title: PublicKeyIdentityDescriptor
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/auth.ts:129](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/auth.ts#L129)

## Properties

### publicKey

> **publicKey**: `string`

Defined in: [packages/core/src/agent/auth.ts:131](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/auth.ts#L131)

***

### type

> **type**: `"PublicKeyIdentity"`

Defined in: [packages/core/src/agent/auth.ts:130](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/auth.ts#L130)
