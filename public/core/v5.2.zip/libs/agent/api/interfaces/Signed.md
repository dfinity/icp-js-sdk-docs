---
title: Signed
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:43](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L43)

## Type Parameters

### T

`T`

## Properties

### content

> **content**: `T`

Defined in: [packages/core/src/agent/agent/http/types.ts:44](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L44)

***

### sender\_pubkey

> **sender\_pubkey**: `ArrayBuffer`

Defined in: [packages/core/src/agent/agent/http/types.ts:45](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L45)

***

### sender\_sig

> **sender\_sig**: `ArrayBuffer`

Defined in: [packages/core/src/agent/agent/http/types.ts:46](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L46)
