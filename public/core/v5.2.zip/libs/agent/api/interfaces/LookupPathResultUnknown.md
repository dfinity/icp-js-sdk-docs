---
title: LookupPathResultUnknown
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:528](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L528)

## Properties

### status

> **status**: [`Unknown`](../enumerations/LookupPathStatus.md#unknown)

Defined in: [packages/core/src/agent/certificate.ts:529](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L529)
