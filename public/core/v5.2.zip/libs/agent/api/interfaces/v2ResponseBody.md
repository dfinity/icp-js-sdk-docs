---
title: v2ResponseBody
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:130](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L130)

## Properties

### error\_code?

> `optional` **error\_code?**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:131](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L131)

***

### reject\_code

> **reject\_code**: `number`

Defined in: [packages/core/src/agent/agent/api.ts:132](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L132)

***

### reject\_message

> **reject\_message**: `string`

Defined in: [packages/core/src/agent/agent/api.ts:133](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L133)
