---
title: UpdateResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:178](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L178)

The result of [Agent.update](Agent.md#update), extending [PollForResponseResult](PollForResponseResult.md)
with the request details and raw HTTP response from the call.

## Extends

- [`PollForResponseResult`](PollForResponseResult.md)

## Properties

### callResponse

> **callResponse**: `object`

Defined in: [packages/core/src/agent/agent/api.ts:182](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L182)

The raw HTTP response from the call endpoint.

#### body

> **body**: [`v2ResponseBody`](v2ResponseBody.md) \| [`v4ResponseBody`](v4ResponseBody.md) \| `null`

#### headers

> **headers**: [`HttpHeaderField`](../type-aliases/HttpHeaderField.md)[]

#### ok

> **ok**: `boolean`

#### status

> **status**: `number`

#### statusText

> **statusText**: `string`

***

### certificate

> **certificate**: [`Certificate`](../classes/Certificate.md)

Defined in: [packages/core/src/agent/polling/types.ts:23](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/polling/types.ts#L23)

The certificate for the request, which can be used to verify the reply.

#### Inherited from

[`PollForResponseResult`](PollForResponseResult.md).[`certificate`](PollForResponseResult.md#certificate)

***

### rawCertificate

> **rawCertificate**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:27](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/polling/types.ts#L27)

The raw certificate bytes for the request.

#### Inherited from

[`PollForResponseResult`](PollForResponseResult.md).[`rawCertificate`](PollForResponseResult.md#rawcertificate)

***

### reply

> **reply**: `Uint8Array`

Defined in: [packages/core/src/agent/polling/types.ts:25](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/polling/types.ts#L25)

The reply bytes for the request.

#### Inherited from

[`PollForResponseResult`](PollForResponseResult.md).[`reply`](PollForResponseResult.md#reply)

***

### requestDetails?

> `optional` **requestDetails?**: [`CallRequest`](CallRequest.md)

Defined in: [packages/core/src/agent/agent/api.ts:180](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L180)

The request details from the call, if available.
