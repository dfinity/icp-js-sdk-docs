---
title: LookupSubtreeResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:561](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L561)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupSubtreeStatus.md#found)

Defined in: [packages/core/src/agent/certificate.ts:562](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L562)

***

### value

> **value**: [`HashTree`](../type-aliases/HashTree.md)

Defined in: [packages/core/src/agent/certificate.ts:563](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L563)
