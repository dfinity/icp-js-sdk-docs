---
title: ReadStateOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:23](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L23)

Options when doing a [Agent.readState](Agent.md#readstate) call.

## Properties

### paths

> **paths**: `Uint8Array`\<`ArrayBufferLike`\>[][]

Defined in: [packages/core/src/agent/agent/api.ts:27](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L27)

A list of paths to read the state of.
