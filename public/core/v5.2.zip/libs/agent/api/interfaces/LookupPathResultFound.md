---
title: LookupPathResultFound
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:532](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L532)

## Properties

### status

> **status**: [`Found`](../enumerations/LookupPathStatus.md#found)

Defined in: [packages/core/src/agent/certificate.ts:533](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L533)

***

### value

> **value**: `Uint8Array`

Defined in: [packages/core/src/agent/certificate.ts:534](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L534)
