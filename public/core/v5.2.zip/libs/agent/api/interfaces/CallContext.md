---
title: CallContext
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/errors.ts:44](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L44)

Call context for errors that arise from a direct HTTP call response.

## Extends

- [`PollingCallContext`](PollingCallContext.md)

## Properties

### canisterId

> **canisterId**: [`Principal`](../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/errors.ts:37](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L37)

#### Inherited from

[`PollingCallContext`](PollingCallContext.md).[`canisterId`](PollingCallContext.md#canisterid)

***

### httpDetails

> **httpDetails**: [`HttpDetailsResponse`](HttpDetailsResponse.md)

Defined in: [packages/core/src/agent/errors.ts:45](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L45)

***

### methodName

> **methodName**: `string`

Defined in: [packages/core/src/agent/errors.ts:38](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L38)

#### Inherited from

[`PollingCallContext`](PollingCallContext.md).[`methodName`](PollingCallContext.md#methodname)
