---
title: NodeSignature
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:57](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L57)

## Properties

### identity

> **identity**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:63](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L63)

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/core/src/agent/agent/api.ts:61](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L61)

***

### timestamp

> **timestamp**: `bigint`

Defined in: [packages/core/src/agent/agent/api.ts:59](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L59)
