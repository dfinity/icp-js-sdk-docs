---
title: ObserveFunction
editUrl: false
next: true
prev: true
---

> **ObserveFunction**\<`T`\> = (`data`, ...`rest`) => `void`

Defined in: [packages/core/src/agent/observable.ts:3](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/observable.ts#L3)

## Type Parameters

### T

`T`

## Parameters

### data

`T`

### rest

...`unknown`[]

## Returns

`void`
