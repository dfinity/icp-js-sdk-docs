---
title: RequestId
editUrl: false
next: true
prev: true
---

> **RequestId** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/request\_id.ts:8](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/request_id.ts#L8)

## Type Declaration

### \_\_requestId\_\_

> **\_\_requestId\_\_**: `void`
