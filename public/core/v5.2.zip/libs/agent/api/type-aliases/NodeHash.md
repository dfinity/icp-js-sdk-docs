---
title: NodeHash
editUrl: false
next: true
prev: true
---

> **NodeHash** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:58](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L58)

## Type Declaration

### \_\_nodeHash\_\_

> **\_\_nodeHash\_\_**: `void`
