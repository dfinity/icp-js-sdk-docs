---
title: QueryStrategy
editUrl: false
next: true
prev: true
---

> **QueryStrategy** = `"query"` \| `"update"`

Defined in: [packages/core/src/agent/actor.ts:25](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/actor.ts#L25)

Controls how query and composite_query methods are executed.

- `'query'` — standard non-replicated query call (default).
- `'update'` — send query methods as update calls that go through consensus.
