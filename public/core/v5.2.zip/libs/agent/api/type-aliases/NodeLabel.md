---
title: NodeLabel
editUrl: false
next: true
prev: true
---

> **NodeLabel** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/certificate.ts:56](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L56)

## Type Declaration

### \_\_nodeLabel\_\_

> **\_\_nodeLabel\_\_**: `void`
