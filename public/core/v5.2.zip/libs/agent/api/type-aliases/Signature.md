---
title: Signature
editUrl: false
next: true
prev: true
---

> **Signature** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/auth.ts:22](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/auth.ts#L22)

A signature array buffer.

## Type Declaration

### \_\_signature\_\_

> **\_\_signature\_\_**: `void`
