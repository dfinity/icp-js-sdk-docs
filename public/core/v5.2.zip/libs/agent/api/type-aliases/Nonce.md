---
title: Nonce
editUrl: false
next: true
prev: true
---

> **Nonce** = `Uint8Array` & `object`

Defined in: [packages/core/src/agent/agent/http/types.ts:125](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L125)

## Type Declaration

### \_\_nonce\_\_

> **\_\_nonce\_\_**: `void`
