---
title: EmptyHashTree
editUrl: false
next: true
prev: true
---

> **EmptyHashTree** = \[[`Empty`](../enumerations/NodeType.md#empty)\]

Defined in: [packages/core/src/agent/certificate.ts:60](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L60)
