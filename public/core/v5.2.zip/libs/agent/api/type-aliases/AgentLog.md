---
title: AgentLog
editUrl: false
next: true
prev: true
---

> **AgentLog** = \{ `level`: `"warn"` \| `"info"`; `message`: `string`; \} \| \{ `error`: [`AgentError`](../classes/AgentError.md); `level`: `"error"`; `message`: `string`; \}

Defined in: [packages/core/src/agent/observable.ts:25](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/observable.ts#L25)
