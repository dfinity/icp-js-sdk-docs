---
title: CanisterRanges
editUrl: false
next: true
prev: true
---

> **CanisterRanges** = \[[`Principal`](../../../principal/api/classes/Principal.md), [`Principal`](../../../principal/api/classes/Principal.md)\][]

Defined in: [packages/core/src/agent/certificate.ts:886](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L886)

Canister ranges in the form of an array of [start, end] principal tuples,
usually decoded from the certificate.
