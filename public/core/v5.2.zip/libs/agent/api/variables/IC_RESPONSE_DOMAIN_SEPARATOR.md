---
title: IC_RESPONSE_DOMAIN_SEPARATOR
editUrl: false
next: true
prev: true
---

> `const` **IC\_RESPONSE\_DOMAIN\_SEPARATOR**: `Uint8Array`\<`ArrayBuffer`\>

Defined in: [packages/core/src/agent/constants.ts:17](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/constants.ts#L17)

The `\x0Bic-response` domain separator used in the signature of IC responses.
