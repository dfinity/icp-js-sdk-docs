---
title: ACTOR_METHOD_WITH_CERTIFICATE
editUrl: false
next: true
prev: true
---

> `const` **ACTOR\_METHOD\_WITH\_CERTIFICATE**: `"certificate"` = `'certificate'`

Defined in: [packages/core/src/agent/actor.ts:378](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/actor.ts#L378)
