---
title: UNREACHABLE_ERROR
editUrl: false
next: true
prev: true
---

> `const` **UNREACHABLE\_ERROR**: `Error`

Defined in: [packages/core/src/agent/errors.ts:962](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/errors.ts#L962)

Special error used to indicate that a code path is unreachable.

For internal use only.
