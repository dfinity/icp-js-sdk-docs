---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"canisterRanges"` \| `"publicKey"` \| `"nodeKeys"` \| [`CustomPath`](../../CanisterStatus/classes/CustomPath.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:52](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/subnetStatus/index.ts#L52)

Pre-configured fields for subnet status paths
