---
title: encodePath
editUrl: false
next: true
prev: true
---

> **encodePath**(`path`, `subnetId`): `Uint8Array`\<`ArrayBufferLike`\>[]

Defined in: [packages/core/src/agent/subnetStatus/index.ts:233](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/subnetStatus/index.ts#L233)

Encode a path for subnet state queries

## Parameters

### path

[`Path`](../type-aliases/Path.md)

the path to encode

### subnetId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the subnet ID

## Returns

`Uint8Array`\<`ArrayBufferLike`\>[]

the encoded path as an array of Uint8Arrays
