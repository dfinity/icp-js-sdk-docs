---
title: lookupSubnetInfo
editUrl: false
next: true
prev: true
---

> **lookupSubnetInfo**(`certificate`, `subnetId`): [`SubnetStatus`](../type-aliases/SubnetStatus.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:202](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/subnetStatus/index.ts#L202)

Fetch subnet info including node keys from a certificate

## Parameters

### certificate

`Uint8Array`

the certificate bytes

### subnetId

[`Principal`](../../../../../principal/api/classes/Principal.md)

the subnet ID

## Returns

[`SubnetStatus`](../type-aliases/SubnetStatus.md)

SubnetStatus with subnet ID and node keys
