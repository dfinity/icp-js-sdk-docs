---
title: IC_ROOT_SUBNET_ID
editUrl: false
next: true
prev: true
---

> `const` **IC\_ROOT\_SUBNET\_ID**: [`Principal`](../../../../../principal/api/classes/Principal.md)

Defined in: [packages/core/src/agent/utils/readState.ts:26](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/utils/readState.ts#L26)

The root subnet ID for IC mainnet
