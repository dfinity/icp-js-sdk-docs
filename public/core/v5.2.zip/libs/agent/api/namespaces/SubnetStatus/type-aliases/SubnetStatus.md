---
title: SubnetStatus
editUrl: false
next: true
prev: true
---

> **SubnetStatus** = `BaseSubnetStatus` & `object`

Defined in: [packages/core/src/agent/subnetStatus/index.ts:40](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/subnetStatus/index.ts#L40)

## Type Declaration

### publicKey

> **publicKey**: `Uint8Array`

The public key of the subnet
