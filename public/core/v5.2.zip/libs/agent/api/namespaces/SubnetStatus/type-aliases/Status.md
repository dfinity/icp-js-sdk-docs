---
title: Status
editUrl: false
next: true
prev: true
---

> **Status** = `BaseStatus` \| `SubnetNodeKeys` \| [`CanisterRanges`](../../../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/subnetStatus/index.ts:47](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/subnetStatus/index.ts#L47)
