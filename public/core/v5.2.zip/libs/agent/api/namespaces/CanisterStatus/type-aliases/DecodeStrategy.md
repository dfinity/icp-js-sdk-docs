---
title: DecodeStrategy
editUrl: false
next: true
prev: true
---

> **DecodeStrategy** = `"cbor"` \| `"hex"` \| `"leb128"` \| `"utf-8"` \| `"raw"`

Defined in: [packages/core/src/agent/utils/readState.ts:59](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/utils/readState.ts#L59)

Decode strategy for custom paths
