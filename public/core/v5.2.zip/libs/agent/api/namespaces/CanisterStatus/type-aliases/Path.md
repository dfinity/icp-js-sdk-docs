---
title: Path
editUrl: false
next: true
prev: true
---

> **Path** = `"time"` \| `"controllers"` \| `"subnet"` \| `"module_hash"` \| `"candid"` \| [`CustomPath`](../classes/CustomPath.md)

Defined in: [packages/core/src/agent/canisterStatus/index.ts:38](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/canisterStatus/index.ts#L38)

Pre-configured fields for canister status paths
