---
title: once
editUrl: false
next: true
prev: true
---

> **once**(): [`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>

Defined in: [packages/core/src/agent/polling/strategy.ts:25](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/polling/strategy.ts#L25)

Predicate that returns true once.

## Returns

[`Predicate`](../type-aliases/Predicate.md)\<`boolean`\>
