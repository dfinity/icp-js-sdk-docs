---
title: randomNumber
editUrl: false
next: true
prev: true
---

> **randomNumber**(): `number`

Defined in: [packages/core/src/agent/utils/random.ts:5](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/utils/random.ts#L5)

Generates a random unsigned 32-bit integer between 0 and 0xffffffff

## Returns

`number`

a random number
