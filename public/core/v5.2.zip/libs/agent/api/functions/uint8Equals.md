---
title: uint8Equals
editUrl: false
next: true
prev: true
---

> **uint8Equals**(`a`, `b`): `boolean`

Defined in: [packages/core/src/agent/utils/buffer.ts:54](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/utils/buffer.ts#L54)

Compares two Uint8Arrays for equality.

## Parameters

### a

`Uint8Array`

The first Uint8Array.

### b

`Uint8Array`

The second Uint8Array.

## Returns

`boolean`

True if the Uint8Arrays are equal, false otherwise.
