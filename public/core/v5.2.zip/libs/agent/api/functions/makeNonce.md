---
title: makeNonce
editUrl: false
next: true
prev: true
---

> **makeNonce**(): [`Nonce`](../type-aliases/Nonce.md)

Defined in: [packages/core/src/agent/agent/http/types.ts:130](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L130)

Create a random Nonce, based on random values

## Returns

[`Nonce`](../type-aliases/Nonce.md)
