---
title: encodeLenBytes
editUrl: false
next: true
prev: true
---

> **encodeLenBytes**(`len`): `number`

Defined in: [packages/core/src/agent/der.ts:9](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/der.ts#L9)

## Parameters

### len

`number`

## Returns

`number`
