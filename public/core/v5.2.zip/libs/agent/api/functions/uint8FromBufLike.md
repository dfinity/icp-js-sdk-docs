---
title: uint8FromBufLike
editUrl: false
next: true
prev: true
---

> **uint8FromBufLike**(`bufLike`): `Uint8Array`

Defined in: [packages/core/src/agent/utils/buffer.ts:6](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/utils/buffer.ts#L6)

Returns a true Uint8Array from an ArrayBufferLike object.

## Parameters

### bufLike

`ArrayBufferLike` \| `Uint8Array`\<`ArrayBufferLike`\> \| `number`[] \| `DataView`\<`ArrayBufferLike`\> \| `ArrayBufferView`\<`ArrayBufferLike`\> \| \[`number`\] \| \{ `buffer`: `ArrayBuffer`; \}

a buffer-like object

## Returns

`Uint8Array`

Uint8Array
