---
title: decodeCanisterRanges
editUrl: false
next: true
prev: true
---

> **decodeCanisterRanges**(`lookupValue`): [`CanisterRanges`](../type-aliases/CanisterRanges.md)

Defined in: [packages/core/src/agent/certificate.ts:973](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L973)

Decode canister ranges from CBOR-encoded buffer

## Parameters

### lookupValue

`Uint8Array`

the CBOR-encoded value read from the certificate

## Returns

[`CanisterRanges`](../type-aliases/CanisterRanges.md)

an array of canister range tuples [start, end]
