---
title: NodeType
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/certificate.ts:47](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L47)

## Enumeration Members

### Empty

> **Empty**: `0`

Defined in: [packages/core/src/agent/certificate.ts:48](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L48)

***

### Fork

> **Fork**: `1`

Defined in: [packages/core/src/agent/certificate.ts:49](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L49)

***

### Labeled

> **Labeled**: `2`

Defined in: [packages/core/src/agent/certificate.ts:50](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L50)

***

### Leaf

> **Leaf**: `3`

Defined in: [packages/core/src/agent/certificate.ts:51](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L51)

***

### Pruned

> **Pruned**: `4`

Defined in: [packages/core/src/agent/certificate.ts:52](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/certificate.ts#L52)
