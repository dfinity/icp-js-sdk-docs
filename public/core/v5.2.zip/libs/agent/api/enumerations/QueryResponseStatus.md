---
title: QueryResponseStatus
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/api.ts:35](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L35)

## Enumeration Members

### Rejected

> **Rejected**: `"rejected"`

Defined in: [packages/core/src/agent/agent/api.ts:37](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L37)

***

### Replied

> **Replied**: `"replied"`

Defined in: [packages/core/src/agent/agent/api.ts:36](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/api.ts#L36)
