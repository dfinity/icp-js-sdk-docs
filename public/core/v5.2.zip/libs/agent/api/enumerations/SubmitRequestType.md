---
title: SubmitRequestType
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/agent/agent/http/types.ts:73](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L73)

## Enumeration Members

### Call

> **Call**: `"call"`

Defined in: [packages/core/src/agent/agent/http/types.ts:74](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/agent/agent/http/types.ts#L74)
