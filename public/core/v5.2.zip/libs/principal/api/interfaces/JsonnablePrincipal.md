---
title: JsonnablePrincipal
editUrl: false
next: true
prev: true
---

Defined in: [packages/core/src/principal/principal.ts:12](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/principal/principal.ts#L12)

## Properties

### \_\_principal\_\_

> **\_\_principal\_\_**: `string`

Defined in: [packages/core/src/principal/principal.ts:13](https://github.com/dfinity/icp-js-core/blob/5ff59c7408b849d1921e524d6e72e570e5578813/packages/core/src/principal/principal.ts#L13)
